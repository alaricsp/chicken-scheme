/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-04-15 09:13
   Version 4.0.1 - SVN rev. 14255
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-04-15 on lenovo-1 (MINGW32_NT-6.0)
   command line: support.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[511];
static double C_possibly_force_alignment;


/* from k4553 */
static C_word C_fcall stub338(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub338(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4546 */
static C_word C_fcall stub333(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub333(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11595)
static void C_ccall f_11595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11609)
static void C_ccall f_11609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11613)
static void C_ccall f_11613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11624)
static void C_ccall f_11624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11636)
static void C_ccall f_11636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11644)
static void C_ccall f_11644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11648)
static void C_ccall f_11648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11607)
static void C_ccall f_11607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11598)
static void C_ccall f_11598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11601)
static void C_ccall f_11601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11582)
static void C_ccall f_11582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11587)
static void C_ccall f_11587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11571)
static void C_ccall f_11571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11576)
static void C_ccall f_11576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11565)
static void C_ccall f_11565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11537)
static void C_ccall f_11537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11537)
static void C_ccall f_11537r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11541)
static void C_ccall f_11541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11516)
static void C_ccall f_11516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11520)
static void C_ccall f_11520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11483)
static void C_ccall f_11483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11489)
static void C_ccall f_11489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11450)
static void C_ccall f_11450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11456)
static void C_ccall f_11456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11426)
static void C_ccall f_11426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11357)
static void C_ccall f_11357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11361)
static void C_ccall f_11361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11366)
static void C_fcall f_11366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11370)
static void C_ccall f_11370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11421)
static void C_ccall f_11421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11400)
static void C_ccall f_11400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11412)
static void C_ccall f_11412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11415)
static void C_ccall f_11415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11388)
static void C_ccall f_11388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11324)
static void C_ccall f_11324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11334)
static void C_ccall f_11334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11337)
static void C_ccall f_11337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11237)
static void C_ccall f_11237(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11246)
static void C_fcall f_11246(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11259)
static void C_ccall f_11259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11265)
static void C_ccall f_11265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11318)
static void C_ccall f_11318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11268)
static void C_ccall f_11268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11283)
static void C_ccall f_11283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11291)
static void C_fcall f_11291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11301)
static void C_ccall f_11301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11286)
static void C_ccall f_11286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11274)
static void C_ccall f_11274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11241)
static void C_ccall f_11241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11231)
static void C_ccall f_11231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11185)
static void C_ccall f_11185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11204)
static void C_ccall f_11204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11215)
static void C_ccall f_11215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11211)
static void C_ccall f_11211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11179)
static void C_ccall f_11179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11101)
static void C_ccall f_11101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11126)
static void C_ccall f_11126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11130)
static void C_ccall f_11130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11132)
static void C_fcall f_11132(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11152)
static void C_ccall f_11152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11156)
static void C_ccall f_11156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11085)
static void C_fcall f_11085(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11089)
static void C_ccall f_11089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11095)
static void C_ccall f_11095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11076)
static void C_ccall f_11076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11032)
static void C_ccall f_11032(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11032)
static void C_ccall f_11032r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11044)
static void C_ccall f_11044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11048)
static void C_ccall f_11048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11052)
static void C_ccall f_11052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11040)
static void C_ccall f_11040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11023)
static void C_ccall f_11023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11017)
static void C_ccall f_11017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11011)
static void C_ccall f_11011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10999)
static void C_ccall f_10999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10961)
static void C_ccall f_10961(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10961)
static void C_ccall f_10961r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10965)
static void C_ccall f_10965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10968)
static void C_ccall f_10968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10975)
static void C_ccall f_10975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10919)
static void C_ccall f_10919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10928)
static void C_fcall f_10928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10890)
static void C_ccall f_10890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10900)
static void C_fcall f_10900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10872)
static void C_ccall f_10872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10821)
static void C_ccall f_10821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10866)
static void C_ccall f_10866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10870)
static void C_ccall f_10870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10824)
static void C_ccall f_10824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10829)
static void C_ccall f_10829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10833)
static void C_ccall f_10833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10827)
static void C_ccall f_10827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10784)
static void C_fcall f_10784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10788)
static void C_ccall f_10788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10797)
static void C_ccall f_10797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10801)
static void C_ccall f_10801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10791)
static void C_ccall f_10791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10749)
static void C_fcall f_10749(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10755)
static void C_fcall f_10755(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10782)
static void C_ccall f_10782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10768)
static void C_ccall f_10768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10702)
static void C_fcall f_10702(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10708)
static void C_fcall f_10708(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10747)
static void C_ccall f_10747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10729)
static void C_ccall f_10729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10688)
static void C_ccall f_10688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10675)
static void C_fcall f_10675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10524)
static void C_fcall f_10524(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10543)
static void C_fcall f_10543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10607)
static void C_ccall f_10607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10618)
static void C_ccall f_10618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10598)
static void C_ccall f_10598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10584)
static void C_fcall f_10584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10572)
static void C_ccall f_10572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10443)
static void C_ccall f_10443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10449)
static void C_ccall f_10449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10504)
static void C_fcall f_10504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10477)
static void C_fcall f_10477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10471)
static void C_fcall f_10471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10151)
static void C_ccall f_10151(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10347)
static void C_fcall f_10347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_fcall f_10368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9841)
static void C_ccall f_9841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9853)
static void C_ccall f_9853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9863)
static void C_fcall f_9863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9915)
static void C_fcall f_9915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9844)
static void C_fcall f_9844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9835)
static void C_ccall f_9835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9528)
static void C_ccall f_9528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9538)
static void C_fcall f_9538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9547)
static void C_fcall f_9547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9559)
static void C_fcall f_9559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9571)
static void C_fcall f_9571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9577)
static void C_ccall f_9577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9611)
static void C_fcall f_9611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9516)
static void C_ccall f_9516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9451)
static void C_ccall f_9451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9464)
static void C_ccall f_9464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9455)
static void C_fcall f_9455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9433)
static void C_ccall f_9433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_fcall f_9424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9414)
static void C_ccall f_9414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8385)
static void C_fcall f_8385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8414)
static void C_fcall f_8414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_fcall f_8433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8452)
static void C_fcall f_8452(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_fcall f_8522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8541)
static void C_fcall f_8541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8623)
static void C_fcall f_8623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8662)
static void C_fcall f_8662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8681)
static void C_fcall f_8681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8700)
static void C_fcall f_8700(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_fcall f_8780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8865)
static void C_fcall f_8865(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8940)
static void C_ccall f_8940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_fcall f_8974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8977)
static void C_ccall f_8977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_fcall f_8814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_fcall f_8575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8455)
static void C_ccall f_8455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8486)
static void C_fcall f_8486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8358)
static void C_ccall f_8358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8344)
static void C_ccall f_8344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8298)
static void C_ccall f_8298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8310)
static void C_ccall f_8310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_ccall f_8329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8332)
static void C_ccall f_8332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8304)
static void C_ccall f_8304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8197)
static void C_ccall f_8197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8166)
static void C_ccall f_8166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8172)
static void C_ccall f_8172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8179)
static void C_fcall f_8179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8074)
static void C_ccall f_8074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8098)
static void C_ccall f_8098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7988)
static void C_ccall f_7988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7994)
static void C_ccall f_7994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8010)
static void C_fcall f_8010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7972)
static void C_ccall f_7972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7978)
static void C_ccall f_7978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7868)
static void C_fcall f_7868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_fcall f_7903(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_fcall f_7825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_fcall f_7796(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7820)
static void C_ccall f_7820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7724)
static void C_ccall f_7724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7730)
static void C_ccall f_7730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7736)
static void C_fcall f_7736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7740)
static void C_ccall f_7740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7751)
static void C_ccall f_7751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7722)
static void C_ccall f_7722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7618)
static void C_fcall f_7618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_fcall f_7654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7672)
static void C_ccall f_7672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7559)
static void C_ccall f_7559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7535)
static void C_ccall f_7535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7442)
static C_word C_fcall f_7442(C_word t0,C_word t1);
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7393)
static void C_fcall f_7393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7209)
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7221)
static void C_fcall f_7221(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7370)
static void C_ccall f_7370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7322)
static void C_ccall f_7322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7326)
static void C_ccall f_7326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7329)
static void C_ccall f_7329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7335)
static void C_ccall f_7335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7289)
static void C_ccall f_7289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7273)
static void C_ccall f_7273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7244)
static void C_ccall f_7244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7138)
static void C_ccall f_7138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7201)
static void C_ccall f_7201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7177)
static void C_fcall f_7177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_fcall f_7160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7164)
static void C_ccall f_7164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7074)
static void C_fcall f_7074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6775)
static void C_fcall f_6775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7009)
static void C_fcall f_7009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_fcall f_6947(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_ccall f_6890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6236)
static void C_ccall f_6236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6615)
static void C_fcall f_6615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6672)
static void C_fcall f_6672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_fcall f_6468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_fcall f_6324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_fcall f_6321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_fcall f_5702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5835)
static void C_fcall f_5835(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_fcall f_5861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_fcall f_5934(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5755)
static void C_fcall f_5755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_fcall f_5776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_fcall f_5797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5661)
static void C_fcall f_5661(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_fcall f_5629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4918)
static void C_fcall f_4918(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_fcall f_4946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_fcall f_4810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4685)
static void C_fcall f_4685(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_fcall f_4632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_fcall f_4640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_fcall f_4585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_fcall f_4411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4433)
static void C_fcall f_4433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_fcall f_4440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4355)
static void C_fcall f_4355(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4273)
static C_word C_fcall f_4273(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4223)
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4202)
static void C_fcall f_4202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4162)
static void C_fcall f_4162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4093)
static void C_ccall f_4093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4067)
static void C_fcall f_4067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11366)
static void C_fcall trf_11366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11366(t0,t1);}

C_noret_decl(trf_11246)
static void C_fcall trf_11246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11246(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11246(t0,t1,t2,t3);}

C_noret_decl(trf_11291)
static void C_fcall trf_11291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11291(t0,t1,t2);}

C_noret_decl(trf_11132)
static void C_fcall trf_11132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11132(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11132(t0,t1,t2,t3);}

C_noret_decl(trf_11085)
static void C_fcall trf_11085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11085(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11085(t0,t1);}

C_noret_decl(trf_10928)
static void C_fcall trf_10928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10928(t0,t1,t2);}

C_noret_decl(trf_10900)
static void C_fcall trf_10900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10900(t0,t1);}

C_noret_decl(trf_10784)
static void C_fcall trf_10784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10784(t0,t1,t2,t3);}

C_noret_decl(trf_10749)
static void C_fcall trf_10749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10749(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10749(t0,t1,t2);}

C_noret_decl(trf_10755)
static void C_fcall trf_10755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10755(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10755(t0,t1,t2);}

C_noret_decl(trf_10702)
static void C_fcall trf_10702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10702(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10702(t0,t1,t2,t3);}

C_noret_decl(trf_10708)
static void C_fcall trf_10708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10708(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10708(t0,t1,t2);}

C_noret_decl(trf_10675)
static void C_fcall trf_10675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10675(t0,t1,t2,t3);}

C_noret_decl(trf_10524)
static void C_fcall trf_10524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10524(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10524(t0,t1,t2,t3);}

C_noret_decl(trf_10543)
static void C_fcall trf_10543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10543(t0,t1);}

C_noret_decl(trf_10584)
static void C_fcall trf_10584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10584(t0,t1);}

C_noret_decl(trf_10504)
static void C_fcall trf_10504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10504(t0,t1);}

C_noret_decl(trf_10477)
static void C_fcall trf_10477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10477(t0,t1);}

C_noret_decl(trf_10471)
static void C_fcall trf_10471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10471(t0,t1);}

C_noret_decl(trf_10347)
static void C_fcall trf_10347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10347(t0,t1);}

C_noret_decl(trf_10368)
static void C_fcall trf_10368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10368(t0,t1);}

C_noret_decl(trf_9863)
static void C_fcall trf_9863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9863(t0,t1);}

C_noret_decl(trf_9915)
static void C_fcall trf_9915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9915(t0,t1);}

C_noret_decl(trf_9844)
static void C_fcall trf_9844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9844(t0,t1);}

C_noret_decl(trf_9538)
static void C_fcall trf_9538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9538(t0,t1);}

C_noret_decl(trf_9547)
static void C_fcall trf_9547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9547(t0,t1);}

C_noret_decl(trf_9559)
static void C_fcall trf_9559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9559(t0,t1);}

C_noret_decl(trf_9571)
static void C_fcall trf_9571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9571(t0,t1);}

C_noret_decl(trf_9611)
static void C_fcall trf_9611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9611(t0,t1);}

C_noret_decl(trf_9455)
static void C_fcall trf_9455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9455(t0,t1);}

C_noret_decl(trf_9424)
static void C_fcall trf_9424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9424(t0,t1);}

C_noret_decl(trf_8385)
static void C_fcall trf_8385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8385(t0,t1,t2);}

C_noret_decl(trf_8414)
static void C_fcall trf_8414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8414(t0,t1);}

C_noret_decl(trf_8433)
static void C_fcall trf_8433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8433(t0,t1);}

C_noret_decl(trf_8452)
static void C_fcall trf_8452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8452(t0,t1);}

C_noret_decl(trf_8522)
static void C_fcall trf_8522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8522(t0,t1);}

C_noret_decl(trf_8541)
static void C_fcall trf_8541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8541(t0,t1);}

C_noret_decl(trf_8623)
static void C_fcall trf_8623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8623(t0,t1);}

C_noret_decl(trf_8662)
static void C_fcall trf_8662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8662(t0,t1);}

C_noret_decl(trf_8681)
static void C_fcall trf_8681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8681(t0,t1);}

C_noret_decl(trf_8700)
static void C_fcall trf_8700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8700(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8700(t0,t1);}

C_noret_decl(trf_8780)
static void C_fcall trf_8780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8780(t0,t1);}

C_noret_decl(trf_8865)
static void C_fcall trf_8865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8865(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8865(t0,t1);}

C_noret_decl(trf_8974)
static void C_fcall trf_8974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8974(t0,t1);}

C_noret_decl(trf_8814)
static void C_fcall trf_8814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8814(t0,t1);}

C_noret_decl(trf_8575)
static void C_fcall trf_8575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8575(t0,t1);}

C_noret_decl(trf_8486)
static void C_fcall trf_8486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8486(t0,t1);}

C_noret_decl(trf_8179)
static void C_fcall trf_8179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8179(t0,t1);}

C_noret_decl(trf_8010)
static void C_fcall trf_8010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8010(t0,t1);}

C_noret_decl(trf_7868)
static void C_fcall trf_7868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7868(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7868(t0,t1,t2,t3);}

C_noret_decl(trf_7903)
static void C_fcall trf_7903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7903(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7903(t0,t1,t2,t3);}

C_noret_decl(trf_7825)
static void C_fcall trf_7825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7825(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7825(t0,t1,t2,t3);}

C_noret_decl(trf_7796)
static void C_fcall trf_7796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7796(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7796(t0,t1,t2,t3);}

C_noret_decl(trf_7736)
static void C_fcall trf_7736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7736(t0,t1);}

C_noret_decl(trf_7618)
static void C_fcall trf_7618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7618(t0,t1);}

C_noret_decl(trf_7654)
static void C_fcall trf_7654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7654(t0,t1);}

C_noret_decl(trf_7393)
static void C_fcall trf_7393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7393(t0,t1,t2);}

C_noret_decl(trf_7221)
static void C_fcall trf_7221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7221(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7221(t0,t1,t2,t3);}

C_noret_decl(trf_7215)
static void C_fcall trf_7215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7215(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7215(t0,t1,t2);}

C_noret_decl(trf_7177)
static void C_fcall trf_7177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7177(t0,t1);}

C_noret_decl(trf_7160)
static void C_fcall trf_7160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7160(t0,t1);}

C_noret_decl(trf_7074)
static void C_fcall trf_7074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7074(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7074(t0,t1,t2);}

C_noret_decl(trf_6775)
static void C_fcall trf_6775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6775(t0,t1);}

C_noret_decl(trf_7009)
static void C_fcall trf_7009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7009(t0,t1);}

C_noret_decl(trf_6947)
static void C_fcall trf_6947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6947(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6947(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6615)
static void C_fcall trf_6615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6615(t0,t1);}

C_noret_decl(trf_6672)
static void C_fcall trf_6672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6672(t0,t1);}

C_noret_decl(trf_6468)
static void C_fcall trf_6468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6468(t0,t1);}

C_noret_decl(trf_6324)
static void C_fcall trf_6324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6324(t0,t1);}

C_noret_decl(trf_6321)
static void C_fcall trf_6321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6321(t0,t1);}

C_noret_decl(trf_5702)
static void C_fcall trf_5702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5702(t0,t1);}

C_noret_decl(trf_5835)
static void C_fcall trf_5835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5835(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5835(t0,t1,t2);}

C_noret_decl(trf_5861)
static void C_fcall trf_5861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5861(t0,t1);}

C_noret_decl(trf_5934)
static void C_fcall trf_5934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5934(t0,t1);}

C_noret_decl(trf_5755)
static void C_fcall trf_5755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5755(t0,t1);}

C_noret_decl(trf_5776)
static void C_fcall trf_5776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5776(t0,t1);}

C_noret_decl(trf_5797)
static void C_fcall trf_5797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5797(t0,t1);}

C_noret_decl(trf_5661)
static void C_fcall trf_5661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5661(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5661(t0,t1,t2);}

C_noret_decl(trf_5629)
static void C_fcall trf_5629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5629(t0,t1);}

C_noret_decl(trf_4918)
static void C_fcall trf_4918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4918(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4918(t0,t1,t2);}

C_noret_decl(trf_4946)
static void C_fcall trf_4946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4946(t0,t1);}

C_noret_decl(trf_4810)
static void C_fcall trf_4810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4810(t0,t1);}

C_noret_decl(trf_4685)
static void C_fcall trf_4685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4685(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4685(t0,t1,t2,t3);}

C_noret_decl(trf_4632)
static void C_fcall trf_4632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4632(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4632(t0,t1,t2);}

C_noret_decl(trf_4640)
static void C_fcall trf_4640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4640(t0,t1);}

C_noret_decl(trf_4585)
static void C_fcall trf_4585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4585(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4585(t0,t1);}

C_noret_decl(trf_4411)
static void C_fcall trf_4411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4411(t0,t1,t2);}

C_noret_decl(trf_4433)
static void C_fcall trf_4433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4433(t0,t1);}

C_noret_decl(trf_4440)
static void C_fcall trf_4440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4440(t0,t1);}

C_noret_decl(trf_4355)
static void C_fcall trf_4355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4355(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4355(t0,t1,t2,t3);}

C_noret_decl(trf_4223)
static void C_fcall trf_4223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4223(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4223(t0,t1,t2,t3);}

C_noret_decl(trf_4202)
static void C_fcall trf_4202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4202(t0,t1);}

C_noret_decl(trf_4162)
static void C_fcall trf_4162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4162(t0,t1,t2);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4115(t0,t1);}

C_noret_decl(trf_4067)
static void C_fcall trf_4067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4067(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5190)){
C_save(t1);
C_rereclaim2(5190*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,511);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],12,"flush-output");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],6,"printf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[15]=C_h_intern(&lf[15],5,"force");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[20]=C_h_intern(&lf[20],25,"\010compilercompiler-warning");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\012\012Warning: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],20,"\003syswarnings-enabled");
lf[25]=C_h_intern(&lf[25],4,"quit");
lf[26]=C_h_intern(&lf[26],4,"exit");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[28]=C_h_intern(&lf[28],21,"\003syssyntax-error-hook");
lf[29]=C_h_intern(&lf[29],16,"print-call-chain");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\031Syntax error (~a): ~a~%~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[35]=C_h_intern(&lf[35],12,"syntax-error");
lf[36]=C_h_intern(&lf[36],31,"\010compileremit-syntax-trace-info");
lf[37]=C_h_intern(&lf[37],9,"map-llist");
lf[38]=C_h_intern(&lf[38],24,"\010compilercheck-signature");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[40]=C_h_intern(&lf[40],18,"\010compilerreal-name");
lf[41]=C_h_intern(&lf[41],13,"\010compilerposq");
lf[42]=C_h_intern(&lf[42],18,"\010compilerstringify");
lf[43]=C_h_intern(&lf[43],14,"symbol->string");
lf[44]=C_h_intern(&lf[44],7,"sprintf");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[46]=C_h_intern(&lf[46],18,"\010compilersymbolify");
lf[47]=C_h_intern(&lf[47],14,"string->symbol");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[49]=C_h_intern(&lf[49],26,"\010compilerbuild-lambda-list");
lf[50]=C_h_intern(&lf[50],29,"\010compilerstring->c-identifier");
lf[51]=C_h_intern(&lf[51],24,"\003sysstring->c-identifier");
lf[52]=C_h_intern(&lf[52],21,"\010compilerc-ify-string");
lf[53]=C_h_intern(&lf[53],16,"\003syslist->string");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[55]=C_h_intern(&lf[55],6,"append");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[57]=C_h_intern(&lf[57],16,"\003sysstring->list");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[61]=C_h_intern(&lf[61],28,"\010compilervalid-c-identifier\077");
lf[62]=C_h_intern(&lf[62],3,"any");
lf[63]=C_h_intern(&lf[63],8,"->string");
lf[64]=C_h_intern(&lf[64],14,"\010compilerwords");
lf[65]=C_h_intern(&lf[65],21,"\010compilerwords->bytes");
lf[66]=C_h_intern(&lf[66],34,"\010compilercheck-and-open-input-file");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[68]=C_h_intern(&lf[68],18,"current-input-port");
lf[69]=C_h_intern(&lf[69],15,"open-input-file");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[72]=C_h_intern(&lf[72],12,"file-exists\077");
lf[73]=C_h_intern(&lf[73],33,"\010compilerclose-checked-input-file");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[75]=C_h_intern(&lf[75],16,"close-input-port");
lf[76]=C_h_intern(&lf[76],19,"\010compilerfold-inner");
lf[77]=C_h_intern(&lf[77],7,"reverse");
lf[78]=C_h_intern(&lf[78],28,"\010compilerfollow-without-loop");
lf[79]=C_h_intern(&lf[79],21,"\010compilersort-symbols");
lf[80]=C_h_intern(&lf[80],8,"string<\077");
lf[81]=C_h_intern(&lf[81],4,"sort");
lf[82]=C_h_intern(&lf[82],18,"\010compilerconstant\077");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_h_intern(&lf[84],29,"\010compilercollapsable-literal\077");
lf[85]=C_h_intern(&lf[85],19,"\010compilerimmediate\077");
lf[86]=C_h_intern(&lf[86],20,"\010compilerbig-fixnum\077");
lf[87]=C_h_intern(&lf[87],23,"\010compilerbasic-literal\077");
lf[88]=C_h_intern(&lf[88],5,"every");
lf[89]=C_h_intern(&lf[89],12,"vector->list");
lf[90]=C_h_intern(&lf[90],32,"\010compilercanonicalize-begin-body");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[93]=C_h_intern(&lf[93],3,"let");
lf[94]=C_h_intern(&lf[94],6,"gensym");
lf[95]=C_h_intern(&lf[95],1,"t");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[97]=C_h_intern(&lf[97],21,"\010compilerstring->expr");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[100]=C_h_intern(&lf[100],5,"begin");
lf[101]=C_h_intern(&lf[101],10,"\003sysappend");
lf[102]=C_h_intern(&lf[102],4,"read");
lf[103]=C_h_intern(&lf[103],6,"unfold");
lf[104]=C_h_intern(&lf[104],11,"eof-object\077");
lf[105]=C_h_intern(&lf[105],6,"values");
lf[106]=C_h_intern(&lf[106],22,"with-input-from-string");
lf[107]=C_h_intern(&lf[107],22,"with-exception-handler");
lf[108]=C_h_intern(&lf[108],30,"call-with-current-continuation");
lf[109]=C_h_intern(&lf[109],30,"\010compilerdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],25,"\003sysdecompose-lambda-list");
lf[111]=C_h_intern(&lf[111],37,"\010compilerprocess-lambda-documentation");
lf[112]=C_h_intern(&lf[112],21,"\010compilerllist-length");
lf[113]=C_h_intern(&lf[113],30,"\010compilerexpand-profile-lambda");
lf[114]=C_h_intern(&lf[114],29,"\010compilerprofile-lambda-index");
lf[115]=C_h_intern(&lf[115],28,"\010compilerprofile-lambda-list");
lf[116]=C_h_intern(&lf[116],33,"\010compilerprofile-info-vector-name");
lf[117]=C_h_intern(&lf[117],17,"\003sysprofile-entry");
lf[118]=C_h_intern(&lf[118],6,"lambda");
lf[119]=C_h_intern(&lf[119],5,"apply");
lf[120]=C_h_intern(&lf[120],16,"\003sysprofile-exit");
lf[121]=C_h_intern(&lf[121],16,"\003sysdynamic-wind");
lf[122]=C_h_intern(&lf[122],10,"alist-cons");
lf[123]=C_h_intern(&lf[123],37,"\010compilerinitialize-analysis-database");
lf[124]=C_h_intern(&lf[124],8,"internal");
lf[125]=C_h_intern(&lf[125],8,"\003sysput!");
lf[126]=C_h_intern(&lf[126],18,"\010compilerintrinsic");
lf[127]=C_h_intern(&lf[127],9,"\003syserror");
lf[128]=C_h_intern(&lf[128],26,"\010compilerinternal-bindings");
lf[129]=C_h_intern(&lf[129],8,"extended");
lf[130]=C_h_intern(&lf[130],17,"extended-bindings");
lf[131]=C_h_intern(&lf[131],26,"\010compilerfoldable-bindings");
lf[132]=C_h_intern(&lf[132],17,"\010compilerfoldable");
lf[133]=C_h_intern(&lf[133],8,"standard");
lf[134]=C_h_intern(&lf[134],17,"standard-bindings");
lf[135]=C_h_intern(&lf[135],12,"\010compilerget");
lf[136]=C_h_intern(&lf[136],18,"\003syshash-table-ref");
lf[137]=C_h_intern(&lf[137],16,"\010compilerget-all");
lf[138]=C_h_intern(&lf[138],10,"filter-map");
lf[139]=C_h_intern(&lf[139],13,"\010compilerput!");
lf[140]=C_h_intern(&lf[140],19,"\003syshash-table-set!");
lf[141]=C_h_intern(&lf[141],17,"\010compilercollect!");
lf[142]=C_h_intern(&lf[142],15,"\010compilercount!");
lf[143]=C_h_intern(&lf[143],17,"\010compilerget-line");
lf[144]=C_h_intern(&lf[144],24,"\003sysline-number-database");
lf[145]=C_h_intern(&lf[145],19,"\010compilerget-line-2");
lf[146]=C_h_intern(&lf[146],30,"\010compilerfind-lambda-container");
lf[147]=C_h_intern(&lf[147],12,"contained-in");
lf[148]=C_h_intern(&lf[148],37,"\010compilerdisplay-line-number-database");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[150]=C_h_intern(&lf[150],7,"\003sysmap");
lf[151]=C_h_intern(&lf[151],3,"cdr");
lf[152]=C_h_intern(&lf[152],23,"\003syshash-table-for-each");
lf[153]=C_h_intern(&lf[153],34,"\010compilerdisplay-analysis-database");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010\011lval=~s");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[159]=C_h_intern(&lf[159],7,"unknown");
lf[160]=C_h_intern(&lf[160],8,"captured");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\011undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003"
"uud\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[163]=C_h_intern(&lf[163],4,"caar");
lf[164]=C_h_intern(&lf[164],5,"value");
lf[165]=C_h_intern(&lf[165],4,"cdar");
lf[166]=C_h_intern(&lf[166],11,"local-value");
lf[167]=C_h_intern(&lf[167],15,"potential-value");
lf[168]=C_h_intern(&lf[168],10,"replacable");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[170]=C_h_intern(&lf[170],10,"references");
lf[171]=C_h_intern(&lf[171],10,"call-sites");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[173]=C_h_intern(&lf[173],4,"home");
lf[174]=C_h_intern(&lf[174],8,"contains");
lf[175]=C_h_intern(&lf[175],8,"use-expr");
lf[176]=C_h_intern(&lf[176],12,"closure-size");
lf[177]=C_h_intern(&lf[177],14,"rest-parameter");
lf[178]=C_h_intern(&lf[178],16,"o-r/access-count");
lf[179]=C_h_intern(&lf[179],18,"captured-variables");
lf[180]=C_h_intern(&lf[180],13,"explicit-rest");
lf[181]=C_h_intern(&lf[181],8,"assigned");
lf[182]=C_h_intern(&lf[182],5,"boxed");
lf[183]=C_h_intern(&lf[183],6,"global");
lf[184]=C_h_intern(&lf[184],12,"contractable");
lf[185]=C_h_intern(&lf[185],16,"standard-binding");
lf[186]=C_h_intern(&lf[186],16,"assigned-locally");
lf[187]=C_h_intern(&lf[187],11,"collapsable");
lf[188]=C_h_intern(&lf[188],9,"removable");
lf[189]=C_h_intern(&lf[189],9,"undefined");
lf[190]=C_h_intern(&lf[190],9,"replacing");
lf[191]=C_h_intern(&lf[191],6,"unused");
lf[192]=C_h_intern(&lf[192],6,"simple");
lf[193]=C_h_intern(&lf[193],9,"inlinable");
lf[194]=C_h_intern(&lf[194],13,"inline-export");
lf[195]=C_h_intern(&lf[195],21,"has-unused-parameters");
lf[196]=C_h_intern(&lf[196],16,"extended-binding");
lf[197]=C_h_intern(&lf[197],12,"customizable");
lf[198]=C_h_intern(&lf[198],8,"constant");
lf[199]=C_h_intern(&lf[199],10,"boxed-rest");
lf[200]=C_h_intern(&lf[200],11,"hidden-refs");
lf[201]=C_h_intern(&lf[201],5,"write");
lf[202]=C_h_intern(&lf[202],34,"\010compilerdefault-standard-bindings");
lf[203]=C_h_intern(&lf[203],34,"\010compilerdefault-extended-bindings");
lf[204]=C_h_intern(&lf[204],9,"make-node");
lf[205]=C_h_intern(&lf[205],4,"node");
lf[206]=C_h_intern(&lf[206],5,"node\077");
lf[207]=C_h_intern(&lf[207],15,"node-class-set!");
lf[208]=C_h_intern(&lf[208],14,"\003sysblock-set!");
lf[209]=C_h_intern(&lf[209],10,"node-class");
lf[210]=C_h_intern(&lf[210],20,"node-parameters-set!");
lf[211]=C_h_intern(&lf[211],15,"node-parameters");
lf[212]=C_h_intern(&lf[212],24,"node-subexpressions-set!");
lf[213]=C_h_intern(&lf[213],19,"node-subexpressions");
lf[214]=C_h_intern(&lf[214],16,"\010compilervarnode");
lf[215]=C_h_intern(&lf[215],13,"\004corevariable");
lf[216]=C_h_intern(&lf[216],14,"\010compilerqnode");
lf[217]=C_h_intern(&lf[217],25,"\010compilerbuild-node-graph");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[219]=C_h_intern(&lf[219],15,"\004coreglobal-ref");
lf[220]=C_h_intern(&lf[220],2,"if");
lf[221]=C_h_intern(&lf[221],14,"\004coreundefined");
lf[222]=C_h_intern(&lf[222],8,"truncate");
lf[223]=C_h_intern(&lf[223],4,"type");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[225]=C_h_intern(&lf[225],6,"fixnum");
lf[226]=C_h_intern(&lf[226],11,"number-type");
lf[227]=C_h_intern(&lf[227],6,"unzip1");
lf[228]=C_h_intern(&lf[228],11,"\004corelambda");
lf[229]=C_h_intern(&lf[229],14,"\004coreprimitive");
lf[230]=C_h_intern(&lf[230],11,"\004coreinline");
lf[231]=C_h_intern(&lf[231],13,"\004corecallunit");
lf[232]=C_h_intern(&lf[232],9,"\004coreproc");
lf[233]=C_h_intern(&lf[233],4,"set!");
lf[234]=C_h_intern(&lf[234],9,"\004coreset!");
lf[235]=C_h_intern(&lf[235],29,"\004coreforeign-callback-wrapper");
lf[236]=C_h_intern(&lf[236],5,"sixth");
lf[237]=C_h_intern(&lf[237],5,"fifth");
lf[238]=C_h_intern(&lf[238],20,"\004coreinline_allocate");
lf[239]=C_h_intern(&lf[239],8,"\004coreapp");
lf[240]=C_h_intern(&lf[240],9,"\004corecall");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[242]=C_h_intern(&lf[242],24,"\010compilersource-filename");
lf[243]=C_h_intern(&lf[243],28,"\003syssymbol->qualified-string");
lf[244]=C_h_intern(&lf[244],7,"\003sysget");
lf[245]=C_h_intern(&lf[245],34,"\010compileralways-bound-to-procedure");
lf[246]=C_h_intern(&lf[246],15,"\004coreinline_ref");
lf[247]=C_h_intern(&lf[247],18,"\004coreinline_update");
lf[248]=C_h_intern(&lf[248],19,"\004coreinline_loc_ref");
lf[249]=C_h_intern(&lf[249],22,"\004coreinline_loc_update");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[251]=C_h_intern(&lf[251],1,"o");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[253]=C_h_intern(&lf[253],30,"\010compilerbuild-expression-tree");
lf[254]=C_h_intern(&lf[254],12,"\004coreclosure");
lf[255]=C_h_intern(&lf[255],4,"last");
lf[256]=C_h_intern(&lf[256],3,"map");
lf[257]=C_h_intern(&lf[257],4,"list");
lf[258]=C_h_intern(&lf[258],7,"butlast");
lf[259]=C_h_intern(&lf[259],5,"cons*");
lf[260]=C_h_intern(&lf[260],9,"\004corebind");
lf[261]=C_h_intern(&lf[261],10,"\004coreunbox");
lf[262]=C_h_intern(&lf[262],8,"\004coreref");
lf[263]=C_h_intern(&lf[263],11,"\004coreupdate");
lf[264]=C_h_intern(&lf[264],13,"\004coreupdate_i");
lf[265]=C_h_intern(&lf[265],8,"\004corebox");
lf[266]=C_h_intern(&lf[266],9,"\004corecond");
lf[267]=C_h_intern(&lf[267],21,"\010compilerfold-boolean");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[269]=C_h_intern(&lf[269],31,"\010compilerinline-lambda-bindings");
lf[270]=C_h_intern(&lf[270],8,"split-at");
lf[271]=C_h_intern(&lf[271],10,"fold-right");
lf[272]=C_h_intern(&lf[272],4,"take");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[274]=C_h_intern(&lf[274],34,"\010compilercopy-node-tree-and-rename");
lf[275]=C_h_intern(&lf[275],9,"alist-ref");
lf[276]=C_h_intern(&lf[276],3,"eq\077");
lf[277]=C_h_intern(&lf[277],1,"f");
lf[278]=C_h_intern(&lf[278],18,"\010compilertree-copy");
lf[279]=C_h_intern(&lf[279],4,"cons");
lf[280]=C_h_intern(&lf[280],19,"\010compilercopy-node!");
lf[281]=C_h_intern(&lf[281],20,"\010compilernode->sexpr");
lf[282]=C_h_intern(&lf[282],20,"\010compilersexpr->node");
lf[283]=C_h_intern(&lf[283],32,"\010compileremit-global-inline-file");
lf[284]=C_h_intern(&lf[284],5,"print");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[286]=C_h_intern(&lf[286],1,"i");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[289]=C_h_intern(&lf[289],2,"pp");
lf[290]=C_h_intern(&lf[290],3,"yes");
lf[291]=C_h_intern(&lf[291],2,"no");
lf[292]=C_h_intern(&lf[292],24,"\010compilerinline-max-size");
lf[293]=C_h_intern(&lf[293],15,"\010compilerinline");
lf[294]=C_h_intern(&lf[294],22,"\010compilerinline-global");
lf[295]=C_h_intern(&lf[295],26,"\010compilervariable-visible\077");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[299]=C_h_intern(&lf[299],15,"chicken-version");
lf[300]=C_h_intern(&lf[300],19,"with-output-to-file");
lf[301]=C_h_intern(&lf[301],25,"\010compilerload-inline-file");
lf[302]=C_h_intern(&lf[302],20,"with-input-from-file");
lf[303]=C_h_intern(&lf[303],19,"\010compilermatch-node");
lf[304]=C_h_intern(&lf[304],1,"a");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[306]=C_h_intern(&lf[306],37,"\010compilerexpression-has-side-effects\077");
lf[307]=C_h_intern(&lf[307],24,"foreign-callback-stub-id");
lf[308]=C_h_intern(&lf[308],4,"find");
lf[309]=C_h_intern(&lf[309],22,"foreign-callback-stubs");
lf[310]=C_h_intern(&lf[310],28,"\010compilersimple-lambda-node\077");
lf[311]=C_h_intern(&lf[311],31,"\010compilerdump-undefined-globals");
lf[312]=C_h_intern(&lf[312],28,"\003systoplevel-definition-hook");
lf[313]=C_h_intern(&lf[313],22,"\010compilerhide-variable");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[315]=C_h_intern(&lf[315],36,"\010compilercompute-database-statistics");
lf[316]=C_h_intern(&lf[316],29,"\010compilercurrent-program-size");
lf[317]=C_h_intern(&lf[317],30,"\010compileroriginal-program-size");
lf[318]=C_h_intern(&lf[318],33,"\010compilerprint-program-statistics");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[325]=C_h_intern(&lf[325],1,"s");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[327]=C_h_intern(&lf[327],35,"\010compilerpprint-expressions-to-file");
lf[328]=C_h_intern(&lf[328],17,"close-output-port");
lf[329]=C_h_intern(&lf[329],12,"pretty-print");
lf[330]=C_h_intern(&lf[330],19,"with-output-to-port");
lf[331]=C_h_intern(&lf[331],16,"open-output-file");
lf[332]=C_h_intern(&lf[332],19,"current-output-port");
lf[333]=C_h_intern(&lf[333],27,"\010compilerforeign-type-check");
lf[334]=C_h_intern(&lf[334],4,"char");
lf[335]=C_h_intern(&lf[335],13,"unsigned-char");
lf[336]=C_h_intern(&lf[336],6,"unsafe");
lf[337]=C_h_intern(&lf[337],25,"\003sysforeign-char-argument");
lf[338]=C_h_intern(&lf[338],3,"int");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-fixnum-argument");
lf[340]=C_h_intern(&lf[340],5,"float");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-flonum-argument");
lf[342]=C_h_intern(&lf[342],7,"pointer");
lf[343]=C_h_intern(&lf[343],26,"\003sysforeign-block-argument");
lf[344]=C_h_intern(&lf[344],15,"nonnull-pointer");
lf[345]=C_h_intern(&lf[345],8,"u8vector");
lf[346]=C_h_intern(&lf[346],34,"\003sysforeign-number-vector-argument");
lf[347]=C_h_intern(&lf[347],16,"nonnull-u8vector");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[349]=C_h_intern(&lf[349],7,"integer");
lf[350]=C_h_intern(&lf[350],28,"\003sysforeign-integer-argument");
lf[351]=C_h_intern(&lf[351],16,"unsigned-integer");
lf[352]=C_h_intern(&lf[352],37,"\003sysforeign-unsigned-integer-argument");
lf[353]=C_h_intern(&lf[353],9,"c-pointer");
lf[354]=C_h_intern(&lf[354],28,"\003sysforeign-pointer-argument");
lf[355]=C_h_intern(&lf[355],17,"nonnull-c-pointer");
lf[356]=C_h_intern(&lf[356],8,"c-string");
lf[357]=C_h_intern(&lf[357],17,"\003sysmake-c-string");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-string-argument");
lf[359]=C_h_intern(&lf[359],16,"nonnull-c-string");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],18,"\003syssymbol->string");
lf[362]=C_h_intern(&lf[362],3,"ref");
lf[363]=C_h_intern(&lf[363],8,"instance");
lf[364]=C_h_intern(&lf[364],12,"instance-ref");
lf[365]=C_h_intern(&lf[365],4,"this");
lf[366]=C_h_intern(&lf[366],8,"slot-ref");
lf[367]=C_h_intern(&lf[367],16,"nonnull-instance");
lf[368]=C_h_intern(&lf[368],5,"const");
lf[369]=C_h_intern(&lf[369],4,"enum");
lf[370]=C_h_intern(&lf[370],8,"function");
lf[371]=C_h_intern(&lf[371],27,"\010compilerforeign-type-table");
lf[372]=C_h_intern(&lf[372],17,"nonnull-c-string*");
lf[373]=C_h_intern(&lf[373],26,"nonnull-unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],9,"c-string*");
lf[375]=C_h_intern(&lf[375],18,"unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],13,"c-string-list");
lf[377]=C_h_intern(&lf[377],14,"c-string-list*");
lf[378]=C_h_intern(&lf[378],18,"unsigned-integer32");
lf[379]=C_h_intern(&lf[379],13,"unsigned-long");
lf[380]=C_h_intern(&lf[380],4,"long");
lf[381]=C_h_intern(&lf[381],9,"integer32");
lf[382]=C_h_intern(&lf[382],17,"nonnull-u16vector");
lf[383]=C_h_intern(&lf[383],16,"nonnull-s8vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s16vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-u32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-f32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f64vector");
lf[389]=C_h_intern(&lf[389],9,"u16vector");
lf[390]=C_h_intern(&lf[390],8,"s8vector");
lf[391]=C_h_intern(&lf[391],9,"s16vector");
lf[392]=C_h_intern(&lf[392],9,"u32vector");
lf[393]=C_h_intern(&lf[393],9,"s32vector");
lf[394]=C_h_intern(&lf[394],9,"f32vector");
lf[395]=C_h_intern(&lf[395],9,"f64vector");
lf[396]=C_h_intern(&lf[396],22,"nonnull-scheme-pointer");
lf[397]=C_h_intern(&lf[397],12,"nonnull-blob");
lf[398]=C_h_intern(&lf[398],19,"nonnull-byte-vector");
lf[399]=C_h_intern(&lf[399],11,"byte-vector");
lf[400]=C_h_intern(&lf[400],4,"blob");
lf[401]=C_h_intern(&lf[401],14,"scheme-pointer");
lf[402]=C_h_intern(&lf[402],6,"double");
lf[403]=C_h_intern(&lf[403],6,"number");
lf[404]=C_h_intern(&lf[404],12,"unsigned-int");
lf[405]=C_h_intern(&lf[405],5,"short");
lf[406]=C_h_intern(&lf[406],14,"unsigned-short");
lf[407]=C_h_intern(&lf[407],4,"byte");
lf[408]=C_h_intern(&lf[408],13,"unsigned-byte");
lf[409]=C_h_intern(&lf[409],5,"int32");
lf[410]=C_h_intern(&lf[410],14,"unsigned-int32");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[412]=C_h_intern(&lf[412],36,"\010compilerforeign-type-convert-result");
lf[413]=C_h_intern(&lf[413],38,"\010compilerforeign-type-convert-argument");
lf[414]=C_h_intern(&lf[414],27,"\010compilerfinal-foreign-type");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[416]=C_h_intern(&lf[416],37,"\010compilerestimate-foreign-result-size");
lf[417]=C_h_intern(&lf[417],9,"integer64");
lf[418]=C_h_intern(&lf[418],4,"bool");
lf[419]=C_h_intern(&lf[419],4,"void");
lf[420]=C_h_intern(&lf[420],13,"scheme-object");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[422]=C_h_intern(&lf[422],46,"\010compilerestimate-foreign-result-location-size");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[425]=C_h_intern(&lf[425],30,"\010compilerfinish-foreign-result");
lf[426]=C_h_intern(&lf[426],17,"\003syspeek-c-string");
lf[427]=C_h_intern(&lf[427],25,"\003syspeek-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],26,"\003syspeek-and-free-c-string");
lf[429]=C_h_intern(&lf[429],34,"\003syspeek-and-free-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],17,"\003sysintern-symbol");
lf[431]=C_h_intern(&lf[431],22,"\003syspeek-c-string-list");
lf[432]=C_h_intern(&lf[432],31,"\003syspeek-and-free-c-string-list");
lf[433]=C_h_intern(&lf[433],35,"\010tinyclosmake-instance-from-pointer");
lf[434]=C_h_intern(&lf[434],4,"make");
lf[435]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[436]=C_h_intern(&lf[436],28,"\010compilerscan-used-variables");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-free-variables");
lf[438]=C_h_intern(&lf[438],11,"lset-adjoin");
lf[439]=C_h_intern(&lf[439],25,"\010compilertopological-sort");
lf[440]=C_h_intern(&lf[440],7,"colored");
lf[441]=C_h_intern(&lf[441],23,"\010compilerchop-separator");
lf[442]=C_h_intern(&lf[442],9,"substring");
lf[443]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[444]=C_h_intern(&lf[444],23,"\010compilerchop-extension");
lf[445]=C_h_intern(&lf[445],22,"\010compilerprint-version");
lf[446]=C_h_intern(&lf[446],6,"print*");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[448]=C_h_intern(&lf[448],20,"\010compilerprint-usage");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\025>Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012\012  Syntax related options:\012\012  "
"  -case-insensitive            don\047t preserve case of read symbols\012    -keyword-"
"style STYLE         allow alternative keyword syntax\012                           "
"       (prefix, suffix or none)\012    -no-parentheses-synonyms     disables list d"
"elimiter synonyms\012    -no-symbol-escape            disables support for escaped "
"symbols\012    -r5rs-syntax                 disables the Chicken extensions to\012    "
"                              R5RS syntax\012    -compile-syntax              macro"
"s are made available at run-time\012    -emit-import-library MODULE  write compile-"
"time module information into\012                                  separate file\012\012  "
"Translation options:\012\012    -explicit-use                do not use units \047library"
"\047 and \047eval\047 by\012                                  default\012    -check-syntax     "
"           stop compilation after macro-expansion\012    -analyze-only             "
"   stop compilation after first analysis pass\012\012  Debugging options:\012\012    -no-war"
"nings                 disable warnings\012    -disable-warning CLASS       disable "
"specific class of warnings\012    -debug-level NUMBER          set level of availab"
"le debugging information\012    -no-trace                    disable tracing inform"
"ation\012    -profile                     executable emits profiling information \012 "
"   -profile-name FILENAME       name of the generated profile information file\012 "
"   -accumulate-profile          executable emits profiling information in\012      "
"                            append mode\012    -no-lambda-info              omit ad"
"ditional procedure-information\012\012  Optimization options:\012\012    -optimize-level NUM"
"BER       enable certain sets of optimization options\012    -optimize-leaf-routine"
"s      enable leaf routine optimization\012    -lambda-lift                 enable "
"lambda-lifting\012    -no-usual-integrations       standard procedures may be redef"
"ined\012    -unsafe                      disable safety checks\012    -local          "
"             assume globals are only modified in current\012                       "
"           file\012    -block                       enable block-compilation\012    -d"
"isable-interrupts          disable interrupts in compiled code\012    -fixnum-arith"
"metic           assume all numbers are fixnums\012    -benchmark-mode              "
"equivalent to \047block -optimize-level 4\012                                  -debug-"
"level 0 -fixnum-arithmetic -lambda-lift\012                                  -inlin"
"e -disable-interrupts\047\012    -disable-stack-overflow-checks  disables detection of"
" stack-overflows\012    -inline                      enable inlining\012    -inline-li"
"mit                set inlining threshold\012    -inline-global               enabl"
"e cross-module inlining\012    -emit-inline-file FILENAME   generate file with glob"
"ally inlinable\012                                  procedures (implies -inline -lo"
"cal)\012\012  Configuration options:\012\012    -unit NAME                   compile file as"
" a library unit\012    -uses NAME                   declare library unit as used.\012 "
"   -heap-size NUMBER            specifies heap-size of compiled executable\012    -"
"heap-initial-size NUMBER    specifies heap-size at startup time\012    -heap-growth"
" PERCENTAGE      specifies growth-rate of expanding heap\012    -heap-shrinkage PER"
"CENTAGE   specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-"
"size NUMBER\012                                 specifies nursery size of compiled "
"executable\012    -extend FILENAME             load file before compilation commenc"
"es\012    -prelude EXPRESSION          add expression to front of source file\012    -"
"postlude EXPRESSION         add expression to end of source file\012    -prologue F"
"ILENAME           include file before main source file\012    -epilogue FILENAME   "
"        include file after main source file\012    -dynamic                     com"
"pile as dynamically loadable code\012    -require-extension NAME      require and i"
"mport extension NAME\012    -static-extension NAME       import extension NAME but "
"link statically\012                                  (if available)\012\012  Obscure opti"
"ons:\012\012    -debug MODES                 display debugging output for the given mo"
"des\012    -unsafe-libraries            marks the generated file as being linked wi"
"th\012                                  the unsafe runtime system\012    -raw         "
"                do not generate implicit init- and exit code                    "
"       \012    -emit-external-prototypes-first\012                                 emi"
"t protoypes for callbacks before foreign\012                                  decla"
"rations\012    -ignore-repository           do not refer to repository for extensio"
"ns\012");
lf[450]=C_h_intern(&lf[450],36,"\010compilermake-block-variable-literal");
lf[451]=C_h_intern(&lf[451],22,"block-variable-literal");
lf[452]=C_h_intern(&lf[452],32,"\010compilerblock-variable-literal\077");
lf[453]=C_h_intern(&lf[453],36,"\010compilerblock-variable-literal-name");
lf[454]=C_h_intern(&lf[454],25,"\010compilermake-random-name");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[456]=C_h_intern(&lf[456],6,"random");
lf[457]=C_h_intern(&lf[457],15,"current-seconds");
lf[458]=C_h_intern(&lf[458],23,"\010compilerset-real-name!");
lf[459]=C_h_intern(&lf[459],24,"\010compilerreal-name-table");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[461]=C_h_intern(&lf[461],19,"\010compilerreal-name2");
lf[462]=C_h_intern(&lf[462],32,"\010compilerdisplay-real-name-table");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[464]=C_h_intern(&lf[464],28,"\010compilersource-info->string");
lf[465]=C_h_intern(&lf[465],4,"conc");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[468]=C_h_intern(&lf[468],11,"make-string");
lf[469]=C_h_intern(&lf[469],3,"max");
lf[470]=C_h_intern(&lf[470],12,"string-null\077");
lf[471]=C_h_intern(&lf[471],19,"\010compilerdump-nodes");
lf[472]=C_h_intern(&lf[472],19,"\003syswrite-char/port");
lf[473]=C_h_intern(&lf[473],19,"\003sysstandard-output");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[477]=C_h_intern(&lf[477],18,"\003sysuser-read-hook");
lf[478]=C_h_intern(&lf[478],15,"foreign-declare");
lf[479]=C_h_intern(&lf[479],7,"declare");
lf[480]=C_h_intern(&lf[480],34,"\010compilerscan-sharp-greater-string");
lf[481]=C_h_intern(&lf[481],18,"\003sysread-char/port");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[483]=C_h_intern(&lf[483],17,"get-output-string");
lf[484]=C_h_intern(&lf[484],18,"open-output-string");
lf[485]=C_h_intern(&lf[485],6,"hidden");
lf[486]=C_h_intern(&lf[486],19,"\010compilervisibility");
lf[487]=C_h_intern(&lf[487],24,"\010compilerexport-variable");
lf[488]=C_h_intern(&lf[488],8,"exported");
lf[489]=C_h_intern(&lf[489],26,"\010compilerblock-compilation");
lf[490]=C_h_intern(&lf[490],22,"\010compilermark-variable");
lf[491]=C_h_intern(&lf[491],22,"\010compilervariable-mark");
lf[492]=C_h_intern(&lf[492],19,"\010compilerintrinsic\077");
lf[493]=C_h_intern(&lf[493],9,"foldable\077");
lf[494]=C_h_intern(&lf[494],35,"\010compilercompiler-macro-environment");
lf[495]=C_h_intern(&lf[495],7,"cdb-get");
lf[496]=C_h_intern(&lf[496],8,"cdb-put!");
lf[497]=C_h_intern(&lf[497],16,"\003sysmacro-subset");
lf[498]=C_h_intern(&lf[498],28,"\003sysextend-macro-environment");
lf[499]=C_h_intern(&lf[499],19,"define-rewrite-rule");
lf[500]=C_h_intern(&lf[500],24,"\004coredefine-rewrite-rule");
lf[501]=C_h_intern(&lf[501],5,"cdadr");
lf[502]=C_h_intern(&lf[502],5,"caadr");
lf[503]=C_h_intern(&lf[503],16,"\003syscheck-syntax");
lf[504]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[505]=C_h_intern(&lf[505],18,"\003syser-transformer");
lf[506]=C_h_intern(&lf[506],21,"\003sysmacro-environment");
lf[507]=C_h_intern(&lf[507],27,"condition-property-accessor");
lf[508]=C_h_intern(&lf[508],3,"exn");
lf[509]=C_h_intern(&lf[509],7,"message");
lf[510]=C_h_intern(&lf[510],19,"condition-predicate");
C_register_lf2(lf,511,create_ptable());
t2=C_mutate(&lf[0] /* (set! c669 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3969,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3967 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3970 in k3967 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3973 in k3970 in k3967 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3988,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3993,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4020,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[20]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4060,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4089,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[28]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4108,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[35]+1 /* (set! syntax-error ...) */,C_retrieve(lf[28]));
t11=C_mutate((C_word*)lf[36]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4153,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[37]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4156,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[38]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4199,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[41]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4267,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[42]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4303,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[46]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4324,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[49]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4349,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[50]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[51]));
t19=C_mutate((C_word*)lf[52]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4393,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[61]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4487,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[64]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4543,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[65]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4550,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[66]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4557,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[73]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4604,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[76]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4616,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[78]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4679,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[79]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4710,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[82]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4730,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[84]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4776,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[85]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4806,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[87]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4852,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[90]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4912,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 293  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[510]))(3,*((C_word*)lf[510]+1),t33,lf[508]);}

/* k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 294  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[507]))(4,*((C_word*)lf[507]+1),t2,lf[508],lf[509]);}

/* k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word ab[172],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=C_mutate((C_word*)lf[97]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[109]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[110]));
t4=C_mutate((C_word*)lf[111]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5120,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[112]+1 /* (set! llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5123,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[113]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5126,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[123]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5267,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[135]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5418,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[137]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5436,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[139]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5454,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[141]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5500,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[142]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5552,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[143]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5609,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[145]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5619,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[146]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5655,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[148]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5679,tmp=(C_word)a,a+=2,tmp));
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_mutate((C_word*)lf[153]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5698,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6146,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[206]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6152,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[207]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6158,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[209]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6167,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[210]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6176,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[211]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6185,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[212]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6194,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[213]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6203,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6212,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[214]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6218,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[216]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6227,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[217]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6236,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[253]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6750,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[267]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7068,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[269]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7116,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[274]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7209,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[278]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7387,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[280]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7421,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[281]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7483,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[282]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7519,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[283]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7544,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[301]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7724,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[303]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7793,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[306]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7988,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[310]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8074,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[311]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8166,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[312]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8197,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[315]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8218,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[318]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8298,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[327]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8337,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[333]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8373,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[412]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9420,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[413]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9451,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[414]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9482,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[416]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9522,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[422]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9841,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[425]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10151,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[436]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10443,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[437]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10521,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[439]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10693,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[441]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10890,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[444]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10919,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[445]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10961,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[448]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10999,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[450]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11011,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[452]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11017,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[453]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11023,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[454]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11032,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[458]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11076,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[40]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11082,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[461]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11161,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[462]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11173,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[464]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11185,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[470]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11231,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[471]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11237,tmp=(C_word)a,a+=2,tmp));
t77=C_retrieve(lf[477]);
t78=C_mutate((C_word*)lf[477]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11324,a[2]=t77,tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[480]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11357,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[86]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11426,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[313]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11450,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[487]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11483,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[295]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11516,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[490]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11537,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[491]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11565,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[492]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11571,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[493]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11582,tmp=(C_word)a,a+=2,tmp));
t88=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11595,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1509 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[506]))(2,*((C_word*)lf[506]+1),t88);}

/* k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11598,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11607,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11609,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1513 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[505]))(3,*((C_word*)lf[505]+1),t3,t4);}

/* a11608 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11609,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11613,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1515 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[503]))(5,*((C_word*)lf[503]+1),t5,lf[499],t2,lf[504]);}

/* k11611 in a11608 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1517 caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[502]+1)))(3,*((C_word*)lf[502]+1),t2,((C_word*)t0)[3]);}

/* k11622 in k11611 in a11608 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1517 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[118]);}

/* k11634 in k11622 in k11611 in a11608 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1517 cdadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[501]+1)))(3,*((C_word*)lf[501]+1),t2,((C_word*)t0)[2]);}

/* k11642 in k11634 in k11622 in k11611 in a11608 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11646 in k11642 in k11634 in k11622 in k11611 in a11608 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11648,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[500],t5));}

/* k11605 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1510 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[498]))(5,*((C_word*)lf[498]+1),((C_word*)t0)[2],lf[499],C_SCHEME_END_OF_LIST,t1);}

/* k11596 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11601,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1518 ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[497]))(3,*((C_word*)lf[497]+1),t2,((C_word*)t0)[2]);}

/* k11599 in k11596 in k11593 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate((C_word*)lf[494]+1 /* (set! compiler-macro-environment ...) */,t1);
t3=C_mutate((C_word*)lf[495]+1 /* (set! cdb-get ...) */,C_retrieve(lf[135]));
t4=C_mutate((C_word*)lf[496]+1 /* (set! cdb-put! ...) */,C_retrieve(lf[139]));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* foldable? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11582,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11587,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[132]);}

/* f_11587 in foldable? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11587,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#intrinsic? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11571,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11576,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[126]);}

/* f_11576 in ##compiler#intrinsic? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11576,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#variable-mark in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11565,4,t0,t1,t2,t3);}
/* support.scm: 1500 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11537r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11537r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11537r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11541,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11541(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11541(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11539 in ##compiler#mark-variable in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1497 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11516,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11520,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1490 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t3,t2,lf[486]);}

/* k11518 in ##compiler#variable-visible? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[485]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[488]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[489]))));}}

/* ##compiler#export-variable in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11483,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[488]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11489,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_11489(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11489(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11487 in ##compiler#export-variable in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[486],t1);}

/* ##compiler#hide-variable in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11450,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[485]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11456,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_11456(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11456(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11454 in ##compiler#hide-variable in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[486],t1);}

/* ##compiler#big-fixnum? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11426,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11357,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11361,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1452 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[484]))(2,*((C_word*)lf[484]+1),t3);}

/* k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11361,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11366,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11366(t5,((C_word*)t0)[2]);}

/* loop in k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_11366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11366,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11368 in loop in k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11370,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1455 quit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[5],lf[482]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11388,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1457 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11400,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11421,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11419 in k11368 in loop in k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1469 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11366(t2,((C_word*)t0)[2]);}

/* k11398 in k11368 in loop in k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11400,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1462 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[483]))(3,*((C_word*)lf[483]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11412,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11410 in k11398 in k11368 in loop in k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11413 in k11410 in k11398 in k11368 in loop in k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1466 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11366(t2,((C_word*)t0)[2]);}

/* k11386 in k11368 in loop in k11359 in ##compiler#scan-sharp-greater-string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1458 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11366(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11324,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11334,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1449 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k11332 in ##sys#user-read-hook in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11337,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1447 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[480]))(3,*((C_word*)lf[480]+1),t2,((C_word*)t0)[2]);}

/* k11335 in k11332 in ##sys#user-read-hook in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11337,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[478],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[479],t4));}

/* ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11237(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11237,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11241,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11246,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11246(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_11246(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11246,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11259,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1425 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[468]+1)))(4,*((C_word*)lf[468]+1),t10,t2,C_make_character(32));}

/* k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11259,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11265,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1427 printf */
((C_proc6)C_retrieve_symbol_proc(lf[13]))(6,*((C_word*)lf[13]+1),t3,lf[476],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11268,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11317 in k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11318,3,t0,t1,t2);}
/* loop3604 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11246(t3,t1,((C_word*)t0)[2],t2);}

/* k11266 in k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11268,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11283,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1431 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t4,lf[475],t5);}
else{
t4=t3;
f_11274(2,t4,C_SCHEME_UNDEFINED);}}

/* k11281 in k11266 in k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11286,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11291,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11291(t6,t2,C_fix(5));}

/* doloop3637 in k11281 in k11266 in k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_11291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11291,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11301,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1434 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,lf[474],t4);}}

/* k11299 in doloop3637 in k11281 in k11266 in k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11291(t3,((C_word*)t0)[2],t2);}

/* k11284 in k11281 in k11266 in k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[473]+1));}

/* k11272 in k11266 in k11263 in k11257 in loop in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[473]+1));}

/* k11239 in ##compiler#dump-nodes in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1437 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* string-null? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11231,3,t0,t1,t2);}
/* support.scm: 1415 string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[470]))(3,*((C_word*)lf[470]+1),t1,t2);}

/* ##compiler#source-info->string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11185,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11204,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1408 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1410 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11202 in ##compiler#source-info->string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11211,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11215,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1409 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[469]+1)))(4,*((C_word*)lf[469]+1),t3,C_fix(0),t5);}

/* k11213 in k11202 in ##compiler#source-info->string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1409 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[468]+1)))(4,*((C_word*)lf[468]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k11209 in k11202 in ##compiler#source-info->string in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1409 conc */
((C_proc8)C_retrieve_symbol_proc(lf[465]))(8,*((C_word*)lf[465]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[466],((C_word*)t0)[3],t1,lf[467],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11179,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1398 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t2,C_retrieve(lf[459]));}

/* a11178 in ##compiler#display-real-name-table in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11179,4,t0,t1,t2,t3);}
/* support.scm: 1400 printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t1,lf[463],t2,t3);}

/* ##compiler#real-name2 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11161,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11165,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1394 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[459]),t2);}

/* k11163 in ##compiler#real-name2 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1395 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11082r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11082r(t0,t1,t2,t3);}}

static void C_ccall f_11082r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11085,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11101,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1378 resolve */
f_11085(t5,t2);}

/* k11099 in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11101,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1382 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t4,t1);}
else{
/* support.scm: 1391 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1379 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11124 in k11099 in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11130,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1383 get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[147]);}

/* k11128 in k11124 in k11099 in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11130,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11132(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11128 in k11124 in k11099 in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_11132(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11132,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1385 resolve */
f_11085(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11137 in loop in k11128 in k11124 in k11099 in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11139,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11152,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1388 sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),t3,lf[460],((C_word*)t0)[4],t1);}}

/* k11150 in k11137 in loop in k11128 in k11124 in k11099 in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11156,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1389 get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[147]);}

/* k11154 in k11150 in k11137 in loop in k11128 in k11124 in k11099 in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1388 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11132(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_11085(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11085,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11089,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1373 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t3,C_retrieve(lf[459]),t2);}

/* k11087 in resolve in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11089,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11095,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1375 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,C_retrieve(lf[459]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11093 in k11087 in resolve in ##compiler#real-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11076,4,t0,t1,t2,t3);}
/* support.scm: 1369 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),t1,C_retrieve(lf[459]),t2,t3);}

/* ##compiler#make-random-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11032(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_11032r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11032r(t0,t1,t2);}}

static void C_ccall f_11032r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11040,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11044,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1356 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11044(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k11042 in ##compiler#make-random-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11048,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1357 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[457]))(2,*((C_word*)lf[457]+1),t2);}

/* k11046 in k11042 in ##compiler#make-random-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11052,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1358 random */
((C_proc3)C_retrieve_symbol_proc(lf[456]))(3,*((C_word*)lf[456]+1),t2,C_fix(1000));}

/* k11050 in k11046 in k11042 in ##compiler#make-random-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1355 sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[44]))(6,*((C_word*)lf[44]+1),((C_word*)t0)[4],lf[455],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11038 in ##compiler#make-random-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1354 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11023,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[451]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11017,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[451]));}

/* ##compiler#make-block-variable-literal in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11011,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[451],t2));}

/* ##compiler#print-usage in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11003,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1227 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[445]))(2,*((C_word*)lf[445]+1),t2);}

/* k11001 in ##compiler#print-usage in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1228 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k11004 in k11001 in ##compiler#print-usage in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1229 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[449]);}

/* ##compiler#print-version in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10961(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_10961r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10961r(t0,t1,t2);}}

static void C_ccall f_10961r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10965,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_10965(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_10965(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k10963 in ##compiler#print-version in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1223 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[446]+1)))(3,*((C_word*)lf[446]+1),t2,lf[447]);}
else{
t3=t2;
f_10968(2,t3,C_SCHEME_UNDEFINED);}}

/* k10966 in k10963 in ##compiler#print-version in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1224 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),t2,C_SCHEME_TRUE);}

/* k10973 in k10966 in k10963 in ##compiler#print-version in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1224 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[284]+1)))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10919,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10928,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10928(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10928,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1216 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[442]+1)))(5,*((C_word*)lf[442]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1217 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10890,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10900,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_10900(t7,(C_word)C_i_memq(t6,lf[443]));}
else{
t6=t5;
f_10900(t6,C_SCHEME_FALSE);}}

/* k10898 in ##compiler#chop-separator in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1209 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[442]+1)))(5,*((C_word*)lf[442]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10693,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10702,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10749,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10784,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10821,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10872,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a10871 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10872,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1191 insert */
t5=((C_word*)t0)[2];
f_10702(t5,t1,t3,t4);}

/* k10819 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10866,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1194 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t3,((C_word*)t0)[2]);}

/* k10864 in k10819 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10870,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1194 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2]);}

/* k10868 in k10864 in k10819 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1194 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10784(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10822 in k10819 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10827,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a10828 in k10822 in k10819 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10829,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10833,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1196 lookup */
t5=((C_word*)t0)[2];
f_10749(t5,t3,t4);}

/* k10831 in a10828 in k10822 in k10819 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[440]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1198 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10784(t5,((C_word*)t0)[4],t3,t4);}}

/* k10825 in k10822 in k10819 in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10784,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10788,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1179 insert */
t5=((C_word*)t0)[2];
f_10702(t5,t4,t2,lf[440]);}

/* k10786 in visit in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10791,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10796 in k10786 in visit in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10797,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10801,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1182 lookup */
t4=((C_word*)t0)[2];
f_10749(t4,t3,t2);}

/* k10799 in a10796 in k10786 in visit in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[440]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1184 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10784(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k10789 in k10786 in visit in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10791,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10749,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10755,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10755(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10755,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10768,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10782,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1174 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t4,t2);}}

/* k10780 in loop in lookup in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1174 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10766 in loop in lookup in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1174 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1175 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10755(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10702(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10702,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10708,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10708(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10708(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10708,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10747,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1168 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t4,t2);}}

/* k10745 in loop in insert in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1168 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10727 in loop in insert in ##compiler#topological-sort in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1169 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10708(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10521,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10524,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10675,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10688,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1151 walk */
t14=((C_word*)t8)[1];
f_10524(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10686 in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1152 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10675,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10681,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10680 in walkeach in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10681,3,t0,t1,t2);}
/* support.scm: 1149 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10524(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10524(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10524,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[83]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t7,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t10)){
t12=t11;
f_10543(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[221]);
if(C_truep(t12)){
t13=t11;
f_10543(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[229]);
if(C_truep(t13)){
t14=t11;
f_10543(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[232]);
t15=t11;
f_10543(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[246])));}}}}

/* k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[215]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10562,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1131 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[438]))(5,*((C_word*)lf[438]+1),t4,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[233]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10584,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10584(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10598,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1136 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[438]))(5,*((C_word*)lf[438]+1),t6,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[93]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10607,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1139 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10524(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[228]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10637,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1142 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1146 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10675(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10636 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10637,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10649,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1145 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t6,t2,((C_word*)t0)[2]);}

/* k10647 in a10636 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1145 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10524(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10605 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10607,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10618,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1140 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10616 in k10605 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1140 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10524(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10596 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10584(t3,t2);}

/* k10582 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1137 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10524(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10560 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10562,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1132 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t3,((C_word*)t0)[2]);}

/* k10566 in k10560 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10568,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10572,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1133 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[438]))(5,*((C_word*)lf[438]+1),t2,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10570 in k10566 in k10560 in k10541 in walk in ##compiler#scan-free-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10443,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10447,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10449,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10449(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10449,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[215]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[233]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10471,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10477,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_10477(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_10477(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[83]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10504,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_10504(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[221]);
t12=t10;
f_10504(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[229])));}}}

/* k10502 in walk in ##compiler#scan-used-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10475 in walk in ##compiler#scan-used-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10477,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10471(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10471(t2,C_SCHEME_UNDEFINED);}}

/* k10469 in walk in ##compiler#scan-used-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10445 in ##compiler#scan-used-variables in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10151(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10151,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[426],t9));}
else{
t6=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[427],t10));}
else{
t7=(C_word)C_eqp(t4,lf[374]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[83],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[428],t12));}
else{
t9=(C_word)C_eqp(t4,lf[372]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[83],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[429],t14));}
else{
t11=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[83],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[426],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[430],t17));}
else{
t12=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[83],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[431],t16));}
else{
t13=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[83],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[432],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10347,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_10347(t18,(C_word)C_i_memq(t17,lf[435]));}
else{
t17=t14;
f_10347(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_10347(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k10345 in ##compiler#finish-foreign-result in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10347,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[433],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_10368(t6,(C_word)C_eqp(lf[367],t5));}
else{
t5=t2;
f_10368(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10368(t3,C_SCHEME_FALSE);}}}

/* k10366 in k10345 in ##compiler#finish-foreign-result in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_10368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10368,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[434],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9841,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9844,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9853,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10145,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1055 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t4,t5);}

/* a10144 in ##compiler#estimate-foreign-result-location-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_10145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10145,2,t0,t1);}
/* support.scm: 1076 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[424],((C_word*)t0)[2]);}

/* a9852 in ##compiler#estimate-foreign-result-location-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9853,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9863,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_9863(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9863(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_9863(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_9863(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t10)){
t11=t6;
f_9863(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t11)){
t12=t6;
f_9863(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t12)){
t13=t6;
f_9863(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t13)){
t14=t6;
f_9863(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t14)){
t15=t6;
f_9863(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_9863(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_9863(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t17)){
t18=t6;
f_9863(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t18)){
t19=t6;
f_9863(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t19)){
t20=t6;
f_9863(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t20)){
t21=t6;
f_9863(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t21)){
t22=t6;
f_9863(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t22)){
t23=t6;
f_9863(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t23)){
t24=t6;
f_9863(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_9863(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[401]);
if(C_truep(t25)){
t26=t6;
f_9863(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[396]);
if(C_truep(t26)){
t27=t6;
f_9863(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t27)){
t28=t6;
f_9863(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t28)){
t29=t6;
f_9863(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t29)){
t30=t6;
f_9863(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t30)){
t31=t6;
f_9863(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t31)){
t32=t6;
f_9863(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t32)){
t33=t6;
f_9863(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t33)){
t34=t6;
f_9863(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t34)){
t35=t6;
f_9863(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t35)){
t36=t6;
f_9863(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[376]);
t37=t6;
f_9863(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[377])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k9861 in a9852 in ##compiler#estimate-foreign-result-location-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9863,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[403]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub338(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1068 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t5=t4;
f_9881(2,t5,C_SCHEME_FALSE);}}}}

/* k9879 in k9861 in a9852 in ##compiler#estimate-foreign-result-location-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9881,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1070 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_9915(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9915(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_9915(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_9915(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
t9=t4;
f_9915(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[370])));}}}}}
else{
/* support.scm: 1075 err */
f_9844(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k9913 in k9879 in k9861 in a9852 in ##compiler#estimate-foreign-result-location-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1074 err */
f_9844(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9844(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9844,NULL,2,t1,t2);}
/* support.scm: 1054 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[423],t2);}

/* ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9522,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9528,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9835,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1025 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t3,t4);}

/* a9834 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9835,2,t0,t1);}
/* support.scm: 1050 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[421],((C_word*)t0)[2]);}

/* a9527 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9528,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9538,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9538(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9538(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_9538(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_9538(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t10)){
t11=t6;
f_9538(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t11)){
t12=t6;
f_9538(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t12)){
t13=t6;
f_9538(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t13)){
t14=t6;
f_9538(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t14)){
t15=t6;
f_9538(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_9538(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_9538(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[409]);
t18=t6;
f_9538(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[410])));}}}}}}}}}}}}

/* k9536 in a9527 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9538,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9547(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=t3;
f_9547(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t5)){
t6=t3;
f_9547(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_9547(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t7)){
t8=t3;
f_9547(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t8)){
t9=t3;
f_9547(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t9)){
t10=t3;
f_9547(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t10)){
t11=t3;
f_9547(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t11)){
t12=t3;
f_9547(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
t13=t3;
f_9547(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[377])));}}}}}}}}}}}

/* k9545 in k9536 in a9527 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9559(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_9559(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t5)){
t6=t3;
f_9559(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t6)){
t7=t3;
f_9559(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t8=t3;
f_9559(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}

/* k9557 in k9545 in k9536 in a9527 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9559,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[340]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9571(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[402]);
if(C_truep(t4)){
t5=t3;
f_9571(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
t6=t3;
f_9571(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[417])));}}}}

/* k9569 in k9557 in k9545 in k9536 in a9527 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9571,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1041 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9577(2,t3,C_SCHEME_FALSE);}}}

/* k9575 in k9569 in k9557 in k9545 in k9536 in a9527 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9577,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1043 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9611,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9611(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9611(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_9611(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_9611(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t8)){
t9=t4;
f_9611(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[370]);
if(C_truep(t9)){
t10=t4;
f_9611(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[363]);
if(C_truep(t10)){
t11=t4;
f_9611(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[364]);
t12=t4;
f_9611(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[367])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9609 in k9575 in k9569 in k9557 in k9545 in k9536 in a9527 in ##compiler#estimate-foreign-result-size in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9482,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9488,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9516,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1012 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t3,t4);}

/* a9515 in ##compiler#final-foreign-type in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9516,2,t0,t1);}
/* support.scm: 1019 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[415],((C_word*)t0)[2]);}

/* a9487 in ##compiler#final-foreign-type in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9488,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9492,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1015 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[371]),t2);}
else{
t5=t4;
f_9492(2,t5,C_SCHEME_FALSE);}}

/* k9490 in a9487 in ##compiler#final-foreign-type in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1017 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9451,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9455,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9464,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1006 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_9455(t5,C_SCHEME_FALSE);}}

/* k9462 in ##compiler#foreign-type-convert-argument in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9464,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9455(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9455(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9455(t2,C_SCHEME_FALSE);}}

/* k9453 in ##compiler#foreign-type-convert-argument in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9420,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9424,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9433,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 999  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_9424(t5,C_SCHEME_FALSE);}}

/* k9431 in ##compiler#foreign-type-convert-result in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9433,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_9424(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9424(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9424(t2,C_SCHEME_FALSE);}}

/* k9422 in ##compiler#foreign-type-convert-result in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_9424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8373,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9414,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 900  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t3,t4,t5);}

/* a9413 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9414,2,t0,t1);}
/* support.scm: 992  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[411],((C_word*)t0)[2]);}

/* a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8379,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8385,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8385(t7,t1,t2);}

/* repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8385,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[334]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[335]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[336]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[337],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8414(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[404]);
if(C_truep(t8)){
t9=t7;
f_8414(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t9)){
t10=t7;
f_8414(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t10)){
t11=t7;
f_8414(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t11)){
t12=t7;
f_8414(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t12)){
t13=t7;
f_8414(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[409]);
t14=t7;
f_8414(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[410])));}}}}}}}}

/* k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8414,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[339],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8433(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t5=t3;
f_8433(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[403])));}}}

/* k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8433,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[341],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8452(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
if(C_truep(t4)){
t5=t3;
f_8452(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t6=t3;
f_8452(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[401])));}}}}

/* k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8452,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8455,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 910  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8522(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
if(C_truep(t4)){
t5=t3;
f_8522(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
t6=t3;
f_8522(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[398])));}}}}

/* k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8522,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[343],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8541(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t4)){
t5=t3;
f_8541(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t5)){
t6=t3;
f_8541(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t6)){
t7=t3;
f_8541(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t7)){
t8=t3;
f_8541(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t8)){
t9=t3;
f_8541(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
t10=t3;
f_8541(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[395])));}}}}}}}}

/* k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8541,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 922  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8623(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_8623(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t5)){
t6=t3;
f_8623(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t6)){
t7=t3;
f_8623(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t7)){
t8=t3;
f_8623(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t8)){
t9=t3;
f_8623(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
t10=t3;
f_8623(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[388])));}}}}}}}}

/* k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8623,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[348]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[346],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8662(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
t5=t3;
f_8662(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[381])));}}}

/* k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8662,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[350],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8681(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_8681(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8681,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[352],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8700(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_8700(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8700(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8700,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8703,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 942  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[354],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8780(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t6=t4;
f_8780(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}}

/* k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8780,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8783,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 950  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8865(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t5=t3;
f_8865(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}

/* k8863 in k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8865(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8865,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[357],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[358],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[357],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[336]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[357],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[358],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[357],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 966  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t3,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8940(2,t4,C_SCHEME_FALSE);}}}}

/* k8938 in k8863 in k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8940,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 968  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8974(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
t6=t4;
f_8974(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[370]);
t7=t4;
f_8974(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[353])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k8972 in k8938 in k8863 in k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8974,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8977,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 972  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[363]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[364]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9044,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 978  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[366],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 985  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8385(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[336]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[350],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[344]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[355]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[354],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9042 in k8972 in k8938 in k8863 in k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9044,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[366],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[83],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[220],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[93],t17));}

/* k8975 in k8972 in k8938 in k8863 in k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8977,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k8781 in k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8814,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8814(t7,(C_word)C_a_i_cons(&a,2,lf[357],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[358],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_8814(t9,(C_word)C_a_i_cons(&a,2,lf[357],t8));}}

/* k8812 in k8781 in k8778 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8814,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k8701 in k8698 in k8679 in k8660 in k8621 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8703,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k8542 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8544,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8575,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8575(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8575(t10,(C_word)C_a_i_cons(&a,2,lf[346],t9));}}

/* k8573 in k8542 in k8539 in k8520 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8575,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k8453 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8455,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8486,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8486(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8486(t7,(C_word)C_a_i_cons(&a,2,lf[343],t6));}}

/* k8484 in k8453 in k8450 in k8431 in k8412 in repeat in a8378 in ##compiler#foreign-type-check in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8486,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* ##compiler#pprint-expressions-to-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8337,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8341,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 881  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[331]+1)))(3,*((C_word*)lf[331]+1),t4,t3);}
else{
/* support.scm: 881  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[332]+1)))(2,*((C_word*)lf[332]+1),t4);}}

/* k8339 in ##compiler#pprint-expressions-to-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8344,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 882  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),t2,t1,t3);}

/* a8351 in k8339 in ##compiler#pprint-expressions-to-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8358,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a8357 in a8351 in k8339 in ##compiler#pprint-expressions-to-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8358,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8362,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 886  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t3,t2);}

/* k8360 in a8357 in a8351 in k8339 in ##compiler#pprint-expressions-to-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 887  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k8342 in k8339 in ##compiler#pprint-expressions-to-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 889  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[328]+1)))(3,*((C_word*)lf[328]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8298,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8304,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8310,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a8309 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8310,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8317,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 869  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t9,lf[325],lf[326]);}

/* k8315 in a8309 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8317,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8320,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 870  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t2,lf[324],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8318 in k8315 in a8309 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 871  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[323],((C_word*)t0)[2]);}

/* k8321 in k8318 in k8315 in a8309 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 872  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[322],((C_word*)t0)[2]);}

/* k8324 in k8321 in k8318 in k8315 in a8309 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 873  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[321],((C_word*)t0)[2]);}

/* k8327 in k8324 in k8321 in k8318 in k8315 in a8309 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8332,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 874  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[320],((C_word*)t0)[2]);}

/* k8330 in k8327 in k8324 in k8321 in k8318 in k8315 in a8309 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 875  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[319],((C_word*)t0)[2]);}

/* a8303 in ##compiler#print-program-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8304,2,t0,t1);}
/* support.scm: 868  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8218,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8222,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8227,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 844  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t13,t14,t2);}

/* a8226 in ##compiler#compute-database-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8227,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a8232 in a8226 in ##compiler#compute-database-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8233,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[183]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[164]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[228],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t5,lf[171]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* k8220 in ##compiler#compute-database-statistics in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 858  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[316]),C_retrieve(lf[317]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8197,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8207,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 821  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t7,lf[251],lf[314],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k8205 in ##sys#toplevel-definition-hook in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 822  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8166,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8172,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 807  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t3,t2);}

/* a8171 in ##compiler#dump-undefined-globals in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8172,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8179,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[183],t3))){
t5=(C_word)C_i_assq(lf[181],t3);
t6=t4;
f_8179(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8179(t5,C_SCHEME_FALSE);}}

/* k8177 in a8171 in ##compiler#dump-undefined-globals in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8179,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8182,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 811  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8180 in k8177 in a8171 in ##compiler#dump-undefined-globals in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 812  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8074,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8098,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_8098(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8098,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[240]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[215],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 799  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[231]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 801  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7988,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7994,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7994(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7994,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[215]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8010,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_8010(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[83]);
if(C_truep(t9)){
t10=t8;
f_8010(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[221]);
if(C_truep(t10)){
t11=t8;
f_8010(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[232]);
t12=t8;
f_8010(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[219])));}}}}

/* k8008 in walk in ##compiler#expression-has-side-effects? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_8010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8024,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 782  find */
((C_proc4)C_retrieve_symbol_proc(lf[308]))(4,*((C_word*)lf[308]+1),((C_word*)t0)[6],t6,C_retrieve(lf[309]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[220]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[93]));
if(C_truep(t4)){
/* support.scm: 783  any */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a8023 in k8008 in walk in ##compiler#expression-has-side-effects? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8024,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 782  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t3,t2);}

/* k8030 in a8023 in k8008 in walk in ##compiler#expression-has-side-effects? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7793,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7796,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7825,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7868,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7972,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 766  matchn */
t15=((C_word*)t12)[1];
f_7868(t15,t14,t2,t3);}

/* k7970 in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7972,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7978,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 769  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[10]))(7,*((C_word*)lf[10]+1),t2,lf[304],lf[305],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7976 in k7970 in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7868(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7868,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 755  resolve */
t4=((C_word*)t0)[4];
f_7796(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7890,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 757  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_7825(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k7888 in matchn in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7903(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k7888 in matchn in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7903(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7903,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 761  resolve */
t4=((C_word*)t0)[4];
f_7796(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7934,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 763  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7868(t7,t4,t5,t6);}}}}

/* k7932 in loop in k7888 in matchn in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 764  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7903(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7825,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 748  resolve */
t4=((C_word*)t0)[3];
f_7796(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7847,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 750  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7845 in match1 in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 750  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7825(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7796(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7796,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7820,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 743  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7818 in resolve in ##compiler#match-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7724,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7730,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 723  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[302]))(4,*((C_word*)lf[302]+1),t1,t2,t3);}

/* a7729 in ##compiler#load-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7730,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7736,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7736(t5,t1);}

/* loop in a7729 in ##compiler#load-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7736,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7740,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 726  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t2);}

/* k7738 in loop in a7729 in ##compiler#load-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7740,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7787,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 731  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t4,t5);}}

/* k7785 in k7738 in loop in a7729 in ##compiler#load-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_7751(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_7751(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k7749 in k7785 in k7738 in loop in a7729 in ##compiler#load-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[294],t1);}

/* k7774 in k7738 in loop in a7729 in ##compiler#load-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 732  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7736(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7544,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7548,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7575,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 692  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[300]))(4,*((C_word*)lf[300]+1),t6,t2,t7);}

/* a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 694  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[299]))(2,*((C_word*)lf[299]+1),t3);}

/* k7720 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 694  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[284]+1)))(7,*((C_word*)lf[284]+1),((C_word*)t0)[2],lf[296],t1,lf[297],C_retrieve(lf[242]),lf[298]);}

/* k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 696  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t2,t3,((C_word*)t0)[2]);}

/* a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7587,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 698  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t4,t2);}

/* k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7594,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[166],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t4,t3,lf[294]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7715,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(t1,lf[205]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[164],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7618(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[159],t5);
t7=t4;
f_7618(t7,(C_word)C_i_not(t6));}}}

/* k7616 in k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7618,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[193],((C_word*)t0)[7]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_i_car(t3);
/* support.scm: 706  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t4,((C_word*)t0)[2],t5,lf[192]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7637 in k7616 in k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7639,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 707  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[200]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7694 in k7637 in k7616 in k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t3,t2,lf[293]);}}

/* k7649 in k7694 in k7637 in k7616 in k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[290]);
if(C_truep(t3)){
t4=t2;
f_7654(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[291]);
if(C_truep(t4)){
t5=t2;
f_7654(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[292]);
t7=t2;
f_7654(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7652 in k7649 in k7694 in k7637 in k7616 in k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7654,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7661,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7672,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 714  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7670 in k7652 in k7649 in k7694 in k7637 in k7616 in k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7672,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 714  pp */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),((C_word*)t0)[2],t2);}

/* k7659 in k7652 in k7649 in k7694 in k7637 in k7616 in k7713 in k7592 in a7586 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 715  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k7580 in k7577 in a7574 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 717  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[284]+1)))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],lf[288]);}

/* k7546 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 719  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t2,lf[286],lf[287]);}
else{
t3=t2;
f_7554(2,t3,C_SCHEME_FALSE);}}

/* k7552 in k7546 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7559,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7567,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 720  sort-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7565 in k7552 in k7546 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7558 in k7552 in k7546 in ##compiler#emit-global-inline-file in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7559,3,t0,t1,t2);}
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[284]+1)))(4,*((C_word*)lf[284]+1),t1,lf[285],t2);}

/* ##compiler#sexpr->node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7519,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7525,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7525(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7525,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7535,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k7533 in walk in ##compiler#sexpr->node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7535,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* ##compiler#node->sexpr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7483,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7489,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7489(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7489,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7509,a[2]=t4,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7513,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(3));
/* map */
t11=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,((C_word*)((C_word*)t0)[2])[1],t10);}

/* k7511 in walk in ##compiler#node->sexpr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7507 in walk in ##compiler#node->sexpr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7509,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7421,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7425,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 671  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t4,t3,t6);}

/* k7423 in ##compiler#copy-node! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 672  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),t2,((C_word*)t0)[3],t4);}

/* k7426 in k7423 in ##compiler#copy-node! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 673  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[212]))(4,*((C_word*)lf[212]+1),t2,((C_word*)t0)[3],t4);}

/* k7429 in k7426 in k7423 in ##compiler#copy-node! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7431,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7442(t4,C_fix(4)));}

/* doloop1688 in k7429 in k7426 in k7423 in ##compiler#copy-node! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static C_word C_fcall f_7442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7387,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7393,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7393(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7393,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 667  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7405 in rec in ##compiler#tree-copy in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7411,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 667  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7393(t4,t2,t3);}

/* k7409 in k7405 in rec in ##compiler#tree-copy in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7411,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7209,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7213,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 635  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[256]+1)))(5,*((C_word*)lf[256]+1),t5,*((C_word*)lf[279]+1),t3,t4);}

/* k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7215,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7221,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 662  walk */
t6=((C_word*)t4)[1];
f_7221(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7221(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7221,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[215]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
/* support.scm: 642  rename */
f_7215(t11,t12,t3);}
else{
t11=(C_word)C_eqp(t9,lf[233]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7273,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 643  rename */
f_7215(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[93]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7289,a[2]=t3,a[3]=t13,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 646  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t14,t13);}
else{
t13=(C_word)C_eqp(t9,lf[228]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7322,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 650  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7370,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 661  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t14,t7);}}}}}

/* k7368 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7373,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7377 in k7368 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7378,3,t0,t1,t2);}
/* walk1556 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7221(t3,t1,t2,((C_word*)t0)[2]);}

/* k7371 in k7368 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7373,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7322,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[94]),t2);}

/* k7324 in a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 654  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t2,t1,((C_word*)t0)[2]);}

/* k7327 in k7324 in a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 657  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,lf[277]);}

/* k7346 in k7327 in k7324 in a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7348,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7356,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7364,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 658  rename */
f_7215(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_7364(2,t5,C_SCHEME_FALSE);}}

/* k7362 in k7346 in k7327 in k7324 in a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 658  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[49]))(5,*((C_word*)lf[49]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7354 in k7346 in k7327 in k7324 in a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7356,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7335,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7339 in k7354 in k7346 in k7327 in k7324 in a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7340,3,t0,t1,t2);}
/* walk1556 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7221(t3,t1,t2,((C_word*)t0)[2]);}

/* k7333 in k7354 in k7346 in k7327 in k7324 in a7321 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7335,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[228],((C_word*)t0)[2],t1));}

/* k7287 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7292,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 647  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7290 in k7287 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7298,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7303,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7302 in k7290 in k7287 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7303,3,t0,t1,t2);}
/* walk1556 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7221(t3,t1,t2,((C_word*)t0)[2]);}

/* k7296 in k7290 in k7287 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7298,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[93],((C_word*)t0)[2],t1));}

/* k7271 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7273,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7260,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7264 in k7271 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7265,3,t0,t1,t2);}
/* walk1556 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7221(t3,t1,t2,((C_word*)t0)[2]);}

/* k7258 in k7271 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7260,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[233],((C_word*)t0)[2],t1));}

/* k7242 in walk in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7244,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[215],t3,C_SCHEME_END_OF_LIST));}

/* rename in k7211 in ##compiler#copy-node-tree-and-rename in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7215(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7215,NULL,3,t1,t2,t3);}
/* support.scm: 636  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[275]))(6,*((C_word*)lf[275]+1),t1,t2,t3,*((C_word*)lf[276]+1),t2);}

/* ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7116,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7122,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 613  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t1,t2,t6);}

/* a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7122,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7128,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7134,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7134,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[94]),((C_word*)t0)[2]);}
else{
t5=t4;
f_7138(2,t5,((C_word*)t0)[2]);}}

/* k7136 in a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 619  copy-node-tree-and-rename */
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_7141(2,t3,((C_word*)t0)[3]);}}

/* k7139 in k7136 in a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7146,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7201,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 625  last */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7160(t4,t1);}}

/* k7199 in k7139 in k7136 in a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7201,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7177,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_END_OF_LIST);
t5=t3;
f_7177(t5,(C_word)C_a_i_record(&a,4,lf[205],lf[83],t4,C_SCHEME_END_OF_LIST));}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[273],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_7177(t8,(C_word)C_a_i_record(&a,4,lf[205],lf[238],t6,t7));}}

/* k7175 in k7199 in k7139 in k7136 in a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7177,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_7160(t3,(C_word)C_a_i_record(&a,4,lf[205],lf[93],((C_word*)t0)[2],t2));}

/* k7158 in k7139 in k7136 in a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7160,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7164,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 631  take */
((C_proc4)C_retrieve_symbol_proc(lf[272]))(4,*((C_word*)lf[272]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7162 in k7158 in k7139 in k7136 in a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 621  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[271]))(6,*((C_word*)lf[271]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7145 in k7139 in k7136 in a7133 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7146,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[205],lf[93],t5,t6));}

/* a7127 in a7121 in ##compiler#inline-lambda-bindings in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7128,2,t0,t1);}
/* support.scm: 616  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[270]))(4,*((C_word*)lf[270]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7068,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7074,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7074(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7074,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 609  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k7092 in fold in ##compiler#fold-boolean in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 610  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7074(t4,t2,t3);}

/* k7096 in k7092 in fold in ##compiler#fold-boolean in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7098,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[205],lf[230],lf[268],t2));}

/* ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6750,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6756,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6756(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6756,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[220]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6775,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_6775(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[265]);
t12=t10;
f_6775(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[266])));}}

/* k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_6775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6775,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[254]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6799,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[215]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[219]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[83]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[83],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[93]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6869,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 583  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[258]))(3,*((C_word*)lf[258]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[118]:lf[228]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6890,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 590  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6756(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[240]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[231]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6923,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[221]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6947,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6947(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7009,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_7009(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t14)){
t15=t13;
f_7009(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t16=t13;
f_7009(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[264])));}}}}}}}}}}}}}

/* k7007 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_7009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7009,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 600  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6756(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7039,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k7037 in k7007 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 601  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7033 in k7007 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7035,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7014 in k7007 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7020,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k7018 in k7014 in k7007 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 600  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[259]))(6,*((C_word*)lf[259]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_6947(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6947,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6965,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 597  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6996,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 598  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6756(3,t10,t8,t9);}}

/* k6994 in loop in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6996,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 598  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6947(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6963 in loop in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6973,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 597  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6756(3,t4,t2,t3);}

/* k6971 in k6963 in loop in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6973,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[260],t3));}

/* k6921 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[259]))(5,*((C_word*)lf[259]+1),((C_word*)t0)[3],lf[231],((C_word*)t0)[2],t1);}

/* k6888 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6890,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6867 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6863 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 583  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[256]+1)))(5,*((C_word*)lf[256]+1),((C_word*)t0)[3],*((C_word*)lf[257]+1),((C_word*)t0)[2],t1);}

/* k6847 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6861,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 584  last */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t3,((C_word*)t0)[2]);}

/* k6859 in k6847 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 584  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6756(3,t2,((C_word*)t0)[2],t1);}

/* k6855 in k6847 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* k6801 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6797 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6799,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[254],t2));}

/* k6780 in k6773 in walk in ##compiler#build-expression-tree in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6236,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6239,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6745,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 567  walk */
t9=((C_word*)t6)[1];
f_6239(3,t9,t8,t2);}

/* k6743 in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6748,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 568  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,lf[251],lf[252],((C_word*)((C_word*)t0)[2])[1]);}

/* k6746 in k6743 in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word *a;
loop:
a=C_alloc(11);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_6239,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[205],lf[215],t5,C_SCHEME_END_OF_LIST));}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 502  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t1,lf[218],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[219]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[205],lf[219],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[220]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[221]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6298,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[83]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6321,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6324,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[225],C_retrieve(lf[226]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_6324(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_6324(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_6324(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[93]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 522  walk */
t68=t1;
t69=t11;
t1=t68;
t2=t69;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6374,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 523  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[227]))(3,*((C_word*)lf[227]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[118]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[228]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6428,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 527  walk */
t68=t14;
t69=t15;
t1=t68;
t2=t69;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[229]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6468(t17,(C_word)C_eqp(lf[83],t16));}
else{
t16=t15;
f_6468(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[230]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[231]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6499,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[232]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_record(&a,4,lf[205],lf[232],t17,C_SCHEME_END_OF_LIST));}
else{
t16=(C_word)C_eqp(t4,lf[233]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[234]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6541,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6594,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 546  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[238]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6615,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6615(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[246]);
if(C_truep(t21)){
t22=t20;
f_6615(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[247]);
if(C_truep(t22)){
t23=t20;
f_6615(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[248]);
t24=t20;
f_6615(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[249])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6735,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6733 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6735,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[240],lf[250],t1));}

/* k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_6615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6615,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6624,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[239]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6640,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6652,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6657 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6658,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6672,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t6,t5,lf[245]);}

/* k6693 in a6657 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6672(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6672(t2,C_SCHEME_FALSE);}}

/* k6670 in a6657 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_6672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6672,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6676,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 562  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 564  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[2]);}}

/* k6677 in k6670 in a6657 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6686(2,t3,t1);}
else{
/* support.scm: 563  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[2]);}}

/* k6684 in k6677 in k6670 in a6657 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6686,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6676(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[242]),((C_word*)t0)[2],t1));}

/* k6674 in k6670 in a6657 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6665,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6663 in k6674 in k6670 in a6657 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[240],((C_word*)t0)[2],t1));}

/* a6651 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6652,2,t0,t1);}
/* support.scm: 554  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t1,((C_word*)t0)[2]);}

/* k6638 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6640,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[240],lf[241],t1));}

/* k6622 in k6613 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6592 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6594,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6574,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6578,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 547  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[236]))(3,*((C_word*)lf[236]+1),t5,((C_word*)t0)[2]);}

/* k6576 in k6592 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 547  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6239(3,t2,((C_word*)t0)[2],t1);}

/* k6572 in k6592 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6574,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[205],lf[235],((C_word*)t0)[2],t2));}

/* k6539 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6541,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[233],((C_word*)t0)[2],t1));}

/* k6497 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6499,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6466 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_6468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6468,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6454,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6452 in k6466 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6426 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[205],lf[118],((C_word*)t0)[2],t2));}

/* k6372 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6377,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6394,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6393 in k6372 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6394,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 524  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6239(3,t4,t1,t3);}

/* k6382 in k6372 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 525  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6239(3,t3,t2,((C_word*)t0)[2]);}

/* k6390 in k6382 in k6372 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 524  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6375 in k6372 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[93],((C_word*)t0)[2],t1));}

/* k6322 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_6324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6324,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 513  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,lf[223],lf[224],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6321(t2,((C_word*)t0)[2]);}}

/* k6325 in k6322 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6334,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 516  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[2]);}

/* k6332 in k6325 in k6322 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6321(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k6319 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_6321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6321,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[83],t3,C_SCHEME_END_OF_LIST));}

/* k6296 in walk in ##compiler#build-node-graph in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6298,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6227,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[83],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6218,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[215],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6212,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* node-subexpressions in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6203,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6194,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6185,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6176,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6167,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6158,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6152,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[205]));}

/* f_6146 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6146,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5698,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5702,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5702(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6144,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 432  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[55]+1)))(5,*((C_word*)lf[55]+1),t4,C_retrieve(lf[202]),C_retrieve(lf[203]),C_retrieve(lf[128]));}}

/* k6142 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5702(t3,t2);}

/* k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5702,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5707,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 435  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5707,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5717,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 443  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),t14,t2);}}

/* k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5835,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5835(t6,t2,((C_word*)t0)[2]);}

/* loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5835(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5835,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 447  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[160]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5861(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t5)){
t6=t4;
f_5861(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t6)){
t7=t4;
f_5861(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t7)){
t8=t4;
f_5861(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t8)){
t9=t4;
f_5861(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t9)){
t10=t4;
f_5861(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t10)){
t11=t4;
f_5861(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t11)){
t12=t4;
f_5861(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t12)){
t13=t4;
f_5861(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t13)){
t14=t4;
f_5861(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t14)){
t15=t4;
f_5861(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t15)){
t16=t4;
f_5861(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t16)){
t17=t4;
f_5861(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t17)){
t18=t4;
f_5861(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t18)){
t19=t4;
f_5861(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t19)){
t20=t4;
f_5861(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t20)){
t21=t4;
f_5861(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t21)){
t22=t4;
f_5861(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t22)){
t23=t4;
f_5861(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[199]);
t24=t4;
f_5861(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[200])));}}}}}}}}}}}}}}}}}}}}

/* k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5861,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 451  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[159]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[159]);
t4=((C_word*)t0)[9];
f_5848(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[164]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[159]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5848(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5899,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 455  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[166]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[159]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5848(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 457  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[167]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 459  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[168]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5934(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t8)){
t9=t7;
f_5934(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t9)){
t10=t7;
f_5934(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[147]);
if(C_truep(t10)){
t11=t7;
f_5934(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t11)){
t12=t7;
f_5934(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t12)){
t13=t7;
f_5934(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
if(C_truep(t13)){
t14=t7;
f_5934(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[178]);
if(C_truep(t14)){
t15=t7;
f_5934(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[179]);
t16=t7;
f_5934(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[180])));}}}}}}}}}}}}}}

/* k5932 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5934,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 462  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[170]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 464  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[171]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5965,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 466  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 467  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[6],lf[172],t4);}}}}

/* k5963 in k5932 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5848(2,t3,t2);}

/* k5953 in k5932 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5848(2,t3,t2);}

/* k5939 in k5932 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5945,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 462  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2]);}

/* k5943 in k5939 in k5932 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 462  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[169],((C_word*)t0)[2],t1);}

/* k5923 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5848(2,t3,t2);}

/* k5913 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5848(2,t3,t2);}

/* k5897 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5848(2,t3,t2);}

/* k5874 in k5859 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[161]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 451  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[162],t3);}

/* k5846 in k5843 in loop in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 468  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5835(t3,((C_word*)t0)[2],t2);}

/* k5718 in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5723,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[159]);
t5=t3;
f_5755(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5755(t4,C_SCHEME_FALSE);}}

/* k5753 in k5718 in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5755,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 470  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[4],lf[156],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[159]);
t4=t2;
f_5776(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5776(t3,C_SCHEME_FALSE);}}}

/* k5774 in k5753 in k5718 in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5776,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 472  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[4],lf[157],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5797,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[159]);
t4=t2;
f_5797(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5797(t3,C_SCHEME_FALSE);}}}

/* k5795 in k5774 in k5753 in k5718 in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5797,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 474  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[158],t6);}
else{
t2=((C_word*)t0)[2];
f_5723(2,t2,C_SCHEME_UNDEFINED);}}

/* k5721 in k5718 in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 475  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[155],t3);}
else{
t3=t2;
f_5726(2,t3,C_SCHEME_UNDEFINED);}}

/* k5724 in k5721 in k5718 in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5729,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 476  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[154],t3);}
else{
t3=t2;
f_5729(2,t3,C_SCHEME_UNDEFINED);}}

/* k5727 in k5724 in k5721 in k5718 in k5715 in a5706 in k5700 in ##compiler#display-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 477  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5685,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 414  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t2,C_retrieve(lf[144]));}

/* a5684 in ##compiler#display-line-number-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5685,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5696,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[151]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5694 in a5684 in ##compiler#display-line-number-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 416  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5655,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5661,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5661(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5661(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5661,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5671,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 410  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t4,((C_word*)t0)[2],t2,lf[147]);}}

/* k5669 in loop in ##compiler#find-lambda-container in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 411  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5661(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5619,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5626,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 402  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[144]),t3);}

/* k5624 in ##compiler#get-line-2 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5629(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5629(t3,C_SCHEME_FALSE);}}

/* k5627 in k5624 in ##compiler#get-line-2 in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_5629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 404  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 405  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5609,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 398  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t1,C_retrieve(lf[144]),t3,t2);}

/* ##compiler#count! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5552r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5552r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5552r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5556,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 386  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5554 in ##compiler#count! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5586,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 391  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 392  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5584 in k5554 in ##compiler#count! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5500,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5504,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 378  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5502 in ##compiler#collect! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5504,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5531,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 382  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 383  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5529 in k5502 in ##compiler#collect! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5454,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5458,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 370  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5456 in ##compiler#put! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5480,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 374  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 375  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5478 in k5456 in ##compiler#put! in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5436r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5436r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5436r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5440,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 364  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,t2,t3);}

/* k5438 in ##compiler#get-all in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 366  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5447 in k5438 in ##compiler#get-all in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5448,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5418,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5422,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 358  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,t2,t3);}

/* k5420 in ##compiler#get in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5267,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5275,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5349,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[134]));}
else{
t4=t3;
f_5271(2,t4,C_SCHEME_UNDEFINED);}}

/* a5348 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5349,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5380,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[133]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5355,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_5355(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_5355(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}

/* k5353 in a5348 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[126],t1);}

/* k5378 in a5348 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5380,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],C_retrieve(lf[131])))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5391,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5391(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5391(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5389 in k5378 in a5348 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[132],t1);}

/* k5273 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5316,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[130]));}

/* a5315 in k5273 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5316,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[129]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5322,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5322(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5322(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5320 in a5315 in k5273 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[126],t1);}

/* k5276 in k5273 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5283,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[128]));}

/* a5282 in k5276 in k5273 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5283,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[124]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5289,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5289(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5289(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5287 in a5282 in k5276 in k5273 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[126],t1);}

/* k5269 in ##compiler#initialize-analysis-database in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5126,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[114]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5130,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 320  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t6);}

/* k5128 in ##compiler#expand-profile-lambda in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 321  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[115]));}

/* k5132 in k5128 in ##compiler#expand-profile-lambda in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[114]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[117],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[118],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[118],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[119],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[118],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[83],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[120],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[118],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[121],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[118],t35));}

/* ##compiler#llist-length in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5123,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_length(t2));}

/* ##compiler#process-lambda-documentation in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5120,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5013,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5020,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),t3,t4);}

/* a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5022,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5028,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t3,t4);}

/* a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a5106 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5107r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5107r(t0,t1,t2);}}

static void C_ccall f_5107r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5113,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k580586 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5112 in a5106 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a5058 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5063,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5091,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 302  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t2,((C_word*)t0)[2],t3);}

/* a5090 in a5058 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5097,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5105,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 302  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t3);}

/* k5103 in a5090 in a5058 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 302  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[103]))(6,*((C_word*)lf[103]+1),((C_word*)t0)[3],*((C_word*)lf[104]+1),*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* a5096 in a5090 in a5058 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5097,3,t0,t1,t2);}
/* support.scm: 302  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t1);}

/* k5061 in a5058 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[99]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k5083 in k5061 in a5058 in a5052 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5085,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[100],t1));}

/* a5027 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5028,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5034,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k580586 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5033 in a5027 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5042,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 299  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k5043 in a5033 in a5027 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 300  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 301  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5040 in a5033 in a5027 in a5021 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 297  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[98],((C_word*)t0)[2],t1);}

/* k5018 in ##compiler#string->expr in k5010 in k5007 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4912,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4918(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4918(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4918,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[91]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[92]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4946,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4946(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4995,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 286  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t7,t4);}}}}

/* k4993 in loop in ##compiler#canonicalize-begin-body in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4946(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[96])));}

/* k4944 in loop in ##compiler#canonicalize-begin-body in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4946,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 288  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4918(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 289  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,lf[95]);}}

/* k4982 in k4944 in loop in ##compiler#canonicalize-begin-body in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4984,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 290  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4918(t8,t6,t7);}

/* k4970 in k4982 in k4944 in loop in ##compiler#canonicalize-begin-body in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4972,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* ##compiler#basic-literal? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4852,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 271  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t5,t2);}}}

/* k4866 in ##compiler#basic-literal? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 272  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4874(2,t3,C_SCHEME_FALSE);}}}

/* k4908 in k4866 in ##compiler#basic-literal? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 272  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[2],C_retrieve(lf[87]),t1);}

/* k4872 in k4866 in ##compiler#basic-literal? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 274  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4887 in k4872 in k4866 in ##compiler#basic-literal? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 275  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4806,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4810,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4850,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 261  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t4,t2);}
else{
t4=t3;
f_4810(t4,C_SCHEME_FALSE);}}

/* k4848 in ##compiler#immediate? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4810(t2,(C_word)C_i_not(t1));}

/* k4808 in ##compiler#immediate? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4776,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4730,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[83],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4710,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4716,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 240  sort */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t1,t2,t3);}

/* a4715 in ##compiler#sort-symbols in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4716,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4724,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 240  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t4,t2);}

/* k4722 in a4715 in ##compiler#sort-symbols in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4728,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 240  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k4726 in k4722 in a4715 in ##compiler#sort-symbols in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 240  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[80]+1)))(4,*((C_word*)lf[80]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4679,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4685,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4685(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4685(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4685,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 236  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 237  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4699 in loop in ##compiler#follow-without-loop in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4700,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 237  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4685(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4616,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4630,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 226  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t5,t3);}}

/* k4628 in ##compiler#fold-inner in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4632,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4632(t5,((C_word*)t0)[2],t1);}

/* fold in k4628 in ##compiler#fold-inner in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4632,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4640(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4661,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 231  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4659 in fold in k4628 in ##compiler#fold-inner in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4661,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4640(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4638 in fold in k4628 in ##compiler#fold-inner in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4604,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[74]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 221  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4557r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4557r(t0,t1,t2,t3);}}

static void C_ccall f_4557r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[67]))){
/* support.scm: 215  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[68]+1)))(2,*((C_word*)lf[68]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4573,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 216  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t4,t2);}}

/* k4571 in ##compiler#check-and-open-input-file in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 216  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4585(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4585(t5,(C_word)C_i_not(t4));}}}

/* k4583 in k4571 in ##compiler#check-and-open-input-file in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 217  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[70],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 218  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[71],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4550,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub338(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4543,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub333(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4487,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4491,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 196  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t4,t2);}

/* k4539 in ##compiler#valid-c-identifier? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4489 in ##compiler#valid-c-identifier? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4491,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4514,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 200  any */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4513 in k4489 in ##compiler#valid-c-identifier? in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4514,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4393,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4405,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4409,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4411,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4411(t5,((C_word*)t0)[2],t1);}

/* loop in k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4411,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[54]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4433,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4433(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4433(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[60])));}}}

/* k4431 in loop in k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4433,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4440(t3,lf[58]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4440(t4,(C_truep(t3)?lf[59]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 193  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4411(t4,t2,t3);}}

/* k4470 in k4431 in loop in k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4438 in k4431 in loop in k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4440,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4456,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 191  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4454 in k4438 in k4431 in loop in k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4442 in k4438 in k4431 in loop in k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4448,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 192  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4411(t4,t2,t3);}

/* k4446 in k4442 in k4438 in k4431 in loop in k4407 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 187  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[55]+1)))(6,*((C_word*)lf[55]+1),((C_word*)t0)[4],lf[56],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4403 in ##compiler#c-ify-string in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4405,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[53]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4349,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4355,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4355(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4355(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4355,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4379,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 173  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4377 in loop in ##compiler#build-lambda-list in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4324,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 167  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4347,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 168  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t3,lf[48],t2);}}}

/* k4345 in ##compiler#symbolify in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 168  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4303,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 162  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t1,t2);}
else{
/* support.scm: 163  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,lf[45],t2);}}}

/* ##compiler#posq in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4267,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4273,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4273(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static C_word C_fcall f_4273(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4199,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4202,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4223(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4223,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 146  err */
t4=((C_word*)t0)[3];
f_4202(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 148  err */
t5=((C_word*)t0)[3];
f_4202(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 149  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4202,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 143  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}

/* k4208 in err in ##compiler#check-signature in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4214,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 144  map-llist */
((C_proc4)C_retrieve_symbol_proc(lf[37]))(4,*((C_word*)lf[37]+1),t2,C_retrieve(lf[40]),t3);}

/* k4212 in k4208 in err in ##compiler#check-signature in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 142  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[39],((C_word*)t0)[2],t1);}

/* map-llist in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4156,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4162,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4162(t7,t1,t3);}

/* loop in map-llist in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4162,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 137  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 138  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4183 in loop in map-llist in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4189,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 138  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4162(t4,t2,t3);}

/* k4187 in k4183 in loop in map-llist in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4153,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[30])));}

/* ##sys#syntax-error-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4108r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4108r(t0,t1,t2,t3);}}

static void C_ccall f_4108r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4112,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 116  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t6);}

/* k4110 in ##sys#syntax-error-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t2;
f_4115(t8,t3);}
else{
t3=t2;
f_4115(t3,C_SCHEME_FALSE);}}

/* k4113 in k4110 in ##sys#syntax-error-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
/* support.scm: 123  fprintf */
((C_proc6)C_retrieve_symbol_proc(lf[21]))(6,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[33],t1,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* support.scm: 124  fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[34],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4116 in k4113 in k4110 in ##sys#syntax-error-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4128 in k4116 in k4113 in k4110 in ##sys#syntax-error-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4129,3,t0,t1,t2);}
/* fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t1,((C_word*)t0)[2],lf[32],t2);}

/* k4119 in k4116 in k4113 in k4110 in ##sys#syntax-error-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 126  print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[29]))(6,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[30]),lf[31]);}

/* k4122 in k4119 in k4116 in k4113 in k4110 in ##sys#syntax-error-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 127  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4089r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4089r(t0,t1,t2,t3);}}

static void C_ccall f_4089r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4093,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 109  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k4091 in quit in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4096,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[27],((C_word*)t0)[2]);}

/* k4104 in k4091 in quit in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4094 in k4091 in quit in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 111  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2]);}

/* k4097 in k4094 in k4091 in quit in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 112  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4060r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4060r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4060r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4067,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[24]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_4067(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_4067(t6,C_SCHEME_FALSE);}}

/* k4065 in ##compiler#compiler-warning in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_fcall f_4067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4067,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 104  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4068 in k4065 in ##compiler#compiler-warning in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4073,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[22],((C_word*)t0)[2]);}

/* k4078 in k4068 in k4065 in ##compiler#compiler-warning in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4071 in k4068 in k4065 in ##compiler#compiler-warning in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 106  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4020r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4020r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4020r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4030,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 93   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t5,lf[19],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k4028 in ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 96   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_4033(2,t3,C_SCHEME_UNDEFINED);}}

/* k4043 in k4028 in ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4050,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4049 in k4043 in k4028 in ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4050,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4058,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 97   force */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k4056 in a4049 in k4043 in k4028 in ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 97   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14],t1);}

/* k4031 in k4028 in ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k4034 in k4031 in k4028 in ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t2);}

/* k4037 in k4034 in k4031 in k4028 in ##compiler#debugging in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3993r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3993r(t0,t1,t2);}}

static void C_ccall f_3993r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4007,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 87   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 88   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k4005 in ##compiler#bomb in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[562] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3969:support_scm",(void*)f_3969},
{"f_3972:support_scm",(void*)f_3972},
{"f_3975:support_scm",(void*)f_3975},
{"f_3978:support_scm",(void*)f_3978},
{"f_3981:support_scm",(void*)f_3981},
{"f_3984:support_scm",(void*)f_3984},
{"f_5009:support_scm",(void*)f_5009},
{"f_5012:support_scm",(void*)f_5012},
{"f_11595:support_scm",(void*)f_11595},
{"f_11609:support_scm",(void*)f_11609},
{"f_11613:support_scm",(void*)f_11613},
{"f_11624:support_scm",(void*)f_11624},
{"f_11636:support_scm",(void*)f_11636},
{"f_11644:support_scm",(void*)f_11644},
{"f_11648:support_scm",(void*)f_11648},
{"f_11607:support_scm",(void*)f_11607},
{"f_11598:support_scm",(void*)f_11598},
{"f_11601:support_scm",(void*)f_11601},
{"f_11582:support_scm",(void*)f_11582},
{"f_11587:support_scm",(void*)f_11587},
{"f_11571:support_scm",(void*)f_11571},
{"f_11576:support_scm",(void*)f_11576},
{"f_11565:support_scm",(void*)f_11565},
{"f_11537:support_scm",(void*)f_11537},
{"f_11541:support_scm",(void*)f_11541},
{"f_11516:support_scm",(void*)f_11516},
{"f_11520:support_scm",(void*)f_11520},
{"f_11483:support_scm",(void*)f_11483},
{"f_11489:support_scm",(void*)f_11489},
{"f_11450:support_scm",(void*)f_11450},
{"f_11456:support_scm",(void*)f_11456},
{"f_11426:support_scm",(void*)f_11426},
{"f_11357:support_scm",(void*)f_11357},
{"f_11361:support_scm",(void*)f_11361},
{"f_11366:support_scm",(void*)f_11366},
{"f_11370:support_scm",(void*)f_11370},
{"f_11421:support_scm",(void*)f_11421},
{"f_11400:support_scm",(void*)f_11400},
{"f_11412:support_scm",(void*)f_11412},
{"f_11415:support_scm",(void*)f_11415},
{"f_11388:support_scm",(void*)f_11388},
{"f_11324:support_scm",(void*)f_11324},
{"f_11334:support_scm",(void*)f_11334},
{"f_11337:support_scm",(void*)f_11337},
{"f_11237:support_scm",(void*)f_11237},
{"f_11246:support_scm",(void*)f_11246},
{"f_11259:support_scm",(void*)f_11259},
{"f_11265:support_scm",(void*)f_11265},
{"f_11318:support_scm",(void*)f_11318},
{"f_11268:support_scm",(void*)f_11268},
{"f_11283:support_scm",(void*)f_11283},
{"f_11291:support_scm",(void*)f_11291},
{"f_11301:support_scm",(void*)f_11301},
{"f_11286:support_scm",(void*)f_11286},
{"f_11274:support_scm",(void*)f_11274},
{"f_11241:support_scm",(void*)f_11241},
{"f_11231:support_scm",(void*)f_11231},
{"f_11185:support_scm",(void*)f_11185},
{"f_11204:support_scm",(void*)f_11204},
{"f_11215:support_scm",(void*)f_11215},
{"f_11211:support_scm",(void*)f_11211},
{"f_11173:support_scm",(void*)f_11173},
{"f_11179:support_scm",(void*)f_11179},
{"f_11161:support_scm",(void*)f_11161},
{"f_11165:support_scm",(void*)f_11165},
{"f_11082:support_scm",(void*)f_11082},
{"f_11101:support_scm",(void*)f_11101},
{"f_11126:support_scm",(void*)f_11126},
{"f_11130:support_scm",(void*)f_11130},
{"f_11132:support_scm",(void*)f_11132},
{"f_11139:support_scm",(void*)f_11139},
{"f_11152:support_scm",(void*)f_11152},
{"f_11156:support_scm",(void*)f_11156},
{"f_11085:support_scm",(void*)f_11085},
{"f_11089:support_scm",(void*)f_11089},
{"f_11095:support_scm",(void*)f_11095},
{"f_11076:support_scm",(void*)f_11076},
{"f_11032:support_scm",(void*)f_11032},
{"f_11044:support_scm",(void*)f_11044},
{"f_11048:support_scm",(void*)f_11048},
{"f_11052:support_scm",(void*)f_11052},
{"f_11040:support_scm",(void*)f_11040},
{"f_11023:support_scm",(void*)f_11023},
{"f_11017:support_scm",(void*)f_11017},
{"f_11011:support_scm",(void*)f_11011},
{"f_10999:support_scm",(void*)f_10999},
{"f_11003:support_scm",(void*)f_11003},
{"f_11006:support_scm",(void*)f_11006},
{"f_10961:support_scm",(void*)f_10961},
{"f_10965:support_scm",(void*)f_10965},
{"f_10968:support_scm",(void*)f_10968},
{"f_10975:support_scm",(void*)f_10975},
{"f_10919:support_scm",(void*)f_10919},
{"f_10928:support_scm",(void*)f_10928},
{"f_10890:support_scm",(void*)f_10890},
{"f_10900:support_scm",(void*)f_10900},
{"f_10693:support_scm",(void*)f_10693},
{"f_10872:support_scm",(void*)f_10872},
{"f_10821:support_scm",(void*)f_10821},
{"f_10866:support_scm",(void*)f_10866},
{"f_10870:support_scm",(void*)f_10870},
{"f_10824:support_scm",(void*)f_10824},
{"f_10829:support_scm",(void*)f_10829},
{"f_10833:support_scm",(void*)f_10833},
{"f_10827:support_scm",(void*)f_10827},
{"f_10784:support_scm",(void*)f_10784},
{"f_10788:support_scm",(void*)f_10788},
{"f_10797:support_scm",(void*)f_10797},
{"f_10801:support_scm",(void*)f_10801},
{"f_10791:support_scm",(void*)f_10791},
{"f_10749:support_scm",(void*)f_10749},
{"f_10755:support_scm",(void*)f_10755},
{"f_10782:support_scm",(void*)f_10782},
{"f_10768:support_scm",(void*)f_10768},
{"f_10702:support_scm",(void*)f_10702},
{"f_10708:support_scm",(void*)f_10708},
{"f_10747:support_scm",(void*)f_10747},
{"f_10729:support_scm",(void*)f_10729},
{"f_10521:support_scm",(void*)f_10521},
{"f_10688:support_scm",(void*)f_10688},
{"f_10675:support_scm",(void*)f_10675},
{"f_10681:support_scm",(void*)f_10681},
{"f_10524:support_scm",(void*)f_10524},
{"f_10543:support_scm",(void*)f_10543},
{"f_10637:support_scm",(void*)f_10637},
{"f_10649:support_scm",(void*)f_10649},
{"f_10607:support_scm",(void*)f_10607},
{"f_10618:support_scm",(void*)f_10618},
{"f_10598:support_scm",(void*)f_10598},
{"f_10584:support_scm",(void*)f_10584},
{"f_10562:support_scm",(void*)f_10562},
{"f_10568:support_scm",(void*)f_10568},
{"f_10572:support_scm",(void*)f_10572},
{"f_10443:support_scm",(void*)f_10443},
{"f_10449:support_scm",(void*)f_10449},
{"f_10504:support_scm",(void*)f_10504},
{"f_10477:support_scm",(void*)f_10477},
{"f_10471:support_scm",(void*)f_10471},
{"f_10447:support_scm",(void*)f_10447},
{"f_10151:support_scm",(void*)f_10151},
{"f_10347:support_scm",(void*)f_10347},
{"f_10368:support_scm",(void*)f_10368},
{"f_9841:support_scm",(void*)f_9841},
{"f_10145:support_scm",(void*)f_10145},
{"f_9853:support_scm",(void*)f_9853},
{"f_9863:support_scm",(void*)f_9863},
{"f_9881:support_scm",(void*)f_9881},
{"f_9915:support_scm",(void*)f_9915},
{"f_9844:support_scm",(void*)f_9844},
{"f_9522:support_scm",(void*)f_9522},
{"f_9835:support_scm",(void*)f_9835},
{"f_9528:support_scm",(void*)f_9528},
{"f_9538:support_scm",(void*)f_9538},
{"f_9547:support_scm",(void*)f_9547},
{"f_9559:support_scm",(void*)f_9559},
{"f_9571:support_scm",(void*)f_9571},
{"f_9577:support_scm",(void*)f_9577},
{"f_9611:support_scm",(void*)f_9611},
{"f_9482:support_scm",(void*)f_9482},
{"f_9516:support_scm",(void*)f_9516},
{"f_9488:support_scm",(void*)f_9488},
{"f_9492:support_scm",(void*)f_9492},
{"f_9451:support_scm",(void*)f_9451},
{"f_9464:support_scm",(void*)f_9464},
{"f_9455:support_scm",(void*)f_9455},
{"f_9420:support_scm",(void*)f_9420},
{"f_9433:support_scm",(void*)f_9433},
{"f_9424:support_scm",(void*)f_9424},
{"f_8373:support_scm",(void*)f_8373},
{"f_9414:support_scm",(void*)f_9414},
{"f_8379:support_scm",(void*)f_8379},
{"f_8385:support_scm",(void*)f_8385},
{"f_8414:support_scm",(void*)f_8414},
{"f_8433:support_scm",(void*)f_8433},
{"f_8452:support_scm",(void*)f_8452},
{"f_8522:support_scm",(void*)f_8522},
{"f_8541:support_scm",(void*)f_8541},
{"f_8623:support_scm",(void*)f_8623},
{"f_8662:support_scm",(void*)f_8662},
{"f_8681:support_scm",(void*)f_8681},
{"f_8700:support_scm",(void*)f_8700},
{"f_8780:support_scm",(void*)f_8780},
{"f_8865:support_scm",(void*)f_8865},
{"f_8940:support_scm",(void*)f_8940},
{"f_8974:support_scm",(void*)f_8974},
{"f_9044:support_scm",(void*)f_9044},
{"f_8977:support_scm",(void*)f_8977},
{"f_8783:support_scm",(void*)f_8783},
{"f_8814:support_scm",(void*)f_8814},
{"f_8703:support_scm",(void*)f_8703},
{"f_8544:support_scm",(void*)f_8544},
{"f_8575:support_scm",(void*)f_8575},
{"f_8455:support_scm",(void*)f_8455},
{"f_8486:support_scm",(void*)f_8486},
{"f_8337:support_scm",(void*)f_8337},
{"f_8341:support_scm",(void*)f_8341},
{"f_8352:support_scm",(void*)f_8352},
{"f_8358:support_scm",(void*)f_8358},
{"f_8362:support_scm",(void*)f_8362},
{"f_8344:support_scm",(void*)f_8344},
{"f_8298:support_scm",(void*)f_8298},
{"f_8310:support_scm",(void*)f_8310},
{"f_8317:support_scm",(void*)f_8317},
{"f_8320:support_scm",(void*)f_8320},
{"f_8323:support_scm",(void*)f_8323},
{"f_8326:support_scm",(void*)f_8326},
{"f_8329:support_scm",(void*)f_8329},
{"f_8332:support_scm",(void*)f_8332},
{"f_8304:support_scm",(void*)f_8304},
{"f_8218:support_scm",(void*)f_8218},
{"f_8227:support_scm",(void*)f_8227},
{"f_8233:support_scm",(void*)f_8233},
{"f_8222:support_scm",(void*)f_8222},
{"f_8197:support_scm",(void*)f_8197},
{"f_8207:support_scm",(void*)f_8207},
{"f_8166:support_scm",(void*)f_8166},
{"f_8172:support_scm",(void*)f_8172},
{"f_8179:support_scm",(void*)f_8179},
{"f_8182:support_scm",(void*)f_8182},
{"f_8074:support_scm",(void*)f_8074},
{"f_8098:support_scm",(void*)f_8098},
{"f_7988:support_scm",(void*)f_7988},
{"f_7994:support_scm",(void*)f_7994},
{"f_8010:support_scm",(void*)f_8010},
{"f_8024:support_scm",(void*)f_8024},
{"f_8032:support_scm",(void*)f_8032},
{"f_7793:support_scm",(void*)f_7793},
{"f_7972:support_scm",(void*)f_7972},
{"f_7978:support_scm",(void*)f_7978},
{"f_7868:support_scm",(void*)f_7868},
{"f_7890:support_scm",(void*)f_7890},
{"f_7903:support_scm",(void*)f_7903},
{"f_7934:support_scm",(void*)f_7934},
{"f_7825:support_scm",(void*)f_7825},
{"f_7847:support_scm",(void*)f_7847},
{"f_7796:support_scm",(void*)f_7796},
{"f_7820:support_scm",(void*)f_7820},
{"f_7724:support_scm",(void*)f_7724},
{"f_7730:support_scm",(void*)f_7730},
{"f_7736:support_scm",(void*)f_7736},
{"f_7740:support_scm",(void*)f_7740},
{"f_7787:support_scm",(void*)f_7787},
{"f_7751:support_scm",(void*)f_7751},
{"f_7776:support_scm",(void*)f_7776},
{"f_7544:support_scm",(void*)f_7544},
{"f_7575:support_scm",(void*)f_7575},
{"f_7722:support_scm",(void*)f_7722},
{"f_7579:support_scm",(void*)f_7579},
{"f_7587:support_scm",(void*)f_7587},
{"f_7594:support_scm",(void*)f_7594},
{"f_7715:support_scm",(void*)f_7715},
{"f_7618:support_scm",(void*)f_7618},
{"f_7639:support_scm",(void*)f_7639},
{"f_7696:support_scm",(void*)f_7696},
{"f_7651:support_scm",(void*)f_7651},
{"f_7654:support_scm",(void*)f_7654},
{"f_7672:support_scm",(void*)f_7672},
{"f_7661:support_scm",(void*)f_7661},
{"f_7582:support_scm",(void*)f_7582},
{"f_7548:support_scm",(void*)f_7548},
{"f_7554:support_scm",(void*)f_7554},
{"f_7567:support_scm",(void*)f_7567},
{"f_7559:support_scm",(void*)f_7559},
{"f_7519:support_scm",(void*)f_7519},
{"f_7525:support_scm",(void*)f_7525},
{"f_7535:support_scm",(void*)f_7535},
{"f_7483:support_scm",(void*)f_7483},
{"f_7489:support_scm",(void*)f_7489},
{"f_7513:support_scm",(void*)f_7513},
{"f_7509:support_scm",(void*)f_7509},
{"f_7421:support_scm",(void*)f_7421},
{"f_7425:support_scm",(void*)f_7425},
{"f_7428:support_scm",(void*)f_7428},
{"f_7431:support_scm",(void*)f_7431},
{"f_7442:support_scm",(void*)f_7442},
{"f_7387:support_scm",(void*)f_7387},
{"f_7393:support_scm",(void*)f_7393},
{"f_7407:support_scm",(void*)f_7407},
{"f_7411:support_scm",(void*)f_7411},
{"f_7209:support_scm",(void*)f_7209},
{"f_7213:support_scm",(void*)f_7213},
{"f_7221:support_scm",(void*)f_7221},
{"f_7370:support_scm",(void*)f_7370},
{"f_7378:support_scm",(void*)f_7378},
{"f_7373:support_scm",(void*)f_7373},
{"f_7322:support_scm",(void*)f_7322},
{"f_7326:support_scm",(void*)f_7326},
{"f_7329:support_scm",(void*)f_7329},
{"f_7348:support_scm",(void*)f_7348},
{"f_7364:support_scm",(void*)f_7364},
{"f_7356:support_scm",(void*)f_7356},
{"f_7340:support_scm",(void*)f_7340},
{"f_7335:support_scm",(void*)f_7335},
{"f_7289:support_scm",(void*)f_7289},
{"f_7292:support_scm",(void*)f_7292},
{"f_7303:support_scm",(void*)f_7303},
{"f_7298:support_scm",(void*)f_7298},
{"f_7273:support_scm",(void*)f_7273},
{"f_7265:support_scm",(void*)f_7265},
{"f_7260:support_scm",(void*)f_7260},
{"f_7244:support_scm",(void*)f_7244},
{"f_7215:support_scm",(void*)f_7215},
{"f_7116:support_scm",(void*)f_7116},
{"f_7122:support_scm",(void*)f_7122},
{"f_7134:support_scm",(void*)f_7134},
{"f_7138:support_scm",(void*)f_7138},
{"f_7141:support_scm",(void*)f_7141},
{"f_7201:support_scm",(void*)f_7201},
{"f_7177:support_scm",(void*)f_7177},
{"f_7160:support_scm",(void*)f_7160},
{"f_7164:support_scm",(void*)f_7164},
{"f_7146:support_scm",(void*)f_7146},
{"f_7128:support_scm",(void*)f_7128},
{"f_7068:support_scm",(void*)f_7068},
{"f_7074:support_scm",(void*)f_7074},
{"f_7094:support_scm",(void*)f_7094},
{"f_7098:support_scm",(void*)f_7098},
{"f_6750:support_scm",(void*)f_6750},
{"f_6756:support_scm",(void*)f_6756},
{"f_6775:support_scm",(void*)f_6775},
{"f_7009:support_scm",(void*)f_7009},
{"f_7039:support_scm",(void*)f_7039},
{"f_7035:support_scm",(void*)f_7035},
{"f_7016:support_scm",(void*)f_7016},
{"f_7020:support_scm",(void*)f_7020},
{"f_6947:support_scm",(void*)f_6947},
{"f_6996:support_scm",(void*)f_6996},
{"f_6965:support_scm",(void*)f_6965},
{"f_6973:support_scm",(void*)f_6973},
{"f_6923:support_scm",(void*)f_6923},
{"f_6890:support_scm",(void*)f_6890},
{"f_6869:support_scm",(void*)f_6869},
{"f_6865:support_scm",(void*)f_6865},
{"f_6849:support_scm",(void*)f_6849},
{"f_6861:support_scm",(void*)f_6861},
{"f_6857:support_scm",(void*)f_6857},
{"f_6803:support_scm",(void*)f_6803},
{"f_6799:support_scm",(void*)f_6799},
{"f_6782:support_scm",(void*)f_6782},
{"f_6236:support_scm",(void*)f_6236},
{"f_6745:support_scm",(void*)f_6745},
{"f_6748:support_scm",(void*)f_6748},
{"f_6239:support_scm",(void*)f_6239},
{"f_6735:support_scm",(void*)f_6735},
{"f_6615:support_scm",(void*)f_6615},
{"f_6658:support_scm",(void*)f_6658},
{"f_6695:support_scm",(void*)f_6695},
{"f_6672:support_scm",(void*)f_6672},
{"f_6679:support_scm",(void*)f_6679},
{"f_6686:support_scm",(void*)f_6686},
{"f_6676:support_scm",(void*)f_6676},
{"f_6665:support_scm",(void*)f_6665},
{"f_6652:support_scm",(void*)f_6652},
{"f_6640:support_scm",(void*)f_6640},
{"f_6624:support_scm",(void*)f_6624},
{"f_6594:support_scm",(void*)f_6594},
{"f_6578:support_scm",(void*)f_6578},
{"f_6574:support_scm",(void*)f_6574},
{"f_6541:support_scm",(void*)f_6541},
{"f_6499:support_scm",(void*)f_6499},
{"f_6468:support_scm",(void*)f_6468},
{"f_6454:support_scm",(void*)f_6454},
{"f_6428:support_scm",(void*)f_6428},
{"f_6374:support_scm",(void*)f_6374},
{"f_6394:support_scm",(void*)f_6394},
{"f_6384:support_scm",(void*)f_6384},
{"f_6392:support_scm",(void*)f_6392},
{"f_6377:support_scm",(void*)f_6377},
{"f_6324:support_scm",(void*)f_6324},
{"f_6327:support_scm",(void*)f_6327},
{"f_6334:support_scm",(void*)f_6334},
{"f_6321:support_scm",(void*)f_6321},
{"f_6298:support_scm",(void*)f_6298},
{"f_6227:support_scm",(void*)f_6227},
{"f_6218:support_scm",(void*)f_6218},
{"f_6212:support_scm",(void*)f_6212},
{"f_6203:support_scm",(void*)f_6203},
{"f_6194:support_scm",(void*)f_6194},
{"f_6185:support_scm",(void*)f_6185},
{"f_6176:support_scm",(void*)f_6176},
{"f_6167:support_scm",(void*)f_6167},
{"f_6158:support_scm",(void*)f_6158},
{"f_6152:support_scm",(void*)f_6152},
{"f_6146:support_scm",(void*)f_6146},
{"f_5698:support_scm",(void*)f_5698},
{"f_6144:support_scm",(void*)f_6144},
{"f_5702:support_scm",(void*)f_5702},
{"f_5707:support_scm",(void*)f_5707},
{"f_5717:support_scm",(void*)f_5717},
{"f_5835:support_scm",(void*)f_5835},
{"f_5845:support_scm",(void*)f_5845},
{"f_5861:support_scm",(void*)f_5861},
{"f_5934:support_scm",(void*)f_5934},
{"f_5965:support_scm",(void*)f_5965},
{"f_5955:support_scm",(void*)f_5955},
{"f_5941:support_scm",(void*)f_5941},
{"f_5945:support_scm",(void*)f_5945},
{"f_5925:support_scm",(void*)f_5925},
{"f_5915:support_scm",(void*)f_5915},
{"f_5899:support_scm",(void*)f_5899},
{"f_5876:support_scm",(void*)f_5876},
{"f_5848:support_scm",(void*)f_5848},
{"f_5720:support_scm",(void*)f_5720},
{"f_5755:support_scm",(void*)f_5755},
{"f_5776:support_scm",(void*)f_5776},
{"f_5797:support_scm",(void*)f_5797},
{"f_5723:support_scm",(void*)f_5723},
{"f_5726:support_scm",(void*)f_5726},
{"f_5729:support_scm",(void*)f_5729},
{"f_5679:support_scm",(void*)f_5679},
{"f_5685:support_scm",(void*)f_5685},
{"f_5696:support_scm",(void*)f_5696},
{"f_5655:support_scm",(void*)f_5655},
{"f_5661:support_scm",(void*)f_5661},
{"f_5671:support_scm",(void*)f_5671},
{"f_5619:support_scm",(void*)f_5619},
{"f_5626:support_scm",(void*)f_5626},
{"f_5629:support_scm",(void*)f_5629},
{"f_5609:support_scm",(void*)f_5609},
{"f_5552:support_scm",(void*)f_5552},
{"f_5556:support_scm",(void*)f_5556},
{"f_5586:support_scm",(void*)f_5586},
{"f_5500:support_scm",(void*)f_5500},
{"f_5504:support_scm",(void*)f_5504},
{"f_5531:support_scm",(void*)f_5531},
{"f_5454:support_scm",(void*)f_5454},
{"f_5458:support_scm",(void*)f_5458},
{"f_5480:support_scm",(void*)f_5480},
{"f_5436:support_scm",(void*)f_5436},
{"f_5440:support_scm",(void*)f_5440},
{"f_5448:support_scm",(void*)f_5448},
{"f_5418:support_scm",(void*)f_5418},
{"f_5422:support_scm",(void*)f_5422},
{"f_5267:support_scm",(void*)f_5267},
{"f_5349:support_scm",(void*)f_5349},
{"f_5355:support_scm",(void*)f_5355},
{"f_5380:support_scm",(void*)f_5380},
{"f_5391:support_scm",(void*)f_5391},
{"f_5275:support_scm",(void*)f_5275},
{"f_5316:support_scm",(void*)f_5316},
{"f_5322:support_scm",(void*)f_5322},
{"f_5278:support_scm",(void*)f_5278},
{"f_5283:support_scm",(void*)f_5283},
{"f_5289:support_scm",(void*)f_5289},
{"f_5271:support_scm",(void*)f_5271},
{"f_5126:support_scm",(void*)f_5126},
{"f_5130:support_scm",(void*)f_5130},
{"f_5134:support_scm",(void*)f_5134},
{"f_5123:support_scm",(void*)f_5123},
{"f_5120:support_scm",(void*)f_5120},
{"f_5013:support_scm",(void*)f_5013},
{"f_5022:support_scm",(void*)f_5022},
{"f_5053:support_scm",(void*)f_5053},
{"f_5107:support_scm",(void*)f_5107},
{"f_5113:support_scm",(void*)f_5113},
{"f_5059:support_scm",(void*)f_5059},
{"f_5091:support_scm",(void*)f_5091},
{"f_5105:support_scm",(void*)f_5105},
{"f_5097:support_scm",(void*)f_5097},
{"f_5063:support_scm",(void*)f_5063},
{"f_5085:support_scm",(void*)f_5085},
{"f_5028:support_scm",(void*)f_5028},
{"f_5034:support_scm",(void*)f_5034},
{"f_5045:support_scm",(void*)f_5045},
{"f_5042:support_scm",(void*)f_5042},
{"f_5020:support_scm",(void*)f_5020},
{"f_4912:support_scm",(void*)f_4912},
{"f_4918:support_scm",(void*)f_4918},
{"f_4995:support_scm",(void*)f_4995},
{"f_4946:support_scm",(void*)f_4946},
{"f_4984:support_scm",(void*)f_4984},
{"f_4972:support_scm",(void*)f_4972},
{"f_4852:support_scm",(void*)f_4852},
{"f_4868:support_scm",(void*)f_4868},
{"f_4910:support_scm",(void*)f_4910},
{"f_4874:support_scm",(void*)f_4874},
{"f_4889:support_scm",(void*)f_4889},
{"f_4806:support_scm",(void*)f_4806},
{"f_4850:support_scm",(void*)f_4850},
{"f_4810:support_scm",(void*)f_4810},
{"f_4776:support_scm",(void*)f_4776},
{"f_4730:support_scm",(void*)f_4730},
{"f_4710:support_scm",(void*)f_4710},
{"f_4716:support_scm",(void*)f_4716},
{"f_4724:support_scm",(void*)f_4724},
{"f_4728:support_scm",(void*)f_4728},
{"f_4679:support_scm",(void*)f_4679},
{"f_4685:support_scm",(void*)f_4685},
{"f_4700:support_scm",(void*)f_4700},
{"f_4616:support_scm",(void*)f_4616},
{"f_4630:support_scm",(void*)f_4630},
{"f_4632:support_scm",(void*)f_4632},
{"f_4661:support_scm",(void*)f_4661},
{"f_4640:support_scm",(void*)f_4640},
{"f_4604:support_scm",(void*)f_4604},
{"f_4557:support_scm",(void*)f_4557},
{"f_4573:support_scm",(void*)f_4573},
{"f_4585:support_scm",(void*)f_4585},
{"f_4550:support_scm",(void*)f_4550},
{"f_4543:support_scm",(void*)f_4543},
{"f_4487:support_scm",(void*)f_4487},
{"f_4541:support_scm",(void*)f_4541},
{"f_4491:support_scm",(void*)f_4491},
{"f_4514:support_scm",(void*)f_4514},
{"f_4393:support_scm",(void*)f_4393},
{"f_4409:support_scm",(void*)f_4409},
{"f_4411:support_scm",(void*)f_4411},
{"f_4433:support_scm",(void*)f_4433},
{"f_4472:support_scm",(void*)f_4472},
{"f_4440:support_scm",(void*)f_4440},
{"f_4456:support_scm",(void*)f_4456},
{"f_4444:support_scm",(void*)f_4444},
{"f_4448:support_scm",(void*)f_4448},
{"f_4405:support_scm",(void*)f_4405},
{"f_4349:support_scm",(void*)f_4349},
{"f_4355:support_scm",(void*)f_4355},
{"f_4379:support_scm",(void*)f_4379},
{"f_4324:support_scm",(void*)f_4324},
{"f_4347:support_scm",(void*)f_4347},
{"f_4303:support_scm",(void*)f_4303},
{"f_4267:support_scm",(void*)f_4267},
{"f_4273:support_scm",(void*)f_4273},
{"f_4199:support_scm",(void*)f_4199},
{"f_4223:support_scm",(void*)f_4223},
{"f_4202:support_scm",(void*)f_4202},
{"f_4210:support_scm",(void*)f_4210},
{"f_4214:support_scm",(void*)f_4214},
{"f_4156:support_scm",(void*)f_4156},
{"f_4162:support_scm",(void*)f_4162},
{"f_4185:support_scm",(void*)f_4185},
{"f_4189:support_scm",(void*)f_4189},
{"f_4153:support_scm",(void*)f_4153},
{"f_4108:support_scm",(void*)f_4108},
{"f_4112:support_scm",(void*)f_4112},
{"f_4115:support_scm",(void*)f_4115},
{"f_4118:support_scm",(void*)f_4118},
{"f_4129:support_scm",(void*)f_4129},
{"f_4121:support_scm",(void*)f_4121},
{"f_4124:support_scm",(void*)f_4124},
{"f_4089:support_scm",(void*)f_4089},
{"f_4093:support_scm",(void*)f_4093},
{"f_4106:support_scm",(void*)f_4106},
{"f_4096:support_scm",(void*)f_4096},
{"f_4099:support_scm",(void*)f_4099},
{"f_4060:support_scm",(void*)f_4060},
{"f_4067:support_scm",(void*)f_4067},
{"f_4070:support_scm",(void*)f_4070},
{"f_4080:support_scm",(void*)f_4080},
{"f_4073:support_scm",(void*)f_4073},
{"f_4020:support_scm",(void*)f_4020},
{"f_4030:support_scm",(void*)f_4030},
{"f_4045:support_scm",(void*)f_4045},
{"f_4050:support_scm",(void*)f_4050},
{"f_4058:support_scm",(void*)f_4058},
{"f_4033:support_scm",(void*)f_4033},
{"f_4036:support_scm",(void*)f_4036},
{"f_4039:support_scm",(void*)f_4039},
{"f_3993:support_scm",(void*)f_3993},
{"f_4007:support_scm",(void*)f_4007},
{"f_3988:support_scm",(void*)f_3988},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
