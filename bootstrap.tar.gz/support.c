/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-08 08:53
   Version 4.0.0x3 - SVN rev. 12690
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-12-01 on dill (Linux)
   command line: support.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[498];
static double C_possibly_force_alignment;


/* from k4392 */
static C_word C_fcall stub331(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub331(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4385 */
static C_word C_fcall stub326(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub326(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11818)
static void C_ccall f_11818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11823)
static void C_ccall f_11823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11812)
static void C_ccall f_11812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11784)
static void C_ccall f_11784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11784)
static void C_ccall f_11784r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11788)
static void C_ccall f_11788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11763)
static void C_ccall f_11763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11767)
static void C_ccall f_11767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11730)
static void C_ccall f_11730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11735)
static void C_ccall f_11735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11735)
static void C_ccall f_11735r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11739)
static void C_ccall f_11739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11702)
static void C_ccall f_11702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11702)
static void C_ccall f_11702r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11706)
static void C_ccall f_11706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11673)
static void C_ccall f_11673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11604)
static void C_ccall f_11604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11608)
static void C_ccall f_11608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11613)
static void C_fcall f_11613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11617)
static void C_ccall f_11617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11668)
static void C_ccall f_11668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11647)
static void C_ccall f_11647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11659)
static void C_ccall f_11659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11662)
static void C_ccall f_11662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11635)
static void C_ccall f_11635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11571)
static void C_ccall f_11571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11581)
static void C_ccall f_11581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11584)
static void C_ccall f_11584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11469)
static void C_ccall f_11469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11478)
static void C_fcall f_11478(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11565)
static void C_ccall f_11565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11482)
static void C_ccall f_11482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11560)
static void C_ccall f_11560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11485)
static void C_ccall f_11485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11488)
static void C_ccall f_11488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11491)
static void C_ccall f_11491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11497)
static void C_ccall f_11497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11550)
static void C_ccall f_11550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11500)
static void C_ccall f_11500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11515)
static void C_ccall f_11515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11523)
static void C_fcall f_11523(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11533)
static void C_ccall f_11533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11518)
static void C_ccall f_11518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11506)
static void C_ccall f_11506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11473)
static void C_ccall f_11473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11463)
static void C_ccall f_11463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11436)
static void C_ccall f_11436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11447)
static void C_ccall f_11447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11443)
static void C_ccall f_11443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11405)
static void C_ccall f_11405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11411)
static void C_ccall f_11411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11393)
static void C_ccall f_11393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11397)
static void C_ccall f_11397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11314)
static void C_ccall f_11314(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11314)
static void C_ccall f_11314r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11333)
static void C_ccall f_11333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11362)
static void C_ccall f_11362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11364)
static void C_fcall f_11364(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11371)
static void C_ccall f_11371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11384)
static void C_ccall f_11384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11388)
static void C_ccall f_11388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11317)
static void C_fcall f_11317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11321)
static void C_ccall f_11321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11327)
static void C_ccall f_11327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11308)
static void C_ccall f_11308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11264)
static void C_ccall f_11264(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11264)
static void C_ccall f_11264r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11276)
static void C_ccall f_11276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11280)
static void C_ccall f_11280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11284)
static void C_ccall f_11284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11272)
static void C_ccall f_11272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11255)
static void C_ccall f_11255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11249)
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11243)
static void C_ccall f_11243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11231)
static void C_ccall f_11231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11235)
static void C_ccall f_11235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11238)
static void C_ccall f_11238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11193)
static void C_ccall f_11193(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11193)
static void C_ccall f_11193r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11197)
static void C_ccall f_11197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11200)
static void C_ccall f_11200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11207)
static void C_ccall f_11207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11151)
static void C_ccall f_11151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11160)
static void C_fcall f_11160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11122)
static void C_ccall f_11122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11132)
static void C_fcall f_11132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10925)
static void C_ccall f_10925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11104)
static void C_ccall f_11104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11053)
static void C_ccall f_11053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11098)
static void C_ccall f_11098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11102)
static void C_ccall f_11102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11061)
static void C_ccall f_11061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11065)
static void C_ccall f_11065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11059)
static void C_ccall f_11059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11016)
static void C_fcall f_11016(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11020)
static void C_ccall f_11020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11029)
static void C_ccall f_11029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11033)
static void C_ccall f_11033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11023)
static void C_ccall f_11023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10981)
static void C_fcall f_10981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10987)
static void C_fcall f_10987(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11014)
static void C_ccall f_11014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11000)
static void C_ccall f_11000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10934)
static void C_fcall f_10934(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10940)
static void C_fcall f_10940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10979)
static void C_ccall f_10979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10961)
static void C_ccall f_10961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10738)
static void C_ccall f_10738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10920)
static void C_ccall f_10920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10907)
static void C_fcall f_10907(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10913)
static void C_ccall f_10913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10741)
static void C_fcall f_10741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10901)
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10745)
static void C_ccall f_10745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10896)
static void C_ccall f_10896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10748)
static void C_ccall f_10748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10891)
static void C_ccall f_10891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10751)
static void C_ccall f_10751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10760)
static void C_fcall f_10760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10854)
static void C_ccall f_10854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10866)
static void C_ccall f_10866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10824)
static void C_ccall f_10824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10835)
static void C_ccall f_10835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10815)
static void C_ccall f_10815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10801)
static void C_fcall f_10801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10779)
static void C_ccall f_10779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10785)
static void C_ccall f_10785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10789)
static void C_ccall f_10789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10645)
static void C_ccall f_10645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10651)
static void C_ccall f_10651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10732)
static void C_ccall f_10732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10655)
static void C_ccall f_10655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10658)
static void C_ccall f_10658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10711)
static void C_fcall f_10711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10698)
static void C_ccall f_10698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10697)
static void C_ccall f_10697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10679)
static void C_fcall f_10679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10673)
static void C_fcall f_10673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10549)
static void C_fcall f_10549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10570)
static void C_fcall f_10570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10043)
static void C_ccall f_10043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10347)
static void C_ccall f_10347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10055)
static void C_ccall f_10055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10065)
static void C_fcall f_10065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10083)
static void C_ccall f_10083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10117)
static void C_fcall f_10117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10046)
static void C_fcall f_10046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9724)
static void C_ccall f_9724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10037)
static void C_ccall f_10037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9730)
static void C_ccall f_9730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9740)
static void C_fcall f_9740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_fcall f_9749(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9761)
static void C_fcall f_9761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9773)
static void C_fcall f_9773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_ccall f_9779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9813)
static void C_fcall f_9813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9684)
static void C_ccall f_9684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9718)
static void C_ccall f_9718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9690)
static void C_ccall f_9690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9694)
static void C_ccall f_9694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9666)
static void C_ccall f_9666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9657)
static void C_fcall f_9657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9622)
static void C_ccall f_9622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9626)
static void C_fcall f_9626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8587)
static void C_fcall f_8587(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8616)
static void C_fcall f_8616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_fcall f_8635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_fcall f_8654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_fcall f_8724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8743)
static void C_fcall f_8743(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8825)
static void C_fcall f_8825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8864)
static void C_fcall f_8864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8883)
static void C_fcall f_8883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_fcall f_8902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_fcall f_8982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9067)
static void C_fcall f_9067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_fcall f_9176(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9246)
static void C_ccall f_9246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9179)
static void C_ccall f_9179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8985)
static void C_ccall f_8985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_fcall f_9016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8746)
static void C_ccall f_8746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_fcall f_8777(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8657)
static void C_ccall f_8657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_fcall f_8688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8539)
static void C_ccall f_8539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8543)
static void C_ccall f_8543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_ccall f_8560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8500)
static void C_ccall f_8500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8519)
static void C_ccall f_8519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_ccall f_8522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8534)
static void C_ccall f_8534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8506)
static void C_ccall f_8506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8414)
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8423)
static void C_ccall f_8423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8429)
static void C_ccall f_8429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8476)
static void C_ccall f_8476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_ccall f_8393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8403)
static void C_ccall f_8403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8368)
static void C_ccall f_8368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8375)
static void C_fcall f_8375(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8378)
static void C_ccall f_8378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8264)
static void C_ccall f_8264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8339)
static void C_ccall f_8339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8316)
static void C_ccall f_8316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8308)
static void C_ccall f_8308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8145)
static void C_ccall f_8145(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8234)
static void C_ccall f_8234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8149)
static void C_ccall f_8149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8229)
static void C_ccall f_8229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8152)
static void C_ccall f_8152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8161)
static void C_fcall f_8161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_ccall f_8188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8187)
static void C_ccall f_8187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8175)
static void C_ccall f_8175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8183)
static void C_ccall f_8183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8123)
static void C_ccall f_8123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8128)
static void C_ccall f_8128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8119)
static void C_ccall f_8119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8080)
static void C_ccall f_8080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_fcall f_8029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7951)
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7973)
static void C_ccall f_7973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_fcall f_7922(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7862)
static void C_fcall f_7862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7886)
static void C_ccall f_7886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7891)
static void C_ccall f_7891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7648)
static void C_ccall f_7648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_ccall f_7683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7722)
static void C_fcall f_7722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7740)
static void C_ccall f_7740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7755)
static void C_fcall f_7755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7773)
static void C_ccall f_7773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7652)
static void C_ccall f_7652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7615)
static void C_ccall f_7615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7637)
static void C_ccall f_7637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7609)
static void C_ccall f_7609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7590)
static void C_ccall f_7590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static C_word C_fcall f_7508(C_word t0,C_word t1);
C_noret_decl(f_7453)
static void C_ccall f_7453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7459)
static void C_fcall f_7459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7244)
static void C_fcall f_7244(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7248)
static void C_ccall f_7248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7254)
static void C_ccall f_7254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7418)
static void C_ccall f_7418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7366)
static void C_ccall f_7366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7384)
static void C_ccall f_7384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7322)
static void C_ccall f_7322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7334)
static void C_ccall f_7334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7289)
static void C_ccall f_7289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7267)
static void C_ccall f_7267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_fcall f_7238(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7137)
static void C_ccall f_7137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7194)
static void C_ccall f_7194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7186)
static void C_ccall f_7186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7170)
static void C_ccall f_7170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7174)
static void C_ccall f_7174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7149)
static void C_ccall f_7149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7071)
static void C_fcall f_7071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6757)
static void C_fcall f_6757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_fcall f_6991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6998)
static void C_ccall f_6998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7002)
static void C_ccall f_7002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6929)
static void C_fcall f_6929(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6905)
static void C_ccall f_6905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6764)
static void C_ccall f_6764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6565)
static void C_fcall f_6565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_fcall f_6643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_ccall f_6603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6528)
static void C_ccall f_6528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6516)
static void C_ccall f_6516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6390)
static void C_fcall f_6390(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6224)
static void C_fcall f_6224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6221)
static void C_fcall f_6221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6102)
static void C_ccall f_6102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_fcall f_5535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_fcall f_5698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_fcall f_5724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_fcall f_5797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_fcall f_5588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_fcall f_5619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_fcall f_5650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5494)
static void C_fcall f_5494(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_fcall f_5462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4757)
static void C_fcall f_4757(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_fcall f_4785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_fcall f_4649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4524)
static void C_fcall f_4524(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_fcall f_4471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_fcall f_4479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_fcall f_4424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_fcall f_4250(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4272)
static void C_fcall f_4272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_fcall f_4279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4194)
static void C_fcall f_4194(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4112)
static C_word C_fcall f_4112(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4062)
static void C_fcall f_4062(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4041)
static void C_fcall f_4041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4001)
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3926)
static void C_fcall f_3926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_ccall f_3892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11613)
static void C_fcall trf_11613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11613(t0,t1);}

C_noret_decl(trf_11478)
static void C_fcall trf_11478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11478(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11478(t0,t1,t2,t3);}

C_noret_decl(trf_11523)
static void C_fcall trf_11523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11523(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11523(t0,t1,t2);}

C_noret_decl(trf_11364)
static void C_fcall trf_11364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11364(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11364(t0,t1,t2,t3);}

C_noret_decl(trf_11317)
static void C_fcall trf_11317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11317(t0,t1);}

C_noret_decl(trf_11160)
static void C_fcall trf_11160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11160(t0,t1,t2);}

C_noret_decl(trf_11132)
static void C_fcall trf_11132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11132(t0,t1);}

C_noret_decl(trf_11016)
static void C_fcall trf_11016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11016(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11016(t0,t1,t2,t3);}

C_noret_decl(trf_10981)
static void C_fcall trf_10981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10981(t0,t1,t2);}

C_noret_decl(trf_10987)
static void C_fcall trf_10987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10987(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10987(t0,t1,t2);}

C_noret_decl(trf_10934)
static void C_fcall trf_10934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10934(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10934(t0,t1,t2,t3);}

C_noret_decl(trf_10940)
static void C_fcall trf_10940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10940(t0,t1,t2);}

C_noret_decl(trf_10907)
static void C_fcall trf_10907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10907(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10907(t0,t1,t2,t3);}

C_noret_decl(trf_10741)
static void C_fcall trf_10741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10741(t0,t1,t2,t3);}

C_noret_decl(trf_10760)
static void C_fcall trf_10760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10760(t0,t1);}

C_noret_decl(trf_10801)
static void C_fcall trf_10801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10801(t0,t1);}

C_noret_decl(trf_10711)
static void C_fcall trf_10711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10711(t0,t1);}

C_noret_decl(trf_10679)
static void C_fcall trf_10679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10679(t0,t1);}

C_noret_decl(trf_10673)
static void C_fcall trf_10673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10673(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10673(t0,t1);}

C_noret_decl(trf_10549)
static void C_fcall trf_10549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10549(t0,t1);}

C_noret_decl(trf_10570)
static void C_fcall trf_10570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10570(t0,t1);}

C_noret_decl(trf_10065)
static void C_fcall trf_10065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10065(t0,t1);}

C_noret_decl(trf_10117)
static void C_fcall trf_10117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10117(t0,t1);}

C_noret_decl(trf_10046)
static void C_fcall trf_10046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10046(t0,t1);}

C_noret_decl(trf_9740)
static void C_fcall trf_9740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9740(t0,t1);}

C_noret_decl(trf_9749)
static void C_fcall trf_9749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9749(t0,t1);}

C_noret_decl(trf_9761)
static void C_fcall trf_9761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9761(t0,t1);}

C_noret_decl(trf_9773)
static void C_fcall trf_9773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9773(t0,t1);}

C_noret_decl(trf_9813)
static void C_fcall trf_9813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9813(t0,t1);}

C_noret_decl(trf_9657)
static void C_fcall trf_9657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9657(t0,t1);}

C_noret_decl(trf_9626)
static void C_fcall trf_9626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9626(t0,t1);}

C_noret_decl(trf_8587)
static void C_fcall trf_8587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8587(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8587(t0,t1,t2);}

C_noret_decl(trf_8616)
static void C_fcall trf_8616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8616(t0,t1);}

C_noret_decl(trf_8635)
static void C_fcall trf_8635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8635(t0,t1);}

C_noret_decl(trf_8654)
static void C_fcall trf_8654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8654(t0,t1);}

C_noret_decl(trf_8724)
static void C_fcall trf_8724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8724(t0,t1);}

C_noret_decl(trf_8743)
static void C_fcall trf_8743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8743(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8743(t0,t1);}

C_noret_decl(trf_8825)
static void C_fcall trf_8825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8825(t0,t1);}

C_noret_decl(trf_8864)
static void C_fcall trf_8864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8864(t0,t1);}

C_noret_decl(trf_8883)
static void C_fcall trf_8883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8883(t0,t1);}

C_noret_decl(trf_8902)
static void C_fcall trf_8902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8902(t0,t1);}

C_noret_decl(trf_8982)
static void C_fcall trf_8982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8982(t0,t1);}

C_noret_decl(trf_9067)
static void C_fcall trf_9067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9067(t0,t1);}

C_noret_decl(trf_9176)
static void C_fcall trf_9176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9176(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9176(t0,t1);}

C_noret_decl(trf_9016)
static void C_fcall trf_9016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9016(t0,t1);}

C_noret_decl(trf_8777)
static void C_fcall trf_8777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8777(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8777(t0,t1);}

C_noret_decl(trf_8688)
static void C_fcall trf_8688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8688(t0,t1);}

C_noret_decl(trf_8375)
static void C_fcall trf_8375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8375(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8375(t0,t1);}

C_noret_decl(trf_8161)
static void C_fcall trf_8161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8161(t0,t1);}

C_noret_decl(trf_7994)
static void C_fcall trf_7994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7994(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7994(t0,t1,t2,t3);}

C_noret_decl(trf_8029)
static void C_fcall trf_8029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8029(t0,t1,t2,t3);}

C_noret_decl(trf_7951)
static void C_fcall trf_7951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7951(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7951(t0,t1,t2,t3);}

C_noret_decl(trf_7922)
static void C_fcall trf_7922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7922(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7922(t0,t1,t2,t3);}

C_noret_decl(trf_7862)
static void C_fcall trf_7862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7862(t0,t1);}

C_noret_decl(trf_7722)
static void C_fcall trf_7722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7722(t0,t1);}

C_noret_decl(trf_7755)
static void C_fcall trf_7755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7755(t0,t1);}

C_noret_decl(trf_7459)
static void C_fcall trf_7459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7459(t0,t1,t2);}

C_noret_decl(trf_7244)
static void C_fcall trf_7244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7244(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7244(t0,t1,t2,t3);}

C_noret_decl(trf_7238)
static void C_fcall trf_7238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7238(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7238(t0,t1,t2);}

C_noret_decl(trf_7071)
static void C_fcall trf_7071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7071(t0,t1,t2);}

C_noret_decl(trf_6757)
static void C_fcall trf_6757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6757(t0,t1);}

C_noret_decl(trf_6991)
static void C_fcall trf_6991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6991(t0,t1);}

C_noret_decl(trf_6929)
static void C_fcall trf_6929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6929(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6929(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6565)
static void C_fcall trf_6565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6565(t0,t1);}

C_noret_decl(trf_6643)
static void C_fcall trf_6643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6643(t0,t1);}

C_noret_decl(trf_6390)
static void C_fcall trf_6390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6390(t0,t1);}

C_noret_decl(trf_6224)
static void C_fcall trf_6224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6224(t0,t1);}

C_noret_decl(trf_6221)
static void C_fcall trf_6221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6221(t0,t1);}

C_noret_decl(trf_5535)
static void C_fcall trf_5535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5535(t0,t1);}

C_noret_decl(trf_5698)
static void C_fcall trf_5698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5698(t0,t1,t2);}

C_noret_decl(trf_5724)
static void C_fcall trf_5724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5724(t0,t1);}

C_noret_decl(trf_5797)
static void C_fcall trf_5797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5797(t0,t1);}

C_noret_decl(trf_5588)
static void C_fcall trf_5588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5588(t0,t1);}

C_noret_decl(trf_5619)
static void C_fcall trf_5619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5619(t0,t1);}

C_noret_decl(trf_5650)
static void C_fcall trf_5650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5650(t0,t1);}

C_noret_decl(trf_5494)
static void C_fcall trf_5494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5494(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5494(t0,t1,t2);}

C_noret_decl(trf_5462)
static void C_fcall trf_5462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5462(t0,t1);}

C_noret_decl(trf_4757)
static void C_fcall trf_4757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4757(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4757(t0,t1,t2);}

C_noret_decl(trf_4785)
static void C_fcall trf_4785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4785(t0,t1);}

C_noret_decl(trf_4649)
static void C_fcall trf_4649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4649(t0,t1);}

C_noret_decl(trf_4524)
static void C_fcall trf_4524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4524(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4524(t0,t1,t2,t3);}

C_noret_decl(trf_4471)
static void C_fcall trf_4471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4471(t0,t1,t2);}

C_noret_decl(trf_4479)
static void C_fcall trf_4479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4479(t0,t1);}

C_noret_decl(trf_4424)
static void C_fcall trf_4424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4424(t0,t1);}

C_noret_decl(trf_4250)
static void C_fcall trf_4250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4250(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4250(t0,t1,t2);}

C_noret_decl(trf_4272)
static void C_fcall trf_4272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4272(t0,t1);}

C_noret_decl(trf_4279)
static void C_fcall trf_4279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4279(t0,t1);}

C_noret_decl(trf_4194)
static void C_fcall trf_4194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4194(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4194(t0,t1,t2,t3);}

C_noret_decl(trf_4062)
static void C_fcall trf_4062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4062(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4062(t0,t1,t2,t3);}

C_noret_decl(trf_4041)
static void C_fcall trf_4041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4041(t0,t1);}

C_noret_decl(trf_4001)
static void C_fcall trf_4001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4001(t0,t1,t2);}

C_noret_decl(trf_3926)
static void C_fcall trf_3926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3926(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5080)){
C_save(t1);
C_rereclaim2(5080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,498);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],12,"flush-output");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],6,"printf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[15]=C_h_intern(&lf[15],5,"force");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[20]=C_h_intern(&lf[20],25,"\010compilercompiler-warning");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],20,"\003syswarnings-enabled");
lf[25]=C_h_intern(&lf[25],4,"quit");
lf[26]=C_h_intern(&lf[26],4,"exit");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[28]=C_h_intern(&lf[28],21,"\003syssyntax-error-hook");
lf[29]=C_h_intern(&lf[29],16,"print-call-chain");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[34]=C_h_intern(&lf[34],12,"syntax-error");
lf[35]=C_h_intern(&lf[35],31,"\010compileremit-syntax-trace-info");
lf[36]=C_h_intern(&lf[36],9,"map-llist");
lf[37]=C_h_intern(&lf[37],24,"\010compilercheck-signature");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[39]=C_h_intern(&lf[39],18,"\010compilerreal-name");
lf[40]=C_h_intern(&lf[40],13,"\010compilerposq");
lf[41]=C_h_intern(&lf[41],18,"\010compilerstringify");
lf[42]=C_h_intern(&lf[42],14,"symbol->string");
lf[43]=C_h_intern(&lf[43],7,"sprintf");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[45]=C_h_intern(&lf[45],18,"\010compilersymbolify");
lf[46]=C_h_intern(&lf[46],14,"string->symbol");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[48]=C_h_intern(&lf[48],26,"\010compilerbuild-lambda-list");
lf[49]=C_h_intern(&lf[49],29,"\010compilerstring->c-identifier");
lf[50]=C_h_intern(&lf[50],24,"\003sysstring->c-identifier");
lf[51]=C_h_intern(&lf[51],21,"\010compilerc-ify-string");
lf[52]=C_h_intern(&lf[52],16,"\003syslist->string");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[54]=C_h_intern(&lf[54],6,"append");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[56]=C_h_intern(&lf[56],16,"\003sysstring->list");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[60]=C_h_intern(&lf[60],28,"\010compilervalid-c-identifier\077");
lf[61]=C_h_intern(&lf[61],3,"any");
lf[62]=C_h_intern(&lf[62],8,"->string");
lf[63]=C_h_intern(&lf[63],14,"\010compilerwords");
lf[64]=C_h_intern(&lf[64],21,"\010compilerwords->bytes");
lf[65]=C_h_intern(&lf[65],34,"\010compilercheck-and-open-input-file");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[67]=C_h_intern(&lf[67],18,"current-input-port");
lf[68]=C_h_intern(&lf[68],15,"open-input-file");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[71]=C_h_intern(&lf[71],12,"file-exists\077");
lf[72]=C_h_intern(&lf[72],33,"\010compilerclose-checked-input-file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[74]=C_h_intern(&lf[74],16,"close-input-port");
lf[75]=C_h_intern(&lf[75],19,"\010compilerfold-inner");
lf[76]=C_h_intern(&lf[76],7,"reverse");
lf[77]=C_h_intern(&lf[77],28,"\010compilerfollow-without-loop");
lf[78]=C_h_intern(&lf[78],21,"\010compilersort-symbols");
lf[79]=C_h_intern(&lf[79],8,"string<\077");
lf[80]=C_h_intern(&lf[80],4,"sort");
lf[81]=C_h_intern(&lf[81],18,"\010compilerconstant\077");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],29,"\010compilercollapsable-literal\077");
lf[84]=C_h_intern(&lf[84],19,"\010compilerimmediate\077");
lf[85]=C_h_intern(&lf[85],20,"\010compilerbig-fixnum\077");
lf[86]=C_h_intern(&lf[86],23,"\010compilerbasic-literal\077");
lf[87]=C_h_intern(&lf[87],5,"every");
lf[88]=C_h_intern(&lf[88],12,"vector->list");
lf[89]=C_h_intern(&lf[89],32,"\010compilercanonicalize-begin-body");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_h_intern(&lf[92],3,"let");
lf[93]=C_h_intern(&lf[93],6,"gensym");
lf[94]=C_h_intern(&lf[94],1,"t");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[96]=C_h_intern(&lf[96],21,"\010compilerstring->expr");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[99]=C_h_intern(&lf[99],5,"begin");
lf[100]=C_h_intern(&lf[100],10,"\003sysappend");
lf[101]=C_h_intern(&lf[101],4,"read");
lf[102]=C_h_intern(&lf[102],6,"unfold");
lf[103]=C_h_intern(&lf[103],11,"eof-object\077");
lf[104]=C_h_intern(&lf[104],6,"values");
lf[105]=C_h_intern(&lf[105],22,"with-input-from-string");
lf[106]=C_h_intern(&lf[106],22,"with-exception-handler");
lf[107]=C_h_intern(&lf[107],30,"call-with-current-continuation");
lf[108]=C_h_intern(&lf[108],30,"\010compilerdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],25,"\003sysdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],37,"\010compilerprocess-lambda-documentation");
lf[111]=C_h_intern(&lf[111],30,"\010compilerexpand-profile-lambda");
lf[112]=C_h_intern(&lf[112],29,"\010compilerprofile-lambda-index");
lf[113]=C_h_intern(&lf[113],28,"\010compilerprofile-lambda-list");
lf[114]=C_h_intern(&lf[114],33,"\010compilerprofile-info-vector-name");
lf[115]=C_h_intern(&lf[115],17,"\003sysprofile-entry");
lf[116]=C_h_intern(&lf[116],6,"lambda");
lf[117]=C_h_intern(&lf[117],5,"apply");
lf[118]=C_h_intern(&lf[118],16,"\003sysprofile-exit");
lf[119]=C_h_intern(&lf[119],16,"\003sysdynamic-wind");
lf[120]=C_h_intern(&lf[120],10,"alist-cons");
lf[121]=C_h_intern(&lf[121],37,"\010compilerinitialize-analysis-database");
lf[122]=C_h_intern(&lf[122],8,"\003sysput!");
lf[123]=C_h_intern(&lf[123],9,"\003syserror");
lf[124]=C_h_intern(&lf[124],18,"\010compilerintrinsic");
lf[125]=C_h_intern(&lf[125],8,"internal");
lf[126]=C_h_intern(&lf[126],26,"\010compilerinternal-bindings");
lf[127]=C_h_intern(&lf[127],35,"\010compilerfoldable-extended-bindings");
lf[128]=C_h_intern(&lf[128],13,"\010compilerput!");
lf[129]=C_h_intern(&lf[129],8,"foldable");
lf[130]=C_h_intern(&lf[130],8,"extended");
lf[131]=C_h_intern(&lf[131],17,"extended-bindings");
lf[132]=C_h_intern(&lf[132],35,"\010compilerfoldable-standard-bindings");
lf[133]=C_h_intern(&lf[133],41,"\010compilerside-effecting-standard-bindings");
lf[134]=C_h_intern(&lf[134],14,"side-effecting");
lf[135]=C_h_intern(&lf[135],8,"standard");
lf[136]=C_h_intern(&lf[136],17,"standard-bindings");
lf[137]=C_h_intern(&lf[137],12,"\010compilerget");
lf[138]=C_h_intern(&lf[138],18,"\003syshash-table-ref");
lf[139]=C_h_intern(&lf[139],16,"\010compilerget-all");
lf[140]=C_h_intern(&lf[140],10,"filter-map");
lf[141]=C_h_intern(&lf[141],19,"\003syshash-table-set!");
lf[142]=C_h_intern(&lf[142],17,"\010compilercollect!");
lf[143]=C_h_intern(&lf[143],15,"\010compilercount!");
lf[144]=C_h_intern(&lf[144],17,"\010compilerget-line");
lf[145]=C_h_intern(&lf[145],24,"\003sysline-number-database");
lf[146]=C_h_intern(&lf[146],19,"\010compilerget-line-2");
lf[147]=C_h_intern(&lf[147],30,"\010compilerfind-lambda-container");
lf[148]=C_h_intern(&lf[148],12,"contained-in");
lf[149]=C_h_intern(&lf[149],37,"\010compilerdisplay-line-number-database");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[151]=C_h_intern(&lf[151],7,"\003sysmap");
lf[152]=C_h_intern(&lf[152],3,"cdr");
lf[153]=C_h_intern(&lf[153],23,"\003syshash-table-for-each");
lf[154]=C_h_intern(&lf[154],34,"\010compilerdisplay-analysis-database");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\010\011lval=~s");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[160]=C_h_intern(&lf[160],7,"unknown");
lf[161]=C_h_intern(&lf[161],8,"captured");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[164]=C_h_intern(&lf[164],4,"caar");
lf[165]=C_h_intern(&lf[165],5,"value");
lf[166]=C_h_intern(&lf[166],4,"cdar");
lf[167]=C_h_intern(&lf[167],11,"local-value");
lf[168]=C_h_intern(&lf[168],15,"potential-value");
lf[169]=C_h_intern(&lf[169],10,"replacable");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[171]=C_h_intern(&lf[171],10,"references");
lf[172]=C_h_intern(&lf[172],10,"call-sites");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[174]=C_h_intern(&lf[174],4,"home");
lf[175]=C_h_intern(&lf[175],8,"contains");
lf[176]=C_h_intern(&lf[176],8,"use-expr");
lf[177]=C_h_intern(&lf[177],12,"closure-size");
lf[178]=C_h_intern(&lf[178],14,"rest-parameter");
lf[179]=C_h_intern(&lf[179],16,"o-r/access-count");
lf[180]=C_h_intern(&lf[180],18,"captured-variables");
lf[181]=C_h_intern(&lf[181],13,"explicit-rest");
lf[182]=C_h_intern(&lf[182],8,"assigned");
lf[183]=C_h_intern(&lf[183],5,"boxed");
lf[184]=C_h_intern(&lf[184],6,"global");
lf[185]=C_h_intern(&lf[185],12,"contractable");
lf[186]=C_h_intern(&lf[186],16,"standard-binding");
lf[187]=C_h_intern(&lf[187],16,"assigned-locally");
lf[188]=C_h_intern(&lf[188],11,"collapsable");
lf[189]=C_h_intern(&lf[189],9,"removable");
lf[190]=C_h_intern(&lf[190],9,"undefined");
lf[191]=C_h_intern(&lf[191],9,"replacing");
lf[192]=C_h_intern(&lf[192],6,"unused");
lf[193]=C_h_intern(&lf[193],6,"simple");
lf[194]=C_h_intern(&lf[194],9,"inlinable");
lf[195]=C_h_intern(&lf[195],13,"inline-export");
lf[196]=C_h_intern(&lf[196],21,"has-unused-parameters");
lf[197]=C_h_intern(&lf[197],16,"extended-binding");
lf[198]=C_h_intern(&lf[198],12,"customizable");
lf[199]=C_h_intern(&lf[199],8,"constant");
lf[200]=C_h_intern(&lf[200],10,"boxed-rest");
lf[201]=C_h_intern(&lf[201],11,"hidden-refs");
lf[202]=C_h_intern(&lf[202],5,"write");
lf[203]=C_h_intern(&lf[203],34,"\010compilerdefault-standard-bindings");
lf[204]=C_h_intern(&lf[204],34,"\010compilerdefault-extended-bindings");
lf[205]=C_h_intern(&lf[205],9,"make-node");
lf[206]=C_h_intern(&lf[206],4,"node");
lf[207]=C_h_intern(&lf[207],5,"node\077");
lf[208]=C_h_intern(&lf[208],15,"node-class-set!");
lf[209]=C_h_intern(&lf[209],14,"\003sysblock-set!");
lf[210]=C_h_intern(&lf[210],10,"node-class");
lf[211]=C_h_intern(&lf[211],20,"node-parameters-set!");
lf[212]=C_h_intern(&lf[212],15,"node-parameters");
lf[213]=C_h_intern(&lf[213],24,"node-subexpressions-set!");
lf[214]=C_h_intern(&lf[214],19,"node-subexpressions");
lf[215]=C_h_intern(&lf[215],16,"\010compilervarnode");
lf[216]=C_h_intern(&lf[216],13,"\004corevariable");
lf[217]=C_h_intern(&lf[217],14,"\010compilerqnode");
lf[218]=C_h_intern(&lf[218],25,"\010compilerbuild-node-graph");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[220]=C_h_intern(&lf[220],15,"\004coreglobal-ref");
lf[221]=C_h_intern(&lf[221],2,"if");
lf[222]=C_h_intern(&lf[222],14,"\004coreundefined");
lf[223]=C_h_intern(&lf[223],8,"truncate");
lf[224]=C_h_intern(&lf[224],4,"type");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[226]=C_h_intern(&lf[226],6,"fixnum");
lf[227]=C_h_intern(&lf[227],11,"number-type");
lf[228]=C_h_intern(&lf[228],6,"unzip1");
lf[229]=C_h_intern(&lf[229],11,"\004corelambda");
lf[230]=C_h_intern(&lf[230],14,"\004coreprimitive");
lf[231]=C_h_intern(&lf[231],11,"\004coreinline");
lf[232]=C_h_intern(&lf[232],13,"\004corecallunit");
lf[233]=C_h_intern(&lf[233],9,"\004coreproc");
lf[234]=C_h_intern(&lf[234],4,"set!");
lf[235]=C_h_intern(&lf[235],9,"\004coreset!");
lf[236]=C_h_intern(&lf[236],29,"\004coreforeign-callback-wrapper");
lf[237]=C_h_intern(&lf[237],5,"sixth");
lf[238]=C_h_intern(&lf[238],5,"fifth");
lf[239]=C_h_intern(&lf[239],20,"\004coreinline_allocate");
lf[240]=C_h_intern(&lf[240],8,"\004coreapp");
lf[241]=C_h_intern(&lf[241],9,"\004corecall");
lf[242]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[243]=C_h_intern(&lf[243],24,"\010compilersource-filename");
lf[244]=C_h_intern(&lf[244],28,"\003syssymbol->qualified-string");
lf[245]=C_h_intern(&lf[245],7,"\003sysget");
lf[246]=C_h_intern(&lf[246],34,"\010compileralways-bound-to-procedure");
lf[247]=C_h_intern(&lf[247],15,"\004coreinline_ref");
lf[248]=C_h_intern(&lf[248],18,"\004coreinline_update");
lf[249]=C_h_intern(&lf[249],19,"\004coreinline_loc_ref");
lf[250]=C_h_intern(&lf[250],22,"\004coreinline_loc_update");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[252]=C_h_intern(&lf[252],1,"o");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[254]=C_h_intern(&lf[254],30,"\010compilerbuild-expression-tree");
lf[255]=C_h_intern(&lf[255],12,"\004coreclosure");
lf[256]=C_h_intern(&lf[256],4,"last");
lf[257]=C_h_intern(&lf[257],3,"map");
lf[258]=C_h_intern(&lf[258],4,"list");
lf[259]=C_h_intern(&lf[259],7,"butlast");
lf[260]=C_h_intern(&lf[260],5,"cons*");
lf[261]=C_h_intern(&lf[261],9,"\004corebind");
lf[262]=C_h_intern(&lf[262],10,"\004coreunbox");
lf[263]=C_h_intern(&lf[263],8,"\004coreref");
lf[264]=C_h_intern(&lf[264],11,"\004coreupdate");
lf[265]=C_h_intern(&lf[265],13,"\004coreupdate_i");
lf[266]=C_h_intern(&lf[266],8,"\004corebox");
lf[267]=C_h_intern(&lf[267],9,"\004corecond");
lf[268]=C_h_intern(&lf[268],21,"\010compilerfold-boolean");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[270]=C_h_intern(&lf[270],31,"\010compilerinline-lambda-bindings");
lf[271]=C_h_intern(&lf[271],8,"split-at");
lf[272]=C_h_intern(&lf[272],10,"fold-right");
lf[273]=C_h_intern(&lf[273],4,"take");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[275]=C_h_intern(&lf[275],34,"\010compilercopy-node-tree-and-rename");
lf[276]=C_h_intern(&lf[276],9,"alist-ref");
lf[277]=C_h_intern(&lf[277],3,"eq\077");
lf[278]=C_h_intern(&lf[278],1,"f");
lf[279]=C_h_intern(&lf[279],18,"\010compilertree-copy");
lf[280]=C_h_intern(&lf[280],4,"cons");
lf[281]=C_h_intern(&lf[281],19,"\010compilercopy-node!");
lf[282]=C_h_intern(&lf[282],20,"\010compilernode->sexpr");
lf[283]=C_h_intern(&lf[283],20,"\010compilersexpr->node");
lf[284]=C_h_intern(&lf[284],32,"\010compileremit-global-inline-file");
lf[285]=C_h_intern(&lf[285],5,"print");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[287]=C_h_intern(&lf[287],1,"i");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[290]=C_h_intern(&lf[290],2,"pp");
lf[291]=C_h_intern(&lf[291],3,"yes");
lf[292]=C_h_intern(&lf[292],2,"no");
lf[293]=C_h_intern(&lf[293],24,"\010compilerinline-max-size");
lf[294]=C_h_intern(&lf[294],15,"\010compilerinline");
lf[295]=C_h_intern(&lf[295],22,"\010compilerinline-global");
lf[296]=C_h_intern(&lf[296],26,"\010compilervariable-visible\077");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[300]=C_h_intern(&lf[300],15,"chicken-version");
lf[301]=C_h_intern(&lf[301],19,"with-output-to-file");
lf[302]=C_h_intern(&lf[302],25,"\010compilerload-inline-file");
lf[303]=C_h_intern(&lf[303],20,"with-input-from-file");
lf[304]=C_h_intern(&lf[304],19,"\010compilermatch-node");
lf[305]=C_h_intern(&lf[305],1,"a");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[307]=C_h_intern(&lf[307],37,"\010compilerexpression-has-side-effects\077");
lf[308]=C_h_intern(&lf[308],24,"foreign-callback-stub-id");
lf[309]=C_h_intern(&lf[309],4,"find");
lf[310]=C_h_intern(&lf[310],22,"foreign-callback-stubs");
lf[311]=C_h_intern(&lf[311],28,"\010compilersimple-lambda-node\077");
lf[312]=C_h_intern(&lf[312],31,"\010compilerdump-undefined-globals");
lf[313]=C_h_intern(&lf[313],28,"\003systoplevel-definition-hook");
lf[314]=C_h_intern(&lf[314],22,"\010compilerhide-variable");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[316]=C_h_intern(&lf[316],36,"\010compilercompute-database-statistics");
lf[317]=C_h_intern(&lf[317],29,"\010compilercurrent-program-size");
lf[318]=C_h_intern(&lf[318],30,"\010compileroriginal-program-size");
lf[319]=C_h_intern(&lf[319],33,"\010compilerprint-program-statistics");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[326]=C_h_intern(&lf[326],1,"s");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[328]=C_h_intern(&lf[328],35,"\010compilerpprint-expressions-to-file");
lf[329]=C_h_intern(&lf[329],17,"close-output-port");
lf[330]=C_h_intern(&lf[330],12,"pretty-print");
lf[331]=C_h_intern(&lf[331],19,"with-output-to-port");
lf[332]=C_h_intern(&lf[332],16,"open-output-file");
lf[333]=C_h_intern(&lf[333],19,"current-output-port");
lf[334]=C_h_intern(&lf[334],27,"\010compilerforeign-type-check");
lf[335]=C_h_intern(&lf[335],4,"char");
lf[336]=C_h_intern(&lf[336],13,"unsigned-char");
lf[337]=C_h_intern(&lf[337],6,"unsafe");
lf[338]=C_h_intern(&lf[338],25,"\003sysforeign-char-argument");
lf[339]=C_h_intern(&lf[339],3,"int");
lf[340]=C_h_intern(&lf[340],27,"\003sysforeign-fixnum-argument");
lf[341]=C_h_intern(&lf[341],5,"float");
lf[342]=C_h_intern(&lf[342],27,"\003sysforeign-flonum-argument");
lf[343]=C_h_intern(&lf[343],7,"pointer");
lf[344]=C_h_intern(&lf[344],26,"\003sysforeign-block-argument");
lf[345]=C_h_intern(&lf[345],15,"nonnull-pointer");
lf[346]=C_h_intern(&lf[346],8,"u8vector");
lf[347]=C_h_intern(&lf[347],34,"\003sysforeign-number-vector-argument");
lf[348]=C_h_intern(&lf[348],16,"nonnull-u8vector");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[350]=C_h_intern(&lf[350],7,"integer");
lf[351]=C_h_intern(&lf[351],28,"\003sysforeign-integer-argument");
lf[352]=C_h_intern(&lf[352],16,"unsigned-integer");
lf[353]=C_h_intern(&lf[353],37,"\003sysforeign-unsigned-integer-argument");
lf[354]=C_h_intern(&lf[354],9,"c-pointer");
lf[355]=C_h_intern(&lf[355],28,"\003sysforeign-pointer-argument");
lf[356]=C_h_intern(&lf[356],17,"nonnull-c-pointer");
lf[357]=C_h_intern(&lf[357],8,"c-string");
lf[358]=C_h_intern(&lf[358],17,"\003sysmake-c-string");
lf[359]=C_h_intern(&lf[359],27,"\003sysforeign-string-argument");
lf[360]=C_h_intern(&lf[360],16,"nonnull-c-string");
lf[361]=C_h_intern(&lf[361],6,"symbol");
lf[362]=C_h_intern(&lf[362],18,"\003syssymbol->string");
lf[363]=C_h_intern(&lf[363],3,"ref");
lf[364]=C_h_intern(&lf[364],8,"instance");
lf[365]=C_h_intern(&lf[365],12,"instance-ref");
lf[366]=C_h_intern(&lf[366],4,"this");
lf[367]=C_h_intern(&lf[367],8,"slot-ref");
lf[368]=C_h_intern(&lf[368],16,"nonnull-instance");
lf[369]=C_h_intern(&lf[369],5,"const");
lf[370]=C_h_intern(&lf[370],4,"enum");
lf[371]=C_h_intern(&lf[371],8,"function");
lf[372]=C_h_intern(&lf[372],27,"\010compilerforeign-type-table");
lf[373]=C_h_intern(&lf[373],17,"nonnull-c-string*");
lf[374]=C_h_intern(&lf[374],26,"nonnull-unsigned-c-string*");
lf[375]=C_h_intern(&lf[375],9,"c-string*");
lf[376]=C_h_intern(&lf[376],18,"unsigned-c-string*");
lf[377]=C_h_intern(&lf[377],13,"c-string-list");
lf[378]=C_h_intern(&lf[378],14,"c-string-list*");
lf[379]=C_h_intern(&lf[379],18,"unsigned-integer32");
lf[380]=C_h_intern(&lf[380],13,"unsigned-long");
lf[381]=C_h_intern(&lf[381],4,"long");
lf[382]=C_h_intern(&lf[382],9,"integer32");
lf[383]=C_h_intern(&lf[383],17,"nonnull-u16vector");
lf[384]=C_h_intern(&lf[384],16,"nonnull-s8vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-s16vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-u32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-s32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f32vector");
lf[389]=C_h_intern(&lf[389],17,"nonnull-f64vector");
lf[390]=C_h_intern(&lf[390],9,"u16vector");
lf[391]=C_h_intern(&lf[391],8,"s8vector");
lf[392]=C_h_intern(&lf[392],9,"s16vector");
lf[393]=C_h_intern(&lf[393],9,"u32vector");
lf[394]=C_h_intern(&lf[394],9,"s32vector");
lf[395]=C_h_intern(&lf[395],9,"f32vector");
lf[396]=C_h_intern(&lf[396],9,"f64vector");
lf[397]=C_h_intern(&lf[397],22,"nonnull-scheme-pointer");
lf[398]=C_h_intern(&lf[398],12,"nonnull-blob");
lf[399]=C_h_intern(&lf[399],19,"nonnull-byte-vector");
lf[400]=C_h_intern(&lf[400],11,"byte-vector");
lf[401]=C_h_intern(&lf[401],4,"blob");
lf[402]=C_h_intern(&lf[402],14,"scheme-pointer");
lf[403]=C_h_intern(&lf[403],6,"double");
lf[404]=C_h_intern(&lf[404],6,"number");
lf[405]=C_h_intern(&lf[405],12,"unsigned-int");
lf[406]=C_h_intern(&lf[406],5,"short");
lf[407]=C_h_intern(&lf[407],14,"unsigned-short");
lf[408]=C_h_intern(&lf[408],4,"byte");
lf[409]=C_h_intern(&lf[409],13,"unsigned-byte");
lf[410]=C_h_intern(&lf[410],5,"int32");
lf[411]=C_h_intern(&lf[411],14,"unsigned-int32");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[413]=C_h_intern(&lf[413],36,"\010compilerforeign-type-convert-result");
lf[414]=C_h_intern(&lf[414],38,"\010compilerforeign-type-convert-argument");
lf[415]=C_h_intern(&lf[415],27,"\010compilerfinal-foreign-type");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[417]=C_h_intern(&lf[417],37,"\010compilerestimate-foreign-result-size");
lf[418]=C_h_intern(&lf[418],9,"integer64");
lf[419]=C_h_intern(&lf[419],4,"bool");
lf[420]=C_h_intern(&lf[420],4,"void");
lf[421]=C_h_intern(&lf[421],13,"scheme-object");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[423]=C_h_intern(&lf[423],46,"\010compilerestimate-foreign-result-location-size");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[426]=C_h_intern(&lf[426],30,"\010compilerfinish-foreign-result");
lf[427]=C_h_intern(&lf[427],17,"\003syspeek-c-string");
lf[428]=C_h_intern(&lf[428],25,"\003syspeek-nonnull-c-string");
lf[429]=C_h_intern(&lf[429],26,"\003syspeek-and-free-c-string");
lf[430]=C_h_intern(&lf[430],34,"\003syspeek-and-free-nonnull-c-string");
lf[431]=C_h_intern(&lf[431],17,"\003sysintern-symbol");
lf[432]=C_h_intern(&lf[432],22,"\003syspeek-c-string-list");
lf[433]=C_h_intern(&lf[433],31,"\003syspeek-and-free-c-string-list");
lf[434]=C_h_intern(&lf[434],35,"\010tinyclosmake-instance-from-pointer");
lf[435]=C_h_intern(&lf[435],4,"make");
lf[436]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-used-variables");
lf[438]=C_h_intern(&lf[438],28,"\010compilerscan-free-variables");
lf[439]=C_h_intern(&lf[439],11,"lset-adjoin");
lf[440]=C_h_intern(&lf[440],25,"\010compilertopological-sort");
lf[441]=C_h_intern(&lf[441],7,"colored");
lf[442]=C_h_intern(&lf[442],23,"\010compilerchop-separator");
lf[443]=C_h_intern(&lf[443],9,"substring");
lf[444]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[445]=C_h_intern(&lf[445],23,"\010compilerchop-extension");
lf[446]=C_h_intern(&lf[446],22,"\010compilerprint-version");
lf[447]=C_h_intern(&lf[447],6,"print*");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000:(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[449]=C_h_intern(&lf[449],20,"\010compilerprint-usage");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\022\337Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012\012  File and pathname opti"
"ons:\012\012    -output-file FILENAME       specifies output-filename, default is \047out"
".c\047\012    -include-path PATHNAME      specifies alternative path for included file"
"s\012    -to-stdout                  write compiled file to stdout instead of file\012"
"\012  Language options:\012\012    -feature SYMBOL             register feature identifie"
"r\012\012  Syntax related options:\012\012    -case-insensitive           don\047t preserve cas"
"e of read symbols\012    -keyword-style STYLE        allow alternative keyword synt"
"ax (none, prefix or suffix)\012    -compile-syntax             macros are made avai"
"lable at run-time\012    -emit-import-library MODULE write compile-time module info"
"rmation into separate file\012\012  Translation options:\012\012    -explicit-use           "
"    do not use units \047library\047 and \047eval\047 by default\012    -check-syntax          "
"     stop compilation after macro-expansion\012    -analyze-only               stop"
" compilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings  "
"              disable warnings\012    -disable-warning CLASS      disable specific "
"class of warnings\012    -debug-level NUMBER         set level of available debuggi"
"ng information\012    -no-trace                   disable tracing information\012    -"
"profile                    executable emits profiling information \012    -profile-"
"name FILENAME      name of the generated profile information file\012    -accumulat"
"e-profile         executable emits profiling information in append mode\012    -no-"
"lambda-info             omit additional procedure-information\012\012  Optimization op"
"tions:\012\012    -optimize-level NUMBER      enable certain sets of optimization opti"
"ons\012    -optimize-leaf-routines     enable leaf routine optimization\012    -lambda"
"-lift                enable lambda-lifting\012    -no-usual-integrations      stand"
"ard procedures may be redefined\012    -unsafe                     disable safety c"
"hecks\012    -local                      assume globals are only modified in curren"
"t file\012    -block                      enable block-compilation\012    -disable-int"
"errupts         disable interrupts in compiled code\012    -fixnum-arithmetic      "
"    assume all numbers are fixnums\012    -benchmark-mode             equivalent to"
" \047-block -optimize-level 4\012                                 -debug-level 0 -fixn"
"um-arithmetic -lambda-lift \012                                 -disable-interrupts"
" -inline\047\012    -disable-stack-overflow-checks  \012                                d"
"isables detection of stack-overflows.\012    -inline                     enable inl"
"ining\012    -inline-limit               set inlining threshold\012    -inline-global "
"             enable cross-module inlining\012    -emit-inline-file FILENAME  genera"
"te file with globally inlinable procedures\012                                (impl"
"ies -inline -local)\012\012  Configuration options:\012\012    -unit NAME                  c"
"ompile file as a library unit\012    -uses NAME                  declare library un"
"it as used.\012    -heap-size NUMBER           specifies heap-size of compiled exec"
"utable\012    -heap-initial-size NUMBER   specifies heap-size at startup time\012    -"
"heap-growth PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shr"
"inkage PERCENTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER"
"\012    -stack-size NUMBER          specifies nursery size of compiled executable\012 "
"   -extend FILENAME            load file before compilation commences\012    -prelu"
"de EXPRESSION         add expression to front of source file\012    -postlude EXPRE"
"SSION        add expression to end of source file\012    -prologue FILENAME        "
"  include file before main source file\012    -epilogue FILENAME          include f"
"ile after main source file\012    -dynamic                    compile as dynamicall"
"y loadable code\012    -require-extension NAME     require and import extension NAM"
"E\012    -extension                  compile as extension (dynamic or static)\012    -"
"ignore-repository          do not refer to repository for extensions\012\012  Obscure "
"options:\012\012    -debug MODES                display debugging output for the given"
" modes\012    -unsafe-libraries           marks the generated file as being linked\012"
"                                with the unsafe runtime system\012    -raw         "
"               do not generate implicit init- and exit code\011\011\011       \012    -emit-"
"external-prototypes-first  emit protoypes for callbacks before foreign\012         "
"                       declarations\012");
lf[451]=C_h_intern(&lf[451],36,"\010compilermake-block-variable-literal");
lf[452]=C_h_intern(&lf[452],22,"block-variable-literal");
lf[453]=C_h_intern(&lf[453],32,"\010compilerblock-variable-literal\077");
lf[454]=C_h_intern(&lf[454],36,"\010compilerblock-variable-literal-name");
lf[455]=C_h_intern(&lf[455],25,"\010compilermake-random-name");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[457]=C_h_intern(&lf[457],6,"random");
lf[458]=C_h_intern(&lf[458],15,"current-seconds");
lf[459]=C_h_intern(&lf[459],23,"\010compilerset-real-name!");
lf[460]=C_h_intern(&lf[460],24,"\010compilerreal-name-table");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[462]=C_h_intern(&lf[462],19,"\010compilerreal-name2");
lf[463]=C_h_intern(&lf[463],32,"\010compilerdisplay-real-name-table");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[465]=C_h_intern(&lf[465],28,"\010compilersource-info->string");
lf[466]=C_h_intern(&lf[466],4,"conc");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[469]=C_h_intern(&lf[469],11,"make-string");
lf[470]=C_h_intern(&lf[470],3,"max");
lf[471]=C_h_intern(&lf[471],12,"string-null\077");
lf[472]=C_h_intern(&lf[472],19,"\010compilerdump-nodes");
lf[473]=C_h_intern(&lf[473],19,"\003syswrite-char/port");
lf[474]=C_h_intern(&lf[474],19,"\003sysstandard-output");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[478]=C_h_intern(&lf[478],18,"\003sysuser-read-hook");
lf[479]=C_h_intern(&lf[479],15,"foreign-declare");
lf[480]=C_h_intern(&lf[480],7,"declare");
lf[481]=C_h_intern(&lf[481],34,"\010compilerscan-sharp-greater-string");
lf[482]=C_h_intern(&lf[482],18,"\003sysread-char/port");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[484]=C_h_intern(&lf[484],17,"get-output-string");
lf[485]=C_h_intern(&lf[485],18,"open-output-string");
lf[486]=C_h_intern(&lf[486],19,"\010compilervisibility");
lf[487]=C_h_intern(&lf[487],6,"hidden");
lf[488]=C_h_intern(&lf[488],24,"\010compilerexport-variable");
lf[489]=C_h_intern(&lf[489],8,"exported");
lf[490]=C_h_intern(&lf[490],26,"\010compilerblock-compilation");
lf[491]=C_h_intern(&lf[491],22,"\010compilermark-variable");
lf[492]=C_h_intern(&lf[492],22,"\010compilervariable-mark");
lf[493]=C_h_intern(&lf[493],19,"\010compilerintrinsic\077");
lf[494]=C_h_intern(&lf[494],27,"condition-property-accessor");
lf[495]=C_h_intern(&lf[495],3,"exn");
lf[496]=C_h_intern(&lf[496],7,"message");
lf[497]=C_h_intern(&lf[497],19,"condition-predicate");
C_register_lf2(lf,498,create_ptable());
t2=C_mutate(&lf[0] /* (set! c655 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3828,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3826 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3829 in k3826 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3832 in k3829 in k3826 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3847,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3852,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3879,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[20]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3919,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3948,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[28]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3967,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[34]+1 /* (set! syntax-error ...) */,C_retrieve(lf[28]));
t11=C_mutate((C_word*)lf[35]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3992,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[36]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3995,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[37]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4038,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[40]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4106,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4142,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[45]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4163,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[48]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4188,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[49]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[50]));
t19=C_mutate((C_word*)lf[51]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4232,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[60]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4326,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[63]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4382,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[64]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4389,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[65]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4396,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[72]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4443,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[75]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4455,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[77]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4518,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4549,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4569,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[83]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4615,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[84]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4645,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[86]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4691,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[89]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4751,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 287  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[497]))(3,*((C_word*)lf[497]+1),t33,lf[495]);}

/* k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 288  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[494]))(4,*((C_word*)lf[494]+1),t2,lf[495],lf[496]);}

/* k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word ab[165],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4851,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[108]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[109]));
t4=C_mutate((C_word*)lf[110]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4959,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4962,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_TRUE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[121]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5103,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[137]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5251,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[139]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5269,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[128]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5287,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[142]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5333,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[143]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5385,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[144]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5442,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[146]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5452,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[147]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5488,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[149]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5512,tmp=(C_word)a,a+=2,tmp));
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_mutate((C_word*)lf[154]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5531,a[2]=t19,tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[205]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6021,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[207]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6027,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[208]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6033,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[210]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6042,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[211]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6051,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[212]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6060,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[213]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6069,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[214]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6078,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[205]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6087,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[215]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6093,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[217]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6108,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[218]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6123,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[254]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6732,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[268]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7065,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[270]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7119,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[275]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7232,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[279]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7453,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[281]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7487,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[282]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7564,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[283]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7615,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[284]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7648,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[302]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7850,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[304]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7919,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[307]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8139,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[311]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8240,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[312]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8362,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[313]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8393,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[316]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8414,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[319]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8500,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[328]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8539,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[334]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8575,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[413]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9622,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[414]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9653,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[415]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9684,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[417]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9724,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[423]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10043,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[426]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10353,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[437]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10645,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[438]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10738,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[440]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10925,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[442]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11122,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[445]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11151,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[446]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11193,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[449]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11231,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[451]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11243,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[453]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11249,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[454]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11255,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[455]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11264,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[459]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11308,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[39]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11314,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[462]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11393,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[463]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11405,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[465]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11417,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[471]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11463,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[472]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11469,tmp=(C_word)a,a+=2,tmp));
t76=C_retrieve(lf[478]);
t77=C_mutate((C_word*)lf[478]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11571,a[2]=t76,tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[481]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11604,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[85]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11673,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[314]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11697,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[488]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11730,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[296]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11763,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[491]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11784,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[492]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11812,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[493]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11818,tmp=(C_word)a,a+=2,tmp));
t86=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t86+1)))(2,t86,C_SCHEME_UNDEFINED);}

/* ##compiler#intrinsic? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11818,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11823,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[124]);}

/* f_11823 in ##compiler#intrinsic? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11823,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t1,t2,t3);}

/* ##compiler#variable-mark in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11812,4,t0,t1,t2,t3);}
/* support.scm: 1480 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11784r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11784r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11784r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11788,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11788(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11788(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11786 in ##compiler#mark-variable in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1477 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11763,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11767,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1470 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t3,t2,lf[486]);}

/* k11765 in ##compiler#variable-visible? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[487]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[489]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[490]))));}}

/* ##compiler#export-variable in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11730,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11735,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[486],lf[489]);}

/* f_11735 in ##compiler#export-variable in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11735r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11735r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11735r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11739,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11739(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11739(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11737 */
static void C_ccall f_11739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#hide-variable in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11697,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11702,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[486],lf[487]);}

/* f_11702 in ##compiler#hide-variable in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11702r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11702r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11702r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11706,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11706(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11706(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11704 */
static void C_ccall f_11706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#big-fixnum? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11673,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11604,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11608,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1432 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[485]))(2,*((C_word*)lf[485]+1),t3);}

/* k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11608,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11613,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11613(t5,((C_word*)t0)[2]);}

/* loop in k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11613,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11615 in loop in k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11617,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1435 quit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[5],lf[483]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11635,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1437 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11647,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11668,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11666 in k11615 in loop in k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1449 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11613(t2,((C_word*)t0)[2]);}

/* k11645 in k11615 in loop in k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11647,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1442 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[484]))(3,*((C_word*)lf[484]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11659,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11657 in k11645 in k11615 in loop in k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11660 in k11657 in k11645 in k11615 in loop in k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1446 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11613(t2,((C_word*)t0)[2]);}

/* k11633 in k11615 in loop in k11606 in ##compiler#scan-sharp-greater-string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1438 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11613(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11571,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11581,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1429 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k11579 in ##sys#user-read-hook in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11584,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1427 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[481]))(3,*((C_word*)lf[481]+1),t2,((C_word*)t0)[2]);}

/* k11582 in k11579 in ##sys#user-read-hook in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11584,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[479],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[480],t4));}

/* ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11469,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11473,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11478,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11478(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11478(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11478,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11482,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11565,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_11565 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11565,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11485,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11560,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_11560 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11560,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11488,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11555,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11555 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11555,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1405 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[469]+1)))(4,*((C_word*)lf[469]+1),t2,((C_word*)t0)[7],C_make_character(32));}

/* k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11491,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11497,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1407 printf */
((C_proc6)C_retrieve_symbol_proc(lf[13]))(6,*((C_word*)lf[13]+1),t3,lf[477],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11500,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11549 in k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11550,3,t0,t1,t2);}
/* loop3507 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11478(t3,t1,((C_word*)t0)[2],t2);}

/* k11498 in k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11500,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11515,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1411 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t4,lf[476],t5);}
else{
t4=t3;
f_11506(2,t4,C_SCHEME_UNDEFINED);}}

/* k11513 in k11498 in k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11518,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11523,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11523(t6,t2,C_fix(5));}

/* doloop3537 in k11513 in k11498 in k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11523(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11523,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11533,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1414 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,lf[475],t4);}}

/* k11531 in doloop3537 in k11513 in k11498 in k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11523(t3,((C_word*)t0)[2],t2);}

/* k11516 in k11513 in k11498 in k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[474]+1));}

/* k11504 in k11498 in k11495 in k11489 in k11486 in k11483 in k11480 in loop in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[474]+1));}

/* k11471 in ##compiler#dump-nodes in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1417 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* string-null? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11463,3,t0,t1,t2);}
/* support.scm: 1395 string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[471]))(3,*((C_word*)lf[471]+1),t1,t2);}

/* ##compiler#source-info->string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11417,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11436,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1388 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1390 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11434 in ##compiler#source-info->string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11443,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1389 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[470]+1)))(4,*((C_word*)lf[470]+1),t3,C_fix(0),t5);}

/* k11445 in k11434 in ##compiler#source-info->string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1389 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[469]+1)))(4,*((C_word*)lf[469]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k11441 in k11434 in ##compiler#source-info->string in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1389 conc */
((C_proc8)C_retrieve_symbol_proc(lf[466]))(8,*((C_word*)lf[466]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[467],((C_word*)t0)[3],t1,lf[468],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11411,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1378 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t1,t2,C_retrieve(lf[460]));}

/* a11410 in ##compiler#display-real-name-table in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11411,4,t0,t1,t2,t3);}
/* support.scm: 1380 printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t1,lf[464],t2,t3);}

/* ##compiler#real-name2 in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11393,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11397,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1374 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t4,C_retrieve(lf[460]),t2);}

/* k11395 in ##compiler#real-name2 in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1375 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11314(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11314r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11314r(t0,t1,t2,t3);}}

static void C_ccall f_11314r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11317,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11333,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1358 resolve */
f_11317(t5,t2);}

/* k11331 in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11333,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1362 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[244]))(3,*((C_word*)lf[244]+1),t4,t1);}
else{
/* support.scm: 1371 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[244]))(3,*((C_word*)lf[244]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1359 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[244]))(3,*((C_word*)lf[244]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11356 in k11331 in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11362,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1363 get */
((C_proc5)C_retrieve_symbol_proc(lf[137]))(5,*((C_word*)lf[137]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[148]);}

/* k11360 in k11356 in k11331 in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11362,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11364,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11364(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11360 in k11356 in k11331 in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11364(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11364,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1365 resolve */
f_11317(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11369 in loop in k11360 in k11356 in k11331 in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11371,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11384,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1368 sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),t3,lf[461],((C_word*)t0)[4],t1);}}

/* k11382 in k11369 in loop in k11360 in k11356 in k11331 in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11388,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1369 get */
((C_proc5)C_retrieve_symbol_proc(lf[137]))(5,*((C_word*)lf[137]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[148]);}

/* k11386 in k11382 in k11369 in loop in k11360 in k11356 in k11331 in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1368 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11364(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11317(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11317,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11321,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1353 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t3,C_retrieve(lf[460]),t2);}

/* k11319 in resolve in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11321,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11327,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1355 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t2,C_retrieve(lf[460]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11325 in k11319 in resolve in ##compiler#real-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11308,4,t0,t1,t2,t3);}
/* support.scm: 1349 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t1,C_retrieve(lf[460]),t2,t3);}

/* ##compiler#make-random-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11264(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_11264r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11264r(t0,t1,t2);}}

static void C_ccall f_11264r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11272,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11276,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1336 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11276(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k11274 in ##compiler#make-random-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11280,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1337 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[458]))(2,*((C_word*)lf[458]+1),t2);}

/* k11278 in k11274 in ##compiler#make-random-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11284,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1338 random */
((C_proc3)C_retrieve_symbol_proc(lf[457]))(3,*((C_word*)lf[457]+1),t2,C_fix(1000));}

/* k11282 in k11278 in k11274 in ##compiler#make-random-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1335 sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[43]))(6,*((C_word*)lf[43]+1),((C_word*)t0)[4],lf[456],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11270 in ##compiler#make-random-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1334 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11255,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[452]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11249,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[452]));}

/* ##compiler#make-block-variable-literal in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11243,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[452],t2));}

/* ##compiler#print-usage in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11235,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1219 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[446]))(2,*((C_word*)lf[446]+1),t2);}

/* k11233 in ##compiler#print-usage in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1220 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k11236 in k11233 in ##compiler#print-usage in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1221 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[450]);}

/* ##compiler#print-version in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11193(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_11193r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11193r(t0,t1,t2);}}

static void C_ccall f_11193r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11197,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_11197(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_11197(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k11195 in ##compiler#print-version in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11200,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1215 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[447]+1)))(3,*((C_word*)lf[447]+1),t2,lf[448]);}
else{
t3=t2;
f_11200(2,t3,C_SCHEME_UNDEFINED);}}

/* k11198 in k11195 in ##compiler#print-version in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1216 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t2,C_SCHEME_TRUE);}

/* k11205 in k11198 in k11195 in ##compiler#print-version in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1216 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[285]+1)))(3,*((C_word*)lf[285]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11151,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11160,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11160(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11160,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1208 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[443]+1)))(5,*((C_word*)lf[443]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1209 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11122,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11132,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_11132(t7,(C_word)C_i_memq(t6,lf[444]));}
else{
t6=t5;
f_11132(t6,C_SCHEME_FALSE);}}

/* k11130 in ##compiler#chop-separator in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1201 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[443]+1)))(5,*((C_word*)lf[443]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10925,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10934,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10981,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11016,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11053,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11104,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a11103 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11104,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1183 insert */
t5=((C_word*)t0)[2];
f_10934(t5,t1,t3,t4);}

/* k11051 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11098,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1186 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t3,((C_word*)t0)[2]);}

/* k11096 in k11051 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11102,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1186 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t2,((C_word*)t0)[2]);}

/* k11100 in k11096 in k11051 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1186 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11016(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11054 in k11051 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11059,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a11060 in k11054 in k11051 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11061,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11065,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1188 lookup */
t5=((C_word*)t0)[2];
f_10981(t5,t3,t4);}

/* k11063 in a11060 in k11054 in k11051 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[441]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1190 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11016(t5,((C_word*)t0)[4],t3,t4);}}

/* k11057 in k11054 in k11051 in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_11016(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11016,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11020,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1171 insert */
t5=((C_word*)t0)[2];
f_10934(t5,t4,t2,lf[441]);}

/* k11018 in visit in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11023,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11028 in k11018 in visit in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11029,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11033,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1174 lookup */
t4=((C_word*)t0)[2];
f_10981(t4,t3,t2);}

/* k11031 in a11028 in k11018 in visit in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[441]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1176 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11016(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k11021 in k11018 in visit in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11023,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10981,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10987,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10987(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10987(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10987,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11000,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11014,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1166 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t4,t2);}}

/* k11012 in loop in lookup in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1166 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10998 in loop in lookup in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_11000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1166 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1167 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10987(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10934(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10934,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10940,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10940(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10940,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10979,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1160 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t4,t2);}}

/* k10977 in loop in insert in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1160 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10959 in loop in insert in ##compiler#topological-sort in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1161 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10940(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10738,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10741,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10907,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10920,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1143 walk */
t14=((C_word*)t8)[1];
f_10741(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10918 in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1144 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10907(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10907,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10913,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10912 in walkeach in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10913,3,t0,t1,t2);}
/* support.scm: 1141 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10741(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10741(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10741,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10745,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10901,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10901 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10901,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10896,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10896 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10896,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10891,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10891 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10891,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10751,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[82]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_10760(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[222]);
if(C_truep(t4)){
t5=t3;
f_10760(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[230]);
if(C_truep(t5)){
t6=t3;
f_10760(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[233]);
t7=t3;
f_10760(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[247])));}}}}

/* k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10760,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[216]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10779,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1123 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t4,*((C_word*)lf[277]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[234]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10801,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10801(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10815,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1128 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t6,*((C_word*)lf[277]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[92]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10824,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1131 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10741(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[229]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10854,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1134 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1138 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10907(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10853 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10854,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10866,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1137 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t6,t2,((C_word*)t0)[2]);}

/* k10864 in a10853 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1137 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10741(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10822 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10824,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10835,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1132 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10833 in k10822 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1132 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10741(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10813 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10801(t3,t2);}

/* k10799 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1129 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10741(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10777 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10779,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1124 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[296]))(3,*((C_word*)lf[296]+1),t3,((C_word*)t0)[2]);}

/* k10783 in k10777 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10785,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10789,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1125 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t2,*((C_word*)lf[277]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10787 in k10783 in k10777 in k10758 in k10749 in k10746 in k10743 in walk in ##compiler#scan-free-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10645,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10649,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10651,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10651(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10651,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10655,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10732,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10732 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10732,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10727,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10727 in k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10727,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10656 in k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10658,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[216]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[234]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10698,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10711,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_10711(t6,t4);}
else{
t6=(C_word)C_eqp(t1,lf[222]);
t7=t5;
f_10711(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[230])));}}}

/* k10709 in k10656 in k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* f_10698 in k10656 in k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10698,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10695 in k10656 in k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10697,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10679,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_10679(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_10679(t5,C_SCHEME_FALSE);}}

/* k10677 in k10695 in k10656 in k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10679,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10673(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10673(t2,C_SCHEME_UNDEFINED);}}

/* k10671 in k10695 in k10656 in k10653 in walk in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10647 in ##compiler#scan-used-variables in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10353,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[427],t9));}
else{
t6=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[428],t10));}
else{
t7=(C_word)C_eqp(t4,lf[375]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[376]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[82],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[429],t12));}
else{
t9=(C_word)C_eqp(t4,lf[373]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[374]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[82],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[430],t14));}
else{
t11=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[82],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[427],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[431],t17));}
else{
t12=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[82],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[432],t16));}
else{
t13=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[82],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[433],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10549,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_10549(t18,(C_word)C_i_memq(t17,lf[436]));}
else{
t17=t14;
f_10549(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_10549(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k10547 in ##compiler#finish-foreign-result in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10549,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[434],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_10570(t6,(C_word)C_eqp(lf[368],t5));}
else{
t5=t2;
f_10570(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10570(t3,C_SCHEME_FALSE);}}}

/* k10568 in k10547 in ##compiler#finish-foreign-result in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10570,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[366],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[82],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[435],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10043,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10046,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10055,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10347,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1047 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t4,t5);}

/* a10346 in ##compiler#estimate-foreign-result-location-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10347,2,t0,t1);}
/* support.scm: 1068 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[425],((C_word*)t0)[2]);}

/* a10054 in ##compiler#estimate-foreign-result-location-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10055,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[335]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10065,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_10065(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[339]);
if(C_truep(t7)){
t8=t6;
f_10065(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t8)){
t9=t6;
f_10065(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t9)){
t10=t6;
f_10065(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t10)){
t11=t6;
f_10065(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[336]);
if(C_truep(t11)){
t12=t6;
f_10065(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t12)){
t13=t6;
f_10065(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t13)){
t14=t6;
f_10065(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t14)){
t15=t6;
f_10065(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t15)){
t16=t6;
f_10065(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t16)){
t17=t6;
f_10065(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t17)){
t18=t6;
f_10065(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[343]);
if(C_truep(t18)){
t19=t6;
f_10065(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t19)){
t20=t6;
f_10065(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[352]);
if(C_truep(t20)){
t21=t6;
f_10065(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[350]);
if(C_truep(t21)){
t22=t6;
f_10065(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[341]);
if(C_truep(t22)){
t23=t6;
f_10065(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t23)){
t24=t6;
f_10065(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t24)){
t25=t6;
f_10065(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[402]);
if(C_truep(t25)){
t26=t6;
f_10065(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[397]);
if(C_truep(t26)){
t27=t6;
f_10065(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t27)){
t28=t6;
f_10065(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[411]);
if(C_truep(t28)){
t29=t6;
f_10065(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t29)){
t30=t6;
f_10065(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t30)){
t31=t6;
f_10065(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t31)){
t32=t6;
f_10065(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t32)){
t33=t6;
f_10065(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t33)){
t34=t6;
f_10065(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t34)){
t35=t6;
f_10065(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t35)){
t36=t6;
f_10065(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[377]);
t37=t6;
f_10065(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[378])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k10063 in a10054 in ##compiler#estimate-foreign-result-location-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10065,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[403]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[404]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub331(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1060 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t4,C_retrieve(lf[372]),((C_word*)t0)[3]);}
else{
t5=t4;
f_10083(2,t5,C_SCHEME_FALSE);}}}}

/* k10081 in k10063 in a10054 in ##compiler#estimate-foreign-result-location-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10083,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1062 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[363]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_10117(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[345]);
if(C_truep(t5)){
t6=t4;
f_10117(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t6)){
t7=t4;
f_10117(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[354]);
if(C_truep(t7)){
t8=t4;
f_10117(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[356]);
t9=t4;
f_10117(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[371])));}}}}}
else{
/* support.scm: 1067 err */
f_10046(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k10115 in k10081 in k10063 in a10054 in ##compiler#estimate-foreign-result-location-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1066 err */
f_10046(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_10046(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10046,NULL,2,t1,t2);}
/* support.scm: 1046 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[424],t2);}

/* ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9724,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9730,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10037,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1017 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a10036 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_10037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10037,2,t0,t1);}
/* support.scm: 1042 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[422],((C_word*)t0)[2]);}

/* a9729 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9730,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[335]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9740,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9740(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[339]);
if(C_truep(t7)){
t8=t6;
f_9740(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t8)){
t9=t6;
f_9740(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t9)){
t10=t6;
f_9740(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t10)){
t11=t6;
f_9740(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t11)){
t12=t6;
f_9740(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[421]);
if(C_truep(t12)){
t13=t6;
f_9740(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[336]);
if(C_truep(t13)){
t14=t6;
f_9740(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t14)){
t15=t6;
f_9740(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t15)){
t16=t6;
f_9740(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t16)){
t17=t6;
f_9740(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[410]);
t18=t6;
f_9740(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[411])));}}}}}}}}}}}}

/* k9738 in a9729 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9740,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[357]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9749(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t4)){
t5=t3;
f_9749(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[354]);
if(C_truep(t5)){
t6=t3;
f_9749(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
if(C_truep(t6)){
t7=t3;
f_9749(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t7)){
t8=t3;
f_9749(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t8)){
t9=t3;
f_9749(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t9)){
t10=t3;
f_9749(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t10)){
t11=t3;
f_9749(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t11)){
t12=t3;
f_9749(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
t13=t3;
f_9749(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}}}}}}

/* k9747 in k9738 in a9729 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9749(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9749,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[352]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9761(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t4)){
t5=t3;
f_9761(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[350]);
if(C_truep(t5)){
t6=t3;
f_9761(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t6)){
t7=t3;
f_9761(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
t8=t3;
f_9761(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[379])));}}}}}}

/* k9759 in k9747 in k9738 in a9729 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9761,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[341]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9773(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
if(C_truep(t4)){
t5=t3;
f_9773(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[404]);
t6=t3;
f_9773(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[418])));}}}}

/* k9771 in k9759 in k9747 in k9738 in a9729 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9773,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1033 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t2,C_retrieve(lf[372]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9779(2,t3,C_SCHEME_FALSE);}}}

/* k9777 in k9771 in k9759 in k9747 in k9738 in a9729 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9779,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1035 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[363]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9813,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9813(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[345]);
if(C_truep(t5)){
t6=t4;
f_9813(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t6)){
t7=t4;
f_9813(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[354]);
if(C_truep(t7)){
t8=t4;
f_9813(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[356]);
if(C_truep(t8)){
t9=t4;
f_9813(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[371]);
if(C_truep(t9)){
t10=t4;
f_9813(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[364]);
if(C_truep(t10)){
t11=t4;
f_9813(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[365]);
t12=t4;
f_9813(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[368])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9811 in k9777 in k9771 in k9759 in k9747 in k9738 in a9729 in ##compiler#estimate-foreign-result-size in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9684,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9690,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9718,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1004 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a9717 in ##compiler#final-foreign-type in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9718,2,t0,t1);}
/* support.scm: 1011 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[416],((C_word*)t0)[2]);}

/* a9689 in ##compiler#final-foreign-type in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9690,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9694,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1007 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t4,C_retrieve(lf[372]),t2);}
else{
t5=t4;
f_9694(2,t5,C_SCHEME_FALSE);}}

/* k9692 in a9689 in ##compiler#final-foreign-type in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1009 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9653,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9657,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9666,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 998  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t5,C_retrieve(lf[372]),t3);}
else{
t5=t4;
f_9657(t5,C_SCHEME_FALSE);}}

/* k9664 in ##compiler#foreign-type-convert-argument in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9666,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9657(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9657(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9657(t2,C_SCHEME_FALSE);}}

/* k9655 in ##compiler#foreign-type-convert-argument in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9622,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9626,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9635,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 991  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t5,C_retrieve(lf[372]),t3);}
else{
t5=t4;
f_9626(t5,C_SCHEME_FALSE);}}

/* k9633 in ##compiler#foreign-type-convert-result in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9635,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_9626(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9626(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9626(t2,C_SCHEME_FALSE);}}

/* k9624 in ##compiler#foreign-type-convert-result in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8575,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8581,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9616,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 892  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t3,t4,t5);}

/* a9615 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
/* support.scm: 984  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[412],((C_word*)t0)[2]);}

/* a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8581,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8587,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8587(t7,t1,t2);}

/* repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8587(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8587,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[335]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[336]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[337]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[338],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[339]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8616(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t8)){
t9=t7;
f_8616(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t9)){
t10=t7;
f_8616(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t10)){
t11=t7;
f_8616(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t11)){
t12=t7;
f_8616(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[409]);
if(C_truep(t12)){
t13=t7;
f_8616(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[410]);
t14=t7;
f_8616(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[411])));}}}}}}}}

/* k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8616,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[337]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[340],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[341]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8635(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[403]);
t5=t3;
f_8635(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[404])));}}}

/* k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8635,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[337]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[342],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[343]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8654(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
if(C_truep(t4)){
t5=t3;
f_8654(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[401]);
t6=t3;
f_8654(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[402])));}}}}

/* k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8654,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8657,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 902  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8724(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
if(C_truep(t4)){
t5=t3;
f_8724(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[398]);
t6=t3;
f_8724(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[399])));}}}}

/* k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8724,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[337]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[344],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[346]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8743(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t4)){
t5=t3;
f_8743(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t5)){
t6=t3;
f_8743(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t6)){
t7=t3;
f_8743(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t7)){
t8=t3;
f_8743(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t8)){
t9=t3;
f_8743(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
t10=t3;
f_8743(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[396])));}}}}}}}}

/* k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8743(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8743,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8746,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 914  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[348]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8825(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t4)){
t5=t3;
f_8825(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t5)){
t6=t3;
f_8825(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t6)){
t7=t3;
f_8825(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t7)){
t8=t3;
f_8825(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
if(C_truep(t8)){
t9=t3;
f_8825(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[388]);
t10=t3;
f_8825(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[389])));}}}}}}}}

/* k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8825,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[337]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[349]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[82],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[347],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[350]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8864(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t5=t3;
f_8864(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[382])));}}}

/* k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8864,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[337]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[351],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[352]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8883(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[379]);
t5=t3;
f_8883(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[380])));}}}

/* k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8883,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[337]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[353],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[354]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8902(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[377]);
t5=t3;
f_8902(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[378])));}}}

/* k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8902,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8905,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 934  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[355],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[357]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8982(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[375]);
t6=t4;
f_8982(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[376])));}}}}

/* k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8982,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8985,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 942  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9067(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[373]);
t5=t3;
f_9067(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[374])));}}}

/* k9065 in k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9067,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[337]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[358],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[359],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[358],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[361]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[337]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[362],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[358],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[362],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[359],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[358],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 958  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t3,C_retrieve(lf[372]),((C_word*)t0)[3]);}
else{
t4=t3;
f_9142(2,t4,C_SCHEME_FALSE);}}}}

/* k9140 in k9065 in k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9142,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 960  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[363]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9176(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t5)){
t6=t4;
f_9176(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[371]);
t7=t4;
f_9176(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[354])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k9174 in k9140 in k9065 in k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9176(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9176,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9179,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 964  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[364]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[365]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9246,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 970  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[366],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[367],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 977  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8587(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[370]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[337]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[351],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[345]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[356]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[355],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9244 in k9174 in k9140 in k9065 in k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9246,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[366],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[367],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[82],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[221],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[92],t17));}

/* k9177 in k9174 in k9140 in k9065 in k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_9179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9179,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[355],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[221],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k8983 in k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8985,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9016,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[337]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_9016(t7,(C_word)C_a_i_cons(&a,2,lf[358],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[359],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_9016(t9,(C_word)C_a_i_cons(&a,2,lf[358],t8));}}

/* k9014 in k8983 in k8980 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_9016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9016,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[221],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8903 in k8900 in k8881 in k8862 in k8823 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8905,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[355],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[221],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k8744 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8746,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8777,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[337]))){
t6=t5;
f_8777(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8777(t10,(C_word)C_a_i_cons(&a,2,lf[347],t9));}}

/* k8775 in k8744 in k8741 in k8722 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8777(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8777,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[221],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8655 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8657,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[337]))){
t6=t5;
f_8688(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8688(t7,(C_word)C_a_i_cons(&a,2,lf[344],t6));}}

/* k8686 in k8655 in k8652 in k8633 in k8614 in repeat in a8580 in ##compiler#foreign-type-check in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8688,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[221],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* ##compiler#pprint-expressions-to-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8539,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8543,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 873  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[332]+1)))(3,*((C_word*)lf[332]+1),t4,t3);}
else{
/* support.scm: 873  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[333]+1)))(2,*((C_word*)lf[333]+1),t4);}}

/* k8541 in ##compiler#pprint-expressions-to-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8546,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8554,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 874  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[331]))(4,*((C_word*)lf[331]+1),t2,t1,t3);}

/* a8553 in k8541 in ##compiler#pprint-expressions-to-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8560,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a8559 in a8553 in k8541 in ##compiler#pprint-expressions-to-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8564,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 878  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t3,t2);}

/* k8562 in a8559 in a8553 in k8541 in ##compiler#pprint-expressions-to-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 879  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k8544 in k8541 in ##compiler#pprint-expressions-to-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 881  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[329]+1)))(3,*((C_word*)lf[329]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8500,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8506,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8512,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a8511 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8512,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8519,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 861  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t9,lf[326],lf[327]);}

/* k8517 in a8511 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8519,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 862  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t2,lf[325],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8520 in k8517 in a8511 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 863  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[324],((C_word*)t0)[2]);}

/* k8523 in k8520 in k8517 in a8511 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8528,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 864  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[323],((C_word*)t0)[2]);}

/* k8526 in k8523 in k8520 in k8517 in a8511 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 865  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[322],((C_word*)t0)[2]);}

/* k8529 in k8526 in k8523 in k8520 in k8517 in a8511 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 866  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[321],((C_word*)t0)[2]);}

/* k8532 in k8529 in k8526 in k8523 in k8520 in k8517 in a8511 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 867  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[320],((C_word*)t0)[2]);}

/* a8505 in ##compiler#print-program-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8506,2,t0,t1);}
/* support.scm: 860  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[316]))(3,*((C_word*)lf[316]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8414,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8418,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8423,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 836  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t13,t14,t2);}

/* a8422 in ##compiler#compute-database-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8423,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a8428 in a8422 in ##compiler#compute-database-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8429,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[184]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[165]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8471,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cdr(t2);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8476,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t8=(C_word)C_eqp(t5,lf[172]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* f_8476 in a8428 in a8422 in ##compiler#compute-database-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8476,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8469 in a8428 in a8422 in ##compiler#compute-database-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[229],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8416 in ##compiler#compute-database-statistics in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 850  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[317]),C_retrieve(lf[318]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8393,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8403,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 813  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t7,lf[252],lf[315],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k8401 in ##sys#toplevel-definition-hook in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 814  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[314]))(3,*((C_word*)lf[314]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8362,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8368,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 799  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t1,t3,t2);}

/* a8367 in ##compiler#dump-undefined-globals in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8368,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8375,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[184],t3))){
t5=(C_word)C_i_assq(lf[182],t3);
t6=t4;
f_8375(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8375(t5,C_SCHEME_FALSE);}}

/* k8373 in a8367 in ##compiler#dump-undefined-globals in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8375,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8378,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 803  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[202]+1)))(3,*((C_word*)lf[202]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8376 in k8373 in a8367 in ##compiler#dump-undefined-globals in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 804  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8240,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8244,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8356,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8356 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8356,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8244,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
if(C_truep((C_word)C_i_cadr(t1))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8264,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8264(3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8264,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8268,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8345,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8345 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8345,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8268,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[241]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8322,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(t1,lf[232]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8340,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}}

/* f_8340 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8340,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8337 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 793  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* f_8322 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8322,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8275 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8277,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8316,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8317,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8317 in k8275 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8317,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8314 in k8275 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8316,2,t0,t1);}
t2=(C_word)C_eqp(lf[216],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8308,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8308 in k8314 in k8275 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8308,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8305 in k8314 in k8275 in k8266 in rec in k8242 in ##compiler#simple-lambda-node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 791  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8139,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8145,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8145(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8145(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8145,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8149,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8234,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8234 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8234,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8152,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8229,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_8229 in k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8229,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8150 in k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8152,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[216]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8161(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
if(C_truep(t4)){
t5=t3;
f_8161(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[222]);
if(C_truep(t5)){
t6=t3;
f_8161(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[233]);
t7=t3;
f_8161(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[220])));}}}}

/* k8159 in k8150 in k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8161,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[229]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8187,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8188,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[221]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[92]));
if(C_truep(t4)){
/* support.scm: 775  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* f_8188 in k8159 in k8150 in k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8188,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8185 in k8159 in k8150 in k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8187,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8175,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 774  find */
((C_proc4)C_retrieve_symbol_proc(lf[309]))(4,*((C_word*)lf[309]+1),((C_word*)t0)[2],t3,C_retrieve(lf[310]));}

/* a8174 in k8185 in k8159 in k8150 in k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8175,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8183,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 774  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t3,t2);}

/* k8181 in a8174 in k8185 in k8159 in k8150 in k8147 in walk in ##compiler#expression-has-side-effects? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7919,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7922,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7951,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7994,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8113,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 758  matchn */
t15=((C_word*)t12)[1];
f_7994(t15,t14,t2,t3);}

/* k8111 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8113,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8119,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8133,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8133 in k8111 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8133,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8121 in k8111 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8127,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8128,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8128 in k8121 in k8111 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8128,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8125 in k8121 in k8111 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 761  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[10]))(7,*((C_word*)lf[10]+1),((C_word*)t0)[4],lf[305],lf[306],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8117 in k8111 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7994,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 747  resolve */
t4=((C_word*)t0)[4];
f_7922(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8101,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8106,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* f_8106 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8106,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8101,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8088,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8093,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_8093 in k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8093,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8086 in k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* support.scm: 749  match1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7951(t3,((C_word*)t0)[2],t1,t2);}

/* k8014 in k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8016,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8080,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8080 in k8014 in k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8080,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8021 in k8014 in k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8023,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8029,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8029(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8021 in k8014 in k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_8029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8029,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 753  resolve */
t4=((C_word*)t0)[4];
f_7922(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8060,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 755  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7994(t7,t4,t5,t6);}}}}

/* k8058 in loop in k8021 in k8014 in k8099 in matchn in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_8060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 756  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8029(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7951,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 740  resolve */
t4=((C_word*)t0)[3];
f_7922(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7973,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 742  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7971 in match1 in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 742  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7951(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7922(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7922,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7946,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 735  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7944 in resolve in ##compiler#match-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7850,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7856,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 715  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[303]))(4,*((C_word*)lf[303]+1),t1,t2,t3);}

/* a7855 in ##compiler#load-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7862,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7862(t5,t1);}

/* loop in a7855 in ##compiler#load-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7862,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 718  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t2);}

/* k7864 in loop in a7855 in ##compiler#load-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7886,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 723  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t4,t5);}}

/* k7884 in k7864 in loop in a7855 in ##compiler#load-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7887,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[295],t1);}

/* f_7887 in k7884 in k7864 in loop in a7855 in ##compiler#load-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_7887r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7887r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7887r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7891,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7891(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7891(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k7889 */
static void C_ccall f_7891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7873 in k7864 in loop in a7855 in ##compiler#load-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 724  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7862(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7648,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7652,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7679,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 684  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[301]))(4,*((C_word*)lf[301]+1),t6,t2,t7);}

/* a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7848,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 686  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[300]))(2,*((C_word*)lf[300]+1),t3);}

/* k7846 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 686  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[285]+1)))(7,*((C_word*)lf[285]+1),((C_word*)t0)[2],lf[297],t1,lf[298],C_retrieve(lf[243]),lf[299]);}

/* k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7686,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 688  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t2,t3,((C_word*)t0)[2]);}

/* a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7691,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 690  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[296]))(3,*((C_word*)lf[296]+1),t4,t2);}

/* k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7698,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[167],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7830,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7834,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7840,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],lf[295]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_7840 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7840,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t1,t2,t3);}

/* k7832 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7835,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_7835 in k7832 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7835,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[206]));}

/* k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7830,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[165],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7722(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[160],t5);
t7=t4;
f_7722(t7,(C_word)C_i_not(t6));}}}

/* k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7722,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[194],((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7811,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7811 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7811,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7740,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(t1);
/* support.scm: 698  get */
((C_proc5)C_retrieve_symbol_proc(lf[137]))(5,*((C_word*)lf[137]+1),t2,((C_word*)t0)[2],t3,lf[193]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7738 in k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7740,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 699  get */
((C_proc5)C_retrieve_symbol_proc(lf[137]))(5,*((C_word*)lf[137]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[201]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7800 in k7738 in k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7794,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[294]);}}

/* f_7794 in k7800 in k7738 in k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7794,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t1,t2,t3);}

/* k7750 in k7800 in k7738 in k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7755,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[291]);
if(C_truep(t3)){
t4=t2;
f_7755(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[292]);
if(C_truep(t4)){
t5=t2;
f_7755(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[293]);
t7=t2;
f_7755(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7753 in k7750 in k7800 in k7738 in k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7755,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7762,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7773,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 706  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7771 in k7753 in k7750 in k7800 in k7738 in k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7773,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 706  pp */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),((C_word*)t0)[2],t2);}

/* k7760 in k7753 in k7750 in k7800 in k7738 in k7729 in k7720 in k7828 in k7696 in a7690 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 707  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k7684 in k7681 in a7678 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 709  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[285]+1)))(3,*((C_word*)lf[285]+1),((C_word*)t0)[2],lf[289]);}

/* k7650 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 711  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t2,lf[287],lf[288]);}
else{
t3=t2;
f_7658(2,t3,C_SCHEME_FALSE);}}

/* k7656 in k7650 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7658,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7663,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7671,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 712  sort-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[78]))(3,*((C_word*)lf[78]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7669 in k7656 in k7650 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7662 in k7656 in k7650 in ##compiler#emit-global-inline-file in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7663,3,t0,t1,t2);}
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[285]+1)))(4,*((C_word*)lf[285]+1),t1,lf[286],t2);}

/* ##compiler#sexpr->node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7615,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7621,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7621(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7621,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7637,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k7635 in walk in ##compiler#sexpr->node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7638,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7638 in k7635 in walk in ##compiler#sexpr->node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7638,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7564,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7570,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7570(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7570,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7578,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7609,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7609 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7609,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7576 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7604,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7604 in k7576 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7604,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7584 in k7576 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7590,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7594,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7598,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7599,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_7599 in k7584 in k7576 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7599,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7596 in k7584 in k7576 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k7592 in k7584 in k7576 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7588 in k7584 in k7576 in walk in ##compiler#node->sexpr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7590,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7487,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7491,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7557,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7558,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_7558 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7558,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7555 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 663  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7548,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7549,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7549 in k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7549,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7546 in k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 664  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7492 in k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7539,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7540,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7540 in k7492 in k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7540,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7537 in k7492 in k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 665  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7495 in k7492 in k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7497,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7508(t4,C_fix(4)));}

/* doloop1624 in k7495 in k7492 in k7489 in ##compiler#copy-node! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static C_word C_fcall f_7508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7453,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7459,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7459(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7459,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 659  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7471 in rec in ##compiler#tree-copy in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7477,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 659  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7459(t4,t2,t3);}

/* k7475 in k7471 in rec in ##compiler#tree-copy in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7477,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7232,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7236,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 627  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[257]+1)))(5,*((C_word*)lf[257]+1),t5,*((C_word*)lf[280]+1),t3,t4);}

/* k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7238,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7244,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 654  walk */
t6=((C_word*)t4)[1];
f_7244(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7244(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7244,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7248,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7444,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7444 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7444,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7251,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7439,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7439 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7439,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7434,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7434 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7254,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[216]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7267,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 634  rename */
f_7238(t3,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(t1,lf[234]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 635  rename */
f_7238(t4,t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7319,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 638  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t6,t5);}
else{
t5=(C_word)C_eqp(t1,lf[229]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 642  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),((C_word*)t0)[7],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 653  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t6,((C_word*)t0)[6]);}}}}}

/* k7416 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7422,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7428 in k7416 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7429,3,t0,t1,t2);}
/* walk1502 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7244(t3,t1,t2,((C_word*)t0)[2]);}

/* k7420 in k7416 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7423,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7423 in k7420 in k7416 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7423,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7359,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[93]),t2);}

/* k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 646  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t2,t1,((C_word*)t0)[2]);}

/* k7364 in k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 649  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[278]);}

/* k7390 in k7364 in k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7392,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7400,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 650  rename */
f_7238(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_7408(2,t5,C_SCHEME_FALSE);}}

/* k7406 in k7390 in k7364 in k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 650  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7398 in k7390 in k7364 in k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7400,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7377,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7383 in k7398 in k7390 in k7364 in k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7384,3,t0,t1,t2);}
/* walk1502 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7244(t3,t1,t2,((C_word*)t0)[2]);}

/* k7375 in k7398 in k7390 in k7364 in k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7378,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[229],((C_word*)t0)[2],t1);}

/* f_7378 in k7375 in k7398 in k7390 in k7364 in k7361 in a7358 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7378,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k7317 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7322,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 639  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7320 in k7317 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7322,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7333,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7340,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7339 in k7320 in k7317 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7340,3,t0,t1,t2);}
/* walk1502 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7244(t3,t1,t2,((C_word*)t0)[2]);}

/* k7331 in k7320 in k7317 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7334,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_7334 in k7331 in k7320 in k7317 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7334,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k7301 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7303,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7288,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7294 in k7301 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7295,3,t0,t1,t2);}
/* walk1502 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7244(t3,t1,t2,((C_word*)t0)[2]);}

/* k7286 in k7301 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7289,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[234],((C_word*)t0)[2],t1);}

/* f_7289 in k7286 in k7301 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7289,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k7265 in k7252 in k7249 in k7246 in walk in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 634  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),((C_word*)t0)[2],t1);}

/* rename in k7234 in ##compiler#copy-node-tree-and-rename in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7238(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7238,NULL,3,t1,t2,t3);}
/* support.scm: 628  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[276]))(6,*((C_word*)lf[276]+1),t1,t2,t3,*((C_word*)lf[277]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7119,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7125,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 605  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),t1,t2,t6);}

/* a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7125,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7131,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7137,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7137,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[93]),((C_word*)t0)[2]);}
else{
t5=t4;
f_7141(2,t5,((C_word*)t0)[2]);}}

/* k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7144,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 611  copy-node-tree-and-rename */
((C_proc5)C_retrieve_symbol_proc(lf[275]))(5,*((C_word*)lf[275]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_7144(2,t3,((C_word*)t0)[3]);}}

/* k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7149,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7224,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 617  last */
((C_proc3)C_retrieve_symbol_proc(lf[256]))(3,*((C_word*)lf[256]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7170(2,t4,t1);}}

/* k7222 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7224,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7194,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 619  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[217]))(3,*((C_word*)lf[217]+1),t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[274],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7208,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[239],t6,((C_word*)t0)[2]);}}

/* f_7208 in k7222 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7208,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k7192 in k7222 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7194,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7186,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t2);}

/* f_7186 in k7192 in k7222 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7186,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k7168 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7174,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 623  take */
((C_proc4)C_retrieve_symbol_proc(lf[273]))(4,*((C_word*)lf[273]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7172 in k7168 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 613  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[272]))(6,*((C_word*)lf[272]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7148 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7149,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7162,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[92],t5,t6);}

/* f_7162 in a7148 in k7142 in k7139 in a7136 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7162,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* a7130 in a7124 in ##compiler#inline-lambda-bindings in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7131,2,t0,t1);}
/* support.scm: 608  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[271]))(4,*((C_word*)lf[271]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7065,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7071,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7071(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_7071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7071,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7097,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 601  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k7095 in fold in ##compiler#fold-boolean in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7101,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 602  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7071(t4,t2,t3);}

/* k7099 in k7095 in fold in ##compiler#fold-boolean in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7089,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[231],lf[269],t2);}

/* f_7089 in k7099 in k7095 in fold in ##compiler#fold-boolean in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7089,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6732,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6738,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6738(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6738,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6742,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7059,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7059 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7059,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6745,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7054,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7054 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7054,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6748,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7049,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7049 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7049,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6748,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[221]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6757(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[266]);
t5=t3;
f_6757(t5,(C_truep(t4)?t4:(C_word)C_eqp(t1,lf[267])));}}

/* k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6757,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6764,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[255]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6785,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[216]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[220]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[82]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[82],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6847,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 575  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[259]))(3,*((C_word*)lf[259]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[229]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[116]:lf[229]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6872,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 582  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6738(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[241]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[232]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6905,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[222]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6929,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6929(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_6991(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
if(C_truep(t14)){
t15=t13;
f_6991(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[264]);
t16=t13;
f_6991(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[265])));}}}}}}}}}}}}}

/* k6989 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6991,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 592  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6738(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k7019 in k6989 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 593  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7015 in k6989 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6996 in k6989 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7002,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k7000 in k6996 in k6989 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_7002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[260]))(6,*((C_word*)lf[260]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6929(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6929,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6947,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 589  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6978,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 590  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6738(3,t10,t8,t9);}}

/* k6976 in loop in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 590  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6929(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6945 in loop in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 589  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6738(3,t4,t2,t3);}

/* k6953 in k6945 in loop in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6955,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[261],t3));}

/* k6903 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 584  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[260]))(5,*((C_word*)lf[260]+1),((C_word*)t0)[3],lf[232],((C_word*)t0)[2],t1);}

/* k6870 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6872,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6849 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6845 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 575  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[257]+1)))(5,*((C_word*)lf[257]+1),((C_word*)t0)[3],*((C_word*)lf[258]+1),((C_word*)t0)[2],t1);}

/* k6829 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6839,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6843,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 576  last */
((C_proc3)C_retrieve_symbol_proc(lf[256]))(3,*((C_word*)lf[256]+1),t3,((C_word*)t0)[2]);}

/* k6841 in k6829 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 576  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6738(3,t2,((C_word*)t0)[2],t1);}

/* k6837 in k6829 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6839,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* k6783 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6779 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[255],t2));}

/* k6762 in k6755 in k6746 in k6743 in k6740 in walk in ##compiler#build-expression-tree in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6764,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6123,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6126,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6727,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 559  walk */
t9=((C_word*)t6)[1];
f_6126(3,t9,t8,t2);}

/* k6725 in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6730,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 560  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,lf[252],lf[253],((C_word*)((C_word*)t0)[2])[1]);}

/* k6728 in k6725 in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word *a;
loop:
a=C_alloc(8);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_6126,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 493  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 494  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t1,lf[219],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[220]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6168,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[220],t7,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(t4,lf[221]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[222]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6196,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6221,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6224,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[226],C_retrieve(lf[227]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_6224(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_6224(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_6224(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[92]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 514  walk */
t65=t1;
t66=t11;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6278,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 515  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[228]))(3,*((C_word*)lf[228]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[116]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[229]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6342,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 519  walk */
t65=t14;
t66=t15;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[230]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6390(t17,(C_word)C_eqp(lf[82],t16));}
else{
t16=t15;
f_6390(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[231]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[232]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6427,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[233]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6454,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,lf[233],t17,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t4,lf[234]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[235]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6482,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[236]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6544,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 538  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[239]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6565(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[247]);
if(C_truep(t21)){
t22=t20;
f_6565(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[248]);
if(C_truep(t22)){
t23=t20;
f_6565(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[249]);
t24=t20;
f_6565(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[250])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6715,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6713 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6716,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[241],lf[251],t1);}

/* f_6716 in k6713 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6716,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6565,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6580,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[240]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6602,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6622,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6643,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6666,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6671,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[246]);}

/* f_6671 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6671,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t1,t2,t3);}

/* k6664 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6643(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6643(t2,C_SCHEME_FALSE);}}

/* k6641 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6643,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6647,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 554  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 556  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[244]))(3,*((C_word*)lf[244]+1),t2,((C_word*)t0)[2]);}}

/* k6648 in k6641 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6657(2,t3,t1);}
else{
/* support.scm: 555  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[244]))(3,*((C_word*)lf[244]+1),t2,((C_word*)t0)[2]);}}

/* k6655 in k6648 in k6641 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6657,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6647(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[243]),((C_word*)t0)[2],t1));}

/* k6645 in k6641 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6647,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6634,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6632 in k6645 in k6641 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6635,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[241],((C_word*)t0)[2],t1);}

/* f_6635 in k6632 in k6645 in k6641 in a6621 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6635,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* a6615 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
/* support.scm: 546  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t1,((C_word*)t0)[2]);}

/* k6600 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6603,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[241],lf[242],t1);}

/* f_6603 in k6600 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6603,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6578 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6581,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6581 in k6578 in k6563 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6581,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6542 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6544,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6524,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6528,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 539  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t5,((C_word*)t0)[2]);}

/* k6526 in k6542 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 539  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6126(3,t2,((C_word*)t0)[2],t1);}

/* k6522 in k6542 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6516,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[236],((C_word*)t0)[2],t2);}

/* f_6516 in k6522 in k6542 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6516,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6480 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6483,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[234],((C_word*)t0)[2],t1);}

/* f_6483 in k6480 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6483,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* f_6454 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6454,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6425 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6428,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6428 in k6425 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6428,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6388 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6390,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6374,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6372 in k6388 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6375,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6375 in k6372 in k6388 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6375,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6340 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6334,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[116],((C_word*)t0)[2],t2);}

/* f_6334 in k6340 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6334,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6276 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6300 in k6276 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6301,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 516  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6126(3,t4,t1,t3);}

/* k6289 in k6276 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6299,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 517  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6126(3,t3,t2,((C_word*)t0)[2]);}

/* k6297 in k6289 in k6276 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 516  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6280 in k6276 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6283,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_6283 in k6280 in k6276 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6283,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* k6222 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6224,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 505  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,lf[224],lf[225],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6221(t2,((C_word*)t0)[2]);}}

/* k6225 in k6222 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 508  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[223]+1)))(3,*((C_word*)lf[223]+1),t2,((C_word*)t0)[2]);}

/* k6232 in k6225 in k6222 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6221(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k6219 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_6221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 501  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[217]))(3,*((C_word*)lf[217]+1),((C_word*)t0)[2],t1);}

/* k6194 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6197,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* f_6197 in k6194 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6197,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* f_6168 in walk in ##compiler#build-node-graph in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6168,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* ##compiler#qnode in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6108,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6117,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[82],t3,C_SCHEME_END_OF_LIST);}

/* f_6117 in ##compiler#qnode in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6117,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* ##compiler#varnode in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6093,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6102,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[216],t3,C_SCHEME_END_OF_LIST);}

/* f_6102 in ##compiler#varnode in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6102,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* make-node in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6087,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* node-subexpressions in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6078,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[206]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6069,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[206]);
/* ##sys#block-set! */
t5=*((C_word*)lf[209]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6060,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[206]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6051,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[206]);
/* ##sys#block-set! */
t5=*((C_word*)lf[209]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6042,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[206]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6033,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[206]);
/* ##sys#block-set! */
t5=*((C_word*)lf[209]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6027,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[206]));}

/* f_6021 in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6021,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[206],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5531,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5535,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5535(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6019,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 424  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),t4,C_retrieve(lf[203]),C_retrieve(lf[204]),C_retrieve(lf[126]));}}

/* k6017 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5535(t3,t2);}

/* k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5535,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5540,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 427  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5540,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5550,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 435  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[202]+1)))(3,*((C_word*)lf[202]+1),t14,t2);}}

/* k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5698(t6,t2,((C_word*)t0)[2]);}

/* loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5698(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5698,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 439  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[161]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5724(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t5)){
t6=t4;
f_5724(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t6)){
t7=t4;
f_5724(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t7)){
t8=t4;
f_5724(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t8)){
t9=t4;
f_5724(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t9)){
t10=t4;
f_5724(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[129]);
if(C_truep(t10)){
t11=t4;
f_5724(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t11)){
t12=t4;
f_5724(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[134]);
if(C_truep(t12)){
t13=t4;
f_5724(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t13)){
t14=t4;
f_5724(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t14)){
t15=t4;
f_5724(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t15)){
t16=t4;
f_5724(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t16)){
t17=t4;
f_5724(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t17)){
t18=t4;
f_5724(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t18)){
t19=t4;
f_5724(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t19)){
t20=t4;
f_5724(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t20)){
t21=t4;
f_5724(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t21)){
t22=t4;
f_5724(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t22)){
t23=t4;
f_5724(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t23)){
t24=t4;
f_5724(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[199]);
if(C_truep(t24)){
t25=t4;
f_5724(t25,t24);}
else{
t25=(C_word)C_eqp(t1,lf[200]);
t26=t4;
f_5724(t26,(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[201])));}}}}}}}}}}}}}}}}}}}}}}

/* k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5724,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 443  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[160]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[160]);
t4=((C_word*)t0)[9];
f_5711(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[165]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[160]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5711(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5762,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 447  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[167]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[160]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5711(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 449  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[168]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5788,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 451  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[169]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5797(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t8)){
t9=t7;
f_5797(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t9)){
t10=t7;
f_5797(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[148]);
if(C_truep(t10)){
t11=t7;
f_5797(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t11)){
t12=t7;
f_5797(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
if(C_truep(t12)){
t13=t7;
f_5797(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[178]);
if(C_truep(t13)){
t14=t7;
f_5797(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[179]);
if(C_truep(t14)){
t15=t7;
f_5797(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[180]);
t16=t7;
f_5797(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[181])));}}}}}}}}}}}}}}

/* k5795 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5797,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 454  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[171]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 456  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[172]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 458  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 459  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[6],lf[173],t4);}}}}

/* k5826 in k5795 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5711(2,t3,t2);}

/* k5816 in k5795 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5711(2,t3,t2);}

/* k5802 in k5795 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5808,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 454  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t2,((C_word*)t0)[2]);}

/* k5806 in k5802 in k5795 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 454  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[170],((C_word*)t0)[2],t1);}

/* k5786 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5711(2,t3,t2);}

/* k5776 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5711(2,t3,t2);}

/* k5760 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5711(2,t3,t2);}

/* k5737 in k5722 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[162]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 443  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[163],t3);}

/* k5709 in k5706 in loop in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 460  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5698(t3,((C_word*)t0)[2],t2);}

/* k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[160]);
t5=t3;
f_5588(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5588(t4,C_SCHEME_FALSE);}}

/* k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5588,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5609,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[160]);
t4=t2;
f_5619(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5619(t3,C_SCHEME_FALSE);}}}

/* k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5640,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[160]);
t4=t2;
f_5650(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5650(t3,C_SCHEME_FALSE);}}}

/* k5648 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5650,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5671,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_5556(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5671 in k5648 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5671,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5659 in k5648 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5666,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5666 in k5659 in k5648 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5666,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5663 in k5659 in k5648 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 466  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[159],t2);}

/* f_5640 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5640,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5628 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5635,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5635 in k5628 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5635,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5632 in k5628 in k5617 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 464  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[158],t2);}

/* f_5609 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5609,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5597 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5604,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5604 in k5597 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5604,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5601 in k5597 in k5586 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 462  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[157],t2);}

/* k5554 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 467  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[156],t3);}
else{
t3=t2;
f_5559(2,t3,C_SCHEME_UNDEFINED);}}

/* k5557 in k5554 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5562,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 468  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[155],t3);}
else{
t3=t2;
f_5562(2,t3,C_SCHEME_UNDEFINED);}}

/* k5560 in k5557 in k5554 in k5551 in k5548 in a5539 in k5533 in ##compiler#display-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 469  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5518,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 406  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t1,t2,C_retrieve(lf[145]));}

/* a5517 in ##compiler#display-line-number-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5518,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5529,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[152]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5527 in a5517 in ##compiler#display-line-number-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 408  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[150],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5488,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5494,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5494(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5494(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5494,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5504,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 402  get */
((C_proc5)C_retrieve_symbol_proc(lf[137]))(5,*((C_word*)lf[137]+1),t4,((C_word*)t0)[2],t2,lf[148]);}}

/* k5502 in loop in ##compiler#find-lambda-container in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 403  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5494(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5452,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5459,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 394  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t4,C_retrieve(lf[145]),t3);}

/* k5457 in ##compiler#get-line-2 in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5462(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5462(t3,C_SCHEME_FALSE);}}

/* k5460 in k5457 in ##compiler#get-line-2 in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_5462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 396  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 397  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5442,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 390  get */
((C_proc5)C_retrieve_symbol_proc(lf[137]))(5,*((C_word*)lf[137]+1),t1,C_retrieve(lf[145]),t3,t2);}

/* ##compiler#count! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5385r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5385r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5389,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 378  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t6,t2,t3);}

/* k5387 in ##compiler#count! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5419,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 383  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 384  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5417 in k5387 in ##compiler#count! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5333,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5337,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 370  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t6,t2,t3);}

/* k5335 in ##compiler#collect! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5337,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5364,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 374  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 375  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5362 in k5335 in ##compiler#collect! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5287,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5291,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 362  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t6,t2,t3);}

/* k5289 in ##compiler#put! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5291,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5313,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 366  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 367  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5311 in k5289 in ##compiler#put! in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5269r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5269r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5269r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5273,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 356  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t5,t2,t3);}

/* k5271 in ##compiler#get-all in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5281,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 358  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[140]))(4,*((C_word*)lf[140]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5280 in k5271 in ##compiler#get-all in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5281,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5251,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 350  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t5,t2,t3);}

/* k5253 in ##compiler#get in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5107,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5197,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[136]));}

/* a5196 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5197,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5223,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[124],lf[135]);}
else{
t4=t3;
f_5201(2,t4,C_SCHEME_UNDEFINED);}}

/* f_5223 in a5196 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5223r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5223r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5223r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5227,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5227(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5227(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5225 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5199 in a5196 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[133])))){
/* support.scm: 333  put! */
((C_proc6)C_retrieve_symbol_proc(lf[128]))(6,*((C_word*)lf[128]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[134],C_SCHEME_TRUE);}
else{
t3=t2;
f_5204(2,t3,C_SCHEME_UNDEFINED);}}

/* k5202 in k5199 in a5196 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[132])))){
/* support.scm: 334  put! */
((C_proc6)C_retrieve_symbol_proc(lf[128]))(6,*((C_word*)lf[128]+1),((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[129],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5152,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[131]));}

/* a5151 in k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5152,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5169,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[124],lf[130]);}
else{
t4=t3;
f_5156(2,t4,C_SCHEME_UNDEFINED);}}

/* f_5169 in a5151 in k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5169r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5169r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5169r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5173,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5173(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5173(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5171 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5154 in a5151 in k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[127])))){
/* support.scm: 340  put! */
((C_proc6)C_retrieve_symbol_proc(lf[128]))(6,*((C_word*)lf[128]+1),((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[129],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5108 in k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5119,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[126]));}
else{
t3=t2;
f_5113(2,t3,C_SCHEME_UNDEFINED);}}

/* a5118 in k5108 in k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5119,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5124,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[124],lf[125]);}

/* f_5124 in a5118 in k5108 in k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5124r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5124r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5124r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5128,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5128(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5128(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5126 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5111 in k5108 in k5105 in ##compiler#initialize-analysis-database in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4962,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[112]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4966,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 311  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t6);}

/* k4964 in ##compiler#expand-profile-lambda in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 312  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[113]));}

/* k4968 in k4964 in ##compiler#expand-profile-lambda in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[112]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[115],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[116],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[116],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[117],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[116],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[82],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[118],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[116],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[119],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[116],t35));}

/* ##compiler#process-lambda-documentation in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4959,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[107]+1)))(3,*((C_word*)lf[107]+1),t3,t4);}

/* a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4861,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4867,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4892,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t1,t3,t4);}

/* a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4945 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4946r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4946r(t0,t1,t2);}}

static void C_ccall f_4946r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4952,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4951 in a4945 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4897 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4902,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4930,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 296  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t2,((C_word*)t0)[2],t3);}

/* a4929 in a4897 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4936,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4944,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 296  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t3);}

/* k4942 in a4929 in a4897 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 296  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[102]))(6,*((C_word*)lf[102]+1),((C_word*)t0)[3],*((C_word*)lf[103]+1),*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* a4935 in a4929 in a4897 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4936,3,t0,t1,t2);}
/* support.scm: 296  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t1);}

/* k4900 in a4897 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4902,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[98]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4922 in k4900 in a4897 in a4891 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* a4866 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4867,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4872 in a4866 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4884,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 293  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4882 in a4872 in a4866 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 294  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 295  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4879 in a4872 in a4866 in a4860 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 291  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* k4857 in ##compiler#string->expr in k4849 in k4846 in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4751,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4757,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4757(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4757(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4757,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[90]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[91]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4785,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4785(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 280  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t7,t4);}}}}

/* k4832 in loop in ##compiler#canonicalize-begin-body in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4785(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[95])));}

/* k4783 in loop in ##compiler#canonicalize-begin-body in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4785,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 282  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4757(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 283  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[94]);}}

/* k4821 in k4783 in loop in ##compiler#canonicalize-begin-body in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4823,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 284  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4757(t8,t6,t7);}

/* k4809 in k4821 in k4783 in loop in ##compiler#canonicalize-begin-body in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4811,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* ##compiler#basic-literal? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4691,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4707,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 265  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t5,t2);}}}

/* k4705 in ##compiler#basic-literal? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 266  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[88]+1)))(3,*((C_word*)lf[88]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4713(2,t3,C_SCHEME_FALSE);}}}

/* k4747 in k4705 in ##compiler#basic-literal? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 266  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[2],C_retrieve(lf[86]),t1);}

/* k4711 in k4705 in ##compiler#basic-literal? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 268  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4726 in k4711 in k4705 in ##compiler#basic-literal? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 269  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4645,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4649,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4689,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 255  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t4,t2);}
else{
t4=t3;
f_4649(t4,C_SCHEME_FALSE);}}

/* k4687 in ##compiler#immediate? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4649(t2,(C_word)C_i_not(t1));}

/* k4647 in ##compiler#immediate? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4615,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4569,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[82],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4549,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4555,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 234  sort */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,t3);}

/* a4554 in ##compiler#sort-symbols in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4555,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4563,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 234  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t4,t2);}

/* k4561 in a4554 in ##compiler#sort-symbols in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4567,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 234  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2]);}

/* k4565 in k4561 in a4554 in ##compiler#sort-symbols in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 234  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[79]+1)))(4,*((C_word*)lf[79]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4518,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4524,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4524(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4524(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4524,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 230  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 231  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4538 in loop in ##compiler#follow-without-loop in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4539,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 231  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4524(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4455,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4469,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 220  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t5,t3);}}

/* k4467 in ##compiler#fold-inner in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4469,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4471,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4471(t5,((C_word*)t0)[2],t1);}

/* fold in k4467 in ##compiler#fold-inner in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4471,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4479(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4500,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 225  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4498 in fold in k4467 in ##compiler#fold-inner in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4479(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4477 in fold in k4467 in ##compiler#fold-inner in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4443,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[73]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 215  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[74]+1)))(3,*((C_word*)lf[74]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4396r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4396r(t0,t1,t2,t3);}}

static void C_ccall f_4396r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[66]))){
/* support.scm: 209  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[67]+1)))(2,*((C_word*)lf[67]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4412,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 210  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),t4,t2);}}

/* k4410 in ##compiler#check-and-open-input-file in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 210  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[68]+1)))(3,*((C_word*)lf[68]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4424(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4424(t5,(C_word)C_i_not(t4));}}}

/* k4422 in k4410 in ##compiler#check-and-open-input-file in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 211  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[69],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 212  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[70],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4389,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4382,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub326(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4326,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4380,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 190  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t4,t2);}

/* k4378 in ##compiler#valid-c-identifier? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4328 in ##compiler#valid-c-identifier? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4330,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4353,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 194  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4352 in k4328 in ##compiler#valid-c-identifier? in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4353,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4232,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4248,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4250(t5,((C_word*)t0)[2],t1);}

/* loop in k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4250(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4250,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[53]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4272,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4272(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4272(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[59])));}}}

/* k4270 in loop in k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4272,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4279(t3,lf[57]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4279(t4,(C_truep(t3)?lf[58]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4250(t4,t2,t3);}}

/* k4309 in k4270 in loop in k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4277 in k4270 in loop in k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4279,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4295,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 185  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4293 in k4277 in k4270 in loop in k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4281 in k4277 in k4270 in loop in k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4287,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 186  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4250(t4,t2,t3);}

/* k4285 in k4281 in k4277 in k4270 in loop in k4246 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 181  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[54]+1)))(6,*((C_word*)lf[54]+1),((C_word*)t0)[4],lf[55],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4242 in ##compiler#c-ify-string in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[52]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4188,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4194,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4194(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4194(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4194,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4218,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 167  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4216 in loop in ##compiler#build-lambda-list in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4163,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 161  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 162  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t3,lf[47],t2);}}}

/* k4184 in ##compiler#symbolify in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 162  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4142,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 156  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t1,t2);}
else{
/* support.scm: 157  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,lf[44],t2);}}}

/* ##compiler#posq in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4106,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4112(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static C_word C_fcall f_4112(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4038,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4041,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4062,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4062(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4062(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4062,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 140  err */
t4=((C_word*)t0)[3];
f_4041(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 142  err */
t5=((C_word*)t0)[3];
f_4041(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 143  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4041,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 137  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k4047 in err in ##compiler#check-signature in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4053,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 138  map-llist */
((C_proc4)C_retrieve_symbol_proc(lf[36]))(4,*((C_word*)lf[36]+1),t2,C_retrieve(lf[39]),t3);}

/* k4051 in k4047 in err in ##compiler#check-signature in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 136  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}

/* map-llist in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3995,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4001,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4001(t7,t1,t3);}

/* loop in map-llist in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4001,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 131  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 132  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4022 in loop in map-llist in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 132  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4001(t4,t2,t3);}

/* k4026 in k4022 in loop in map-llist in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3992,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[30])));}

/* ##sys#syntax-error-hook in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3967r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3967r(t0,t1,t2,t3);}}

static void C_ccall f_3967r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3971,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k3969 in ##sys#syntax-error-hook in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 118  fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t2,t1,lf[33],((C_word*)t0)[2]);}

/* k3972 in k3969 in ##sys#syntax-error-hook in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3984 in k3972 in k3969 in ##sys#syntax-error-hook in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3985,3,t0,t1,t2);}
/* fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t1,((C_word*)t0)[2],lf[32],t2);}

/* k3975 in k3972 in k3969 in ##sys#syntax-error-hook in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 120  print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[29]))(6,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[30]),lf[31]);}

/* k3978 in k3975 in k3972 in k3969 in ##sys#syntax-error-hook in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 121  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3948r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3948r(t0,t1,t2,t3);}}

static void C_ccall f_3948r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3952,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k3950 in quit in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3955,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 111  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[27],((C_word*)t0)[2]);}

/* k3963 in k3950 in quit in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3953 in k3950 in quit in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 112  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2]);}

/* k3956 in k3953 in k3950 in quit in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 113  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3919r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3919r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3919r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3926,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[24]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_3926(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3926(t6,C_SCHEME_FALSE);}}

/* k3924 in ##compiler#compiler-warning in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_fcall f_3926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3926,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3927 in k3924 in ##compiler#compiler-warning in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3932,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 106  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[22],((C_word*)t0)[2]);}

/* k3937 in k3927 in k3924 in ##compiler#compiler-warning in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3930 in k3927 in k3924 in ##compiler#compiler-warning in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 107  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3879r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3879r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3879r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3889,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 94   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t5,lf[19],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3887 in ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3892,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 97   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_3892(2,t3,C_SCHEME_UNDEFINED);}}

/* k3902 in k3887 in ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3909,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3908 in k3902 in k3887 in ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3909,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3917,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   force */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k3915 in a3908 in k3902 in k3887 in ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 98   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14],t1);}

/* k3890 in k3887 in ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k3893 in k3890 in k3887 in ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 100  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t2);}

/* k3896 in k3893 in k3890 in k3887 in ##compiler#debugging in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3852r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3852r(t0,t1,t2);}}

static void C_ccall f_3852r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3866,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 88   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 89   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k3864 in ##compiler#bomb in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3841 in k3838 in k3835 in k3832 in k3829 in k3826 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3847,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[670] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3828:support_scm",(void*)f_3828},
{"f_3831:support_scm",(void*)f_3831},
{"f_3834:support_scm",(void*)f_3834},
{"f_3837:support_scm",(void*)f_3837},
{"f_3840:support_scm",(void*)f_3840},
{"f_3843:support_scm",(void*)f_3843},
{"f_4848:support_scm",(void*)f_4848},
{"f_4851:support_scm",(void*)f_4851},
{"f_11818:support_scm",(void*)f_11818},
{"f_11823:support_scm",(void*)f_11823},
{"f_11812:support_scm",(void*)f_11812},
{"f_11784:support_scm",(void*)f_11784},
{"f_11788:support_scm",(void*)f_11788},
{"f_11763:support_scm",(void*)f_11763},
{"f_11767:support_scm",(void*)f_11767},
{"f_11730:support_scm",(void*)f_11730},
{"f_11735:support_scm",(void*)f_11735},
{"f_11739:support_scm",(void*)f_11739},
{"f_11697:support_scm",(void*)f_11697},
{"f_11702:support_scm",(void*)f_11702},
{"f_11706:support_scm",(void*)f_11706},
{"f_11673:support_scm",(void*)f_11673},
{"f_11604:support_scm",(void*)f_11604},
{"f_11608:support_scm",(void*)f_11608},
{"f_11613:support_scm",(void*)f_11613},
{"f_11617:support_scm",(void*)f_11617},
{"f_11668:support_scm",(void*)f_11668},
{"f_11647:support_scm",(void*)f_11647},
{"f_11659:support_scm",(void*)f_11659},
{"f_11662:support_scm",(void*)f_11662},
{"f_11635:support_scm",(void*)f_11635},
{"f_11571:support_scm",(void*)f_11571},
{"f_11581:support_scm",(void*)f_11581},
{"f_11584:support_scm",(void*)f_11584},
{"f_11469:support_scm",(void*)f_11469},
{"f_11478:support_scm",(void*)f_11478},
{"f_11565:support_scm",(void*)f_11565},
{"f_11482:support_scm",(void*)f_11482},
{"f_11560:support_scm",(void*)f_11560},
{"f_11485:support_scm",(void*)f_11485},
{"f_11555:support_scm",(void*)f_11555},
{"f_11488:support_scm",(void*)f_11488},
{"f_11491:support_scm",(void*)f_11491},
{"f_11497:support_scm",(void*)f_11497},
{"f_11550:support_scm",(void*)f_11550},
{"f_11500:support_scm",(void*)f_11500},
{"f_11515:support_scm",(void*)f_11515},
{"f_11523:support_scm",(void*)f_11523},
{"f_11533:support_scm",(void*)f_11533},
{"f_11518:support_scm",(void*)f_11518},
{"f_11506:support_scm",(void*)f_11506},
{"f_11473:support_scm",(void*)f_11473},
{"f_11463:support_scm",(void*)f_11463},
{"f_11417:support_scm",(void*)f_11417},
{"f_11436:support_scm",(void*)f_11436},
{"f_11447:support_scm",(void*)f_11447},
{"f_11443:support_scm",(void*)f_11443},
{"f_11405:support_scm",(void*)f_11405},
{"f_11411:support_scm",(void*)f_11411},
{"f_11393:support_scm",(void*)f_11393},
{"f_11397:support_scm",(void*)f_11397},
{"f_11314:support_scm",(void*)f_11314},
{"f_11333:support_scm",(void*)f_11333},
{"f_11358:support_scm",(void*)f_11358},
{"f_11362:support_scm",(void*)f_11362},
{"f_11364:support_scm",(void*)f_11364},
{"f_11371:support_scm",(void*)f_11371},
{"f_11384:support_scm",(void*)f_11384},
{"f_11388:support_scm",(void*)f_11388},
{"f_11317:support_scm",(void*)f_11317},
{"f_11321:support_scm",(void*)f_11321},
{"f_11327:support_scm",(void*)f_11327},
{"f_11308:support_scm",(void*)f_11308},
{"f_11264:support_scm",(void*)f_11264},
{"f_11276:support_scm",(void*)f_11276},
{"f_11280:support_scm",(void*)f_11280},
{"f_11284:support_scm",(void*)f_11284},
{"f_11272:support_scm",(void*)f_11272},
{"f_11255:support_scm",(void*)f_11255},
{"f_11249:support_scm",(void*)f_11249},
{"f_11243:support_scm",(void*)f_11243},
{"f_11231:support_scm",(void*)f_11231},
{"f_11235:support_scm",(void*)f_11235},
{"f_11238:support_scm",(void*)f_11238},
{"f_11193:support_scm",(void*)f_11193},
{"f_11197:support_scm",(void*)f_11197},
{"f_11200:support_scm",(void*)f_11200},
{"f_11207:support_scm",(void*)f_11207},
{"f_11151:support_scm",(void*)f_11151},
{"f_11160:support_scm",(void*)f_11160},
{"f_11122:support_scm",(void*)f_11122},
{"f_11132:support_scm",(void*)f_11132},
{"f_10925:support_scm",(void*)f_10925},
{"f_11104:support_scm",(void*)f_11104},
{"f_11053:support_scm",(void*)f_11053},
{"f_11098:support_scm",(void*)f_11098},
{"f_11102:support_scm",(void*)f_11102},
{"f_11056:support_scm",(void*)f_11056},
{"f_11061:support_scm",(void*)f_11061},
{"f_11065:support_scm",(void*)f_11065},
{"f_11059:support_scm",(void*)f_11059},
{"f_11016:support_scm",(void*)f_11016},
{"f_11020:support_scm",(void*)f_11020},
{"f_11029:support_scm",(void*)f_11029},
{"f_11033:support_scm",(void*)f_11033},
{"f_11023:support_scm",(void*)f_11023},
{"f_10981:support_scm",(void*)f_10981},
{"f_10987:support_scm",(void*)f_10987},
{"f_11014:support_scm",(void*)f_11014},
{"f_11000:support_scm",(void*)f_11000},
{"f_10934:support_scm",(void*)f_10934},
{"f_10940:support_scm",(void*)f_10940},
{"f_10979:support_scm",(void*)f_10979},
{"f_10961:support_scm",(void*)f_10961},
{"f_10738:support_scm",(void*)f_10738},
{"f_10920:support_scm",(void*)f_10920},
{"f_10907:support_scm",(void*)f_10907},
{"f_10913:support_scm",(void*)f_10913},
{"f_10741:support_scm",(void*)f_10741},
{"f_10901:support_scm",(void*)f_10901},
{"f_10745:support_scm",(void*)f_10745},
{"f_10896:support_scm",(void*)f_10896},
{"f_10748:support_scm",(void*)f_10748},
{"f_10891:support_scm",(void*)f_10891},
{"f_10751:support_scm",(void*)f_10751},
{"f_10760:support_scm",(void*)f_10760},
{"f_10854:support_scm",(void*)f_10854},
{"f_10866:support_scm",(void*)f_10866},
{"f_10824:support_scm",(void*)f_10824},
{"f_10835:support_scm",(void*)f_10835},
{"f_10815:support_scm",(void*)f_10815},
{"f_10801:support_scm",(void*)f_10801},
{"f_10779:support_scm",(void*)f_10779},
{"f_10785:support_scm",(void*)f_10785},
{"f_10789:support_scm",(void*)f_10789},
{"f_10645:support_scm",(void*)f_10645},
{"f_10651:support_scm",(void*)f_10651},
{"f_10732:support_scm",(void*)f_10732},
{"f_10655:support_scm",(void*)f_10655},
{"f_10727:support_scm",(void*)f_10727},
{"f_10658:support_scm",(void*)f_10658},
{"f_10711:support_scm",(void*)f_10711},
{"f_10698:support_scm",(void*)f_10698},
{"f_10697:support_scm",(void*)f_10697},
{"f_10679:support_scm",(void*)f_10679},
{"f_10673:support_scm",(void*)f_10673},
{"f_10649:support_scm",(void*)f_10649},
{"f_10353:support_scm",(void*)f_10353},
{"f_10549:support_scm",(void*)f_10549},
{"f_10570:support_scm",(void*)f_10570},
{"f_10043:support_scm",(void*)f_10043},
{"f_10347:support_scm",(void*)f_10347},
{"f_10055:support_scm",(void*)f_10055},
{"f_10065:support_scm",(void*)f_10065},
{"f_10083:support_scm",(void*)f_10083},
{"f_10117:support_scm",(void*)f_10117},
{"f_10046:support_scm",(void*)f_10046},
{"f_9724:support_scm",(void*)f_9724},
{"f_10037:support_scm",(void*)f_10037},
{"f_9730:support_scm",(void*)f_9730},
{"f_9740:support_scm",(void*)f_9740},
{"f_9749:support_scm",(void*)f_9749},
{"f_9761:support_scm",(void*)f_9761},
{"f_9773:support_scm",(void*)f_9773},
{"f_9779:support_scm",(void*)f_9779},
{"f_9813:support_scm",(void*)f_9813},
{"f_9684:support_scm",(void*)f_9684},
{"f_9718:support_scm",(void*)f_9718},
{"f_9690:support_scm",(void*)f_9690},
{"f_9694:support_scm",(void*)f_9694},
{"f_9653:support_scm",(void*)f_9653},
{"f_9666:support_scm",(void*)f_9666},
{"f_9657:support_scm",(void*)f_9657},
{"f_9622:support_scm",(void*)f_9622},
{"f_9635:support_scm",(void*)f_9635},
{"f_9626:support_scm",(void*)f_9626},
{"f_8575:support_scm",(void*)f_8575},
{"f_9616:support_scm",(void*)f_9616},
{"f_8581:support_scm",(void*)f_8581},
{"f_8587:support_scm",(void*)f_8587},
{"f_8616:support_scm",(void*)f_8616},
{"f_8635:support_scm",(void*)f_8635},
{"f_8654:support_scm",(void*)f_8654},
{"f_8724:support_scm",(void*)f_8724},
{"f_8743:support_scm",(void*)f_8743},
{"f_8825:support_scm",(void*)f_8825},
{"f_8864:support_scm",(void*)f_8864},
{"f_8883:support_scm",(void*)f_8883},
{"f_8902:support_scm",(void*)f_8902},
{"f_8982:support_scm",(void*)f_8982},
{"f_9067:support_scm",(void*)f_9067},
{"f_9142:support_scm",(void*)f_9142},
{"f_9176:support_scm",(void*)f_9176},
{"f_9246:support_scm",(void*)f_9246},
{"f_9179:support_scm",(void*)f_9179},
{"f_8985:support_scm",(void*)f_8985},
{"f_9016:support_scm",(void*)f_9016},
{"f_8905:support_scm",(void*)f_8905},
{"f_8746:support_scm",(void*)f_8746},
{"f_8777:support_scm",(void*)f_8777},
{"f_8657:support_scm",(void*)f_8657},
{"f_8688:support_scm",(void*)f_8688},
{"f_8539:support_scm",(void*)f_8539},
{"f_8543:support_scm",(void*)f_8543},
{"f_8554:support_scm",(void*)f_8554},
{"f_8560:support_scm",(void*)f_8560},
{"f_8564:support_scm",(void*)f_8564},
{"f_8546:support_scm",(void*)f_8546},
{"f_8500:support_scm",(void*)f_8500},
{"f_8512:support_scm",(void*)f_8512},
{"f_8519:support_scm",(void*)f_8519},
{"f_8522:support_scm",(void*)f_8522},
{"f_8525:support_scm",(void*)f_8525},
{"f_8528:support_scm",(void*)f_8528},
{"f_8531:support_scm",(void*)f_8531},
{"f_8534:support_scm",(void*)f_8534},
{"f_8506:support_scm",(void*)f_8506},
{"f_8414:support_scm",(void*)f_8414},
{"f_8423:support_scm",(void*)f_8423},
{"f_8429:support_scm",(void*)f_8429},
{"f_8476:support_scm",(void*)f_8476},
{"f_8471:support_scm",(void*)f_8471},
{"f_8418:support_scm",(void*)f_8418},
{"f_8393:support_scm",(void*)f_8393},
{"f_8403:support_scm",(void*)f_8403},
{"f_8362:support_scm",(void*)f_8362},
{"f_8368:support_scm",(void*)f_8368},
{"f_8375:support_scm",(void*)f_8375},
{"f_8378:support_scm",(void*)f_8378},
{"f_8240:support_scm",(void*)f_8240},
{"f_8356:support_scm",(void*)f_8356},
{"f_8244:support_scm",(void*)f_8244},
{"f_8264:support_scm",(void*)f_8264},
{"f_8345:support_scm",(void*)f_8345},
{"f_8268:support_scm",(void*)f_8268},
{"f_8340:support_scm",(void*)f_8340},
{"f_8339:support_scm",(void*)f_8339},
{"f_8322:support_scm",(void*)f_8322},
{"f_8277:support_scm",(void*)f_8277},
{"f_8317:support_scm",(void*)f_8317},
{"f_8316:support_scm",(void*)f_8316},
{"f_8308:support_scm",(void*)f_8308},
{"f_8307:support_scm",(void*)f_8307},
{"f_8139:support_scm",(void*)f_8139},
{"f_8145:support_scm",(void*)f_8145},
{"f_8234:support_scm",(void*)f_8234},
{"f_8149:support_scm",(void*)f_8149},
{"f_8229:support_scm",(void*)f_8229},
{"f_8152:support_scm",(void*)f_8152},
{"f_8161:support_scm",(void*)f_8161},
{"f_8188:support_scm",(void*)f_8188},
{"f_8187:support_scm",(void*)f_8187},
{"f_8175:support_scm",(void*)f_8175},
{"f_8183:support_scm",(void*)f_8183},
{"f_7919:support_scm",(void*)f_7919},
{"f_8113:support_scm",(void*)f_8113},
{"f_8133:support_scm",(void*)f_8133},
{"f_8123:support_scm",(void*)f_8123},
{"f_8128:support_scm",(void*)f_8128},
{"f_8127:support_scm",(void*)f_8127},
{"f_8119:support_scm",(void*)f_8119},
{"f_7994:support_scm",(void*)f_7994},
{"f_8106:support_scm",(void*)f_8106},
{"f_8101:support_scm",(void*)f_8101},
{"f_8093:support_scm",(void*)f_8093},
{"f_8088:support_scm",(void*)f_8088},
{"f_8016:support_scm",(void*)f_8016},
{"f_8080:support_scm",(void*)f_8080},
{"f_8023:support_scm",(void*)f_8023},
{"f_8029:support_scm",(void*)f_8029},
{"f_8060:support_scm",(void*)f_8060},
{"f_7951:support_scm",(void*)f_7951},
{"f_7973:support_scm",(void*)f_7973},
{"f_7922:support_scm",(void*)f_7922},
{"f_7946:support_scm",(void*)f_7946},
{"f_7850:support_scm",(void*)f_7850},
{"f_7856:support_scm",(void*)f_7856},
{"f_7862:support_scm",(void*)f_7862},
{"f_7866:support_scm",(void*)f_7866},
{"f_7886:support_scm",(void*)f_7886},
{"f_7887:support_scm",(void*)f_7887},
{"f_7891:support_scm",(void*)f_7891},
{"f_7875:support_scm",(void*)f_7875},
{"f_7648:support_scm",(void*)f_7648},
{"f_7679:support_scm",(void*)f_7679},
{"f_7848:support_scm",(void*)f_7848},
{"f_7683:support_scm",(void*)f_7683},
{"f_7691:support_scm",(void*)f_7691},
{"f_7698:support_scm",(void*)f_7698},
{"f_7840:support_scm",(void*)f_7840},
{"f_7834:support_scm",(void*)f_7834},
{"f_7835:support_scm",(void*)f_7835},
{"f_7830:support_scm",(void*)f_7830},
{"f_7722:support_scm",(void*)f_7722},
{"f_7811:support_scm",(void*)f_7811},
{"f_7731:support_scm",(void*)f_7731},
{"f_7740:support_scm",(void*)f_7740},
{"f_7802:support_scm",(void*)f_7802},
{"f_7794:support_scm",(void*)f_7794},
{"f_7752:support_scm",(void*)f_7752},
{"f_7755:support_scm",(void*)f_7755},
{"f_7773:support_scm",(void*)f_7773},
{"f_7762:support_scm",(void*)f_7762},
{"f_7686:support_scm",(void*)f_7686},
{"f_7652:support_scm",(void*)f_7652},
{"f_7658:support_scm",(void*)f_7658},
{"f_7671:support_scm",(void*)f_7671},
{"f_7663:support_scm",(void*)f_7663},
{"f_7615:support_scm",(void*)f_7615},
{"f_7621:support_scm",(void*)f_7621},
{"f_7637:support_scm",(void*)f_7637},
{"f_7638:support_scm",(void*)f_7638},
{"f_7564:support_scm",(void*)f_7564},
{"f_7570:support_scm",(void*)f_7570},
{"f_7609:support_scm",(void*)f_7609},
{"f_7578:support_scm",(void*)f_7578},
{"f_7604:support_scm",(void*)f_7604},
{"f_7586:support_scm",(void*)f_7586},
{"f_7599:support_scm",(void*)f_7599},
{"f_7598:support_scm",(void*)f_7598},
{"f_7594:support_scm",(void*)f_7594},
{"f_7590:support_scm",(void*)f_7590},
{"f_7487:support_scm",(void*)f_7487},
{"f_7558:support_scm",(void*)f_7558},
{"f_7557:support_scm",(void*)f_7557},
{"f_7491:support_scm",(void*)f_7491},
{"f_7549:support_scm",(void*)f_7549},
{"f_7548:support_scm",(void*)f_7548},
{"f_7494:support_scm",(void*)f_7494},
{"f_7540:support_scm",(void*)f_7540},
{"f_7539:support_scm",(void*)f_7539},
{"f_7497:support_scm",(void*)f_7497},
{"f_7508:support_scm",(void*)f_7508},
{"f_7453:support_scm",(void*)f_7453},
{"f_7459:support_scm",(void*)f_7459},
{"f_7473:support_scm",(void*)f_7473},
{"f_7477:support_scm",(void*)f_7477},
{"f_7232:support_scm",(void*)f_7232},
{"f_7236:support_scm",(void*)f_7236},
{"f_7244:support_scm",(void*)f_7244},
{"f_7444:support_scm",(void*)f_7444},
{"f_7248:support_scm",(void*)f_7248},
{"f_7439:support_scm",(void*)f_7439},
{"f_7251:support_scm",(void*)f_7251},
{"f_7434:support_scm",(void*)f_7434},
{"f_7254:support_scm",(void*)f_7254},
{"f_7418:support_scm",(void*)f_7418},
{"f_7429:support_scm",(void*)f_7429},
{"f_7422:support_scm",(void*)f_7422},
{"f_7423:support_scm",(void*)f_7423},
{"f_7359:support_scm",(void*)f_7359},
{"f_7363:support_scm",(void*)f_7363},
{"f_7366:support_scm",(void*)f_7366},
{"f_7392:support_scm",(void*)f_7392},
{"f_7408:support_scm",(void*)f_7408},
{"f_7400:support_scm",(void*)f_7400},
{"f_7384:support_scm",(void*)f_7384},
{"f_7377:support_scm",(void*)f_7377},
{"f_7378:support_scm",(void*)f_7378},
{"f_7319:support_scm",(void*)f_7319},
{"f_7322:support_scm",(void*)f_7322},
{"f_7340:support_scm",(void*)f_7340},
{"f_7333:support_scm",(void*)f_7333},
{"f_7334:support_scm",(void*)f_7334},
{"f_7303:support_scm",(void*)f_7303},
{"f_7295:support_scm",(void*)f_7295},
{"f_7288:support_scm",(void*)f_7288},
{"f_7289:support_scm",(void*)f_7289},
{"f_7267:support_scm",(void*)f_7267},
{"f_7238:support_scm",(void*)f_7238},
{"f_7119:support_scm",(void*)f_7119},
{"f_7125:support_scm",(void*)f_7125},
{"f_7137:support_scm",(void*)f_7137},
{"f_7141:support_scm",(void*)f_7141},
{"f_7144:support_scm",(void*)f_7144},
{"f_7224:support_scm",(void*)f_7224},
{"f_7208:support_scm",(void*)f_7208},
{"f_7194:support_scm",(void*)f_7194},
{"f_7186:support_scm",(void*)f_7186},
{"f_7170:support_scm",(void*)f_7170},
{"f_7174:support_scm",(void*)f_7174},
{"f_7149:support_scm",(void*)f_7149},
{"f_7162:support_scm",(void*)f_7162},
{"f_7131:support_scm",(void*)f_7131},
{"f_7065:support_scm",(void*)f_7065},
{"f_7071:support_scm",(void*)f_7071},
{"f_7097:support_scm",(void*)f_7097},
{"f_7101:support_scm",(void*)f_7101},
{"f_7089:support_scm",(void*)f_7089},
{"f_6732:support_scm",(void*)f_6732},
{"f_6738:support_scm",(void*)f_6738},
{"f_7059:support_scm",(void*)f_7059},
{"f_6742:support_scm",(void*)f_6742},
{"f_7054:support_scm",(void*)f_7054},
{"f_6745:support_scm",(void*)f_6745},
{"f_7049:support_scm",(void*)f_7049},
{"f_6748:support_scm",(void*)f_6748},
{"f_6757:support_scm",(void*)f_6757},
{"f_6991:support_scm",(void*)f_6991},
{"f_7021:support_scm",(void*)f_7021},
{"f_7017:support_scm",(void*)f_7017},
{"f_6998:support_scm",(void*)f_6998},
{"f_7002:support_scm",(void*)f_7002},
{"f_6929:support_scm",(void*)f_6929},
{"f_6978:support_scm",(void*)f_6978},
{"f_6947:support_scm",(void*)f_6947},
{"f_6955:support_scm",(void*)f_6955},
{"f_6905:support_scm",(void*)f_6905},
{"f_6872:support_scm",(void*)f_6872},
{"f_6851:support_scm",(void*)f_6851},
{"f_6847:support_scm",(void*)f_6847},
{"f_6831:support_scm",(void*)f_6831},
{"f_6843:support_scm",(void*)f_6843},
{"f_6839:support_scm",(void*)f_6839},
{"f_6785:support_scm",(void*)f_6785},
{"f_6781:support_scm",(void*)f_6781},
{"f_6764:support_scm",(void*)f_6764},
{"f_6123:support_scm",(void*)f_6123},
{"f_6727:support_scm",(void*)f_6727},
{"f_6730:support_scm",(void*)f_6730},
{"f_6126:support_scm",(void*)f_6126},
{"f_6715:support_scm",(void*)f_6715},
{"f_6716:support_scm",(void*)f_6716},
{"f_6565:support_scm",(void*)f_6565},
{"f_6622:support_scm",(void*)f_6622},
{"f_6671:support_scm",(void*)f_6671},
{"f_6666:support_scm",(void*)f_6666},
{"f_6643:support_scm",(void*)f_6643},
{"f_6650:support_scm",(void*)f_6650},
{"f_6657:support_scm",(void*)f_6657},
{"f_6647:support_scm",(void*)f_6647},
{"f_6634:support_scm",(void*)f_6634},
{"f_6635:support_scm",(void*)f_6635},
{"f_6616:support_scm",(void*)f_6616},
{"f_6602:support_scm",(void*)f_6602},
{"f_6603:support_scm",(void*)f_6603},
{"f_6580:support_scm",(void*)f_6580},
{"f_6581:support_scm",(void*)f_6581},
{"f_6544:support_scm",(void*)f_6544},
{"f_6528:support_scm",(void*)f_6528},
{"f_6524:support_scm",(void*)f_6524},
{"f_6516:support_scm",(void*)f_6516},
{"f_6482:support_scm",(void*)f_6482},
{"f_6483:support_scm",(void*)f_6483},
{"f_6454:support_scm",(void*)f_6454},
{"f_6427:support_scm",(void*)f_6427},
{"f_6428:support_scm",(void*)f_6428},
{"f_6390:support_scm",(void*)f_6390},
{"f_6374:support_scm",(void*)f_6374},
{"f_6375:support_scm",(void*)f_6375},
{"f_6342:support_scm",(void*)f_6342},
{"f_6334:support_scm",(void*)f_6334},
{"f_6278:support_scm",(void*)f_6278},
{"f_6301:support_scm",(void*)f_6301},
{"f_6291:support_scm",(void*)f_6291},
{"f_6299:support_scm",(void*)f_6299},
{"f_6282:support_scm",(void*)f_6282},
{"f_6283:support_scm",(void*)f_6283},
{"f_6224:support_scm",(void*)f_6224},
{"f_6227:support_scm",(void*)f_6227},
{"f_6234:support_scm",(void*)f_6234},
{"f_6221:support_scm",(void*)f_6221},
{"f_6196:support_scm",(void*)f_6196},
{"f_6197:support_scm",(void*)f_6197},
{"f_6168:support_scm",(void*)f_6168},
{"f_6108:support_scm",(void*)f_6108},
{"f_6117:support_scm",(void*)f_6117},
{"f_6093:support_scm",(void*)f_6093},
{"f_6102:support_scm",(void*)f_6102},
{"f_6087:support_scm",(void*)f_6087},
{"f_6078:support_scm",(void*)f_6078},
{"f_6069:support_scm",(void*)f_6069},
{"f_6060:support_scm",(void*)f_6060},
{"f_6051:support_scm",(void*)f_6051},
{"f_6042:support_scm",(void*)f_6042},
{"f_6033:support_scm",(void*)f_6033},
{"f_6027:support_scm",(void*)f_6027},
{"f_6021:support_scm",(void*)f_6021},
{"f_5531:support_scm",(void*)f_5531},
{"f_6019:support_scm",(void*)f_6019},
{"f_5535:support_scm",(void*)f_5535},
{"f_5540:support_scm",(void*)f_5540},
{"f_5550:support_scm",(void*)f_5550},
{"f_5698:support_scm",(void*)f_5698},
{"f_5708:support_scm",(void*)f_5708},
{"f_5724:support_scm",(void*)f_5724},
{"f_5797:support_scm",(void*)f_5797},
{"f_5828:support_scm",(void*)f_5828},
{"f_5818:support_scm",(void*)f_5818},
{"f_5804:support_scm",(void*)f_5804},
{"f_5808:support_scm",(void*)f_5808},
{"f_5788:support_scm",(void*)f_5788},
{"f_5778:support_scm",(void*)f_5778},
{"f_5762:support_scm",(void*)f_5762},
{"f_5739:support_scm",(void*)f_5739},
{"f_5711:support_scm",(void*)f_5711},
{"f_5553:support_scm",(void*)f_5553},
{"f_5588:support_scm",(void*)f_5588},
{"f_5619:support_scm",(void*)f_5619},
{"f_5650:support_scm",(void*)f_5650},
{"f_5671:support_scm",(void*)f_5671},
{"f_5661:support_scm",(void*)f_5661},
{"f_5666:support_scm",(void*)f_5666},
{"f_5665:support_scm",(void*)f_5665},
{"f_5640:support_scm",(void*)f_5640},
{"f_5630:support_scm",(void*)f_5630},
{"f_5635:support_scm",(void*)f_5635},
{"f_5634:support_scm",(void*)f_5634},
{"f_5609:support_scm",(void*)f_5609},
{"f_5599:support_scm",(void*)f_5599},
{"f_5604:support_scm",(void*)f_5604},
{"f_5603:support_scm",(void*)f_5603},
{"f_5556:support_scm",(void*)f_5556},
{"f_5559:support_scm",(void*)f_5559},
{"f_5562:support_scm",(void*)f_5562},
{"f_5512:support_scm",(void*)f_5512},
{"f_5518:support_scm",(void*)f_5518},
{"f_5529:support_scm",(void*)f_5529},
{"f_5488:support_scm",(void*)f_5488},
{"f_5494:support_scm",(void*)f_5494},
{"f_5504:support_scm",(void*)f_5504},
{"f_5452:support_scm",(void*)f_5452},
{"f_5459:support_scm",(void*)f_5459},
{"f_5462:support_scm",(void*)f_5462},
{"f_5442:support_scm",(void*)f_5442},
{"f_5385:support_scm",(void*)f_5385},
{"f_5389:support_scm",(void*)f_5389},
{"f_5419:support_scm",(void*)f_5419},
{"f_5333:support_scm",(void*)f_5333},
{"f_5337:support_scm",(void*)f_5337},
{"f_5364:support_scm",(void*)f_5364},
{"f_5287:support_scm",(void*)f_5287},
{"f_5291:support_scm",(void*)f_5291},
{"f_5313:support_scm",(void*)f_5313},
{"f_5269:support_scm",(void*)f_5269},
{"f_5273:support_scm",(void*)f_5273},
{"f_5281:support_scm",(void*)f_5281},
{"f_5251:support_scm",(void*)f_5251},
{"f_5255:support_scm",(void*)f_5255},
{"f_5103:support_scm",(void*)f_5103},
{"f_5197:support_scm",(void*)f_5197},
{"f_5223:support_scm",(void*)f_5223},
{"f_5227:support_scm",(void*)f_5227},
{"f_5201:support_scm",(void*)f_5201},
{"f_5204:support_scm",(void*)f_5204},
{"f_5107:support_scm",(void*)f_5107},
{"f_5152:support_scm",(void*)f_5152},
{"f_5169:support_scm",(void*)f_5169},
{"f_5173:support_scm",(void*)f_5173},
{"f_5156:support_scm",(void*)f_5156},
{"f_5110:support_scm",(void*)f_5110},
{"f_5119:support_scm",(void*)f_5119},
{"f_5124:support_scm",(void*)f_5124},
{"f_5128:support_scm",(void*)f_5128},
{"f_5113:support_scm",(void*)f_5113},
{"f_4962:support_scm",(void*)f_4962},
{"f_4966:support_scm",(void*)f_4966},
{"f_4970:support_scm",(void*)f_4970},
{"f_4959:support_scm",(void*)f_4959},
{"f_4852:support_scm",(void*)f_4852},
{"f_4861:support_scm",(void*)f_4861},
{"f_4892:support_scm",(void*)f_4892},
{"f_4946:support_scm",(void*)f_4946},
{"f_4952:support_scm",(void*)f_4952},
{"f_4898:support_scm",(void*)f_4898},
{"f_4930:support_scm",(void*)f_4930},
{"f_4944:support_scm",(void*)f_4944},
{"f_4936:support_scm",(void*)f_4936},
{"f_4902:support_scm",(void*)f_4902},
{"f_4924:support_scm",(void*)f_4924},
{"f_4867:support_scm",(void*)f_4867},
{"f_4873:support_scm",(void*)f_4873},
{"f_4884:support_scm",(void*)f_4884},
{"f_4881:support_scm",(void*)f_4881},
{"f_4859:support_scm",(void*)f_4859},
{"f_4751:support_scm",(void*)f_4751},
{"f_4757:support_scm",(void*)f_4757},
{"f_4834:support_scm",(void*)f_4834},
{"f_4785:support_scm",(void*)f_4785},
{"f_4823:support_scm",(void*)f_4823},
{"f_4811:support_scm",(void*)f_4811},
{"f_4691:support_scm",(void*)f_4691},
{"f_4707:support_scm",(void*)f_4707},
{"f_4749:support_scm",(void*)f_4749},
{"f_4713:support_scm",(void*)f_4713},
{"f_4728:support_scm",(void*)f_4728},
{"f_4645:support_scm",(void*)f_4645},
{"f_4689:support_scm",(void*)f_4689},
{"f_4649:support_scm",(void*)f_4649},
{"f_4615:support_scm",(void*)f_4615},
{"f_4569:support_scm",(void*)f_4569},
{"f_4549:support_scm",(void*)f_4549},
{"f_4555:support_scm",(void*)f_4555},
{"f_4563:support_scm",(void*)f_4563},
{"f_4567:support_scm",(void*)f_4567},
{"f_4518:support_scm",(void*)f_4518},
{"f_4524:support_scm",(void*)f_4524},
{"f_4539:support_scm",(void*)f_4539},
{"f_4455:support_scm",(void*)f_4455},
{"f_4469:support_scm",(void*)f_4469},
{"f_4471:support_scm",(void*)f_4471},
{"f_4500:support_scm",(void*)f_4500},
{"f_4479:support_scm",(void*)f_4479},
{"f_4443:support_scm",(void*)f_4443},
{"f_4396:support_scm",(void*)f_4396},
{"f_4412:support_scm",(void*)f_4412},
{"f_4424:support_scm",(void*)f_4424},
{"f_4389:support_scm",(void*)f_4389},
{"f_4382:support_scm",(void*)f_4382},
{"f_4326:support_scm",(void*)f_4326},
{"f_4380:support_scm",(void*)f_4380},
{"f_4330:support_scm",(void*)f_4330},
{"f_4353:support_scm",(void*)f_4353},
{"f_4232:support_scm",(void*)f_4232},
{"f_4248:support_scm",(void*)f_4248},
{"f_4250:support_scm",(void*)f_4250},
{"f_4272:support_scm",(void*)f_4272},
{"f_4311:support_scm",(void*)f_4311},
{"f_4279:support_scm",(void*)f_4279},
{"f_4295:support_scm",(void*)f_4295},
{"f_4283:support_scm",(void*)f_4283},
{"f_4287:support_scm",(void*)f_4287},
{"f_4244:support_scm",(void*)f_4244},
{"f_4188:support_scm",(void*)f_4188},
{"f_4194:support_scm",(void*)f_4194},
{"f_4218:support_scm",(void*)f_4218},
{"f_4163:support_scm",(void*)f_4163},
{"f_4186:support_scm",(void*)f_4186},
{"f_4142:support_scm",(void*)f_4142},
{"f_4106:support_scm",(void*)f_4106},
{"f_4112:support_scm",(void*)f_4112},
{"f_4038:support_scm",(void*)f_4038},
{"f_4062:support_scm",(void*)f_4062},
{"f_4041:support_scm",(void*)f_4041},
{"f_4049:support_scm",(void*)f_4049},
{"f_4053:support_scm",(void*)f_4053},
{"f_3995:support_scm",(void*)f_3995},
{"f_4001:support_scm",(void*)f_4001},
{"f_4024:support_scm",(void*)f_4024},
{"f_4028:support_scm",(void*)f_4028},
{"f_3992:support_scm",(void*)f_3992},
{"f_3967:support_scm",(void*)f_3967},
{"f_3971:support_scm",(void*)f_3971},
{"f_3974:support_scm",(void*)f_3974},
{"f_3985:support_scm",(void*)f_3985},
{"f_3977:support_scm",(void*)f_3977},
{"f_3980:support_scm",(void*)f_3980},
{"f_3948:support_scm",(void*)f_3948},
{"f_3952:support_scm",(void*)f_3952},
{"f_3965:support_scm",(void*)f_3965},
{"f_3955:support_scm",(void*)f_3955},
{"f_3958:support_scm",(void*)f_3958},
{"f_3919:support_scm",(void*)f_3919},
{"f_3926:support_scm",(void*)f_3926},
{"f_3929:support_scm",(void*)f_3929},
{"f_3939:support_scm",(void*)f_3939},
{"f_3932:support_scm",(void*)f_3932},
{"f_3879:support_scm",(void*)f_3879},
{"f_3889:support_scm",(void*)f_3889},
{"f_3904:support_scm",(void*)f_3904},
{"f_3909:support_scm",(void*)f_3909},
{"f_3917:support_scm",(void*)f_3917},
{"f_3892:support_scm",(void*)f_3892},
{"f_3895:support_scm",(void*)f_3895},
{"f_3898:support_scm",(void*)f_3898},
{"f_3852:support_scm",(void*)f_3852},
{"f_3866:support_scm",(void*)f_3866},
{"f_3847:support_scm",(void*)f_3847},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
