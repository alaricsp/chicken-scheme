/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-06 13:44
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-28 on dill (Linux)
   command line: support.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[506];
static double C_possibly_force_alignment;


/* from k2003 */
static C_word C_fcall stub100(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub100(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k1996 */
static C_word C_fcall stub96(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub96(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8897)
static void C_ccall f_8897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8895)
static void C_ccall f_8895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8790)
static void C_fcall f_8790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8795)
static void C_ccall f_8795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8799)
static void C_ccall f_8799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8835)
static void C_fcall f_8835(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8879)
static void C_ccall f_8879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8851)
static void C_ccall f_8851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8802)
static void C_ccall f_8802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8809)
static void C_ccall f_8809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8805)
static void C_ccall f_8805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8784)
static void C_ccall f_8784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8768)
static void C_ccall f_8768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_ccall f_8777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8761)
static void C_fcall f_8761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8731)
static void C_ccall f_8731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8755)
static void C_ccall f_8755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8625)
static void C_ccall f_8625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8629)
static void C_ccall f_8629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8634)
static void C_fcall f_8634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8638)
static void C_ccall f_8638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8689)
static void C_ccall f_8689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8668)
static void C_ccall f_8668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8680)
static void C_ccall f_8680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8656)
static void C_ccall f_8656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8600)
static void C_ccall f_8600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8613)
static void C_ccall f_8613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8513)
static void C_ccall f_8513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8522)
static void C_fcall f_8522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8535)
static void C_ccall f_8535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8541)
static void C_ccall f_8541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8559)
static void C_ccall f_8559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8567)
static void C_fcall f_8567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8577)
static void C_ccall f_8577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8550)
static void C_ccall f_8550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8517)
static void C_ccall f_8517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8507)
static void C_ccall f_8507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8431)
static void C_ccall f_8431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8438)
static void C_fcall f_8438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8450)
static void C_ccall f_8450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8461)
static void C_ccall f_8461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8457)
static void C_ccall f_8457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8419)
static void C_ccall f_8419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8425)
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8407)
static void C_ccall f_8407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8328)
static void C_ccall f_8328(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8328)
static void C_ccall f_8328r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8378)
static void C_fcall f_8378(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8385)
static void C_ccall f_8385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8402)
static void C_ccall f_8402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8331)
static void C_fcall f_8331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8290)
static void C_ccall f_8290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8294)
static void C_ccall f_8294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8298)
static void C_ccall f_8298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8286)
static void C_ccall f_8286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8260)
static void C_ccall f_8260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8165)
static void C_fcall f_8165(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8137)
static void C_fcall f_8137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_ccall f_7930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_ccall f_8103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8061)
static void C_ccall f_8061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8066)
static void C_ccall f_8066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8070)
static void C_ccall f_8070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8021)
static void C_fcall f_8021(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8025)
static void C_ccall f_8025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7986)
static void C_fcall f_7986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7992)
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8005)
static void C_ccall f_8005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_fcall f_7939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7945)
static void C_fcall f_7945(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_fcall f_7915(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7921)
static void C_ccall f_7921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7774)
static void C_fcall f_7774(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7793)
static void C_fcall f_7793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7824)
static void C_fcall f_7824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7754)
static void C_fcall f_7754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_fcall f_7727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_fcall f_7721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7630)
static void C_fcall f_7630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_fcall f_7589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7542)
static void C_fcall f_7542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7520)
static C_word C_fcall f_7520(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7129)
static void C_fcall f_7129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7181)
static void C_fcall f_7181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_fcall f_7110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6804)
static void C_fcall f_6804(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_fcall f_6813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_fcall f_6825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_fcall f_6837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6877)
static void C_fcall f_6877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_fcall f_6721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6690)
static void C_fcall f_6690(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6680)
static void C_ccall f_6680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5843)
static void C_fcall f_5843(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5868)
static void C_fcall f_5868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_fcall f_5883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5898)
static void C_fcall f_5898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5936)
static void C_fcall f_5936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_fcall f_5951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_fcall f_5993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_fcall f_6020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6035)
static void C_fcall f_6035(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_fcall f_6050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_fcall f_6094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_fcall f_6139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_fcall f_6386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_fcall f_6354(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_fcall f_6242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_fcall f_6210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static C_word C_fcall f_6205(C_word *a,C_word t0);
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6112)
static void C_fcall f_6112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5954)
static void C_ccall f_5954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_fcall f_5969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5676)
static void C_ccall f_5676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_fcall f_5598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5546)
static void C_fcall f_5546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5499)
static void C_fcall f_5499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5455)
static void C_fcall f_5455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5238)
static void C_fcall f_5238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_fcall f_5096(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5131)
static void C_fcall f_5131(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_fcall f_5024(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static C_word C_fcall f_4980(C_word t0,C_word t1);
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4931)
static void C_fcall f_4931(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4759)
static void C_fcall f_4759(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_fcall f_4753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_fcall f_4698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4612)
static void C_fcall f_4612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4337)
static void C_fcall f_4337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_fcall f_4547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_fcall f_4493(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_fcall f_4180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4237)
static void C_fcall f_4237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_fcall f_4033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_fcall f_3892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_fcall f_3889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_fcall f_3308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_fcall f_3439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_fcall f_3496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_fcall f_3361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_fcall f_3382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3267)
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_fcall f_3235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2633)
static void C_fcall f_2633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_fcall f_2642(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_fcall f_2689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_fcall f_2430(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2440)
static void C_fcall f_2440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_fcall f_2449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_fcall f_2473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2348)
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_fcall f_2376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_fcall f_2240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2135)
static void C_fcall f_2135(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_fcall f_2090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_fcall f_2035(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_fcall f_1861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1883)
static void C_fcall f_1883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_fcall f_1890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1805)
static void C_fcall f_1805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1723)
static C_word C_fcall f_1723(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1673)
static void C_fcall f_1673(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1652)
static void C_fcall f_1652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1612)
static void C_fcall f_1612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1537)
static void C_fcall f_1537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8790)
static void C_fcall trf_8790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8790(t0,t1);}

C_noret_decl(trf_8835)
static void C_fcall trf_8835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8835(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8835(t0,t1,t2);}

C_noret_decl(trf_8761)
static void C_fcall trf_8761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8761(t0,t1);}

C_noret_decl(trf_8634)
static void C_fcall trf_8634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8634(t0,t1);}

C_noret_decl(trf_8522)
static void C_fcall trf_8522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8522(t0,t1,t2,t3);}

C_noret_decl(trf_8567)
static void C_fcall trf_8567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8567(t0,t1,t2);}

C_noret_decl(trf_8438)
static void C_fcall trf_8438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8438(t0,t1);}

C_noret_decl(trf_8378)
static void C_fcall trf_8378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8378(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8378(t0,t1,t2,t3);}

C_noret_decl(trf_8331)
static void C_fcall trf_8331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8331(t0,t1);}

C_noret_decl(trf_8165)
static void C_fcall trf_8165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8165(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8165(t0,t1,t2);}

C_noret_decl(trf_8137)
static void C_fcall trf_8137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8137(t0,t1);}

C_noret_decl(trf_8021)
static void C_fcall trf_8021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8021(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8021(t0,t1,t2,t3);}

C_noret_decl(trf_7986)
static void C_fcall trf_7986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7986(t0,t1,t2);}

C_noret_decl(trf_7992)
static void C_fcall trf_7992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7992(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7992(t0,t1,t2);}

C_noret_decl(trf_7939)
static void C_fcall trf_7939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7939(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7939(t0,t1,t2,t3);}

C_noret_decl(trf_7945)
static void C_fcall trf_7945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7945(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7945(t0,t1,t2);}

C_noret_decl(trf_7915)
static void C_fcall trf_7915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7915(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7915(t0,t1,t2,t3);}

C_noret_decl(trf_7774)
static void C_fcall trf_7774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7774(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7774(t0,t1,t2,t3);}

C_noret_decl(trf_7793)
static void C_fcall trf_7793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7793(t0,t1);}

C_noret_decl(trf_7824)
static void C_fcall trf_7824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7824(t0,t1);}

C_noret_decl(trf_7754)
static void C_fcall trf_7754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7754(t0,t1);}

C_noret_decl(trf_7727)
static void C_fcall trf_7727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7727(t0,t1);}

C_noret_decl(trf_7721)
static void C_fcall trf_7721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7721(t0,t1);}

C_noret_decl(trf_7630)
static void C_fcall trf_7630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7630(t0,t1);}

C_noret_decl(trf_7589)
static void C_fcall trf_7589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7589(t0,t1);}

C_noret_decl(trf_7542)
static void C_fcall trf_7542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7542(t0,t1);}

C_noret_decl(trf_7129)
static void C_fcall trf_7129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7129(t0,t1);}

C_noret_decl(trf_7181)
static void C_fcall trf_7181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7181(t0,t1);}

C_noret_decl(trf_7110)
static void C_fcall trf_7110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7110(t0,t1);}

C_noret_decl(trf_6804)
static void C_fcall trf_6804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6804(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6804(t0,t1);}

C_noret_decl(trf_6813)
static void C_fcall trf_6813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6813(t0,t1);}

C_noret_decl(trf_6825)
static void C_fcall trf_6825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6825(t0,t1);}

C_noret_decl(trf_6837)
static void C_fcall trf_6837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6837(t0,t1);}

C_noret_decl(trf_6877)
static void C_fcall trf_6877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6877(t0,t1);}

C_noret_decl(trf_6721)
static void C_fcall trf_6721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6721(t0,t1);}

C_noret_decl(trf_6690)
static void C_fcall trf_6690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6690(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6690(t0,t1);}

C_noret_decl(trf_5843)
static void C_fcall trf_5843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5843(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5843(t0,t1,t2);}

C_noret_decl(trf_5868)
static void C_fcall trf_5868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5868(t0,t1);}

C_noret_decl(trf_5883)
static void C_fcall trf_5883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5883(t0,t1);}

C_noret_decl(trf_5898)
static void C_fcall trf_5898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5898(t0,t1);}

C_noret_decl(trf_5936)
static void C_fcall trf_5936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5936(t0,t1);}

C_noret_decl(trf_5951)
static void C_fcall trf_5951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5951(t0,t1);}

C_noret_decl(trf_5993)
static void C_fcall trf_5993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5993(t0,t1);}

C_noret_decl(trf_6020)
static void C_fcall trf_6020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6020(t0,t1);}

C_noret_decl(trf_6035)
static void C_fcall trf_6035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6035(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6035(t0,t1);}

C_noret_decl(trf_6050)
static void C_fcall trf_6050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6050(t0,t1);}

C_noret_decl(trf_6094)
static void C_fcall trf_6094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6094(t0,t1);}

C_noret_decl(trf_6139)
static void C_fcall trf_6139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6139(t0,t1);}

C_noret_decl(trf_6386)
static void C_fcall trf_6386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6386(t0,t1);}

C_noret_decl(trf_6354)
static void C_fcall trf_6354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6354(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6354(t0,t1);}

C_noret_decl(trf_6242)
static void C_fcall trf_6242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6242(t0,t1);}

C_noret_decl(trf_6210)
static void C_fcall trf_6210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6210(t0,t1);}

C_noret_decl(trf_6112)
static void C_fcall trf_6112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6112(t0,t1);}

C_noret_decl(trf_5969)
static void C_fcall trf_5969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5969(t0,t1);}

C_noret_decl(trf_5598)
static void C_fcall trf_5598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5598(t0,t1);}

C_noret_decl(trf_5546)
static void C_fcall trf_5546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5546(t0,t1);}

C_noret_decl(trf_5499)
static void C_fcall trf_5499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5499(t0,t1);}

C_noret_decl(trf_5455)
static void C_fcall trf_5455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5455(t0,t1);}

C_noret_decl(trf_5238)
static void C_fcall trf_5238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5238(t0,t1);}

C_noret_decl(trf_5096)
static void C_fcall trf_5096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5096(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5096(t0,t1,t2,t3);}

C_noret_decl(trf_5131)
static void C_fcall trf_5131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5131(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5131(t0,t1,t2,t3);}

C_noret_decl(trf_5053)
static void C_fcall trf_5053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5053(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5053(t0,t1,t2,t3);}

C_noret_decl(trf_5024)
static void C_fcall trf_5024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5024(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5024(t0,t1,t2,t3);}

C_noret_decl(trf_4931)
static void C_fcall trf_4931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4931(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4931(t0,t1,t2);}

C_noret_decl(trf_4759)
static void C_fcall trf_4759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4759(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4759(t0,t1,t2,t3);}

C_noret_decl(trf_4753)
static void C_fcall trf_4753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4753(t0,t1,t2);}

C_noret_decl(trf_4698)
static void C_fcall trf_4698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4698(t0,t1);}

C_noret_decl(trf_4612)
static void C_fcall trf_4612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4612(t0,t1,t2);}

C_noret_decl(trf_4337)
static void C_fcall trf_4337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4337(t0,t1);}

C_noret_decl(trf_4547)
static void C_fcall trf_4547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4547(t0,t1);}

C_noret_decl(trf_4493)
static void C_fcall trf_4493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4493(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4493(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4180)
static void C_fcall trf_4180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4180(t0,t1);}

C_noret_decl(trf_4237)
static void C_fcall trf_4237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4237(t0,t1);}

C_noret_decl(trf_4033)
static void C_fcall trf_4033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4033(t0,t1);}

C_noret_decl(trf_3892)
static void C_fcall trf_3892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3892(t0,t1);}

C_noret_decl(trf_3889)
static void C_fcall trf_3889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3889(t0,t1);}

C_noret_decl(trf_3308)
static void C_fcall trf_3308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3308(t0,t1);}

C_noret_decl(trf_3413)
static void C_fcall trf_3413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3413(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3413(t0,t1,t2);}

C_noret_decl(trf_3439)
static void C_fcall trf_3439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3439(t0,t1);}

C_noret_decl(trf_3496)
static void C_fcall trf_3496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3496(t0,t1);}

C_noret_decl(trf_3361)
static void C_fcall trf_3361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3361(t0,t1);}

C_noret_decl(trf_3382)
static void C_fcall trf_3382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3382(t0,t1);}

C_noret_decl(trf_3267)
static void C_fcall trf_3267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3267(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3267(t0,t1,t2);}

C_noret_decl(trf_3235)
static void C_fcall trf_3235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3235(t0,t1);}

C_noret_decl(trf_2633)
static void C_fcall trf_2633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2633(t0,t1);}

C_noret_decl(trf_2642)
static void C_fcall trf_2642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2642(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2642(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2689)
static void C_fcall trf_2689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2689(t0,t1);}

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2582(t0,t1);}

C_noret_decl(trf_2430)
static void C_fcall trf_2430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2430(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2430(t0,t1,t2,t3);}

C_noret_decl(trf_2440)
static void C_fcall trf_2440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2440(t0,t1);}

C_noret_decl(trf_2449)
static void C_fcall trf_2449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2449(t0,t1);}

C_noret_decl(trf_2473)
static void C_fcall trf_2473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2473(t0,t1);}

C_noret_decl(trf_2348)
static void C_fcall trf_2348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2348(t0,t1,t2);}

C_noret_decl(trf_2376)
static void C_fcall trf_2376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2376(t0,t1);}

C_noret_decl(trf_2240)
static void C_fcall trf_2240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2240(t0,t1);}

C_noret_decl(trf_2135)
static void C_fcall trf_2135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2135(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2135(t0,t1,t2,t3);}

C_noret_decl(trf_2082)
static void C_fcall trf_2082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2082(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2082(t0,t1,t2);}

C_noret_decl(trf_2090)
static void C_fcall trf_2090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2090(t0,t1);}

C_noret_decl(trf_2035)
static void C_fcall trf_2035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2035(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2035(t0,t1);}

C_noret_decl(trf_1861)
static void C_fcall trf_1861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1861(t0,t1,t2);}

C_noret_decl(trf_1883)
static void C_fcall trf_1883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1883(t0,t1);}

C_noret_decl(trf_1890)
static void C_fcall trf_1890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1890(t0,t1);}

C_noret_decl(trf_1805)
static void C_fcall trf_1805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1805(t0,t1,t2,t3);}

C_noret_decl(trf_1673)
static void C_fcall trf_1673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1673(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1673(t0,t1,t2,t3);}

C_noret_decl(trf_1652)
static void C_fcall trf_1652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1652(t0,t1);}

C_noret_decl(trf_1612)
static void C_fcall trf_1612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1612(t0,t1,t2);}

C_noret_decl(trf_1537)
static void C_fcall trf_1537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1537(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5104)){
C_save(t1);
C_rereclaim2(5104*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,506);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\011\012CHICKEN\012");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000 (c)2000-2008 Felix L. Winkelmann");
lf[7]=C_h_intern(&lf[7],30,"\010compilercompiler-cleanup-hook");
lf[8]=C_h_intern(&lf[8],26,"\010compilerdebugging-chicken");
lf[9]=C_h_intern(&lf[9],26,"\010compilerdisabled-warnings");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_h_intern(&lf[11],5,"error");
lf[12]=C_h_intern(&lf[12],13,"string-append");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\034[internal compiler screwup] ");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\033[internal compiler screwup]");
lf[15]=C_h_intern(&lf[15],18,"\010compilerdebugging");
lf[16]=C_h_intern(&lf[16],12,"flush-output");
lf[17]=C_h_intern(&lf[17],7,"newline");
lf[18]=C_h_intern(&lf[18],6,"printf");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[20]=C_h_intern(&lf[20],5,"force");
lf[21]=C_h_intern(&lf[21],12,"\003sysfor-each");
lf[22]=C_h_intern(&lf[22],7,"display");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[25]=C_h_intern(&lf[25],25,"\010compilercompiler-warning");
lf[26]=C_h_intern(&lf[26],7,"fprintf");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[28]=C_h_intern(&lf[28],18,"current-error-port");
lf[29]=C_h_intern(&lf[29],20,"\003syswarnings-enabled");
lf[30]=C_h_intern(&lf[30],4,"quit");
lf[31]=C_h_intern(&lf[31],4,"exit");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[33]=C_h_intern(&lf[33],21,"\003syssyntax-error-hook");
lf[34]=C_h_intern(&lf[34],16,"print-call-chain");
lf[35]=C_h_intern(&lf[35],18,"\003syscurrent-thread");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[39]=C_h_intern(&lf[39],12,"syntax-error");
lf[40]=C_h_intern(&lf[40],31,"\010compileremit-syntax-trace-info");
lf[41]=C_h_intern(&lf[41],9,"map-llist");
lf[42]=C_h_intern(&lf[42],24,"\010compilercheck-signature");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[44]=C_h_intern(&lf[44],18,"\010compilerreal-name");
lf[45]=C_h_intern(&lf[45],13,"\010compilerposq");
lf[46]=C_h_intern(&lf[46],18,"\010compilerstringify");
lf[47]=C_h_intern(&lf[47],14,"symbol->string");
lf[48]=C_h_intern(&lf[48],7,"sprintf");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[50]=C_h_intern(&lf[50],18,"\010compilersymbolify");
lf[51]=C_h_intern(&lf[51],14,"string->symbol");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[53]=C_h_intern(&lf[53],26,"\010compilerbuild-lambda-list");
lf[54]=C_h_intern(&lf[54],29,"\010compilerstring->c-identifier");
lf[55]=C_h_intern(&lf[55],24,"\003sysstring->c-identifier");
lf[56]=C_h_intern(&lf[56],21,"\010compilerc-ify-string");
lf[57]=C_h_intern(&lf[57],16,"\003syslist->string");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[59]=C_h_intern(&lf[59],6,"append");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[61]=C_h_intern(&lf[61],16,"\003sysstring->list");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[65]=C_h_intern(&lf[65],28,"\010compilervalid-c-identifier\077");
lf[66]=C_h_intern(&lf[66],3,"any");
lf[67]=C_h_intern(&lf[67],8,"->string");
lf[68]=C_h_intern(&lf[68],14,"\010compilerwords");
lf[69]=C_h_intern(&lf[69],21,"\010compilerwords->bytes");
lf[70]=C_h_intern(&lf[70],34,"\010compilercheck-and-open-input-file");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[72]=C_h_intern(&lf[72],18,"current-input-port");
lf[73]=C_h_intern(&lf[73],15,"open-input-file");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[76]=C_h_intern(&lf[76],12,"file-exists\077");
lf[77]=C_h_intern(&lf[77],33,"\010compilerclose-checked-input-file");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[79]=C_h_intern(&lf[79],16,"close-input-port");
lf[80]=C_h_intern(&lf[80],19,"\010compilerfold-inner");
lf[81]=C_h_intern(&lf[81],7,"reverse");
lf[82]=C_h_intern(&lf[82],28,"\010compilerfollow-without-loop");
lf[83]=C_h_intern(&lf[83],18,"\010compilerconstant\077");
lf[84]=C_h_intern(&lf[84],5,"quote");
lf[85]=C_h_intern(&lf[85],29,"\010compilercollapsable-literal\077");
lf[86]=C_h_intern(&lf[86],19,"\010compilerimmediate\077");
lf[87]=C_h_intern(&lf[87],20,"\010compilerbig-fixnum\077");
lf[88]=C_h_intern(&lf[88],23,"\010compilerbasic-literal\077");
lf[89]=C_h_intern(&lf[89],5,"every");
lf[90]=C_h_intern(&lf[90],12,"vector->list");
lf[91]=C_h_intern(&lf[91],32,"\010compilercanonicalize-begin-body");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[94]=C_h_intern(&lf[94],3,"let");
lf[95]=C_h_intern(&lf[95],6,"gensym");
lf[96]=C_h_intern(&lf[96],1,"t");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[98]=C_h_intern(&lf[98],34,"\010compilerextract-mutable-constants");
lf[99]=C_h_intern(&lf[99],12,"\004coreinclude");
lf[100]=C_h_intern(&lf[100],9,"\004coreset!");
lf[101]=C_h_intern(&lf[101],5,"cons*");
lf[102]=C_h_intern(&lf[102],7,"\003sysmap");
lf[103]=C_h_intern(&lf[103],2,"if");
lf[104]=C_h_intern(&lf[104],20,"\004corecompiletimeonly");
lf[105]=C_h_intern(&lf[105],19,"\004corecompiletimetoo");
lf[106]=C_h_intern(&lf[106],4,"set!");
lf[107]=C_h_intern(&lf[107],6,"lambda");
lf[108]=C_h_intern(&lf[108],11,"\004coreinline");
lf[109]=C_h_intern(&lf[109],20,"\004coreinline_allocate");
lf[110]=C_h_intern(&lf[110],18,"\004coreinline_update");
lf[111]=C_h_intern(&lf[111],19,"\004coreinline_loc_ref");
lf[112]=C_h_intern(&lf[112],22,"\004coreinline_loc_update");
lf[113]=C_h_intern(&lf[113],12,"\004coredeclare");
lf[114]=C_h_intern(&lf[114],14,"\004coreimmutable");
lf[115]=C_h_intern(&lf[115],14,"\004coreundefined");
lf[116]=C_h_intern(&lf[116],14,"\004coreprimitive");
lf[117]=C_h_intern(&lf[117],15,"\004coreinline_ref");
lf[118]=C_h_intern(&lf[118],10,"alist-cons");
lf[119]=C_h_intern(&lf[119],25,"\010compilermake-random-name");
lf[120]=C_h_intern(&lf[120],3,"map");
lf[121]=C_h_intern(&lf[121],4,"caar");
lf[122]=C_h_intern(&lf[122],5,"cadar");
lf[123]=C_h_intern(&lf[123],5,"cddar");
lf[124]=C_h_intern(&lf[124],4,"cdar");
lf[125]=C_h_intern(&lf[125],21,"\010compilerstring->expr");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[128]=C_h_intern(&lf[128],5,"begin");
lf[129]=C_h_intern(&lf[129],4,"read");
lf[130]=C_h_intern(&lf[130],6,"unfold");
lf[131]=C_h_intern(&lf[131],11,"eof-object\077");
lf[132]=C_h_intern(&lf[132],6,"values");
lf[133]=C_h_intern(&lf[133],22,"with-input-from-string");
lf[134]=C_h_intern(&lf[134],22,"with-exception-handler");
lf[135]=C_h_intern(&lf[135],30,"call-with-current-continuation");
lf[136]=C_h_intern(&lf[136],30,"\010compilerdecompose-lambda-list");
lf[137]=C_h_intern(&lf[137],25,"\003sysdecompose-lambda-list");
lf[138]=C_h_intern(&lf[138],37,"\010compilerprocess-lambda-documentation");
lf[139]=C_h_intern(&lf[139],30,"\010compilerexpand-profile-lambda");
lf[140]=C_h_intern(&lf[140],29,"\010compilerprofile-lambda-index");
lf[141]=C_h_intern(&lf[141],28,"\010compilerprofile-lambda-list");
lf[142]=C_h_intern(&lf[142],17,"\003sysprofile-entry");
lf[143]=C_h_intern(&lf[143],33,"\010compilerprofile-info-vector-name");
lf[144]=C_h_intern(&lf[144],5,"apply");
lf[145]=C_h_intern(&lf[145],16,"\003sysprofile-exit");
lf[146]=C_h_intern(&lf[146],16,"\003sysdynamic-wind");
lf[147]=C_h_intern(&lf[147],37,"\010compilerinitialize-analysis-database");
lf[148]=C_h_intern(&lf[148],13,"\010compilerput!");
lf[149]=C_h_intern(&lf[149],8,"constant");
lf[150]=C_h_intern(&lf[150],26,"\010compilermutable-constants");
lf[151]=C_h_intern(&lf[151],35,"\010compilerfoldable-extended-bindings");
lf[152]=C_h_intern(&lf[152],8,"foldable");
lf[153]=C_h_intern(&lf[153],16,"extended-binding");
lf[154]=C_h_intern(&lf[154],17,"extended-bindings");
lf[155]=C_h_intern(&lf[155],35,"\010compilerfoldable-standard-bindings");
lf[156]=C_h_intern(&lf[156],41,"\010compilerside-effecting-standard-bindings");
lf[157]=C_h_intern(&lf[157],14,"side-effecting");
lf[158]=C_h_intern(&lf[158],16,"standard-binding");
lf[159]=C_h_intern(&lf[159],17,"standard-bindings");
lf[160]=C_h_intern(&lf[160],12,"\010compilerget");
lf[161]=C_h_intern(&lf[161],18,"\003syshash-table-ref");
lf[162]=C_h_intern(&lf[162],16,"\010compilerget-all");
lf[163]=C_h_intern(&lf[163],10,"filter-map");
lf[164]=C_h_intern(&lf[164],19,"\003syshash-table-set!");
lf[165]=C_h_intern(&lf[165],17,"\010compilercollect!");
lf[166]=C_h_intern(&lf[166],15,"\010compilercount!");
lf[167]=C_h_intern(&lf[167],17,"\010compilerget-line");
lf[168]=C_h_intern(&lf[168],24,"\003sysline-number-database");
lf[169]=C_h_intern(&lf[169],19,"\010compilerget-line-2");
lf[170]=C_h_intern(&lf[170],30,"\010compilerfind-lambda-container");
lf[171]=C_h_intern(&lf[171],12,"contained-in");
lf[172]=C_h_intern(&lf[172],37,"\010compilerdisplay-line-number-database");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[174]=C_h_intern(&lf[174],3,"cdr");
lf[175]=C_h_intern(&lf[175],23,"\003syshash-table-for-each");
lf[176]=C_h_intern(&lf[176],34,"\010compilerdisplay-analysis-database");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[181]=C_h_intern(&lf[181],7,"unknown");
lf[182]=C_h_intern(&lf[182],8,"captured");
lf[183]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[185]=C_h_intern(&lf[185],5,"value");
lf[186]=C_h_intern(&lf[186],15,"potential-value");
lf[187]=C_h_intern(&lf[187],10,"replacable");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[189]=C_h_intern(&lf[189],10,"references");
lf[190]=C_h_intern(&lf[190],10,"call-sites");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[192]=C_h_intern(&lf[192],4,"home");
lf[193]=C_h_intern(&lf[193],8,"contains");
lf[194]=C_h_intern(&lf[194],8,"use-expr");
lf[195]=C_h_intern(&lf[195],12,"closure-size");
lf[196]=C_h_intern(&lf[196],14,"rest-parameter");
lf[197]=C_h_intern(&lf[197],16,"o-r/access-count");
lf[198]=C_h_intern(&lf[198],18,"captured-variables");
lf[199]=C_h_intern(&lf[199],13,"explicit-rest");
lf[200]=C_h_intern(&lf[200],8,"assigned");
lf[201]=C_h_intern(&lf[201],5,"boxed");
lf[202]=C_h_intern(&lf[202],6,"global");
lf[203]=C_h_intern(&lf[203],12,"contractable");
lf[204]=C_h_intern(&lf[204],16,"assigned-locally");
lf[205]=C_h_intern(&lf[205],11,"collapsable");
lf[206]=C_h_intern(&lf[206],9,"removable");
lf[207]=C_h_intern(&lf[207],9,"undefined");
lf[208]=C_h_intern(&lf[208],9,"replacing");
lf[209]=C_h_intern(&lf[209],6,"unused");
lf[210]=C_h_intern(&lf[210],6,"simple");
lf[211]=C_h_intern(&lf[211],9,"inlinable");
lf[212]=C_h_intern(&lf[212],13,"inline-export");
lf[213]=C_h_intern(&lf[213],21,"has-unused-parameters");
lf[214]=C_h_intern(&lf[214],12,"customizable");
lf[215]=C_h_intern(&lf[215],10,"boxed-rest");
lf[216]=C_h_intern(&lf[216],5,"write");
lf[217]=C_h_intern(&lf[217],34,"\010compilerdefault-standard-bindings");
lf[218]=C_h_intern(&lf[218],34,"\010compilerdefault-extended-bindings");
lf[219]=C_h_intern(&lf[219],26,"\010compilerinternal-bindings");
lf[220]=C_h_intern(&lf[220],9,"make-node");
lf[221]=C_h_intern(&lf[221],4,"node");
lf[222]=C_h_intern(&lf[222],5,"node\077");
lf[223]=C_h_intern(&lf[223],15,"node-class-set!");
lf[224]=C_h_intern(&lf[224],14,"\003sysblock-set!");
lf[225]=C_h_intern(&lf[225],10,"node-class");
lf[226]=C_h_intern(&lf[226],20,"node-parameters-set!");
lf[227]=C_h_intern(&lf[227],15,"node-parameters");
lf[228]=C_h_intern(&lf[228],24,"node-subexpressions-set!");
lf[229]=C_h_intern(&lf[229],19,"node-subexpressions");
lf[230]=C_h_intern(&lf[230],16,"\010compilervarnode");
lf[231]=C_h_intern(&lf[231],13,"\004corevariable");
lf[232]=C_h_intern(&lf[232],14,"\010compilerqnode");
lf[233]=C_h_intern(&lf[233],25,"\010compilerbuild-node-graph");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[235]=C_h_intern(&lf[235],15,"\004coreglobal-ref");
lf[236]=C_h_intern(&lf[236],8,"truncate");
lf[237]=C_h_intern(&lf[237],4,"type");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[239]=C_h_intern(&lf[239],6,"fixnum");
lf[240]=C_h_intern(&lf[240],11,"number-type");
lf[241]=C_h_intern(&lf[241],6,"unzip1");
lf[242]=C_h_intern(&lf[242],13,"\004corecallunit");
lf[243]=C_h_intern(&lf[243],9,"\004coreproc");
lf[244]=C_h_intern(&lf[244],29,"\004coreforeign-callback-wrapper");
lf[245]=C_h_intern(&lf[245],5,"sixth");
lf[246]=C_h_intern(&lf[246],5,"fifth");
lf[247]=C_h_intern(&lf[247],8,"\004coreapp");
lf[248]=C_h_intern(&lf[248],9,"\004corecall");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[250]=C_h_intern(&lf[250],24,"\010compilersource-filename");
lf[251]=C_h_intern(&lf[251],28,"\003syssymbol->qualified-string");
lf[252]=C_h_intern(&lf[252],34,"\010compileralways-bound-to-procedure");
lf[253]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[254]=C_h_intern(&lf[254],1,"o");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[256]=C_h_intern(&lf[256],30,"\010compilerbuild-expression-tree");
lf[257]=C_h_intern(&lf[257],12,"\004coreclosure");
lf[258]=C_h_intern(&lf[258],4,"last");
lf[259]=C_h_intern(&lf[259],4,"list");
lf[260]=C_h_intern(&lf[260],7,"butlast");
lf[261]=C_h_intern(&lf[261],11,"\004corelambda");
lf[262]=C_h_intern(&lf[262],9,"\004corebind");
lf[263]=C_h_intern(&lf[263],10,"\004coreunbox");
lf[264]=C_h_intern(&lf[264],8,"\004coreref");
lf[265]=C_h_intern(&lf[265],11,"\004coreupdate");
lf[266]=C_h_intern(&lf[266],13,"\004coreupdate_i");
lf[267]=C_h_intern(&lf[267],8,"\004corebox");
lf[268]=C_h_intern(&lf[268],9,"\004corecond");
lf[269]=C_h_intern(&lf[269],21,"\010compilerfold-boolean");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[271]=C_h_intern(&lf[271],31,"\010compilerinline-lambda-bindings");
lf[272]=C_h_intern(&lf[272],8,"split-at");
lf[273]=C_h_intern(&lf[273],10,"fold-right");
lf[274]=C_h_intern(&lf[274],4,"take");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[276]=C_h_intern(&lf[276],34,"\010compilercopy-node-tree-and-rename");
lf[277]=C_h_intern(&lf[277],9,"alist-ref");
lf[278]=C_h_intern(&lf[278],3,"eq\077");
lf[279]=C_h_intern(&lf[279],18,"\010compilertree-copy");
lf[280]=C_h_intern(&lf[280],4,"cons");
lf[281]=C_h_intern(&lf[281],19,"\010compilercopy-node!");
lf[282]=C_h_intern(&lf[282],19,"\010compilermatch-node");
lf[283]=C_h_intern(&lf[283],1,"a");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[285]=C_h_intern(&lf[285],37,"\010compilerexpression-has-side-effects\077");
lf[286]=C_h_intern(&lf[286],24,"foreign-callback-stub-id");
lf[287]=C_h_intern(&lf[287],4,"find");
lf[288]=C_h_intern(&lf[288],22,"foreign-callback-stubs");
lf[289]=C_h_intern(&lf[289],28,"\010compilersimple-lambda-node\077");
lf[290]=C_h_intern(&lf[290],25,"\010compilerexport-dump-hook");
lf[291]=C_h_intern(&lf[291],30,"\010compilerdump-exported-globals");
lf[292]=C_h_intern(&lf[292],26,"\010compilerblock-compilation");
lf[293]=C_h_intern(&lf[293],8,"string<\077");
lf[294]=C_h_intern(&lf[294],4,"sort");
lf[295]=C_h_intern(&lf[295],20,"\010compilerexport-list");
lf[296]=C_h_intern(&lf[296],22,"\010compilerblock-globals");
lf[297]=C_h_intern(&lf[297],19,"with-output-to-file");
lf[298]=C_h_intern(&lf[298],31,"\010compilerdump-undefined-globals");
lf[299]=C_h_intern(&lf[299],29,"\010compilercheck-global-exports");
lf[300]=C_h_intern(&lf[300],3,"var");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000,exported global variable `~S\047 is not defined");
lf[302]=C_h_intern(&lf[302],6,"delete");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\0005exported global variable `~S\047 is used but not defined");
lf[304]=C_h_intern(&lf[304],29,"\010compilercheck-global-imports");
lf[305]=C_h_intern(&lf[305],5,"redef");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\0000redefinition of imported variable `~s\047 from `~s\047");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000#variable `~s\047 used but not imported");
lf[308]=C_h_intern(&lf[308],8,"keyword\077");
lf[309]=C_h_intern(&lf[309],21,"\010compilerimport-table");
lf[310]=C_h_intern(&lf[310],27,"\010compilerexport-import-hook");
lf[311]=C_h_intern(&lf[311],28,"\010compilerlookup-exports-file");
lf[312]=C_h_intern(&lf[312],9,"read-file");
lf[313]=C_h_intern(&lf[313],21,"\010compilerverbose-mode");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\035loading exports file ~a ...~%");
lf[315]=C_h_intern(&lf[315],28,"\003sysresolve-include-filename");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\010.exports");
lf[317]=C_h_intern(&lf[317],36,"\010compilercompute-database-statistics");
lf[318]=C_h_intern(&lf[318],29,"\010compilercurrent-program-size");
lf[319]=C_h_intern(&lf[319],30,"\010compileroriginal-program-size");
lf[320]=C_h_intern(&lf[320],33,"\010compilerprint-program-statistics");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[327]=C_h_intern(&lf[327],1,"s");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[329]=C_h_intern(&lf[329],35,"\010compilerpprint-expressions-to-file");
lf[330]=C_h_intern(&lf[330],17,"close-output-port");
lf[331]=C_h_intern(&lf[331],12,"pretty-print");
lf[332]=C_h_intern(&lf[332],19,"with-output-to-port");
lf[333]=C_h_intern(&lf[333],16,"open-output-file");
lf[334]=C_h_intern(&lf[334],19,"current-output-port");
lf[335]=C_h_intern(&lf[335],27,"\010compilerforeign-type-check");
lf[336]=C_h_intern(&lf[336],4,"char");
lf[337]=C_h_intern(&lf[337],13,"unsigned-char");
lf[338]=C_h_intern(&lf[338],6,"unsafe");
lf[339]=C_h_intern(&lf[339],25,"\003sysforeign-char-argument");
lf[340]=C_h_intern(&lf[340],3,"int");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-fixnum-argument");
lf[342]=C_h_intern(&lf[342],5,"float");
lf[343]=C_h_intern(&lf[343],27,"\003sysforeign-flonum-argument");
lf[344]=C_h_intern(&lf[344],7,"pointer");
lf[345]=C_h_intern(&lf[345],26,"\003sysforeign-block-argument");
lf[346]=C_h_intern(&lf[346],15,"nonnull-pointer");
lf[347]=C_h_intern(&lf[347],8,"u8vector");
lf[348]=C_h_intern(&lf[348],34,"\003sysforeign-number-vector-argument");
lf[349]=C_h_intern(&lf[349],16,"nonnull-u8vector");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[351]=C_h_intern(&lf[351],7,"integer");
lf[352]=C_h_intern(&lf[352],28,"\003sysforeign-integer-argument");
lf[353]=C_h_intern(&lf[353],16,"unsigned-integer");
lf[354]=C_h_intern(&lf[354],37,"\003sysforeign-unsigned-integer-argument");
lf[355]=C_h_intern(&lf[355],9,"c-pointer");
lf[356]=C_h_intern(&lf[356],28,"\003sysforeign-pointer-argument");
lf[357]=C_h_intern(&lf[357],17,"nonnull-c-pointer");
lf[358]=C_h_intern(&lf[358],8,"c-string");
lf[359]=C_h_intern(&lf[359],17,"\003sysmake-c-string");
lf[360]=C_h_intern(&lf[360],27,"\003sysforeign-string-argument");
lf[361]=C_h_intern(&lf[361],16,"nonnull-c-string");
lf[362]=C_h_intern(&lf[362],6,"symbol");
lf[363]=C_h_intern(&lf[363],18,"\003syssymbol->string");
lf[364]=C_h_intern(&lf[364],4,"this");
lf[365]=C_h_intern(&lf[365],8,"slot-ref");
lf[366]=C_h_intern(&lf[366],3,"ref");
lf[367]=C_h_intern(&lf[367],8,"function");
lf[368]=C_h_intern(&lf[368],8,"instance");
lf[369]=C_h_intern(&lf[369],12,"instance-ref");
lf[370]=C_h_intern(&lf[370],16,"nonnull-instance");
lf[371]=C_h_intern(&lf[371],5,"const");
lf[372]=C_h_intern(&lf[372],4,"enum");
lf[373]=C_h_intern(&lf[373],27,"\010compilerforeign-type-table");
lf[374]=C_h_intern(&lf[374],17,"nonnull-c-string*");
lf[375]=C_h_intern(&lf[375],26,"nonnull-unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],9,"c-string*");
lf[377]=C_h_intern(&lf[377],18,"unsigned-c-string*");
lf[378]=C_h_intern(&lf[378],13,"c-string-list");
lf[379]=C_h_intern(&lf[379],14,"c-string-list*");
lf[380]=C_h_intern(&lf[380],18,"unsigned-integer32");
lf[381]=C_h_intern(&lf[381],13,"unsigned-long");
lf[382]=C_h_intern(&lf[382],4,"long");
lf[383]=C_h_intern(&lf[383],9,"integer32");
lf[384]=C_h_intern(&lf[384],17,"nonnull-u16vector");
lf[385]=C_h_intern(&lf[385],16,"nonnull-s8vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s16vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-u32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-s32vector");
lf[389]=C_h_intern(&lf[389],17,"nonnull-f32vector");
lf[390]=C_h_intern(&lf[390],17,"nonnull-f64vector");
lf[391]=C_h_intern(&lf[391],9,"u16vector");
lf[392]=C_h_intern(&lf[392],8,"s8vector");
lf[393]=C_h_intern(&lf[393],9,"s16vector");
lf[394]=C_h_intern(&lf[394],9,"u32vector");
lf[395]=C_h_intern(&lf[395],9,"s32vector");
lf[396]=C_h_intern(&lf[396],9,"f32vector");
lf[397]=C_h_intern(&lf[397],9,"f64vector");
lf[398]=C_h_intern(&lf[398],22,"nonnull-scheme-pointer");
lf[399]=C_h_intern(&lf[399],12,"nonnull-blob");
lf[400]=C_h_intern(&lf[400],19,"nonnull-byte-vector");
lf[401]=C_h_intern(&lf[401],11,"byte-vector");
lf[402]=C_h_intern(&lf[402],4,"blob");
lf[403]=C_h_intern(&lf[403],14,"scheme-pointer");
lf[404]=C_h_intern(&lf[404],6,"double");
lf[405]=C_h_intern(&lf[405],6,"number");
lf[406]=C_h_intern(&lf[406],12,"unsigned-int");
lf[407]=C_h_intern(&lf[407],5,"short");
lf[408]=C_h_intern(&lf[408],14,"unsigned-short");
lf[409]=C_h_intern(&lf[409],4,"byte");
lf[410]=C_h_intern(&lf[410],13,"unsigned-byte");
lf[411]=C_h_intern(&lf[411],5,"int32");
lf[412]=C_h_intern(&lf[412],14,"unsigned-int32");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[414]=C_h_intern(&lf[414],36,"\010compilerforeign-type-convert-result");
lf[415]=C_h_intern(&lf[415],38,"\010compilerforeign-type-convert-argument");
lf[416]=C_h_intern(&lf[416],27,"\010compilerfinal-foreign-type");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[418]=C_h_intern(&lf[418],37,"\010compilerestimate-foreign-result-size");
lf[419]=C_h_intern(&lf[419],9,"integer64");
lf[420]=C_h_intern(&lf[420],4,"bool");
lf[421]=C_h_intern(&lf[421],4,"void");
lf[422]=C_h_intern(&lf[422],13,"scheme-object");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[424]=C_h_intern(&lf[424],46,"\010compilerestimate-foreign-result-location-size");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[427]=C_h_intern(&lf[427],30,"\010compilerfinish-foreign-result");
lf[428]=C_h_intern(&lf[428],17,"\003syspeek-c-string");
lf[429]=C_h_intern(&lf[429],25,"\003syspeek-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],26,"\003syspeek-and-free-c-string");
lf[431]=C_h_intern(&lf[431],34,"\003syspeek-and-free-nonnull-c-string");
lf[432]=C_h_intern(&lf[432],17,"\003sysintern-symbol");
lf[433]=C_h_intern(&lf[433],22,"\003syspeek-c-string-list");
lf[434]=C_h_intern(&lf[434],31,"\003syspeek-and-free-c-string-list");
lf[435]=C_h_intern(&lf[435],35,"\010tinyclosmake-instance-from-pointer");
lf[436]=C_h_intern(&lf[436],4,"make");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-used-variables");
lf[438]=C_h_intern(&lf[438],28,"\010compilerscan-free-variables");
lf[439]=C_h_intern(&lf[439],11,"lset-adjoin");
lf[440]=C_h_intern(&lf[440],25,"\010compilertopological-sort");
lf[441]=C_h_intern(&lf[441],7,"colored");
lf[442]=C_h_intern(&lf[442],23,"\010compilerchop-separator");
lf[443]=C_h_intern(&lf[443],9,"substring");
lf[444]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[445]=C_h_intern(&lf[445],23,"\010compilerchop-extension");
lf[446]=C_h_intern(&lf[446],22,"\010compilerprint-version");
lf[447]=C_h_intern(&lf[447],5,"print");
lf[448]=C_h_intern(&lf[448],15,"chicken-version");
lf[449]=C_h_intern(&lf[449],6,"print*");
lf[450]=C_h_intern(&lf[450],9,"\003syserror");
lf[451]=C_h_intern(&lf[451],20,"\010compilerprint-usage");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\021\244Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012    -quiet               "
"       do not display compile information\012\012  File and pathname options:\012\012    -ou"
"tput-file FILENAME       specifies output-filename, default is \047out.c\047\012    -incl"
"ude-path PATHNAME      specifies alternative path for included files\012    -to-std"
"out                  write compiled file to stdout instead of file\012\012  Language o"
"ptions:\012\012    -feature SYMBOL             register feature identifier\012\012  Syntax r"
"elated options:\012\012    -case-insensitive           don\047t preserve case of read sym"
"bols\012    -keyword-style STYLE        allow alternative keyword syntax (none, pre"
"fix or suffix)\012    -run-time-macros            macros are made available at run-"
"time\012\012  Translation options:\012\012    -explicit-use               do not use units \047"
"library\047 and \047eval\047 by default\012    -check-syntax               stop compilation "
"after macro-expansion\012    -analyze-only               stop compilation after fir"
"st analysis pass\012\012  Debugging options:\012\012    -no-warnings                disable "
"warnings\012    -disable-warning CLASS      disable specific class of warnings\012    "
"-debug-level NUMBER         set level of available debugging information\012    -no"
"-trace                   disable tracing information\012    -profile               "
"     executable emits profiling information \012    -profile-name FILENAME      nam"
"e of the generated profile information file\012    -accumulate-profile         exec"
"utable emits profiling information in append mode\012    -no-lambda-info           "
"  omit additional procedure-information\012    -emit-exports FILENAME      write ex"
"ported toplevel variables to FILENAME\012    -check-imports              look for u"
"ndefined toplevel variables\012    -import FILENAME            read externally expo"
"rted symbols from FILENAME\012\012  Optimization options:\012\012    -optimize-level NUMBER "
"     enable certain sets of optimization options\012    -optimize-leaf-routines    "
" enable leaf routine optimization\012    -lambda-lift                enable lambda-"
"lifting\012    -no-usual-integrations      standard procedures may be redefined\012   "
" -unsafe                     disable safety checks\012    -block                   "
"   enable block-compilation\012    -disable-interrupts         disable interrupts i"
"n compiled code\012    -fixnum-arithmetic          assume all numbers are fixnums\012 "
"   -benchmark-mode             fixnum mode, no interrupts and opt.-level 3\012    -"
"disable-stack-overflow-checks  disables detection of stack-overflows.\012    -inlin"
"e                     enable inlining\012    -inline-limit               set inlini"
"ng threshold\012\012  Configuration options:\012\012    -unit NAME                  compile "
"file as a library unit\012    -uses NAME                  declare library unit as u"
"sed.\012    -heap-size NUMBER           specifies heap-size of compiled executable\012"
"    -heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-gr"
"owth PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage "
"PERCENTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER\012    -s"
"tack-size NUMBER          specifies nursery size of compiled executable\012    -ext"
"end FILENAME            load file before compilation commences\012    -prelude EXPR"
"ESSION         add expression to front of source file\012    -postlude EXPRESSION  "
"      add expression to end of source file\012    -prologue FILENAME          inclu"
"de file before main source file\012    -epilogue FILENAME          include file aft"
"er main source file\012    -dynamic                    compile as dynamically loada"
"ble code\012    -require-extension NAME     require extension NAME in compiled code"
"\012    -extension                  compile as extension (dynamic or static)\012\012  Obs"
"cure options:\012\012    -debug MODES                display debugging output for the "
"given modes\012    -unsafe-libraries           marks the generated file as being li"
"nked\012                                with the unsafe runtime system\012    -raw    "
"                    do not generate implicit init- and exit code\011\011\011       \012    -"
"emit-external-prototypes-first  emit protoypes for callbacks before foreign\012    "
"                            declarations\012");
lf[453]=C_h_intern(&lf[453],36,"\010compilermake-block-variable-literal");
lf[454]=C_h_intern(&lf[454],22,"block-variable-literal");
lf[455]=C_h_intern(&lf[455],32,"\010compilerblock-variable-literal\077");
lf[456]=C_h_intern(&lf[456],32,"block-variable-literal-name-set!");
lf[457]=C_h_intern(&lf[457],36,"\010compilerblock-variable-literal-name");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[459]=C_h_intern(&lf[459],6,"random");
lf[460]=C_h_intern(&lf[460],15,"current-seconds");
lf[461]=C_h_intern(&lf[461],23,"\010compilerset-real-name!");
lf[462]=C_h_intern(&lf[462],24,"\010compilerreal-name-table");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[464]=C_h_intern(&lf[464],19,"\010compilerreal-name2");
lf[465]=C_h_intern(&lf[465],32,"\010compilerdisplay-real-name-table");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[467]=C_h_intern(&lf[467],28,"\010compilersource-info->string");
lf[468]=C_h_intern(&lf[468],4,"conc");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[471]=C_h_intern(&lf[471],11,"make-string");
lf[472]=C_h_intern(&lf[472],3,"max");
lf[473]=C_h_intern(&lf[473],12,"string-null\077");
lf[474]=C_h_intern(&lf[474],19,"\010compilerdump-nodes");
lf[475]=C_h_intern(&lf[475],19,"\003syswrite-char/port");
lf[476]=C_h_intern(&lf[476],19,"\003sysstandard-output");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[480]=C_h_intern(&lf[480],18,"\003sysuser-read-hook");
lf[481]=C_h_intern(&lf[481],15,"foreign-declare");
lf[482]=C_h_intern(&lf[482],7,"declare");
lf[483]=C_h_intern(&lf[483],34,"\010compilerscan-sharp-greater-string");
lf[484]=C_h_intern(&lf[484],18,"\003sysread-char/port");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[486]=C_h_intern(&lf[486],17,"get-output-string");
lf[487]=C_h_intern(&lf[487],18,"open-output-string");
lf[488]=C_h_intern(&lf[488],35,"\010compilerprocess-custom-declaration");
lf[489]=C_h_intern(&lf[489],29,"\010compilercustom-declare-alist");
lf[490]=C_h_intern(&lf[490],31,"\010compileremit-control-file-item");
lf[491]=C_h_intern(&lf[491],25,"\010compilercsc-control-file");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\004~S~%");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\006#%csc\012");
lf[494]=C_h_intern(&lf[494],26,"pathname-replace-extension");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[496]=C_h_intern(&lf[496],32,"\010compilerregister-compiler-macro");
lf[497]=C_h_intern(&lf[497],29,"\010compilercompiler-macro-table");
lf[498]=C_h_intern(&lf[498],4,"eval");
lf[499]=C_h_intern(&lf[499],6,"\000whole");
lf[500]=C_h_intern(&lf[500],7,"call/cc");
lf[501]=C_h_intern(&lf[501],11,"make-vector");
lf[502]=C_h_intern(&lf[502],27,"condition-property-accessor");
lf[503]=C_h_intern(&lf[503],3,"exn");
lf[504]=C_h_intern(&lf[504],7,"message");
lf[505]=C_h_intern(&lf[505],19,"condition-predicate");
C_register_lf2(lf,506,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1443 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1446 in k1443 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1449 in k1446 in k1443 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate(&lf[3],lf[4]);
t4=C_mutate(&lf[5],lf[6]);
t5=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1458,tmp=(C_word)a,a+=2,tmp));
t6=C_set_block_item(lf[8],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[9],0,C_SCHEME_END_OF_LIST);
t8=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1463,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1490,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1530,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1559,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1578,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[39]+1,C_retrieve(lf[33]));
t14=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1603,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1606,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1649,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1717,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1753,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1774,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1799,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[54]+1,C_retrieve(lf[55]));
t22=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1843,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1937,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1993,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2000,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2007,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2054,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2066,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2129,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2160,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2206,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2236,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2282,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2342,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2425,tmp=(C_word)a,a+=2,tmp));
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 318  condition-predicate */
t37=C_retrieve(lf[505]);
((C_proc3)C_retrieve_proc(t37))(3,t37,t36,lf[503]);}

/* k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 319  condition-property-accessor */
t3=C_retrieve(lf[502]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[503],lf[504]);}

/* k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[136]+1,C_retrieve(lf[137]));
t4=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2903,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2906,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[147]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2963,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3024,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3042,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3060,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3106,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[166]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3158,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3215,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3225,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3261,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3285,tmp=(C_word)a,a+=2,tmp));
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3714,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3720,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3726,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3735,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3744,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3753,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3762,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3771,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3780,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3786,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3795,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3804,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4312,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4606,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4654,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4747,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4925,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[281]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4959,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5021,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5216,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5302,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[290]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5394,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[291]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5400,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5486,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5517,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5561,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5619,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5625,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5676,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5756,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5795,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5831,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6686,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6717,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6748,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6788,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7107,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[427]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7417,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[437]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7693,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7771,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7930,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[442]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8127,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[445]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8156,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[446]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8198,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[451]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8236,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[453]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8248,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[455]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8254,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[456]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8260,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[457]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8269,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8278,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[461]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8322,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8328,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[464]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8407,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[465]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8419,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[467]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8431,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[473]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8507,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[474]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8513,tmp=(C_word)a,a+=2,tmp));
t76=C_retrieve(lf[480]);
t77=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8600,a[2]=t76,tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[483]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8625,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[488]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8694,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[490]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8757,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[496]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8786,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8897,tmp=(C_word)a,a+=2,tmp));
t83=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t83+1)))(2,t83,C_SCHEME_UNDEFINED);}

/* ##compiler#big-fixnum? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8897,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8786,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8790,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[497]))){
t6=t5;
f_8790(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8895,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1493 make-vector */
t7=*((C_word*)lf[501]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k8893 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[497]+1,t1);
t3=((C_word*)t0)[2];
f_8790(t3,t2);}

/* k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8790,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1494 call/cc */
t3=*((C_word*)lf[500]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8795,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8799,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1496 gensym */
t4=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8797 in a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8799,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8802,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8835,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8835(t8,t4,((C_word*)t0)[2]);}

/* loop in k8797 in a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8835(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8835,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[499],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8851,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=t5;
f_8851(2,t7,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 1502 return */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8879,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* support.scm: 1505 loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8877 in loop in k8797 in a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8879,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8849 in loop in k8797 in a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cddr(((C_word*)t0)[4]));}

/* k8800 in k8797 in a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8805,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8809,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)((C_word*)t0)[3])[1]);
t5=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,lf[107],t5);
t7=(C_word)C_a_i_list(&a,2,lf[174],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_a_i_list(&a,3,lf[144],t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[107],t4,t8);
/* support.scm: 1509 eval */
t10=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,t9);}

/* k8807 in k8800 in k8797 in a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1506 ##sys#hash-table-set! */
t2=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[497]),((C_word*)t0)[2],t1);}

/* k8803 in k8800 in k8797 in a8794 in k8788 in ##compiler#register-compiler-macro in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#emit-control-file-item in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8757,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8761,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[491]))){
t4=t3;
f_8761(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8768,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8784,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1479 pathname-replace-extension */
t6=C_retrieve(lf[494]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[250]),lf[495]);}}

/* k8782 in ##compiler#emit-control-file-item in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1479 open-output-file */
t2=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8766 in ##compiler#emit-control-file-item in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8768,2,t0,t1);}
t2=C_mutate((C_word*)lf[491]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8771,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1480 display */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[493],C_retrieve(lf[491]));}

/* k8769 in k8766 in ##compiler#emit-control-file-item in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8771,2,t0,t1);}
t2=C_retrieve(lf[7]);
t3=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8773,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
f_8761(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k8769 in k8766 in ##compiler#emit-control-file-item in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8777,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1484 close-output-port */
t3=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[491]));}

/* k8775 in ##compiler#compiler-cleanup-hook in k8769 in k8766 in ##compiler#emit-control-file-item in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1485 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8759 in ##compiler#emit-control-file-item in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1486 fprintf */
t2=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[491]),lf[492],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8694,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[489]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8716,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_8716(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8731,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1466 open-output-file */
t14=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k8729 in ##compiler#process-custom-declaration in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8731,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[489]));
t5=C_mutate((C_word*)lf[489]+1,t4);
t6=C_retrieve(lf[7]);
t7=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8741,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8755,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1474 cons* */
t9=C_retrieve(lf[101]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8753 in k8729 in ##compiler#process-custom-declaration in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1474 emit-control-file-item */
t2=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_8741 in k8729 in ##compiler#process-custom-declaration in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8745,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1472 close-output-port */
t3=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8743 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1473 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8714 in ##compiler#process-custom-declaration in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8716,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[22]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8724,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a8720 in k8714 in ##compiler#process-custom-declaration in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8724,3,t0,t1,t2);}
/* support.scm: 1475 g1306 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8625,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8629,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1436 open-output-string */
t4=C_retrieve(lf[487]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8629,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8634,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8634(t5,((C_word*)t0)[2]);}

/* loop in k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8634,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[484]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8636 in loop in k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8638,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1439 quit */
t2=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[485]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8656,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1441 newline */
t3=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8668,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[484]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8689,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k8687 in k8636 in loop in k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1453 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8634(t2,((C_word*)t0)[2]);}

/* k8666 in k8636 in loop in k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8668,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1446 get-output-string */
t3=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8680,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k8678 in k8666 in k8636 in loop in k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8683,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8681 in k8678 in k8666 in k8636 in loop in k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1450 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8634(t2,((C_word*)t0)[2]);}

/* k8654 in k8636 in loop in k8627 in ##compiler#scan-sharp-greater-string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1442 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8634(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8600,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8610,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[484]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1433 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k8608 in ##sys#user-read-hook in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1431 scan-sharp-greater-string */
t3=C_retrieve(lf[483]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8611 in k8608 in ##sys#user-read-hook in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8613,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[481],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[482],t2));}

/* ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8513,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8517,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8522,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8522(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8522(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8522,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8535,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1409 make-string */
t11=*((C_word*)lf[471]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t2,C_make_character(32));}

/* k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8535,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8541,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1411 printf */
t4=C_retrieve(lf[18]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[479],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8593 in k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8594,3,t0,t1,t2);}
/* loop1251 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8522(t3,t1,((C_word*)t0)[2],t2);}

/* k8542 in k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8544,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8550,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8559,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1415 printf */
t6=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[478],t5);}
else{
t4=t3;
f_8550(2,t4,C_SCHEME_UNDEFINED);}}

/* k8557 in k8542 in k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8567,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8567(t6,t2,C_fix(5));}

/* do1265 in k8557 in k8542 in k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8567,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8577,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1418 printf */
t5=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[477],t4);}}

/* k8575 in do1265 in k8557 in k8542 in k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8567(t3,((C_word*)t0)[2],t2);}

/* k8560 in k8557 in k8542 in k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[476]+1));}

/* k8548 in k8542 in k8539 in k8533 in loop in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[476]+1));}

/* k8515 in ##compiler#dump-nodes in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1421 newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8507,3,t0,t1,t2);}
/* support.scm: 1399 string-null? */
t3=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#source-info->string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8431,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8438,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cdddr(t2);
t7=t3;
f_8438(t7,(C_word)C_i_nullp(t6));}
else{
t6=t3;
f_8438(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8438(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8438(t4,C_SCHEME_FALSE);}}

/* k8436 in ##compiler#source-info->string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8438,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8450,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1392 ->string */
t6=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* ->string */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k8448 in k8436 in ##compiler#source-info->string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8457,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1393 max */
t6=*((C_word*)lf[472]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k8459 in k8448 in k8436 in ##compiler#source-info->string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1393 make-string */
t2=*((C_word*)lf[471]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k8455 in k8448 in k8436 in ##compiler#source-info->string in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1393 conc */
t2=C_retrieve(lf[468]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[469],((C_word*)t0)[3],t1,lf[470],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8425,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1384 ##sys#hash-table-for-each */
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[462]));}

/* a8424 in ##compiler#display-real-name-table in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8425,4,t0,t1,t2,t3);}
/* support.scm: 1386 printf */
t4=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[466],t2,t3);}

/* ##compiler#real-name2 in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8407,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8411,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1380 ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[462]),t2);}

/* k8409 in ##compiler#real-name2 in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1381 real-name */
t2=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8328(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8328r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8328r(t0,t1,t2,t3);}}

static void C_ccall f_8328r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8331,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8347,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1364 resolve */
f_8331(t5,t2);}

/* k8345 in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8347,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1368 ##sys#symbol->qualified-string */
t5=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
/* support.scm: 1377 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1365 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8370 in k8345 in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8376,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1369 get */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[171]);}

/* k8374 in k8370 in k8345 in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8376,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8378(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k8374 in k8370 in k8345 in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8378(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8378,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1371 resolve */
f_8331(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k8383 in loop in k8374 in k8370 in k8345 in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8385,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8398,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1374 sprintf */
t4=C_retrieve(lf[48]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[463],((C_word*)t0)[4],t1);}}

/* k8396 in k8383 in loop in k8374 in k8370 in k8345 in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8402,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1375 get */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[171]);}

/* k8400 in k8396 in k8383 in loop in k8374 in k8370 in k8345 in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1374 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8378(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8331(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8331,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8335,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1359 ##sys#hash-table-ref */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[462]),t2);}

/* k8333 in resolve in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8335,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8341,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1361 ##sys#hash-table-ref */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[462]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k8339 in k8333 in resolve in ##compiler#real-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8322,4,t0,t1,t2,t3);}
/* support.scm: 1355 ##sys#hash-table-set! */
t4=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[462]),t2,t3);}

/* ##compiler#make-random-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_8278r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8278r(t0,t1,t2);}}

static void C_ccall f_8278r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8286,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8290,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1342 gensym */
t5=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_8290(2,t6,(C_word)C_i_car(t2));}
else{
/* support.scm: 1342 ##sys#error */
t6=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k8288 in ##compiler#make-random-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8294,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1343 current-seconds */
t3=C_retrieve(lf[460]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8292 in k8288 in ##compiler#make-random-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8298,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1344 random */
t3=C_retrieve(lf[459]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k8296 in k8292 in k8288 in ##compiler#make-random-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1341 sprintf */
t2=C_retrieve(lf[48]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[458],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8284 in ##compiler#make-random-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1340 string->symbol */
t2=*((C_word*)lf[51]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8269,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[454]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* block-variable-literal-name-set! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8260,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[454]);
/* support.scm: 1333 ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* ##compiler#block-variable-literal? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8254,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[454]));}

/* ##compiler#make-block-variable-literal in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8248,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[454],t2));}

/* ##compiler#print-usage in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8240,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1232 print-version */
t3=C_retrieve(lf[446]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8238 in ##compiler#print-usage in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1233 newline */
t3=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8241 in k8238 in ##compiler#print-usage in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1234 display */
t2=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[452]);}

/* ##compiler#print-version in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8198(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_8198r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8198r(t0,t1,t2);}}

static void C_ccall f_8198r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8202,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_8202(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_8202(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k8200 in ##compiler#print-version in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1228 print* */
t3=*((C_word*)lf[449]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[4]);}
else{
t3=t2;
f_8205(2,t3,C_SCHEME_UNDEFINED);}}

/* k8203 in k8200 in ##compiler#print-version in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1229 chicken-version */
t3=C_retrieve(lf[448]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k8210 in k8203 in k8200 in ##compiler#print-version in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1229 print */
t2=*((C_word*)lf[447]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8156,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8165,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8165(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8165(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8165,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1221 substring */
t6=*((C_word*)lf[443]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1222 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8127,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8137,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_8137(t7,(C_word)C_i_memq(t6,lf[444]));}
else{
t6=t5;
f_8137(t6,C_SCHEME_FALSE);}}

/* k8135 in ##compiler#chop-separator in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1214 substring */
t2=*((C_word*)lf[443]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7930,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7939,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7986,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8021,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8058,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8109,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a8108 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8109,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1196 insert */
t5=((C_word*)t0)[2];
f_7939(t5,t1,t3,t4);}

/* k8056 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8103,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1199 caar */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k8101 in k8056 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8107,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1199 cdar */
t3=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8105 in k8101 in k8056 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1199 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8021(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8059 in k8056 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8064,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a8065 in k8059 in k8056 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8066,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8070,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1201 lookup */
t5=((C_word*)t0)[2];
f_7986(t5,t3,t4);}

/* k8068 in a8065 in k8059 in k8056 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[441]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1203 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8021(t5,((C_word*)t0)[4],t3,t4);}}

/* k8062 in k8059 in k8056 in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_8021(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8021,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8025,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1184 insert */
t5=((C_word*)t0)[2];
f_7939(t5,t4,t2,lf[441]);}

/* k8023 in visit in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8028,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8033 in k8023 in visit in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8034,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8038,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1187 lookup */
t4=((C_word*)t0)[2];
f_7986(t4,t3,t2);}

/* k8036 in a8033 in k8023 in visit in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[441]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1189 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8021(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k8026 in k8023 in visit in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8028,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7986,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7992,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7992(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7992,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8005,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8019,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1179 caar */
t5=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k8017 in loop in lookup in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1179 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8003 in loop in lookup in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_8005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1179 cdar */
t2=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1180 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7992(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7939(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7939,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7945,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7945(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7945(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7945,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1173 caar */
t5=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7982 in loop in insert in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1173 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7964 in loop in insert in ##compiler#topological-sort in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1174 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7945(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7771,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7774,a[2]=t8,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7915,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7928,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1156 walk */
t12=((C_word*)t6)[1];
f_7774(t12,t11,t2,C_SCHEME_END_OF_LIST);}

/* k7926 in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7915(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7915,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7921,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a7920 in walkeach in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7921,3,t0,t1,t2);}
/* support.scm: 1154 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7774(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7774(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7774,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[84]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t7,a[8]=t9,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t10)){
t12=t11;
f_7793(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[115]);
if(C_truep(t12)){
t13=t11;
f_7793(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[116]);
if(C_truep(t13)){
t14=t11;
f_7793(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[243]);
t15=t11;
f_7793(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[117])));}}}}

/* k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7793,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[231]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[6]))){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7812,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1138 lset-adjoin */
t5=C_retrieve(lf[439]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[5])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[106]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7824,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[6]))){
t6=t5;
f_7824(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7838,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1141 lset-adjoin */
t7=C_retrieve(lf[439]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[94]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1144 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7774(t7,t5,t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[261]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7877,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1147 decompose-lambda-list */
t8=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[9],t6,t7);}
else{
/* support.scm: 1151 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7915(t6,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[6]);}}}}}}

/* a7876 in k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7877,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7889,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1150 append */
t7=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7887 in a7876 in k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1150 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7774(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7845 in k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7847,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7858,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1145 append */
t4=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7856 in k7845 in k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1145 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7774(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7836 in k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7824(t3,t2);}

/* k7822 in k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1142 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7774(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7810 in k7791 in walk in ##compiler#scan-free-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7693,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7697,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7699,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7699(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7699,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[231]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[106]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7721,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7727,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_7727(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_7727(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[84]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7754,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_7754(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[115]);
t12=t10;
f_7754(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[116])));}}}

/* k7752 in walk in ##compiler#scan-used-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k7725 in walk in ##compiler#scan-used-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7727,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_7721(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_7721(t2,C_SCHEME_UNDEFINED);}}

/* k7719 in walk in ##compiler#scan-used-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7695 in ##compiler#scan-used-variables in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[131],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7417,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[428],t3,t6));}
else{
t6=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[429],t3,t7));}
else{
t7=(C_word)C_eqp(t4,lf[376]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[377]));
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[430],t3,t9));}
else{
t9=(C_word)C_eqp(t4,lf[374]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t10)){
t11=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[431],t3,t11));}
else{
t11=(C_word)C_eqp(t4,lf[362]);
if(C_truep(t11)){
t12=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t13=(C_word)C_a_i_list(&a,3,lf[428],t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,2,lf[432],t13));}
else{
t12=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t12)){
t13=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[433],t3,t13));}
else{
t13=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t13)){
t14=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[434],t3,t14));}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7520,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_eqp(t15,lf[368]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7542,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(t2);
t21=t17;
f_7542(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_7542(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_7542(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(t2);
t18=(C_word)C_eqp(t17,lf[369]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7589,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t21))){
t22=(C_word)C_i_cdddr(t2);
t23=t19;
f_7589(t23,(C_word)C_i_nullp(t22));}
else{
t22=t19;
f_7589(t22,C_SCHEME_FALSE);}}
else{
t21=t19;
f_7589(t21,C_SCHEME_FALSE);}}
else{
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7630,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_car(t2);
t21=(C_word)C_eqp(t20,lf[370]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t23))){
t24=(C_word)C_i_cdddr(t2);
t25=t19;
f_7630(t25,(C_word)C_i_nullp(t24));}
else{
t24=t19;
f_7630(t24,C_SCHEME_FALSE);}}
else{
t23=t19;
f_7630(t23,C_SCHEME_FALSE);}}
else{
t22=t19;
f_7630(t22,C_SCHEME_FALSE);}}}}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t3);}}}}}}}}}

/* k7628 in ##compiler#finish-foreign-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7630,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,lf[84],lf[364]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,4,lf[436],t3,t4,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7587 in ##compiler#finish-foreign-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7589,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1101 g1092 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7520(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7540 in ##compiler#finish-foreign-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7542,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1101 g1092 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7520(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g1092 in ##compiler#finish-foreign-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static C_word C_fcall f_7520(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_a_i_list(&a,3,lf[435],((C_word*)t0)[2],t1));}

/* ##compiler#estimate-foreign-result-location-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7107,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7110,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7119,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7411,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1065 follow-without-loop */
t6=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a7410 in ##compiler#estimate-foreign-result-location-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7411,2,t0,t1);}
/* support.scm: 1086 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[426],((C_word*)t0)[2]);}

/* a7118 in ##compiler#estimate-foreign-result-location-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7119,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[336]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7129,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_7129(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t7)){
t8=t6;
f_7129(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t8)){
t9=t6;
f_7129(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t9)){
t10=t6;
f_7129(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t10)){
t11=t6;
f_7129(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t11)){
t12=t6;
f_7129(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t12)){
t13=t6;
f_7129(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t13)){
t14=t6;
f_7129(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t14)){
t15=t6;
f_7129(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t15)){
t16=t6;
f_7129(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t16)){
t17=t6;
f_7129(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t17)){
t18=t6;
f_7129(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[344]);
if(C_truep(t18)){
t19=t6;
f_7129(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t19)){
t20=t6;
f_7129(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t20)){
t21=t6;
f_7129(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t21)){
t22=t6;
f_7129(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t22)){
t23=t6;
f_7129(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t23)){
t24=t6;
f_7129(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[362]);
if(C_truep(t24)){
t25=t6;
f_7129(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[403]);
if(C_truep(t25)){
t26=t6;
f_7129(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[398]);
if(C_truep(t26)){
t27=t6;
f_7129(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[411]);
if(C_truep(t27)){
t28=t6;
f_7129(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[412]);
if(C_truep(t28)){
t29=t6;
f_7129(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[383]);
if(C_truep(t29)){
t30=t6;
f_7129(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t30)){
t31=t6;
f_7129(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t31)){
t32=t6;
f_7129(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t32)){
t33=t6;
f_7129(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t33)){
t34=t6;
f_7129(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t34)){
t35=t6;
f_7129(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t35)){
t36=t6;
f_7129(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[378]);
t37=t6;
f_7129(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[379])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7127 in a7118 in ##compiler#estimate-foreign-result-location-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7129,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1074 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[404]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[405]));
if(C_truep(t3)){
/* support.scm: 1076 words->bytes */
t4=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[6],C_fix(2));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1078 ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[373]),((C_word*)t0)[3]);}
else{
t5=t4;
f_7147(2,t5,C_SCHEME_FALSE);}}}}

/* k7145 in k7127 in a7118 in ##compiler#estimate-foreign-result-location-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7147,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1080 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[366]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_7181(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t5)){
t6=t4;
f_7181(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t6)){
t7=t4;
f_7181(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t7)){
t8=t4;
f_7181(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[357]);
t9=t4;
f_7181(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[367])));}}}}}
else{
/* support.scm: 1085 err */
f_7110(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k7179 in k7145 in k7127 in a7118 in ##compiler#estimate-foreign-result-location-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1083 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(1));}
else{
/* support.scm: 1084 err */
f_7110(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_7110(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7110,NULL,2,t1,t2);}
/* support.scm: 1064 quit */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[425],t2);}

/* ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6788,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6794,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7101,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1035 follow-without-loop */
t5=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a7100 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
/* support.scm: 1060 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[423],((C_word*)t0)[2]);}

/* a6793 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6794,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[336]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6804,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6804(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t7)){
t8=t6;
f_6804(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t8)){
t9=t6;
f_6804(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t9)){
t10=t6;
f_6804(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[421]);
if(C_truep(t10)){
t11=t6;
f_6804(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t11)){
t12=t6;
f_6804(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[422]);
if(C_truep(t12)){
t13=t6;
f_6804(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t13)){
t14=t6;
f_6804(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t14)){
t15=t6;
f_6804(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t15)){
t16=t6;
f_6804(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t16)){
t17=t6;
f_6804(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[411]);
t18=t6;
f_6804(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[412])));}}}}}}}}}}}}

/* k6802 in a6793 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6804(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6804,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[358]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6813(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t4)){
t5=t3;
f_6813(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t5)){
t6=t3;
f_6813(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[357]);
if(C_truep(t6)){
t7=t3;
f_6813(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[362]);
if(C_truep(t7)){
t8=t3;
f_6813(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t8)){
t9=t3;
f_6813(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t9)){
t10=t3;
f_6813(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
if(C_truep(t10)){
t11=t3;
f_6813(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t11)){
t12=t3;
f_6813(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[378]);
t13=t3;
f_6813(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[379])));}}}}}}}}}}}

/* k6811 in k6802 in a6793 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6813,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1045 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6825(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_6825(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
if(C_truep(t5)){
t6=t3;
f_6825(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t6)){
t7=t3;
f_6825(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
t8=t3;
f_6825(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[380])));}}}}}}

/* k6823 in k6811 in k6802 in a6793 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6825,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1047 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(4));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[342]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_6837(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[404]);
if(C_truep(t4)){
t5=t3;
f_6837(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[405]);
t6=t3;
f_6837(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[419])));}}}}

/* k6835 in k6823 in k6811 in k6802 in a6793 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6837,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1049 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1051 ##sys#hash-table-ref */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[373]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6843(2,t3,C_SCHEME_FALSE);}}}

/* k6841 in k6835 in k6823 in k6811 in k6802 in a6793 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6843,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1053 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[366]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6877,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_6877(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t5)){
t6=t4;
f_6877(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t6)){
t7=t4;
f_6877(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t7)){
t8=t4;
f_6877(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[357]);
if(C_truep(t8)){
t9=t4;
f_6877(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[367]);
if(C_truep(t9)){
t10=t4;
f_6877(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[368]);
if(C_truep(t10)){
t11=t4;
f_6877(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[369]);
t12=t4;
f_6877(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[370])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k6875 in k6841 in k6835 in k6823 in k6811 in k6802 in a6793 in ##compiler#estimate-foreign-result-size in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1057 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6748,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6754,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1022 follow-without-loop */
t5=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a6781 in ##compiler#final-foreign-type in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
/* support.scm: 1029 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[417],((C_word*)t0)[2]);}

/* a6753 in ##compiler#final-foreign-type in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6754,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6758,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1025 ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[373]),t2);}
else{
t5=t4;
f_6758(2,t5,C_SCHEME_FALSE);}}

/* k6756 in a6753 in ##compiler#final-foreign-type in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1027 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6717,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6721,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6730,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1016 ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[373]),t3);}
else{
t5=t4;
f_6721(t5,C_SCHEME_FALSE);}}

/* k6728 in ##compiler#foreign-type-convert-argument in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_6721(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6721(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6721(t2,C_SCHEME_FALSE);}}

/* k6719 in ##compiler#foreign-type-convert-argument in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6686,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6690,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6699,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1009 ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[373]),t3);}
else{
t5=t4;
f_6690(t5,C_SCHEME_FALSE);}}

/* k6697 in ##compiler#foreign-type-convert-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6699,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_6690(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6690(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6690(t2,C_SCHEME_FALSE);}}

/* k6688 in ##compiler#foreign-type-convert-result in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5831,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5837,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6680,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 910  follow-without-loop */
t6=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a6679 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6680,2,t0,t1);}
/* support.scm: 1002 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[413],((C_word*)t0)[2]);}

/* a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5837,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5843,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5843(t7,t1,t2);}

/* repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5843(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5843,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[336]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[337]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[4]:(C_word)C_a_i_list(&a,2,lf[339],((C_word*)t0)[4])));}
else{
t6=(C_word)C_eqp(t3,lf[340]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5868(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t8)){
t9=t7;
f_5868(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t9)){
t10=t7;
f_5868(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t10)){
t11=t7;
f_5868(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[409]);
if(C_truep(t11)){
t12=t7;
f_5868(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[410]);
if(C_truep(t12)){
t13=t7;
f_5868(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[411]);
t14=t7;
f_5868(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[412])));}}}}}}}}

/* k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5868,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[341],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5883(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[404]);
t5=t3;
f_5883(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[405])));}}}

/* k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5883,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[343],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5898(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[401]);
if(C_truep(t4)){
t5=t3;
f_5898(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t6=t3;
f_5898(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[403])));}}}}

/* k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5898,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5901,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 920  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[346]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5936(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[398]);
if(C_truep(t4)){
t5=t3;
f_5936(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
t6=t3;
f_5936(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[400])));}}}}

/* k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5936,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[345],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5951(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t4)){
t5=t3;
f_5951(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t5)){
t6=t3;
f_5951(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t6)){
t7=t3;
f_5951(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t7)){
t8=t3;
f_5951(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
if(C_truep(t8)){
t9=t3;
f_5951(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
t10=t3;
f_5951(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[397])));}}}}}}}}

/* k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5951,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 932  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5993(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t4)){
t5=t3;
f_5993(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t5)){
t6=t3;
f_5993(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t6)){
t7=t3;
f_5993(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
if(C_truep(t7)){
t8=t3;
f_5993(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[388]);
if(C_truep(t8)){
t9=t3;
f_5993(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[389]);
t10=t3;
f_5993(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[390])));}}}}}}}}

/* k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5993,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[350]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[84],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[348],t4,((C_word*)t0)[6]));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6020(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
t5=t3;
f_6020(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[383])));}}}

/* k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6020,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[352],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6035(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[380]);
t5=t3;
f_6035(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[381])));}}}

/* k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6035(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6035,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[354],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6050(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_6050(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6050,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6053,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 952  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[357]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[356],((C_word*)t0)[7]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[358]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6094(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t6=t4;
f_6094(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}}

/* k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6094,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6097,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 960  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[361]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6139(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t5=t3;
f_6139(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}

/* k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6139,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[359],((C_word*)t0)[6]));}
else{
t2=(C_word)C_a_i_list(&a,2,lf[360],((C_word*)t0)[6]);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[359],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[362]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[338]))){
t3=(C_word)C_a_i_list(&a,2,lf[363],((C_word*)t0)[6]);
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[359],t3));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[363],((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,2,lf[360],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[359],t4));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 976  ##sys#hash-table-ref */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[373]),((C_word*)t0)[3]);}
else{
t4=t3;
f_6182(2,t4,C_SCHEME_FALSE);}}}}

/* k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6182,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 978  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6205,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6242,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[366]);
if(C_truep(t6)){
/* support.scm: 980  g879 */
t7=t4;
f_6242(t7,((C_word*)t0)[5]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[344]);
if(C_truep(t8)){
/* support.scm: 980  g879 */
t9=t4;
f_6242(t9,((C_word*)t0)[5]);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[367]);
if(C_truep(t10)){
/* support.scm: 980  g879 */
t11=t4;
f_6242(t11,((C_word*)t0)[5]);}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[355]);
if(C_truep(t12)){
/* support.scm: 980  g879 */
t13=t4;
f_6242(t13,((C_word*)t0)[5]);}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[368]);
if(C_truep(t14)){
/* support.scm: 980  g880 */
t15=t3;
f_6210(t15,((C_word*)t0)[5]);}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[369]);
if(C_truep(t16)){
/* support.scm: 980  g880 */
t17=t3;
f_6210(t17,((C_word*)t0)[5]);}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[370]);
if(C_truep(t18)){
t19=(C_word)C_a_i_list(&a,2,lf[84],lf[364]);
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[365],((C_word*)t0)[3],t19));}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[371]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6354(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6354(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[372]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6386(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6386(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[346]);
if(C_truep(t24)){
/* support.scm: 980  g884 */
t25=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t25))(2,t25,f_6205(C_a_i(&a,6),t2));}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[357]);
/* support.scm: 980  g884 */
t27=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t27))(2,t27,(C_truep(t26)?f_6205(C_a_i(&a,6),t2):((C_word*)t0)[3]));}}}}}}}}}}}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6384 in k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6386,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,2,lf[352],((C_word*)t0)[2])):((C_word*)t0)[2]));}

/* k6352 in k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* support.scm: 980  repeat */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5843(t3,((C_word*)t0)[3],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g879 in k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6246,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 982  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6244 in g879 in k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6246,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[356],t1);
t5=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[103],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[94],t3,t6));}

/* g880 in k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6210,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6214,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 988  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6212 in g880 in k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6214,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[84],lf[364]);
t5=(C_word)C_a_i_list(&a,3,lf[365],((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,4,lf[103],t1,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[94],t3,t7));}

/* g884 in k6180 in k6137 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static C_word C_fcall f_6205(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_a_i_list(&a,2,lf[356],((C_word*)t0)[2]));}

/* k6095 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6097,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6112,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[338]))){
t5=t4;
f_6112(t5,(C_word)C_a_i_list(&a,2,lf[359],t1));}
else{
t5=(C_word)C_a_i_list(&a,2,lf[360],t1);
t6=t4;
f_6112(t6,(C_word)C_a_i_list(&a,2,lf[359],t5));}}

/* k6110 in k6095 in k6092 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_6112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6112,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[103],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t3));}

/* k6051 in k6048 in k6033 in k6018 in k5991 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[356],t1);
t5=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[103],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[94],t3,t6));}

/* k5952 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5954,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5969,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[338]))){
t5=t4;
f_5969(t5,t1);}
else{
t5=(C_word)C_a_i_list(&a,2,lf[84],((C_word*)t0)[2]);
t6=t4;
f_5969(t6,(C_word)C_a_i_list(&a,3,lf[348],t5,t1));}}

/* k5967 in k5952 in k5949 in k5934 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5969,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[103],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t3));}

/* k5899 in k5896 in k5881 in k5866 in repeat in a5836 in ##compiler#foreign-type-check in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5901,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_truep(C_retrieve(lf[338]))?t1:(C_word)C_a_i_list(&a,2,lf[345],t1));
t5=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[103],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[94],t3,t6));}

/* ##compiler#pprint-expressions-to-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5795,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5799,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 891  open-output-file */
t5=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
/* support.scm: 891  current-output-port */
t5=*((C_word*)lf[334]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5797 in ##compiler#pprint-expressions-to-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5802,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 892  with-output-to-port */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a5809 in k5797 in ##compiler#pprint-expressions-to-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5816,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5815 in a5809 in k5797 in ##compiler#pprint-expressions-to-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5816,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5820,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 896  pretty-print */
t4=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5818 in a5815 in a5809 in k5797 in ##compiler#pprint-expressions-to-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 897  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5800 in k5797 in ##compiler#pprint-expressions-to-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 899  close-output-port */
t2=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5756,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5762,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5768,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a5767 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5768,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5775,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 879  debugging */
t10=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[327],lf[328]);}

/* k5773 in a5767 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5775,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 880  printf */
t3=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[326],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5776 in k5773 in a5767 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 881  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[325],((C_word*)t0)[2]);}

/* k5779 in k5776 in k5773 in a5767 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 882  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[324],((C_word*)t0)[2]);}

/* k5782 in k5779 in k5776 in k5773 in a5767 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 883  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[323],((C_word*)t0)[2]);}

/* k5785 in k5782 in k5779 in k5776 in k5773 in a5767 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 884  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[322],((C_word*)t0)[2]);}

/* k5788 in k5785 in k5782 in k5779 in k5776 in k5773 in a5767 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 885  printf */
t2=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[321],((C_word*)t0)[2]);}

/* a5761 in ##compiler#print-program-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5762,2,t0,t1);}
/* support.scm: 878  compute-database-statistics */
t2=C_retrieve(lf[317]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5676,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5680,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5685,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 854  ##sys#hash-table-for-each */
t15=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a5684 in ##compiler#compute-database-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5685,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5690 in a5684 in ##compiler#compute-database-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5691,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[202]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[185]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[261],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t5,lf[190]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* k5678 in ##compiler#compute-database-statistics in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 868  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[318]),C_retrieve(lf[319]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5625,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5629,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5674,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 822  ->string */
t6=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k5672 in ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 822  string-append */
t2=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[316]);}

/* k5668 in ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 821  ##sys#resolve-include-filename */
t2=C_retrieve(lf[315]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5627 in ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5629,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5638,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 824  file-exists? */
t3=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5636 in k5627 in ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[313]))){
/* support.scm: 826  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[314],((C_word*)t0)[2]);}
else{
t3=t2;
f_5641(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5639 in k5636 in k5627 in ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5663,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 832  read-file */
t4=C_retrieve(lf[312]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5661 in k5639 in k5636 in k5627 in ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5645 in k5639 in k5636 in k5627 in ##compiler#lookup-exports-file in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5646,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 830  ##sys#hash-table-set! */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[309]),t2,((C_word*)t0)[2]);}
else{
/* support.scm: 831  export-import-hook */
t3=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}}

/* ##compiler#export-import-hook in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5619,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#check-global-imports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5567,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 805  ##sys#hash-table-for-each */
t4=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5566 in ##compiler#check-global-imports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5567,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5571,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 807  ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[309]),t2);}

/* k5569 in a5566 in ##compiler#check-global-imports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=(C_word)C_i_assq(lf[189],((C_word*)t0)[4]);
t3=(C_word)C_i_assq(lf[200],((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(lf[202],((C_word*)t0)[4]))){
if(C_truep(t3)){
if(C_truep(t1)){
/* support.scm: 813  compiler-warning */
t4=C_retrieve(lf[25]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],lf[305],lf[306],((C_word*)t0)[2],t1);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=t1;
if(C_truep(t5)){
t6=t4;
f_5598(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5617,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 814  keyword? */
t7=C_retrieve(lf[308]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}}
else{
t5=t4;
f_5598(t5,C_SCHEME_FALSE);}}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5615 in k5569 in a5566 in ##compiler#check-global-imports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5598(t2,(C_word)C_i_not(t1));}

/* k5596 in k5569 in a5566 in ##compiler#check-global-imports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 815  compiler-warning */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[300],lf[307],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#check-global-exports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5517,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[295]))){
t3=C_retrieve(lf[295]);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5524,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5535,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 796  ##sys#hash-table-for-each */
t7=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5534 in ##compiler#check-global-exports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5535,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5539,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5546,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t6=(C_word)C_i_assq(lf[200],t3);
t7=t5;
f_5546(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_5546(t6,C_SCHEME_FALSE);}}

/* k5544 in a5534 in ##compiler#check-global-exports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 799  compiler-warning */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[300],lf[303],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5539(2,t2,C_SCHEME_UNDEFINED);}}

/* k5537 in a5534 in ##compiler#check-global-exports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 800  delete */
t3=C_retrieve(lf[302]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[278]+1));}

/* k5541 in k5537 in a5534 in ##compiler#check-global-exports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5522 in ##compiler#check-global-exports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5529,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a5528 in k5522 in ##compiler#check-global-exports in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5529,3,t0,t1,t2);}
/* ##compiler#compiler-warning */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[300],lf[301],t2);}

/* ##compiler#dump-undefined-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5486,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5492,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 785  ##sys#hash-table-for-each */
t4=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5491 in ##compiler#dump-undefined-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5492,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5499,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[202],t3))){
t5=(C_word)C_i_assq(lf[200],t3);
t6=t4;
f_5499(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5499(t5,C_SCHEME_FALSE);}}

/* k5497 in a5491 in ##compiler#dump-undefined-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5499,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5502,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 789  write */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5500 in k5497 in a5491 in ##compiler#dump-undefined-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 790  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5400,4,t0,t1,t2,t3);}
if(C_truep(C_retrieve(lf[292]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5409,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 764  with-output-to-file */
t5=C_retrieve(lf[297]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}}

/* a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5413,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 767  ##sys#hash-table-for-each */
t6=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a5447 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5448,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5455,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(lf[202],t3))){
if(C_truep((C_word)C_i_assq(lf[200],t3))){
t5=(C_truep(C_retrieve(lf[295]))?(C_word)C_i_memq(t2,C_retrieve(lf[295])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5455(t6,t5);}
else{
t6=(C_word)C_i_memq(t2,C_retrieve(lf[296]));
t7=t4;
f_5455(t7,(C_word)C_i_not(t6));}}
else{
t5=t4;
f_5455(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_5455(t5,C_SCHEME_FALSE);}}

/* k5453 in a5447 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5455,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5411 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5421,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5434,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 779  sort */
t6=C_retrieve(lf[294]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* a5433 in k5411 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5434,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* support.scm: 781  string<? */
t6=*((C_word*)lf[293]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* k5430 in k5411 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5420 in k5411 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5421,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5425,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 777  write */
t4=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5423 in a5420 in k5411 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 778  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5414 in k5411 in a5408 in ##compiler#dump-exported-globals in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 782  export-dump-hook */
t2=C_retrieve(lf[290]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#export-dump-hook in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5394,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#simple-lambda-node? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5302,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5326,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5326(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5326,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[248]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[231],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 753  every */
t15=C_retrieve(lf[89]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[242]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 755  every */
t9=C_retrieve(lf[89]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5216,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5222,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5222(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5222,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[231]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5238,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5238(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[84]);
if(C_truep(t9)){
t10=t8;
f_5238(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[115]);
if(C_truep(t10)){
t11=t8;
f_5238(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[243]);
t12=t8;
f_5238(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[235])));}}}}

/* k5236 in walk in ##compiler#expression-has-side-effects? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5238,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5252,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 736  find */
t7=C_retrieve(lf[287]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],t6,C_retrieve(lf[288]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[103]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[94]));
if(C_truep(t4)){
/* support.scm: 737  any */
t5=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a5251 in k5236 in walk in ##compiler#expression-has-side-effects? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5260,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 736  foreign-callback-stub-id */
t4=C_retrieve(lf[286]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5258 in a5251 in k5236 in walk in ##compiler#expression-has-side-effects? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5021,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5024,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5096,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5200,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 720  matchn */
t15=((C_word*)t12)[1];
f_5096(t15,t14,t2,t3);}

/* k5198 in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 723  debugging */
t7=C_retrieve(lf[15]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t2,lf[283],lf[284],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5204 in k5198 in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5096(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5096,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 709  resolve */
t4=((C_word*)t0)[4];
f_5024(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5118,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 711  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5053(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k5116 in matchn in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5118,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5131,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5131(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k5116 in matchn in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5131(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5131,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 715  resolve */
t4=((C_word*)t0)[4];
f_5024(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5162,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 717  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5096(t7,t4,t5,t6);}}}}

/* k5160 in loop in k5116 in matchn in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 718  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5131(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5053,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 702  resolve */
t4=((C_word*)t0)[3];
f_5024(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5075,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 704  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k5073 in match1 in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 704  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5053(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_5024(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5024,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5048,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 697  alist-cons */
t6=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k5046 in resolve in ##compiler#match-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#copy-node! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4959,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4963,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 679  node-class-set! */
t7=C_retrieve(lf[223]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t3,t6);}

/* k4961 in ##compiler#copy-node! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 680  node-parameters-set! */
t5=C_retrieve(lf[226]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4964 in k4961 in ##compiler#copy-node! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 681  node-subexpressions-set! */
t5=C_retrieve(lf[228]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4967 in k4964 in k4961 in ##compiler#copy-node! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4969,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4980(t4,C_fix(4)));}

/* do628 in k4967 in k4964 in k4961 in ##compiler#copy-node! in k2797 in k2794 in k1449 in k1446 in k1443 */
static C_word C_fcall f_4980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4925,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4931,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4931(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4931(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4931,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4945,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 675  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4943 in rec in ##compiler#tree-copy in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4949,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 675  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4931(t4,t2,t3);}

/* k4947 in k4943 in rec in ##compiler#tree-copy in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4747,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4751,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 643  map */
t6=*((C_word*)lf[120]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[280]+1),t3,t4);}

/* k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4753,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4759,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 670  walk */
t6=((C_word*)t4)[1];
f_4759(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4759(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4759,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[231]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4782,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
/* support.scm: 650  rename */
f_4753(t11,t12,t3);}
else{
t11=(C_word)C_eqp(t9,lf[106]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4811,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 651  rename */
f_4753(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[94]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4827,a[2]=t3,a[3]=t13,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 654  gensym */
t15=C_retrieve(lf[95]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t13);}
else{
t13=(C_word)C_eqp(t9,lf[261]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4860,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 658  decompose-lambda-list */
t16=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4908,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 669  tree-copy */
t15=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}}}}}

/* k4906 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4911,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4915 in k4906 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4916,3,t0,t1,t2);}
/* walk574 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4759(t3,t1,t2,((C_word*)t0)[2]);}

/* k4909 in k4906 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4911,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4859 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4860,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[95]),t2);}

/* k4862 in a4859 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 662  append */
t3=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4865 in k4862 in a4859 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 666  rename */
f_4753(t5,((C_word*)t0)[3],t1);}
else{
t6=t5;
f_4902(2,t6,C_SCHEME_FALSE);}}

/* k4900 in k4865 in k4862 in a4859 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 666  build-lambda-list */
t2=C_retrieve(lf[53]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4892 in k4865 in k4862 in a4859 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4894,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4873,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a4877 in k4892 in k4865 in k4862 in a4859 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4878,3,t0,t1,t2);}
/* walk574 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4759(t3,t1,t2,((C_word*)t0)[2]);}

/* k4871 in k4892 in k4865 in k4862 in a4859 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[261],((C_word*)t0)[2],t1));}

/* k4825 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 655  alist-cons */
t3=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4828 in k4825 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4836,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4840 in k4828 in k4825 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4841,3,t0,t1,t2);}
/* walk574 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4759(t3,t1,t2,((C_word*)t0)[2]);}

/* k4834 in k4828 in k4825 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[94],((C_word*)t0)[2],t1));}

/* k4809 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4811,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4798,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4802 in k4809 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4803,3,t0,t1,t2);}
/* walk574 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4759(t3,t1,t2,((C_word*)t0)[2]);}

/* k4796 in k4809 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4798,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[106],((C_word*)t0)[2],t1));}

/* k4780 in walk in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 650  varnode */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k4749 in ##compiler#copy-node-tree-and-rename in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4753(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4753,NULL,3,t1,t2,t3);}
/* support.scm: 644  alist-ref */
t4=C_retrieve(lf[277]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[278]+1),t2);}

/* ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4654,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4660,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 621  decompose-lambda-list */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4660,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4666,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4672,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4672,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[95]),((C_word*)t0)[2]);}
else{
t5=t4;
f_4676(2,t5,((C_word*)t0)[2]);}}

/* k4674 in a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 627  copy-node-tree-and-rename */
t3=C_retrieve(lf[276]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_4679(2,t3,((C_word*)t0)[3]);}}

/* k4677 in k4674 in a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4684,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4698,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 633  last */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_4698(t4,t1);}}

/* k4737 in k4677 in k4674 in a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4715,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 635  qnode */
t4=C_retrieve(lf[232]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[275],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_4715(2,t8,(C_word)C_a_i_record(&a,4,lf[221],lf[109],t6,t7));}}

/* k4713 in k4737 in k4677 in k4674 in a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_4698(t3,(C_word)C_a_i_record(&a,4,lf[221],lf[94],((C_word*)t0)[2],t2));}

/* k4696 in k4677 in k4674 in a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4698,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 639  take */
t3=C_retrieve(lf[274]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4700 in k4696 in k4677 in k4674 in a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 629  fold-right */
t2=C_retrieve(lf[273]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4683 in k4677 in k4674 in a4671 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4684,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[221],lf[94],t5,t6));}

/* a4665 in a4659 in ##compiler#inline-lambda-bindings in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
/* support.scm: 624  split-at */
t2=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4606,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4612,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4612(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4612,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 617  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k4630 in fold in ##compiler#fold-boolean in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 618  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4612(t4,t2,t3);}

/* k4634 in k4630 in fold in ##compiler#fold-boolean in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[221],lf[108],lf[270],t2));}

/* ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4312,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4318,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4318(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4318,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[103]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4337,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_4337(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[267]);
t12=t10;
f_4337(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[268])));}}

/* k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4337,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[257]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[231]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[235]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[84]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,lf[84],t6));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[94]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 591  butlast */
t10=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[107]:lf[261]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4436,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 598  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_4318(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[248]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[242]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4469,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[115]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_4493(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_4547(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[264]);
if(C_truep(t14)){
t15=t13;
f_4547(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[265]);
t16=t13;
f_4547(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[266])));}}}}}}}}}}}}}

/* k4545 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 608  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4318(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4575 in k4545 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 609  append */
t2=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4571 in k4545 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4552 in k4545 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k4556 in k4552 in k4545 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 608  cons* */
t2=C_retrieve(lf[101]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4493(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4493,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 605  reverse */
t7=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4534,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 606  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_4318(3,t10,t8,t9);}}

/* k4532 in loop in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4534,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 606  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4493(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4505 in loop in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4511,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 605  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4318(3,t4,t2,t3);}

/* k4509 in k4505 in loop in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[262],((C_word*)t0)[2],t1));}

/* k4467 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 600  cons* */
t2=C_retrieve(lf[101]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[242],((C_word*)t0)[2],t1);}

/* k4434 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4413 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4409 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 591  map */
t2=*((C_word*)lf[120]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[259]+1),((C_word*)t0)[2],t1);}

/* k4397 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4403,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4407,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 592  last */
t4=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4405 in k4397 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4318(3,t2,((C_word*)t0)[2],t1);}

/* k4401 in k4397 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t1));}

/* k4359 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[257],t2));}

/* k4342 in k4335 in walk in ##compiler#build-expression-tree in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3804,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3807,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4307,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 575  walk */
t9=((C_word*)t6)[1];
f_3807(3,t9,t8,t2);}

/* k4305 in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4310,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 576  debugging */
t3=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[254],lf[255],((C_word*)((C_word*)t0)[2])[1]);}

/* k4308 in k4305 in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word *a;
loop:
a=C_alloc(83);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3807,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 510  varnode */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 511  bomb */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[234],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[221],lf[235],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[103]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[115]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3866,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[84]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3889,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3892,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[239],C_retrieve(lf[240]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_3892(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_3892(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_3892(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[94]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 531  walk */
t64=t1;
t65=t11;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3942,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 532  unzip1 */
t13=C_retrieve(lf[241]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[107]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t12,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_caddr(t2);
/* support.scm: 535  walk */
t64=t13;
t65=t14;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t11=(C_word)C_eqp(t4,lf[116]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_i_car(t2);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t13,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t12))){
t15=(C_word)C_i_car(t12);
t16=t14;
f_4033(t16,(C_word)C_eqp(lf[84],t15));}
else{
t15=t14;
f_4033(t15,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t4,lf[108]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[242]));
if(C_truep(t13)){
t14=(C_word)C_i_car(t2);
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4064,a[2]=t16,a[3]=t14,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_i_cddr(t2);
/* map */
t19=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,((C_word*)((C_word*)t0)[3])[1],t18);}
else{
t14=(C_word)C_eqp(t4,lf[243]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,t15,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,4,lf[221],lf[243],t16,C_SCHEME_END_OF_LIST));}
else{
t15=(C_word)C_eqp(t4,lf[106]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(t4,lf[100]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(t2);
t18=(C_word)C_a_i_list(&a,1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4106,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cddr(t2);
/* map */
t21=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,((C_word*)((C_word*)t0)[3])[1],t20);}
else{
t17=(C_word)C_eqp(t4,lf[244]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_i_cadr(t18);
t20=(C_word)C_i_caddr(t2);
t21=(C_word)C_i_cadr(t20);
t22=(C_word)C_i_cadddr(t2);
t23=(C_word)C_i_cadr(t22);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4159,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t23,a[6]=t21,a[7]=t19,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 554  fifth */
t25=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,t2);}
else{
t18=(C_word)C_eqp(t4,lf[109]);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t18)){
t20=t19;
f_4180(t20,t18);}
else{
t20=(C_word)C_eqp(t4,lf[117]);
if(C_truep(t20)){
t21=t19;
f_4180(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[110]);
if(C_truep(t21)){
t22=t19;
f_4180(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[111]);
t23=t19;
f_4180(t23,(C_truep(t22)?t22:(C_word)C_eqp(t4,lf[112])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4297,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k4295 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4297,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[248],lf[253],t1));}

/* k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4180,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4189,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[247]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4205,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 562  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a4222 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4223,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4237,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[252])))){
t5=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_4237(t7,C_SCHEME_TRUE);}
else{
t5=t4;
f_4237(t5,C_SCHEME_FALSE);}}

/* k4235 in a4222 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4237,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 570  real-name */
t4=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm: 572  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4242 in k4235 in a4222 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_4251(2,t3,t1);}
else{
/* support.scm: 571  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4249 in k4242 in k4235 in a4222 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4241(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[250]),((C_word*)t0)[2],t1));}

/* k4239 in k4235 in a4222 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4230,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k4228 in k4239 in k4235 in a4222 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[248],((C_word*)t0)[2],t1));}

/* a4216 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
/* support.scm: 562  get-line-2 */
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4203 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[248],lf[249],t1));}

/* k4187 in k4178 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4157 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4139,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4143,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 555  sixth */
t6=C_retrieve(lf[245]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k4141 in k4157 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 555  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3807(3,t2,((C_word*)t0)[2],t1);}

/* k4137 in k4157 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[221],lf[244],((C_word*)t0)[2],t2));}

/* k4104 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4106,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[106],((C_word*)t0)[2],t1));}

/* k4062 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4031 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_4033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4033,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4019,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k4017 in k4031 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3991 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[221],lf[107],((C_word*)t0)[2],t2));}

/* k3940 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3945,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a3961 in k3940 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3962,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 533  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3807(3,t4,t1,t3);}

/* k3950 in k3940 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3960,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 534  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3807(3,t3,t2,((C_word*)t0)[2]);}

/* k3958 in k3950 in k3940 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 533  append */
t3=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3943 in k3940 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[94],((C_word*)t0)[2],t1));}

/* k3890 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3892,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 522  compiler-warning */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[237],lf[238],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3889(t2,((C_word*)t0)[2]);}}

/* k3893 in k3890 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 525  truncate */
t3=*((C_word*)lf[236]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3900 in k3893 in k3890 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3889(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k3887 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 518  qnode */
t2=C_retrieve(lf[232]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3864 in walk in ##compiler#build-node-graph in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3795,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[221],lf[84],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3786,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[221],lf[231],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3780,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[221],t2,t3,t4));}

/* node-subexpressions in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3771,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[221]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3762,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[221]);
/* support.scm: 496  ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3753,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[221]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3744,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[221]);
/* support.scm: 496  ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3735,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[221]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3726,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[221]);
/* support.scm: 496  ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3720,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[221]));}

/* f_3714 in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3714,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[221],t2,t3,t4));}

/* ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3308,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_3308(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3712,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 448  append */
t5=*((C_word*)lf[59]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[217]),C_retrieve(lf[218]),C_retrieve(lf[219]));}}

/* k3710 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3308(t3,t2);}

/* k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3308,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 451  ##sys#hash-table-for-each */
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3313,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3323,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t11,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 458  write */
t13=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}}

/* k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3413(t6,t2,((C_word*)t0)[2]);}

/* loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3413,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 462  caar */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[182]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_3439(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t5)){
t6=t4;
f_3439(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t6)){
t7=t4;
f_3439(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[202]);
if(C_truep(t7)){
t8=t4;
f_3439(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t8)){
t9=t4;
f_3439(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t9)){
t10=t4;
f_3439(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[152]);
if(C_truep(t10)){
t11=t4;
f_3439(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t11)){
t12=t4;
f_3439(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[157]);
if(C_truep(t12)){
t13=t4;
f_3439(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t13)){
t14=t4;
f_3439(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t14)){
t15=t4;
f_3439(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t15)){
t16=t4;
f_3439(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t16)){
t17=t4;
f_3439(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t17)){
t18=t4;
f_3439(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t18)){
t19=t4;
f_3439(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[211]);
if(C_truep(t19)){
t20=t4;
f_3439(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[212]);
if(C_truep(t20)){
t21=t4;
f_3439(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[213]);
if(C_truep(t21)){
t22=t4;
f_3439(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[153]);
if(C_truep(t22)){
t23=t4;
f_3439(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[214]);
if(C_truep(t23)){
t24=t4;
f_3439(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[149]);
t25=t4;
f_3439(t25,(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[215])));}}}}}}}}}}}}}}}}}}}}}

/* k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3439,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 466  caar */
t3=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[181]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[181]);
t4=((C_word*)t0)[8];
f_3426(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[185]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[181]);
if(C_truep(t4)){
t5=((C_word*)t0)[8];
f_3426(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 470  cdar */
t6=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[186]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 472  cdar */
t6=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[187]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3496(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[192]);
if(C_truep(t7)){
t8=t6;
f_3496(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[193]);
if(C_truep(t8)){
t9=t6;
f_3496(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[171]);
if(C_truep(t9)){
t10=t6;
f_3496(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[194]);
if(C_truep(t10)){
t11=t6;
f_3496(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[195]);
if(C_truep(t11)){
t12=t6;
f_3496(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[196]);
if(C_truep(t12)){
t13=t6;
f_3496(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[197]);
if(C_truep(t13)){
t14=t6;
f_3496(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[198]);
t15=t6;
f_3496(t15,(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[6],lf[199])));}}}}}}}}}}}}}

/* k3494 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3496,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 475  caar */
t3=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[189]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 477  cdar */
t4=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[190]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 479  cdar */
t5=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 480  bomb */
t5=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[191],t4);}}}}

/* k3525 in k3494 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3426(2,t3,t2);}

/* k3515 in k3494 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3426(2,t3,t2);}

/* k3501 in k3494 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3507,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 475  cdar */
t3=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3505 in k3501 in k3494 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 475  printf */
t2=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[188],((C_word*)t0)[2],t1);}

/* k3485 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3426(2,t3,t2);}

/* k3475 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3426(2,t3,t2);}

/* k3452 in k3437 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[183]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 466  printf */
t4=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[184],t3);}

/* k3424 in k3421 in loop in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 481  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3413(t3,((C_word*)t0)[2],t2);}

/* k3324 in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[181]);
t5=t3;
f_3361(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3361(t4,C_SCHEME_FALSE);}}

/* k3359 in k3324 in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3361,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 483  printf */
t7=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],lf[179],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[181]);
t4=t2;
f_3382(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3382(t3,C_SCHEME_FALSE);}}}

/* k3380 in k3359 in k3324 in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3382,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 485  printf */
t7=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[180],t6);}
else{
t2=((C_word*)t0)[2];
f_3329(2,t2,C_SCHEME_UNDEFINED);}}

/* k3327 in k3324 in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 486  printf */
t4=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[178],t3);}
else{
t3=t2;
f_3332(2,t3,C_SCHEME_UNDEFINED);}}

/* k3330 in k3327 in k3324 in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 487  printf */
t4=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[177],t3);}
else{
t3=t2;
f_3335(2,t3,C_SCHEME_UNDEFINED);}}

/* k3333 in k3330 in k3327 in k3324 in k3321 in a3312 in k3306 in ##compiler#display-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 488  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3291,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 430  ##sys#hash-table-for-each */
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[168]));}

/* a3290 in ##compiler#display-line-number-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3291,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3302,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[174]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3300 in a3290 in ##compiler#display-line-number-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 432  printf */
t2=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[173],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3261,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3267,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3267(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3267,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3277,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 426  get */
t5=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[171]);}}

/* k3275 in loop in ##compiler#find-lambda-container in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 427  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3267(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3225,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3232,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 418  ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[168]),t3);}

/* k3230 in ##compiler#get-line-2 in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_3235(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_3235(t3,C_SCHEME_FALSE);}}

/* k3233 in k3230 in ##compiler#get-line-2 in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_fcall f_3235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 420  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 421  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3215,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 414  get */
t4=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[168]),t3,t2);}

/* ##compiler#count! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_3158r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3158r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3158r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3162,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 402  ##sys#hash-table-ref */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3160 in ##compiler#count! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3192,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 407  alist-cons */
t7=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 408  ##sys#hash-table-set! */
t6=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k3190 in k3160 in ##compiler#count! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3106,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3110,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 394  ##sys#hash-table-ref */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3108 in ##compiler#collect! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 398  alist-cons */
t6=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 399  ##sys#hash-table-set! */
t4=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k3135 in k3108 in ##compiler#collect! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3060,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3064,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 386  ##sys#hash-table-ref */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3062 in ##compiler#put! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3086,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 390  alist-cons */
t5=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 391  ##sys#hash-table-set! */
t4=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k3084 in k3062 in ##compiler#put! in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3042r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3042r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 380  ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3044 in ##compiler#get-all in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3054,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 382  filter-map */
t3=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a3053 in k3044 in ##compiler#get-all in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3054,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3024,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 374  ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3026 in ##compiler#get in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2963,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2967,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[159]));}

/* a2999 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3000,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 360  put! */
t4=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[158],C_SCHEME_TRUE);}

/* k3002 in a2999 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[156])))){
/* support.scm: 361  put! */
t3=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[157],C_SCHEME_TRUE);}
else{
t3=t2;
f_3007(2,t3,C_SCHEME_UNDEFINED);}}

/* k3005 in k3002 in a2999 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[155])))){
/* support.scm: 362  put! */
t2=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[152],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2965 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[154]));}

/* a2984 in k2965 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 366  put! */
t4=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[153],C_SCHEME_TRUE);}

/* k2987 in a2984 in k2965 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[151])))){
/* support.scm: 367  put! */
t2=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[152],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2968 in k2965 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[150]));}

/* a2974 in k2968 in k2965 in ##compiler#initialize-analysis-database in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2975,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 370  put! */
t4=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t3,lf[149],C_SCHEME_TRUE);}

/* ##compiler#expand-profile-lambda in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2906,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[140]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2910,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 342  gensym */
t7=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k2908 in ##compiler#expand-profile-lambda in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 343  alist-cons */
t3=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[141]));}

/* k2912 in k2908 in ##compiler#expand-profile-lambda in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=C_mutate((C_word*)lf[141]+1,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[140]+1,t3);
t5=(C_word)C_a_i_list(&a,2,lf[84],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[142],t5,C_retrieve(lf[143]));
t7=(C_word)C_a_i_list(&a,3,lf[107],C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_list(&a,3,lf[107],((C_word*)t0)[5],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,3,lf[144],t8,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[107],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,lf[84],((C_word*)t0)[6]);
t12=(C_word)C_a_i_list(&a,3,lf[145],t11,C_retrieve(lf[143]));
t13=(C_word)C_a_i_list(&a,3,lf[107],C_SCHEME_END_OF_LIST,t12);
t14=(C_word)C_a_i_list(&a,4,lf[146],t7,t10,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[107],((C_word*)t0)[3],t14));}

/* ##compiler#process-lambda-documentation in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2903,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2800,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2807,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2809,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2815,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2840,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2889 in a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2890r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2890r(t0,t1,t2);}}

static void C_ccall f_2890r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g239241 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2895 in a2889 in a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2845 in a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2850,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2874,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 327  with-input-from-string */
t4=C_retrieve(lf[133]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a2873 in a2845 in a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2880,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2888,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 327  read */
t4=*((C_word*)lf[129]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2886 in a2873 in a2845 in a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 327  unfold */
t2=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[131]+1),*((C_word*)lf[132]+1),((C_word*)t0)[2],t1);}

/* a2879 in a2873 in a2845 in a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2880,3,t0,t1,t2);}
/* support.scm: 327  read */
t3=*((C_word*)lf[129]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2848 in a2845 in a2839 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[127]);}
else{
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_nullp(t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[128],t1)));}}

/* a2814 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2815,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* g239241 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2820 in a2814 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 324  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k2830 in a2820 in a2814 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 325  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 326  ->string */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2827 in a2820 in a2814 in a2808 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 322  quit */
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[126],((C_word*)t0)[2],t1);}

/* k2805 in ##compiler#string->expr in k2797 in k2794 in k1449 in k1446 in k1443 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2425,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2428,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2789,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 314  walk */
t9=((C_word*)t6)[1];
f_2428(3,t9,t8,t2);}

/* k2787 in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 315  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2428,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[84]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2582,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t2);
t9=t6;
f_2582(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_2582(t8,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2633,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[94]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cadr(t2);
t11=t6;
f_2633(t11,(C_word)C_i_listp(t10));}
else{
t10=t6;
f_2633(t10,C_SCHEME_FALSE);}}
else{
t9=t6;
f_2633(t9,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2633,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2642(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g184187 */
t4=((C_word*)t0)[3];
f_2430(t4,((C_word*)t0)[2],t2,t3);}}

/* g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2642(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2642,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t6=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2743,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* cdar */
t8=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}
else{
t7=t5;
f_2689(t7,C_SCHEME_FALSE);}}}

/* k2741 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* cddar */
t3=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2689(t2,C_SCHEME_FALSE);}}

/* k2737 in k2741 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2689(t2,(C_word)C_i_nullp(t1));}

/* k2687 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2689,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2712,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* cadar */
t4=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* g184187 */
t4=((C_word*)t0)[2];
f_2430(t4,((C_word*)t0)[4],t2,t3);}}

/* k2710 in k2687 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2708,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* caar */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2706 in k2710 in k2687 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* g179224 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2642(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2650 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2655,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t3=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2653 in k2650 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2669,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[120]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2674 in k2653 in k2650 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2675,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2683,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* walk174 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2428(3,t5,t4,t3);}

/* k2681 in a2674 in k2653 in k2650 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2667 in k2653 in k2650 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2671 in k2667 in k2653 in k2650 in g179 in k2631 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[94],t2));}

/* k2580 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2602,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##compiler#collapsable-literal? */
t4=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g184187 */
t4=((C_word*)t0)[2];
f_2430(t4,((C_word*)t0)[4],t2,t3);}}

/* k2600 in k2580 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##compiler#make-random-name */
t3=C_retrieve(lf[119]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k2592 in k2600 in k2580 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2598,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* alist-cons */
t3=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2596 in k2592 in k2600 in k2580 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* g184 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2430(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2430,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[99]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2440(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[113]);
if(C_truep(t7)){
t8=t6;
f_2440(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[114]);
if(C_truep(t8)){
t9=t6;
f_2440(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[115]);
if(C_truep(t9)){
t10=t6;
f_2440(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[116]);
t11=t6;
f_2440(t11,(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[117])));}}}}}

/* k2438 in g184 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2440,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[100]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_2449(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[106]);
if(C_truep(t4)){
t5=t3;
f_2449(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[107]);
if(C_truep(t5)){
t6=t3;
f_2449(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[108]);
if(C_truep(t6)){
t7=t3;
f_2449(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[109]);
if(C_truep(t7)){
t8=t3;
f_2449(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[110]);
if(C_truep(t8)){
t9=t3;
f_2449(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[111]);
t10=t3;
f_2449(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[112])));}}}}}}}}

/* k2447 in k2438 in g184 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2449,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2460,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[103]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2473(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[104]);
t5=t3;
f_2473(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[3],lf[105])));}}}

/* k2471 in k2447 in k2438 in g184 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_fcall f_2473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2473,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}}

/* k2478 in k2471 in k2447 in k2438 in g184 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2458 in k2447 in k2438 in g184 in walk in ##compiler#extract-mutable-constants in k1449 in k1446 in k1443 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 309  cons* */
t2=C_retrieve(lf[101]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#canonicalize-begin-body in k1449 in k1446 in k1443 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2342,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2348,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2348(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k1449 in k1446 in k1443 */
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2348,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[92]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[93]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2376,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_2376(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2413,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 285  constant? */
t8=C_retrieve(lf[83]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k2411 in loop in ##compiler#canonicalize-begin-body in k1449 in k1446 in k1443 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2376(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[97])));}

/* k2374 in loop in ##compiler#canonicalize-begin-body in k1449 in k1446 in k1443 */
static void C_fcall f_2376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 287  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2348(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 288  gensym */
t3=C_retrieve(lf[95]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[96]);}}

/* k2404 in k2374 in loop in ##compiler#canonicalize-begin-body in k1449 in k1446 in k1443 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 289  loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2348(t7,t5,t6);}

/* k2392 in k2404 in k2374 in loop in ##compiler#canonicalize-begin-body in k1449 in k1446 in k1443 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t1));}

/* ##compiler#basic-literal? in k1449 in k1446 in k1443 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2282,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 270  constant? */
t6=C_retrieve(lf[83]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}

/* k2296 in ##compiler#basic-literal? in k1449 in k1446 in k1443 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 271  vector->list */
t4=*((C_word*)lf[90]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2304(2,t3,C_SCHEME_FALSE);}}}

/* k2338 in k2296 in ##compiler#basic-literal? in k1449 in k1446 in k1443 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 271  every */
t2=C_retrieve(lf[89]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[88]),t1);}

/* k2302 in k2296 in ##compiler#basic-literal? in k1449 in k1446 in k1443 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 273  basic-literal? */
t4=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k2317 in k2302 in k2296 in ##compiler#basic-literal? in k1449 in k1446 in k1443 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 274  basic-literal? */
t3=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k1449 in k1446 in k1443 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2280,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 260  big-fixnum? */
t5=C_retrieve(lf[87]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t3;
f_2240(t4,C_SCHEME_FALSE);}}

/* k2278 in ##compiler#immediate? in k1449 in k1446 in k1443 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2240(t2,(C_word)C_i_not(t1));}

/* k2238 in ##compiler#immediate? in k1449 in k1446 in k1443 */
static void C_fcall f_2240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k1449 in k1446 in k1443 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2206,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k1449 in k1446 in k1443 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2160,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[84],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#follow-without-loop in k1449 in k1446 in k1443 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2129,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2135,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2135(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k1449 in k1446 in k1443 */
static void C_fcall f_2135(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2135,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 238  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 239  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a2149 in loop in ##compiler#follow-without-loop in k1449 in k1446 in k1443 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2150,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 239  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2135(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k1449 in k1446 in k1443 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2066,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 228  reverse */
t6=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k2078 in ##compiler#fold-inner in k1449 in k1446 in k1443 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2082,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2082(t5,((C_word*)t0)[2],t1);}

/* fold in k2078 in ##compiler#fold-inner in k1449 in k1446 in k1443 */
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2082,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_2090(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2111,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 233  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k2109 in fold in k2078 in ##compiler#fold-inner in k1449 in k1446 in k1443 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2090(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k2088 in fold in k2078 in ##compiler#fold-inner in k1449 in k1446 in k1443 */
static void C_fcall f_2090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k1449 in k1446 in k1443 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2054,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[78]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 223  close-input-port */
t4=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k1449 in k1446 in k1443 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2007r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2007r(t0,t1,t2,t3);}}

static void C_ccall f_2007r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[71]))){
/* support.scm: 217  current-input-port */
t4=*((C_word*)lf[72]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2023,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 218  file-exists? */
t5=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k2021 in ##compiler#check-and-open-input-file in k1449 in k1446 in k1443 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 218  open-input-file */
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2035(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_2035(t5,(C_word)C_i_not(t4));}}}

/* k2033 in k2021 in ##compiler#check-and-open-input-file in k1449 in k1446 in k1443 */
static void C_fcall f_2035(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 219  quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[74],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 220  quit */
t3=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[75],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k1449 in k1446 in k1443 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2000,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub100(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k1449 in k1446 in k1443 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1993,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub96(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k1449 in k1446 in k1443 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1937,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1991,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 198  ->string */
t5=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1989 in ##compiler#valid-c-identifier? in k1449 in k1446 in k1443 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[61]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1939 in ##compiler#valid-c-identifier? in k1449 in k1446 in k1443 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1964,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 202  any */
t7=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1963 in k1939 in ##compiler#valid-c-identifier? in k1449 in k1446 in k1443 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1964,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1843,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1855,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[61]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1861(t5,((C_word*)t0)[2],t1);}

/* loop in k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_fcall f_1861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1861,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[58]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1883,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_1883(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_1883(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[64])));}}}

/* k1881 in loop in k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_fcall f_1883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1883,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_1890(t3,lf[62]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_1890(t4,(C_truep(t3)?lf[63]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 195  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1861(t4,t2,t3);}}

/* k1920 in k1881 in loop in k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1888 in k1881 in loop in k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_fcall f_1890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1890,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 193  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k1904 in k1888 in k1881 in loop in k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[61]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1892 in k1888 in k1881 in loop in k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1898,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 194  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1861(t4,t2,t3);}

/* k1896 in k1892 in k1888 in k1881 in loop in k1857 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 189  append */
t2=*((C_word*)lf[59]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[60],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1853 in ##compiler#c-ify-string in k1449 in k1446 in k1443 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k1449 in k1446 in k1443 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1799,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1805,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1805(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k1449 in k1446 in k1443 */
static void C_fcall f_1805(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1805,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1829,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 175  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k1827 in loop in ##compiler#build-lambda-list in k1449 in k1446 in k1443 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k1449 in k1446 in k1443 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1774,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 169  string->symbol */
t3=*((C_word*)lf[51]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1797,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 170  sprintf */
t4=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[52],t2);}}}

/* k1795 in ##compiler#symbolify in k1449 in k1446 in k1443 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 170  string->symbol */
t2=*((C_word*)lf[51]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k1449 in k1446 in k1443 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1753,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 164  symbol->string */
t3=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* support.scm: 165  sprintf */
t3=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[49],t2);}}}

/* ##compiler#posq in k1449 in k1446 in k1443 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1717,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1723(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k1449 in k1446 in k1443 */
static C_word C_fcall f_1723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k1449 in k1446 in k1443 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1649,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1652,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1673,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1673(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k1449 in k1446 in k1443 */
static void C_fcall f_1673(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1673,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 148  err */
t4=((C_word*)t0)[3];
f_1652(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 150  err */
t5=((C_word*)t0)[3];
f_1652(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 151  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k1449 in k1446 in k1443 */
static void C_fcall f_1652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1652,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 145  real-name */
t3=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1658 in err in ##compiler#check-signature in k1449 in k1446 in k1443 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1664,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 146  map-llist */
t4=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[44]),t3);}

/* k1662 in k1658 in err in ##compiler#check-signature in k1449 in k1446 in k1443 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 144  quit */
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[43],((C_word*)t0)[2],t1);}

/* map-llist in k1449 in k1446 in k1443 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1606,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1612,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1612(t7,t1,t3);}

/* loop in map-llist in k1449 in k1446 in k1443 */
static void C_fcall f_1612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1612,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 139  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 140  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k1633 in loop in map-llist in k1449 in k1446 in k1443 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1639,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 140  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1612(t4,t2,t3);}

/* k1637 in k1633 in loop in map-llist in k1449 in k1446 in k1443 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k1449 in k1446 in k1443 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1603,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[35])));}

/* ##sys#syntax-error-hook in k1449 in k1446 in k1443 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1578r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1578r(t0,t1,t2,t3);}}

static void C_ccall f_1578r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1582,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 125  current-error-port */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1580 in ##sys#syntax-error-hook in k1449 in k1446 in k1443 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 126  fprintf */
t3=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[38],((C_word*)t0)[2]);}

/* k1583 in k1580 in ##sys#syntax-error-hook in k1449 in k1446 in k1443 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1595 in k1583 in k1580 in ##sys#syntax-error-hook in k1449 in k1446 in k1443 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1596,3,t0,t1,t2);}
/* fprintf */
t3=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],lf[37],t2);}

/* k1586 in k1583 in k1580 in ##sys#syntax-error-hook in k1449 in k1446 in k1443 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 128  print-call-chain */
t3=C_retrieve(lf[34]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[35]),lf[36]);}

/* k1589 in k1586 in k1583 in k1580 in ##sys#syntax-error-hook in k1449 in k1446 in k1443 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 129  exit */
t2=C_retrieve(lf[31]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k1449 in k1446 in k1443 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1559r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1559r(t0,t1,t2,t3);}}

static void C_ccall f_1559r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1563,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 118  current-error-port */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1561 in quit in k1449 in k1446 in k1443 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 119  string-append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[32],((C_word*)t0)[2]);}

/* k1574 in k1561 in quit in k1449 in k1446 in k1443 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[26]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1564 in k1561 in quit in k1449 in k1446 in k1443 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 120  newline */
t3=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1567 in k1564 in k1561 in quit in k1449 in k1446 in k1443 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 121  exit */
t2=C_retrieve(lf[31]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k1449 in k1446 in k1443 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1530r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1530r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1530r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1537,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[29]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[9]));
t7=t5;
f_1537(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_1537(t6,C_SCHEME_FALSE);}}

/* k1535 in ##compiler#compiler-warning in k1449 in k1446 in k1443 */
static void C_fcall f_1537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1537,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 113  current-error-port */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1538 in k1535 in ##compiler#compiler-warning in k1449 in k1446 in k1443 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1543,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 114  string-append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[27],((C_word*)t0)[2]);}

/* k1548 in k1538 in k1535 in ##compiler#compiler-warning in k1449 in k1446 in k1443 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[26]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1541 in k1538 in k1535 in ##compiler#compiler-warning in k1449 in k1446 in k1443 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 115  newline */
t2=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1490r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1490r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1490r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[8])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 102  printf */
t6=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[24],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k1498 in ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 105  display */
t4=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[23]);}
else{
t3=t2;
f_1503(2,t3,C_SCHEME_UNDEFINED);}}

/* k1513 in k1498 in ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1520,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a1519 in k1513 in k1498 in ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1520,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1528,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 106  force */
t4=C_retrieve(lf[20]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1526 in a1519 in k1513 in k1498 in ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 106  printf */
t2=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[19],t1);}

/* k1501 in k1498 in ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 107  newline */
t3=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1504 in k1501 in k1498 in ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 108  flush-output */
t3=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1507 in k1504 in k1501 in k1498 in ##compiler#debugging in k1449 in k1446 in k1443 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k1449 in k1446 in k1443 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1463r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1463r(t0,t1,t2);}}

static void C_ccall f_1463r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 96   string-append */
t5=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[13],t4);}
else{
/* support.scm: 97   error */
t3=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[14]);}}

/* k1475 in ##compiler#bomb in k1449 in k1446 in k1443 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[11]+1),t1,t2);}

/* f_1458 in k1449 in k1446 in k1443 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1458,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[574] = {
{"toplevelsupport.scm",(void*)C_support_toplevel},
{"f_1445support.scm",(void*)f_1445},
{"f_1448support.scm",(void*)f_1448},
{"f_1451support.scm",(void*)f_1451},
{"f_2796support.scm",(void*)f_2796},
{"f_2799support.scm",(void*)f_2799},
{"f_8897support.scm",(void*)f_8897},
{"f_8786support.scm",(void*)f_8786},
{"f_8895support.scm",(void*)f_8895},
{"f_8790support.scm",(void*)f_8790},
{"f_8795support.scm",(void*)f_8795},
{"f_8799support.scm",(void*)f_8799},
{"f_8835support.scm",(void*)f_8835},
{"f_8879support.scm",(void*)f_8879},
{"f_8851support.scm",(void*)f_8851},
{"f_8802support.scm",(void*)f_8802},
{"f_8809support.scm",(void*)f_8809},
{"f_8805support.scm",(void*)f_8805},
{"f_8757support.scm",(void*)f_8757},
{"f_8784support.scm",(void*)f_8784},
{"f_8768support.scm",(void*)f_8768},
{"f_8771support.scm",(void*)f_8771},
{"f_8773support.scm",(void*)f_8773},
{"f_8777support.scm",(void*)f_8777},
{"f_8761support.scm",(void*)f_8761},
{"f_8694support.scm",(void*)f_8694},
{"f_8731support.scm",(void*)f_8731},
{"f_8755support.scm",(void*)f_8755},
{"f_8741support.scm",(void*)f_8741},
{"f_8745support.scm",(void*)f_8745},
{"f_8716support.scm",(void*)f_8716},
{"f_8724support.scm",(void*)f_8724},
{"f_8625support.scm",(void*)f_8625},
{"f_8629support.scm",(void*)f_8629},
{"f_8634support.scm",(void*)f_8634},
{"f_8638support.scm",(void*)f_8638},
{"f_8689support.scm",(void*)f_8689},
{"f_8668support.scm",(void*)f_8668},
{"f_8680support.scm",(void*)f_8680},
{"f_8683support.scm",(void*)f_8683},
{"f_8656support.scm",(void*)f_8656},
{"f_8600support.scm",(void*)f_8600},
{"f_8610support.scm",(void*)f_8610},
{"f_8613support.scm",(void*)f_8613},
{"f_8513support.scm",(void*)f_8513},
{"f_8522support.scm",(void*)f_8522},
{"f_8535support.scm",(void*)f_8535},
{"f_8541support.scm",(void*)f_8541},
{"f_8594support.scm",(void*)f_8594},
{"f_8544support.scm",(void*)f_8544},
{"f_8559support.scm",(void*)f_8559},
{"f_8567support.scm",(void*)f_8567},
{"f_8577support.scm",(void*)f_8577},
{"f_8562support.scm",(void*)f_8562},
{"f_8550support.scm",(void*)f_8550},
{"f_8517support.scm",(void*)f_8517},
{"f_8507support.scm",(void*)f_8507},
{"f_8431support.scm",(void*)f_8431},
{"f_8438support.scm",(void*)f_8438},
{"f_8450support.scm",(void*)f_8450},
{"f_8461support.scm",(void*)f_8461},
{"f_8457support.scm",(void*)f_8457},
{"f_8419support.scm",(void*)f_8419},
{"f_8425support.scm",(void*)f_8425},
{"f_8407support.scm",(void*)f_8407},
{"f_8411support.scm",(void*)f_8411},
{"f_8328support.scm",(void*)f_8328},
{"f_8347support.scm",(void*)f_8347},
{"f_8372support.scm",(void*)f_8372},
{"f_8376support.scm",(void*)f_8376},
{"f_8378support.scm",(void*)f_8378},
{"f_8385support.scm",(void*)f_8385},
{"f_8398support.scm",(void*)f_8398},
{"f_8402support.scm",(void*)f_8402},
{"f_8331support.scm",(void*)f_8331},
{"f_8335support.scm",(void*)f_8335},
{"f_8341support.scm",(void*)f_8341},
{"f_8322support.scm",(void*)f_8322},
{"f_8278support.scm",(void*)f_8278},
{"f_8290support.scm",(void*)f_8290},
{"f_8294support.scm",(void*)f_8294},
{"f_8298support.scm",(void*)f_8298},
{"f_8286support.scm",(void*)f_8286},
{"f_8269support.scm",(void*)f_8269},
{"f_8260support.scm",(void*)f_8260},
{"f_8254support.scm",(void*)f_8254},
{"f_8248support.scm",(void*)f_8248},
{"f_8236support.scm",(void*)f_8236},
{"f_8240support.scm",(void*)f_8240},
{"f_8243support.scm",(void*)f_8243},
{"f_8198support.scm",(void*)f_8198},
{"f_8202support.scm",(void*)f_8202},
{"f_8205support.scm",(void*)f_8205},
{"f_8212support.scm",(void*)f_8212},
{"f_8156support.scm",(void*)f_8156},
{"f_8165support.scm",(void*)f_8165},
{"f_8127support.scm",(void*)f_8127},
{"f_8137support.scm",(void*)f_8137},
{"f_7930support.scm",(void*)f_7930},
{"f_8109support.scm",(void*)f_8109},
{"f_8058support.scm",(void*)f_8058},
{"f_8103support.scm",(void*)f_8103},
{"f_8107support.scm",(void*)f_8107},
{"f_8061support.scm",(void*)f_8061},
{"f_8066support.scm",(void*)f_8066},
{"f_8070support.scm",(void*)f_8070},
{"f_8064support.scm",(void*)f_8064},
{"f_8021support.scm",(void*)f_8021},
{"f_8025support.scm",(void*)f_8025},
{"f_8034support.scm",(void*)f_8034},
{"f_8038support.scm",(void*)f_8038},
{"f_8028support.scm",(void*)f_8028},
{"f_7986support.scm",(void*)f_7986},
{"f_7992support.scm",(void*)f_7992},
{"f_8019support.scm",(void*)f_8019},
{"f_8005support.scm",(void*)f_8005},
{"f_7939support.scm",(void*)f_7939},
{"f_7945support.scm",(void*)f_7945},
{"f_7984support.scm",(void*)f_7984},
{"f_7966support.scm",(void*)f_7966},
{"f_7771support.scm",(void*)f_7771},
{"f_7928support.scm",(void*)f_7928},
{"f_7915support.scm",(void*)f_7915},
{"f_7921support.scm",(void*)f_7921},
{"f_7774support.scm",(void*)f_7774},
{"f_7793support.scm",(void*)f_7793},
{"f_7877support.scm",(void*)f_7877},
{"f_7889support.scm",(void*)f_7889},
{"f_7847support.scm",(void*)f_7847},
{"f_7858support.scm",(void*)f_7858},
{"f_7838support.scm",(void*)f_7838},
{"f_7824support.scm",(void*)f_7824},
{"f_7812support.scm",(void*)f_7812},
{"f_7693support.scm",(void*)f_7693},
{"f_7699support.scm",(void*)f_7699},
{"f_7754support.scm",(void*)f_7754},
{"f_7727support.scm",(void*)f_7727},
{"f_7721support.scm",(void*)f_7721},
{"f_7697support.scm",(void*)f_7697},
{"f_7417support.scm",(void*)f_7417},
{"f_7630support.scm",(void*)f_7630},
{"f_7589support.scm",(void*)f_7589},
{"f_7542support.scm",(void*)f_7542},
{"f_7520support.scm",(void*)f_7520},
{"f_7107support.scm",(void*)f_7107},
{"f_7411support.scm",(void*)f_7411},
{"f_7119support.scm",(void*)f_7119},
{"f_7129support.scm",(void*)f_7129},
{"f_7147support.scm",(void*)f_7147},
{"f_7181support.scm",(void*)f_7181},
{"f_7110support.scm",(void*)f_7110},
{"f_6788support.scm",(void*)f_6788},
{"f_7101support.scm",(void*)f_7101},
{"f_6794support.scm",(void*)f_6794},
{"f_6804support.scm",(void*)f_6804},
{"f_6813support.scm",(void*)f_6813},
{"f_6825support.scm",(void*)f_6825},
{"f_6837support.scm",(void*)f_6837},
{"f_6843support.scm",(void*)f_6843},
{"f_6877support.scm",(void*)f_6877},
{"f_6748support.scm",(void*)f_6748},
{"f_6782support.scm",(void*)f_6782},
{"f_6754support.scm",(void*)f_6754},
{"f_6758support.scm",(void*)f_6758},
{"f_6717support.scm",(void*)f_6717},
{"f_6730support.scm",(void*)f_6730},
{"f_6721support.scm",(void*)f_6721},
{"f_6686support.scm",(void*)f_6686},
{"f_6699support.scm",(void*)f_6699},
{"f_6690support.scm",(void*)f_6690},
{"f_5831support.scm",(void*)f_5831},
{"f_6680support.scm",(void*)f_6680},
{"f_5837support.scm",(void*)f_5837},
{"f_5843support.scm",(void*)f_5843},
{"f_5868support.scm",(void*)f_5868},
{"f_5883support.scm",(void*)f_5883},
{"f_5898support.scm",(void*)f_5898},
{"f_5936support.scm",(void*)f_5936},
{"f_5951support.scm",(void*)f_5951},
{"f_5993support.scm",(void*)f_5993},
{"f_6020support.scm",(void*)f_6020},
{"f_6035support.scm",(void*)f_6035},
{"f_6050support.scm",(void*)f_6050},
{"f_6094support.scm",(void*)f_6094},
{"f_6139support.scm",(void*)f_6139},
{"f_6182support.scm",(void*)f_6182},
{"f_6386support.scm",(void*)f_6386},
{"f_6354support.scm",(void*)f_6354},
{"f_6242support.scm",(void*)f_6242},
{"f_6246support.scm",(void*)f_6246},
{"f_6210support.scm",(void*)f_6210},
{"f_6214support.scm",(void*)f_6214},
{"f_6205support.scm",(void*)f_6205},
{"f_6097support.scm",(void*)f_6097},
{"f_6112support.scm",(void*)f_6112},
{"f_6053support.scm",(void*)f_6053},
{"f_5954support.scm",(void*)f_5954},
{"f_5969support.scm",(void*)f_5969},
{"f_5901support.scm",(void*)f_5901},
{"f_5795support.scm",(void*)f_5795},
{"f_5799support.scm",(void*)f_5799},
{"f_5810support.scm",(void*)f_5810},
{"f_5816support.scm",(void*)f_5816},
{"f_5820support.scm",(void*)f_5820},
{"f_5802support.scm",(void*)f_5802},
{"f_5756support.scm",(void*)f_5756},
{"f_5768support.scm",(void*)f_5768},
{"f_5775support.scm",(void*)f_5775},
{"f_5778support.scm",(void*)f_5778},
{"f_5781support.scm",(void*)f_5781},
{"f_5784support.scm",(void*)f_5784},
{"f_5787support.scm",(void*)f_5787},
{"f_5790support.scm",(void*)f_5790},
{"f_5762support.scm",(void*)f_5762},
{"f_5676support.scm",(void*)f_5676},
{"f_5685support.scm",(void*)f_5685},
{"f_5691support.scm",(void*)f_5691},
{"f_5680support.scm",(void*)f_5680},
{"f_5625support.scm",(void*)f_5625},
{"f_5674support.scm",(void*)f_5674},
{"f_5670support.scm",(void*)f_5670},
{"f_5629support.scm",(void*)f_5629},
{"f_5638support.scm",(void*)f_5638},
{"f_5641support.scm",(void*)f_5641},
{"f_5663support.scm",(void*)f_5663},
{"f_5646support.scm",(void*)f_5646},
{"f_5619support.scm",(void*)f_5619},
{"f_5561support.scm",(void*)f_5561},
{"f_5567support.scm",(void*)f_5567},
{"f_5571support.scm",(void*)f_5571},
{"f_5617support.scm",(void*)f_5617},
{"f_5598support.scm",(void*)f_5598},
{"f_5517support.scm",(void*)f_5517},
{"f_5535support.scm",(void*)f_5535},
{"f_5546support.scm",(void*)f_5546},
{"f_5539support.scm",(void*)f_5539},
{"f_5543support.scm",(void*)f_5543},
{"f_5524support.scm",(void*)f_5524},
{"f_5529support.scm",(void*)f_5529},
{"f_5486support.scm",(void*)f_5486},
{"f_5492support.scm",(void*)f_5492},
{"f_5499support.scm",(void*)f_5499},
{"f_5502support.scm",(void*)f_5502},
{"f_5400support.scm",(void*)f_5400},
{"f_5409support.scm",(void*)f_5409},
{"f_5448support.scm",(void*)f_5448},
{"f_5455support.scm",(void*)f_5455},
{"f_5413support.scm",(void*)f_5413},
{"f_5434support.scm",(void*)f_5434},
{"f_5432support.scm",(void*)f_5432},
{"f_5421support.scm",(void*)f_5421},
{"f_5425support.scm",(void*)f_5425},
{"f_5416support.scm",(void*)f_5416},
{"f_5394support.scm",(void*)f_5394},
{"f_5302support.scm",(void*)f_5302},
{"f_5326support.scm",(void*)f_5326},
{"f_5216support.scm",(void*)f_5216},
{"f_5222support.scm",(void*)f_5222},
{"f_5238support.scm",(void*)f_5238},
{"f_5252support.scm",(void*)f_5252},
{"f_5260support.scm",(void*)f_5260},
{"f_5021support.scm",(void*)f_5021},
{"f_5200support.scm",(void*)f_5200},
{"f_5206support.scm",(void*)f_5206},
{"f_5096support.scm",(void*)f_5096},
{"f_5118support.scm",(void*)f_5118},
{"f_5131support.scm",(void*)f_5131},
{"f_5162support.scm",(void*)f_5162},
{"f_5053support.scm",(void*)f_5053},
{"f_5075support.scm",(void*)f_5075},
{"f_5024support.scm",(void*)f_5024},
{"f_5048support.scm",(void*)f_5048},
{"f_4959support.scm",(void*)f_4959},
{"f_4963support.scm",(void*)f_4963},
{"f_4966support.scm",(void*)f_4966},
{"f_4969support.scm",(void*)f_4969},
{"f_4980support.scm",(void*)f_4980},
{"f_4925support.scm",(void*)f_4925},
{"f_4931support.scm",(void*)f_4931},
{"f_4945support.scm",(void*)f_4945},
{"f_4949support.scm",(void*)f_4949},
{"f_4747support.scm",(void*)f_4747},
{"f_4751support.scm",(void*)f_4751},
{"f_4759support.scm",(void*)f_4759},
{"f_4908support.scm",(void*)f_4908},
{"f_4916support.scm",(void*)f_4916},
{"f_4911support.scm",(void*)f_4911},
{"f_4860support.scm",(void*)f_4860},
{"f_4864support.scm",(void*)f_4864},
{"f_4867support.scm",(void*)f_4867},
{"f_4902support.scm",(void*)f_4902},
{"f_4894support.scm",(void*)f_4894},
{"f_4878support.scm",(void*)f_4878},
{"f_4873support.scm",(void*)f_4873},
{"f_4827support.scm",(void*)f_4827},
{"f_4830support.scm",(void*)f_4830},
{"f_4841support.scm",(void*)f_4841},
{"f_4836support.scm",(void*)f_4836},
{"f_4811support.scm",(void*)f_4811},
{"f_4803support.scm",(void*)f_4803},
{"f_4798support.scm",(void*)f_4798},
{"f_4782support.scm",(void*)f_4782},
{"f_4753support.scm",(void*)f_4753},
{"f_4654support.scm",(void*)f_4654},
{"f_4660support.scm",(void*)f_4660},
{"f_4672support.scm",(void*)f_4672},
{"f_4676support.scm",(void*)f_4676},
{"f_4679support.scm",(void*)f_4679},
{"f_4739support.scm",(void*)f_4739},
{"f_4715support.scm",(void*)f_4715},
{"f_4698support.scm",(void*)f_4698},
{"f_4702support.scm",(void*)f_4702},
{"f_4684support.scm",(void*)f_4684},
{"f_4666support.scm",(void*)f_4666},
{"f_4606support.scm",(void*)f_4606},
{"f_4612support.scm",(void*)f_4612},
{"f_4632support.scm",(void*)f_4632},
{"f_4636support.scm",(void*)f_4636},
{"f_4312support.scm",(void*)f_4312},
{"f_4318support.scm",(void*)f_4318},
{"f_4337support.scm",(void*)f_4337},
{"f_4547support.scm",(void*)f_4547},
{"f_4577support.scm",(void*)f_4577},
{"f_4573support.scm",(void*)f_4573},
{"f_4554support.scm",(void*)f_4554},
{"f_4558support.scm",(void*)f_4558},
{"f_4493support.scm",(void*)f_4493},
{"f_4534support.scm",(void*)f_4534},
{"f_4507support.scm",(void*)f_4507},
{"f_4511support.scm",(void*)f_4511},
{"f_4469support.scm",(void*)f_4469},
{"f_4436support.scm",(void*)f_4436},
{"f_4415support.scm",(void*)f_4415},
{"f_4411support.scm",(void*)f_4411},
{"f_4399support.scm",(void*)f_4399},
{"f_4407support.scm",(void*)f_4407},
{"f_4403support.scm",(void*)f_4403},
{"f_4361support.scm",(void*)f_4361},
{"f_4344support.scm",(void*)f_4344},
{"f_3804support.scm",(void*)f_3804},
{"f_4307support.scm",(void*)f_4307},
{"f_4310support.scm",(void*)f_4310},
{"f_3807support.scm",(void*)f_3807},
{"f_4297support.scm",(void*)f_4297},
{"f_4180support.scm",(void*)f_4180},
{"f_4223support.scm",(void*)f_4223},
{"f_4237support.scm",(void*)f_4237},
{"f_4244support.scm",(void*)f_4244},
{"f_4251support.scm",(void*)f_4251},
{"f_4241support.scm",(void*)f_4241},
{"f_4230support.scm",(void*)f_4230},
{"f_4217support.scm",(void*)f_4217},
{"f_4205support.scm",(void*)f_4205},
{"f_4189support.scm",(void*)f_4189},
{"f_4159support.scm",(void*)f_4159},
{"f_4143support.scm",(void*)f_4143},
{"f_4139support.scm",(void*)f_4139},
{"f_4106support.scm",(void*)f_4106},
{"f_4064support.scm",(void*)f_4064},
{"f_4033support.scm",(void*)f_4033},
{"f_4019support.scm",(void*)f_4019},
{"f_3993support.scm",(void*)f_3993},
{"f_3942support.scm",(void*)f_3942},
{"f_3962support.scm",(void*)f_3962},
{"f_3952support.scm",(void*)f_3952},
{"f_3960support.scm",(void*)f_3960},
{"f_3945support.scm",(void*)f_3945},
{"f_3892support.scm",(void*)f_3892},
{"f_3895support.scm",(void*)f_3895},
{"f_3902support.scm",(void*)f_3902},
{"f_3889support.scm",(void*)f_3889},
{"f_3866support.scm",(void*)f_3866},
{"f_3795support.scm",(void*)f_3795},
{"f_3786support.scm",(void*)f_3786},
{"f_3780support.scm",(void*)f_3780},
{"f_3771support.scm",(void*)f_3771},
{"f_3762support.scm",(void*)f_3762},
{"f_3753support.scm",(void*)f_3753},
{"f_3744support.scm",(void*)f_3744},
{"f_3735support.scm",(void*)f_3735},
{"f_3726support.scm",(void*)f_3726},
{"f_3720support.scm",(void*)f_3720},
{"f_3714support.scm",(void*)f_3714},
{"f_3304support.scm",(void*)f_3304},
{"f_3712support.scm",(void*)f_3712},
{"f_3308support.scm",(void*)f_3308},
{"f_3313support.scm",(void*)f_3313},
{"f_3323support.scm",(void*)f_3323},
{"f_3413support.scm",(void*)f_3413},
{"f_3423support.scm",(void*)f_3423},
{"f_3439support.scm",(void*)f_3439},
{"f_3496support.scm",(void*)f_3496},
{"f_3527support.scm",(void*)f_3527},
{"f_3517support.scm",(void*)f_3517},
{"f_3503support.scm",(void*)f_3503},
{"f_3507support.scm",(void*)f_3507},
{"f_3487support.scm",(void*)f_3487},
{"f_3477support.scm",(void*)f_3477},
{"f_3454support.scm",(void*)f_3454},
{"f_3426support.scm",(void*)f_3426},
{"f_3326support.scm",(void*)f_3326},
{"f_3361support.scm",(void*)f_3361},
{"f_3382support.scm",(void*)f_3382},
{"f_3329support.scm",(void*)f_3329},
{"f_3332support.scm",(void*)f_3332},
{"f_3335support.scm",(void*)f_3335},
{"f_3285support.scm",(void*)f_3285},
{"f_3291support.scm",(void*)f_3291},
{"f_3302support.scm",(void*)f_3302},
{"f_3261support.scm",(void*)f_3261},
{"f_3267support.scm",(void*)f_3267},
{"f_3277support.scm",(void*)f_3277},
{"f_3225support.scm",(void*)f_3225},
{"f_3232support.scm",(void*)f_3232},
{"f_3235support.scm",(void*)f_3235},
{"f_3215support.scm",(void*)f_3215},
{"f_3158support.scm",(void*)f_3158},
{"f_3162support.scm",(void*)f_3162},
{"f_3192support.scm",(void*)f_3192},
{"f_3106support.scm",(void*)f_3106},
{"f_3110support.scm",(void*)f_3110},
{"f_3137support.scm",(void*)f_3137},
{"f_3060support.scm",(void*)f_3060},
{"f_3064support.scm",(void*)f_3064},
{"f_3086support.scm",(void*)f_3086},
{"f_3042support.scm",(void*)f_3042},
{"f_3046support.scm",(void*)f_3046},
{"f_3054support.scm",(void*)f_3054},
{"f_3024support.scm",(void*)f_3024},
{"f_3028support.scm",(void*)f_3028},
{"f_2963support.scm",(void*)f_2963},
{"f_3000support.scm",(void*)f_3000},
{"f_3004support.scm",(void*)f_3004},
{"f_3007support.scm",(void*)f_3007},
{"f_2967support.scm",(void*)f_2967},
{"f_2985support.scm",(void*)f_2985},
{"f_2989support.scm",(void*)f_2989},
{"f_2970support.scm",(void*)f_2970},
{"f_2975support.scm",(void*)f_2975},
{"f_2906support.scm",(void*)f_2906},
{"f_2910support.scm",(void*)f_2910},
{"f_2914support.scm",(void*)f_2914},
{"f_2903support.scm",(void*)f_2903},
{"f_2800support.scm",(void*)f_2800},
{"f_2809support.scm",(void*)f_2809},
{"f_2840support.scm",(void*)f_2840},
{"f_2890support.scm",(void*)f_2890},
{"f_2896support.scm",(void*)f_2896},
{"f_2846support.scm",(void*)f_2846},
{"f_2874support.scm",(void*)f_2874},
{"f_2888support.scm",(void*)f_2888},
{"f_2880support.scm",(void*)f_2880},
{"f_2850support.scm",(void*)f_2850},
{"f_2815support.scm",(void*)f_2815},
{"f_2821support.scm",(void*)f_2821},
{"f_2832support.scm",(void*)f_2832},
{"f_2829support.scm",(void*)f_2829},
{"f_2807support.scm",(void*)f_2807},
{"f_2425support.scm",(void*)f_2425},
{"f_2789support.scm",(void*)f_2789},
{"f_2428support.scm",(void*)f_2428},
{"f_2633support.scm",(void*)f_2633},
{"f_2642support.scm",(void*)f_2642},
{"f_2743support.scm",(void*)f_2743},
{"f_2739support.scm",(void*)f_2739},
{"f_2689support.scm",(void*)f_2689},
{"f_2712support.scm",(void*)f_2712},
{"f_2708support.scm",(void*)f_2708},
{"f_2652support.scm",(void*)f_2652},
{"f_2655support.scm",(void*)f_2655},
{"f_2675support.scm",(void*)f_2675},
{"f_2683support.scm",(void*)f_2683},
{"f_2669support.scm",(void*)f_2669},
{"f_2673support.scm",(void*)f_2673},
{"f_2582support.scm",(void*)f_2582},
{"f_2602support.scm",(void*)f_2602},
{"f_2594support.scm",(void*)f_2594},
{"f_2598support.scm",(void*)f_2598},
{"f_2430support.scm",(void*)f_2430},
{"f_2440support.scm",(void*)f_2440},
{"f_2449support.scm",(void*)f_2449},
{"f_2473support.scm",(void*)f_2473},
{"f_2480support.scm",(void*)f_2480},
{"f_2460support.scm",(void*)f_2460},
{"f_2342support.scm",(void*)f_2342},
{"f_2348support.scm",(void*)f_2348},
{"f_2413support.scm",(void*)f_2413},
{"f_2376support.scm",(void*)f_2376},
{"f_2406support.scm",(void*)f_2406},
{"f_2394support.scm",(void*)f_2394},
{"f_2282support.scm",(void*)f_2282},
{"f_2298support.scm",(void*)f_2298},
{"f_2340support.scm",(void*)f_2340},
{"f_2304support.scm",(void*)f_2304},
{"f_2319support.scm",(void*)f_2319},
{"f_2236support.scm",(void*)f_2236},
{"f_2280support.scm",(void*)f_2280},
{"f_2240support.scm",(void*)f_2240},
{"f_2206support.scm",(void*)f_2206},
{"f_2160support.scm",(void*)f_2160},
{"f_2129support.scm",(void*)f_2129},
{"f_2135support.scm",(void*)f_2135},
{"f_2150support.scm",(void*)f_2150},
{"f_2066support.scm",(void*)f_2066},
{"f_2080support.scm",(void*)f_2080},
{"f_2082support.scm",(void*)f_2082},
{"f_2111support.scm",(void*)f_2111},
{"f_2090support.scm",(void*)f_2090},
{"f_2054support.scm",(void*)f_2054},
{"f_2007support.scm",(void*)f_2007},
{"f_2023support.scm",(void*)f_2023},
{"f_2035support.scm",(void*)f_2035},
{"f_2000support.scm",(void*)f_2000},
{"f_1993support.scm",(void*)f_1993},
{"f_1937support.scm",(void*)f_1937},
{"f_1991support.scm",(void*)f_1991},
{"f_1941support.scm",(void*)f_1941},
{"f_1964support.scm",(void*)f_1964},
{"f_1843support.scm",(void*)f_1843},
{"f_1859support.scm",(void*)f_1859},
{"f_1861support.scm",(void*)f_1861},
{"f_1883support.scm",(void*)f_1883},
{"f_1922support.scm",(void*)f_1922},
{"f_1890support.scm",(void*)f_1890},
{"f_1906support.scm",(void*)f_1906},
{"f_1894support.scm",(void*)f_1894},
{"f_1898support.scm",(void*)f_1898},
{"f_1855support.scm",(void*)f_1855},
{"f_1799support.scm",(void*)f_1799},
{"f_1805support.scm",(void*)f_1805},
{"f_1829support.scm",(void*)f_1829},
{"f_1774support.scm",(void*)f_1774},
{"f_1797support.scm",(void*)f_1797},
{"f_1753support.scm",(void*)f_1753},
{"f_1717support.scm",(void*)f_1717},
{"f_1723support.scm",(void*)f_1723},
{"f_1649support.scm",(void*)f_1649},
{"f_1673support.scm",(void*)f_1673},
{"f_1652support.scm",(void*)f_1652},
{"f_1660support.scm",(void*)f_1660},
{"f_1664support.scm",(void*)f_1664},
{"f_1606support.scm",(void*)f_1606},
{"f_1612support.scm",(void*)f_1612},
{"f_1635support.scm",(void*)f_1635},
{"f_1639support.scm",(void*)f_1639},
{"f_1603support.scm",(void*)f_1603},
{"f_1578support.scm",(void*)f_1578},
{"f_1582support.scm",(void*)f_1582},
{"f_1585support.scm",(void*)f_1585},
{"f_1596support.scm",(void*)f_1596},
{"f_1588support.scm",(void*)f_1588},
{"f_1591support.scm",(void*)f_1591},
{"f_1559support.scm",(void*)f_1559},
{"f_1563support.scm",(void*)f_1563},
{"f_1576support.scm",(void*)f_1576},
{"f_1566support.scm",(void*)f_1566},
{"f_1569support.scm",(void*)f_1569},
{"f_1530support.scm",(void*)f_1530},
{"f_1537support.scm",(void*)f_1537},
{"f_1540support.scm",(void*)f_1540},
{"f_1550support.scm",(void*)f_1550},
{"f_1543support.scm",(void*)f_1543},
{"f_1490support.scm",(void*)f_1490},
{"f_1500support.scm",(void*)f_1500},
{"f_1515support.scm",(void*)f_1515},
{"f_1520support.scm",(void*)f_1520},
{"f_1528support.scm",(void*)f_1528},
{"f_1503support.scm",(void*)f_1503},
{"f_1506support.scm",(void*)f_1506},
{"f_1509support.scm",(void*)f_1509},
{"f_1463support.scm",(void*)f_1463},
{"f_1477support.scm",(void*)f_1477},
{"f_1458support.scm",(void*)f_1458},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
