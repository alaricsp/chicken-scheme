/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-01-18 12:16
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: support.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[506];


/* from k2002 */
static C_word C_fcall stub100(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub100(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k1995 */
static C_word C_fcall stub96(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub96(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8785)
static void C_ccall f_8785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8789)
static void C_fcall f_8789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8794)
static void C_ccall f_8794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8798)
static void C_ccall f_8798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8834)
static void C_fcall f_8834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8850)
static void C_ccall f_8850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8808)
static void C_ccall f_8808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8767)
static void C_ccall f_8767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8770)
static void C_ccall f_8770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8772)
static void C_ccall f_8772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8776)
static void C_ccall f_8776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_fcall f_8760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8693)
static void C_ccall f_8693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_ccall f_8715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8624)
static void C_ccall f_8624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8628)
static void C_ccall f_8628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8633)
static void C_fcall f_8633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8637)
static void C_ccall f_8637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8612)
static void C_ccall f_8612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8521)
static void C_fcall f_8521(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8534)
static void C_ccall f_8534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8543)
static void C_ccall f_8543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8558)
static void C_ccall f_8558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_fcall f_8566(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8576)
static void C_ccall f_8576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8561)
static void C_ccall f_8561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8549)
static void C_ccall f_8549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8516)
static void C_ccall f_8516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8506)
static void C_ccall f_8506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8437)
static void C_fcall f_8437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8449)
static void C_ccall f_8449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8460)
static void C_ccall f_8460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8456)
static void C_ccall f_8456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8410)
static void C_ccall f_8410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8346)
static void C_ccall f_8346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8375)
static void C_ccall f_8375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_fcall f_8377(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8397)
static void C_ccall f_8397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8401)
static void C_ccall f_8401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8330)
static void C_fcall f_8330(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8334)
static void C_ccall f_8334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8285)
static void C_ccall f_8285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8235)
static void C_ccall f_8235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8242)
static void C_ccall f_8242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8197)
static void C_ccall f_8197(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8197)
static void C_ccall f_8197r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8211)
static void C_ccall f_8211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8164)
static void C_fcall f_8164(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8136)
static void C_fcall f_8136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8102)
static void C_ccall f_8102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_fcall f_8020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8033)
static void C_ccall f_8033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8027)
static void C_ccall f_8027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_fcall f_7985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7991)
static void C_fcall f_7991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8018)
static void C_ccall f_8018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_fcall f_7938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7944)
static void C_fcall f_7944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7965)
static void C_ccall f_7965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7773)
static void C_fcall f_7773(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7792)
static void C_fcall f_7792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7888)
static void C_ccall f_7888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7837)
static void C_ccall f_7837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7823)
static void C_fcall f_7823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7753)
static void C_fcall f_7753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_fcall f_7726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7720)
static void C_fcall f_7720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7629)
static void C_fcall f_7629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_fcall f_7588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7541)
static void C_fcall f_7541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static C_word C_fcall f_7519(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7128)
static void C_fcall f_7128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_fcall f_7180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_fcall f_7109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6803)
static void C_fcall f_6803(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6812)
static void C_fcall f_6812(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6824)
static void C_fcall f_6824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6836)
static void C_fcall f_6836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_fcall f_6876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_fcall f_6720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_fcall f_6689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5842)
static void C_fcall f_5842(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5867)
static void C_fcall f_5867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_fcall f_5882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_fcall f_5897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_fcall f_5935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_fcall f_5950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5992)
static void C_fcall f_5992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6019)
static void C_fcall f_6019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6034)
static void C_fcall f_6034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_fcall f_6049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_fcall f_6093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_fcall f_6138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6385)
static void C_fcall f_6385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_fcall f_6353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_fcall f_6241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6245)
static void C_ccall f_6245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6209)
static void C_fcall f_6209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static C_word C_fcall f_6204(C_word *a,C_word t0);
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_fcall f_6111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_ccall f_6052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_fcall f_5968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_fcall f_5597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5545)
static void C_fcall f_5545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5498)
static void C_fcall f_5498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5408)
static void C_ccall f_5408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5454)
static void C_fcall f_5454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5237)
static void C_fcall f_5237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_fcall f_5052(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_fcall f_5023(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static C_word C_fcall f_4979(C_word t0,C_word t1);
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4930)
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_fcall f_4758(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_fcall f_4752(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_fcall f_4697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4611)
static void C_fcall f_4611(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4336)
static void C_fcall f_4336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_fcall f_4546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4492)
static void C_fcall f_4492(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_fcall f_4179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4236)
static void C_fcall f_4236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_fcall f_4032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_fcall f_3891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_fcall f_3888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_fcall f_3307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_fcall f_3412(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_fcall f_3438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_fcall f_3495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_fcall f_3360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_fcall f_3381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3266)
static void C_fcall f_3266(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_fcall f_3234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2632)
static void C_fcall f_2632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_fcall f_2641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_fcall f_2688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_fcall f_2581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_fcall f_2429(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2439)
static void C_fcall f_2439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_fcall f_2448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_fcall f_2472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2347)
static void C_fcall f_2347(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_fcall f_2375(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_fcall f_2239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2134)
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_fcall f_2081(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_fcall f_2089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_fcall f_2034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1882)
static void C_fcall f_1882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_fcall f_1889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1804)
static void C_fcall f_1804(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1722)
static C_word C_fcall f_1722(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1672)
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1651)
static void C_fcall f_1651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1611)
static void C_fcall f_1611(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1536)
static void C_fcall f_1536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8789)
static void C_fcall trf_8789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8789(t0,t1);}

C_noret_decl(trf_8834)
static void C_fcall trf_8834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8834(t0,t1,t2);}

C_noret_decl(trf_8760)
static void C_fcall trf_8760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8760(t0,t1);}

C_noret_decl(trf_8633)
static void C_fcall trf_8633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8633(t0,t1);}

C_noret_decl(trf_8521)
static void C_fcall trf_8521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8521(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8521(t0,t1,t2,t3);}

C_noret_decl(trf_8566)
static void C_fcall trf_8566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8566(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8566(t0,t1,t2);}

C_noret_decl(trf_8437)
static void C_fcall trf_8437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8437(t0,t1);}

C_noret_decl(trf_8377)
static void C_fcall trf_8377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8377(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8377(t0,t1,t2,t3);}

C_noret_decl(trf_8330)
static void C_fcall trf_8330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8330(t0,t1);}

C_noret_decl(trf_8164)
static void C_fcall trf_8164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8164(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8164(t0,t1,t2);}

C_noret_decl(trf_8136)
static void C_fcall trf_8136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8136(t0,t1);}

C_noret_decl(trf_8020)
static void C_fcall trf_8020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8020(t0,t1,t2,t3);}

C_noret_decl(trf_7985)
static void C_fcall trf_7985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7985(t0,t1,t2);}

C_noret_decl(trf_7991)
static void C_fcall trf_7991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7991(t0,t1,t2);}

C_noret_decl(trf_7938)
static void C_fcall trf_7938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7938(t0,t1,t2,t3);}

C_noret_decl(trf_7944)
static void C_fcall trf_7944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7944(t0,t1,t2);}

C_noret_decl(trf_7914)
static void C_fcall trf_7914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7914(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7914(t0,t1,t2,t3);}

C_noret_decl(trf_7773)
static void C_fcall trf_7773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7773(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7773(t0,t1,t2,t3);}

C_noret_decl(trf_7792)
static void C_fcall trf_7792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7792(t0,t1);}

C_noret_decl(trf_7823)
static void C_fcall trf_7823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7823(t0,t1);}

C_noret_decl(trf_7753)
static void C_fcall trf_7753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7753(t0,t1);}

C_noret_decl(trf_7726)
static void C_fcall trf_7726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7726(t0,t1);}

C_noret_decl(trf_7720)
static void C_fcall trf_7720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7720(t0,t1);}

C_noret_decl(trf_7629)
static void C_fcall trf_7629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7629(t0,t1);}

C_noret_decl(trf_7588)
static void C_fcall trf_7588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7588(t0,t1);}

C_noret_decl(trf_7541)
static void C_fcall trf_7541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7541(t0,t1);}

C_noret_decl(trf_7128)
static void C_fcall trf_7128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7128(t0,t1);}

C_noret_decl(trf_7180)
static void C_fcall trf_7180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7180(t0,t1);}

C_noret_decl(trf_7109)
static void C_fcall trf_7109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7109(t0,t1);}

C_noret_decl(trf_6803)
static void C_fcall trf_6803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6803(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6803(t0,t1);}

C_noret_decl(trf_6812)
static void C_fcall trf_6812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6812(t0,t1);}

C_noret_decl(trf_6824)
static void C_fcall trf_6824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6824(t0,t1);}

C_noret_decl(trf_6836)
static void C_fcall trf_6836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6836(t0,t1);}

C_noret_decl(trf_6876)
static void C_fcall trf_6876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6876(t0,t1);}

C_noret_decl(trf_6720)
static void C_fcall trf_6720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6720(t0,t1);}

C_noret_decl(trf_6689)
static void C_fcall trf_6689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6689(t0,t1);}

C_noret_decl(trf_5842)
static void C_fcall trf_5842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5842(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5842(t0,t1,t2);}

C_noret_decl(trf_5867)
static void C_fcall trf_5867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5867(t0,t1);}

C_noret_decl(trf_5882)
static void C_fcall trf_5882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5882(t0,t1);}

C_noret_decl(trf_5897)
static void C_fcall trf_5897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5897(t0,t1);}

C_noret_decl(trf_5935)
static void C_fcall trf_5935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5935(t0,t1);}

C_noret_decl(trf_5950)
static void C_fcall trf_5950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5950(t0,t1);}

C_noret_decl(trf_5992)
static void C_fcall trf_5992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5992(t0,t1);}

C_noret_decl(trf_6019)
static void C_fcall trf_6019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6019(t0,t1);}

C_noret_decl(trf_6034)
static void C_fcall trf_6034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6034(t0,t1);}

C_noret_decl(trf_6049)
static void C_fcall trf_6049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6049(t0,t1);}

C_noret_decl(trf_6093)
static void C_fcall trf_6093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6093(t0,t1);}

C_noret_decl(trf_6138)
static void C_fcall trf_6138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6138(t0,t1);}

C_noret_decl(trf_6385)
static void C_fcall trf_6385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6385(t0,t1);}

C_noret_decl(trf_6353)
static void C_fcall trf_6353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6353(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6353(t0,t1);}

C_noret_decl(trf_6241)
static void C_fcall trf_6241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6241(t0,t1);}

C_noret_decl(trf_6209)
static void C_fcall trf_6209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6209(t0,t1);}

C_noret_decl(trf_6111)
static void C_fcall trf_6111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6111(t0,t1);}

C_noret_decl(trf_5968)
static void C_fcall trf_5968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5968(t0,t1);}

C_noret_decl(trf_5597)
static void C_fcall trf_5597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5597(t0,t1);}

C_noret_decl(trf_5545)
static void C_fcall trf_5545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5545(t0,t1);}

C_noret_decl(trf_5498)
static void C_fcall trf_5498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5498(t0,t1);}

C_noret_decl(trf_5454)
static void C_fcall trf_5454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5454(t0,t1);}

C_noret_decl(trf_5237)
static void C_fcall trf_5237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5237(t0,t1);}

C_noret_decl(trf_5095)
static void C_fcall trf_5095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5095(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5095(t0,t1,t2,t3);}

C_noret_decl(trf_5130)
static void C_fcall trf_5130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5130(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5130(t0,t1,t2,t3);}

C_noret_decl(trf_5052)
static void C_fcall trf_5052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5052(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5052(t0,t1,t2,t3);}

C_noret_decl(trf_5023)
static void C_fcall trf_5023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5023(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5023(t0,t1,t2,t3);}

C_noret_decl(trf_4930)
static void C_fcall trf_4930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4930(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4930(t0,t1,t2);}

C_noret_decl(trf_4758)
static void C_fcall trf_4758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4758(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4758(t0,t1,t2,t3);}

C_noret_decl(trf_4752)
static void C_fcall trf_4752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4752(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4752(t0,t1,t2);}

C_noret_decl(trf_4697)
static void C_fcall trf_4697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4697(t0,t1);}

C_noret_decl(trf_4611)
static void C_fcall trf_4611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4611(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4611(t0,t1,t2);}

C_noret_decl(trf_4336)
static void C_fcall trf_4336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4336(t0,t1);}

C_noret_decl(trf_4546)
static void C_fcall trf_4546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4546(t0,t1);}

C_noret_decl(trf_4492)
static void C_fcall trf_4492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4492(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4492(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4179)
static void C_fcall trf_4179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4179(t0,t1);}

C_noret_decl(trf_4236)
static void C_fcall trf_4236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4236(t0,t1);}

C_noret_decl(trf_4032)
static void C_fcall trf_4032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4032(t0,t1);}

C_noret_decl(trf_3891)
static void C_fcall trf_3891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3891(t0,t1);}

C_noret_decl(trf_3888)
static void C_fcall trf_3888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3888(t0,t1);}

C_noret_decl(trf_3307)
static void C_fcall trf_3307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3307(t0,t1);}

C_noret_decl(trf_3412)
static void C_fcall trf_3412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3412(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3412(t0,t1,t2);}

C_noret_decl(trf_3438)
static void C_fcall trf_3438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3438(t0,t1);}

C_noret_decl(trf_3495)
static void C_fcall trf_3495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3495(t0,t1);}

C_noret_decl(trf_3360)
static void C_fcall trf_3360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3360(t0,t1);}

C_noret_decl(trf_3381)
static void C_fcall trf_3381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3381(t0,t1);}

C_noret_decl(trf_3266)
static void C_fcall trf_3266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3266(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3266(t0,t1,t2);}

C_noret_decl(trf_3234)
static void C_fcall trf_3234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3234(t0,t1);}

C_noret_decl(trf_2632)
static void C_fcall trf_2632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2632(t0,t1);}

C_noret_decl(trf_2641)
static void C_fcall trf_2641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2641(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2641(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2688)
static void C_fcall trf_2688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2688(t0,t1);}

C_noret_decl(trf_2581)
static void C_fcall trf_2581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2581(t0,t1);}

C_noret_decl(trf_2429)
static void C_fcall trf_2429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2429(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2429(t0,t1,t2,t3);}

C_noret_decl(trf_2439)
static void C_fcall trf_2439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2439(t0,t1);}

C_noret_decl(trf_2448)
static void C_fcall trf_2448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2448(t0,t1);}

C_noret_decl(trf_2472)
static void C_fcall trf_2472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2472(t0,t1);}

C_noret_decl(trf_2347)
static void C_fcall trf_2347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2347(t0,t1,t2);}

C_noret_decl(trf_2375)
static void C_fcall trf_2375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2375(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2375(t0,t1);}

C_noret_decl(trf_2239)
static void C_fcall trf_2239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2239(t0,t1);}

C_noret_decl(trf_2134)
static void C_fcall trf_2134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2134(t0,t1,t2,t3);}

C_noret_decl(trf_2081)
static void C_fcall trf_2081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2081(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2081(t0,t1,t2);}

C_noret_decl(trf_2089)
static void C_fcall trf_2089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2089(t0,t1);}

C_noret_decl(trf_2034)
static void C_fcall trf_2034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2034(t0,t1);}

C_noret_decl(trf_1860)
static void C_fcall trf_1860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1860(t0,t1,t2);}

C_noret_decl(trf_1882)
static void C_fcall trf_1882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1882(t0,t1);}

C_noret_decl(trf_1889)
static void C_fcall trf_1889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1889(t0,t1);}

C_noret_decl(trf_1804)
static void C_fcall trf_1804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1804(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1804(t0,t1,t2,t3);}

C_noret_decl(trf_1672)
static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1672(t0,t1,t2,t3);}

C_noret_decl(trf_1651)
static void C_fcall trf_1651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1651(t0,t1);}

C_noret_decl(trf_1611)
static void C_fcall trf_1611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1611(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1611(t0,t1,t2);}

C_noret_decl(trf_1536)
static void C_fcall trf_1536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1536(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5104)){
C_save(t1);
C_rereclaim2(5104*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,506);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\011\012CHICKEN\012");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000 (c)2000-2008 Felix L. Winkelmann");
lf[7]=C_h_intern(&lf[7],30,"\010compilercompiler-cleanup-hook");
lf[8]=C_h_intern(&lf[8],26,"\010compilerdebugging-chicken");
lf[9]=C_h_intern(&lf[9],26,"\010compilerdisabled-warnings");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_h_intern(&lf[11],5,"error");
lf[12]=C_h_intern(&lf[12],13,"string-append");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\034[internal compiler screwup] ");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\033[internal compiler screwup]");
lf[15]=C_h_intern(&lf[15],18,"\010compilerdebugging");
lf[16]=C_h_intern(&lf[16],12,"flush-output");
lf[17]=C_h_intern(&lf[17],7,"newline");
lf[18]=C_h_intern(&lf[18],6,"printf");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[20]=C_h_intern(&lf[20],5,"force");
lf[21]=C_h_intern(&lf[21],12,"\003sysfor-each");
lf[22]=C_h_intern(&lf[22],7,"display");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[25]=C_h_intern(&lf[25],25,"\010compilercompiler-warning");
lf[26]=C_h_intern(&lf[26],7,"fprintf");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[28]=C_h_intern(&lf[28],18,"current-error-port");
lf[29]=C_h_intern(&lf[29],20,"\003syswarnings-enabled");
lf[30]=C_h_intern(&lf[30],4,"quit");
lf[31]=C_h_intern(&lf[31],4,"exit");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[33]=C_h_intern(&lf[33],21,"\003syssyntax-error-hook");
lf[34]=C_h_intern(&lf[34],16,"print-call-chain");
lf[35]=C_h_intern(&lf[35],18,"\003syscurrent-thread");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[39]=C_h_intern(&lf[39],12,"syntax-error");
lf[40]=C_h_intern(&lf[40],31,"\010compileremit-syntax-trace-info");
lf[41]=C_h_intern(&lf[41],9,"map-llist");
lf[42]=C_h_intern(&lf[42],24,"\010compilercheck-signature");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[44]=C_h_intern(&lf[44],18,"\010compilerreal-name");
lf[45]=C_h_intern(&lf[45],13,"\010compilerposq");
lf[46]=C_h_intern(&lf[46],18,"\010compilerstringify");
lf[47]=C_h_intern(&lf[47],14,"symbol->string");
lf[48]=C_h_intern(&lf[48],7,"sprintf");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[50]=C_h_intern(&lf[50],18,"\010compilersymbolify");
lf[51]=C_h_intern(&lf[51],14,"string->symbol");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[53]=C_h_intern(&lf[53],26,"\010compilerbuild-lambda-list");
lf[54]=C_h_intern(&lf[54],29,"\010compilerstring->c-identifier");
lf[55]=C_h_intern(&lf[55],24,"\003sysstring->c-identifier");
lf[56]=C_h_intern(&lf[56],21,"\010compilerc-ify-string");
lf[57]=C_h_intern(&lf[57],16,"\003syslist->string");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[59]=C_h_intern(&lf[59],6,"append");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[61]=C_h_intern(&lf[61],16,"\003sysstring->list");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[65]=C_h_intern(&lf[65],28,"\010compilervalid-c-identifier\077");
lf[66]=C_h_intern(&lf[66],3,"any");
lf[67]=C_h_intern(&lf[67],8,"->string");
lf[68]=C_h_intern(&lf[68],14,"\010compilerwords");
lf[69]=C_h_intern(&lf[69],21,"\010compilerwords->bytes");
lf[70]=C_h_intern(&lf[70],34,"\010compilercheck-and-open-input-file");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[72]=C_h_intern(&lf[72],18,"current-input-port");
lf[73]=C_h_intern(&lf[73],15,"open-input-file");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[76]=C_h_intern(&lf[76],12,"file-exists\077");
lf[77]=C_h_intern(&lf[77],33,"\010compilerclose-checked-input-file");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[79]=C_h_intern(&lf[79],16,"close-input-port");
lf[80]=C_h_intern(&lf[80],19,"\010compilerfold-inner");
lf[81]=C_h_intern(&lf[81],7,"reverse");
lf[82]=C_h_intern(&lf[82],28,"\010compilerfollow-without-loop");
lf[83]=C_h_intern(&lf[83],18,"\010compilerconstant\077");
lf[84]=C_h_intern(&lf[84],5,"quote");
lf[85]=C_h_intern(&lf[85],29,"\010compilercollapsable-literal\077");
lf[86]=C_h_intern(&lf[86],19,"\010compilerimmediate\077");
lf[87]=C_h_intern(&lf[87],20,"\010compilerbig-fixnum\077");
lf[88]=C_h_intern(&lf[88],23,"\010compilerbasic-literal\077");
lf[89]=C_h_intern(&lf[89],5,"every");
lf[90]=C_h_intern(&lf[90],12,"vector->list");
lf[91]=C_h_intern(&lf[91],32,"\010compilercanonicalize-begin-body");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[94]=C_h_intern(&lf[94],3,"let");
lf[95]=C_h_intern(&lf[95],6,"gensym");
lf[96]=C_h_intern(&lf[96],1,"t");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[98]=C_h_intern(&lf[98],34,"\010compilerextract-mutable-constants");
lf[99]=C_h_intern(&lf[99],12,"\004coreinclude");
lf[100]=C_h_intern(&lf[100],9,"\004coreset!");
lf[101]=C_h_intern(&lf[101],5,"cons*");
lf[102]=C_h_intern(&lf[102],7,"\003sysmap");
lf[103]=C_h_intern(&lf[103],2,"if");
lf[104]=C_h_intern(&lf[104],20,"\004corecompiletimeonly");
lf[105]=C_h_intern(&lf[105],19,"\004corecompiletimetoo");
lf[106]=C_h_intern(&lf[106],4,"set!");
lf[107]=C_h_intern(&lf[107],6,"lambda");
lf[108]=C_h_intern(&lf[108],11,"\004coreinline");
lf[109]=C_h_intern(&lf[109],20,"\004coreinline_allocate");
lf[110]=C_h_intern(&lf[110],18,"\004coreinline_update");
lf[111]=C_h_intern(&lf[111],19,"\004coreinline_loc_ref");
lf[112]=C_h_intern(&lf[112],22,"\004coreinline_loc_update");
lf[113]=C_h_intern(&lf[113],12,"\004coredeclare");
lf[114]=C_h_intern(&lf[114],14,"\004coreimmutable");
lf[115]=C_h_intern(&lf[115],14,"\004coreundefined");
lf[116]=C_h_intern(&lf[116],14,"\004coreprimitive");
lf[117]=C_h_intern(&lf[117],15,"\004coreinline_ref");
lf[118]=C_h_intern(&lf[118],10,"alist-cons");
lf[119]=C_h_intern(&lf[119],25,"\010compilermake-random-name");
lf[120]=C_h_intern(&lf[120],3,"map");
lf[121]=C_h_intern(&lf[121],4,"caar");
lf[122]=C_h_intern(&lf[122],5,"cadar");
lf[123]=C_h_intern(&lf[123],5,"cddar");
lf[124]=C_h_intern(&lf[124],4,"cdar");
lf[125]=C_h_intern(&lf[125],21,"\010compilerstring->expr");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[128]=C_h_intern(&lf[128],5,"begin");
lf[129]=C_h_intern(&lf[129],4,"read");
lf[130]=C_h_intern(&lf[130],6,"unfold");
lf[131]=C_h_intern(&lf[131],11,"eof-object\077");
lf[132]=C_h_intern(&lf[132],6,"values");
lf[133]=C_h_intern(&lf[133],22,"with-input-from-string");
lf[134]=C_h_intern(&lf[134],22,"with-exception-handler");
lf[135]=C_h_intern(&lf[135],30,"call-with-current-continuation");
lf[136]=C_h_intern(&lf[136],30,"\010compilerdecompose-lambda-list");
lf[137]=C_h_intern(&lf[137],25,"\003sysdecompose-lambda-list");
lf[138]=C_h_intern(&lf[138],37,"\010compilerprocess-lambda-documentation");
lf[139]=C_h_intern(&lf[139],30,"\010compilerexpand-profile-lambda");
lf[140]=C_h_intern(&lf[140],29,"\010compilerprofile-lambda-index");
lf[141]=C_h_intern(&lf[141],28,"\010compilerprofile-lambda-list");
lf[142]=C_h_intern(&lf[142],17,"\003sysprofile-entry");
lf[143]=C_h_intern(&lf[143],33,"\010compilerprofile-info-vector-name");
lf[144]=C_h_intern(&lf[144],5,"apply");
lf[145]=C_h_intern(&lf[145],16,"\003sysprofile-exit");
lf[146]=C_h_intern(&lf[146],16,"\003sysdynamic-wind");
lf[147]=C_h_intern(&lf[147],37,"\010compilerinitialize-analysis-database");
lf[148]=C_h_intern(&lf[148],13,"\010compilerput!");
lf[149]=C_h_intern(&lf[149],8,"constant");
lf[150]=C_h_intern(&lf[150],26,"\010compilermutable-constants");
lf[151]=C_h_intern(&lf[151],35,"\010compilerfoldable-extended-bindings");
lf[152]=C_h_intern(&lf[152],8,"foldable");
lf[153]=C_h_intern(&lf[153],16,"extended-binding");
lf[154]=C_h_intern(&lf[154],17,"extended-bindings");
lf[155]=C_h_intern(&lf[155],35,"\010compilerfoldable-standard-bindings");
lf[156]=C_h_intern(&lf[156],41,"\010compilerside-effecting-standard-bindings");
lf[157]=C_h_intern(&lf[157],14,"side-effecting");
lf[158]=C_h_intern(&lf[158],16,"standard-binding");
lf[159]=C_h_intern(&lf[159],17,"standard-bindings");
lf[160]=C_h_intern(&lf[160],12,"\010compilerget");
lf[161]=C_h_intern(&lf[161],18,"\003syshash-table-ref");
lf[162]=C_h_intern(&lf[162],16,"\010compilerget-all");
lf[163]=C_h_intern(&lf[163],10,"filter-map");
lf[164]=C_h_intern(&lf[164],19,"\003syshash-table-set!");
lf[165]=C_h_intern(&lf[165],17,"\010compilercollect!");
lf[166]=C_h_intern(&lf[166],15,"\010compilercount!");
lf[167]=C_h_intern(&lf[167],17,"\010compilerget-line");
lf[168]=C_h_intern(&lf[168],24,"\003sysline-number-database");
lf[169]=C_h_intern(&lf[169],19,"\010compilerget-line-2");
lf[170]=C_h_intern(&lf[170],30,"\010compilerfind-lambda-container");
lf[171]=C_h_intern(&lf[171],12,"contained-in");
lf[172]=C_h_intern(&lf[172],37,"\010compilerdisplay-line-number-database");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[174]=C_h_intern(&lf[174],3,"cdr");
lf[175]=C_h_intern(&lf[175],23,"\003syshash-table-for-each");
lf[176]=C_h_intern(&lf[176],34,"\010compilerdisplay-analysis-database");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[181]=C_h_intern(&lf[181],7,"unknown");
lf[182]=C_h_intern(&lf[182],8,"captured");
lf[183]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[185]=C_h_intern(&lf[185],5,"value");
lf[186]=C_h_intern(&lf[186],15,"potential-value");
lf[187]=C_h_intern(&lf[187],10,"replacable");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[189]=C_h_intern(&lf[189],10,"references");
lf[190]=C_h_intern(&lf[190],10,"call-sites");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[192]=C_h_intern(&lf[192],4,"home");
lf[193]=C_h_intern(&lf[193],8,"contains");
lf[194]=C_h_intern(&lf[194],8,"use-expr");
lf[195]=C_h_intern(&lf[195],12,"closure-size");
lf[196]=C_h_intern(&lf[196],14,"rest-parameter");
lf[197]=C_h_intern(&lf[197],16,"o-r/access-count");
lf[198]=C_h_intern(&lf[198],18,"captured-variables");
lf[199]=C_h_intern(&lf[199],13,"explicit-rest");
lf[200]=C_h_intern(&lf[200],8,"assigned");
lf[201]=C_h_intern(&lf[201],5,"boxed");
lf[202]=C_h_intern(&lf[202],6,"global");
lf[203]=C_h_intern(&lf[203],12,"contractable");
lf[204]=C_h_intern(&lf[204],16,"assigned-locally");
lf[205]=C_h_intern(&lf[205],11,"collapsable");
lf[206]=C_h_intern(&lf[206],9,"removable");
lf[207]=C_h_intern(&lf[207],9,"undefined");
lf[208]=C_h_intern(&lf[208],9,"replacing");
lf[209]=C_h_intern(&lf[209],6,"unused");
lf[210]=C_h_intern(&lf[210],6,"simple");
lf[211]=C_h_intern(&lf[211],9,"inlinable");
lf[212]=C_h_intern(&lf[212],13,"inline-export");
lf[213]=C_h_intern(&lf[213],21,"has-unused-parameters");
lf[214]=C_h_intern(&lf[214],12,"customizable");
lf[215]=C_h_intern(&lf[215],10,"boxed-rest");
lf[216]=C_h_intern(&lf[216],5,"write");
lf[217]=C_h_intern(&lf[217],34,"\010compilerdefault-standard-bindings");
lf[218]=C_h_intern(&lf[218],34,"\010compilerdefault-extended-bindings");
lf[219]=C_h_intern(&lf[219],26,"\010compilerinternal-bindings");
lf[220]=C_h_intern(&lf[220],9,"make-node");
lf[221]=C_h_intern(&lf[221],4,"node");
lf[222]=C_h_intern(&lf[222],5,"node\077");
lf[223]=C_h_intern(&lf[223],15,"node-class-set!");
lf[224]=C_h_intern(&lf[224],14,"\003sysblock-set!");
lf[225]=C_h_intern(&lf[225],10,"node-class");
lf[226]=C_h_intern(&lf[226],20,"node-parameters-set!");
lf[227]=C_h_intern(&lf[227],15,"node-parameters");
lf[228]=C_h_intern(&lf[228],24,"node-subexpressions-set!");
lf[229]=C_h_intern(&lf[229],19,"node-subexpressions");
lf[230]=C_h_intern(&lf[230],16,"\010compilervarnode");
lf[231]=C_h_intern(&lf[231],13,"\004corevariable");
lf[232]=C_h_intern(&lf[232],14,"\010compilerqnode");
lf[233]=C_h_intern(&lf[233],25,"\010compilerbuild-node-graph");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[235]=C_h_intern(&lf[235],15,"\004coreglobal-ref");
lf[236]=C_h_intern(&lf[236],8,"truncate");
lf[237]=C_h_intern(&lf[237],4,"type");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[239]=C_h_intern(&lf[239],6,"fixnum");
lf[240]=C_h_intern(&lf[240],11,"number-type");
lf[241]=C_h_intern(&lf[241],6,"unzip1");
lf[242]=C_h_intern(&lf[242],13,"\004corecallunit");
lf[243]=C_h_intern(&lf[243],9,"\004coreproc");
lf[244]=C_h_intern(&lf[244],29,"\004coreforeign-callback-wrapper");
lf[245]=C_h_intern(&lf[245],5,"sixth");
lf[246]=C_h_intern(&lf[246],5,"fifth");
lf[247]=C_h_intern(&lf[247],8,"\004coreapp");
lf[248]=C_h_intern(&lf[248],9,"\004corecall");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[250]=C_h_intern(&lf[250],24,"\010compilersource-filename");
lf[251]=C_h_intern(&lf[251],28,"\003syssymbol->qualified-string");
lf[252]=C_h_intern(&lf[252],34,"\010compileralways-bound-to-procedure");
lf[253]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[254]=C_h_intern(&lf[254],1,"o");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[256]=C_h_intern(&lf[256],30,"\010compilerbuild-expression-tree");
lf[257]=C_h_intern(&lf[257],12,"\004coreclosure");
lf[258]=C_h_intern(&lf[258],4,"last");
lf[259]=C_h_intern(&lf[259],4,"list");
lf[260]=C_h_intern(&lf[260],7,"butlast");
lf[261]=C_h_intern(&lf[261],11,"\004corelambda");
lf[262]=C_h_intern(&lf[262],9,"\004corebind");
lf[263]=C_h_intern(&lf[263],10,"\004coreunbox");
lf[264]=C_h_intern(&lf[264],8,"\004coreref");
lf[265]=C_h_intern(&lf[265],11,"\004coreupdate");
lf[266]=C_h_intern(&lf[266],13,"\004coreupdate_i");
lf[267]=C_h_intern(&lf[267],8,"\004corebox");
lf[268]=C_h_intern(&lf[268],9,"\004corecond");
lf[269]=C_h_intern(&lf[269],21,"\010compilerfold-boolean");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[271]=C_h_intern(&lf[271],31,"\010compilerinline-lambda-bindings");
lf[272]=C_h_intern(&lf[272],8,"split-at");
lf[273]=C_h_intern(&lf[273],10,"fold-right");
lf[274]=C_h_intern(&lf[274],4,"take");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[276]=C_h_intern(&lf[276],34,"\010compilercopy-node-tree-and-rename");
lf[277]=C_h_intern(&lf[277],9,"alist-ref");
lf[278]=C_h_intern(&lf[278],3,"eq\077");
lf[279]=C_h_intern(&lf[279],18,"\010compilertree-copy");
lf[280]=C_h_intern(&lf[280],4,"cons");
lf[281]=C_h_intern(&lf[281],19,"\010compilercopy-node!");
lf[282]=C_h_intern(&lf[282],19,"\010compilermatch-node");
lf[283]=C_h_intern(&lf[283],1,"a");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[285]=C_h_intern(&lf[285],37,"\010compilerexpression-has-side-effects\077");
lf[286]=C_h_intern(&lf[286],24,"foreign-callback-stub-id");
lf[287]=C_h_intern(&lf[287],4,"find");
lf[288]=C_h_intern(&lf[288],22,"foreign-callback-stubs");
lf[289]=C_h_intern(&lf[289],28,"\010compilersimple-lambda-node\077");
lf[290]=C_h_intern(&lf[290],25,"\010compilerexport-dump-hook");
lf[291]=C_h_intern(&lf[291],30,"\010compilerdump-exported-globals");
lf[292]=C_h_intern(&lf[292],26,"\010compilerblock-compilation");
lf[293]=C_h_intern(&lf[293],8,"string<\077");
lf[294]=C_h_intern(&lf[294],4,"sort");
lf[295]=C_h_intern(&lf[295],20,"\010compilerexport-list");
lf[296]=C_h_intern(&lf[296],22,"\010compilerblock-globals");
lf[297]=C_h_intern(&lf[297],19,"with-output-to-file");
lf[298]=C_h_intern(&lf[298],31,"\010compilerdump-undefined-globals");
lf[299]=C_h_intern(&lf[299],29,"\010compilercheck-global-exports");
lf[300]=C_h_intern(&lf[300],3,"var");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000,exported global variable `~S\047 is not defined");
lf[302]=C_h_intern(&lf[302],6,"delete");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\0005exported global variable `~S\047 is used but not defined");
lf[304]=C_h_intern(&lf[304],29,"\010compilercheck-global-imports");
lf[305]=C_h_intern(&lf[305],5,"redef");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\0000redefinition of imported variable `~s\047 from `~s\047");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000#variable `~s\047 used but not imported");
lf[308]=C_h_intern(&lf[308],8,"keyword\077");
lf[309]=C_h_intern(&lf[309],21,"\010compilerimport-table");
lf[310]=C_h_intern(&lf[310],27,"\010compilerexport-import-hook");
lf[311]=C_h_intern(&lf[311],28,"\010compilerlookup-exports-file");
lf[312]=C_h_intern(&lf[312],9,"read-file");
lf[313]=C_h_intern(&lf[313],21,"\010compilerverbose-mode");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\035loading exports file ~a ...~%");
lf[315]=C_h_intern(&lf[315],28,"\003sysresolve-include-filename");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\010.exports");
lf[317]=C_h_intern(&lf[317],36,"\010compilercompute-database-statistics");
lf[318]=C_h_intern(&lf[318],29,"\010compilercurrent-program-size");
lf[319]=C_h_intern(&lf[319],30,"\010compileroriginal-program-size");
lf[320]=C_h_intern(&lf[320],33,"\010compilerprint-program-statistics");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[327]=C_h_intern(&lf[327],1,"s");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[329]=C_h_intern(&lf[329],35,"\010compilerpprint-expressions-to-file");
lf[330]=C_h_intern(&lf[330],17,"close-output-port");
lf[331]=C_h_intern(&lf[331],12,"pretty-print");
lf[332]=C_h_intern(&lf[332],19,"with-output-to-port");
lf[333]=C_h_intern(&lf[333],16,"open-output-file");
lf[334]=C_h_intern(&lf[334],19,"current-output-port");
lf[335]=C_h_intern(&lf[335],27,"\010compilerforeign-type-check");
lf[336]=C_h_intern(&lf[336],4,"char");
lf[337]=C_h_intern(&lf[337],13,"unsigned-char");
lf[338]=C_h_intern(&lf[338],6,"unsafe");
lf[339]=C_h_intern(&lf[339],25,"\003sysforeign-char-argument");
lf[340]=C_h_intern(&lf[340],3,"int");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-fixnum-argument");
lf[342]=C_h_intern(&lf[342],5,"float");
lf[343]=C_h_intern(&lf[343],27,"\003sysforeign-flonum-argument");
lf[344]=C_h_intern(&lf[344],7,"pointer");
lf[345]=C_h_intern(&lf[345],26,"\003sysforeign-block-argument");
lf[346]=C_h_intern(&lf[346],15,"nonnull-pointer");
lf[347]=C_h_intern(&lf[347],8,"u8vector");
lf[348]=C_h_intern(&lf[348],34,"\003sysforeign-number-vector-argument");
lf[349]=C_h_intern(&lf[349],16,"nonnull-u8vector");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[351]=C_h_intern(&lf[351],7,"integer");
lf[352]=C_h_intern(&lf[352],28,"\003sysforeign-integer-argument");
lf[353]=C_h_intern(&lf[353],16,"unsigned-integer");
lf[354]=C_h_intern(&lf[354],37,"\003sysforeign-unsigned-integer-argument");
lf[355]=C_h_intern(&lf[355],9,"c-pointer");
lf[356]=C_h_intern(&lf[356],28,"\003sysforeign-pointer-argument");
lf[357]=C_h_intern(&lf[357],17,"nonnull-c-pointer");
lf[358]=C_h_intern(&lf[358],8,"c-string");
lf[359]=C_h_intern(&lf[359],17,"\003sysmake-c-string");
lf[360]=C_h_intern(&lf[360],27,"\003sysforeign-string-argument");
lf[361]=C_h_intern(&lf[361],16,"nonnull-c-string");
lf[362]=C_h_intern(&lf[362],6,"symbol");
lf[363]=C_h_intern(&lf[363],18,"\003syssymbol->string");
lf[364]=C_h_intern(&lf[364],4,"this");
lf[365]=C_h_intern(&lf[365],8,"slot-ref");
lf[366]=C_h_intern(&lf[366],3,"ref");
lf[367]=C_h_intern(&lf[367],8,"function");
lf[368]=C_h_intern(&lf[368],8,"instance");
lf[369]=C_h_intern(&lf[369],12,"instance-ref");
lf[370]=C_h_intern(&lf[370],16,"nonnull-instance");
lf[371]=C_h_intern(&lf[371],5,"const");
lf[372]=C_h_intern(&lf[372],4,"enum");
lf[373]=C_h_intern(&lf[373],27,"\010compilerforeign-type-table");
lf[374]=C_h_intern(&lf[374],17,"nonnull-c-string*");
lf[375]=C_h_intern(&lf[375],26,"nonnull-unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],9,"c-string*");
lf[377]=C_h_intern(&lf[377],18,"unsigned-c-string*");
lf[378]=C_h_intern(&lf[378],13,"c-string-list");
lf[379]=C_h_intern(&lf[379],14,"c-string-list*");
lf[380]=C_h_intern(&lf[380],18,"unsigned-integer32");
lf[381]=C_h_intern(&lf[381],13,"unsigned-long");
lf[382]=C_h_intern(&lf[382],4,"long");
lf[383]=C_h_intern(&lf[383],9,"integer32");
lf[384]=C_h_intern(&lf[384],17,"nonnull-u16vector");
lf[385]=C_h_intern(&lf[385],16,"nonnull-s8vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s16vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-u32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-s32vector");
lf[389]=C_h_intern(&lf[389],17,"nonnull-f32vector");
lf[390]=C_h_intern(&lf[390],17,"nonnull-f64vector");
lf[391]=C_h_intern(&lf[391],9,"u16vector");
lf[392]=C_h_intern(&lf[392],8,"s8vector");
lf[393]=C_h_intern(&lf[393],9,"s16vector");
lf[394]=C_h_intern(&lf[394],9,"u32vector");
lf[395]=C_h_intern(&lf[395],9,"s32vector");
lf[396]=C_h_intern(&lf[396],9,"f32vector");
lf[397]=C_h_intern(&lf[397],9,"f64vector");
lf[398]=C_h_intern(&lf[398],22,"nonnull-scheme-pointer");
lf[399]=C_h_intern(&lf[399],12,"nonnull-blob");
lf[400]=C_h_intern(&lf[400],19,"nonnull-byte-vector");
lf[401]=C_h_intern(&lf[401],11,"byte-vector");
lf[402]=C_h_intern(&lf[402],4,"blob");
lf[403]=C_h_intern(&lf[403],14,"scheme-pointer");
lf[404]=C_h_intern(&lf[404],6,"double");
lf[405]=C_h_intern(&lf[405],6,"number");
lf[406]=C_h_intern(&lf[406],12,"unsigned-int");
lf[407]=C_h_intern(&lf[407],5,"short");
lf[408]=C_h_intern(&lf[408],14,"unsigned-short");
lf[409]=C_h_intern(&lf[409],4,"byte");
lf[410]=C_h_intern(&lf[410],13,"unsigned-byte");
lf[411]=C_h_intern(&lf[411],5,"int32");
lf[412]=C_h_intern(&lf[412],14,"unsigned-int32");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[414]=C_h_intern(&lf[414],36,"\010compilerforeign-type-convert-result");
lf[415]=C_h_intern(&lf[415],38,"\010compilerforeign-type-convert-argument");
lf[416]=C_h_intern(&lf[416],27,"\010compilerfinal-foreign-type");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[418]=C_h_intern(&lf[418],37,"\010compilerestimate-foreign-result-size");
lf[419]=C_h_intern(&lf[419],9,"integer64");
lf[420]=C_h_intern(&lf[420],4,"bool");
lf[421]=C_h_intern(&lf[421],4,"void");
lf[422]=C_h_intern(&lf[422],13,"scheme-object");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[424]=C_h_intern(&lf[424],46,"\010compilerestimate-foreign-result-location-size");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[427]=C_h_intern(&lf[427],30,"\010compilerfinish-foreign-result");
lf[428]=C_h_intern(&lf[428],17,"\003syspeek-c-string");
lf[429]=C_h_intern(&lf[429],25,"\003syspeek-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],26,"\003syspeek-and-free-c-string");
lf[431]=C_h_intern(&lf[431],34,"\003syspeek-and-free-nonnull-c-string");
lf[432]=C_h_intern(&lf[432],17,"\003sysintern-symbol");
lf[433]=C_h_intern(&lf[433],22,"\003syspeek-c-string-list");
lf[434]=C_h_intern(&lf[434],31,"\003syspeek-and-free-c-string-list");
lf[435]=C_h_intern(&lf[435],35,"\010tinyclosmake-instance-from-pointer");
lf[436]=C_h_intern(&lf[436],4,"make");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-used-variables");
lf[438]=C_h_intern(&lf[438],28,"\010compilerscan-free-variables");
lf[439]=C_h_intern(&lf[439],11,"lset-adjoin");
lf[440]=C_h_intern(&lf[440],25,"\010compilertopological-sort");
lf[441]=C_h_intern(&lf[441],7,"colored");
lf[442]=C_h_intern(&lf[442],23,"\010compilerchop-separator");
lf[443]=C_h_intern(&lf[443],9,"substring");
lf[444]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[445]=C_h_intern(&lf[445],23,"\010compilerchop-extension");
lf[446]=C_h_intern(&lf[446],22,"\010compilerprint-version");
lf[447]=C_h_intern(&lf[447],5,"print");
lf[448]=C_h_intern(&lf[448],15,"chicken-version");
lf[449]=C_h_intern(&lf[449],6,"print*");
lf[450]=C_h_intern(&lf[450],9,"\003syserror");
lf[451]=C_h_intern(&lf[451],20,"\010compilerprint-usage");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\021\244Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012    -quiet               "
"       do not display compile information\012\012  File and pathname options:\012\012    -ou"
"tput-file FILENAME       specifies output-filename, default is \047out.c\047\012    -incl"
"ude-path PATHNAME      specifies alternative path for included files\012    -to-std"
"out                  write compiled file to stdout instead of file\012\012  Language o"
"ptions:\012\012    -feature SYMBOL             register feature identifier\012\012  Syntax r"
"elated options:\012\012    -case-insensitive           don\047t preserve case of read sym"
"bols\012    -keyword-style STYLE        allow alternative keyword syntax (none, pre"
"fix or suffix)\012    -run-time-macros            macros are made available at run-"
"time\012\012  Translation options:\012\012    -explicit-use               do not use units \047"
"library\047 and \047eval\047 by default\012    -check-syntax               stop compilation "
"after macro-expansion\012    -analyze-only               stop compilation after fir"
"st analysis pass\012\012  Debugging options:\012\012    -no-warnings                disable "
"warnings\012    -disable-warning CLASS      disable specific class of warnings\012    "
"-debug-level NUMBER         set level of available debugging information\012    -no"
"-trace                   disable tracing information\012    -profile               "
"     executable emits profiling information \012    -profile-name FILENAME      nam"
"e of the generated profile information file\012    -accumulate-profile         exec"
"utable emits profiling information in append mode\012    -no-lambda-info           "
"  omit additional procedure-information\012    -emit-exports FILENAME      write ex"
"ported toplevel variables to FILENAME\012    -check-imports              look for u"
"ndefined toplevel variables\012    -import FILENAME            read externally expo"
"rted symbols from FILENAME\012\012  Optimization options:\012\012    -optimize-level NUMBER "
"     enable certain sets of optimization options\012    -optimize-leaf-routines    "
" enable leaf routine optimization\012    -lambda-lift                enable lambda-"
"lifting\012    -no-usual-integrations      standard procedures may be redefined\012   "
" -unsafe                     disable safety checks\012    -block                   "
"   enable block-compilation\012    -disable-interrupts         disable interrupts i"
"n compiled code\012    -fixnum-arithmetic          assume all numbers are fixnums\012 "
"   -benchmark-mode             fixnum mode, no interrupts and opt.-level 3\012    -"
"disable-stack-overflow-checks  disables detection of stack-overflows.\012    -inlin"
"e                     enable inlining\012    -inline-limit               set inlini"
"ng threshold\012\012  Configuration options:\012\012    -unit NAME                  compile "
"file as a library unit\012    -uses NAME                  declare library unit as u"
"sed.\012    -heap-size NUMBER           specifies heap-size of compiled executable\012"
"    -heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-gr"
"owth PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage "
"PERCENTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER\012    -s"
"tack-size NUMBER          specifies nursery size of compiled executable\012    -ext"
"end FILENAME            load file before compilation commences\012    -prelude EXPR"
"ESSION         add expression to front of source file\012    -postlude EXPRESSION  "
"      add expression to end of source file\012    -prologue FILENAME          inclu"
"de file before main source file\012    -epilogue FILENAME          include file aft"
"er main source file\012    -dynamic                    compile as dynamically loada"
"ble code\012    -require-extension NAME     require extension NAME in compiled code"
"\012    -extension                  compile as extension (dynamic or static)\012\012  Obs"
"cure options:\012\012    -debug MODES                display debugging output for the "
"given modes\012    -unsafe-libraries           marks the generated file as being li"
"nked\012                                with the unsafe runtime system\012    -raw    "
"                    do not generate implicit init- and exit code\011\011\011       \012    -"
"emit-external-prototypes-first  emit protoypes for callbacks before foreign\012    "
"                            declarations\012");
lf[453]=C_h_intern(&lf[453],36,"\010compilermake-block-variable-literal");
lf[454]=C_h_intern(&lf[454],22,"block-variable-literal");
lf[455]=C_h_intern(&lf[455],32,"\010compilerblock-variable-literal\077");
lf[456]=C_h_intern(&lf[456],32,"block-variable-literal-name-set!");
lf[457]=C_h_intern(&lf[457],36,"\010compilerblock-variable-literal-name");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[459]=C_h_intern(&lf[459],6,"random");
lf[460]=C_h_intern(&lf[460],15,"current-seconds");
lf[461]=C_h_intern(&lf[461],23,"\010compilerset-real-name!");
lf[462]=C_h_intern(&lf[462],24,"\010compilerreal-name-table");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[464]=C_h_intern(&lf[464],19,"\010compilerreal-name2");
lf[465]=C_h_intern(&lf[465],32,"\010compilerdisplay-real-name-table");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[467]=C_h_intern(&lf[467],28,"\010compilersource-info->string");
lf[468]=C_h_intern(&lf[468],4,"conc");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[471]=C_h_intern(&lf[471],11,"make-string");
lf[472]=C_h_intern(&lf[472],3,"max");
lf[473]=C_h_intern(&lf[473],12,"string-null\077");
lf[474]=C_h_intern(&lf[474],19,"\010compilerdump-nodes");
lf[475]=C_h_intern(&lf[475],19,"\003syswrite-char/port");
lf[476]=C_h_intern(&lf[476],19,"\003sysstandard-output");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[480]=C_h_intern(&lf[480],18,"\003sysuser-read-hook");
lf[481]=C_h_intern(&lf[481],15,"foreign-declare");
lf[482]=C_h_intern(&lf[482],7,"declare");
lf[483]=C_h_intern(&lf[483],34,"\010compilerscan-sharp-greater-string");
lf[484]=C_h_intern(&lf[484],18,"\003sysread-char/port");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[486]=C_h_intern(&lf[486],17,"get-output-string");
lf[487]=C_h_intern(&lf[487],18,"open-output-string");
lf[488]=C_h_intern(&lf[488],35,"\010compilerprocess-custom-declaration");
lf[489]=C_h_intern(&lf[489],29,"\010compilercustom-declare-alist");
lf[490]=C_h_intern(&lf[490],31,"\010compileremit-control-file-item");
lf[491]=C_h_intern(&lf[491],25,"\010compilercsc-control-file");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\004~S~%");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\006#%csc\012");
lf[494]=C_h_intern(&lf[494],26,"pathname-replace-extension");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[496]=C_h_intern(&lf[496],32,"\010compilerregister-compiler-macro");
lf[497]=C_h_intern(&lf[497],29,"\010compilercompiler-macro-table");
lf[498]=C_h_intern(&lf[498],4,"eval");
lf[499]=C_h_intern(&lf[499],6,"\000whole");
lf[500]=C_h_intern(&lf[500],7,"call/cc");
lf[501]=C_h_intern(&lf[501],11,"make-vector");
lf[502]=C_h_intern(&lf[502],27,"condition-property-accessor");
lf[503]=C_h_intern(&lf[503],3,"exn");
lf[504]=C_h_intern(&lf[504],7,"message");
lf[505]=C_h_intern(&lf[505],19,"condition-predicate");
C_register_lf2(lf,506,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1442 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1445 in k1442 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1448 in k1445 in k1442 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate(&lf[3],lf[4]);
t4=C_mutate(&lf[5],lf[6]);
t5=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1457,tmp=(C_word)a,a+=2,tmp));
t6=C_set_block_item(lf[8],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[9],0,C_SCHEME_END_OF_LIST);
t8=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1462,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1489,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1529,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1558,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1577,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[39]+1,C_retrieve(lf[33]));
t14=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1602,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1605,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1648,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1716,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1752,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1773,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1798,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[54]+1,C_retrieve(lf[55]));
t22=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1842,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1936,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1992,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1999,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2006,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2053,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2065,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2128,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2159,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2205,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2235,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2281,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2341,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2424,tmp=(C_word)a,a+=2,tmp));
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 318  condition-predicate */
t37=C_retrieve(lf[505]);
((C_proc3)C_retrieve_proc(t37))(3,t37,t36,lf[503]);}

/* k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 319  condition-property-accessor */
t3=C_retrieve(lf[502]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[503],lf[504]);}

/* k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[136]+1,C_retrieve(lf[137]));
t4=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2902,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2905,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[147]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2962,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3023,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3041,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3059,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3105,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[166]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3157,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3214,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3224,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3260,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3284,tmp=(C_word)a,a+=2,tmp));
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3303,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3713,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3719,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3725,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3734,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3743,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3752,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3761,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3770,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3779,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3785,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3794,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3803,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4311,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4605,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4653,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4746,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4924,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[281]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4958,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5020,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5215,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5301,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[290]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5393,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[291]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5399,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5485,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5516,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5560,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5618,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5624,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5675,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5755,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5794,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5830,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6685,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6716,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6747,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6787,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7106,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[427]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7416,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[437]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7692,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7770,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7929,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[442]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8126,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[445]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8155,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[446]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8197,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[451]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8235,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[453]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8247,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[455]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8253,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[456]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8259,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[457]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8268,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8277,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[461]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8321,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8327,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[464]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8406,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[465]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8418,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[467]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8430,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[473]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8506,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[474]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8512,tmp=(C_word)a,a+=2,tmp));
t76=C_retrieve(lf[480]);
t77=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8599,a[2]=t76,tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[483]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8624,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[488]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8693,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[490]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8756,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[496]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8785,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8896,tmp=(C_word)a,a+=2,tmp));
t83=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t83+1)))(2,t83,C_SCHEME_UNDEFINED);}

/* ##compiler#big-fixnum? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8896,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8785,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8789,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[497]))){
t6=t5;
f_8789(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8894,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1493 make-vector */
t7=*((C_word*)lf[501]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k8892 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[497]+1,t1);
t3=((C_word*)t0)[2];
f_8789(t3,t2);}

/* k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8789,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1494 call/cc */
t3=*((C_word*)lf[500]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8794,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8798,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1496 gensym */
t4=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8796 in a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8798,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8801,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8834,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8834(t8,t4,((C_word*)t0)[2]);}

/* loop in k8796 in a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8834,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[499],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8850,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=t5;
f_8850(2,t7,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 1502 return */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8878,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* support.scm: 1505 loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8876 in loop in k8796 in a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8878,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8848 in loop in k8796 in a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cddr(((C_word*)t0)[4]));}

/* k8799 in k8796 in a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8804,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8808,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)((C_word*)t0)[3])[1]);
t5=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,lf[107],t5);
t7=(C_word)C_a_i_list(&a,2,lf[174],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_a_i_list(&a,3,lf[144],t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[107],t4,t8);
/* support.scm: 1509 eval */
t10=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,t9);}

/* k8806 in k8799 in k8796 in a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1506 ##sys#hash-table-set! */
t2=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[497]),((C_word*)t0)[2],t1);}

/* k8802 in k8799 in k8796 in a8793 in k8787 in ##compiler#register-compiler-macro in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#emit-control-file-item in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8756,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8760,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[491]))){
t4=t3;
f_8760(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8767,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8783,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1479 pathname-replace-extension */
t6=C_retrieve(lf[494]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[250]),lf[495]);}}

/* k8781 in ##compiler#emit-control-file-item in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1479 open-output-file */
t2=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8765 in ##compiler#emit-control-file-item in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8767,2,t0,t1);}
t2=C_mutate((C_word*)lf[491]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1480 display */
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[493],C_retrieve(lf[491]));}

/* k8768 in k8765 in ##compiler#emit-control-file-item in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8770,2,t0,t1);}
t2=C_retrieve(lf[7]);
t3=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8772,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
f_8760(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k8768 in k8765 in ##compiler#emit-control-file-item in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8776,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1484 close-output-port */
t3=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[491]));}

/* k8774 in ##compiler#compiler-cleanup-hook in k8768 in k8765 in ##compiler#emit-control-file-item in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1485 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8758 in ##compiler#emit-control-file-item in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1486 fprintf */
t2=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[491]),lf[492],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8693,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[489]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8715,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_8715(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8730,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1466 open-output-file */
t14=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k8728 in ##compiler#process-custom-declaration in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8730,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[489]));
t5=C_mutate((C_word*)lf[489]+1,t4);
t6=C_retrieve(lf[7]);
t7=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8740,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1474 cons* */
t9=C_retrieve(lf[101]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8752 in k8728 in ##compiler#process-custom-declaration in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1474 emit-control-file-item */
t2=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_8740 in k8728 in ##compiler#process-custom-declaration in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8744,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1472 close-output-port */
t3=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8742 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1473 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8713 in ##compiler#process-custom-declaration in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8715,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[22]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8723,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a8719 in k8713 in ##compiler#process-custom-declaration in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8723,3,t0,t1,t2);}
/* support.scm: 1475 g1305 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8624,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8628,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1436 open-output-string */
t4=C_retrieve(lf[487]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8628,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8633,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8633(t5,((C_word*)t0)[2]);}

/* loop in k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8633,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[484]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8635 in loop in k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8637,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1439 quit */
t2=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[485]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8655,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1441 newline */
t3=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8667,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[484]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k8686 in k8635 in loop in k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1453 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8633(t2,((C_word*)t0)[2]);}

/* k8665 in k8635 in loop in k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8667,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1446 get-output-string */
t3=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k8677 in k8665 in k8635 in loop in k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8682,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8680 in k8677 in k8665 in k8635 in loop in k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1450 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8633(t2,((C_word*)t0)[2]);}

/* k8653 in k8635 in loop in k8626 in ##compiler#scan-sharp-greater-string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1442 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8633(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8599,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8609,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[484]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1433 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k8607 in ##sys#user-read-hook in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8612,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1431 scan-sharp-greater-string */
t3=C_retrieve(lf[483]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8610 in k8607 in ##sys#user-read-hook in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8612,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[481],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[482],t2));}

/* ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8512,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8516,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8521,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8521(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8521(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8521,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8534,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1409 make-string */
t11=*((C_word*)lf[471]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t2,C_make_character(32));}

/* k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8534,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8540,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1411 printf */
t4=C_retrieve(lf[18]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[479],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8543,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8592 in k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8593,3,t0,t1,t2);}
/* loop1250 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8521(t3,t1,((C_word*)t0)[2],t2);}

/* k8541 in k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8543,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8549,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8558,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1415 printf */
t6=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[478],t5);}
else{
t4=t3;
f_8549(2,t4,C_SCHEME_UNDEFINED);}}

/* k8556 in k8541 in k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8561,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8566,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8566(t6,t2,C_fix(5));}

/* do1264 in k8556 in k8541 in k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8566(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8566,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8576,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1418 printf */
t5=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[477],t4);}}

/* k8574 in do1264 in k8556 in k8541 in k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8566(t3,((C_word*)t0)[2],t2);}

/* k8559 in k8556 in k8541 in k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[476]+1));}

/* k8547 in k8541 in k8538 in k8532 in loop in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[475]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[476]+1));}

/* k8514 in ##compiler#dump-nodes in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1421 newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8506,3,t0,t1,t2);}
/* support.scm: 1399 string-null? */
t3=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#source-info->string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8430,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8437,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cdddr(t2);
t7=t3;
f_8437(t7,(C_word)C_i_nullp(t6));}
else{
t6=t3;
f_8437(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8437(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8437(t4,C_SCHEME_FALSE);}}

/* k8435 in ##compiler#source-info->string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8437,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8449,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1392 ->string */
t6=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* ->string */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k8447 in k8435 in ##compiler#source-info->string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8456,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8460,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1393 max */
t6=*((C_word*)lf[472]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k8458 in k8447 in k8435 in ##compiler#source-info->string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1393 make-string */
t2=*((C_word*)lf[471]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k8454 in k8447 in k8435 in ##compiler#source-info->string in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1393 conc */
t2=C_retrieve(lf[468]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[469],((C_word*)t0)[3],t1,lf[470],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8424,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1384 ##sys#hash-table-for-each */
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[462]));}

/* a8423 in ##compiler#display-real-name-table in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8424,4,t0,t1,t2,t3);}
/* support.scm: 1386 printf */
t4=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[466],t2,t3);}

/* ##compiler#real-name2 in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8406,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8410,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1380 ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[462]),t2);}

/* k8408 in ##compiler#real-name2 in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1381 real-name */
t2=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8327r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8327r(t0,t1,t2,t3);}}

static void C_ccall f_8327r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8330,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8346,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1364 resolve */
f_8330(t5,t2);}

/* k8344 in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8346,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1368 ##sys#symbol->qualified-string */
t5=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
/* support.scm: 1377 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1365 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8369 in k8344 in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8375,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1369 get */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[171]);}

/* k8373 in k8369 in k8344 in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8375,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8377(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k8373 in k8369 in k8344 in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8377(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8377,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1371 resolve */
f_8330(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k8382 in loop in k8373 in k8369 in k8344 in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8384,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8397,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1374 sprintf */
t4=C_retrieve(lf[48]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[463],((C_word*)t0)[4],t1);}}

/* k8395 in k8382 in loop in k8373 in k8369 in k8344 in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8401,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1375 get */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[171]);}

/* k8399 in k8395 in k8382 in loop in k8373 in k8369 in k8344 in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1374 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8377(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8330(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8330,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8334,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1359 ##sys#hash-table-ref */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[462]),t2);}

/* k8332 in resolve in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8334,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8340,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1361 ##sys#hash-table-ref */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[462]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k8338 in k8332 in resolve in ##compiler#real-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8321,4,t0,t1,t2,t3);}
/* support.scm: 1355 ##sys#hash-table-set! */
t4=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[462]),t2,t3);}

/* ##compiler#make-random-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_8277r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8277r(t0,t1,t2);}}

static void C_ccall f_8277r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8285,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8289,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1342 gensym */
t5=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_8289(2,t6,(C_word)C_i_car(t2));}
else{
/* support.scm: 1342 ##sys#error */
t6=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k8287 in ##compiler#make-random-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8293,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1343 current-seconds */
t3=C_retrieve(lf[460]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8291 in k8287 in ##compiler#make-random-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8297,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1344 random */
t3=C_retrieve(lf[459]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k8295 in k8291 in k8287 in ##compiler#make-random-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1341 sprintf */
t2=C_retrieve(lf[48]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[458],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8283 in ##compiler#make-random-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1340 string->symbol */
t2=*((C_word*)lf[51]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8268,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[454]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* block-variable-literal-name-set! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8259,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[454]);
/* support.scm: 1333 ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* ##compiler#block-variable-literal? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8253,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[454]));}

/* ##compiler#make-block-variable-literal in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8247,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[454],t2));}

/* ##compiler#print-usage in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8239,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1232 print-version */
t3=C_retrieve(lf[446]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8237 in ##compiler#print-usage in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8242,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1233 newline */
t3=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8240 in k8237 in ##compiler#print-usage in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1234 display */
t2=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[452]);}

/* ##compiler#print-version in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8197(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_8197r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8197r(t0,t1,t2);}}

static void C_ccall f_8197r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8201,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_8201(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_8201(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[450]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k8199 in ##compiler#print-version in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1228 print* */
t3=*((C_word*)lf[449]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[4]);}
else{
t3=t2;
f_8204(2,t3,C_SCHEME_UNDEFINED);}}

/* k8202 in k8199 in ##compiler#print-version in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1229 chicken-version */
t3=C_retrieve(lf[448]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k8209 in k8202 in k8199 in ##compiler#print-version in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1229 print */
t2=*((C_word*)lf[447]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8155,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8164,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8164(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8164(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8164,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1221 substring */
t6=*((C_word*)lf[443]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1222 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8126,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8136,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_8136(t7,(C_word)C_i_memq(t6,lf[444]));}
else{
t6=t5;
f_8136(t6,C_SCHEME_FALSE);}}

/* k8134 in ##compiler#chop-separator in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1214 substring */
t2=*((C_word*)lf[443]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7929,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7938,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7985,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8020,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8057,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8108,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a8107 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8108,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1196 insert */
t5=((C_word*)t0)[2];
f_7938(t5,t1,t3,t4);}

/* k8055 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8102,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1199 caar */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k8100 in k8055 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8106,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1199 cdar */
t3=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8104 in k8100 in k8055 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1199 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8020(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8058 in k8055 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8063,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a8064 in k8058 in k8055 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8065,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8069,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1201 lookup */
t5=((C_word*)t0)[2];
f_7985(t5,t3,t4);}

/* k8067 in a8064 in k8058 in k8055 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[441]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1203 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8020(t5,((C_word*)t0)[4],t3,t4);}}

/* k8061 in k8058 in k8055 in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_8020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8020,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8024,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1184 insert */
t5=((C_word*)t0)[2];
f_7938(t5,t4,t2,lf[441]);}

/* k8022 in visit in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8027,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8033,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8032 in k8022 in visit in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8033,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8037,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1187 lookup */
t4=((C_word*)t0)[2];
f_7985(t4,t3,t2);}

/* k8035 in a8032 in k8022 in visit in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[441]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1189 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8020(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k8025 in k8022 in visit in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8027,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7985,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7991,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7991(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7991,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8018,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1179 caar */
t5=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k8016 in loop in lookup in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1179 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8002 in loop in lookup in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1179 cdar */
t2=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1180 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7991(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7938(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7938,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7944(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7944,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7983,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1173 caar */
t5=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7981 in loop in insert in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1173 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7963 in loop in insert in ##compiler#topological-sort in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1174 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7944(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7770,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7773,a[2]=t8,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7914,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7927,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1156 walk */
t12=((C_word*)t6)[1];
f_7773(t12,t11,t2,C_SCHEME_END_OF_LIST);}

/* k7925 in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7914,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7920,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a7919 in walkeach in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7920,3,t0,t1,t2);}
/* support.scm: 1154 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7773(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7773(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7773,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[84]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t7,a[8]=t9,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t10)){
t12=t11;
f_7792(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[115]);
if(C_truep(t12)){
t13=t11;
f_7792(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[116]);
if(C_truep(t13)){
t14=t11;
f_7792(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[243]);
t15=t11;
f_7792(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[117])));}}}}

/* k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7792,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[231]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[6]))){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1138 lset-adjoin */
t5=C_retrieve(lf[439]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[5])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[106]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7823,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[6]))){
t6=t5;
f_7823(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7837,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1141 lset-adjoin */
t7=C_retrieve(lf[439]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[94]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7846,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1144 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7773(t7,t5,t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[261]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7876,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1147 decompose-lambda-list */
t8=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[9],t6,t7);}
else{
/* support.scm: 1151 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7914(t6,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[6]);}}}}}}

/* a7875 in k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7876,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7888,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1150 append */
t7=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7886 in a7875 in k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1150 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7773(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7844 in k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7846,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7857,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1145 append */
t4=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7855 in k7844 in k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1145 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7773(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7835 in k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7823(t3,t2);}

/* k7821 in k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1142 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7773(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7809 in k7790 in walk in ##compiler#scan-free-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7692,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7696,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7698,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7698(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7698,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[231]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[106]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7720,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7726,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_7726(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_7726(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[84]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7753,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_7753(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[115]);
t12=t10;
f_7753(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[116])));}}}

/* k7751 in walk in ##compiler#scan-used-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k7724 in walk in ##compiler#scan-used-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7726,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_7720(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_7720(t2,C_SCHEME_UNDEFINED);}}

/* k7718 in walk in ##compiler#scan-used-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7694 in ##compiler#scan-used-variables in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[131],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7416,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[428],t3,t6));}
else{
t6=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[429],t3,t7));}
else{
t7=(C_word)C_eqp(t4,lf[376]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[377]));
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[430],t3,t9));}
else{
t9=(C_word)C_eqp(t4,lf[374]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t10)){
t11=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[431],t3,t11));}
else{
t11=(C_word)C_eqp(t4,lf[362]);
if(C_truep(t11)){
t12=(C_word)C_a_i_list(&a,2,lf[84],C_fix(0));
t13=(C_word)C_a_i_list(&a,3,lf[428],t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,2,lf[432],t13));}
else{
t12=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t12)){
t13=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[433],t3,t13));}
else{
t13=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t13)){
t14=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[434],t3,t14));}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_eqp(t15,lf[368]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7541,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(t2);
t21=t17;
f_7541(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_7541(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_7541(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(t2);
t18=(C_word)C_eqp(t17,lf[369]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7588,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t21))){
t22=(C_word)C_i_cdddr(t2);
t23=t19;
f_7588(t23,(C_word)C_i_nullp(t22));}
else{
t22=t19;
f_7588(t22,C_SCHEME_FALSE);}}
else{
t21=t19;
f_7588(t21,C_SCHEME_FALSE);}}
else{
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7629,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_car(t2);
t21=(C_word)C_eqp(t20,lf[370]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t23))){
t24=(C_word)C_i_cdddr(t2);
t25=t19;
f_7629(t25,(C_word)C_i_nullp(t24));}
else{
t24=t19;
f_7629(t24,C_SCHEME_FALSE);}}
else{
t23=t19;
f_7629(t23,C_SCHEME_FALSE);}}
else{
t22=t19;
f_7629(t22,C_SCHEME_FALSE);}}}}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t3);}}}}}}}}}

/* k7627 in ##compiler#finish-foreign-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7629,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,lf[84],lf[364]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,4,lf[436],t3,t4,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7586 in ##compiler#finish-foreign-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7588,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1101 g1091 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7519(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7539 in ##compiler#finish-foreign-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7541,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1101 g1091 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7519(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g1091 in ##compiler#finish-foreign-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static C_word C_fcall f_7519(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_a_i_list(&a,3,lf[435],((C_word*)t0)[2],t1));}

/* ##compiler#estimate-foreign-result-location-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7109,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7118,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1065 follow-without-loop */
t6=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a7409 in ##compiler#estimate-foreign-result-location-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7410,2,t0,t1);}
/* support.scm: 1086 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[426],((C_word*)t0)[2]);}

/* a7117 in ##compiler#estimate-foreign-result-location-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7118,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[336]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_7128(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t7)){
t8=t6;
f_7128(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t8)){
t9=t6;
f_7128(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t9)){
t10=t6;
f_7128(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t10)){
t11=t6;
f_7128(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t11)){
t12=t6;
f_7128(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t12)){
t13=t6;
f_7128(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t13)){
t14=t6;
f_7128(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t14)){
t15=t6;
f_7128(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t15)){
t16=t6;
f_7128(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t16)){
t17=t6;
f_7128(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t17)){
t18=t6;
f_7128(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[344]);
if(C_truep(t18)){
t19=t6;
f_7128(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t19)){
t20=t6;
f_7128(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t20)){
t21=t6;
f_7128(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t21)){
t22=t6;
f_7128(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t22)){
t23=t6;
f_7128(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t23)){
t24=t6;
f_7128(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[362]);
if(C_truep(t24)){
t25=t6;
f_7128(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[403]);
if(C_truep(t25)){
t26=t6;
f_7128(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[398]);
if(C_truep(t26)){
t27=t6;
f_7128(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[411]);
if(C_truep(t27)){
t28=t6;
f_7128(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[412]);
if(C_truep(t28)){
t29=t6;
f_7128(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[383]);
if(C_truep(t29)){
t30=t6;
f_7128(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t30)){
t31=t6;
f_7128(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t31)){
t32=t6;
f_7128(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t32)){
t33=t6;
f_7128(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t33)){
t34=t6;
f_7128(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t34)){
t35=t6;
f_7128(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t35)){
t36=t6;
f_7128(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[378]);
t37=t6;
f_7128(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[379])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7126 in a7117 in ##compiler#estimate-foreign-result-location-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7128,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1074 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[404]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[405]));
if(C_truep(t3)){
/* support.scm: 1076 words->bytes */
t4=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[6],C_fix(2));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1078 ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[373]),((C_word*)t0)[3]);}
else{
t5=t4;
f_7146(2,t5,C_SCHEME_FALSE);}}}}

/* k7144 in k7126 in a7117 in ##compiler#estimate-foreign-result-location-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1080 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[366]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_7180(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t5)){
t6=t4;
f_7180(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t6)){
t7=t4;
f_7180(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t7)){
t8=t4;
f_7180(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[357]);
t9=t4;
f_7180(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[367])));}}}}}
else{
/* support.scm: 1085 err */
f_7109(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k7178 in k7144 in k7126 in a7117 in ##compiler#estimate-foreign-result-location-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1083 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(1));}
else{
/* support.scm: 1084 err */
f_7109(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_7109(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7109,NULL,2,t1,t2);}
/* support.scm: 1064 quit */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[425],t2);}

/* ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6787,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6793,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1035 follow-without-loop */
t5=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a7099 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
/* support.scm: 1060 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[423],((C_word*)t0)[2]);}

/* a6792 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6793,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[336]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6803,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6803(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t7)){
t8=t6;
f_6803(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t8)){
t9=t6;
f_6803(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t9)){
t10=t6;
f_6803(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[421]);
if(C_truep(t10)){
t11=t6;
f_6803(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t11)){
t12=t6;
f_6803(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[422]);
if(C_truep(t12)){
t13=t6;
f_6803(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t13)){
t14=t6;
f_6803(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t14)){
t15=t6;
f_6803(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t15)){
t16=t6;
f_6803(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t16)){
t17=t6;
f_6803(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[411]);
t18=t6;
f_6803(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[412])));}}}}}}}}}}}}

/* k6801 in a6792 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6803(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6803,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[358]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6812(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t4)){
t5=t3;
f_6812(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t5)){
t6=t3;
f_6812(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[357]);
if(C_truep(t6)){
t7=t3;
f_6812(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[362]);
if(C_truep(t7)){
t8=t3;
f_6812(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t8)){
t9=t3;
f_6812(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t9)){
t10=t3;
f_6812(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
if(C_truep(t10)){
t11=t3;
f_6812(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t11)){
t12=t3;
f_6812(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[378]);
t13=t3;
f_6812(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[379])));}}}}}}}}}}}

/* k6810 in k6801 in a6792 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6812,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1045 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6824(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_6824(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
if(C_truep(t5)){
t6=t3;
f_6824(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t6)){
t7=t3;
f_6824(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
t8=t3;
f_6824(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[380])));}}}}}}

/* k6822 in k6810 in k6801 in a6792 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6824,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1047 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(4));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[342]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_6836(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[404]);
if(C_truep(t4)){
t5=t3;
f_6836(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[405]);
t6=t3;
f_6836(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[419])));}}}}

/* k6834 in k6822 in k6810 in k6801 in a6792 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6836,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1049 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1051 ##sys#hash-table-ref */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[373]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6842(2,t3,C_SCHEME_FALSE);}}}

/* k6840 in k6834 in k6822 in k6810 in k6801 in a6792 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1053 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[366]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6876,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_6876(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t5)){
t6=t4;
f_6876(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t6)){
t7=t4;
f_6876(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t7)){
t8=t4;
f_6876(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[357]);
if(C_truep(t8)){
t9=t4;
f_6876(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[367]);
if(C_truep(t9)){
t10=t4;
f_6876(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[368]);
if(C_truep(t10)){
t11=t4;
f_6876(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[369]);
t12=t4;
f_6876(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[370])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k6874 in k6840 in k6834 in k6822 in k6810 in k6801 in a6792 in ##compiler#estimate-foreign-result-size in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1057 words->bytes */
t2=C_retrieve(lf[69]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6747,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6753,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6781,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1022 follow-without-loop */
t5=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a6780 in ##compiler#final-foreign-type in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
/* support.scm: 1029 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[417],((C_word*)t0)[2]);}

/* a6752 in ##compiler#final-foreign-type in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6753,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6757,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1025 ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[373]),t2);}
else{
t5=t4;
f_6757(2,t5,C_SCHEME_FALSE);}}

/* k6755 in a6752 in ##compiler#final-foreign-type in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1027 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6716,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6720,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6729,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1016 ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[373]),t3);}
else{
t5=t4;
f_6720(t5,C_SCHEME_FALSE);}}

/* k6727 in ##compiler#foreign-type-convert-argument in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6729,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_6720(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6720(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6720(t2,C_SCHEME_FALSE);}}

/* k6718 in ##compiler#foreign-type-convert-argument in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6685,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6689,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6698,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1009 ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[373]),t3);}
else{
t5=t4;
f_6689(t5,C_SCHEME_FALSE);}}

/* k6696 in ##compiler#foreign-type-convert-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6698,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_6689(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6689(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6689(t2,C_SCHEME_FALSE);}}

/* k6687 in ##compiler#foreign-type-convert-result in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5830,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5836,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6679,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 910  follow-without-loop */
t6=C_retrieve(lf[82]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a6678 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6679,2,t0,t1);}
/* support.scm: 1002 quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[413],((C_word*)t0)[2]);}

/* a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5836,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5842,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5842(t7,t1,t2);}

/* repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5842(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5842,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[336]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[337]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[4]:(C_word)C_a_i_list(&a,2,lf[339],((C_word*)t0)[4])));}
else{
t6=(C_word)C_eqp(t3,lf[340]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5867(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t8)){
t9=t7;
f_5867(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t9)){
t10=t7;
f_5867(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t10)){
t11=t7;
f_5867(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[409]);
if(C_truep(t11)){
t12=t7;
f_5867(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[410]);
if(C_truep(t12)){
t13=t7;
f_5867(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[411]);
t14=t7;
f_5867(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[412])));}}}}}}}}

/* k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5867,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[341],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5882(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[404]);
t5=t3;
f_5882(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[405])));}}}

/* k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5882,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[343],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5897(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[401]);
if(C_truep(t4)){
t5=t3;
f_5897(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t6=t3;
f_5897(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[403])));}}}}

/* k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5897,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5900,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 920  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[346]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5935(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[398]);
if(C_truep(t4)){
t5=t3;
f_5935(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
t6=t3;
f_5935(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[400])));}}}}

/* k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5935,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[345],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5950(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t4)){
t5=t3;
f_5950(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t5)){
t6=t3;
f_5950(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t6)){
t7=t3;
f_5950(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t7)){
t8=t3;
f_5950(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
if(C_truep(t8)){
t9=t3;
f_5950(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
t10=t3;
f_5950(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[397])));}}}}}}}}

/* k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5950,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5953,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 932  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5992(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t4)){
t5=t3;
f_5992(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t5)){
t6=t3;
f_5992(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t6)){
t7=t3;
f_5992(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
if(C_truep(t7)){
t8=t3;
f_5992(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[388]);
if(C_truep(t8)){
t9=t3;
f_5992(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[389]);
t10=t3;
f_5992(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[390])));}}}}}}}}

/* k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5992,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[350]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[84],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[348],t4,((C_word*)t0)[6]));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6019(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
t5=t3;
f_6019(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[383])));}}}

/* k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6019,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[352],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6034(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[380]);
t5=t3;
f_6034(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[381])));}}}

/* k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6034,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[354],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6049(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_6049(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6049,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6052,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 952  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[357]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[356],((C_word*)t0)[7]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[358]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6093(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t6=t4;
f_6093(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}}

/* k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6093,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 960  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[361]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6138(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t5=t3;
f_6138(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}

/* k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6138,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[359],((C_word*)t0)[6]));}
else{
t2=(C_word)C_a_i_list(&a,2,lf[360],((C_word*)t0)[6]);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[359],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[362]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[338]))){
t3=(C_word)C_a_i_list(&a,2,lf[363],((C_word*)t0)[6]);
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[359],t3));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[363],((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,2,lf[360],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[359],t4));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 976  ##sys#hash-table-ref */
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[373]),((C_word*)t0)[3]);}
else{
t4=t3;
f_6181(2,t4,C_SCHEME_FALSE);}}}}

/* k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6181,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 978  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6209,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6241,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[366]);
if(C_truep(t6)){
/* support.scm: 980  g878 */
t7=t4;
f_6241(t7,((C_word*)t0)[5]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[344]);
if(C_truep(t8)){
/* support.scm: 980  g878 */
t9=t4;
f_6241(t9,((C_word*)t0)[5]);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[367]);
if(C_truep(t10)){
/* support.scm: 980  g878 */
t11=t4;
f_6241(t11,((C_word*)t0)[5]);}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[355]);
if(C_truep(t12)){
/* support.scm: 980  g878 */
t13=t4;
f_6241(t13,((C_word*)t0)[5]);}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[368]);
if(C_truep(t14)){
/* support.scm: 980  g879 */
t15=t3;
f_6209(t15,((C_word*)t0)[5]);}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[369]);
if(C_truep(t16)){
/* support.scm: 980  g879 */
t17=t3;
f_6209(t17,((C_word*)t0)[5]);}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[370]);
if(C_truep(t18)){
t19=(C_word)C_a_i_list(&a,2,lf[84],lf[364]);
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[365],((C_word*)t0)[3],t19));}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[371]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6353(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6353(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[372]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6385(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6385(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[346]);
if(C_truep(t24)){
/* support.scm: 980  g883 */
t25=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t25))(2,t25,f_6204(C_a_i(&a,6),t2));}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[357]);
/* support.scm: 980  g883 */
t27=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t27))(2,t27,(C_truep(t26)?f_6204(C_a_i(&a,6),t2):((C_word*)t0)[3]));}}}}}}}}}}}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6383 in k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6385,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_truep(C_retrieve(lf[338]))?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,2,lf[352],((C_word*)t0)[2])):((C_word*)t0)[2]));}

/* k6351 in k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* support.scm: 980  repeat */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5842(t3,((C_word*)t0)[3],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g878 in k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6241,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6245,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 982  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6243 in g878 in k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6245,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[356],t1);
t5=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[103],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[94],t3,t6));}

/* g879 in k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6209,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6213,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 988  gensym */
t3=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6211 in g879 in k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6213,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[84],lf[364]);
t5=(C_word)C_a_i_list(&a,3,lf[365],((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,4,lf[103],t1,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[94],t3,t7));}

/* g883 in k6179 in k6136 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static C_word C_fcall f_6204(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_a_i_list(&a,2,lf[356],((C_word*)t0)[2]));}

/* k6094 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6096,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6111,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[338]))){
t5=t4;
f_6111(t5,(C_word)C_a_i_list(&a,2,lf[359],t1));}
else{
t5=(C_word)C_a_i_list(&a,2,lf[360],t1);
t6=t4;
f_6111(t6,(C_word)C_a_i_list(&a,2,lf[359],t5));}}

/* k6109 in k6094 in k6091 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_6111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6111,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[103],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t3));}

/* k6050 in k6047 in k6032 in k6017 in k5990 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_6052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6052,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[356],t1);
t5=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[103],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[94],t3,t6));}

/* k5951 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5953,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5968,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[338]))){
t5=t4;
f_5968(t5,t1);}
else{
t5=(C_word)C_a_i_list(&a,2,lf[84],((C_word*)t0)[2]);
t6=t4;
f_5968(t6,(C_word)C_a_i_list(&a,3,lf[348],t5,t1));}}

/* k5966 in k5951 in k5948 in k5933 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5968,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[103],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t3));}

/* k5898 in k5895 in k5880 in k5865 in repeat in a5835 in ##compiler#foreign-type-check in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5900,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_truep(C_retrieve(lf[338]))?t1:(C_word)C_a_i_list(&a,2,lf[345],t1));
t5=(C_word)C_a_i_list(&a,2,lf[84],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[103],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[94],t3,t6));}

/* ##compiler#pprint-expressions-to-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5794,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5798,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 891  open-output-file */
t5=*((C_word*)lf[333]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
/* support.scm: 891  current-output-port */
t5=*((C_word*)lf[334]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5796 in ##compiler#pprint-expressions-to-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5801,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 892  with-output-to-port */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a5808 in k5796 in ##compiler#pprint-expressions-to-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5815,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5814 in a5808 in k5796 in ##compiler#pprint-expressions-to-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5815,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 896  pretty-print */
t4=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5817 in a5814 in a5808 in k5796 in ##compiler#pprint-expressions-to-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 897  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5799 in k5796 in ##compiler#pprint-expressions-to-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 899  close-output-port */
t2=*((C_word*)lf[330]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5755,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5767,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a5766 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5767,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5774,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 879  debugging */
t10=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[327],lf[328]);}

/* k5772 in a5766 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5774,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5777,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 880  printf */
t3=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[326],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5775 in k5772 in a5766 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 881  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[325],((C_word*)t0)[2]);}

/* k5778 in k5775 in k5772 in a5766 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 882  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[324],((C_word*)t0)[2]);}

/* k5781 in k5778 in k5775 in k5772 in a5766 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 883  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[323],((C_word*)t0)[2]);}

/* k5784 in k5781 in k5778 in k5775 in k5772 in a5766 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 884  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[322],((C_word*)t0)[2]);}

/* k5787 in k5784 in k5781 in k5778 in k5775 in k5772 in a5766 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 885  printf */
t2=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[321],((C_word*)t0)[2]);}

/* a5760 in ##compiler#print-program-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5761,2,t0,t1);}
/* support.scm: 878  compute-database-statistics */
t2=C_retrieve(lf[317]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5675,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5679,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5684,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 854  ##sys#hash-table-for-each */
t15=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a5683 in ##compiler#compute-database-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5684,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5689 in a5683 in ##compiler#compute-database-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5690,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[202]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[185]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[261],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t5,lf[190]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* k5677 in ##compiler#compute-database-statistics in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 868  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[318]),C_retrieve(lf[319]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5624,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5628,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5669,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5673,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 822  ->string */
t6=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k5671 in ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 822  string-append */
t2=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[316]);}

/* k5667 in ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 821  ##sys#resolve-include-filename */
t2=C_retrieve(lf[315]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5626 in ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5637,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 824  file-exists? */
t3=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5635 in k5626 in ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5637,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[313]))){
/* support.scm: 826  printf */
t3=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[314],((C_word*)t0)[2]);}
else{
t3=t2;
f_5640(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5638 in k5635 in k5626 in ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5645,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5662,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 832  read-file */
t4=C_retrieve(lf[312]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5660 in k5638 in k5635 in k5626 in ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5644 in k5638 in k5635 in k5626 in ##compiler#lookup-exports-file in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5645,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 830  ##sys#hash-table-set! */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[309]),t2,((C_word*)t0)[2]);}
else{
/* support.scm: 831  export-import-hook */
t3=C_retrieve(lf[310]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}}

/* ##compiler#export-import-hook in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5618,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#check-global-imports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5566,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 805  ##sys#hash-table-for-each */
t4=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5565 in ##compiler#check-global-imports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5566,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5570,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 807  ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[309]),t2);}

/* k5568 in a5565 in ##compiler#check-global-imports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5570,2,t0,t1);}
t2=(C_word)C_i_assq(lf[189],((C_word*)t0)[4]);
t3=(C_word)C_i_assq(lf[200],((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(lf[202],((C_word*)t0)[4]))){
if(C_truep(t3)){
if(C_truep(t1)){
/* support.scm: 813  compiler-warning */
t4=C_retrieve(lf[25]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],lf[305],lf[306],((C_word*)t0)[2],t1);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=t1;
if(C_truep(t5)){
t6=t4;
f_5597(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5616,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 814  keyword? */
t7=C_retrieve(lf[308]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}}
else{
t5=t4;
f_5597(t5,C_SCHEME_FALSE);}}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5614 in k5568 in a5565 in ##compiler#check-global-imports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5597(t2,(C_word)C_i_not(t1));}

/* k5595 in k5568 in a5565 in ##compiler#check-global-imports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 815  compiler-warning */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[300],lf[307],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#check-global-exports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5516,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[295]))){
t3=C_retrieve(lf[295]);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5523,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5534,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 796  ##sys#hash-table-for-each */
t7=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5533 in ##compiler#check-global-exports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5534,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5538,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5545,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t6=(C_word)C_i_assq(lf[200],t3);
t7=t5;
f_5545(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_5545(t6,C_SCHEME_FALSE);}}

/* k5543 in a5533 in ##compiler#check-global-exports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 799  compiler-warning */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[300],lf[303],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5538(2,t2,C_SCHEME_UNDEFINED);}}

/* k5536 in a5533 in ##compiler#check-global-exports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 800  delete */
t3=C_retrieve(lf[302]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[278]+1));}

/* k5540 in k5536 in a5533 in ##compiler#check-global-exports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5521 in ##compiler#check-global-exports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5528,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a5527 in k5521 in ##compiler#check-global-exports in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5528,3,t0,t1,t2);}
/* ##compiler#compiler-warning */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[300],lf[301],t2);}

/* ##compiler#dump-undefined-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5485,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5491,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 785  ##sys#hash-table-for-each */
t4=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5490 in ##compiler#dump-undefined-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5491,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5498,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[202],t3))){
t5=(C_word)C_i_assq(lf[200],t3);
t6=t4;
f_5498(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5498(t5,C_SCHEME_FALSE);}}

/* k5496 in a5490 in ##compiler#dump-undefined-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5498(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5498,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5501,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 789  write */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5499 in k5496 in a5490 in ##compiler#dump-undefined-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 790  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5399,4,t0,t1,t2,t3);}
if(C_truep(C_retrieve(lf[292]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5408,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 764  with-output-to-file */
t5=C_retrieve(lf[297]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}}

/* a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5408,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5412,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5447,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 767  ##sys#hash-table-for-each */
t6=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a5446 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5447,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5454,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(lf[202],t3))){
if(C_truep((C_word)C_i_assq(lf[200],t3))){
t5=(C_truep(C_retrieve(lf[295]))?(C_word)C_i_memq(t2,C_retrieve(lf[295])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5454(t6,t5);}
else{
t6=(C_word)C_i_memq(t2,C_retrieve(lf[296]));
t7=t4;
f_5454(t7,(C_word)C_i_not(t6));}}
else{
t5=t4;
f_5454(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_5454(t5,C_SCHEME_FALSE);}}

/* k5452 in a5446 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5454,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5410 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5420,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5431,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5433,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 779  sort */
t6=C_retrieve(lf[294]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* a5432 in k5410 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5433,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* support.scm: 781  string<? */
t6=*((C_word*)lf[293]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* k5429 in k5410 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5419 in k5410 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5424,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 777  write */
t4=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5422 in a5419 in k5410 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 778  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5413 in k5410 in a5407 in ##compiler#dump-exported-globals in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 782  export-dump-hook */
t2=C_retrieve(lf[290]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#export-dump-hook in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5393,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#simple-lambda-node? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5301,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5325,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5325(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5325,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[248]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[231],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 753  every */
t15=C_retrieve(lf[89]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[242]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 755  every */
t9=C_retrieve(lf[89]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5215,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5221,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5221(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5221,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[231]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5237,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5237(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[84]);
if(C_truep(t9)){
t10=t8;
f_5237(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[115]);
if(C_truep(t10)){
t11=t8;
f_5237(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[243]);
t12=t8;
f_5237(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[235])));}}}}

/* k5235 in walk in ##compiler#expression-has-side-effects? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5237,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5251,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 736  find */
t7=C_retrieve(lf[287]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],t6,C_retrieve(lf[288]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[103]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[94]));
if(C_truep(t4)){
/* support.scm: 737  any */
t5=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a5250 in k5235 in walk in ##compiler#expression-has-side-effects? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5251,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5259,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 736  foreign-callback-stub-id */
t4=C_retrieve(lf[286]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5257 in a5250 in k5235 in walk in ##compiler#expression-has-side-effects? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5020,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5023,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5052,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5095,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5199,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 720  matchn */
t15=((C_word*)t12)[1];
f_5095(t15,t14,t2,t3);}

/* k5197 in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5199,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 723  debugging */
t7=C_retrieve(lf[15]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t2,lf[283],lf[284],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5203 in k5197 in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5095,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 709  resolve */
t4=((C_word*)t0)[4];
f_5023(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5117,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 711  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5052(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k5115 in matchn in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5117,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5130(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k5115 in matchn in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5130(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5130,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 715  resolve */
t4=((C_word*)t0)[4];
f_5023(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5161,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 717  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5095(t7,t4,t5,t6);}}}}

/* k5159 in loop in k5115 in matchn in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 718  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5130(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5052(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5052,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 702  resolve */
t4=((C_word*)t0)[3];
f_5023(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5074,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 704  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k5072 in match1 in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 704  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5052(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_5023(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5023,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 697  alist-cons */
t6=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k5045 in resolve in ##compiler#match-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#copy-node! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4958,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4962,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 679  node-class-set! */
t7=C_retrieve(lf[223]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t3,t6);}

/* k4960 in ##compiler#copy-node! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 680  node-parameters-set! */
t5=C_retrieve(lf[226]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4963 in k4960 in ##compiler#copy-node! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 681  node-subexpressions-set! */
t5=C_retrieve(lf[228]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4966 in k4963 in k4960 in ##compiler#copy-node! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4979(t4,C_fix(4)));}

/* do627 in k4966 in k4963 in k4960 in ##compiler#copy-node! in k2796 in k2793 in k1448 in k1445 in k1442 */
static C_word C_fcall f_4979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4924,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4930(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4930,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 675  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4942 in rec in ##compiler#tree-copy in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4948,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 675  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4930(t4,t2,t3);}

/* k4946 in k4942 in rec in ##compiler#tree-copy in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4948,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4746,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 643  map */
t6=*((C_word*)lf[120]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[280]+1),t3,t4);}

/* k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4752,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 670  walk */
t6=((C_word*)t4)[1];
f_4758(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4758(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4758,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[231]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4781,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
/* support.scm: 650  rename */
f_4752(t11,t12,t3);}
else{
t11=(C_word)C_eqp(t9,lf[106]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4810,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 651  rename */
f_4752(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[94]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4826,a[2]=t3,a[3]=t13,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 654  gensym */
t15=C_retrieve(lf[95]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t13);}
else{
t13=(C_word)C_eqp(t9,lf[261]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4859,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 658  decompose-lambda-list */
t16=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4907,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 669  tree-copy */
t15=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}}}}}

/* k4905 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4910,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4914 in k4905 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4915,3,t0,t1,t2);}
/* walk573 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4758(t3,t1,t2,((C_word*)t0)[2]);}

/* k4908 in k4905 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4858 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4859,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[95]),t2);}

/* k4861 in a4858 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 662  append */
t3=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4864 in k4861 in a4858 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4866,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 666  rename */
f_4752(t5,((C_word*)t0)[3],t1);}
else{
t6=t5;
f_4901(2,t6,C_SCHEME_FALSE);}}

/* k4899 in k4864 in k4861 in a4858 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 666  build-lambda-list */
t2=C_retrieve(lf[53]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4891 in k4864 in k4861 in a4858 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4872,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a4876 in k4891 in k4864 in k4861 in a4858 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4877,3,t0,t1,t2);}
/* walk573 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4758(t3,t1,t2,((C_word*)t0)[2]);}

/* k4870 in k4891 in k4864 in k4861 in a4858 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4872,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[261],((C_word*)t0)[2],t1));}

/* k4824 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 655  alist-cons */
t3=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4827 in k4824 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4835,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4840,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4839 in k4827 in k4824 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4840,3,t0,t1,t2);}
/* walk573 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4758(t3,t1,t2,((C_word*)t0)[2]);}

/* k4833 in k4827 in k4824 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[94],((C_word*)t0)[2],t1));}

/* k4808 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4797,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4801 in k4808 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4802,3,t0,t1,t2);}
/* walk573 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4758(t3,t1,t2,((C_word*)t0)[2]);}

/* k4795 in k4808 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[106],((C_word*)t0)[2],t1));}

/* k4779 in walk in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 650  varnode */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k4748 in ##compiler#copy-node-tree-and-rename in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4752(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4752,NULL,3,t1,t2,t3);}
/* support.scm: 644  alist-ref */
t4=C_retrieve(lf[277]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[278]+1),t2);}

/* ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4653,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4659,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 621  decompose-lambda-list */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4659,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4665,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4671,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4671,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[95]),((C_word*)t0)[2]);}
else{
t5=t4;
f_4675(2,t5,((C_word*)t0)[2]);}}

/* k4673 in a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 627  copy-node-tree-and-rename */
t3=C_retrieve(lf[276]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_4678(2,t3,((C_word*)t0)[3]);}}

/* k4676 in k4673 in a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4683,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 633  last */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_4697(t4,t1);}}

/* k4736 in k4676 in k4673 in a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4714,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 635  qnode */
t4=C_retrieve(lf[232]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[275],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_4714(2,t8,(C_word)C_a_i_record(&a,4,lf[221],lf[109],t6,t7));}}

/* k4712 in k4736 in k4676 in k4673 in a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_4697(t3,(C_word)C_a_i_record(&a,4,lf[221],lf[94],((C_word*)t0)[2],t2));}

/* k4695 in k4676 in k4673 in a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4697,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 639  take */
t3=C_retrieve(lf[274]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4699 in k4695 in k4676 in k4673 in a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 629  fold-right */
t2=C_retrieve(lf[273]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4682 in k4676 in k4673 in a4670 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4683,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[221],lf[94],t5,t6));}

/* a4664 in a4658 in ##compiler#inline-lambda-bindings in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
/* support.scm: 624  split-at */
t2=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4605,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4611,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4611(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4611(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4611,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 617  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k4629 in fold in ##compiler#fold-boolean in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 618  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4611(t4,t2,t3);}

/* k4633 in k4629 in fold in ##compiler#fold-boolean in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[221],lf[108],lf[270],t2));}

/* ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4311,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4317,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4317(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4317,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[103]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4336,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_4336(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[267]);
t12=t10;
f_4336(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[268])));}}

/* k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4336,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[257]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[231]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[235]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[84]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,lf[84],t6));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[94]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 591  butlast */
t10=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[107]:lf[261]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4435,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 598  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_4317(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[248]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[242]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4468,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[115]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4492,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_4492(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_4546(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[264]);
if(C_truep(t14)){
t15=t13;
f_4546(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[265]);
t16=t13;
f_4546(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[266])));}}}}}}}}}}}}}

/* k4544 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4546,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 608  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4317(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4574 in k4544 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 609  append */
t2=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4570 in k4544 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4551 in k4544 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k4555 in k4551 in k4544 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 608  cons* */
t2=C_retrieve(lf[101]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4492(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4492,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 605  reverse */
t7=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4533,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 606  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_4317(3,t10,t8,t9);}}

/* k4531 in loop in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 606  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4492(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4504 in loop in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4510,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 605  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4317(3,t4,t2,t3);}

/* k4508 in k4504 in loop in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[262],((C_word*)t0)[2],t1));}

/* k4466 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 600  cons* */
t2=C_retrieve(lf[101]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[242],((C_word*)t0)[2],t1);}

/* k4433 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4412 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4408 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 591  map */
t2=*((C_word*)lf[120]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[259]+1),((C_word*)t0)[2],t1);}

/* k4396 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4402,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4406,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 592  last */
t4=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4404 in k4396 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4317(3,t2,((C_word*)t0)[2],t1);}

/* k4400 in k4396 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4402,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t1));}

/* k4358 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[257],t2));}

/* k4341 in k4334 in walk in ##compiler#build-expression-tree in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3803,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 575  walk */
t9=((C_word*)t6)[1];
f_3806(3,t9,t8,t2);}

/* k4304 in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4309,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 576  debugging */
t3=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[254],lf[255],((C_word*)((C_word*)t0)[2])[1]);}

/* k4307 in k4304 in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word *a;
loop:
a=C_alloc(83);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3806,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 510  varnode */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 511  bomb */
t3=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[234]);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[221],lf[235],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[103]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[115]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3865,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[84]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3888,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[239],C_retrieve(lf[240]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_3891(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_3891(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_3891(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[94]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 531  walk */
t64=t1;
t65=t11;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3941,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 532  unzip1 */
t13=C_retrieve(lf[241]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[107]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3992,a[2]=t12,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_caddr(t2);
/* support.scm: 535  walk */
t64=t13;
t65=t14;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t11=(C_word)C_eqp(t4,lf[116]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_i_car(t2);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t13,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t12))){
t15=(C_word)C_i_car(t12);
t16=t14;
f_4032(t16,(C_word)C_eqp(lf[84],t15));}
else{
t15=t14;
f_4032(t15,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t4,lf[108]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[242]));
if(C_truep(t13)){
t14=(C_word)C_i_car(t2);
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4063,a[2]=t16,a[3]=t14,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_i_cddr(t2);
/* map */
t19=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,((C_word*)((C_word*)t0)[3])[1],t18);}
else{
t14=(C_word)C_eqp(t4,lf[243]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,t15,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,4,lf[221],lf[243],t16,C_SCHEME_END_OF_LIST));}
else{
t15=(C_word)C_eqp(t4,lf[106]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(t4,lf[100]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(t2);
t18=(C_word)C_a_i_list(&a,1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4105,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cddr(t2);
/* map */
t21=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,((C_word*)((C_word*)t0)[3])[1],t20);}
else{
t17=(C_word)C_eqp(t4,lf[244]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_i_cadr(t18);
t20=(C_word)C_i_caddr(t2);
t21=(C_word)C_i_cadr(t20);
t22=(C_word)C_i_cadddr(t2);
t23=(C_word)C_i_cadr(t22);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4158,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t23,a[6]=t21,a[7]=t19,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 554  fifth */
t25=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,t2);}
else{
t18=(C_word)C_eqp(t4,lf[109]);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t18)){
t20=t19;
f_4179(t20,t18);}
else{
t20=(C_word)C_eqp(t4,lf[117]);
if(C_truep(t20)){
t21=t19;
f_4179(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[110]);
if(C_truep(t21)){
t22=t19;
f_4179(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[111]);
t23=t19;
f_4179(t23,(C_truep(t22)?t22:(C_word)C_eqp(t4,lf[112])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4296,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k4294 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[248],lf[253],t1));}

/* k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4179,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4188,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[247]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 562  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a4221 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4222,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4236,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[252])))){
t5=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_4236(t7,C_SCHEME_TRUE);}
else{
t5=t4;
f_4236(t5,C_SCHEME_FALSE);}}

/* k4234 in a4221 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4236,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 570  real-name */
t4=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm: 572  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4241 in k4234 in a4221 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_4250(2,t3,t1);}
else{
/* support.scm: 571  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4248 in k4241 in k4234 in a4221 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4240(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[250]),((C_word*)t0)[2],t1));}

/* k4238 in k4234 in a4221 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4229,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k4227 in k4238 in k4234 in a4221 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4229,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[248],((C_word*)t0)[2],t1));}

/* a4215 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
/* support.scm: 562  get-line-2 */
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4202 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[248],lf[249],t1));}

/* k4186 in k4177 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4156 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4142,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 555  sixth */
t6=C_retrieve(lf[245]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k4140 in k4156 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 555  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3806(3,t2,((C_word*)t0)[2],t1);}

/* k4136 in k4156 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4138,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[221],lf[244],((C_word*)t0)[2],t2));}

/* k4103 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[106],((C_word*)t0)[2],t1));}

/* k4061 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4030 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_4032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4032,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4018,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k4016 in k4030 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3990 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[221],lf[107],((C_word*)t0)[2],t2));}

/* k3939 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3944,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a3960 in k3939 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3961,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 533  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3806(3,t4,t1,t3);}

/* k3949 in k3939 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3959,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 534  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3806(3,t3,t2,((C_word*)t0)[2]);}

/* k3957 in k3949 in k3939 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 533  append */
t3=*((C_word*)lf[59]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3942 in k3939 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],lf[94],((C_word*)t0)[2],t1));}

/* k3889 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3891,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 522  compiler-warning */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[237],lf[238],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3888(t2,((C_word*)t0)[2]);}}

/* k3892 in k3889 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 525  truncate */
t3=*((C_word*)lf[236]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3899 in k3892 in k3889 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3888(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k3886 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 518  qnode */
t2=C_retrieve(lf[232]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3863 in walk in ##compiler#build-node-graph in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[221],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3794,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[221],lf[84],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3785,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[221],lf[231],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3779,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[221],t2,t3,t4));}

/* node-subexpressions in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3770,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[221]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3761,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[221]);
/* support.scm: 496  ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3752,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[221]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3743,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[221]);
/* support.scm: 496  ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3734,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[221]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3725,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[221]);
/* support.scm: 496  ##sys#block-set! */
t5=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3719,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[221]));}

/* f_3713 in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3713,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[221],t2,t3,t4));}

/* ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3303,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_3307(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3711,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 448  append */
t5=*((C_word*)lf[59]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[217]),C_retrieve(lf[218]),C_retrieve(lf[219]));}}

/* k3709 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3307(t3,t2);}

/* k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3307,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 451  ##sys#hash-table-for-each */
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3312,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3322,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t11,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 458  write */
t13=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}}

/* k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3412(t6,t2,((C_word*)t0)[2]);}

/* loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3412(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3412,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 462  caar */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[182]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_3438(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t5)){
t6=t4;
f_3438(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t6)){
t7=t4;
f_3438(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[202]);
if(C_truep(t7)){
t8=t4;
f_3438(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t8)){
t9=t4;
f_3438(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t9)){
t10=t4;
f_3438(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[152]);
if(C_truep(t10)){
t11=t4;
f_3438(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t11)){
t12=t4;
f_3438(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[157]);
if(C_truep(t12)){
t13=t4;
f_3438(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t13)){
t14=t4;
f_3438(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t14)){
t15=t4;
f_3438(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t15)){
t16=t4;
f_3438(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t16)){
t17=t4;
f_3438(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t17)){
t18=t4;
f_3438(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t18)){
t19=t4;
f_3438(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[211]);
if(C_truep(t19)){
t20=t4;
f_3438(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[212]);
if(C_truep(t20)){
t21=t4;
f_3438(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[213]);
if(C_truep(t21)){
t22=t4;
f_3438(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[153]);
if(C_truep(t22)){
t23=t4;
f_3438(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[214]);
if(C_truep(t23)){
t24=t4;
f_3438(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[149]);
t25=t4;
f_3438(t25,(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[215])));}}}}}}}}}}}}}}}}}}}}}

/* k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3438,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 466  caar */
t3=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[181]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[181]);
t4=((C_word*)t0)[8];
f_3425(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[185]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[181]);
if(C_truep(t4)){
t5=((C_word*)t0)[8];
f_3425(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 470  cdar */
t6=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[186]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 472  cdar */
t6=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[187]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3495(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[192]);
if(C_truep(t7)){
t8=t6;
f_3495(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[193]);
if(C_truep(t8)){
t9=t6;
f_3495(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[171]);
if(C_truep(t9)){
t10=t6;
f_3495(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[194]);
if(C_truep(t10)){
t11=t6;
f_3495(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[195]);
if(C_truep(t11)){
t12=t6;
f_3495(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[196]);
if(C_truep(t12)){
t13=t6;
f_3495(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[197]);
if(C_truep(t13)){
t14=t6;
f_3495(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[198]);
t15=t6;
f_3495(t15,(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[6],lf[199])));}}}}}}}}}}}}}

/* k3493 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3495,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 475  caar */
t3=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[189]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 477  cdar */
t4=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[190]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 479  cdar */
t5=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 480  bomb */
t5=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[191],t4);}}}}

/* k3524 in k3493 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3425(2,t3,t2);}

/* k3514 in k3493 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3425(2,t3,t2);}

/* k3500 in k3493 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3506,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 475  cdar */
t3=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3504 in k3500 in k3493 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 475  printf */
t2=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[188],((C_word*)t0)[2],t1);}

/* k3484 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3425(2,t3,t2);}

/* k3474 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3425(2,t3,t2);}

/* k3451 in k3436 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[183]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 466  printf */
t4=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[184],t3);}

/* k3423 in k3420 in loop in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 481  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3412(t3,((C_word*)t0)[2],t2);}

/* k3323 in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[181]);
t5=t3;
f_3360(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3360(t4,C_SCHEME_FALSE);}}

/* k3358 in k3323 in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 483  printf */
t7=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],lf[179],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[181]);
t4=t2;
f_3381(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3381(t3,C_SCHEME_FALSE);}}}

/* k3379 in k3358 in k3323 in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3381,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 485  printf */
t7=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[180],t6);}
else{
t2=((C_word*)t0)[2];
f_3328(2,t2,C_SCHEME_UNDEFINED);}}

/* k3326 in k3323 in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 486  printf */
t4=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[178],t3);}
else{
t3=t2;
f_3331(2,t3,C_SCHEME_UNDEFINED);}}

/* k3329 in k3326 in k3323 in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 487  printf */
t4=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[177],t3);}
else{
t3=t2;
f_3334(2,t3,C_SCHEME_UNDEFINED);}}

/* k3332 in k3329 in k3326 in k3323 in k3320 in a3311 in k3305 in ##compiler#display-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 488  newline */
t2=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3290,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 430  ##sys#hash-table-for-each */
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[168]));}

/* a3289 in ##compiler#display-line-number-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3290,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3301,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[174]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3299 in a3289 in ##compiler#display-line-number-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 432  printf */
t2=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[173],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3260,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3266,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3266(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3266(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3266,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3276,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 426  get */
t5=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[171]);}}

/* k3274 in loop in ##compiler#find-lambda-container in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 427  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3266(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3224,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3231,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 418  ##sys#hash-table-ref */
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[168]),t3);}

/* k3229 in ##compiler#get-line-2 in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_3234(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_3234(t3,C_SCHEME_FALSE);}}

/* k3232 in k3229 in ##compiler#get-line-2 in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_fcall f_3234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 420  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 421  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3214,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 414  get */
t4=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[168]),t3,t2);}

/* ##compiler#count! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_3157r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3157r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3157r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3161,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 402  ##sys#hash-table-ref */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3159 in ##compiler#count! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3161,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3191,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 407  alist-cons */
t7=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 408  ##sys#hash-table-set! */
t6=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k3189 in k3159 in ##compiler#count! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3105,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3109,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 394  ##sys#hash-table-ref */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3107 in ##compiler#collect! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3136,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 398  alist-cons */
t6=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 399  ##sys#hash-table-set! */
t4=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k3134 in k3107 in ##compiler#collect! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3059,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3063,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 386  ##sys#hash-table-ref */
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3061 in ##compiler#put! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3085,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 390  alist-cons */
t5=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 391  ##sys#hash-table-set! */
t4=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k3083 in k3061 in ##compiler#put! in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3041r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3041r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3045,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 380  ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3043 in ##compiler#get-all in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3053,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 382  filter-map */
t3=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a3052 in k3043 in ##compiler#get-all in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3053,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3023,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3027,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 374  ##sys#hash-table-ref */
t6=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3025 in ##compiler#get in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2962,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2966,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[159]));}

/* a2998 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2999,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 360  put! */
t4=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[158],C_SCHEME_TRUE);}

/* k3001 in a2998 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[156])))){
/* support.scm: 361  put! */
t3=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[157],C_SCHEME_TRUE);}
else{
t3=t2;
f_3006(2,t3,C_SCHEME_UNDEFINED);}}

/* k3004 in k3001 in a2998 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[155])))){
/* support.scm: 362  put! */
t2=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[152],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2964 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[154]));}

/* a2983 in k2964 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2984,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 366  put! */
t4=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[153],C_SCHEME_TRUE);}

/* k2986 in a2983 in k2964 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[151])))){
/* support.scm: 367  put! */
t2=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[152],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2967 in k2964 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[150]));}

/* a2973 in k2967 in k2964 in ##compiler#initialize-analysis-database in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2974,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 370  put! */
t4=C_retrieve(lf[148]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t3,lf[149],C_SCHEME_TRUE);}

/* ##compiler#expand-profile-lambda in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2905,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[140]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2909,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 342  gensym */
t7=C_retrieve(lf[95]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k2907 in ##compiler#expand-profile-lambda in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 343  alist-cons */
t3=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[141]));}

/* k2911 in k2907 in ##compiler#expand-profile-lambda in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=C_mutate((C_word*)lf[141]+1,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[140]+1,t3);
t5=(C_word)C_a_i_list(&a,2,lf[84],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[142],t5,C_retrieve(lf[143]));
t7=(C_word)C_a_i_list(&a,3,lf[107],C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_list(&a,3,lf[107],((C_word*)t0)[5],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,3,lf[144],t8,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[107],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,lf[84],((C_word*)t0)[6]);
t12=(C_word)C_a_i_list(&a,3,lf[145],t11,C_retrieve(lf[143]));
t13=(C_word)C_a_i_list(&a,3,lf[107],C_SCHEME_END_OF_LIST,t12);
t14=(C_word)C_a_i_list(&a,4,lf[146],t7,t10,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[107],((C_word*)t0)[3],t14));}

/* ##compiler#process-lambda-documentation in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2902,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2799,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2806,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[135]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2808,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2814,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2839,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2888 in a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2889r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2889r(t0,t1,t2);}}

static void C_ccall f_2889r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2895,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g239241 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2894 in a2888 in a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2844 in a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2849,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2873,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 327  with-input-from-string */
t4=C_retrieve(lf[133]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a2872 in a2844 in a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2879,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2887,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 327  read */
t4=*((C_word*)lf[129]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2885 in a2872 in a2844 in a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 327  unfold */
t2=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[131]+1),*((C_word*)lf[132]+1),((C_word*)t0)[2],t1);}

/* a2878 in a2872 in a2844 in a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2879,3,t0,t1,t2);}
/* support.scm: 327  read */
t3=*((C_word*)lf[129]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2847 in a2844 in a2838 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2849,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[127]);}
else{
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_nullp(t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[128],t1)));}}

/* a2813 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2814,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* g239241 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2819 in a2813 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 324  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k2829 in a2819 in a2813 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 325  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 326  ->string */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2826 in a2819 in a2813 in a2807 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 322  quit */
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[126],((C_word*)t0)[2],t1);}

/* k2804 in ##compiler#string->expr in k2796 in k2793 in k1448 in k1445 in k1442 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2424,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2427,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 314  walk */
t9=((C_word*)t6)[1];
f_2427(3,t9,t8,t2);}

/* k2786 in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 315  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2427,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[84]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2581,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t2);
t9=t6;
f_2581(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_2581(t8,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2632,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[94]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cadr(t2);
t11=t6;
f_2632(t11,(C_word)C_i_listp(t10));}
else{
t10=t6;
f_2632(t10,C_SCHEME_FALSE);}}
else{
t9=t6;
f_2632(t9,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2632(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2632,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2641(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g184187 */
t4=((C_word*)t0)[3];
f_2429(t4,((C_word*)t0)[2],t2,t3);}}

/* g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2641,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2651,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t6=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2742,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* cdar */
t8=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}
else{
t7=t5;
f_2688(t7,C_SCHEME_FALSE);}}}

/* k2740 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* cddar */
t3=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2688(t2,C_SCHEME_FALSE);}}

/* k2736 in k2740 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2688(t2,(C_word)C_i_nullp(t1));}

/* k2686 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* cadar */
t4=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* g184187 */
t4=((C_word*)t0)[2];
f_2429(t4,((C_word*)t0)[4],t2,t3);}}

/* k2709 in k2686 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2707,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* caar */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2705 in k2709 in k2686 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2707,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* g179224 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2641(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2649 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2654,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t3=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2652 in k2649 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2668,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[120]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2673 in k2652 in k2649 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2674,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* walk174 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2427(3,t5,t4,t3);}

/* k2680 in a2673 in k2652 in k2649 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2666 in k2652 in k2649 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2670 in k2666 in k2652 in k2649 in g179 in k2630 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[94],t2));}

/* k2579 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2581,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2601,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##compiler#collapsable-literal? */
t4=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g184187 */
t4=((C_word*)t0)[2];
f_2429(t4,((C_word*)t0)[4],t2,t3);}}

/* k2599 in k2579 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##compiler#make-random-name */
t3=C_retrieve(lf[119]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k2591 in k2599 in k2579 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2597,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* alist-cons */
t3=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2595 in k2591 in k2599 in k2579 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* g184 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2429(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2429,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[99]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2439(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[113]);
if(C_truep(t7)){
t8=t6;
f_2439(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[114]);
if(C_truep(t8)){
t9=t6;
f_2439(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[115]);
if(C_truep(t9)){
t10=t6;
f_2439(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[116]);
t11=t6;
f_2439(t11,(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[117])));}}}}}

/* k2437 in g184 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2439,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[100]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_2448(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[106]);
if(C_truep(t4)){
t5=t3;
f_2448(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[107]);
if(C_truep(t5)){
t6=t3;
f_2448(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[108]);
if(C_truep(t6)){
t7=t3;
f_2448(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[109]);
if(C_truep(t7)){
t8=t3;
f_2448(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[110]);
if(C_truep(t8)){
t9=t3;
f_2448(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[111]);
t10=t3;
f_2448(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[112])));}}}}}}}}

/* k2446 in k2437 in g184 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2448,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2459,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[103]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2472(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[104]);
t5=t3;
f_2472(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[3],lf[105])));}}}

/* k2470 in k2446 in k2437 in g184 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_fcall f_2472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2472,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}}

/* k2477 in k2470 in k2446 in k2437 in g184 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2457 in k2446 in k2437 in g184 in walk in ##compiler#extract-mutable-constants in k1448 in k1445 in k1442 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 309  cons* */
t2=C_retrieve(lf[101]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#canonicalize-begin-body in k1448 in k1445 in k1442 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2341,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2347(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k1448 in k1445 in k1442 */
static void C_fcall f_2347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2347,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[92]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[93]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2375,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_2375(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2412,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 285  constant? */
t8=C_retrieve(lf[83]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k2410 in loop in ##compiler#canonicalize-begin-body in k1448 in k1445 in k1442 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2375(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[97])));}

/* k2373 in loop in ##compiler#canonicalize-begin-body in k1448 in k1445 in k1442 */
static void C_fcall f_2375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2375,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 287  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2347(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 288  gensym */
t3=C_retrieve(lf[95]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[96]);}}

/* k2403 in k2373 in loop in ##compiler#canonicalize-begin-body in k1448 in k1445 in k1442 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2393,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 289  loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2347(t7,t5,t6);}

/* k2391 in k2403 in k2373 in loop in ##compiler#canonicalize-begin-body in k1448 in k1445 in k1442 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[94],((C_word*)t0)[2],t1));}

/* ##compiler#basic-literal? in k1448 in k1445 in k1442 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2281,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 270  constant? */
t6=C_retrieve(lf[83]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}

/* k2295 in ##compiler#basic-literal? in k1448 in k1445 in k1442 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2339,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 271  vector->list */
t4=*((C_word*)lf[90]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2303(2,t3,C_SCHEME_FALSE);}}}

/* k2337 in k2295 in ##compiler#basic-literal? in k1448 in k1445 in k1442 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 271  every */
t2=C_retrieve(lf[89]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[88]),t1);}

/* k2301 in k2295 in ##compiler#basic-literal? in k1448 in k1445 in k1442 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 273  basic-literal? */
t4=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k2316 in k2301 in k2295 in ##compiler#basic-literal? in k1448 in k1445 in k1442 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 274  basic-literal? */
t3=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k1448 in k1445 in k1442 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2235,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 260  big-fixnum? */
t5=C_retrieve(lf[87]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t3;
f_2239(t4,C_SCHEME_FALSE);}}

/* k2277 in ##compiler#immediate? in k1448 in k1445 in k1442 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2239(t2,(C_word)C_i_not(t1));}

/* k2237 in ##compiler#immediate? in k1448 in k1445 in k1442 */
static void C_fcall f_2239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k1448 in k1445 in k1442 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2205,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k1448 in k1445 in k1442 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2159,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[84],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#follow-without-loop in k1448 in k1445 in k1442 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2128,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2134,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2134(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k1448 in k1445 in k1442 */
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2134,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 238  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 239  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a2148 in loop in ##compiler#follow-without-loop in k1448 in k1445 in k1442 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2149,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 239  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2134(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k1448 in k1445 in k1442 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2065,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2079,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 228  reverse */
t6=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k2077 in ##compiler#fold-inner in k1448 in k1445 in k1442 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2081,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2081(t5,((C_word*)t0)[2],t1);}

/* fold in k2077 in ##compiler#fold-inner in k1448 in k1445 in k1442 */
static void C_fcall f_2081(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2081,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_2089(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 233  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k2108 in fold in k2077 in ##compiler#fold-inner in k1448 in k1445 in k1442 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2089(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k2087 in fold in k2077 in ##compiler#fold-inner in k1448 in k1445 in k1442 */
static void C_fcall f_2089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k1448 in k1445 in k1442 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2053,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[78]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 223  close-input-port */
t4=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k1448 in k1445 in k1442 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2006r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2006r(t0,t1,t2,t3);}}

static void C_ccall f_2006r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[71]))){
/* support.scm: 217  current-input-port */
t4=*((C_word*)lf[72]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2022,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 218  file-exists? */
t5=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k2020 in ##compiler#check-and-open-input-file in k1448 in k1445 in k1442 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 218  open-input-file */
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2034(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_2034(t5,(C_word)C_i_not(t4));}}}

/* k2032 in k2020 in ##compiler#check-and-open-input-file in k1448 in k1445 in k1442 */
static void C_fcall f_2034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 219  quit */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[74],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 220  quit */
t3=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[75],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k1448 in k1445 in k1442 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1999,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub100(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k1448 in k1445 in k1442 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1992,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub96(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k1448 in k1445 in k1442 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1936,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1990,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 198  ->string */
t5=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1988 in ##compiler#valid-c-identifier? in k1448 in k1445 in k1442 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[61]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1938 in ##compiler#valid-c-identifier? in k1448 in k1445 in k1442 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1963,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 202  any */
t7=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1962 in k1938 in ##compiler#valid-c-identifier? in k1448 in k1445 in k1442 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1963,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1842,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[61]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1860,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1860(t5,((C_word*)t0)[2],t1);}

/* loop in k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1860,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[58]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1882,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_1882(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_1882(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[64])));}}}

/* k1880 in loop in k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_fcall f_1882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1882,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_1889(t3,lf[62]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_1889(t4,(C_truep(t3)?lf[63]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 195  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1860(t4,t2,t3);}}

/* k1919 in k1880 in loop in k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1887 in k1880 in loop in k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_fcall f_1889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1889,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 193  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k1903 in k1887 in k1880 in loop in k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[61]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1891 in k1887 in k1880 in loop in k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 194  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1860(t4,t2,t3);}

/* k1895 in k1891 in k1887 in k1880 in loop in k1856 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 189  append */
t2=*((C_word*)lf[59]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[60],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1852 in ##compiler#c-ify-string in k1448 in k1445 in k1442 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k1448 in k1445 in k1442 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1798,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1804,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1804(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k1448 in k1445 in k1442 */
static void C_fcall f_1804(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1804,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 175  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k1826 in loop in ##compiler#build-lambda-list in k1448 in k1445 in k1442 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k1448 in k1445 in k1442 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1773,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 169  string->symbol */
t3=*((C_word*)lf[51]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1796,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 170  sprintf */
t4=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[52],t2);}}}

/* k1794 in ##compiler#symbolify in k1448 in k1445 in k1442 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 170  string->symbol */
t2=*((C_word*)lf[51]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k1448 in k1445 in k1442 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1752,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 164  symbol->string */
t3=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* support.scm: 165  sprintf */
t3=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[49],t2);}}}

/* ##compiler#posq in k1448 in k1445 in k1442 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1716,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1722(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k1448 in k1445 in k1442 */
static C_word C_fcall f_1722(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k1448 in k1445 in k1442 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1648,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1651,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1672(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k1448 in k1445 in k1442 */
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 148  err */
t4=((C_word*)t0)[3];
f_1651(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 150  err */
t5=((C_word*)t0)[3];
f_1651(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 151  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k1448 in k1445 in k1442 */
static void C_fcall f_1651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1651,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 145  real-name */
t3=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1657 in err in ##compiler#check-signature in k1448 in k1445 in k1442 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1663,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 146  map-llist */
t4=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[44]),t3);}

/* k1661 in k1657 in err in ##compiler#check-signature in k1448 in k1445 in k1442 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 144  quit */
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[43],((C_word*)t0)[2],t1);}

/* map-llist in k1448 in k1445 in k1442 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1605,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1611,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1611(t7,t1,t3);}

/* loop in map-llist in k1448 in k1445 in k1442 */
static void C_fcall f_1611(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1611,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 139  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 140  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k1632 in loop in map-llist in k1448 in k1445 in k1442 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 140  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1611(t4,t2,t3);}

/* k1636 in k1632 in loop in map-llist in k1448 in k1445 in k1442 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k1448 in k1445 in k1442 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1602,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[35])));}

/* ##sys#syntax-error-hook in k1448 in k1445 in k1442 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1577r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1577r(t0,t1,t2,t3);}}

static void C_ccall f_1577r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1581,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 125  current-error-port */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1579 in ##sys#syntax-error-hook in k1448 in k1445 in k1442 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 126  fprintf */
t3=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[38],((C_word*)t0)[2]);}

/* k1582 in k1579 in ##sys#syntax-error-hook in k1448 in k1445 in k1442 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1594 in k1582 in k1579 in ##sys#syntax-error-hook in k1448 in k1445 in k1442 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1595,3,t0,t1,t2);}
/* fprintf */
t3=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],lf[37],t2);}

/* k1585 in k1582 in k1579 in ##sys#syntax-error-hook in k1448 in k1445 in k1442 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 128  print-call-chain */
t3=C_retrieve(lf[34]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[35]),lf[36]);}

/* k1588 in k1585 in k1582 in k1579 in ##sys#syntax-error-hook in k1448 in k1445 in k1442 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 129  exit */
t2=C_retrieve(lf[31]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k1448 in k1445 in k1442 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1558r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1558r(t0,t1,t2,t3);}}

static void C_ccall f_1558r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1562,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 118  current-error-port */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1560 in quit in k1448 in k1445 in k1442 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1565,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 119  string-append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[32],((C_word*)t0)[2]);}

/* k1573 in k1560 in quit in k1448 in k1445 in k1442 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[26]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1563 in k1560 in quit in k1448 in k1445 in k1442 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 120  newline */
t3=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1566 in k1563 in k1560 in quit in k1448 in k1445 in k1442 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 121  exit */
t2=C_retrieve(lf[31]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k1448 in k1445 in k1442 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1529r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1529r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1529r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1536,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[29]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[9]));
t7=t5;
f_1536(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_1536(t6,C_SCHEME_FALSE);}}

/* k1534 in ##compiler#compiler-warning in k1448 in k1445 in k1442 */
static void C_fcall f_1536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1536,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 113  current-error-port */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1537 in k1534 in ##compiler#compiler-warning in k1448 in k1445 in k1442 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1542,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 114  string-append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[27],((C_word*)t0)[2]);}

/* k1547 in k1537 in k1534 in ##compiler#compiler-warning in k1448 in k1445 in k1442 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[26]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1540 in k1537 in k1534 in ##compiler#compiler-warning in k1448 in k1445 in k1442 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 115  newline */
t2=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1489r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1489r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1489r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[8])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1499,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 102  printf */
t6=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[24],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k1497 in ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 105  display */
t4=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[23]);}
else{
t3=t2;
f_1502(2,t3,C_SCHEME_UNDEFINED);}}

/* k1512 in k1497 in ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1519,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a1518 in k1512 in k1497 in ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1519,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1527,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 106  force */
t4=C_retrieve(lf[20]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1525 in a1518 in k1512 in k1497 in ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 106  printf */
t2=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[19],t1);}

/* k1500 in k1497 in ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 107  newline */
t3=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1503 in k1500 in k1497 in ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 108  flush-output */
t3=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1506 in k1503 in k1500 in k1497 in ##compiler#debugging in k1448 in k1445 in k1442 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k1448 in k1445 in k1442 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1462r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1462r(t0,t1,t2);}}

static void C_ccall f_1462r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1476,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 96   string-append */
t5=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[13],t4);}
else{
/* support.scm: 97   error */
t3=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[14]);}}

/* k1474 in ##compiler#bomb in k1448 in k1445 in k1442 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[11]+1),t1,t2);}

/* f_1457 in k1448 in k1445 in k1442 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[574] = {
{"toplevelsupport.scm",(void*)C_support_toplevel},
{"f_1444support.scm",(void*)f_1444},
{"f_1447support.scm",(void*)f_1447},
{"f_1450support.scm",(void*)f_1450},
{"f_2795support.scm",(void*)f_2795},
{"f_2798support.scm",(void*)f_2798},
{"f_8896support.scm",(void*)f_8896},
{"f_8785support.scm",(void*)f_8785},
{"f_8894support.scm",(void*)f_8894},
{"f_8789support.scm",(void*)f_8789},
{"f_8794support.scm",(void*)f_8794},
{"f_8798support.scm",(void*)f_8798},
{"f_8834support.scm",(void*)f_8834},
{"f_8878support.scm",(void*)f_8878},
{"f_8850support.scm",(void*)f_8850},
{"f_8801support.scm",(void*)f_8801},
{"f_8808support.scm",(void*)f_8808},
{"f_8804support.scm",(void*)f_8804},
{"f_8756support.scm",(void*)f_8756},
{"f_8783support.scm",(void*)f_8783},
{"f_8767support.scm",(void*)f_8767},
{"f_8770support.scm",(void*)f_8770},
{"f_8772support.scm",(void*)f_8772},
{"f_8776support.scm",(void*)f_8776},
{"f_8760support.scm",(void*)f_8760},
{"f_8693support.scm",(void*)f_8693},
{"f_8730support.scm",(void*)f_8730},
{"f_8754support.scm",(void*)f_8754},
{"f_8740support.scm",(void*)f_8740},
{"f_8744support.scm",(void*)f_8744},
{"f_8715support.scm",(void*)f_8715},
{"f_8723support.scm",(void*)f_8723},
{"f_8624support.scm",(void*)f_8624},
{"f_8628support.scm",(void*)f_8628},
{"f_8633support.scm",(void*)f_8633},
{"f_8637support.scm",(void*)f_8637},
{"f_8688support.scm",(void*)f_8688},
{"f_8667support.scm",(void*)f_8667},
{"f_8679support.scm",(void*)f_8679},
{"f_8682support.scm",(void*)f_8682},
{"f_8655support.scm",(void*)f_8655},
{"f_8599support.scm",(void*)f_8599},
{"f_8609support.scm",(void*)f_8609},
{"f_8612support.scm",(void*)f_8612},
{"f_8512support.scm",(void*)f_8512},
{"f_8521support.scm",(void*)f_8521},
{"f_8534support.scm",(void*)f_8534},
{"f_8540support.scm",(void*)f_8540},
{"f_8593support.scm",(void*)f_8593},
{"f_8543support.scm",(void*)f_8543},
{"f_8558support.scm",(void*)f_8558},
{"f_8566support.scm",(void*)f_8566},
{"f_8576support.scm",(void*)f_8576},
{"f_8561support.scm",(void*)f_8561},
{"f_8549support.scm",(void*)f_8549},
{"f_8516support.scm",(void*)f_8516},
{"f_8506support.scm",(void*)f_8506},
{"f_8430support.scm",(void*)f_8430},
{"f_8437support.scm",(void*)f_8437},
{"f_8449support.scm",(void*)f_8449},
{"f_8460support.scm",(void*)f_8460},
{"f_8456support.scm",(void*)f_8456},
{"f_8418support.scm",(void*)f_8418},
{"f_8424support.scm",(void*)f_8424},
{"f_8406support.scm",(void*)f_8406},
{"f_8410support.scm",(void*)f_8410},
{"f_8327support.scm",(void*)f_8327},
{"f_8346support.scm",(void*)f_8346},
{"f_8371support.scm",(void*)f_8371},
{"f_8375support.scm",(void*)f_8375},
{"f_8377support.scm",(void*)f_8377},
{"f_8384support.scm",(void*)f_8384},
{"f_8397support.scm",(void*)f_8397},
{"f_8401support.scm",(void*)f_8401},
{"f_8330support.scm",(void*)f_8330},
{"f_8334support.scm",(void*)f_8334},
{"f_8340support.scm",(void*)f_8340},
{"f_8321support.scm",(void*)f_8321},
{"f_8277support.scm",(void*)f_8277},
{"f_8289support.scm",(void*)f_8289},
{"f_8293support.scm",(void*)f_8293},
{"f_8297support.scm",(void*)f_8297},
{"f_8285support.scm",(void*)f_8285},
{"f_8268support.scm",(void*)f_8268},
{"f_8259support.scm",(void*)f_8259},
{"f_8253support.scm",(void*)f_8253},
{"f_8247support.scm",(void*)f_8247},
{"f_8235support.scm",(void*)f_8235},
{"f_8239support.scm",(void*)f_8239},
{"f_8242support.scm",(void*)f_8242},
{"f_8197support.scm",(void*)f_8197},
{"f_8201support.scm",(void*)f_8201},
{"f_8204support.scm",(void*)f_8204},
{"f_8211support.scm",(void*)f_8211},
{"f_8155support.scm",(void*)f_8155},
{"f_8164support.scm",(void*)f_8164},
{"f_8126support.scm",(void*)f_8126},
{"f_8136support.scm",(void*)f_8136},
{"f_7929support.scm",(void*)f_7929},
{"f_8108support.scm",(void*)f_8108},
{"f_8057support.scm",(void*)f_8057},
{"f_8102support.scm",(void*)f_8102},
{"f_8106support.scm",(void*)f_8106},
{"f_8060support.scm",(void*)f_8060},
{"f_8065support.scm",(void*)f_8065},
{"f_8069support.scm",(void*)f_8069},
{"f_8063support.scm",(void*)f_8063},
{"f_8020support.scm",(void*)f_8020},
{"f_8024support.scm",(void*)f_8024},
{"f_8033support.scm",(void*)f_8033},
{"f_8037support.scm",(void*)f_8037},
{"f_8027support.scm",(void*)f_8027},
{"f_7985support.scm",(void*)f_7985},
{"f_7991support.scm",(void*)f_7991},
{"f_8018support.scm",(void*)f_8018},
{"f_8004support.scm",(void*)f_8004},
{"f_7938support.scm",(void*)f_7938},
{"f_7944support.scm",(void*)f_7944},
{"f_7983support.scm",(void*)f_7983},
{"f_7965support.scm",(void*)f_7965},
{"f_7770support.scm",(void*)f_7770},
{"f_7927support.scm",(void*)f_7927},
{"f_7914support.scm",(void*)f_7914},
{"f_7920support.scm",(void*)f_7920},
{"f_7773support.scm",(void*)f_7773},
{"f_7792support.scm",(void*)f_7792},
{"f_7876support.scm",(void*)f_7876},
{"f_7888support.scm",(void*)f_7888},
{"f_7846support.scm",(void*)f_7846},
{"f_7857support.scm",(void*)f_7857},
{"f_7837support.scm",(void*)f_7837},
{"f_7823support.scm",(void*)f_7823},
{"f_7811support.scm",(void*)f_7811},
{"f_7692support.scm",(void*)f_7692},
{"f_7698support.scm",(void*)f_7698},
{"f_7753support.scm",(void*)f_7753},
{"f_7726support.scm",(void*)f_7726},
{"f_7720support.scm",(void*)f_7720},
{"f_7696support.scm",(void*)f_7696},
{"f_7416support.scm",(void*)f_7416},
{"f_7629support.scm",(void*)f_7629},
{"f_7588support.scm",(void*)f_7588},
{"f_7541support.scm",(void*)f_7541},
{"f_7519support.scm",(void*)f_7519},
{"f_7106support.scm",(void*)f_7106},
{"f_7410support.scm",(void*)f_7410},
{"f_7118support.scm",(void*)f_7118},
{"f_7128support.scm",(void*)f_7128},
{"f_7146support.scm",(void*)f_7146},
{"f_7180support.scm",(void*)f_7180},
{"f_7109support.scm",(void*)f_7109},
{"f_6787support.scm",(void*)f_6787},
{"f_7100support.scm",(void*)f_7100},
{"f_6793support.scm",(void*)f_6793},
{"f_6803support.scm",(void*)f_6803},
{"f_6812support.scm",(void*)f_6812},
{"f_6824support.scm",(void*)f_6824},
{"f_6836support.scm",(void*)f_6836},
{"f_6842support.scm",(void*)f_6842},
{"f_6876support.scm",(void*)f_6876},
{"f_6747support.scm",(void*)f_6747},
{"f_6781support.scm",(void*)f_6781},
{"f_6753support.scm",(void*)f_6753},
{"f_6757support.scm",(void*)f_6757},
{"f_6716support.scm",(void*)f_6716},
{"f_6729support.scm",(void*)f_6729},
{"f_6720support.scm",(void*)f_6720},
{"f_6685support.scm",(void*)f_6685},
{"f_6698support.scm",(void*)f_6698},
{"f_6689support.scm",(void*)f_6689},
{"f_5830support.scm",(void*)f_5830},
{"f_6679support.scm",(void*)f_6679},
{"f_5836support.scm",(void*)f_5836},
{"f_5842support.scm",(void*)f_5842},
{"f_5867support.scm",(void*)f_5867},
{"f_5882support.scm",(void*)f_5882},
{"f_5897support.scm",(void*)f_5897},
{"f_5935support.scm",(void*)f_5935},
{"f_5950support.scm",(void*)f_5950},
{"f_5992support.scm",(void*)f_5992},
{"f_6019support.scm",(void*)f_6019},
{"f_6034support.scm",(void*)f_6034},
{"f_6049support.scm",(void*)f_6049},
{"f_6093support.scm",(void*)f_6093},
{"f_6138support.scm",(void*)f_6138},
{"f_6181support.scm",(void*)f_6181},
{"f_6385support.scm",(void*)f_6385},
{"f_6353support.scm",(void*)f_6353},
{"f_6241support.scm",(void*)f_6241},
{"f_6245support.scm",(void*)f_6245},
{"f_6209support.scm",(void*)f_6209},
{"f_6213support.scm",(void*)f_6213},
{"f_6204support.scm",(void*)f_6204},
{"f_6096support.scm",(void*)f_6096},
{"f_6111support.scm",(void*)f_6111},
{"f_6052support.scm",(void*)f_6052},
{"f_5953support.scm",(void*)f_5953},
{"f_5968support.scm",(void*)f_5968},
{"f_5900support.scm",(void*)f_5900},
{"f_5794support.scm",(void*)f_5794},
{"f_5798support.scm",(void*)f_5798},
{"f_5809support.scm",(void*)f_5809},
{"f_5815support.scm",(void*)f_5815},
{"f_5819support.scm",(void*)f_5819},
{"f_5801support.scm",(void*)f_5801},
{"f_5755support.scm",(void*)f_5755},
{"f_5767support.scm",(void*)f_5767},
{"f_5774support.scm",(void*)f_5774},
{"f_5777support.scm",(void*)f_5777},
{"f_5780support.scm",(void*)f_5780},
{"f_5783support.scm",(void*)f_5783},
{"f_5786support.scm",(void*)f_5786},
{"f_5789support.scm",(void*)f_5789},
{"f_5761support.scm",(void*)f_5761},
{"f_5675support.scm",(void*)f_5675},
{"f_5684support.scm",(void*)f_5684},
{"f_5690support.scm",(void*)f_5690},
{"f_5679support.scm",(void*)f_5679},
{"f_5624support.scm",(void*)f_5624},
{"f_5673support.scm",(void*)f_5673},
{"f_5669support.scm",(void*)f_5669},
{"f_5628support.scm",(void*)f_5628},
{"f_5637support.scm",(void*)f_5637},
{"f_5640support.scm",(void*)f_5640},
{"f_5662support.scm",(void*)f_5662},
{"f_5645support.scm",(void*)f_5645},
{"f_5618support.scm",(void*)f_5618},
{"f_5560support.scm",(void*)f_5560},
{"f_5566support.scm",(void*)f_5566},
{"f_5570support.scm",(void*)f_5570},
{"f_5616support.scm",(void*)f_5616},
{"f_5597support.scm",(void*)f_5597},
{"f_5516support.scm",(void*)f_5516},
{"f_5534support.scm",(void*)f_5534},
{"f_5545support.scm",(void*)f_5545},
{"f_5538support.scm",(void*)f_5538},
{"f_5542support.scm",(void*)f_5542},
{"f_5523support.scm",(void*)f_5523},
{"f_5528support.scm",(void*)f_5528},
{"f_5485support.scm",(void*)f_5485},
{"f_5491support.scm",(void*)f_5491},
{"f_5498support.scm",(void*)f_5498},
{"f_5501support.scm",(void*)f_5501},
{"f_5399support.scm",(void*)f_5399},
{"f_5408support.scm",(void*)f_5408},
{"f_5447support.scm",(void*)f_5447},
{"f_5454support.scm",(void*)f_5454},
{"f_5412support.scm",(void*)f_5412},
{"f_5433support.scm",(void*)f_5433},
{"f_5431support.scm",(void*)f_5431},
{"f_5420support.scm",(void*)f_5420},
{"f_5424support.scm",(void*)f_5424},
{"f_5415support.scm",(void*)f_5415},
{"f_5393support.scm",(void*)f_5393},
{"f_5301support.scm",(void*)f_5301},
{"f_5325support.scm",(void*)f_5325},
{"f_5215support.scm",(void*)f_5215},
{"f_5221support.scm",(void*)f_5221},
{"f_5237support.scm",(void*)f_5237},
{"f_5251support.scm",(void*)f_5251},
{"f_5259support.scm",(void*)f_5259},
{"f_5020support.scm",(void*)f_5020},
{"f_5199support.scm",(void*)f_5199},
{"f_5205support.scm",(void*)f_5205},
{"f_5095support.scm",(void*)f_5095},
{"f_5117support.scm",(void*)f_5117},
{"f_5130support.scm",(void*)f_5130},
{"f_5161support.scm",(void*)f_5161},
{"f_5052support.scm",(void*)f_5052},
{"f_5074support.scm",(void*)f_5074},
{"f_5023support.scm",(void*)f_5023},
{"f_5047support.scm",(void*)f_5047},
{"f_4958support.scm",(void*)f_4958},
{"f_4962support.scm",(void*)f_4962},
{"f_4965support.scm",(void*)f_4965},
{"f_4968support.scm",(void*)f_4968},
{"f_4979support.scm",(void*)f_4979},
{"f_4924support.scm",(void*)f_4924},
{"f_4930support.scm",(void*)f_4930},
{"f_4944support.scm",(void*)f_4944},
{"f_4948support.scm",(void*)f_4948},
{"f_4746support.scm",(void*)f_4746},
{"f_4750support.scm",(void*)f_4750},
{"f_4758support.scm",(void*)f_4758},
{"f_4907support.scm",(void*)f_4907},
{"f_4915support.scm",(void*)f_4915},
{"f_4910support.scm",(void*)f_4910},
{"f_4859support.scm",(void*)f_4859},
{"f_4863support.scm",(void*)f_4863},
{"f_4866support.scm",(void*)f_4866},
{"f_4901support.scm",(void*)f_4901},
{"f_4893support.scm",(void*)f_4893},
{"f_4877support.scm",(void*)f_4877},
{"f_4872support.scm",(void*)f_4872},
{"f_4826support.scm",(void*)f_4826},
{"f_4829support.scm",(void*)f_4829},
{"f_4840support.scm",(void*)f_4840},
{"f_4835support.scm",(void*)f_4835},
{"f_4810support.scm",(void*)f_4810},
{"f_4802support.scm",(void*)f_4802},
{"f_4797support.scm",(void*)f_4797},
{"f_4781support.scm",(void*)f_4781},
{"f_4752support.scm",(void*)f_4752},
{"f_4653support.scm",(void*)f_4653},
{"f_4659support.scm",(void*)f_4659},
{"f_4671support.scm",(void*)f_4671},
{"f_4675support.scm",(void*)f_4675},
{"f_4678support.scm",(void*)f_4678},
{"f_4738support.scm",(void*)f_4738},
{"f_4714support.scm",(void*)f_4714},
{"f_4697support.scm",(void*)f_4697},
{"f_4701support.scm",(void*)f_4701},
{"f_4683support.scm",(void*)f_4683},
{"f_4665support.scm",(void*)f_4665},
{"f_4605support.scm",(void*)f_4605},
{"f_4611support.scm",(void*)f_4611},
{"f_4631support.scm",(void*)f_4631},
{"f_4635support.scm",(void*)f_4635},
{"f_4311support.scm",(void*)f_4311},
{"f_4317support.scm",(void*)f_4317},
{"f_4336support.scm",(void*)f_4336},
{"f_4546support.scm",(void*)f_4546},
{"f_4576support.scm",(void*)f_4576},
{"f_4572support.scm",(void*)f_4572},
{"f_4553support.scm",(void*)f_4553},
{"f_4557support.scm",(void*)f_4557},
{"f_4492support.scm",(void*)f_4492},
{"f_4533support.scm",(void*)f_4533},
{"f_4506support.scm",(void*)f_4506},
{"f_4510support.scm",(void*)f_4510},
{"f_4468support.scm",(void*)f_4468},
{"f_4435support.scm",(void*)f_4435},
{"f_4414support.scm",(void*)f_4414},
{"f_4410support.scm",(void*)f_4410},
{"f_4398support.scm",(void*)f_4398},
{"f_4406support.scm",(void*)f_4406},
{"f_4402support.scm",(void*)f_4402},
{"f_4360support.scm",(void*)f_4360},
{"f_4343support.scm",(void*)f_4343},
{"f_3803support.scm",(void*)f_3803},
{"f_4306support.scm",(void*)f_4306},
{"f_4309support.scm",(void*)f_4309},
{"f_3806support.scm",(void*)f_3806},
{"f_4296support.scm",(void*)f_4296},
{"f_4179support.scm",(void*)f_4179},
{"f_4222support.scm",(void*)f_4222},
{"f_4236support.scm",(void*)f_4236},
{"f_4243support.scm",(void*)f_4243},
{"f_4250support.scm",(void*)f_4250},
{"f_4240support.scm",(void*)f_4240},
{"f_4229support.scm",(void*)f_4229},
{"f_4216support.scm",(void*)f_4216},
{"f_4204support.scm",(void*)f_4204},
{"f_4188support.scm",(void*)f_4188},
{"f_4158support.scm",(void*)f_4158},
{"f_4142support.scm",(void*)f_4142},
{"f_4138support.scm",(void*)f_4138},
{"f_4105support.scm",(void*)f_4105},
{"f_4063support.scm",(void*)f_4063},
{"f_4032support.scm",(void*)f_4032},
{"f_4018support.scm",(void*)f_4018},
{"f_3992support.scm",(void*)f_3992},
{"f_3941support.scm",(void*)f_3941},
{"f_3961support.scm",(void*)f_3961},
{"f_3951support.scm",(void*)f_3951},
{"f_3959support.scm",(void*)f_3959},
{"f_3944support.scm",(void*)f_3944},
{"f_3891support.scm",(void*)f_3891},
{"f_3894support.scm",(void*)f_3894},
{"f_3901support.scm",(void*)f_3901},
{"f_3888support.scm",(void*)f_3888},
{"f_3865support.scm",(void*)f_3865},
{"f_3794support.scm",(void*)f_3794},
{"f_3785support.scm",(void*)f_3785},
{"f_3779support.scm",(void*)f_3779},
{"f_3770support.scm",(void*)f_3770},
{"f_3761support.scm",(void*)f_3761},
{"f_3752support.scm",(void*)f_3752},
{"f_3743support.scm",(void*)f_3743},
{"f_3734support.scm",(void*)f_3734},
{"f_3725support.scm",(void*)f_3725},
{"f_3719support.scm",(void*)f_3719},
{"f_3713support.scm",(void*)f_3713},
{"f_3303support.scm",(void*)f_3303},
{"f_3711support.scm",(void*)f_3711},
{"f_3307support.scm",(void*)f_3307},
{"f_3312support.scm",(void*)f_3312},
{"f_3322support.scm",(void*)f_3322},
{"f_3412support.scm",(void*)f_3412},
{"f_3422support.scm",(void*)f_3422},
{"f_3438support.scm",(void*)f_3438},
{"f_3495support.scm",(void*)f_3495},
{"f_3526support.scm",(void*)f_3526},
{"f_3516support.scm",(void*)f_3516},
{"f_3502support.scm",(void*)f_3502},
{"f_3506support.scm",(void*)f_3506},
{"f_3486support.scm",(void*)f_3486},
{"f_3476support.scm",(void*)f_3476},
{"f_3453support.scm",(void*)f_3453},
{"f_3425support.scm",(void*)f_3425},
{"f_3325support.scm",(void*)f_3325},
{"f_3360support.scm",(void*)f_3360},
{"f_3381support.scm",(void*)f_3381},
{"f_3328support.scm",(void*)f_3328},
{"f_3331support.scm",(void*)f_3331},
{"f_3334support.scm",(void*)f_3334},
{"f_3284support.scm",(void*)f_3284},
{"f_3290support.scm",(void*)f_3290},
{"f_3301support.scm",(void*)f_3301},
{"f_3260support.scm",(void*)f_3260},
{"f_3266support.scm",(void*)f_3266},
{"f_3276support.scm",(void*)f_3276},
{"f_3224support.scm",(void*)f_3224},
{"f_3231support.scm",(void*)f_3231},
{"f_3234support.scm",(void*)f_3234},
{"f_3214support.scm",(void*)f_3214},
{"f_3157support.scm",(void*)f_3157},
{"f_3161support.scm",(void*)f_3161},
{"f_3191support.scm",(void*)f_3191},
{"f_3105support.scm",(void*)f_3105},
{"f_3109support.scm",(void*)f_3109},
{"f_3136support.scm",(void*)f_3136},
{"f_3059support.scm",(void*)f_3059},
{"f_3063support.scm",(void*)f_3063},
{"f_3085support.scm",(void*)f_3085},
{"f_3041support.scm",(void*)f_3041},
{"f_3045support.scm",(void*)f_3045},
{"f_3053support.scm",(void*)f_3053},
{"f_3023support.scm",(void*)f_3023},
{"f_3027support.scm",(void*)f_3027},
{"f_2962support.scm",(void*)f_2962},
{"f_2999support.scm",(void*)f_2999},
{"f_3003support.scm",(void*)f_3003},
{"f_3006support.scm",(void*)f_3006},
{"f_2966support.scm",(void*)f_2966},
{"f_2984support.scm",(void*)f_2984},
{"f_2988support.scm",(void*)f_2988},
{"f_2969support.scm",(void*)f_2969},
{"f_2974support.scm",(void*)f_2974},
{"f_2905support.scm",(void*)f_2905},
{"f_2909support.scm",(void*)f_2909},
{"f_2913support.scm",(void*)f_2913},
{"f_2902support.scm",(void*)f_2902},
{"f_2799support.scm",(void*)f_2799},
{"f_2808support.scm",(void*)f_2808},
{"f_2839support.scm",(void*)f_2839},
{"f_2889support.scm",(void*)f_2889},
{"f_2895support.scm",(void*)f_2895},
{"f_2845support.scm",(void*)f_2845},
{"f_2873support.scm",(void*)f_2873},
{"f_2887support.scm",(void*)f_2887},
{"f_2879support.scm",(void*)f_2879},
{"f_2849support.scm",(void*)f_2849},
{"f_2814support.scm",(void*)f_2814},
{"f_2820support.scm",(void*)f_2820},
{"f_2831support.scm",(void*)f_2831},
{"f_2828support.scm",(void*)f_2828},
{"f_2806support.scm",(void*)f_2806},
{"f_2424support.scm",(void*)f_2424},
{"f_2788support.scm",(void*)f_2788},
{"f_2427support.scm",(void*)f_2427},
{"f_2632support.scm",(void*)f_2632},
{"f_2641support.scm",(void*)f_2641},
{"f_2742support.scm",(void*)f_2742},
{"f_2738support.scm",(void*)f_2738},
{"f_2688support.scm",(void*)f_2688},
{"f_2711support.scm",(void*)f_2711},
{"f_2707support.scm",(void*)f_2707},
{"f_2651support.scm",(void*)f_2651},
{"f_2654support.scm",(void*)f_2654},
{"f_2674support.scm",(void*)f_2674},
{"f_2682support.scm",(void*)f_2682},
{"f_2668support.scm",(void*)f_2668},
{"f_2672support.scm",(void*)f_2672},
{"f_2581support.scm",(void*)f_2581},
{"f_2601support.scm",(void*)f_2601},
{"f_2593support.scm",(void*)f_2593},
{"f_2597support.scm",(void*)f_2597},
{"f_2429support.scm",(void*)f_2429},
{"f_2439support.scm",(void*)f_2439},
{"f_2448support.scm",(void*)f_2448},
{"f_2472support.scm",(void*)f_2472},
{"f_2479support.scm",(void*)f_2479},
{"f_2459support.scm",(void*)f_2459},
{"f_2341support.scm",(void*)f_2341},
{"f_2347support.scm",(void*)f_2347},
{"f_2412support.scm",(void*)f_2412},
{"f_2375support.scm",(void*)f_2375},
{"f_2405support.scm",(void*)f_2405},
{"f_2393support.scm",(void*)f_2393},
{"f_2281support.scm",(void*)f_2281},
{"f_2297support.scm",(void*)f_2297},
{"f_2339support.scm",(void*)f_2339},
{"f_2303support.scm",(void*)f_2303},
{"f_2318support.scm",(void*)f_2318},
{"f_2235support.scm",(void*)f_2235},
{"f_2279support.scm",(void*)f_2279},
{"f_2239support.scm",(void*)f_2239},
{"f_2205support.scm",(void*)f_2205},
{"f_2159support.scm",(void*)f_2159},
{"f_2128support.scm",(void*)f_2128},
{"f_2134support.scm",(void*)f_2134},
{"f_2149support.scm",(void*)f_2149},
{"f_2065support.scm",(void*)f_2065},
{"f_2079support.scm",(void*)f_2079},
{"f_2081support.scm",(void*)f_2081},
{"f_2110support.scm",(void*)f_2110},
{"f_2089support.scm",(void*)f_2089},
{"f_2053support.scm",(void*)f_2053},
{"f_2006support.scm",(void*)f_2006},
{"f_2022support.scm",(void*)f_2022},
{"f_2034support.scm",(void*)f_2034},
{"f_1999support.scm",(void*)f_1999},
{"f_1992support.scm",(void*)f_1992},
{"f_1936support.scm",(void*)f_1936},
{"f_1990support.scm",(void*)f_1990},
{"f_1940support.scm",(void*)f_1940},
{"f_1963support.scm",(void*)f_1963},
{"f_1842support.scm",(void*)f_1842},
{"f_1858support.scm",(void*)f_1858},
{"f_1860support.scm",(void*)f_1860},
{"f_1882support.scm",(void*)f_1882},
{"f_1921support.scm",(void*)f_1921},
{"f_1889support.scm",(void*)f_1889},
{"f_1905support.scm",(void*)f_1905},
{"f_1893support.scm",(void*)f_1893},
{"f_1897support.scm",(void*)f_1897},
{"f_1854support.scm",(void*)f_1854},
{"f_1798support.scm",(void*)f_1798},
{"f_1804support.scm",(void*)f_1804},
{"f_1828support.scm",(void*)f_1828},
{"f_1773support.scm",(void*)f_1773},
{"f_1796support.scm",(void*)f_1796},
{"f_1752support.scm",(void*)f_1752},
{"f_1716support.scm",(void*)f_1716},
{"f_1722support.scm",(void*)f_1722},
{"f_1648support.scm",(void*)f_1648},
{"f_1672support.scm",(void*)f_1672},
{"f_1651support.scm",(void*)f_1651},
{"f_1659support.scm",(void*)f_1659},
{"f_1663support.scm",(void*)f_1663},
{"f_1605support.scm",(void*)f_1605},
{"f_1611support.scm",(void*)f_1611},
{"f_1634support.scm",(void*)f_1634},
{"f_1638support.scm",(void*)f_1638},
{"f_1602support.scm",(void*)f_1602},
{"f_1577support.scm",(void*)f_1577},
{"f_1581support.scm",(void*)f_1581},
{"f_1584support.scm",(void*)f_1584},
{"f_1595support.scm",(void*)f_1595},
{"f_1587support.scm",(void*)f_1587},
{"f_1590support.scm",(void*)f_1590},
{"f_1558support.scm",(void*)f_1558},
{"f_1562support.scm",(void*)f_1562},
{"f_1575support.scm",(void*)f_1575},
{"f_1565support.scm",(void*)f_1565},
{"f_1568support.scm",(void*)f_1568},
{"f_1529support.scm",(void*)f_1529},
{"f_1536support.scm",(void*)f_1536},
{"f_1539support.scm",(void*)f_1539},
{"f_1549support.scm",(void*)f_1549},
{"f_1542support.scm",(void*)f_1542},
{"f_1489support.scm",(void*)f_1489},
{"f_1499support.scm",(void*)f_1499},
{"f_1514support.scm",(void*)f_1514},
{"f_1519support.scm",(void*)f_1519},
{"f_1527support.scm",(void*)f_1527},
{"f_1502support.scm",(void*)f_1502},
{"f_1505support.scm",(void*)f_1505},
{"f_1508support.scm",(void*)f_1508},
{"f_1462support.scm",(void*)f_1462},
{"f_1476support.scm",(void*)f_1476},
{"f_1457support.scm",(void*)f_1457},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
