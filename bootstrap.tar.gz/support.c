/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-30 14:36
   Version 4.0.0x5 - SVN rev. 12341
   macosx-unix-gnu-ppc [ dload ptables applyhook ]
   compiled 2008-11-03 on apfel (Darwin)
   command line: support.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[509];
static double C_possibly_force_alignment;


/* from k4422 */
static C_word C_fcall stub331(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub331(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4415 */
static C_word C_fcall stub326(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub326(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11863)
static void C_ccall f_11863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11877)
static void C_ccall f_11877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11881)
static void C_ccall f_11881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11892)
static void C_ccall f_11892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11904)
static void C_ccall f_11904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11912)
static void C_ccall f_11912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11916)
static void C_ccall f_11916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11875)
static void C_ccall f_11875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11866)
static void C_ccall f_11866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11869)
static void C_ccall f_11869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11850)
static void C_ccall f_11850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11855)
static void C_ccall f_11855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11839)
static void C_ccall f_11839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11844)
static void C_ccall f_11844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11833)
static void C_ccall f_11833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11805)
static void C_ccall f_11805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11805)
static void C_ccall f_11805r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11809)
static void C_ccall f_11809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11784)
static void C_ccall f_11784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11788)
static void C_ccall f_11788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11751)
static void C_ccall f_11751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11756)
static void C_ccall f_11756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11756)
static void C_ccall f_11756r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11760)
static void C_ccall f_11760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11718)
static void C_ccall f_11718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11723)
static void C_ccall f_11723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11723)
static void C_ccall f_11723r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11727)
static void C_ccall f_11727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11694)
static void C_ccall f_11694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11625)
static void C_ccall f_11625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11629)
static void C_ccall f_11629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11634)
static void C_fcall f_11634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11638)
static void C_ccall f_11638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11689)
static void C_ccall f_11689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11668)
static void C_ccall f_11668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11680)
static void C_ccall f_11680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11683)
static void C_ccall f_11683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11656)
static void C_ccall f_11656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11592)
static void C_ccall f_11592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11602)
static void C_ccall f_11602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11605)
static void C_ccall f_11605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11490)
static void C_ccall f_11490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11499)
static void C_fcall f_11499(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11586)
static void C_ccall f_11586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11503)
static void C_ccall f_11503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11581)
static void C_ccall f_11581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11506)
static void C_ccall f_11506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11576)
static void C_ccall f_11576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11509)
static void C_ccall f_11509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11512)
static void C_ccall f_11512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11518)
static void C_ccall f_11518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11571)
static void C_ccall f_11571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11521)
static void C_ccall f_11521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11536)
static void C_ccall f_11536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11544)
static void C_fcall f_11544(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11554)
static void C_ccall f_11554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11539)
static void C_ccall f_11539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11527)
static void C_ccall f_11527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11494)
static void C_ccall f_11494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11484)
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11438)
static void C_ccall f_11438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11457)
static void C_ccall f_11457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11468)
static void C_ccall f_11468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11464)
static void C_ccall f_11464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11426)
static void C_ccall f_11426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11432)
static void C_ccall f_11432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11414)
static void C_ccall f_11414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11418)
static void C_ccall f_11418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11335)
static void C_ccall f_11335(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11335)
static void C_ccall f_11335r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11354)
static void C_ccall f_11354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11379)
static void C_ccall f_11379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11383)
static void C_ccall f_11383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11385)
static void C_fcall f_11385(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11405)
static void C_ccall f_11405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11409)
static void C_ccall f_11409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11338)
static void C_fcall f_11338(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11342)
static void C_ccall f_11342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11348)
static void C_ccall f_11348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11329)
static void C_ccall f_11329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11285)
static void C_ccall f_11285(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11285)
static void C_ccall f_11285r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11297)
static void C_ccall f_11297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11301)
static void C_ccall f_11301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11293)
static void C_ccall f_11293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11276)
static void C_ccall f_11276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11270)
static void C_ccall f_11270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11264)
static void C_ccall f_11264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11252)
static void C_ccall f_11252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11256)
static void C_ccall f_11256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11259)
static void C_ccall f_11259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_ccall f_11214(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11214)
static void C_ccall f_11214r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11218)
static void C_ccall f_11218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11221)
static void C_ccall f_11221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11228)
static void C_ccall f_11228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11172)
static void C_ccall f_11172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11181)
static void C_fcall f_11181(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11143)
static void C_ccall f_11143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11153)
static void C_fcall f_11153(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10946)
static void C_ccall f_10946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11125)
static void C_ccall f_11125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11074)
static void C_ccall f_11074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11119)
static void C_ccall f_11119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11123)
static void C_ccall f_11123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11077)
static void C_ccall f_11077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11086)
static void C_ccall f_11086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11080)
static void C_ccall f_11080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11037)
static void C_fcall f_11037(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11041)
static void C_ccall f_11041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11050)
static void C_ccall f_11050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11054)
static void C_ccall f_11054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11044)
static void C_ccall f_11044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11002)
static void C_fcall f_11002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11008)
static void C_fcall f_11008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11035)
static void C_ccall f_11035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11021)
static void C_ccall f_11021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10955)
static void C_fcall f_10955(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10961)
static void C_fcall f_10961(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11000)
static void C_ccall f_11000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10982)
static void C_ccall f_10982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10759)
static void C_ccall f_10759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10941)
static void C_ccall f_10941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10928)
static void C_fcall f_10928(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10934)
static void C_ccall f_10934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10762)
static void C_fcall f_10762(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10922)
static void C_ccall f_10922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10766)
static void C_ccall f_10766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10917)
static void C_ccall f_10917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10769)
static void C_ccall f_10769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10912)
static void C_ccall f_10912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10772)
static void C_ccall f_10772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10781)
static void C_fcall f_10781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10875)
static void C_ccall f_10875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10845)
static void C_ccall f_10845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10856)
static void C_ccall f_10856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10836)
static void C_ccall f_10836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10822)
static void C_fcall f_10822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10800)
static void C_ccall f_10800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10806)
static void C_ccall f_10806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10810)
static void C_ccall f_10810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10666)
static void C_ccall f_10666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10672)
static void C_ccall f_10672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10753)
static void C_ccall f_10753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10748)
static void C_ccall f_10748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10679)
static void C_ccall f_10679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10732)
static void C_fcall f_10732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10719)
static void C_ccall f_10719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10718)
static void C_ccall f_10718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10700)
static void C_fcall f_10700(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10694)
static void C_fcall f_10694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10374)
static void C_ccall f_10374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10570)
static void C_fcall f_10570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10591)
static void C_fcall f_10591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10064)
static void C_ccall f_10064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10076)
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10086)
static void C_fcall f_10086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10104)
static void C_ccall f_10104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10138)
static void C_fcall f_10138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10067)
static void C_fcall f_10067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9745)
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9751)
static void C_ccall f_9751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9761)
static void C_fcall f_9761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9770)
static void C_fcall f_9770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9782)
static void C_fcall f_9782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9794)
static void C_fcall f_9794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9834)
static void C_fcall f_9834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9705)
static void C_ccall f_9705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9739)
static void C_ccall f_9739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9711)
static void C_ccall f_9711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9674)
static void C_ccall f_9674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9687)
static void C_ccall f_9687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9678)
static void C_fcall f_9678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9643)
static void C_ccall f_9643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_fcall f_9647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8596)
static void C_ccall f_8596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9637)
static void C_ccall f_9637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8608)
static void C_fcall f_8608(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8637)
static void C_fcall f_8637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8656)
static void C_fcall f_8656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8675)
static void C_fcall f_8675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_fcall f_8745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_fcall f_8764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static void C_fcall f_8846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8885)
static void C_fcall f_8885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8904)
static void C_fcall f_8904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8923)
static void C_fcall f_8923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_fcall f_9003(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9088)
static void C_fcall f_9088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9197)
static void C_fcall f_9197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9267)
static void C_ccall f_9267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9200)
static void C_ccall f_9200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_fcall f_9037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8926)
static void C_ccall f_8926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8767)
static void C_ccall f_8767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8798)
static void C_fcall f_8798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8678)
static void C_ccall f_8678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8709)
static void C_fcall f_8709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_ccall f_8560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8585)
static void C_ccall f_8585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8567)
static void C_ccall f_8567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8533)
static void C_ccall f_8533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8543)
static void C_ccall f_8543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8549)
static void C_ccall f_8549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8527)
static void C_ccall f_8527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_ccall f_8435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8444)
static void C_ccall f_8444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8450)
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8497)
static void C_ccall f_8497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8439)
static void C_ccall f_8439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8414)
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8396)
static void C_fcall f_8396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8399)
static void C_ccall f_8399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8285)
static void C_ccall f_8285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8366)
static void C_ccall f_8366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8298)
static void C_ccall f_8298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8338)
static void C_ccall f_8338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_ccall f_8329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8328)
static void C_ccall f_8328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8160)
static void C_ccall f_8160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8166)
static void C_ccall f_8166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8255)
static void C_ccall f_8255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8250)
static void C_ccall f_8250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8173)
static void C_ccall f_8173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_fcall f_8182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8208)
static void C_ccall f_8208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7940)
static void C_ccall f_7940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8144)
static void C_ccall f_8144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8149)
static void C_ccall f_8149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8148)
static void C_ccall f_8148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8015)
static void C_fcall f_8015(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8044)
static void C_ccall f_8044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8050)
static void C_fcall f_8050(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7972)
static void C_fcall f_7972(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7994)
static void C_ccall f_7994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_fcall f_7943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7967)
static void C_ccall f_7967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_fcall f_7883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7855)
static void C_ccall f_7855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_fcall f_7743(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7761)
static void C_ccall f_7761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7773)
static void C_ccall f_7773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_fcall f_7776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7673)
static void C_ccall f_7673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7642)
static void C_ccall f_7642(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7659)
static void C_ccall f_7659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7630)
static void C_ccall f_7630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7620)
static void C_ccall f_7620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7615)
static void C_ccall f_7615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7611)
static void C_ccall f_7611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7529)
static C_word C_fcall f_7529(C_word t0,C_word t1);
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7480)
static void C_fcall f_7480(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7498)
static void C_ccall f_7498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_fcall f_7265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7465)
static void C_ccall f_7465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7269)
static void C_ccall f_7269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7384)
static void C_ccall f_7384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7259)
static void C_fcall f_7259(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7215)
static void C_ccall f_7215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7170)
static void C_ccall f_7170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7092)
static void C_fcall f_7092(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7075)
static void C_ccall f_7075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_fcall f_6778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_fcall f_7012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_fcall f_6950(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6806)
static void C_ccall f_6806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6586)
static void C_fcall f_6586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_fcall f_6664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6623)
static void C_ccall f_6623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6549)
static void C_ccall f_6549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6411)
static void C_fcall f_6411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6245)
static void C_fcall f_6245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6248)
static void C_ccall f_6248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_fcall f_6242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6138)
static void C_ccall f_6138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5731)
static void C_fcall f_5731(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5757)
static void C_fcall f_5757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_fcall f_5830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_fcall f_5621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_fcall f_5652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5683)
static void C_fcall f_5683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5527)
static void C_fcall f_5527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_fcall f_5495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5219)
static void C_ccall f_5219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5191)
static void C_ccall f_5191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4787)
static void C_fcall f_4787(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_fcall f_4815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4554)
static void C_fcall f_4554(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_fcall f_4501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_fcall f_4509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_fcall f_4454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_fcall f_4280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4302)
static void C_fcall f_4302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_fcall f_4309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4224)
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4142)
static C_word C_fcall f_4142(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4092)
static void C_fcall f_4092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4071)
static void C_fcall f_4071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4031)
static void C_fcall f_4031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3956)
static void C_fcall f_3956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11634)
static void C_fcall trf_11634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11634(t0,t1);}

C_noret_decl(trf_11499)
static void C_fcall trf_11499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11499(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11499(t0,t1,t2,t3);}

C_noret_decl(trf_11544)
static void C_fcall trf_11544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11544(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11544(t0,t1,t2);}

C_noret_decl(trf_11385)
static void C_fcall trf_11385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11385(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11385(t0,t1,t2,t3);}

C_noret_decl(trf_11338)
static void C_fcall trf_11338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11338(t0,t1);}

C_noret_decl(trf_11181)
static void C_fcall trf_11181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11181(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11181(t0,t1,t2);}

C_noret_decl(trf_11153)
static void C_fcall trf_11153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11153(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11153(t0,t1);}

C_noret_decl(trf_11037)
static void C_fcall trf_11037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11037(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11037(t0,t1,t2,t3);}

C_noret_decl(trf_11002)
static void C_fcall trf_11002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11002(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11002(t0,t1,t2);}

C_noret_decl(trf_11008)
static void C_fcall trf_11008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11008(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11008(t0,t1,t2);}

C_noret_decl(trf_10955)
static void C_fcall trf_10955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10955(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10955(t0,t1,t2,t3);}

C_noret_decl(trf_10961)
static void C_fcall trf_10961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10961(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10961(t0,t1,t2);}

C_noret_decl(trf_10928)
static void C_fcall trf_10928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10928(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10928(t0,t1,t2,t3);}

C_noret_decl(trf_10762)
static void C_fcall trf_10762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10762(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10762(t0,t1,t2,t3);}

C_noret_decl(trf_10781)
static void C_fcall trf_10781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10781(t0,t1);}

C_noret_decl(trf_10822)
static void C_fcall trf_10822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10822(t0,t1);}

C_noret_decl(trf_10732)
static void C_fcall trf_10732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10732(t0,t1);}

C_noret_decl(trf_10700)
static void C_fcall trf_10700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10700(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10700(t0,t1);}

C_noret_decl(trf_10694)
static void C_fcall trf_10694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10694(t0,t1);}

C_noret_decl(trf_10570)
static void C_fcall trf_10570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10570(t0,t1);}

C_noret_decl(trf_10591)
static void C_fcall trf_10591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10591(t0,t1);}

C_noret_decl(trf_10086)
static void C_fcall trf_10086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10086(t0,t1);}

C_noret_decl(trf_10138)
static void C_fcall trf_10138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10138(t0,t1);}

C_noret_decl(trf_10067)
static void C_fcall trf_10067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10067(t0,t1);}

C_noret_decl(trf_9761)
static void C_fcall trf_9761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9761(t0,t1);}

C_noret_decl(trf_9770)
static void C_fcall trf_9770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9770(t0,t1);}

C_noret_decl(trf_9782)
static void C_fcall trf_9782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9782(t0,t1);}

C_noret_decl(trf_9794)
static void C_fcall trf_9794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9794(t0,t1);}

C_noret_decl(trf_9834)
static void C_fcall trf_9834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9834(t0,t1);}

C_noret_decl(trf_9678)
static void C_fcall trf_9678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9678(t0,t1);}

C_noret_decl(trf_9647)
static void C_fcall trf_9647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9647(t0,t1);}

C_noret_decl(trf_8608)
static void C_fcall trf_8608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8608(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8608(t0,t1,t2);}

C_noret_decl(trf_8637)
static void C_fcall trf_8637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8637(t0,t1);}

C_noret_decl(trf_8656)
static void C_fcall trf_8656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8656(t0,t1);}

C_noret_decl(trf_8675)
static void C_fcall trf_8675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8675(t0,t1);}

C_noret_decl(trf_8745)
static void C_fcall trf_8745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8745(t0,t1);}

C_noret_decl(trf_8764)
static void C_fcall trf_8764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8764(t0,t1);}

C_noret_decl(trf_8846)
static void C_fcall trf_8846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8846(t0,t1);}

C_noret_decl(trf_8885)
static void C_fcall trf_8885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8885(t0,t1);}

C_noret_decl(trf_8904)
static void C_fcall trf_8904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8904(t0,t1);}

C_noret_decl(trf_8923)
static void C_fcall trf_8923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8923(t0,t1);}

C_noret_decl(trf_9003)
static void C_fcall trf_9003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9003(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9003(t0,t1);}

C_noret_decl(trf_9088)
static void C_fcall trf_9088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9088(t0,t1);}

C_noret_decl(trf_9197)
static void C_fcall trf_9197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9197(t0,t1);}

C_noret_decl(trf_9037)
static void C_fcall trf_9037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9037(t0,t1);}

C_noret_decl(trf_8798)
static void C_fcall trf_8798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8798(t0,t1);}

C_noret_decl(trf_8709)
static void C_fcall trf_8709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8709(t0,t1);}

C_noret_decl(trf_8396)
static void C_fcall trf_8396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8396(t0,t1);}

C_noret_decl(trf_8182)
static void C_fcall trf_8182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8182(t0,t1);}

C_noret_decl(trf_8015)
static void C_fcall trf_8015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8015(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8015(t0,t1,t2,t3);}

C_noret_decl(trf_8050)
static void C_fcall trf_8050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8050(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8050(t0,t1,t2,t3);}

C_noret_decl(trf_7972)
static void C_fcall trf_7972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7972(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7972(t0,t1,t2,t3);}

C_noret_decl(trf_7943)
static void C_fcall trf_7943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7943(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7943(t0,t1,t2,t3);}

C_noret_decl(trf_7883)
static void C_fcall trf_7883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7883(t0,t1);}

C_noret_decl(trf_7743)
static void C_fcall trf_7743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7743(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7743(t0,t1);}

C_noret_decl(trf_7776)
static void C_fcall trf_7776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7776(t0,t1);}

C_noret_decl(trf_7480)
static void C_fcall trf_7480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7480(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7480(t0,t1,t2);}

C_noret_decl(trf_7265)
static void C_fcall trf_7265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7265(t0,t1,t2,t3);}

C_noret_decl(trf_7259)
static void C_fcall trf_7259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7259(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7259(t0,t1,t2);}

C_noret_decl(trf_7092)
static void C_fcall trf_7092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7092(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7092(t0,t1,t2);}

C_noret_decl(trf_6778)
static void C_fcall trf_6778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6778(t0,t1);}

C_noret_decl(trf_7012)
static void C_fcall trf_7012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7012(t0,t1);}

C_noret_decl(trf_6950)
static void C_fcall trf_6950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6950(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6950(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6586)
static void C_fcall trf_6586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6586(t0,t1);}

C_noret_decl(trf_6664)
static void C_fcall trf_6664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6664(t0,t1);}

C_noret_decl(trf_6411)
static void C_fcall trf_6411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6411(t0,t1);}

C_noret_decl(trf_6245)
static void C_fcall trf_6245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6245(t0,t1);}

C_noret_decl(trf_6242)
static void C_fcall trf_6242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6242(t0,t1);}

C_noret_decl(trf_5568)
static void C_fcall trf_5568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5568(t0,t1);}

C_noret_decl(trf_5731)
static void C_fcall trf_5731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5731(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5731(t0,t1,t2);}

C_noret_decl(trf_5757)
static void C_fcall trf_5757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5757(t0,t1);}

C_noret_decl(trf_5830)
static void C_fcall trf_5830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5830(t0,t1);}

C_noret_decl(trf_5621)
static void C_fcall trf_5621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5621(t0,t1);}

C_noret_decl(trf_5652)
static void C_fcall trf_5652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5652(t0,t1);}

C_noret_decl(trf_5683)
static void C_fcall trf_5683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5683(t0,t1);}

C_noret_decl(trf_5527)
static void C_fcall trf_5527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5527(t0,t1,t2);}

C_noret_decl(trf_5495)
static void C_fcall trf_5495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5495(t0,t1);}

C_noret_decl(trf_4787)
static void C_fcall trf_4787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4787(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4787(t0,t1,t2);}

C_noret_decl(trf_4815)
static void C_fcall trf_4815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4815(t0,t1);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4679(t0,t1);}

C_noret_decl(trf_4554)
static void C_fcall trf_4554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4554(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4554(t0,t1,t2,t3);}

C_noret_decl(trf_4501)
static void C_fcall trf_4501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4501(t0,t1,t2);}

C_noret_decl(trf_4509)
static void C_fcall trf_4509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4509(t0,t1);}

C_noret_decl(trf_4454)
static void C_fcall trf_4454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4454(t0,t1);}

C_noret_decl(trf_4280)
static void C_fcall trf_4280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4280(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4280(t0,t1,t2);}

C_noret_decl(trf_4302)
static void C_fcall trf_4302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4302(t0,t1);}

C_noret_decl(trf_4309)
static void C_fcall trf_4309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4309(t0,t1);}

C_noret_decl(trf_4224)
static void C_fcall trf_4224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4224(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4224(t0,t1,t2,t3);}

C_noret_decl(trf_4092)
static void C_fcall trf_4092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4092(t0,t1,t2,t3);}

C_noret_decl(trf_4071)
static void C_fcall trf_4071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4071(t0,t1);}

C_noret_decl(trf_4031)
static void C_fcall trf_4031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4031(t0,t1,t2);}

C_noret_decl(trf_3956)
static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3956(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5180)){
C_save(t1);
C_rereclaim2(5180*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,509);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],12,"flush-output");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],6,"printf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[15]=C_h_intern(&lf[15],5,"force");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[20]=C_h_intern(&lf[20],25,"\010compilercompiler-warning");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],20,"\003syswarnings-enabled");
lf[25]=C_h_intern(&lf[25],4,"quit");
lf[26]=C_h_intern(&lf[26],4,"exit");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[28]=C_h_intern(&lf[28],21,"\003syssyntax-error-hook");
lf[29]=C_h_intern(&lf[29],16,"print-call-chain");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[34]=C_h_intern(&lf[34],12,"syntax-error");
lf[35]=C_h_intern(&lf[35],31,"\010compileremit-syntax-trace-info");
lf[36]=C_h_intern(&lf[36],9,"map-llist");
lf[37]=C_h_intern(&lf[37],24,"\010compilercheck-signature");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[39]=C_h_intern(&lf[39],18,"\010compilerreal-name");
lf[40]=C_h_intern(&lf[40],13,"\010compilerposq");
lf[41]=C_h_intern(&lf[41],18,"\010compilerstringify");
lf[42]=C_h_intern(&lf[42],14,"symbol->string");
lf[43]=C_h_intern(&lf[43],7,"sprintf");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[45]=C_h_intern(&lf[45],18,"\010compilersymbolify");
lf[46]=C_h_intern(&lf[46],14,"string->symbol");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[48]=C_h_intern(&lf[48],26,"\010compilerbuild-lambda-list");
lf[49]=C_h_intern(&lf[49],29,"\010compilerstring->c-identifier");
lf[50]=C_h_intern(&lf[50],24,"\003sysstring->c-identifier");
lf[51]=C_h_intern(&lf[51],21,"\010compilerc-ify-string");
lf[52]=C_h_intern(&lf[52],16,"\003syslist->string");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[54]=C_h_intern(&lf[54],6,"append");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[56]=C_h_intern(&lf[56],16,"\003sysstring->list");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[60]=C_h_intern(&lf[60],28,"\010compilervalid-c-identifier\077");
lf[61]=C_h_intern(&lf[61],3,"any");
lf[62]=C_h_intern(&lf[62],8,"->string");
lf[63]=C_h_intern(&lf[63],14,"\010compilerwords");
lf[64]=C_h_intern(&lf[64],21,"\010compilerwords->bytes");
lf[65]=C_h_intern(&lf[65],34,"\010compilercheck-and-open-input-file");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[67]=C_h_intern(&lf[67],18,"current-input-port");
lf[68]=C_h_intern(&lf[68],15,"open-input-file");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[71]=C_h_intern(&lf[71],12,"file-exists\077");
lf[72]=C_h_intern(&lf[72],33,"\010compilerclose-checked-input-file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[74]=C_h_intern(&lf[74],16,"close-input-port");
lf[75]=C_h_intern(&lf[75],19,"\010compilerfold-inner");
lf[76]=C_h_intern(&lf[76],7,"reverse");
lf[77]=C_h_intern(&lf[77],28,"\010compilerfollow-without-loop");
lf[78]=C_h_intern(&lf[78],21,"\010compilersort-symbols");
lf[79]=C_h_intern(&lf[79],8,"string<\077");
lf[80]=C_h_intern(&lf[80],4,"sort");
lf[81]=C_h_intern(&lf[81],18,"\010compilerconstant\077");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],29,"\010compilercollapsable-literal\077");
lf[84]=C_h_intern(&lf[84],19,"\010compilerimmediate\077");
lf[85]=C_h_intern(&lf[85],20,"\010compilerbig-fixnum\077");
lf[86]=C_h_intern(&lf[86],23,"\010compilerbasic-literal\077");
lf[87]=C_h_intern(&lf[87],5,"every");
lf[88]=C_h_intern(&lf[88],12,"vector->list");
lf[89]=C_h_intern(&lf[89],32,"\010compilercanonicalize-begin-body");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_h_intern(&lf[92],3,"let");
lf[93]=C_h_intern(&lf[93],6,"gensym");
lf[94]=C_h_intern(&lf[94],1,"t");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[96]=C_h_intern(&lf[96],21,"\010compilerstring->expr");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[99]=C_h_intern(&lf[99],5,"begin");
lf[100]=C_h_intern(&lf[100],10,"\003sysappend");
lf[101]=C_h_intern(&lf[101],4,"read");
lf[102]=C_h_intern(&lf[102],6,"unfold");
lf[103]=C_h_intern(&lf[103],11,"eof-object\077");
lf[104]=C_h_intern(&lf[104],6,"values");
lf[105]=C_h_intern(&lf[105],22,"with-input-from-string");
lf[106]=C_h_intern(&lf[106],22,"with-exception-handler");
lf[107]=C_h_intern(&lf[107],30,"call-with-current-continuation");
lf[108]=C_h_intern(&lf[108],30,"\010compilerdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],25,"\003sysdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],37,"\010compilerprocess-lambda-documentation");
lf[111]=C_h_intern(&lf[111],30,"\010compilerexpand-profile-lambda");
lf[112]=C_h_intern(&lf[112],29,"\010compilerprofile-lambda-index");
lf[113]=C_h_intern(&lf[113],28,"\010compilerprofile-lambda-list");
lf[114]=C_h_intern(&lf[114],33,"\010compilerprofile-info-vector-name");
lf[115]=C_h_intern(&lf[115],17,"\003sysprofile-entry");
lf[116]=C_h_intern(&lf[116],6,"lambda");
lf[117]=C_h_intern(&lf[117],5,"apply");
lf[118]=C_h_intern(&lf[118],16,"\003sysprofile-exit");
lf[119]=C_h_intern(&lf[119],16,"\003sysdynamic-wind");
lf[120]=C_h_intern(&lf[120],10,"alist-cons");
lf[121]=C_h_intern(&lf[121],37,"\010compilerinitialize-analysis-database");
lf[122]=C_h_intern(&lf[122],8,"\003sysput!");
lf[123]=C_h_intern(&lf[123],9,"\003syserror");
lf[124]=C_h_intern(&lf[124],18,"\010compilerintrinsic");
lf[125]=C_h_intern(&lf[125],8,"internal");
lf[126]=C_h_intern(&lf[126],26,"\010compilerinternal-bindings");
lf[127]=C_h_intern(&lf[127],8,"extended");
lf[128]=C_h_intern(&lf[128],17,"extended-bindings");
lf[129]=C_h_intern(&lf[129],26,"\010compilerfoldable-bindings");
lf[130]=C_h_intern(&lf[130],17,"\010compilerfoldable");
lf[131]=C_h_intern(&lf[131],8,"standard");
lf[132]=C_h_intern(&lf[132],17,"standard-bindings");
lf[133]=C_h_intern(&lf[133],12,"\010compilerget");
lf[134]=C_h_intern(&lf[134],18,"\003syshash-table-ref");
lf[135]=C_h_intern(&lf[135],16,"\010compilerget-all");
lf[136]=C_h_intern(&lf[136],10,"filter-map");
lf[137]=C_h_intern(&lf[137],13,"\010compilerput!");
lf[138]=C_h_intern(&lf[138],19,"\003syshash-table-set!");
lf[139]=C_h_intern(&lf[139],17,"\010compilercollect!");
lf[140]=C_h_intern(&lf[140],15,"\010compilercount!");
lf[141]=C_h_intern(&lf[141],17,"\010compilerget-line");
lf[142]=C_h_intern(&lf[142],24,"\003sysline-number-database");
lf[143]=C_h_intern(&lf[143],19,"\010compilerget-line-2");
lf[144]=C_h_intern(&lf[144],30,"\010compilerfind-lambda-container");
lf[145]=C_h_intern(&lf[145],12,"contained-in");
lf[146]=C_h_intern(&lf[146],37,"\010compilerdisplay-line-number-database");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[148]=C_h_intern(&lf[148],7,"\003sysmap");
lf[149]=C_h_intern(&lf[149],3,"cdr");
lf[150]=C_h_intern(&lf[150],23,"\003syshash-table-for-each");
lf[151]=C_h_intern(&lf[151],34,"\010compilerdisplay-analysis-database");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\010\011lval=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[157]=C_h_intern(&lf[157],7,"unknown");
lf[158]=C_h_intern(&lf[158],8,"captured");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\011undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003"
"uud\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[161]=C_h_intern(&lf[161],4,"caar");
lf[162]=C_h_intern(&lf[162],5,"value");
lf[163]=C_h_intern(&lf[163],4,"cdar");
lf[164]=C_h_intern(&lf[164],11,"local-value");
lf[165]=C_h_intern(&lf[165],15,"potential-value");
lf[166]=C_h_intern(&lf[166],10,"replacable");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[168]=C_h_intern(&lf[168],10,"references");
lf[169]=C_h_intern(&lf[169],10,"call-sites");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[171]=C_h_intern(&lf[171],4,"home");
lf[172]=C_h_intern(&lf[172],8,"contains");
lf[173]=C_h_intern(&lf[173],8,"use-expr");
lf[174]=C_h_intern(&lf[174],12,"closure-size");
lf[175]=C_h_intern(&lf[175],14,"rest-parameter");
lf[176]=C_h_intern(&lf[176],16,"o-r/access-count");
lf[177]=C_h_intern(&lf[177],18,"captured-variables");
lf[178]=C_h_intern(&lf[178],13,"explicit-rest");
lf[179]=C_h_intern(&lf[179],8,"assigned");
lf[180]=C_h_intern(&lf[180],5,"boxed");
lf[181]=C_h_intern(&lf[181],6,"global");
lf[182]=C_h_intern(&lf[182],12,"contractable");
lf[183]=C_h_intern(&lf[183],16,"standard-binding");
lf[184]=C_h_intern(&lf[184],16,"assigned-locally");
lf[185]=C_h_intern(&lf[185],11,"collapsable");
lf[186]=C_h_intern(&lf[186],9,"removable");
lf[187]=C_h_intern(&lf[187],9,"undefined");
lf[188]=C_h_intern(&lf[188],9,"replacing");
lf[189]=C_h_intern(&lf[189],6,"unused");
lf[190]=C_h_intern(&lf[190],6,"simple");
lf[191]=C_h_intern(&lf[191],9,"inlinable");
lf[192]=C_h_intern(&lf[192],13,"inline-export");
lf[193]=C_h_intern(&lf[193],21,"has-unused-parameters");
lf[194]=C_h_intern(&lf[194],16,"extended-binding");
lf[195]=C_h_intern(&lf[195],12,"customizable");
lf[196]=C_h_intern(&lf[196],8,"constant");
lf[197]=C_h_intern(&lf[197],10,"boxed-rest");
lf[198]=C_h_intern(&lf[198],11,"hidden-refs");
lf[199]=C_h_intern(&lf[199],5,"write");
lf[200]=C_h_intern(&lf[200],34,"\010compilerdefault-standard-bindings");
lf[201]=C_h_intern(&lf[201],34,"\010compilerdefault-extended-bindings");
lf[202]=C_h_intern(&lf[202],9,"make-node");
lf[203]=C_h_intern(&lf[203],4,"node");
lf[204]=C_h_intern(&lf[204],5,"node\077");
lf[205]=C_h_intern(&lf[205],15,"node-class-set!");
lf[206]=C_h_intern(&lf[206],14,"\003sysblock-set!");
lf[207]=C_h_intern(&lf[207],10,"node-class");
lf[208]=C_h_intern(&lf[208],20,"node-parameters-set!");
lf[209]=C_h_intern(&lf[209],15,"node-parameters");
lf[210]=C_h_intern(&lf[210],24,"node-subexpressions-set!");
lf[211]=C_h_intern(&lf[211],19,"node-subexpressions");
lf[212]=C_h_intern(&lf[212],16,"\010compilervarnode");
lf[213]=C_h_intern(&lf[213],13,"\004corevariable");
lf[214]=C_h_intern(&lf[214],14,"\010compilerqnode");
lf[215]=C_h_intern(&lf[215],25,"\010compilerbuild-node-graph");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[217]=C_h_intern(&lf[217],15,"\004coreglobal-ref");
lf[218]=C_h_intern(&lf[218],2,"if");
lf[219]=C_h_intern(&lf[219],14,"\004coreundefined");
lf[220]=C_h_intern(&lf[220],8,"truncate");
lf[221]=C_h_intern(&lf[221],4,"type");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[223]=C_h_intern(&lf[223],6,"fixnum");
lf[224]=C_h_intern(&lf[224],11,"number-type");
lf[225]=C_h_intern(&lf[225],6,"unzip1");
lf[226]=C_h_intern(&lf[226],11,"\004corelambda");
lf[227]=C_h_intern(&lf[227],14,"\004coreprimitive");
lf[228]=C_h_intern(&lf[228],11,"\004coreinline");
lf[229]=C_h_intern(&lf[229],13,"\004corecallunit");
lf[230]=C_h_intern(&lf[230],9,"\004coreproc");
lf[231]=C_h_intern(&lf[231],4,"set!");
lf[232]=C_h_intern(&lf[232],9,"\004coreset!");
lf[233]=C_h_intern(&lf[233],29,"\004coreforeign-callback-wrapper");
lf[234]=C_h_intern(&lf[234],5,"sixth");
lf[235]=C_h_intern(&lf[235],5,"fifth");
lf[236]=C_h_intern(&lf[236],20,"\004coreinline_allocate");
lf[237]=C_h_intern(&lf[237],8,"\004coreapp");
lf[238]=C_h_intern(&lf[238],9,"\004corecall");
lf[239]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[240]=C_h_intern(&lf[240],24,"\010compilersource-filename");
lf[241]=C_h_intern(&lf[241],28,"\003syssymbol->qualified-string");
lf[242]=C_h_intern(&lf[242],7,"\003sysget");
lf[243]=C_h_intern(&lf[243],34,"\010compileralways-bound-to-procedure");
lf[244]=C_h_intern(&lf[244],15,"\004coreinline_ref");
lf[245]=C_h_intern(&lf[245],18,"\004coreinline_update");
lf[246]=C_h_intern(&lf[246],19,"\004coreinline_loc_ref");
lf[247]=C_h_intern(&lf[247],22,"\004coreinline_loc_update");
lf[248]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[249]=C_h_intern(&lf[249],1,"o");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[251]=C_h_intern(&lf[251],30,"\010compilerbuild-expression-tree");
lf[252]=C_h_intern(&lf[252],12,"\004coreclosure");
lf[253]=C_h_intern(&lf[253],4,"last");
lf[254]=C_h_intern(&lf[254],3,"map");
lf[255]=C_h_intern(&lf[255],4,"list");
lf[256]=C_h_intern(&lf[256],7,"butlast");
lf[257]=C_h_intern(&lf[257],5,"cons*");
lf[258]=C_h_intern(&lf[258],9,"\004corebind");
lf[259]=C_h_intern(&lf[259],10,"\004coreunbox");
lf[260]=C_h_intern(&lf[260],8,"\004coreref");
lf[261]=C_h_intern(&lf[261],11,"\004coreupdate");
lf[262]=C_h_intern(&lf[262],13,"\004coreupdate_i");
lf[263]=C_h_intern(&lf[263],8,"\004corebox");
lf[264]=C_h_intern(&lf[264],9,"\004corecond");
lf[265]=C_h_intern(&lf[265],21,"\010compilerfold-boolean");
lf[266]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[267]=C_h_intern(&lf[267],31,"\010compilerinline-lambda-bindings");
lf[268]=C_h_intern(&lf[268],8,"split-at");
lf[269]=C_h_intern(&lf[269],10,"fold-right");
lf[270]=C_h_intern(&lf[270],4,"take");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[272]=C_h_intern(&lf[272],34,"\010compilercopy-node-tree-and-rename");
lf[273]=C_h_intern(&lf[273],9,"alist-ref");
lf[274]=C_h_intern(&lf[274],3,"eq\077");
lf[275]=C_h_intern(&lf[275],1,"f");
lf[276]=C_h_intern(&lf[276],18,"\010compilertree-copy");
lf[277]=C_h_intern(&lf[277],4,"cons");
lf[278]=C_h_intern(&lf[278],19,"\010compilercopy-node!");
lf[279]=C_h_intern(&lf[279],20,"\010compilernode->sexpr");
lf[280]=C_h_intern(&lf[280],20,"\010compilersexpr->node");
lf[281]=C_h_intern(&lf[281],32,"\010compileremit-global-inline-file");
lf[282]=C_h_intern(&lf[282],5,"print");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[284]=C_h_intern(&lf[284],1,"i");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[287]=C_h_intern(&lf[287],2,"pp");
lf[288]=C_h_intern(&lf[288],3,"yes");
lf[289]=C_h_intern(&lf[289],2,"no");
lf[290]=C_h_intern(&lf[290],24,"\010compilerinline-max-size");
lf[291]=C_h_intern(&lf[291],15,"\010compilerinline");
lf[292]=C_h_intern(&lf[292],22,"\010compilerinline-global");
lf[293]=C_h_intern(&lf[293],26,"\010compilervariable-visible\077");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[297]=C_h_intern(&lf[297],15,"chicken-version");
lf[298]=C_h_intern(&lf[298],19,"with-output-to-file");
lf[299]=C_h_intern(&lf[299],25,"\010compilerload-inline-file");
lf[300]=C_h_intern(&lf[300],20,"with-input-from-file");
lf[301]=C_h_intern(&lf[301],19,"\010compilermatch-node");
lf[302]=C_h_intern(&lf[302],1,"a");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[304]=C_h_intern(&lf[304],37,"\010compilerexpression-has-side-effects\077");
lf[305]=C_h_intern(&lf[305],24,"foreign-callback-stub-id");
lf[306]=C_h_intern(&lf[306],4,"find");
lf[307]=C_h_intern(&lf[307],22,"foreign-callback-stubs");
lf[308]=C_h_intern(&lf[308],28,"\010compilersimple-lambda-node\077");
lf[309]=C_h_intern(&lf[309],31,"\010compilerdump-undefined-globals");
lf[310]=C_h_intern(&lf[310],28,"\003systoplevel-definition-hook");
lf[311]=C_h_intern(&lf[311],22,"\010compilerhide-variable");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[313]=C_h_intern(&lf[313],36,"\010compilercompute-database-statistics");
lf[314]=C_h_intern(&lf[314],29,"\010compilercurrent-program-size");
lf[315]=C_h_intern(&lf[315],30,"\010compileroriginal-program-size");
lf[316]=C_h_intern(&lf[316],33,"\010compilerprint-program-statistics");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[323]=C_h_intern(&lf[323],1,"s");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[325]=C_h_intern(&lf[325],35,"\010compilerpprint-expressions-to-file");
lf[326]=C_h_intern(&lf[326],17,"close-output-port");
lf[327]=C_h_intern(&lf[327],12,"pretty-print");
lf[328]=C_h_intern(&lf[328],19,"with-output-to-port");
lf[329]=C_h_intern(&lf[329],16,"open-output-file");
lf[330]=C_h_intern(&lf[330],19,"current-output-port");
lf[331]=C_h_intern(&lf[331],27,"\010compilerforeign-type-check");
lf[332]=C_h_intern(&lf[332],4,"char");
lf[333]=C_h_intern(&lf[333],13,"unsigned-char");
lf[334]=C_h_intern(&lf[334],6,"unsafe");
lf[335]=C_h_intern(&lf[335],25,"\003sysforeign-char-argument");
lf[336]=C_h_intern(&lf[336],3,"int");
lf[337]=C_h_intern(&lf[337],27,"\003sysforeign-fixnum-argument");
lf[338]=C_h_intern(&lf[338],5,"float");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-flonum-argument");
lf[340]=C_h_intern(&lf[340],7,"pointer");
lf[341]=C_h_intern(&lf[341],26,"\003sysforeign-block-argument");
lf[342]=C_h_intern(&lf[342],15,"nonnull-pointer");
lf[343]=C_h_intern(&lf[343],8,"u8vector");
lf[344]=C_h_intern(&lf[344],34,"\003sysforeign-number-vector-argument");
lf[345]=C_h_intern(&lf[345],16,"nonnull-u8vector");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[347]=C_h_intern(&lf[347],7,"integer");
lf[348]=C_h_intern(&lf[348],28,"\003sysforeign-integer-argument");
lf[349]=C_h_intern(&lf[349],16,"unsigned-integer");
lf[350]=C_h_intern(&lf[350],37,"\003sysforeign-unsigned-integer-argument");
lf[351]=C_h_intern(&lf[351],9,"c-pointer");
lf[352]=C_h_intern(&lf[352],28,"\003sysforeign-pointer-argument");
lf[353]=C_h_intern(&lf[353],17,"nonnull-c-pointer");
lf[354]=C_h_intern(&lf[354],8,"c-string");
lf[355]=C_h_intern(&lf[355],17,"\003sysmake-c-string");
lf[356]=C_h_intern(&lf[356],27,"\003sysforeign-string-argument");
lf[357]=C_h_intern(&lf[357],16,"nonnull-c-string");
lf[358]=C_h_intern(&lf[358],6,"symbol");
lf[359]=C_h_intern(&lf[359],18,"\003syssymbol->string");
lf[360]=C_h_intern(&lf[360],3,"ref");
lf[361]=C_h_intern(&lf[361],8,"instance");
lf[362]=C_h_intern(&lf[362],12,"instance-ref");
lf[363]=C_h_intern(&lf[363],4,"this");
lf[364]=C_h_intern(&lf[364],8,"slot-ref");
lf[365]=C_h_intern(&lf[365],16,"nonnull-instance");
lf[366]=C_h_intern(&lf[366],5,"const");
lf[367]=C_h_intern(&lf[367],4,"enum");
lf[368]=C_h_intern(&lf[368],8,"function");
lf[369]=C_h_intern(&lf[369],27,"\010compilerforeign-type-table");
lf[370]=C_h_intern(&lf[370],17,"nonnull-c-string*");
lf[371]=C_h_intern(&lf[371],26,"nonnull-unsigned-c-string*");
lf[372]=C_h_intern(&lf[372],9,"c-string*");
lf[373]=C_h_intern(&lf[373],18,"unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],13,"c-string-list");
lf[375]=C_h_intern(&lf[375],14,"c-string-list*");
lf[376]=C_h_intern(&lf[376],18,"unsigned-integer32");
lf[377]=C_h_intern(&lf[377],13,"unsigned-long");
lf[378]=C_h_intern(&lf[378],4,"long");
lf[379]=C_h_intern(&lf[379],9,"integer32");
lf[380]=C_h_intern(&lf[380],17,"nonnull-u16vector");
lf[381]=C_h_intern(&lf[381],16,"nonnull-s8vector");
lf[382]=C_h_intern(&lf[382],17,"nonnull-s16vector");
lf[383]=C_h_intern(&lf[383],17,"nonnull-u32vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s32vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-f32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-f64vector");
lf[387]=C_h_intern(&lf[387],9,"u16vector");
lf[388]=C_h_intern(&lf[388],8,"s8vector");
lf[389]=C_h_intern(&lf[389],9,"s16vector");
lf[390]=C_h_intern(&lf[390],9,"u32vector");
lf[391]=C_h_intern(&lf[391],9,"s32vector");
lf[392]=C_h_intern(&lf[392],9,"f32vector");
lf[393]=C_h_intern(&lf[393],9,"f64vector");
lf[394]=C_h_intern(&lf[394],22,"nonnull-scheme-pointer");
lf[395]=C_h_intern(&lf[395],12,"nonnull-blob");
lf[396]=C_h_intern(&lf[396],19,"nonnull-byte-vector");
lf[397]=C_h_intern(&lf[397],11,"byte-vector");
lf[398]=C_h_intern(&lf[398],4,"blob");
lf[399]=C_h_intern(&lf[399],14,"scheme-pointer");
lf[400]=C_h_intern(&lf[400],6,"double");
lf[401]=C_h_intern(&lf[401],6,"number");
lf[402]=C_h_intern(&lf[402],12,"unsigned-int");
lf[403]=C_h_intern(&lf[403],5,"short");
lf[404]=C_h_intern(&lf[404],14,"unsigned-short");
lf[405]=C_h_intern(&lf[405],4,"byte");
lf[406]=C_h_intern(&lf[406],13,"unsigned-byte");
lf[407]=C_h_intern(&lf[407],5,"int32");
lf[408]=C_h_intern(&lf[408],14,"unsigned-int32");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[410]=C_h_intern(&lf[410],36,"\010compilerforeign-type-convert-result");
lf[411]=C_h_intern(&lf[411],38,"\010compilerforeign-type-convert-argument");
lf[412]=C_h_intern(&lf[412],27,"\010compilerfinal-foreign-type");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[414]=C_h_intern(&lf[414],37,"\010compilerestimate-foreign-result-size");
lf[415]=C_h_intern(&lf[415],9,"integer64");
lf[416]=C_h_intern(&lf[416],4,"bool");
lf[417]=C_h_intern(&lf[417],4,"void");
lf[418]=C_h_intern(&lf[418],13,"scheme-object");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[420]=C_h_intern(&lf[420],46,"\010compilerestimate-foreign-result-location-size");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[423]=C_h_intern(&lf[423],30,"\010compilerfinish-foreign-result");
lf[424]=C_h_intern(&lf[424],17,"\003syspeek-c-string");
lf[425]=C_h_intern(&lf[425],25,"\003syspeek-nonnull-c-string");
lf[426]=C_h_intern(&lf[426],26,"\003syspeek-and-free-c-string");
lf[427]=C_h_intern(&lf[427],34,"\003syspeek-and-free-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],17,"\003sysintern-symbol");
lf[429]=C_h_intern(&lf[429],22,"\003syspeek-c-string-list");
lf[430]=C_h_intern(&lf[430],31,"\003syspeek-and-free-c-string-list");
lf[431]=C_h_intern(&lf[431],35,"\010tinyclosmake-instance-from-pointer");
lf[432]=C_h_intern(&lf[432],4,"make");
lf[433]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[434]=C_h_intern(&lf[434],28,"\010compilerscan-used-variables");
lf[435]=C_h_intern(&lf[435],28,"\010compilerscan-free-variables");
lf[436]=C_h_intern(&lf[436],11,"lset-adjoin");
lf[437]=C_h_intern(&lf[437],25,"\010compilertopological-sort");
lf[438]=C_h_intern(&lf[438],7,"colored");
lf[439]=C_h_intern(&lf[439],23,"\010compilerchop-separator");
lf[440]=C_h_intern(&lf[440],9,"substring");
lf[441]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[442]=C_h_intern(&lf[442],23,"\010compilerchop-extension");
lf[443]=C_h_intern(&lf[443],22,"\010compilerprint-version");
lf[444]=C_h_intern(&lf[444],6,"print*");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000:(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[446]=C_h_intern(&lf[446],20,"\010compilerprint-usage");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\0238Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012\012  File and pathname opti"
"ons:\012\012    -output-file FILENAME       specifies output-filename, default is \047out"
".c\047\012    -include-path PATHNAME      specifies alternative path for included file"
"s\012    -to-stdout                  write compiled file to stdout instead of file\012"
"\012  Language options:\012\012    -feature SYMBOL             register feature identifie"
"r\012\012  Syntax related options:\012\012    -case-insensitive           don\047t preserve cas"
"e of read symbols\012    -keyword-style STYLE        allow alternative keyword synt"
"ax (none, prefix or suffix)\012    -compile-syntax             macros are made avai"
"lable at run-time\012    -emit-import-library MODULE write compile-time module info"
"rmation into separate file\012\012  Translation options:\012\012    -explicit-use           "
"    do not use units \047library\047 and \047eval\047 by default\012    -check-syntax          "
"     stop compilation after macro-expansion\012    -analyze-only               stop"
" compilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings  "
"              disable warnings\012    -disable-warning CLASS      disable specific "
"class of warnings\012    -debug-level NUMBER         set level of available debuggi"
"ng information\012    -no-trace                   disable tracing information\012    -"
"profile                    executable emits profiling information \012    -profile-"
"name FILENAME      name of the generated profile information file\012    -accumulat"
"e-profile         executable emits profiling information in append mode\012    -no-"
"lambda-info             omit additional procedure-information\012\012  Optimization op"
"tions:\012\012    -optimize-level NUMBER      enable certain sets of optimization opti"
"ons\012    -optimize-leaf-routines     enable leaf routine optimization\012    -lambda"
"-lift                enable lambda-lifting\012    -no-usual-integrations      stand"
"ard procedures may be redefined\012    -unsafe                     disable safety c"
"hecks\012    -local                      assume globals are only modified in curren"
"t file\012    -block                      enable block-compilation\012    -disable-int"
"errupts         disable interrupts in compiled code\012    -fixnum-arithmetic      "
"    assume all numbers are fixnums\012    -benchmark-mode             equivalent to"
" \047-block -optimize-level 4\012                                 -debug-level 0 -fixn"
"um-arithmetic -lambda-lift \012                                 -disable-interrupts"
" -inline\047\012    -disable-stack-overflow-checks  \012                                d"
"isables detection of stack-overflows.\012    -inline                     enable inl"
"ining\012    -inline-limit               set inlining threshold\012    -inline-global "
"             enable cross-module inlining\012    -emit-inline-file FILENAME  genera"
"te file with globally inlinable procedures\012                                (impl"
"ies -inline -local)\012\012  Configuration options:\012\012    -unit NAME                  c"
"ompile file as a library unit\012    -uses NAME                  declare library un"
"it as used.\012    -heap-size NUMBER           specifies heap-size of compiled exec"
"utable\012    -heap-initial-size NUMBER   specifies heap-size at startup time\012    -"
"heap-growth PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shr"
"inkage PERCENTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER"
"\012    -stack-size NUMBER          specifies nursery size of compiled executable\012 "
"   -extend FILENAME            load file before compilation commences\012    -prelu"
"de EXPRESSION         add expression to front of source file\012    -postlude EXPRE"
"SSION        add expression to end of source file\012    -prologue FILENAME        "
"  include file before main source file\012    -epilogue FILENAME          include f"
"ile after main source file\012    -dynamic                    compile as dynamicall"
"y loadable code\012    -require-extension NAME     require and import extension NAM"
"E\012    -static-extension NAME      import extension NAME but link statically (if "
"available)\012    -extension                  compile as extension (dynamic or stat"
"ic)\012    -ignore-repository          do not refer to repository for extensions\012\012 "
" Obscure options:\012\012    -debug MODES                display debugging output for "
"the given modes\012    -unsafe-libraries           marks the generated file as bein"
"g linked\012                                with the unsafe runtime system\012    -raw"
"                        do not generate implicit init- and exit code\011\011\011       \012 "
"   -emit-external-prototypes-first  emit protoypes for callbacks before foreign\012"
"                                declarations\012");
lf[448]=C_h_intern(&lf[448],36,"\010compilermake-block-variable-literal");
lf[449]=C_h_intern(&lf[449],22,"block-variable-literal");
lf[450]=C_h_intern(&lf[450],32,"\010compilerblock-variable-literal\077");
lf[451]=C_h_intern(&lf[451],36,"\010compilerblock-variable-literal-name");
lf[452]=C_h_intern(&lf[452],25,"\010compilermake-random-name");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[454]=C_h_intern(&lf[454],6,"random");
lf[455]=C_h_intern(&lf[455],15,"current-seconds");
lf[456]=C_h_intern(&lf[456],23,"\010compilerset-real-name!");
lf[457]=C_h_intern(&lf[457],24,"\010compilerreal-name-table");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[459]=C_h_intern(&lf[459],19,"\010compilerreal-name2");
lf[460]=C_h_intern(&lf[460],32,"\010compilerdisplay-real-name-table");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[462]=C_h_intern(&lf[462],28,"\010compilersource-info->string");
lf[463]=C_h_intern(&lf[463],4,"conc");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[466]=C_h_intern(&lf[466],11,"make-string");
lf[467]=C_h_intern(&lf[467],3,"max");
lf[468]=C_h_intern(&lf[468],12,"string-null\077");
lf[469]=C_h_intern(&lf[469],19,"\010compilerdump-nodes");
lf[470]=C_h_intern(&lf[470],19,"\003syswrite-char/port");
lf[471]=C_h_intern(&lf[471],19,"\003sysstandard-output");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[475]=C_h_intern(&lf[475],18,"\003sysuser-read-hook");
lf[476]=C_h_intern(&lf[476],15,"foreign-declare");
lf[477]=C_h_intern(&lf[477],7,"declare");
lf[478]=C_h_intern(&lf[478],34,"\010compilerscan-sharp-greater-string");
lf[479]=C_h_intern(&lf[479],18,"\003sysread-char/port");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[481]=C_h_intern(&lf[481],17,"get-output-string");
lf[482]=C_h_intern(&lf[482],18,"open-output-string");
lf[483]=C_h_intern(&lf[483],19,"\010compilervisibility");
lf[484]=C_h_intern(&lf[484],6,"hidden");
lf[485]=C_h_intern(&lf[485],24,"\010compilerexport-variable");
lf[486]=C_h_intern(&lf[486],8,"exported");
lf[487]=C_h_intern(&lf[487],26,"\010compilerblock-compilation");
lf[488]=C_h_intern(&lf[488],22,"\010compilermark-variable");
lf[489]=C_h_intern(&lf[489],22,"\010compilervariable-mark");
lf[490]=C_h_intern(&lf[490],19,"\010compilerintrinsic\077");
lf[491]=C_h_intern(&lf[491],9,"foldable\077");
lf[492]=C_h_intern(&lf[492],35,"\010compilercompiler-macro-environment");
lf[493]=C_h_intern(&lf[493],7,"cdb-get");
lf[494]=C_h_intern(&lf[494],8,"cdb-put!");
lf[495]=C_h_intern(&lf[495],16,"\003sysmacro-subset");
lf[496]=C_h_intern(&lf[496],28,"\003sysextend-macro-environment");
lf[497]=C_h_intern(&lf[497],19,"define-rewrite-rule");
lf[498]=C_h_intern(&lf[498],24,"\004coredefine-rewrite-rule");
lf[499]=C_h_intern(&lf[499],5,"cdadr");
lf[500]=C_h_intern(&lf[500],5,"caadr");
lf[501]=C_h_intern(&lf[501],16,"\003syscheck-syntax");
lf[502]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[503]=C_h_intern(&lf[503],18,"\003syser-transformer");
lf[504]=C_h_intern(&lf[504],21,"\003sysmacro-environment");
lf[505]=C_h_intern(&lf[505],27,"condition-property-accessor");
lf[506]=C_h_intern(&lf[506],3,"exn");
lf[507]=C_h_intern(&lf[507],7,"message");
lf[508]=C_h_intern(&lf[508],19,"condition-predicate");
C_register_lf2(lf,509,create_ptable());
t2=C_mutate(&lf[0] /* (set! c655 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3858,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3856 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3859 in k3856 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3862 in k3859 in k3856 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3877,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3882,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3909,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[20]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3949,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3978,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[28]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3997,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[34]+1 /* (set! syntax-error ...) */,C_retrieve(lf[28]));
t11=C_mutate((C_word*)lf[35]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4022,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[36]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4025,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[37]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4068,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[40]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4136,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4172,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[45]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4193,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[48]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4218,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[49]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[50]));
t19=C_mutate((C_word*)lf[51]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4262,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[60]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4356,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[63]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4412,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[64]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4419,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[65]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4426,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[72]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4473,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[75]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4485,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[77]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4548,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4579,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4599,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[83]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4645,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[84]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4675,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[86]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4721,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[89]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4781,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 286  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[508]))(3,*((C_word*)lf[508]+1),t33,lf[506]);}

/* k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 287  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[505]))(4,*((C_word*)lf[505]+1),t2,lf[506],lf[507]);}

/* k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word ab[170],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[108]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[109]));
t4=C_mutate((C_word*)lf[110]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4989,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4992,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_TRUE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[121]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5133,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[133]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5284,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[135]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5302,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[137]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5320,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[139]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5366,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[140]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5418,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[141]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5475,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[143]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5485,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[144]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5521,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[146]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5545,tmp=(C_word)a,a+=2,tmp));
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_mutate((C_word*)lf[151]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5564,a[2]=t19,tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[202]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6042,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[204]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6048,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[205]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6054,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[207]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6063,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[208]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6072,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[209]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6081,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[210]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6090,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[211]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6099,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[202]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6108,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[212]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6114,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[214]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6129,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[215]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6144,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[251]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6753,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[265]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7086,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[267]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7140,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[272]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7253,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[276]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7474,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[278]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7508,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[279]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7585,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[280]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7636,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[281]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7669,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[299]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7871,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[301]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7940,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[304]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8160,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[308]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8261,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[309]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8383,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[310]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8414,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[313]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8435,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[316]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8521,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[325]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8560,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[331]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8596,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[410]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9643,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[411]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9674,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[412]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9705,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[414]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9745,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[420]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10064,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[423]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10374,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[434]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10666,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[435]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10759,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[437]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10946,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[439]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11143,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[442]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11172,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[443]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11214,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[446]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11252,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[448]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11264,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[450]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11270,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[451]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11276,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[452]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11285,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[456]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11329,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[39]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11335,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[459]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11414,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[460]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11426,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[462]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11438,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[468]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11484,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[469]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11490,tmp=(C_word)a,a+=2,tmp));
t76=C_retrieve(lf[475]);
t77=C_mutate((C_word*)lf[475]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11592,a[2]=t76,tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[478]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11625,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[85]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11694,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[311]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11718,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[485]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11751,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[293]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11784,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[488]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11805,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[489]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11833,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[490]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11839,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[491]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11850,tmp=(C_word)a,a+=2,tmp));
t87=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1488 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[504]))(2,*((C_word*)lf[504]+1),t87);}

/* k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11866,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11875,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11877,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1492 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t3,t4);}

/* a11876 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11877,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11881,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1494 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[501]))(5,*((C_word*)lf[501]+1),t5,lf[497],t2,lf[502]);}

/* k11879 in a11876 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1496 caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[500]+1)))(3,*((C_word*)lf[500]+1),t2,((C_word*)t0)[3]);}

/* k11890 in k11879 in a11876 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1496 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11902 in k11890 in k11879 in a11876 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1496 cdadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[499]+1)))(3,*((C_word*)lf[499]+1),t2,((C_word*)t0)[2]);}

/* k11910 in k11902 in k11890 in k11879 in a11876 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11914 in k11910 in k11902 in k11890 in k11879 in a11876 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11916,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[498],t5));}

/* k11873 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1489 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[496]))(5,*((C_word*)lf[496]+1),((C_word*)t0)[2],lf[497],C_SCHEME_END_OF_LIST,t1);}

/* k11864 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11869,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1497 ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[495]))(3,*((C_word*)lf[495]+1),t2,((C_word*)t0)[2]);}

/* k11867 in k11864 in k11861 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate((C_word*)lf[492]+1 /* (set! compiler-macro-environment ...) */,t1);
t3=C_mutate((C_word*)lf[493]+1 /* (set! cdb-get ...) */,C_retrieve(lf[133]));
t4=C_mutate((C_word*)lf[494]+1 /* (set! cdb-put! ...) */,C_retrieve(lf[137]));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* foldable? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11850,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11855,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[130]);}

/* f_11855 in foldable? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11855,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t1,t2,t3);}

/* ##compiler#intrinsic? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11844,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[124]);}

/* f_11844 in ##compiler#intrinsic? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11844,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t1,t2,t3);}

/* ##compiler#variable-mark in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11833,4,t0,t1,t2,t3);}
/* support.scm: 1479 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11805r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11805r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11805r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11809,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11809(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11809(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11807 in ##compiler#mark-variable in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1476 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11788,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1469 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t3,t2,lf[483]);}

/* k11786 in ##compiler#variable-visible? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[484]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[486]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[487]))));}}

/* ##compiler#export-variable in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11751,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11756,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[483],lf[486]);}

/* f_11756 in ##compiler#export-variable in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11756r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11756r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11756r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11760,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11760(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11760(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11758 */
static void C_ccall f_11760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#hide-variable in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11718,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11723,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[483],lf[484]);}

/* f_11723 in ##compiler#hide-variable in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11723r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11723r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11723r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11727,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11727(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11727(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11725 */
static void C_ccall f_11727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#big-fixnum? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11694,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11625,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11629,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1431 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[482]))(2,*((C_word*)lf[482]+1),t3);}

/* k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11629,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11634,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11634(t5,((C_word*)t0)[2]);}

/* loop in k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11634,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[479]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11636 in loop in k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11638,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1434 quit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[5],lf[480]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11656,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1436 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11668,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[479]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11689,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[470]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11687 in k11636 in loop in k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1448 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11634(t2,((C_word*)t0)[2]);}

/* k11666 in k11636 in loop in k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11668,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1441 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[481]))(3,*((C_word*)lf[481]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11680,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[470]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11678 in k11666 in k11636 in loop in k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11683,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[470]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11681 in k11678 in k11666 in k11636 in loop in k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1445 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11634(t2,((C_word*)t0)[2]);}

/* k11654 in k11636 in loop in k11627 in ##compiler#scan-sharp-greater-string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1437 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11634(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11592,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11602,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[479]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1428 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k11600 in ##sys#user-read-hook in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11605,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1426 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[478]))(3,*((C_word*)lf[478]+1),t2,((C_word*)t0)[2]);}

/* k11603 in k11600 in ##sys#user-read-hook in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11605,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[476],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[477],t4));}

/* ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11490,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11494,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11499,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11499(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11499(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11499,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11503,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11586,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_11586 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11586,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11506,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11581,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_11581 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11581,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11509,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11576,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11576 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11576,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1404 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[466]+1)))(4,*((C_word*)lf[466]+1),t2,((C_word*)t0)[7],C_make_character(32));}

/* k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11512,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11518,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1406 printf */
((C_proc6)C_retrieve_symbol_proc(lf[13]))(6,*((C_word*)lf[13]+1),t3,lf[474],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11521,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11570 in k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11571,3,t0,t1,t2);}
/* loop3505 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11499(t3,t1,((C_word*)t0)[2],t2);}

/* k11519 in k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11521,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11527,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11536,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1410 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t4,lf[473],t5);}
else{
t4=t3;
f_11527(2,t4,C_SCHEME_UNDEFINED);}}

/* k11534 in k11519 in k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11539,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11544,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11544(t6,t2,C_fix(5));}

/* doloop3535 in k11534 in k11519 in k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11544(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11544,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11554,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1413 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,lf[472],t4);}}

/* k11552 in doloop3535 in k11534 in k11519 in k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11544(t3,((C_word*)t0)[2],t2);}

/* k11537 in k11534 in k11519 in k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[470]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[471]+1));}

/* k11525 in k11519 in k11516 in k11510 in k11507 in k11504 in k11501 in loop in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[470]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[471]+1));}

/* k11492 in ##compiler#dump-nodes in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1416 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* string-null? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11484,3,t0,t1,t2);}
/* support.scm: 1394 string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[468]))(3,*((C_word*)lf[468]+1),t1,t2);}

/* ##compiler#source-info->string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11438,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11457,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1387 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1389 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11455 in ##compiler#source-info->string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11464,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1388 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[467]+1)))(4,*((C_word*)lf[467]+1),t3,C_fix(0),t5);}

/* k11466 in k11455 in ##compiler#source-info->string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1388 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[466]+1)))(4,*((C_word*)lf[466]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k11462 in k11455 in ##compiler#source-info->string in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1388 conc */
((C_proc8)C_retrieve_symbol_proc(lf[463]))(8,*((C_word*)lf[463]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[464],((C_word*)t0)[3],t1,lf[465],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11432,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1377 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t2,C_retrieve(lf[457]));}

/* a11431 in ##compiler#display-real-name-table in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11432,4,t0,t1,t2,t3);}
/* support.scm: 1379 printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t1,lf[461],t2,t3);}

/* ##compiler#real-name2 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11414,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11418,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1373 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[457]),t2);}

/* k11416 in ##compiler#real-name2 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1374 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11335(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11335r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11335r(t0,t1,t2,t3);}}

static void C_ccall f_11335r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11338,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11354,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1357 resolve */
f_11338(t5,t2);}

/* k11352 in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11354,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1361 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[241]))(3,*((C_word*)lf[241]+1),t4,t1);}
else{
/* support.scm: 1370 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[241]))(3,*((C_word*)lf[241]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1358 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[241]))(3,*((C_word*)lf[241]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11377 in k11352 in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11383,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1362 get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[145]);}

/* k11381 in k11377 in k11352 in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11383,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11385,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11385(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11381 in k11377 in k11352 in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11385(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11385,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1364 resolve */
f_11338(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11390 in loop in k11381 in k11377 in k11352 in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11392,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11405,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1367 sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),t3,lf[458],((C_word*)t0)[4],t1);}}

/* k11403 in k11390 in loop in k11381 in k11377 in k11352 in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11409,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1368 get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[145]);}

/* k11407 in k11403 in k11390 in loop in k11381 in k11377 in k11352 in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1367 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11385(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11338(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11338,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11342,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1352 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[457]),t2);}

/* k11340 in resolve in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11342,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11348,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1354 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[457]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11346 in k11340 in resolve in ##compiler#real-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11329,4,t0,t1,t2,t3);}
/* support.scm: 1348 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),t1,C_retrieve(lf[457]),t2,t3);}

/* ##compiler#make-random-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11285(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_11285r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11285r(t0,t1,t2);}}

static void C_ccall f_11285r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11293,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11297,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1335 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11297(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k11295 in ##compiler#make-random-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11301,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1336 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[455]))(2,*((C_word*)lf[455]+1),t2);}

/* k11299 in k11295 in ##compiler#make-random-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11305,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1337 random */
((C_proc3)C_retrieve_symbol_proc(lf[454]))(3,*((C_word*)lf[454]+1),t2,C_fix(1000));}

/* k11303 in k11299 in k11295 in ##compiler#make-random-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1334 sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[43]))(6,*((C_word*)lf[43]+1),((C_word*)t0)[4],lf[453],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11291 in ##compiler#make-random-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1333 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11276,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[449]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11270,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[449]));}

/* ##compiler#make-block-variable-literal in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11264,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[449],t2));}

/* ##compiler#print-usage in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11256,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1217 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[443]))(2,*((C_word*)lf[443]+1),t2);}

/* k11254 in ##compiler#print-usage in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1218 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k11257 in k11254 in ##compiler#print-usage in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1219 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[447]);}

/* ##compiler#print-version in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11214(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_11214r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11214r(t0,t1,t2);}}

static void C_ccall f_11214r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11218,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_11218(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_11218(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k11216 in ##compiler#print-version in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1213 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[444]+1)))(3,*((C_word*)lf[444]+1),t2,lf[445]);}
else{
t3=t2;
f_11221(2,t3,C_SCHEME_UNDEFINED);}}

/* k11219 in k11216 in ##compiler#print-version in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1214 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t2,C_SCHEME_TRUE);}

/* k11226 in k11219 in k11216 in ##compiler#print-version in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1214 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[282]+1)))(3,*((C_word*)lf[282]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11172,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11181,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11181(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11181(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11181,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1206 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[440]+1)))(5,*((C_word*)lf[440]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1207 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11143,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11153,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_11153(t7,(C_word)C_i_memq(t6,lf[441]));}
else{
t6=t5;
f_11153(t6,C_SCHEME_FALSE);}}

/* k11151 in ##compiler#chop-separator in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11153(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1199 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[440]+1)))(5,*((C_word*)lf[440]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10946,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10955,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11002,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11037,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11074,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11125,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a11124 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11125,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1181 insert */
t5=((C_word*)t0)[2];
f_10955(t5,t1,t3,t4);}

/* k11072 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11119,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1184 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t3,((C_word*)t0)[2]);}

/* k11117 in k11072 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11123,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1184 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[2]);}

/* k11121 in k11117 in k11072 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1184 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11037(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11075 in k11072 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11080,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a11081 in k11075 in k11072 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11086,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1186 lookup */
t5=((C_word*)t0)[2];
f_11002(t5,t3,t4);}

/* k11084 in a11081 in k11075 in k11072 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[438]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1188 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11037(t5,((C_word*)t0)[4],t3,t4);}}

/* k11078 in k11075 in k11072 in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11037(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11037,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11041,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1169 insert */
t5=((C_word*)t0)[2];
f_10955(t5,t4,t2,lf[438]);}

/* k11039 in visit in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11044,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11049 in k11039 in visit in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11050,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11054,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1172 lookup */
t4=((C_word*)t0)[2];
f_11002(t4,t3,t2);}

/* k11052 in a11049 in k11039 in visit in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[438]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1174 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11037(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k11042 in k11039 in visit in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11044,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11002,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11008,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11008(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_11008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11008,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11021,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11035,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1164 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t4,t2);}}

/* k11033 in loop in lookup in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1164 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11019 in loop in lookup in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1164 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1165 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11008(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10955(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10955,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10961,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10961(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10961(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10961,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11000,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1158 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t4,t2);}}

/* k10998 in loop in insert in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_11000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1158 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10980 in loop in insert in ##compiler#topological-sort in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1159 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10961(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10759,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10762,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10928,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10941,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1141 walk */
t14=((C_word*)t8)[1];
f_10762(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10939 in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1142 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10928(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10928,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10934,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10933 in walkeach in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10934,3,t0,t1,t2);}
/* support.scm: 1139 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10762(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10762(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10762,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10766,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10922,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10922 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10922,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10917,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10917 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10917,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10912,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10912 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10912,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10772,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[82]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_10781(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[219]);
if(C_truep(t4)){
t5=t3;
f_10781(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[227]);
if(C_truep(t5)){
t6=t3;
f_10781(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[230]);
t7=t3;
f_10781(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[244])));}}}}

/* k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10781,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[213]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10800,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1121 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[436]))(5,*((C_word*)lf[436]+1),t4,*((C_word*)lf[274]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[231]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10822,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10822(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10836,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1126 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[436]))(5,*((C_word*)lf[436]+1),t6,*((C_word*)lf[274]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[92]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10845,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1129 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10762(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[226]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10875,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1132 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1136 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10928(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10874 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10875,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10887,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1135 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t6,t2,((C_word*)t0)[2]);}

/* k10885 in a10874 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1135 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10762(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10843 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10845,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10856,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1130 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10854 in k10843 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1130 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10762(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10834 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10822(t3,t2);}

/* k10820 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1127 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10762(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10798 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10800,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1122 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[293]))(3,*((C_word*)lf[293]+1),t3,((C_word*)t0)[2]);}

/* k10804 in k10798 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10806,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10810,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1123 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[436]))(5,*((C_word*)lf[436]+1),t2,*((C_word*)lf[274]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10808 in k10804 in k10798 in k10779 in k10770 in k10767 in k10764 in walk in ##compiler#scan-free-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10666,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10670,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10672,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10672(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10672,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10676,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10753,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10753 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10753,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10748,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10748 in k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10748,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10677 in k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10679,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[213]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[231]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10719,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10732,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_10732(t6,t4);}
else{
t6=(C_word)C_eqp(t1,lf[219]);
t7=t5;
f_10732(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[227])));}}}

/* k10730 in k10677 in k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* f_10719 in k10677 in k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10719,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10716 in k10677 in k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10718,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10694,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10700,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_10700(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_10700(t5,C_SCHEME_FALSE);}}

/* k10698 in k10716 in k10677 in k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10700(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10700,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10694(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10694(t2,C_SCHEME_UNDEFINED);}}

/* k10692 in k10716 in k10677 in k10674 in walk in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10668 in ##compiler#scan-used-variables in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10374,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[424],t9));}
else{
t6=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[425],t10));}
else{
t7=(C_word)C_eqp(t4,lf[372]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[82],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[426],t12));}
else{
t9=(C_word)C_eqp(t4,lf[370]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[371]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[82],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[427],t14));}
else{
t11=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[82],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[424],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[428],t17));}
else{
t12=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[82],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[429],t16));}
else{
t13=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[82],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[430],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10570,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_10570(t18,(C_word)C_i_memq(t17,lf[433]));}
else{
t17=t14;
f_10570(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_10570(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k10568 in ##compiler#finish-foreign-result in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10570,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[431],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_10591(t6,(C_word)C_eqp(lf[365],t5));}
else{
t5=t2;
f_10591(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10591(t3,C_SCHEME_FALSE);}}}

/* k10589 in k10568 in ##compiler#finish-foreign-result in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[363],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[82],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[432],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10064,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10067,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10076,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1045 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t4,t5);}

/* a10367 in ##compiler#estimate-foreign-result-location-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10368,2,t0,t1);}
/* support.scm: 1066 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[422],((C_word*)t0)[2]);}

/* a10075 in ##compiler#estimate-foreign-result-location-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10076,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[332]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10086,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_10086(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[336]);
if(C_truep(t7)){
t8=t6;
f_10086(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[403]);
if(C_truep(t8)){
t9=t6;
f_10086(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[416]);
if(C_truep(t9)){
t10=t6;
f_10086(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t10)){
t11=t6;
f_10086(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[333]);
if(C_truep(t11)){
t12=t6;
f_10086(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[402]);
if(C_truep(t12)){
t13=t6;
f_10086(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t13)){
t14=t6;
f_10086(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t14)){
t15=t6;
f_10086(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t15)){
t16=t6;
f_10086(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t16)){
t17=t6;
f_10086(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t17)){
t18=t6;
f_10086(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t18)){
t19=t6;
f_10086(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t19)){
t20=t6;
f_10086(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t20)){
t21=t6;
f_10086(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[347]);
if(C_truep(t21)){
t22=t6;
f_10086(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t22)){
t23=t6;
f_10086(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t23)){
t24=t6;
f_10086(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t24)){
t25=t6;
f_10086(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[399]);
if(C_truep(t25)){
t26=t6;
f_10086(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[394]);
if(C_truep(t26)){
t27=t6;
f_10086(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t27)){
t28=t6;
f_10086(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t28)){
t29=t6;
f_10086(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t29)){
t30=t6;
f_10086(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t30)){
t31=t6;
f_10086(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t31)){
t32=t6;
f_10086(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[371]);
if(C_truep(t32)){
t33=t6;
f_10086(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t33)){
t34=t6;
f_10086(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t34)){
t35=t6;
f_10086(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[370]);
if(C_truep(t35)){
t36=t6;
f_10086(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[374]);
t37=t6;
f_10086(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[375])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k10084 in a10075 in ##compiler#estimate-foreign-result-location-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[401]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub331(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1058 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[369]),((C_word*)t0)[3]);}
else{
t5=t4;
f_10104(2,t5,C_SCHEME_FALSE);}}}}

/* k10102 in k10084 in a10075 in ##compiler#estimate-foreign-result-location-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10104,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1060 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[360]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_10138(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
t6=t4;
f_10138(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[340]);
if(C_truep(t6)){
t7=t4;
f_10138(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[351]);
if(C_truep(t7)){
t8=t4;
f_10138(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[353]);
t9=t4;
f_10138(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[368])));}}}}}
else{
/* support.scm: 1065 err */
f_10067(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k10136 in k10102 in k10084 in a10075 in ##compiler#estimate-foreign-result-location-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1064 err */
f_10067(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_10067(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10067,NULL,2,t1,t2);}
/* support.scm: 1044 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[421],t2);}

/* ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9745,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9751,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1015 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a10057 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10058,2,t0,t1);}
/* support.scm: 1040 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[419],((C_word*)t0)[2]);}

/* a9750 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9751,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[332]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9761,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9761(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[336]);
if(C_truep(t7)){
t8=t6;
f_9761(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[403]);
if(C_truep(t8)){
t9=t6;
f_9761(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[416]);
if(C_truep(t9)){
t10=t6;
f_9761(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[417]);
if(C_truep(t10)){
t11=t6;
f_9761(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t11)){
t12=t6;
f_9761(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t12)){
t13=t6;
f_9761(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[333]);
if(C_truep(t13)){
t14=t6;
f_9761(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[402]);
if(C_truep(t14)){
t15=t6;
f_9761(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t15)){
t16=t6;
f_9761(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t16)){
t17=t6;
f_9761(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[407]);
t18=t6;
f_9761(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[408])));}}}}}}}}}}}}

/* k9759 in a9750 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9761,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[354]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9770(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[357]);
if(C_truep(t4)){
t5=t3;
f_9770(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
if(C_truep(t5)){
t6=t3;
f_9770(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t6)){
t7=t3;
f_9770(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[358]);
if(C_truep(t7)){
t8=t3;
f_9770(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t8)){
t9=t3;
f_9770(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[370]);
if(C_truep(t9)){
t10=t3;
f_9770(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t10)){
t11=t3;
f_9770(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t11)){
t12=t3;
f_9770(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
t13=t3;
f_9770(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[375])));}}}}}}}}}}}

/* k9768 in k9759 in a9750 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9770,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9782(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[378]);
if(C_truep(t4)){
t5=t3;
f_9782(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
if(C_truep(t5)){
t6=t3;
f_9782(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
if(C_truep(t6)){
t7=t3;
f_9782(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
t8=t3;
f_9782(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[376])));}}}}}}

/* k9780 in k9768 in k9759 in a9750 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9782,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[338]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9794(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[400]);
if(C_truep(t4)){
t5=t3;
f_9794(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[401]);
t6=t3;
f_9794(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[415])));}}}}

/* k9792 in k9780 in k9768 in k9759 in a9750 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9794,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1031 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[369]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9800(2,t3,C_SCHEME_FALSE);}}}

/* k9798 in k9792 in k9780 in k9768 in k9759 in a9750 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9800,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1033 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[360]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9834,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9834(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
t6=t4;
f_9834(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[340]);
if(C_truep(t6)){
t7=t4;
f_9834(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[351]);
if(C_truep(t7)){
t8=t4;
f_9834(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t8)){
t9=t4;
f_9834(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[368]);
if(C_truep(t9)){
t10=t4;
f_9834(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[361]);
if(C_truep(t10)){
t11=t4;
f_9834(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[362]);
t12=t4;
f_9834(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[365])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9832 in k9798 in k9792 in k9780 in k9768 in k9759 in a9750 in ##compiler#estimate-foreign-result-size in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9705,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9711,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9739,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1002 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a9738 in ##compiler#final-foreign-type in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9739,2,t0,t1);}
/* support.scm: 1009 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[413],((C_word*)t0)[2]);}

/* a9710 in ##compiler#final-foreign-type in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9711,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9715,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1005 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[369]),t2);}
else{
t5=t4;
f_9715(2,t5,C_SCHEME_FALSE);}}

/* k9713 in a9710 in ##compiler#final-foreign-type in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1007 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9674,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9678,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9687,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 996  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,C_retrieve(lf[369]),t3);}
else{
t5=t4;
f_9678(t5,C_SCHEME_FALSE);}}

/* k9685 in ##compiler#foreign-type-convert-argument in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9687,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9678(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9678(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9678(t2,C_SCHEME_FALSE);}}

/* k9676 in ##compiler#foreign-type-convert-argument in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9643,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9647,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9656,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 989  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,C_retrieve(lf[369]),t3);}
else{
t5=t4;
f_9647(t5,C_SCHEME_FALSE);}}

/* k9654 in ##compiler#foreign-type-convert-result in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9656,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_9647(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9647(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9647(t2,C_SCHEME_FALSE);}}

/* k9645 in ##compiler#foreign-type-convert-result in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8596,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8602,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9637,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 890  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t3,t4,t5);}

/* a9636 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9637,2,t0,t1);}
/* support.scm: 982  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[409],((C_word*)t0)[2]);}

/* a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8602,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8608,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8608(t7,t1,t2);}

/* repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8608(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8608,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[332]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[333]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[334]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[335],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[336]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8637(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[402]);
if(C_truep(t8)){
t9=t7;
f_8637(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[403]);
if(C_truep(t9)){
t10=t7;
f_8637(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[404]);
if(C_truep(t10)){
t11=t7;
f_8637(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t11)){
t12=t7;
f_8637(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t12)){
t13=t7;
f_8637(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[407]);
t14=t7;
f_8637(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[408])));}}}}}}}}

/* k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8637,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[334]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[337],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[338]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8656(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t5=t3;
f_8656(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[401])));}}}

/* k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8656,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[334]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[339],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8675(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
if(C_truep(t4)){
t5=t3;
f_8675(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[398]);
t6=t3;
f_8675(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[399])));}}}}

/* k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8675,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8678,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 900  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8745(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t4)){
t5=t3;
f_8745(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
t6=t3;
f_8745(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[396])));}}}}

/* k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8745,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[334]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[341],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[343]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8764(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[387]);
if(C_truep(t4)){
t5=t3;
f_8764(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[388]);
if(C_truep(t5)){
t6=t3;
f_8764(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t6)){
t7=t3;
f_8764(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t7)){
t8=t3;
f_8764(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t8)){
t9=t3;
f_8764(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
t10=t3;
f_8764(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[393])));}}}}}}}}

/* k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8764,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8767,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 912  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8846(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_8846(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t5)){
t6=t3;
f_8846(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t6)){
t7=t3;
f_8846(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t7)){
t8=t3;
f_8846(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t8)){
t9=t3;
f_8846(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
t10=t3;
f_8846(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[386])));}}}}}}}}

/* k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8846,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[334]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[346]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[82],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[344],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8885(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[378]);
t5=t3;
f_8885(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[379])));}}}

/* k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8885,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[334]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[348],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8904(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_8904(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8904,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[334]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[350],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8923(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t5=t3;
f_8923(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}

/* k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8923,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8926,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 932  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[352],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[354]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_9003(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t6=t4;
f_9003(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}}

/* k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9003(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9003,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9006,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 940  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[357]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9088(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[370]);
t5=t3;
f_9088(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[371])));}}}

/* k9086 in k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9088,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[334]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[355],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[356],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[355],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[358]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[334]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[359],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[355],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[359],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[356],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[355],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 956  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[369]),((C_word*)t0)[3]);}
else{
t4=t3;
f_9163(2,t4,C_SCHEME_FALSE);}}}}

/* k9161 in k9086 in k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 958  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[360]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9197(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[340]);
if(C_truep(t5)){
t6=t4;
f_9197(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[368]);
t7=t4;
f_9197(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[351])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k9195 in k9161 in k9086 in k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9197,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9200,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 962  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[361]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[362]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9267,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 968  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[365]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[363],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[364],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[366]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 975  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8608(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[334]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[348],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[342]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[353]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[352],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9265 in k9195 in k9161 in k9086 in k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9267,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[363],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[364],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[82],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[218],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[92],t17));}

/* k9198 in k9195 in k9161 in k9086 in k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9200,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[352],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[218],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k9004 in k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_9006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9006,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9037,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[334]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_9037(t7,(C_word)C_a_i_cons(&a,2,lf[355],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[356],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_9037(t9,(C_word)C_a_i_cons(&a,2,lf[355],t8));}}

/* k9035 in k9004 in k9001 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_9037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9037,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[218],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8924 in k8921 in k8902 in k8883 in k8844 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8926,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[352],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[218],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k8765 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8767,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8798,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[334]))){
t6=t5;
f_8798(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8798(t10,(C_word)C_a_i_cons(&a,2,lf[344],t9));}}

/* k8796 in k8765 in k8762 in k8743 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8798,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[218],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8676 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8678,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8709,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[334]))){
t6=t5;
f_8709(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8709(t7,(C_word)C_a_i_cons(&a,2,lf[341],t6));}}

/* k8707 in k8676 in k8673 in k8654 in k8635 in repeat in a8601 in ##compiler#foreign-type-check in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8709,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[218],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* ##compiler#pprint-expressions-to-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8560,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8564,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 871  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[329]+1)))(3,*((C_word*)lf[329]+1),t4,t3);}
else{
/* support.scm: 871  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[330]+1)))(2,*((C_word*)lf[330]+1),t4);}}

/* k8562 in ##compiler#pprint-expressions-to-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8567,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 872  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[328]))(4,*((C_word*)lf[328]+1),t2,t1,t3);}

/* a8574 in k8562 in ##compiler#pprint-expressions-to-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8581,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a8580 in a8574 in k8562 in ##compiler#pprint-expressions-to-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8581,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8585,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 876  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[327]))(3,*((C_word*)lf[327]+1),t3,t2);}

/* k8583 in a8580 in a8574 in k8562 in ##compiler#pprint-expressions-to-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 877  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k8565 in k8562 in ##compiler#pprint-expressions-to-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 879  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[326]+1)))(3,*((C_word*)lf[326]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8521,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8533,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a8532 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8533,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8540,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 859  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t9,lf[323],lf[324]);}

/* k8538 in a8532 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8540,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8543,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 860  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t2,lf[322],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8541 in k8538 in a8532 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 861  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[321],((C_word*)t0)[2]);}

/* k8544 in k8541 in k8538 in a8532 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 862  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[320],((C_word*)t0)[2]);}

/* k8547 in k8544 in k8541 in k8538 in a8532 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 863  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[319],((C_word*)t0)[2]);}

/* k8550 in k8547 in k8544 in k8541 in k8538 in a8532 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 864  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[318],((C_word*)t0)[2]);}

/* k8553 in k8550 in k8547 in k8544 in k8541 in k8538 in a8532 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 865  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[317],((C_word*)t0)[2]);}

/* a8526 in ##compiler#print-program-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8527,2,t0,t1);}
/* support.scm: 858  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8435,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8439,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8444,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 834  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t13,t14,t2);}

/* a8443 in ##compiler#compute-database-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8444,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a8449 in a8443 in ##compiler#compute-database-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8450,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[181]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[162]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8492,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cdr(t2);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8497,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t8=(C_word)C_eqp(t5,lf[169]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* f_8497 in a8449 in a8443 in ##compiler#compute-database-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8497,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8490 in a8449 in a8443 in ##compiler#compute-database-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[226],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8437 in ##compiler#compute-database-statistics in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 848  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[314]),C_retrieve(lf[315]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8414,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8424,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 811  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t7,lf[249],lf[312],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k8422 in ##sys#toplevel-definition-hook in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 812  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[311]))(3,*((C_word*)lf[311]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8383,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8389,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 797  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t3,t2);}

/* a8388 in ##compiler#dump-undefined-globals in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8389,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8396,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[181],t3))){
t5=(C_word)C_i_assq(lf[179],t3);
t6=t4;
f_8396(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8396(t5,C_SCHEME_FALSE);}}

/* k8394 in a8388 in ##compiler#dump-undefined-globals in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8396,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8399,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 801  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[199]+1)))(3,*((C_word*)lf[199]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8397 in k8394 in a8388 in ##compiler#dump-undefined-globals in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 802  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8261,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8265,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8377,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8377 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8377,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8265,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
if(C_truep((C_word)C_i_cadr(t1))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8285,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8285(3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8285,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8289,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8366,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8366 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8366,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8289,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[238]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8343,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(t1,lf[229]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8361,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}}

/* f_8361 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8361,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8358 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 791  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* f_8343 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8343,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8296 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8298,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8337,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8338,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8338 in k8296 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8338,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8335 in k8296 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8337,2,t0,t1);}
t2=(C_word)C_eqp(lf[213],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8329,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8329 in k8335 in k8296 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8329,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8326 in k8335 in k8296 in k8287 in rec in k8263 in ##compiler#simple-lambda-node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 789  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8160,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8166,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8166(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8166,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8255,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8255 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8255,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8173,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8250,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_8250 in k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8250,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8171 in k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8173,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[213]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8182(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
if(C_truep(t4)){
t5=t3;
f_8182(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[219]);
if(C_truep(t5)){
t6=t3;
f_8182(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[230]);
t7=t3;
f_8182(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[217])));}}}}

/* k8180 in k8171 in k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8182,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[226]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8208,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8209,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[218]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[92]));
if(C_truep(t4)){
/* support.scm: 773  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* f_8209 in k8180 in k8171 in k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8209,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8206 in k8180 in k8171 in k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8208,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8196,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 772  find */
((C_proc4)C_retrieve_symbol_proc(lf[306]))(4,*((C_word*)lf[306]+1),((C_word*)t0)[2],t3,C_retrieve(lf[307]));}

/* a8195 in k8206 in k8180 in k8171 in k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8196,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 772  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),t3,t2);}

/* k8202 in a8195 in k8206 in k8180 in k8171 in k8168 in walk in ##compiler#expression-has-side-effects? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7940,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7943,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7972,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8015,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8134,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 756  matchn */
t15=((C_word*)t12)[1];
f_8015(t15,t14,t2,t3);}

/* k8132 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8134,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8154,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8154 in k8132 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8154,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8142 in k8132 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8149,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8149 in k8142 in k8132 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8149,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8146 in k8142 in k8132 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 759  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[10]))(7,*((C_word*)lf[10]+1),((C_word*)t0)[4],lf[302],lf[303],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8138 in k8132 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8015(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8015,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 745  resolve */
t4=((C_word*)t0)[4];
f_7943(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8122,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8127,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* f_8127 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8127,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8122,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8109,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8114,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_8114 in k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8114,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8107 in k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* support.scm: 747  match1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7972(t3,((C_word*)t0)[2],t1,t2);}

/* k8035 in k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8037,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8101,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8101 in k8035 in k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8101,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8042 in k8035 in k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8044,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8050,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8050(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8042 in k8035 in k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_8050(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8050,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 751  resolve */
t4=((C_word*)t0)[4];
f_7943(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8081,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 753  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8015(t7,t4,t5,t6);}}}}

/* k8079 in loop in k8042 in k8035 in k8120 in matchn in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 754  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8050(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7972(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7972,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 738  resolve */
t4=((C_word*)t0)[3];
f_7943(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7994,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 740  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7992 in match1 in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 740  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7972(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7943,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7967,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 733  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7965 in resolve in ##compiler#match-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7871,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7877,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 713  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[300]))(4,*((C_word*)lf[300]+1),t1,t2,t3);}

/* a7876 in ##compiler#load-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7877,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7883,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7883(t5,t1);}

/* loop in a7876 in ##compiler#load-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7883,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7887,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 716  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t2);}

/* k7885 in loop in a7876 in ##compiler#load-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7887,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7907,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 721  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t4,t5);}}

/* k7905 in k7885 in loop in a7876 in ##compiler#load-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7908,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[292],t1);}

/* f_7908 in k7905 in k7885 in loop in a7876 in ##compiler#load-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_7908r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7908r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7908r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7912,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7912(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7912(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k7910 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7894 in k7885 in loop in a7876 in ##compiler#load-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 722  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7883(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7669,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7673,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7700,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 682  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[298]))(4,*((C_word*)lf[298]+1),t6,t2,t7);}

/* a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7869,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 684  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[297]))(2,*((C_word*)lf[297]+1),t3);}

/* k7867 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 684  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[282]+1)))(7,*((C_word*)lf[282]+1),((C_word*)t0)[2],lf[294],t1,lf[295],C_retrieve(lf[240]),lf[296]);}

/* k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7707,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 686  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t2,t3,((C_word*)t0)[2]);}

/* a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7712,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 688  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[293]))(3,*((C_word*)lf[293]+1),t4,t2);}

/* k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7719,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[164],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7855,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7861,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],lf[292]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_7861 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7861,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t1,t2,t3);}

/* k7853 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7856,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_7856 in k7853 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7856,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[203]));}

/* k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[162],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7743(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[157],t5);
t7=t4;
f_7743(t7,(C_word)C_i_not(t6));}}}

/* k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7743(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7743,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[191],((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7832,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7832 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7832,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7761,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(t1);
/* support.scm: 696  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[2],t3,lf[190]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7759 in k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7761,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 697  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[198]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7821 in k7759 in k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7823,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7815,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[291]);}}

/* f_7815 in k7821 in k7759 in k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7815,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t1,t2,t3);}

/* k7771 in k7821 in k7759 in k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[288]);
if(C_truep(t3)){
t4=t2;
f_7776(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[289]);
if(C_truep(t4)){
t5=t2;
f_7776(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[290]);
t7=t2;
f_7776(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7774 in k7771 in k7821 in k7759 in k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7776,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7794,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 704  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7792 in k7774 in k7771 in k7821 in k7759 in k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 704  pp */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),((C_word*)t0)[2],t2);}

/* k7781 in k7774 in k7771 in k7821 in k7759 in k7750 in k7741 in k7849 in k7717 in a7711 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 705  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k7705 in k7702 in a7699 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 707  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[282]+1)))(3,*((C_word*)lf[282]+1),((C_word*)t0)[2],lf[286]);}

/* k7671 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 709  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t2,lf[284],lf[285]);}
else{
t3=t2;
f_7679(2,t3,C_SCHEME_FALSE);}}

/* k7677 in k7671 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7684,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7692,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 710  sort-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[78]))(3,*((C_word*)lf[78]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7690 in k7677 in k7671 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7683 in k7677 in k7671 in ##compiler#emit-global-inline-file in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7684,3,t0,t1,t2);}
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[282]+1)))(4,*((C_word*)lf[282]+1),t1,lf[283],t2);}

/* ##compiler#sexpr->node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7636,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7642,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7642(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7642(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7642,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7658,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k7656 in walk in ##compiler#sexpr->node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7659,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7659 in k7656 in walk in ##compiler#sexpr->node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7659,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7585,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7591,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7591(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7591,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7599,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7630,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7630 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7630,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7597 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7625,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7625 in k7597 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7625,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7605 in k7597 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7611,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7615,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7620,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_7620 in k7605 in k7597 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7620,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7617 in k7605 in k7597 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k7613 in k7605 in k7597 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7609 in k7605 in k7597 in walk in ##compiler#node->sexpr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7611,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7508,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7512,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7578,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7579,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_7579 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7579,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7576 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 661  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[205]))(4,*((C_word*)lf[205]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7569,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7570,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7570 in k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7570,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7567 in k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 662  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7513 in k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7560,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7561,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7561 in k7513 in k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7561,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7558 in k7513 in k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 663  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7516 in k7513 in k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7518,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7529(t4,C_fix(4)));}

/* doloop1622 in k7516 in k7513 in k7510 in ##compiler#copy-node! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static C_word C_fcall f_7529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7474,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7480,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7480(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7480(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7480,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7494,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 657  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7492 in rec in ##compiler#tree-copy in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7498,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 657  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7480(t4,t2,t3);}

/* k7496 in k7492 in rec in ##compiler#tree-copy in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7498,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7253,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7257,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 625  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[254]+1)))(5,*((C_word*)lf[254]+1),t5,*((C_word*)lf[277]+1),t3,t4);}

/* k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7259,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7265,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 652  walk */
t6=((C_word*)t4)[1];
f_7265(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7265,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7269,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7465,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7465 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7465,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7272,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7460,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7460 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7460,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7455,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7455 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7455,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[213]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7288,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 632  rename */
f_7259(t3,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(t1,lf[231]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 633  rename */
f_7259(t4,t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 636  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t6,t5);}
else{
t5=(C_word)C_eqp(t1,lf[226]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7380,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 640  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),((C_word*)t0)[7],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 651  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t6,((C_word*)t0)[6]);}}}}}

/* k7437 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7443,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7449 in k7437 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7450,3,t0,t1,t2);}
/* walk1500 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7265(t3,t1,t2,((C_word*)t0)[2]);}

/* k7441 in k7437 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7444,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7444 in k7441 in k7437 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7444,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7380,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[93]),t2);}

/* k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 644  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t2,t1,((C_word*)t0)[2]);}

/* k7385 in k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 647  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[275]);}

/* k7411 in k7385 in k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7413,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7421,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7429,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 648  rename */
f_7259(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_7429(2,t5,C_SCHEME_FALSE);}}

/* k7427 in k7411 in k7385 in k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 648  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7419 in k7411 in k7385 in k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7421,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7398,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7404 in k7419 in k7411 in k7385 in k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7405,3,t0,t1,t2);}
/* walk1500 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7265(t3,t1,t2,((C_word*)t0)[2]);}

/* k7396 in k7419 in k7411 in k7385 in k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7399,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[226],((C_word*)t0)[2],t1);}

/* f_7399 in k7396 in k7419 in k7411 in k7385 in k7382 in a7379 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7399,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k7338 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7343,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 637  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7341 in k7338 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7343,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7354,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7361,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7360 in k7341 in k7338 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7361,3,t0,t1,t2);}
/* walk1500 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7265(t3,t1,t2,((C_word*)t0)[2]);}

/* k7352 in k7341 in k7338 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7355,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_7355 in k7352 in k7341 in k7338 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7355,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k7322 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7324,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7309,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7315 in k7322 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7316,3,t0,t1,t2);}
/* walk1500 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7265(t3,t1,t2,((C_word*)t0)[2]);}

/* k7307 in k7322 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7310,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[231],((C_word*)t0)[2],t1);}

/* f_7310 in k7307 in k7322 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7310,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k7286 in k7273 in k7270 in k7267 in walk in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 632  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* rename in k7255 in ##compiler#copy-node-tree-and-rename in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7259(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7259,NULL,3,t1,t2,t3);}
/* support.scm: 626  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[273]))(6,*((C_word*)lf[273]+1),t1,t2,t3,*((C_word*)lf[274]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7140,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7146,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 603  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),t1,t2,t6);}

/* a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7146,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7152,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7158,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7158,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[93]),((C_word*)t0)[2]);}
else{
t5=t4;
f_7162(2,t5,((C_word*)t0)[2]);}}

/* k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7165,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 609  copy-node-tree-and-rename */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_7165(2,t3,((C_word*)t0)[3]);}}

/* k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7170,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7191,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7245,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 615  last */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7191(2,t4,t1);}}

/* k7243 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7245,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7215,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 617  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[271],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7229,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[236],t6,((C_word*)t0)[2]);}}

/* f_7229 in k7243 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7229,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k7213 in k7243 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7215,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7207,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t2);}

/* f_7207 in k7213 in k7243 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7207,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k7189 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 621  take */
((C_proc4)C_retrieve_symbol_proc(lf[270]))(4,*((C_word*)lf[270]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7193 in k7189 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 611  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[269]))(6,*((C_word*)lf[269]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7169 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7170,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7183,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[92],t5,t6);}

/* f_7183 in a7169 in k7163 in k7160 in a7157 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7183,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* a7151 in a7145 in ##compiler#inline-lambda-bindings in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
/* support.scm: 606  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[268]))(4,*((C_word*)lf[268]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7086,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7092,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7092(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7092(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7092,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 599  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k7116 in fold in ##compiler#fold-boolean in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7122,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 600  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7092(t4,t2,t3);}

/* k7120 in k7116 in fold in ##compiler#fold-boolean in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7122,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7110,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[228],lf[266],t2);}

/* f_7110 in k7120 in k7116 in fold in ##compiler#fold-boolean in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7110,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6753,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6759,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6759(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6759,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6763,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7080,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7080 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7080,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6766,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7075,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7075 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7075,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6769,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7070,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7070 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7070,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6769,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[218]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6778(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[263]);
t5=t3;
f_6778(t5,(C_truep(t4)?t4:(C_word)C_eqp(t1,lf[264])));}}

/* k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_6778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6778,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6785,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[252]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6802,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6806,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[213]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[217]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[82]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[82],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6872,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 573  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[256]))(3,*((C_word*)lf[256]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[226]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[116]:lf[226]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6893,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 580  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6759(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[238]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[229]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6926,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[219]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[258]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6950,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6950(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[259]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7012,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_7012(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
if(C_truep(t14)){
t15=t13;
f_7012(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
t16=t13;
f_7012(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[262])));}}}}}}}}}}}}}

/* k7010 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_7012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7012,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 590  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6759(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7038,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7042,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k7040 in k7010 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 591  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7036 in k7010 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7038,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7017 in k7010 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k7021 in k7017 in k7010 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 590  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[257]))(6,*((C_word*)lf[257]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_6950(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6950,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6968,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 587  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6999,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 588  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6759(3,t10,t8,t9);}}

/* k6997 in loop in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6999,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 588  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6950(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6966 in loop in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6976,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 587  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6759(3,t4,t2,t3);}

/* k6974 in k6966 in loop in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[258],t3));}

/* k6924 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 582  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[257]))(5,*((C_word*)lf[257]+1),((C_word*)t0)[3],lf[229],((C_word*)t0)[2],t1);}

/* k6891 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6893,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6870 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6866 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 573  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[254]+1)))(5,*((C_word*)lf[254]+1),((C_word*)t0)[3],*((C_word*)lf[255]+1),((C_word*)t0)[2],t1);}

/* k6850 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6864,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 574  last */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t3,((C_word*)t0)[2]);}

/* k6862 in k6850 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 574  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6759(3,t2,((C_word*)t0)[2],t1);}

/* k6858 in k6850 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6860,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* k6804 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6800 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6802,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[252],t2));}

/* k6783 in k6776 in k6767 in k6764 in k6761 in walk in ##compiler#build-expression-tree in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6785,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6144,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6147,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6748,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 557  walk */
t9=((C_word*)t6)[1];
f_6147(3,t9,t8,t2);}

/* k6746 in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6751,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 558  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,lf[249],lf[250],((C_word*)((C_word*)t0)[2])[1]);}

/* k6749 in k6746 in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word *a;
loop:
a=C_alloc(8);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_6147,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 491  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 492  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t1,lf[216],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[217]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6189,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[217],t7,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(t4,lf[218]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[219]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6217,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6242,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6245,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[223],C_retrieve(lf[224]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_6245(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_6245(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_6245(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[92]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 512  walk */
t65=t1;
t66=t11;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6299,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 513  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[225]))(3,*((C_word*)lf[225]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[116]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[226]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 517  walk */
t65=t14;
t66=t15;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[227]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6411(t17,(C_word)C_eqp(lf[82],t16));}
else{
t16=t15;
f_6411(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[228]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[229]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6448,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[230]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6475,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,lf[230],t17,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t4,lf[231]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[232]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6503,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[233]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6565,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 536  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[236]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6586(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[244]);
if(C_truep(t21)){
t22=t20;
f_6586(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[245]);
if(C_truep(t22)){
t23=t20;
f_6586(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[246]);
t24=t20;
f_6586(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[247])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6736,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6734 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6737,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[238],lf[248],t1);}

/* f_6737 in k6734 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6737,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_6586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6586,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6601,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[237]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6623,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6637,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6643,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6664,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6687,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6692,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[243]);}

/* f_6692 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6692,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t1,t2,t3);}

/* k6685 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6664(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6664(t2,C_SCHEME_FALSE);}}

/* k6662 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_6664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6664,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6668,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 552  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 554  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[241]))(3,*((C_word*)lf[241]+1),t2,((C_word*)t0)[2]);}}

/* k6669 in k6662 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6678(2,t3,t1);}
else{
/* support.scm: 553  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[241]))(3,*((C_word*)lf[241]+1),t2,((C_word*)t0)[2]);}}

/* k6676 in k6669 in k6662 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6678,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6668(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[240]),((C_word*)t0)[2],t1));}

/* k6666 in k6662 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6668,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6655,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6653 in k6666 in k6662 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6656,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[238],((C_word*)t0)[2],t1);}

/* f_6656 in k6653 in k6666 in k6662 in a6642 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6656,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* a6636 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
/* support.scm: 544  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[143]))(3,*((C_word*)lf[143]+1),t1,((C_word*)t0)[2]);}

/* k6621 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6624,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[238],lf[239],t1);}

/* f_6624 in k6621 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6624,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6599 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6602,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6602 in k6599 in k6584 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6602,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6563 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6545,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6549,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 537  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[234]))(3,*((C_word*)lf[234]+1),t5,((C_word*)t0)[2]);}

/* k6547 in k6563 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 537  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6147(3,t2,((C_word*)t0)[2],t1);}

/* k6543 in k6563 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6545,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6537,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[233],((C_word*)t0)[2],t2);}

/* f_6537 in k6543 in k6563 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6537,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6501 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6504,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[231],((C_word*)t0)[2],t1);}

/* f_6504 in k6501 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6504,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* f_6475 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6475,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6446 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6449,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6449 in k6446 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6449,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6409 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_6411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6411,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6395,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6393 in k6409 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6396,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6396 in k6393 in k6409 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6396,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6361 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6355,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[116],((C_word*)t0)[2],t2);}

/* f_6355 in k6361 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6355,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6297 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6303,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6321 in k6297 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6322,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 514  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6147(3,t4,t1,t3);}

/* k6310 in k6297 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6320,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 515  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6147(3,t3,t2,((C_word*)t0)[2]);}

/* k6318 in k6310 in k6297 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 514  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6301 in k6297 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6304,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_6304 in k6301 in k6297 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6304,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* k6243 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_6245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6245,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 503  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,lf[221],lf[222],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6242(t2,((C_word*)t0)[2]);}}

/* k6246 in k6243 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 506  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[220]+1)))(3,*((C_word*)lf[220]+1),t2,((C_word*)t0)[2]);}

/* k6253 in k6246 in k6243 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6242(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k6240 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_6242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 499  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),((C_word*)t0)[2],t1);}

/* k6215 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6218,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* f_6218 in k6215 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6218,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* f_6189 in walk in ##compiler#build-node-graph in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6189,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* ##compiler#qnode in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6129,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6138,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[82],t3,C_SCHEME_END_OF_LIST);}

/* f_6138 in ##compiler#qnode in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6138,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* ##compiler#varnode in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6114,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6123,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[213],t3,C_SCHEME_END_OF_LIST);}

/* f_6123 in ##compiler#varnode in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6123,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* make-node in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6108,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* node-subexpressions in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6099,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[203]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6090,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[203]);
/* ##sys#block-set! */
t5=*((C_word*)lf[206]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6081,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[203]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6072,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[203]);
/* ##sys#block-set! */
t5=*((C_word*)lf[206]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6063,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[203]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6054,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[203]);
/* ##sys#block-set! */
t5=*((C_word*)lf[206]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6048,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[203]));}

/* f_6042 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6042,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[203],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5564,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5568,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5568(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6040,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 422  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),t4,C_retrieve(lf[200]),C_retrieve(lf[201]),C_retrieve(lf[126]));}}

/* k6038 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5568(t3,t2);}

/* k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5568,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 425  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5573,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5583,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 433  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[199]+1)))(3,*((C_word*)lf[199]+1),t14,t2);}}

/* k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5731,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5731(t6,t2,((C_word*)t0)[2]);}

/* loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5731(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5731,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 437  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[158]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5757(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[179]);
if(C_truep(t5)){
t6=t4;
f_5757(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t6)){
t7=t4;
f_5757(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t7)){
t8=t4;
f_5757(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t8)){
t9=t4;
f_5757(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t9)){
t10=t4;
f_5757(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t10)){
t11=t4;
f_5757(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t11)){
t12=t4;
f_5757(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t12)){
t13=t4;
f_5757(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t13)){
t14=t4;
f_5757(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t14)){
t15=t4;
f_5757(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t15)){
t16=t4;
f_5757(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t16)){
t17=t4;
f_5757(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t17)){
t18=t4;
f_5757(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t18)){
t19=t4;
f_5757(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t19)){
t20=t4;
f_5757(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t20)){
t21=t4;
f_5757(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t21)){
t22=t4;
f_5757(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t22)){
t23=t4;
f_5757(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[197]);
t24=t4;
f_5757(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[198])));}}}}}}}}}}}}}}}}}}}}

/* k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5757,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5772,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 441  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[157]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[157]);
t4=((C_word*)t0)[9];
f_5744(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[162]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[157]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5744(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 445  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[164]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[157]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5744(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 447  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[165]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5821,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 449  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[166]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5830(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[171]);
if(C_truep(t8)){
t9=t7;
f_5830(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[172]);
if(C_truep(t9)){
t10=t7;
f_5830(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[145]);
if(C_truep(t10)){
t11=t7;
f_5830(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t11)){
t12=t7;
f_5830(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t12)){
t13=t7;
f_5830(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t13)){
t14=t7;
f_5830(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t14)){
t15=t7;
f_5830(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
t16=t7;
f_5830(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[178])));}}}}}}}}}}}}}}

/* k5828 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5837,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 452  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[168]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 454  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[169]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 456  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 457  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[6],lf[170],t4);}}}}

/* k5859 in k5828 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5744(2,t3,t2);}

/* k5849 in k5828 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5744(2,t3,t2);}

/* k5835 in k5828 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5841,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 452  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[2]);}

/* k5839 in k5835 in k5828 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 452  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[167],((C_word*)t0)[2],t1);}

/* k5819 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5744(2,t3,t2);}

/* k5809 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5744(2,t3,t2);}

/* k5793 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5744(2,t3,t2);}

/* k5770 in k5755 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[159]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 441  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[160],t3);}

/* k5742 in k5739 in loop in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 458  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5731(t3,((C_word*)t0)[2],t2);}

/* k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[157]);
t5=t3;
f_5621(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5621(t4,C_SCHEME_FALSE);}}

/* k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5621,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5642,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[157]);
t4=t2;
f_5652(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5652(t3,C_SCHEME_FALSE);}}}

/* k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5652,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5673,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[157]);
t4=t2;
f_5683(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5683(t3,C_SCHEME_FALSE);}}}

/* k5681 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5683,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5704,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_5589(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5704 in k5681 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5704,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5692 in k5681 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5699,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5699 in k5692 in k5681 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5699,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5696 in k5692 in k5681 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 464  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[156],t2);}

/* f_5673 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5673,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5661 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5667,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5668,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5668 in k5661 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5668,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5665 in k5661 in k5650 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5667,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 462  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[155],t2);}

/* f_5642 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5642,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5630 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5637,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5637 in k5630 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5637,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5634 in k5630 in k5619 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 460  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[154],t2);}

/* k5587 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 465  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[153],t3);}
else{
t3=t2;
f_5592(2,t3,C_SCHEME_UNDEFINED);}}

/* k5590 in k5587 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 466  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[152],t3);}
else{
t3=t2;
f_5595(2,t3,C_SCHEME_UNDEFINED);}}

/* k5593 in k5590 in k5587 in k5584 in k5581 in a5572 in k5566 in ##compiler#display-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 467  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5551,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 404  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t2,C_retrieve(lf[142]));}

/* a5550 in ##compiler#display-line-number-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5551,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5562,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[149]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5560 in a5550 in ##compiler#display-line-number-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 406  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[147],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5521,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5527,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5527(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5527(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5527,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5537,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 400  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t4,((C_word*)t0)[2],t2,lf[145]);}}

/* k5535 in loop in ##compiler#find-lambda-container in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 401  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5527(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5485,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5492,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 392  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[142]),t3);}

/* k5490 in ##compiler#get-line-2 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5495(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5495(t3,C_SCHEME_FALSE);}}

/* k5493 in k5490 in ##compiler#get-line-2 in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_5495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 394  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 395  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5475,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 388  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t1,C_retrieve(lf[142]),t3,t2);}

/* ##compiler#count! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5418r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5418r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5418r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5422,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 376  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k5420 in ##compiler#count! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5452,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 381  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 382  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5450 in k5420 in ##compiler#count! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5366,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5370,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 368  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k5368 in ##compiler#collect! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5397,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 372  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 373  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5395 in k5368 in ##compiler#collect! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5320,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5324,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 360  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k5322 in ##compiler#put! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5346,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 364  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 365  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5344 in k5322 in ##compiler#put! in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5302r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5302r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5302r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5306,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 354  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k5304 in ##compiler#get-all in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5306,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5314,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 356  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5313 in k5304 in ##compiler#get-all in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5314,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5284,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5288,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 348  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k5286 in ##compiler#get in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5133,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5137,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5141,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5215,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[132]));}
else{
t4=t3;
f_5137(2,t4,C_SCHEME_UNDEFINED);}}

/* a5214 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5215,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5219,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5256,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[124],lf[131]);}

/* f_5256 in a5214 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5256r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5256r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5256r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5260,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5260(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5260(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5258 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5217 in a5214 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5219,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],C_retrieve(lf[129])))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5229,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[130],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5229 in k5217 in a5214 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5229r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5229r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5229r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5233,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5233(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5233(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5231 */
static void C_ccall f_5233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5139 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5182,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[128]));}

/* a5181 in k5139 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5182,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5187,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[124],lf[127]);}

/* f_5187 in a5181 in k5139 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5187r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5187r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5191,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5191(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5191(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5189 */
static void C_ccall f_5191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5142 in k5139 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5149,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[126]));}

/* a5148 in k5142 in k5139 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5149,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5154,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[124],lf[125]);}

/* f_5154 in a5148 in k5142 in k5139 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5154r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5154r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5158,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5158(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5158(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[123]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5156 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5135 in ##compiler#initialize-analysis-database in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4992,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[112]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4996,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 310  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t6);}

/* k4994 in ##compiler#expand-profile-lambda in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 311  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[113]));}

/* k4998 in k4994 in ##compiler#expand-profile-lambda in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[112]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[115],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[116],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[116],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[117],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[116],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[82],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[118],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[116],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[119],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[116],t35));}

/* ##compiler#process-lambda-documentation in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4989,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4882,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4889,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[107]+1)))(3,*((C_word*)lf[107]+1),t3,t4);}

/* a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4891,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4897,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4922,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t1,t3,t4);}

/* a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4975 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4976r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4976r(t0,t1,t2);}}

static void C_ccall f_4976r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4982,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4981 in a4975 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4927 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4932,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4960,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 295  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t2,((C_word*)t0)[2],t3);}

/* a4959 in a4927 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4966,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4974,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 295  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t3);}

/* k4972 in a4959 in a4927 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 295  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[102]))(6,*((C_word*)lf[102]+1),((C_word*)t0)[3],*((C_word*)lf[103]+1),*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* a4965 in a4959 in a4927 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4966,3,t0,t1,t2);}
/* support.scm: 295  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t1);}

/* k4930 in a4927 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4932,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[98]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4952 in k4930 in a4927 in a4921 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* a4896 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4897,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4902 in a4896 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 292  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4912 in a4902 in a4896 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 293  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 294  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4909 in a4902 in a4896 in a4890 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 290  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* k4887 in ##compiler#string->expr in k4879 in k4876 in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4781,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4787,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4787(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4787(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4787,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[90]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[91]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4815,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4815(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4864,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 279  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t7,t4);}}}}

/* k4862 in loop in ##compiler#canonicalize-begin-body in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4815(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[95])));}

/* k4813 in loop in ##compiler#canonicalize-begin-body in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4815,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 281  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4787(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 282  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[94]);}}

/* k4851 in k4813 in loop in ##compiler#canonicalize-begin-body in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 283  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4787(t8,t6,t7);}

/* k4839 in k4851 in k4813 in loop in ##compiler#canonicalize-begin-body in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* ##compiler#basic-literal? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4721,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4737,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 264  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t5,t2);}}}

/* k4735 in ##compiler#basic-literal? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 265  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[88]+1)))(3,*((C_word*)lf[88]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4743(2,t3,C_SCHEME_FALSE);}}}

/* k4777 in k4735 in ##compiler#basic-literal? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 265  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[2],C_retrieve(lf[86]),t1);}

/* k4741 in k4735 in ##compiler#basic-literal? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 267  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4756 in k4741 in k4735 in ##compiler#basic-literal? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 268  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4675,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4679,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4719,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 254  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t4,t2);}
else{
t4=t3;
f_4679(t4,C_SCHEME_FALSE);}}

/* k4717 in ##compiler#immediate? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4679(t2,(C_word)C_i_not(t1));}

/* k4677 in ##compiler#immediate? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4645,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4599,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[82],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4579,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4585,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 233  sort */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,t3);}

/* a4584 in ##compiler#sort-symbols in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4585,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4593,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 233  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t4,t2);}

/* k4591 in a4584 in ##compiler#sort-symbols in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4597,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 233  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2]);}

/* k4595 in k4591 in a4584 in ##compiler#sort-symbols in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 233  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[79]+1)))(4,*((C_word*)lf[79]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4548,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4554,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4554(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4554(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4554,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 229  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 230  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4568 in loop in ##compiler#follow-without-loop in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4569,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 230  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4554(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4485,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4499,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 219  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t5,t3);}}

/* k4497 in ##compiler#fold-inner in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4499,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4501(t5,((C_word*)t0)[2],t1);}

/* fold in k4497 in ##compiler#fold-inner in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4501,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4509(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4530,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 224  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4528 in fold in k4497 in ##compiler#fold-inner in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4530,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4509(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4507 in fold in k4497 in ##compiler#fold-inner in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4473,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[73]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 214  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[74]+1)))(3,*((C_word*)lf[74]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4426r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4426r(t0,t1,t2,t3);}}

static void C_ccall f_4426r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[66]))){
/* support.scm: 208  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[67]+1)))(2,*((C_word*)lf[67]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4442,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 209  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),t4,t2);}}

/* k4440 in ##compiler#check-and-open-input-file in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 209  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[68]+1)))(3,*((C_word*)lf[68]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4454(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4454(t5,(C_word)C_i_not(t4));}}}

/* k4452 in k4440 in ##compiler#check-and-open-input-file in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 210  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[69],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 211  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[70],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4419,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4412,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub326(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4356,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4360,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4410,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 189  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t4,t2);}

/* k4408 in ##compiler#valid-c-identifier? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4358 in ##compiler#valid-c-identifier? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4383,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 193  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4382 in k4358 in ##compiler#valid-c-identifier? in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4383,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4262,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4274,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4278,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4278,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4280(t5,((C_word*)t0)[2],t1);}

/* loop in k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4280,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[53]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4302,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4302(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4302(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[59])));}}}

/* k4300 in loop in k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4302,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4309(t3,lf[57]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4309(t4,(C_truep(t3)?lf[58]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 186  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4280(t4,t2,t3);}}

/* k4339 in k4300 in loop in k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4307 in k4300 in loop in k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4309,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 184  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4323 in k4307 in k4300 in loop in k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4311 in k4307 in k4300 in loop in k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4317,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 185  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4280(t4,t2,t3);}

/* k4315 in k4311 in k4307 in k4300 in loop in k4276 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 180  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[54]+1)))(6,*((C_word*)lf[54]+1),((C_word*)t0)[4],lf[55],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4272 in ##compiler#c-ify-string in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[52]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4218,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4224(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4224,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4248,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 166  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4246 in loop in ##compiler#build-lambda-list in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4193,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 160  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 161  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t3,lf[47],t2);}}}

/* k4214 in ##compiler#symbolify in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 161  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4172,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 155  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t1,t2);}
else{
/* support.scm: 156  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,lf[44],t2);}}}

/* ##compiler#posq in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4136,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4142,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4142(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static C_word C_fcall f_4142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4068,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4071,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4092,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4092(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4092,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 139  err */
t4=((C_word*)t0)[3];
f_4071(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 141  err */
t5=((C_word*)t0)[3];
f_4071(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 142  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4071,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 136  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k4077 in err in ##compiler#check-signature in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4083,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 137  map-llist */
((C_proc4)C_retrieve_symbol_proc(lf[36]))(4,*((C_word*)lf[36]+1),t2,C_retrieve(lf[39]),t3);}

/* k4081 in k4077 in err in ##compiler#check-signature in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 135  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}

/* map-llist in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4025,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4031,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4031(t7,t1,t3);}

/* loop in map-llist in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_4031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4031,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 130  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 131  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4052 in loop in map-llist in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4058,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 131  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4031(t4,t2,t3);}

/* k4056 in k4052 in loop in map-llist in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4022,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[30])));}

/* ##sys#syntax-error-hook in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3997r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3997r(t0,t1,t2,t3);}}

static void C_ccall f_3997r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4001,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 116  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k3999 in ##sys#syntax-error-hook in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t2,t1,lf[33],((C_word*)t0)[2]);}

/* k4002 in k3999 in ##sys#syntax-error-hook in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4014 in k4002 in k3999 in ##sys#syntax-error-hook in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4015,3,t0,t1,t2);}
/* fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t1,((C_word*)t0)[2],lf[32],t2);}

/* k4005 in k4002 in k3999 in ##sys#syntax-error-hook in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 119  print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[29]))(6,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[30]),lf[31]);}

/* k4008 in k4005 in k4002 in k3999 in ##sys#syntax-error-hook in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 120  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3978r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3978r(t0,t1,t2,t3);}}

static void C_ccall f_3978r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3982,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 109  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k3980 in quit in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3985,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[27],((C_word*)t0)[2]);}

/* k3993 in k3980 in quit in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3983 in k3980 in quit in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 111  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2]);}

/* k3986 in k3983 in k3980 in quit in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 112  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3949r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3949r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3949r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3956,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[24]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_3956(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3956(t6,C_SCHEME_FALSE);}}

/* k3954 in ##compiler#compiler-warning in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_fcall f_3956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 104  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3957 in k3954 in ##compiler#compiler-warning in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3962,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[22],((C_word*)t0)[2]);}

/* k3967 in k3957 in k3954 in ##compiler#compiler-warning in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3960 in k3957 in k3954 in ##compiler#compiler-warning in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 106  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3909r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3909r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3919,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 93   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t5,lf[19],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3917 in ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 96   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_3922(2,t3,C_SCHEME_UNDEFINED);}}

/* k3932 in k3917 in ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3939,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3938 in k3932 in k3917 in ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3939,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3947,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 97   force */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k3945 in a3938 in k3932 in k3917 in ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 97   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14],t1);}

/* k3920 in k3917 in ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k3923 in k3920 in k3917 in ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t2);}

/* k3926 in k3923 in k3920 in k3917 in ##compiler#debugging in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3882r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3882r(t0,t1,t2);}}

static void C_ccall f_3882r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3896,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 87   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 88   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k3894 in ##compiler#bomb in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3871 in k3868 in k3865 in k3862 in k3859 in k3856 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[682] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3858:support_scm",(void*)f_3858},
{"f_3861:support_scm",(void*)f_3861},
{"f_3864:support_scm",(void*)f_3864},
{"f_3867:support_scm",(void*)f_3867},
{"f_3870:support_scm",(void*)f_3870},
{"f_3873:support_scm",(void*)f_3873},
{"f_4878:support_scm",(void*)f_4878},
{"f_4881:support_scm",(void*)f_4881},
{"f_11863:support_scm",(void*)f_11863},
{"f_11877:support_scm",(void*)f_11877},
{"f_11881:support_scm",(void*)f_11881},
{"f_11892:support_scm",(void*)f_11892},
{"f_11904:support_scm",(void*)f_11904},
{"f_11912:support_scm",(void*)f_11912},
{"f_11916:support_scm",(void*)f_11916},
{"f_11875:support_scm",(void*)f_11875},
{"f_11866:support_scm",(void*)f_11866},
{"f_11869:support_scm",(void*)f_11869},
{"f_11850:support_scm",(void*)f_11850},
{"f_11855:support_scm",(void*)f_11855},
{"f_11839:support_scm",(void*)f_11839},
{"f_11844:support_scm",(void*)f_11844},
{"f_11833:support_scm",(void*)f_11833},
{"f_11805:support_scm",(void*)f_11805},
{"f_11809:support_scm",(void*)f_11809},
{"f_11784:support_scm",(void*)f_11784},
{"f_11788:support_scm",(void*)f_11788},
{"f_11751:support_scm",(void*)f_11751},
{"f_11756:support_scm",(void*)f_11756},
{"f_11760:support_scm",(void*)f_11760},
{"f_11718:support_scm",(void*)f_11718},
{"f_11723:support_scm",(void*)f_11723},
{"f_11727:support_scm",(void*)f_11727},
{"f_11694:support_scm",(void*)f_11694},
{"f_11625:support_scm",(void*)f_11625},
{"f_11629:support_scm",(void*)f_11629},
{"f_11634:support_scm",(void*)f_11634},
{"f_11638:support_scm",(void*)f_11638},
{"f_11689:support_scm",(void*)f_11689},
{"f_11668:support_scm",(void*)f_11668},
{"f_11680:support_scm",(void*)f_11680},
{"f_11683:support_scm",(void*)f_11683},
{"f_11656:support_scm",(void*)f_11656},
{"f_11592:support_scm",(void*)f_11592},
{"f_11602:support_scm",(void*)f_11602},
{"f_11605:support_scm",(void*)f_11605},
{"f_11490:support_scm",(void*)f_11490},
{"f_11499:support_scm",(void*)f_11499},
{"f_11586:support_scm",(void*)f_11586},
{"f_11503:support_scm",(void*)f_11503},
{"f_11581:support_scm",(void*)f_11581},
{"f_11506:support_scm",(void*)f_11506},
{"f_11576:support_scm",(void*)f_11576},
{"f_11509:support_scm",(void*)f_11509},
{"f_11512:support_scm",(void*)f_11512},
{"f_11518:support_scm",(void*)f_11518},
{"f_11571:support_scm",(void*)f_11571},
{"f_11521:support_scm",(void*)f_11521},
{"f_11536:support_scm",(void*)f_11536},
{"f_11544:support_scm",(void*)f_11544},
{"f_11554:support_scm",(void*)f_11554},
{"f_11539:support_scm",(void*)f_11539},
{"f_11527:support_scm",(void*)f_11527},
{"f_11494:support_scm",(void*)f_11494},
{"f_11484:support_scm",(void*)f_11484},
{"f_11438:support_scm",(void*)f_11438},
{"f_11457:support_scm",(void*)f_11457},
{"f_11468:support_scm",(void*)f_11468},
{"f_11464:support_scm",(void*)f_11464},
{"f_11426:support_scm",(void*)f_11426},
{"f_11432:support_scm",(void*)f_11432},
{"f_11414:support_scm",(void*)f_11414},
{"f_11418:support_scm",(void*)f_11418},
{"f_11335:support_scm",(void*)f_11335},
{"f_11354:support_scm",(void*)f_11354},
{"f_11379:support_scm",(void*)f_11379},
{"f_11383:support_scm",(void*)f_11383},
{"f_11385:support_scm",(void*)f_11385},
{"f_11392:support_scm",(void*)f_11392},
{"f_11405:support_scm",(void*)f_11405},
{"f_11409:support_scm",(void*)f_11409},
{"f_11338:support_scm",(void*)f_11338},
{"f_11342:support_scm",(void*)f_11342},
{"f_11348:support_scm",(void*)f_11348},
{"f_11329:support_scm",(void*)f_11329},
{"f_11285:support_scm",(void*)f_11285},
{"f_11297:support_scm",(void*)f_11297},
{"f_11301:support_scm",(void*)f_11301},
{"f_11305:support_scm",(void*)f_11305},
{"f_11293:support_scm",(void*)f_11293},
{"f_11276:support_scm",(void*)f_11276},
{"f_11270:support_scm",(void*)f_11270},
{"f_11264:support_scm",(void*)f_11264},
{"f_11252:support_scm",(void*)f_11252},
{"f_11256:support_scm",(void*)f_11256},
{"f_11259:support_scm",(void*)f_11259},
{"f_11214:support_scm",(void*)f_11214},
{"f_11218:support_scm",(void*)f_11218},
{"f_11221:support_scm",(void*)f_11221},
{"f_11228:support_scm",(void*)f_11228},
{"f_11172:support_scm",(void*)f_11172},
{"f_11181:support_scm",(void*)f_11181},
{"f_11143:support_scm",(void*)f_11143},
{"f_11153:support_scm",(void*)f_11153},
{"f_10946:support_scm",(void*)f_10946},
{"f_11125:support_scm",(void*)f_11125},
{"f_11074:support_scm",(void*)f_11074},
{"f_11119:support_scm",(void*)f_11119},
{"f_11123:support_scm",(void*)f_11123},
{"f_11077:support_scm",(void*)f_11077},
{"f_11082:support_scm",(void*)f_11082},
{"f_11086:support_scm",(void*)f_11086},
{"f_11080:support_scm",(void*)f_11080},
{"f_11037:support_scm",(void*)f_11037},
{"f_11041:support_scm",(void*)f_11041},
{"f_11050:support_scm",(void*)f_11050},
{"f_11054:support_scm",(void*)f_11054},
{"f_11044:support_scm",(void*)f_11044},
{"f_11002:support_scm",(void*)f_11002},
{"f_11008:support_scm",(void*)f_11008},
{"f_11035:support_scm",(void*)f_11035},
{"f_11021:support_scm",(void*)f_11021},
{"f_10955:support_scm",(void*)f_10955},
{"f_10961:support_scm",(void*)f_10961},
{"f_11000:support_scm",(void*)f_11000},
{"f_10982:support_scm",(void*)f_10982},
{"f_10759:support_scm",(void*)f_10759},
{"f_10941:support_scm",(void*)f_10941},
{"f_10928:support_scm",(void*)f_10928},
{"f_10934:support_scm",(void*)f_10934},
{"f_10762:support_scm",(void*)f_10762},
{"f_10922:support_scm",(void*)f_10922},
{"f_10766:support_scm",(void*)f_10766},
{"f_10917:support_scm",(void*)f_10917},
{"f_10769:support_scm",(void*)f_10769},
{"f_10912:support_scm",(void*)f_10912},
{"f_10772:support_scm",(void*)f_10772},
{"f_10781:support_scm",(void*)f_10781},
{"f_10875:support_scm",(void*)f_10875},
{"f_10887:support_scm",(void*)f_10887},
{"f_10845:support_scm",(void*)f_10845},
{"f_10856:support_scm",(void*)f_10856},
{"f_10836:support_scm",(void*)f_10836},
{"f_10822:support_scm",(void*)f_10822},
{"f_10800:support_scm",(void*)f_10800},
{"f_10806:support_scm",(void*)f_10806},
{"f_10810:support_scm",(void*)f_10810},
{"f_10666:support_scm",(void*)f_10666},
{"f_10672:support_scm",(void*)f_10672},
{"f_10753:support_scm",(void*)f_10753},
{"f_10676:support_scm",(void*)f_10676},
{"f_10748:support_scm",(void*)f_10748},
{"f_10679:support_scm",(void*)f_10679},
{"f_10732:support_scm",(void*)f_10732},
{"f_10719:support_scm",(void*)f_10719},
{"f_10718:support_scm",(void*)f_10718},
{"f_10700:support_scm",(void*)f_10700},
{"f_10694:support_scm",(void*)f_10694},
{"f_10670:support_scm",(void*)f_10670},
{"f_10374:support_scm",(void*)f_10374},
{"f_10570:support_scm",(void*)f_10570},
{"f_10591:support_scm",(void*)f_10591},
{"f_10064:support_scm",(void*)f_10064},
{"f_10368:support_scm",(void*)f_10368},
{"f_10076:support_scm",(void*)f_10076},
{"f_10086:support_scm",(void*)f_10086},
{"f_10104:support_scm",(void*)f_10104},
{"f_10138:support_scm",(void*)f_10138},
{"f_10067:support_scm",(void*)f_10067},
{"f_9745:support_scm",(void*)f_9745},
{"f_10058:support_scm",(void*)f_10058},
{"f_9751:support_scm",(void*)f_9751},
{"f_9761:support_scm",(void*)f_9761},
{"f_9770:support_scm",(void*)f_9770},
{"f_9782:support_scm",(void*)f_9782},
{"f_9794:support_scm",(void*)f_9794},
{"f_9800:support_scm",(void*)f_9800},
{"f_9834:support_scm",(void*)f_9834},
{"f_9705:support_scm",(void*)f_9705},
{"f_9739:support_scm",(void*)f_9739},
{"f_9711:support_scm",(void*)f_9711},
{"f_9715:support_scm",(void*)f_9715},
{"f_9674:support_scm",(void*)f_9674},
{"f_9687:support_scm",(void*)f_9687},
{"f_9678:support_scm",(void*)f_9678},
{"f_9643:support_scm",(void*)f_9643},
{"f_9656:support_scm",(void*)f_9656},
{"f_9647:support_scm",(void*)f_9647},
{"f_8596:support_scm",(void*)f_8596},
{"f_9637:support_scm",(void*)f_9637},
{"f_8602:support_scm",(void*)f_8602},
{"f_8608:support_scm",(void*)f_8608},
{"f_8637:support_scm",(void*)f_8637},
{"f_8656:support_scm",(void*)f_8656},
{"f_8675:support_scm",(void*)f_8675},
{"f_8745:support_scm",(void*)f_8745},
{"f_8764:support_scm",(void*)f_8764},
{"f_8846:support_scm",(void*)f_8846},
{"f_8885:support_scm",(void*)f_8885},
{"f_8904:support_scm",(void*)f_8904},
{"f_8923:support_scm",(void*)f_8923},
{"f_9003:support_scm",(void*)f_9003},
{"f_9088:support_scm",(void*)f_9088},
{"f_9163:support_scm",(void*)f_9163},
{"f_9197:support_scm",(void*)f_9197},
{"f_9267:support_scm",(void*)f_9267},
{"f_9200:support_scm",(void*)f_9200},
{"f_9006:support_scm",(void*)f_9006},
{"f_9037:support_scm",(void*)f_9037},
{"f_8926:support_scm",(void*)f_8926},
{"f_8767:support_scm",(void*)f_8767},
{"f_8798:support_scm",(void*)f_8798},
{"f_8678:support_scm",(void*)f_8678},
{"f_8709:support_scm",(void*)f_8709},
{"f_8560:support_scm",(void*)f_8560},
{"f_8564:support_scm",(void*)f_8564},
{"f_8575:support_scm",(void*)f_8575},
{"f_8581:support_scm",(void*)f_8581},
{"f_8585:support_scm",(void*)f_8585},
{"f_8567:support_scm",(void*)f_8567},
{"f_8521:support_scm",(void*)f_8521},
{"f_8533:support_scm",(void*)f_8533},
{"f_8540:support_scm",(void*)f_8540},
{"f_8543:support_scm",(void*)f_8543},
{"f_8546:support_scm",(void*)f_8546},
{"f_8549:support_scm",(void*)f_8549},
{"f_8552:support_scm",(void*)f_8552},
{"f_8555:support_scm",(void*)f_8555},
{"f_8527:support_scm",(void*)f_8527},
{"f_8435:support_scm",(void*)f_8435},
{"f_8444:support_scm",(void*)f_8444},
{"f_8450:support_scm",(void*)f_8450},
{"f_8497:support_scm",(void*)f_8497},
{"f_8492:support_scm",(void*)f_8492},
{"f_8439:support_scm",(void*)f_8439},
{"f_8414:support_scm",(void*)f_8414},
{"f_8424:support_scm",(void*)f_8424},
{"f_8383:support_scm",(void*)f_8383},
{"f_8389:support_scm",(void*)f_8389},
{"f_8396:support_scm",(void*)f_8396},
{"f_8399:support_scm",(void*)f_8399},
{"f_8261:support_scm",(void*)f_8261},
{"f_8377:support_scm",(void*)f_8377},
{"f_8265:support_scm",(void*)f_8265},
{"f_8285:support_scm",(void*)f_8285},
{"f_8366:support_scm",(void*)f_8366},
{"f_8289:support_scm",(void*)f_8289},
{"f_8361:support_scm",(void*)f_8361},
{"f_8360:support_scm",(void*)f_8360},
{"f_8343:support_scm",(void*)f_8343},
{"f_8298:support_scm",(void*)f_8298},
{"f_8338:support_scm",(void*)f_8338},
{"f_8337:support_scm",(void*)f_8337},
{"f_8329:support_scm",(void*)f_8329},
{"f_8328:support_scm",(void*)f_8328},
{"f_8160:support_scm",(void*)f_8160},
{"f_8166:support_scm",(void*)f_8166},
{"f_8255:support_scm",(void*)f_8255},
{"f_8170:support_scm",(void*)f_8170},
{"f_8250:support_scm",(void*)f_8250},
{"f_8173:support_scm",(void*)f_8173},
{"f_8182:support_scm",(void*)f_8182},
{"f_8209:support_scm",(void*)f_8209},
{"f_8208:support_scm",(void*)f_8208},
{"f_8196:support_scm",(void*)f_8196},
{"f_8204:support_scm",(void*)f_8204},
{"f_7940:support_scm",(void*)f_7940},
{"f_8134:support_scm",(void*)f_8134},
{"f_8154:support_scm",(void*)f_8154},
{"f_8144:support_scm",(void*)f_8144},
{"f_8149:support_scm",(void*)f_8149},
{"f_8148:support_scm",(void*)f_8148},
{"f_8140:support_scm",(void*)f_8140},
{"f_8015:support_scm",(void*)f_8015},
{"f_8127:support_scm",(void*)f_8127},
{"f_8122:support_scm",(void*)f_8122},
{"f_8114:support_scm",(void*)f_8114},
{"f_8109:support_scm",(void*)f_8109},
{"f_8037:support_scm",(void*)f_8037},
{"f_8101:support_scm",(void*)f_8101},
{"f_8044:support_scm",(void*)f_8044},
{"f_8050:support_scm",(void*)f_8050},
{"f_8081:support_scm",(void*)f_8081},
{"f_7972:support_scm",(void*)f_7972},
{"f_7994:support_scm",(void*)f_7994},
{"f_7943:support_scm",(void*)f_7943},
{"f_7967:support_scm",(void*)f_7967},
{"f_7871:support_scm",(void*)f_7871},
{"f_7877:support_scm",(void*)f_7877},
{"f_7883:support_scm",(void*)f_7883},
{"f_7887:support_scm",(void*)f_7887},
{"f_7907:support_scm",(void*)f_7907},
{"f_7908:support_scm",(void*)f_7908},
{"f_7912:support_scm",(void*)f_7912},
{"f_7896:support_scm",(void*)f_7896},
{"f_7669:support_scm",(void*)f_7669},
{"f_7700:support_scm",(void*)f_7700},
{"f_7869:support_scm",(void*)f_7869},
{"f_7704:support_scm",(void*)f_7704},
{"f_7712:support_scm",(void*)f_7712},
{"f_7719:support_scm",(void*)f_7719},
{"f_7861:support_scm",(void*)f_7861},
{"f_7855:support_scm",(void*)f_7855},
{"f_7856:support_scm",(void*)f_7856},
{"f_7851:support_scm",(void*)f_7851},
{"f_7743:support_scm",(void*)f_7743},
{"f_7832:support_scm",(void*)f_7832},
{"f_7752:support_scm",(void*)f_7752},
{"f_7761:support_scm",(void*)f_7761},
{"f_7823:support_scm",(void*)f_7823},
{"f_7815:support_scm",(void*)f_7815},
{"f_7773:support_scm",(void*)f_7773},
{"f_7776:support_scm",(void*)f_7776},
{"f_7794:support_scm",(void*)f_7794},
{"f_7783:support_scm",(void*)f_7783},
{"f_7707:support_scm",(void*)f_7707},
{"f_7673:support_scm",(void*)f_7673},
{"f_7679:support_scm",(void*)f_7679},
{"f_7692:support_scm",(void*)f_7692},
{"f_7684:support_scm",(void*)f_7684},
{"f_7636:support_scm",(void*)f_7636},
{"f_7642:support_scm",(void*)f_7642},
{"f_7658:support_scm",(void*)f_7658},
{"f_7659:support_scm",(void*)f_7659},
{"f_7585:support_scm",(void*)f_7585},
{"f_7591:support_scm",(void*)f_7591},
{"f_7630:support_scm",(void*)f_7630},
{"f_7599:support_scm",(void*)f_7599},
{"f_7625:support_scm",(void*)f_7625},
{"f_7607:support_scm",(void*)f_7607},
{"f_7620:support_scm",(void*)f_7620},
{"f_7619:support_scm",(void*)f_7619},
{"f_7615:support_scm",(void*)f_7615},
{"f_7611:support_scm",(void*)f_7611},
{"f_7508:support_scm",(void*)f_7508},
{"f_7579:support_scm",(void*)f_7579},
{"f_7578:support_scm",(void*)f_7578},
{"f_7512:support_scm",(void*)f_7512},
{"f_7570:support_scm",(void*)f_7570},
{"f_7569:support_scm",(void*)f_7569},
{"f_7515:support_scm",(void*)f_7515},
{"f_7561:support_scm",(void*)f_7561},
{"f_7560:support_scm",(void*)f_7560},
{"f_7518:support_scm",(void*)f_7518},
{"f_7529:support_scm",(void*)f_7529},
{"f_7474:support_scm",(void*)f_7474},
{"f_7480:support_scm",(void*)f_7480},
{"f_7494:support_scm",(void*)f_7494},
{"f_7498:support_scm",(void*)f_7498},
{"f_7253:support_scm",(void*)f_7253},
{"f_7257:support_scm",(void*)f_7257},
{"f_7265:support_scm",(void*)f_7265},
{"f_7465:support_scm",(void*)f_7465},
{"f_7269:support_scm",(void*)f_7269},
{"f_7460:support_scm",(void*)f_7460},
{"f_7272:support_scm",(void*)f_7272},
{"f_7455:support_scm",(void*)f_7455},
{"f_7275:support_scm",(void*)f_7275},
{"f_7439:support_scm",(void*)f_7439},
{"f_7450:support_scm",(void*)f_7450},
{"f_7443:support_scm",(void*)f_7443},
{"f_7444:support_scm",(void*)f_7444},
{"f_7380:support_scm",(void*)f_7380},
{"f_7384:support_scm",(void*)f_7384},
{"f_7387:support_scm",(void*)f_7387},
{"f_7413:support_scm",(void*)f_7413},
{"f_7429:support_scm",(void*)f_7429},
{"f_7421:support_scm",(void*)f_7421},
{"f_7405:support_scm",(void*)f_7405},
{"f_7398:support_scm",(void*)f_7398},
{"f_7399:support_scm",(void*)f_7399},
{"f_7340:support_scm",(void*)f_7340},
{"f_7343:support_scm",(void*)f_7343},
{"f_7361:support_scm",(void*)f_7361},
{"f_7354:support_scm",(void*)f_7354},
{"f_7355:support_scm",(void*)f_7355},
{"f_7324:support_scm",(void*)f_7324},
{"f_7316:support_scm",(void*)f_7316},
{"f_7309:support_scm",(void*)f_7309},
{"f_7310:support_scm",(void*)f_7310},
{"f_7288:support_scm",(void*)f_7288},
{"f_7259:support_scm",(void*)f_7259},
{"f_7140:support_scm",(void*)f_7140},
{"f_7146:support_scm",(void*)f_7146},
{"f_7158:support_scm",(void*)f_7158},
{"f_7162:support_scm",(void*)f_7162},
{"f_7165:support_scm",(void*)f_7165},
{"f_7245:support_scm",(void*)f_7245},
{"f_7229:support_scm",(void*)f_7229},
{"f_7215:support_scm",(void*)f_7215},
{"f_7207:support_scm",(void*)f_7207},
{"f_7191:support_scm",(void*)f_7191},
{"f_7195:support_scm",(void*)f_7195},
{"f_7170:support_scm",(void*)f_7170},
{"f_7183:support_scm",(void*)f_7183},
{"f_7152:support_scm",(void*)f_7152},
{"f_7086:support_scm",(void*)f_7086},
{"f_7092:support_scm",(void*)f_7092},
{"f_7118:support_scm",(void*)f_7118},
{"f_7122:support_scm",(void*)f_7122},
{"f_7110:support_scm",(void*)f_7110},
{"f_6753:support_scm",(void*)f_6753},
{"f_6759:support_scm",(void*)f_6759},
{"f_7080:support_scm",(void*)f_7080},
{"f_6763:support_scm",(void*)f_6763},
{"f_7075:support_scm",(void*)f_7075},
{"f_6766:support_scm",(void*)f_6766},
{"f_7070:support_scm",(void*)f_7070},
{"f_6769:support_scm",(void*)f_6769},
{"f_6778:support_scm",(void*)f_6778},
{"f_7012:support_scm",(void*)f_7012},
{"f_7042:support_scm",(void*)f_7042},
{"f_7038:support_scm",(void*)f_7038},
{"f_7019:support_scm",(void*)f_7019},
{"f_7023:support_scm",(void*)f_7023},
{"f_6950:support_scm",(void*)f_6950},
{"f_6999:support_scm",(void*)f_6999},
{"f_6968:support_scm",(void*)f_6968},
{"f_6976:support_scm",(void*)f_6976},
{"f_6926:support_scm",(void*)f_6926},
{"f_6893:support_scm",(void*)f_6893},
{"f_6872:support_scm",(void*)f_6872},
{"f_6868:support_scm",(void*)f_6868},
{"f_6852:support_scm",(void*)f_6852},
{"f_6864:support_scm",(void*)f_6864},
{"f_6860:support_scm",(void*)f_6860},
{"f_6806:support_scm",(void*)f_6806},
{"f_6802:support_scm",(void*)f_6802},
{"f_6785:support_scm",(void*)f_6785},
{"f_6144:support_scm",(void*)f_6144},
{"f_6748:support_scm",(void*)f_6748},
{"f_6751:support_scm",(void*)f_6751},
{"f_6147:support_scm",(void*)f_6147},
{"f_6736:support_scm",(void*)f_6736},
{"f_6737:support_scm",(void*)f_6737},
{"f_6586:support_scm",(void*)f_6586},
{"f_6643:support_scm",(void*)f_6643},
{"f_6692:support_scm",(void*)f_6692},
{"f_6687:support_scm",(void*)f_6687},
{"f_6664:support_scm",(void*)f_6664},
{"f_6671:support_scm",(void*)f_6671},
{"f_6678:support_scm",(void*)f_6678},
{"f_6668:support_scm",(void*)f_6668},
{"f_6655:support_scm",(void*)f_6655},
{"f_6656:support_scm",(void*)f_6656},
{"f_6637:support_scm",(void*)f_6637},
{"f_6623:support_scm",(void*)f_6623},
{"f_6624:support_scm",(void*)f_6624},
{"f_6601:support_scm",(void*)f_6601},
{"f_6602:support_scm",(void*)f_6602},
{"f_6565:support_scm",(void*)f_6565},
{"f_6549:support_scm",(void*)f_6549},
{"f_6545:support_scm",(void*)f_6545},
{"f_6537:support_scm",(void*)f_6537},
{"f_6503:support_scm",(void*)f_6503},
{"f_6504:support_scm",(void*)f_6504},
{"f_6475:support_scm",(void*)f_6475},
{"f_6448:support_scm",(void*)f_6448},
{"f_6449:support_scm",(void*)f_6449},
{"f_6411:support_scm",(void*)f_6411},
{"f_6395:support_scm",(void*)f_6395},
{"f_6396:support_scm",(void*)f_6396},
{"f_6363:support_scm",(void*)f_6363},
{"f_6355:support_scm",(void*)f_6355},
{"f_6299:support_scm",(void*)f_6299},
{"f_6322:support_scm",(void*)f_6322},
{"f_6312:support_scm",(void*)f_6312},
{"f_6320:support_scm",(void*)f_6320},
{"f_6303:support_scm",(void*)f_6303},
{"f_6304:support_scm",(void*)f_6304},
{"f_6245:support_scm",(void*)f_6245},
{"f_6248:support_scm",(void*)f_6248},
{"f_6255:support_scm",(void*)f_6255},
{"f_6242:support_scm",(void*)f_6242},
{"f_6217:support_scm",(void*)f_6217},
{"f_6218:support_scm",(void*)f_6218},
{"f_6189:support_scm",(void*)f_6189},
{"f_6129:support_scm",(void*)f_6129},
{"f_6138:support_scm",(void*)f_6138},
{"f_6114:support_scm",(void*)f_6114},
{"f_6123:support_scm",(void*)f_6123},
{"f_6108:support_scm",(void*)f_6108},
{"f_6099:support_scm",(void*)f_6099},
{"f_6090:support_scm",(void*)f_6090},
{"f_6081:support_scm",(void*)f_6081},
{"f_6072:support_scm",(void*)f_6072},
{"f_6063:support_scm",(void*)f_6063},
{"f_6054:support_scm",(void*)f_6054},
{"f_6048:support_scm",(void*)f_6048},
{"f_6042:support_scm",(void*)f_6042},
{"f_5564:support_scm",(void*)f_5564},
{"f_6040:support_scm",(void*)f_6040},
{"f_5568:support_scm",(void*)f_5568},
{"f_5573:support_scm",(void*)f_5573},
{"f_5583:support_scm",(void*)f_5583},
{"f_5731:support_scm",(void*)f_5731},
{"f_5741:support_scm",(void*)f_5741},
{"f_5757:support_scm",(void*)f_5757},
{"f_5830:support_scm",(void*)f_5830},
{"f_5861:support_scm",(void*)f_5861},
{"f_5851:support_scm",(void*)f_5851},
{"f_5837:support_scm",(void*)f_5837},
{"f_5841:support_scm",(void*)f_5841},
{"f_5821:support_scm",(void*)f_5821},
{"f_5811:support_scm",(void*)f_5811},
{"f_5795:support_scm",(void*)f_5795},
{"f_5772:support_scm",(void*)f_5772},
{"f_5744:support_scm",(void*)f_5744},
{"f_5586:support_scm",(void*)f_5586},
{"f_5621:support_scm",(void*)f_5621},
{"f_5652:support_scm",(void*)f_5652},
{"f_5683:support_scm",(void*)f_5683},
{"f_5704:support_scm",(void*)f_5704},
{"f_5694:support_scm",(void*)f_5694},
{"f_5699:support_scm",(void*)f_5699},
{"f_5698:support_scm",(void*)f_5698},
{"f_5673:support_scm",(void*)f_5673},
{"f_5663:support_scm",(void*)f_5663},
{"f_5668:support_scm",(void*)f_5668},
{"f_5667:support_scm",(void*)f_5667},
{"f_5642:support_scm",(void*)f_5642},
{"f_5632:support_scm",(void*)f_5632},
{"f_5637:support_scm",(void*)f_5637},
{"f_5636:support_scm",(void*)f_5636},
{"f_5589:support_scm",(void*)f_5589},
{"f_5592:support_scm",(void*)f_5592},
{"f_5595:support_scm",(void*)f_5595},
{"f_5545:support_scm",(void*)f_5545},
{"f_5551:support_scm",(void*)f_5551},
{"f_5562:support_scm",(void*)f_5562},
{"f_5521:support_scm",(void*)f_5521},
{"f_5527:support_scm",(void*)f_5527},
{"f_5537:support_scm",(void*)f_5537},
{"f_5485:support_scm",(void*)f_5485},
{"f_5492:support_scm",(void*)f_5492},
{"f_5495:support_scm",(void*)f_5495},
{"f_5475:support_scm",(void*)f_5475},
{"f_5418:support_scm",(void*)f_5418},
{"f_5422:support_scm",(void*)f_5422},
{"f_5452:support_scm",(void*)f_5452},
{"f_5366:support_scm",(void*)f_5366},
{"f_5370:support_scm",(void*)f_5370},
{"f_5397:support_scm",(void*)f_5397},
{"f_5320:support_scm",(void*)f_5320},
{"f_5324:support_scm",(void*)f_5324},
{"f_5346:support_scm",(void*)f_5346},
{"f_5302:support_scm",(void*)f_5302},
{"f_5306:support_scm",(void*)f_5306},
{"f_5314:support_scm",(void*)f_5314},
{"f_5284:support_scm",(void*)f_5284},
{"f_5288:support_scm",(void*)f_5288},
{"f_5133:support_scm",(void*)f_5133},
{"f_5215:support_scm",(void*)f_5215},
{"f_5256:support_scm",(void*)f_5256},
{"f_5260:support_scm",(void*)f_5260},
{"f_5219:support_scm",(void*)f_5219},
{"f_5229:support_scm",(void*)f_5229},
{"f_5233:support_scm",(void*)f_5233},
{"f_5141:support_scm",(void*)f_5141},
{"f_5182:support_scm",(void*)f_5182},
{"f_5187:support_scm",(void*)f_5187},
{"f_5191:support_scm",(void*)f_5191},
{"f_5144:support_scm",(void*)f_5144},
{"f_5149:support_scm",(void*)f_5149},
{"f_5154:support_scm",(void*)f_5154},
{"f_5158:support_scm",(void*)f_5158},
{"f_5137:support_scm",(void*)f_5137},
{"f_4992:support_scm",(void*)f_4992},
{"f_4996:support_scm",(void*)f_4996},
{"f_5000:support_scm",(void*)f_5000},
{"f_4989:support_scm",(void*)f_4989},
{"f_4882:support_scm",(void*)f_4882},
{"f_4891:support_scm",(void*)f_4891},
{"f_4922:support_scm",(void*)f_4922},
{"f_4976:support_scm",(void*)f_4976},
{"f_4982:support_scm",(void*)f_4982},
{"f_4928:support_scm",(void*)f_4928},
{"f_4960:support_scm",(void*)f_4960},
{"f_4974:support_scm",(void*)f_4974},
{"f_4966:support_scm",(void*)f_4966},
{"f_4932:support_scm",(void*)f_4932},
{"f_4954:support_scm",(void*)f_4954},
{"f_4897:support_scm",(void*)f_4897},
{"f_4903:support_scm",(void*)f_4903},
{"f_4914:support_scm",(void*)f_4914},
{"f_4911:support_scm",(void*)f_4911},
{"f_4889:support_scm",(void*)f_4889},
{"f_4781:support_scm",(void*)f_4781},
{"f_4787:support_scm",(void*)f_4787},
{"f_4864:support_scm",(void*)f_4864},
{"f_4815:support_scm",(void*)f_4815},
{"f_4853:support_scm",(void*)f_4853},
{"f_4841:support_scm",(void*)f_4841},
{"f_4721:support_scm",(void*)f_4721},
{"f_4737:support_scm",(void*)f_4737},
{"f_4779:support_scm",(void*)f_4779},
{"f_4743:support_scm",(void*)f_4743},
{"f_4758:support_scm",(void*)f_4758},
{"f_4675:support_scm",(void*)f_4675},
{"f_4719:support_scm",(void*)f_4719},
{"f_4679:support_scm",(void*)f_4679},
{"f_4645:support_scm",(void*)f_4645},
{"f_4599:support_scm",(void*)f_4599},
{"f_4579:support_scm",(void*)f_4579},
{"f_4585:support_scm",(void*)f_4585},
{"f_4593:support_scm",(void*)f_4593},
{"f_4597:support_scm",(void*)f_4597},
{"f_4548:support_scm",(void*)f_4548},
{"f_4554:support_scm",(void*)f_4554},
{"f_4569:support_scm",(void*)f_4569},
{"f_4485:support_scm",(void*)f_4485},
{"f_4499:support_scm",(void*)f_4499},
{"f_4501:support_scm",(void*)f_4501},
{"f_4530:support_scm",(void*)f_4530},
{"f_4509:support_scm",(void*)f_4509},
{"f_4473:support_scm",(void*)f_4473},
{"f_4426:support_scm",(void*)f_4426},
{"f_4442:support_scm",(void*)f_4442},
{"f_4454:support_scm",(void*)f_4454},
{"f_4419:support_scm",(void*)f_4419},
{"f_4412:support_scm",(void*)f_4412},
{"f_4356:support_scm",(void*)f_4356},
{"f_4410:support_scm",(void*)f_4410},
{"f_4360:support_scm",(void*)f_4360},
{"f_4383:support_scm",(void*)f_4383},
{"f_4262:support_scm",(void*)f_4262},
{"f_4278:support_scm",(void*)f_4278},
{"f_4280:support_scm",(void*)f_4280},
{"f_4302:support_scm",(void*)f_4302},
{"f_4341:support_scm",(void*)f_4341},
{"f_4309:support_scm",(void*)f_4309},
{"f_4325:support_scm",(void*)f_4325},
{"f_4313:support_scm",(void*)f_4313},
{"f_4317:support_scm",(void*)f_4317},
{"f_4274:support_scm",(void*)f_4274},
{"f_4218:support_scm",(void*)f_4218},
{"f_4224:support_scm",(void*)f_4224},
{"f_4248:support_scm",(void*)f_4248},
{"f_4193:support_scm",(void*)f_4193},
{"f_4216:support_scm",(void*)f_4216},
{"f_4172:support_scm",(void*)f_4172},
{"f_4136:support_scm",(void*)f_4136},
{"f_4142:support_scm",(void*)f_4142},
{"f_4068:support_scm",(void*)f_4068},
{"f_4092:support_scm",(void*)f_4092},
{"f_4071:support_scm",(void*)f_4071},
{"f_4079:support_scm",(void*)f_4079},
{"f_4083:support_scm",(void*)f_4083},
{"f_4025:support_scm",(void*)f_4025},
{"f_4031:support_scm",(void*)f_4031},
{"f_4054:support_scm",(void*)f_4054},
{"f_4058:support_scm",(void*)f_4058},
{"f_4022:support_scm",(void*)f_4022},
{"f_3997:support_scm",(void*)f_3997},
{"f_4001:support_scm",(void*)f_4001},
{"f_4004:support_scm",(void*)f_4004},
{"f_4015:support_scm",(void*)f_4015},
{"f_4007:support_scm",(void*)f_4007},
{"f_4010:support_scm",(void*)f_4010},
{"f_3978:support_scm",(void*)f_3978},
{"f_3982:support_scm",(void*)f_3982},
{"f_3995:support_scm",(void*)f_3995},
{"f_3985:support_scm",(void*)f_3985},
{"f_3988:support_scm",(void*)f_3988},
{"f_3949:support_scm",(void*)f_3949},
{"f_3956:support_scm",(void*)f_3956},
{"f_3959:support_scm",(void*)f_3959},
{"f_3969:support_scm",(void*)f_3969},
{"f_3962:support_scm",(void*)f_3962},
{"f_3909:support_scm",(void*)f_3909},
{"f_3919:support_scm",(void*)f_3919},
{"f_3934:support_scm",(void*)f_3934},
{"f_3939:support_scm",(void*)f_3939},
{"f_3947:support_scm",(void*)f_3947},
{"f_3922:support_scm",(void*)f_3922},
{"f_3925:support_scm",(void*)f_3925},
{"f_3928:support_scm",(void*)f_3928},
{"f_3882:support_scm",(void*)f_3882},
{"f_3896:support_scm",(void*)f_3896},
{"f_3877:support_scm",(void*)f_3877},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
