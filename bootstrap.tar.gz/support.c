/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-05-02 09:52
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   SVN rev. 10674	compiled 2008-04-30 on debian (Linux)
   command line: support.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[504];
static double C_possibly_force_alignment;


/* from k2008 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k2001 */
static C_word C_fcall stub94(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub94(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8900)
static void C_ccall f_8900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8795)
static void C_fcall f_8795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8800)
static void C_ccall f_8800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8840)
static void C_fcall f_8840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8856)
static void C_ccall f_8856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8810)
static void C_ccall f_8810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8789)
static void C_ccall f_8789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8776)
static void C_ccall f_8776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_fcall f_8766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8746)
static void C_ccall f_8746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8721)
static void C_ccall f_8721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8729)
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8630)
static void C_ccall f_8630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8634)
static void C_ccall f_8634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8639)
static void C_fcall f_8639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8685)
static void C_ccall f_8685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8661)
static void C_ccall f_8661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static void C_ccall f_8618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8518)
static void C_ccall f_8518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8527)
static void C_fcall f_8527(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8549)
static void C_ccall f_8549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8572)
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8567)
static void C_ccall f_8567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_ccall f_8522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8443)
static void C_fcall f_8443(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8455)
static void C_ccall f_8455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8466)
static void C_ccall f_8466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8416)
static void C_ccall f_8416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_fcall f_8383(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8390)
static void C_ccall f_8390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8403)
static void C_ccall f_8403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8407)
static void C_ccall f_8407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8336)
static void C_fcall f_8336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8346)
static void C_ccall f_8346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8283)
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8283)
static void C_ccall f_8283r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8291)
static void C_ccall f_8291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_ccall f_8245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8161)
static void C_ccall f_8161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8170)
static void C_fcall f_8170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8132)
static void C_ccall f_8132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8142)
static void C_fcall f_8142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7935)
static void C_ccall f_7935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8066)
static void C_ccall f_8066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8026)
static void C_fcall f_8026(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8030)
static void C_ccall f_8030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8039)
static void C_ccall f_8039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8033)
static void C_ccall f_8033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7991)
static void C_fcall f_7991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7997)
static void C_fcall f_7997(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_fcall f_7944(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7950)
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7989)
static void C_ccall f_7989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7971)
static void C_ccall f_7971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7933)
static void C_ccall f_7933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_fcall f_7920(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7926)
static void C_ccall f_7926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7779)
static void C_fcall f_7779(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7798)
static void C_fcall f_7798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7882)
static void C_ccall f_7882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7894)
static void C_ccall f_7894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7829)
static void C_fcall f_7829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7759)
static void C_fcall f_7759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_fcall f_7732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_fcall f_7726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7635)
static void C_fcall f_7635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_fcall f_7594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_fcall f_7547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static C_word C_fcall f_7525(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7134)
static void C_fcall f_7134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7186)
static void C_fcall f_7186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_fcall f_7115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6809)
static void C_fcall f_6809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_fcall f_6818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_fcall f_6830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_fcall f_6842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6882)
static void C_fcall f_6882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_fcall f_6726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6695)
static void C_fcall f_6695(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5848)
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5873)
static void C_fcall f_5873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_fcall f_5888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_fcall f_5903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_fcall f_5941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5956)
static void C_fcall f_5956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5998)
static void C_fcall f_5998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6025)
static void C_fcall f_6025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_fcall f_6040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_fcall f_6055(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6099)
static void C_fcall f_6099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_fcall f_6144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6391)
static void C_fcall f_6391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_fcall f_6359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6247)
static void C_fcall f_6247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_fcall f_6215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static C_word C_fcall f_6210(C_word *a,C_word t0);
C_noret_decl(f_6102)
static void C_ccall f_6102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_fcall f_6117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_fcall f_5974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5651)
static void C_ccall f_5651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_fcall f_5603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5551)
static void C_fcall f_5551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5504)
static void C_fcall f_5504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5460)
static void C_fcall f_5460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5243)
static void C_fcall f_5243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5101)
static void C_fcall f_5101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_fcall f_5136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_fcall f_5058(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_fcall f_5029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static C_word C_fcall f_4985(C_word t0,C_word t1);
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4936)
static void C_fcall f_4936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_fcall f_4764(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_fcall f_4758(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_fcall f_4703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4617)
static void C_fcall f_4617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4342)
static void C_fcall f_4342(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_fcall f_4552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_fcall f_4498(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_fcall f_4185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4242)
static void C_fcall f_4242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_fcall f_4038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_fcall f_3897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_fcall f_3894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_fcall f_3313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_fcall f_3444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_fcall f_3501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_fcall f_3366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_fcall f_3387(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3272)
static void C_fcall f_3272(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_fcall f_3240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2638)
static void C_fcall f_2638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_fcall f_2647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_fcall f_2694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_fcall f_2587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_fcall f_2435(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2445)
static void C_fcall f_2445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_fcall f_2454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_fcall f_2478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2353)
static void C_fcall f_2353(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_fcall f_2381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_fcall f_2245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2140)
static void C_fcall f_2140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_fcall f_2087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_fcall f_2095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_fcall f_2040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_fcall f_1866(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1888)
static void C_fcall f_1888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_fcall f_1895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1810)
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1728)
static C_word C_fcall f_1728(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1678)
static void C_fcall f_1678(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1657)
static void C_fcall f_1657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1617)
static void C_fcall f_1617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1542)
static void C_fcall f_1542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8795)
static void C_fcall trf_8795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8795(t0,t1);}

C_noret_decl(trf_8840)
static void C_fcall trf_8840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8840(t0,t1,t2);}

C_noret_decl(trf_8766)
static void C_fcall trf_8766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8766(t0,t1);}

C_noret_decl(trf_8639)
static void C_fcall trf_8639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8639(t0,t1);}

C_noret_decl(trf_8527)
static void C_fcall trf_8527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8527(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8527(t0,t1,t2,t3);}

C_noret_decl(trf_8572)
static void C_fcall trf_8572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8572(t0,t1,t2);}

C_noret_decl(trf_8443)
static void C_fcall trf_8443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8443(t0,t1);}

C_noret_decl(trf_8383)
static void C_fcall trf_8383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8383(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8383(t0,t1,t2,t3);}

C_noret_decl(trf_8336)
static void C_fcall trf_8336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8336(t0,t1);}

C_noret_decl(trf_8170)
static void C_fcall trf_8170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8170(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8170(t0,t1,t2);}

C_noret_decl(trf_8142)
static void C_fcall trf_8142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8142(t0,t1);}

C_noret_decl(trf_8026)
static void C_fcall trf_8026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8026(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8026(t0,t1,t2,t3);}

C_noret_decl(trf_7991)
static void C_fcall trf_7991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7991(t0,t1,t2);}

C_noret_decl(trf_7997)
static void C_fcall trf_7997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7997(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7997(t0,t1,t2);}

C_noret_decl(trf_7944)
static void C_fcall trf_7944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7944(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7944(t0,t1,t2,t3);}

C_noret_decl(trf_7950)
static void C_fcall trf_7950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7950(t0,t1,t2);}

C_noret_decl(trf_7920)
static void C_fcall trf_7920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7920(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7920(t0,t1,t2,t3);}

C_noret_decl(trf_7779)
static void C_fcall trf_7779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7779(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7779(t0,t1,t2,t3);}

C_noret_decl(trf_7798)
static void C_fcall trf_7798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7798(t0,t1);}

C_noret_decl(trf_7829)
static void C_fcall trf_7829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7829(t0,t1);}

C_noret_decl(trf_7759)
static void C_fcall trf_7759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7759(t0,t1);}

C_noret_decl(trf_7732)
static void C_fcall trf_7732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7732(t0,t1);}

C_noret_decl(trf_7726)
static void C_fcall trf_7726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7726(t0,t1);}

C_noret_decl(trf_7635)
static void C_fcall trf_7635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7635(t0,t1);}

C_noret_decl(trf_7594)
static void C_fcall trf_7594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7594(t0,t1);}

C_noret_decl(trf_7547)
static void C_fcall trf_7547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7547(t0,t1);}

C_noret_decl(trf_7134)
static void C_fcall trf_7134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7134(t0,t1);}

C_noret_decl(trf_7186)
static void C_fcall trf_7186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7186(t0,t1);}

C_noret_decl(trf_7115)
static void C_fcall trf_7115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7115(t0,t1);}

C_noret_decl(trf_6809)
static void C_fcall trf_6809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6809(t0,t1);}

C_noret_decl(trf_6818)
static void C_fcall trf_6818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6818(t0,t1);}

C_noret_decl(trf_6830)
static void C_fcall trf_6830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6830(t0,t1);}

C_noret_decl(trf_6842)
static void C_fcall trf_6842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6842(t0,t1);}

C_noret_decl(trf_6882)
static void C_fcall trf_6882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6882(t0,t1);}

C_noret_decl(trf_6726)
static void C_fcall trf_6726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6726(t0,t1);}

C_noret_decl(trf_6695)
static void C_fcall trf_6695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6695(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6695(t0,t1);}

C_noret_decl(trf_5848)
static void C_fcall trf_5848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5848(t0,t1,t2);}

C_noret_decl(trf_5873)
static void C_fcall trf_5873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5873(t0,t1);}

C_noret_decl(trf_5888)
static void C_fcall trf_5888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5888(t0,t1);}

C_noret_decl(trf_5903)
static void C_fcall trf_5903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5903(t0,t1);}

C_noret_decl(trf_5941)
static void C_fcall trf_5941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5941(t0,t1);}

C_noret_decl(trf_5956)
static void C_fcall trf_5956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5956(t0,t1);}

C_noret_decl(trf_5998)
static void C_fcall trf_5998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5998(t0,t1);}

C_noret_decl(trf_6025)
static void C_fcall trf_6025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6025(t0,t1);}

C_noret_decl(trf_6040)
static void C_fcall trf_6040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6040(t0,t1);}

C_noret_decl(trf_6055)
static void C_fcall trf_6055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6055(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6055(t0,t1);}

C_noret_decl(trf_6099)
static void C_fcall trf_6099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6099(t0,t1);}

C_noret_decl(trf_6144)
static void C_fcall trf_6144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6144(t0,t1);}

C_noret_decl(trf_6391)
static void C_fcall trf_6391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6391(t0,t1);}

C_noret_decl(trf_6359)
static void C_fcall trf_6359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6359(t0,t1);}

C_noret_decl(trf_6247)
static void C_fcall trf_6247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6247(t0,t1);}

C_noret_decl(trf_6215)
static void C_fcall trf_6215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6215(t0,t1);}

C_noret_decl(trf_6117)
static void C_fcall trf_6117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6117(t0,t1);}

C_noret_decl(trf_5974)
static void C_fcall trf_5974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5974(t0,t1);}

C_noret_decl(trf_5603)
static void C_fcall trf_5603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5603(t0,t1);}

C_noret_decl(trf_5551)
static void C_fcall trf_5551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5551(t0,t1);}

C_noret_decl(trf_5504)
static void C_fcall trf_5504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5504(t0,t1);}

C_noret_decl(trf_5460)
static void C_fcall trf_5460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5460(t0,t1);}

C_noret_decl(trf_5243)
static void C_fcall trf_5243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5243(t0,t1);}

C_noret_decl(trf_5101)
static void C_fcall trf_5101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5101(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5101(t0,t1,t2,t3);}

C_noret_decl(trf_5136)
static void C_fcall trf_5136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5136(t0,t1,t2,t3);}

C_noret_decl(trf_5058)
static void C_fcall trf_5058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5058(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5058(t0,t1,t2,t3);}

C_noret_decl(trf_5029)
static void C_fcall trf_5029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5029(t0,t1,t2,t3);}

C_noret_decl(trf_4936)
static void C_fcall trf_4936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4936(t0,t1,t2);}

C_noret_decl(trf_4764)
static void C_fcall trf_4764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4764(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4764(t0,t1,t2,t3);}

C_noret_decl(trf_4758)
static void C_fcall trf_4758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4758(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4758(t0,t1,t2);}

C_noret_decl(trf_4703)
static void C_fcall trf_4703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4703(t0,t1);}

C_noret_decl(trf_4617)
static void C_fcall trf_4617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4617(t0,t1,t2);}

C_noret_decl(trf_4342)
static void C_fcall trf_4342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4342(t0,t1);}

C_noret_decl(trf_4552)
static void C_fcall trf_4552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4552(t0,t1);}

C_noret_decl(trf_4498)
static void C_fcall trf_4498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4498(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4498(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4185)
static void C_fcall trf_4185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4185(t0,t1);}

C_noret_decl(trf_4242)
static void C_fcall trf_4242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4242(t0,t1);}

C_noret_decl(trf_4038)
static void C_fcall trf_4038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4038(t0,t1);}

C_noret_decl(trf_3897)
static void C_fcall trf_3897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3897(t0,t1);}

C_noret_decl(trf_3894)
static void C_fcall trf_3894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3894(t0,t1);}

C_noret_decl(trf_3313)
static void C_fcall trf_3313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3313(t0,t1);}

C_noret_decl(trf_3418)
static void C_fcall trf_3418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3418(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3418(t0,t1,t2);}

C_noret_decl(trf_3444)
static void C_fcall trf_3444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3444(t0,t1);}

C_noret_decl(trf_3501)
static void C_fcall trf_3501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3501(t0,t1);}

C_noret_decl(trf_3366)
static void C_fcall trf_3366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3366(t0,t1);}

C_noret_decl(trf_3387)
static void C_fcall trf_3387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3387(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3387(t0,t1);}

C_noret_decl(trf_3272)
static void C_fcall trf_3272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3272(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3272(t0,t1,t2);}

C_noret_decl(trf_3240)
static void C_fcall trf_3240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3240(t0,t1);}

C_noret_decl(trf_2638)
static void C_fcall trf_2638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2638(t0,t1);}

C_noret_decl(trf_2647)
static void C_fcall trf_2647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2647(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2647(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2694)
static void C_fcall trf_2694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2694(t0,t1);}

C_noret_decl(trf_2587)
static void C_fcall trf_2587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2587(t0,t1);}

C_noret_decl(trf_2435)
static void C_fcall trf_2435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2435(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2435(t0,t1,t2,t3);}

C_noret_decl(trf_2445)
static void C_fcall trf_2445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2445(t0,t1);}

C_noret_decl(trf_2454)
static void C_fcall trf_2454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2454(t0,t1);}

C_noret_decl(trf_2478)
static void C_fcall trf_2478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2478(t0,t1);}

C_noret_decl(trf_2353)
static void C_fcall trf_2353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2353(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2353(t0,t1,t2);}

C_noret_decl(trf_2381)
static void C_fcall trf_2381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2381(t0,t1);}

C_noret_decl(trf_2245)
static void C_fcall trf_2245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2245(t0,t1);}

C_noret_decl(trf_2140)
static void C_fcall trf_2140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2140(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2140(t0,t1,t2,t3);}

C_noret_decl(trf_2087)
static void C_fcall trf_2087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2087(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2087(t0,t1,t2);}

C_noret_decl(trf_2095)
static void C_fcall trf_2095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2095(t0,t1);}

C_noret_decl(trf_2040)
static void C_fcall trf_2040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2040(t0,t1);}

C_noret_decl(trf_1866)
static void C_fcall trf_1866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1866(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1866(t0,t1,t2);}

C_noret_decl(trf_1888)
static void C_fcall trf_1888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1888(t0,t1);}

C_noret_decl(trf_1895)
static void C_fcall trf_1895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1895(t0,t1);}

C_noret_decl(trf_1810)
static void C_fcall trf_1810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1810(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1810(t0,t1,t2,t3);}

C_noret_decl(trf_1678)
static void C_fcall trf_1678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1678(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1678(t0,t1,t2,t3);}

C_noret_decl(trf_1657)
static void C_fcall trf_1657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1657(t0,t1);}

C_noret_decl(trf_1617)
static void C_fcall trf_1617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1617(t0,t1,t2);}

C_noret_decl(trf_1542)
static void C_fcall trf_1542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1542(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5104)){
C_save(t1);
C_rereclaim2(5104*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,504);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000C\012CHICKEN\012(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[5]=C_h_intern(&lf[5],30,"\010compilercompiler-cleanup-hook");
lf[6]=C_h_intern(&lf[6],26,"\010compilerdebugging-chicken");
lf[7]=C_h_intern(&lf[7],26,"\010compilerdisabled-warnings");
lf[8]=C_h_intern(&lf[8],13,"\010compilerbomb");
lf[9]=C_h_intern(&lf[9],5,"error");
lf[10]=C_h_intern(&lf[10],13,"string-append");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\034[internal compiler screwup] ");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\033[internal compiler screwup]");
lf[13]=C_h_intern(&lf[13],18,"\010compilerdebugging");
lf[14]=C_h_intern(&lf[14],12,"flush-output");
lf[15]=C_h_intern(&lf[15],7,"newline");
lf[16]=C_h_intern(&lf[16],6,"printf");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[18]=C_h_intern(&lf[18],5,"force");
lf[19]=C_h_intern(&lf[19],12,"\003sysfor-each");
lf[20]=C_h_intern(&lf[20],7,"display");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],7,"fprintf");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[26]=C_h_intern(&lf[26],18,"current-error-port");
lf[27]=C_h_intern(&lf[27],20,"\003syswarnings-enabled");
lf[28]=C_h_intern(&lf[28],4,"quit");
lf[29]=C_h_intern(&lf[29],4,"exit");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[31]=C_h_intern(&lf[31],21,"\003syssyntax-error-hook");
lf[32]=C_h_intern(&lf[32],16,"print-call-chain");
lf[33]=C_h_intern(&lf[33],18,"\003syscurrent-thread");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[37]=C_h_intern(&lf[37],12,"syntax-error");
lf[38]=C_h_intern(&lf[38],31,"\010compileremit-syntax-trace-info");
lf[39]=C_h_intern(&lf[39],9,"map-llist");
lf[40]=C_h_intern(&lf[40],24,"\010compilercheck-signature");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[42]=C_h_intern(&lf[42],18,"\010compilerreal-name");
lf[43]=C_h_intern(&lf[43],13,"\010compilerposq");
lf[44]=C_h_intern(&lf[44],18,"\010compilerstringify");
lf[45]=C_h_intern(&lf[45],14,"symbol->string");
lf[46]=C_h_intern(&lf[46],7,"sprintf");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[48]=C_h_intern(&lf[48],18,"\010compilersymbolify");
lf[49]=C_h_intern(&lf[49],14,"string->symbol");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[51]=C_h_intern(&lf[51],26,"\010compilerbuild-lambda-list");
lf[52]=C_h_intern(&lf[52],29,"\010compilerstring->c-identifier");
lf[53]=C_h_intern(&lf[53],24,"\003sysstring->c-identifier");
lf[54]=C_h_intern(&lf[54],21,"\010compilerc-ify-string");
lf[55]=C_h_intern(&lf[55],16,"\003syslist->string");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[57]=C_h_intern(&lf[57],6,"append");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[59]=C_h_intern(&lf[59],16,"\003sysstring->list");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[63]=C_h_intern(&lf[63],28,"\010compilervalid-c-identifier\077");
lf[64]=C_h_intern(&lf[64],3,"any");
lf[65]=C_h_intern(&lf[65],8,"->string");
lf[66]=C_h_intern(&lf[66],14,"\010compilerwords");
lf[67]=C_h_intern(&lf[67],21,"\010compilerwords->bytes");
lf[68]=C_h_intern(&lf[68],34,"\010compilercheck-and-open-input-file");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[70]=C_h_intern(&lf[70],18,"current-input-port");
lf[71]=C_h_intern(&lf[71],15,"open-input-file");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[74]=C_h_intern(&lf[74],12,"file-exists\077");
lf[75]=C_h_intern(&lf[75],33,"\010compilerclose-checked-input-file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[77]=C_h_intern(&lf[77],16,"close-input-port");
lf[78]=C_h_intern(&lf[78],19,"\010compilerfold-inner");
lf[79]=C_h_intern(&lf[79],7,"reverse");
lf[80]=C_h_intern(&lf[80],28,"\010compilerfollow-without-loop");
lf[81]=C_h_intern(&lf[81],18,"\010compilerconstant\077");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],29,"\010compilercollapsable-literal\077");
lf[84]=C_h_intern(&lf[84],19,"\010compilerimmediate\077");
lf[85]=C_h_intern(&lf[85],20,"\010compilerbig-fixnum\077");
lf[86]=C_h_intern(&lf[86],23,"\010compilerbasic-literal\077");
lf[87]=C_h_intern(&lf[87],5,"every");
lf[88]=C_h_intern(&lf[88],12,"vector->list");
lf[89]=C_h_intern(&lf[89],32,"\010compilercanonicalize-begin-body");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_h_intern(&lf[92],3,"let");
lf[93]=C_h_intern(&lf[93],6,"gensym");
lf[94]=C_h_intern(&lf[94],1,"t");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[96]=C_h_intern(&lf[96],34,"\010compilerextract-mutable-constants");
lf[97]=C_h_intern(&lf[97],12,"\004coreinclude");
lf[98]=C_h_intern(&lf[98],9,"\004coreset!");
lf[99]=C_h_intern(&lf[99],5,"cons*");
lf[100]=C_h_intern(&lf[100],7,"\003sysmap");
lf[101]=C_h_intern(&lf[101],2,"if");
lf[102]=C_h_intern(&lf[102],20,"\004corecompiletimeonly");
lf[103]=C_h_intern(&lf[103],19,"\004corecompiletimetoo");
lf[104]=C_h_intern(&lf[104],4,"set!");
lf[105]=C_h_intern(&lf[105],6,"lambda");
lf[106]=C_h_intern(&lf[106],11,"\004coreinline");
lf[107]=C_h_intern(&lf[107],20,"\004coreinline_allocate");
lf[108]=C_h_intern(&lf[108],18,"\004coreinline_update");
lf[109]=C_h_intern(&lf[109],19,"\004coreinline_loc_ref");
lf[110]=C_h_intern(&lf[110],22,"\004coreinline_loc_update");
lf[111]=C_h_intern(&lf[111],12,"\004coredeclare");
lf[112]=C_h_intern(&lf[112],14,"\004coreimmutable");
lf[113]=C_h_intern(&lf[113],14,"\004coreundefined");
lf[114]=C_h_intern(&lf[114],14,"\004coreprimitive");
lf[115]=C_h_intern(&lf[115],15,"\004coreinline_ref");
lf[116]=C_h_intern(&lf[116],10,"alist-cons");
lf[117]=C_h_intern(&lf[117],25,"\010compilermake-random-name");
lf[118]=C_h_intern(&lf[118],3,"map");
lf[119]=C_h_intern(&lf[119],4,"caar");
lf[120]=C_h_intern(&lf[120],5,"cadar");
lf[121]=C_h_intern(&lf[121],5,"cddar");
lf[122]=C_h_intern(&lf[122],4,"cdar");
lf[123]=C_h_intern(&lf[123],21,"\010compilerstring->expr");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[125]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[126]=C_h_intern(&lf[126],5,"begin");
lf[127]=C_h_intern(&lf[127],4,"read");
lf[128]=C_h_intern(&lf[128],6,"unfold");
lf[129]=C_h_intern(&lf[129],11,"eof-object\077");
lf[130]=C_h_intern(&lf[130],6,"values");
lf[131]=C_h_intern(&lf[131],22,"with-input-from-string");
lf[132]=C_h_intern(&lf[132],22,"with-exception-handler");
lf[133]=C_h_intern(&lf[133],30,"call-with-current-continuation");
lf[134]=C_h_intern(&lf[134],30,"\010compilerdecompose-lambda-list");
lf[135]=C_h_intern(&lf[135],25,"\003sysdecompose-lambda-list");
lf[136]=C_h_intern(&lf[136],37,"\010compilerprocess-lambda-documentation");
lf[137]=C_h_intern(&lf[137],30,"\010compilerexpand-profile-lambda");
lf[138]=C_h_intern(&lf[138],29,"\010compilerprofile-lambda-index");
lf[139]=C_h_intern(&lf[139],28,"\010compilerprofile-lambda-list");
lf[140]=C_h_intern(&lf[140],17,"\003sysprofile-entry");
lf[141]=C_h_intern(&lf[141],33,"\010compilerprofile-info-vector-name");
lf[142]=C_h_intern(&lf[142],5,"apply");
lf[143]=C_h_intern(&lf[143],16,"\003sysprofile-exit");
lf[144]=C_h_intern(&lf[144],16,"\003sysdynamic-wind");
lf[145]=C_h_intern(&lf[145],37,"\010compilerinitialize-analysis-database");
lf[146]=C_h_intern(&lf[146],13,"\010compilerput!");
lf[147]=C_h_intern(&lf[147],8,"constant");
lf[148]=C_h_intern(&lf[148],26,"\010compilermutable-constants");
lf[149]=C_h_intern(&lf[149],35,"\010compilerfoldable-extended-bindings");
lf[150]=C_h_intern(&lf[150],8,"foldable");
lf[151]=C_h_intern(&lf[151],16,"extended-binding");
lf[152]=C_h_intern(&lf[152],17,"extended-bindings");
lf[153]=C_h_intern(&lf[153],35,"\010compilerfoldable-standard-bindings");
lf[154]=C_h_intern(&lf[154],41,"\010compilerside-effecting-standard-bindings");
lf[155]=C_h_intern(&lf[155],14,"side-effecting");
lf[156]=C_h_intern(&lf[156],16,"standard-binding");
lf[157]=C_h_intern(&lf[157],17,"standard-bindings");
lf[158]=C_h_intern(&lf[158],12,"\010compilerget");
lf[159]=C_h_intern(&lf[159],18,"\003syshash-table-ref");
lf[160]=C_h_intern(&lf[160],16,"\010compilerget-all");
lf[161]=C_h_intern(&lf[161],10,"filter-map");
lf[162]=C_h_intern(&lf[162],19,"\003syshash-table-set!");
lf[163]=C_h_intern(&lf[163],17,"\010compilercollect!");
lf[164]=C_h_intern(&lf[164],15,"\010compilercount!");
lf[165]=C_h_intern(&lf[165],17,"\010compilerget-line");
lf[166]=C_h_intern(&lf[166],24,"\003sysline-number-database");
lf[167]=C_h_intern(&lf[167],19,"\010compilerget-line-2");
lf[168]=C_h_intern(&lf[168],30,"\010compilerfind-lambda-container");
lf[169]=C_h_intern(&lf[169],12,"contained-in");
lf[170]=C_h_intern(&lf[170],37,"\010compilerdisplay-line-number-database");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[172]=C_h_intern(&lf[172],3,"cdr");
lf[173]=C_h_intern(&lf[173],23,"\003syshash-table-for-each");
lf[174]=C_h_intern(&lf[174],34,"\010compilerdisplay-analysis-database");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[179]=C_h_intern(&lf[179],7,"unknown");
lf[180]=C_h_intern(&lf[180],8,"captured");
lf[181]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[183]=C_h_intern(&lf[183],5,"value");
lf[184]=C_h_intern(&lf[184],15,"potential-value");
lf[185]=C_h_intern(&lf[185],10,"replacable");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[187]=C_h_intern(&lf[187],10,"references");
lf[188]=C_h_intern(&lf[188],10,"call-sites");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[190]=C_h_intern(&lf[190],4,"home");
lf[191]=C_h_intern(&lf[191],8,"contains");
lf[192]=C_h_intern(&lf[192],8,"use-expr");
lf[193]=C_h_intern(&lf[193],12,"closure-size");
lf[194]=C_h_intern(&lf[194],14,"rest-parameter");
lf[195]=C_h_intern(&lf[195],16,"o-r/access-count");
lf[196]=C_h_intern(&lf[196],18,"captured-variables");
lf[197]=C_h_intern(&lf[197],13,"explicit-rest");
lf[198]=C_h_intern(&lf[198],8,"assigned");
lf[199]=C_h_intern(&lf[199],5,"boxed");
lf[200]=C_h_intern(&lf[200],6,"global");
lf[201]=C_h_intern(&lf[201],12,"contractable");
lf[202]=C_h_intern(&lf[202],16,"assigned-locally");
lf[203]=C_h_intern(&lf[203],11,"collapsable");
lf[204]=C_h_intern(&lf[204],9,"removable");
lf[205]=C_h_intern(&lf[205],9,"undefined");
lf[206]=C_h_intern(&lf[206],9,"replacing");
lf[207]=C_h_intern(&lf[207],6,"unused");
lf[208]=C_h_intern(&lf[208],6,"simple");
lf[209]=C_h_intern(&lf[209],9,"inlinable");
lf[210]=C_h_intern(&lf[210],13,"inline-export");
lf[211]=C_h_intern(&lf[211],21,"has-unused-parameters");
lf[212]=C_h_intern(&lf[212],12,"customizable");
lf[213]=C_h_intern(&lf[213],10,"boxed-rest");
lf[214]=C_h_intern(&lf[214],5,"write");
lf[215]=C_h_intern(&lf[215],34,"\010compilerdefault-standard-bindings");
lf[216]=C_h_intern(&lf[216],34,"\010compilerdefault-extended-bindings");
lf[217]=C_h_intern(&lf[217],26,"\010compilerinternal-bindings");
lf[218]=C_h_intern(&lf[218],9,"make-node");
lf[219]=C_h_intern(&lf[219],4,"node");
lf[220]=C_h_intern(&lf[220],5,"node\077");
lf[221]=C_h_intern(&lf[221],15,"node-class-set!");
lf[222]=C_h_intern(&lf[222],14,"\003sysblock-set!");
lf[223]=C_h_intern(&lf[223],10,"node-class");
lf[224]=C_h_intern(&lf[224],20,"node-parameters-set!");
lf[225]=C_h_intern(&lf[225],15,"node-parameters");
lf[226]=C_h_intern(&lf[226],24,"node-subexpressions-set!");
lf[227]=C_h_intern(&lf[227],19,"node-subexpressions");
lf[228]=C_h_intern(&lf[228],16,"\010compilervarnode");
lf[229]=C_h_intern(&lf[229],13,"\004corevariable");
lf[230]=C_h_intern(&lf[230],14,"\010compilerqnode");
lf[231]=C_h_intern(&lf[231],25,"\010compilerbuild-node-graph");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[233]=C_h_intern(&lf[233],15,"\004coreglobal-ref");
lf[234]=C_h_intern(&lf[234],8,"truncate");
lf[235]=C_h_intern(&lf[235],4,"type");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[237]=C_h_intern(&lf[237],6,"fixnum");
lf[238]=C_h_intern(&lf[238],11,"number-type");
lf[239]=C_h_intern(&lf[239],6,"unzip1");
lf[240]=C_h_intern(&lf[240],13,"\004corecallunit");
lf[241]=C_h_intern(&lf[241],9,"\004coreproc");
lf[242]=C_h_intern(&lf[242],29,"\004coreforeign-callback-wrapper");
lf[243]=C_h_intern(&lf[243],5,"sixth");
lf[244]=C_h_intern(&lf[244],5,"fifth");
lf[245]=C_h_intern(&lf[245],8,"\004coreapp");
lf[246]=C_h_intern(&lf[246],9,"\004corecall");
lf[247]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[248]=C_h_intern(&lf[248],24,"\010compilersource-filename");
lf[249]=C_h_intern(&lf[249],28,"\003syssymbol->qualified-string");
lf[250]=C_h_intern(&lf[250],34,"\010compileralways-bound-to-procedure");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[252]=C_h_intern(&lf[252],1,"o");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[254]=C_h_intern(&lf[254],30,"\010compilerbuild-expression-tree");
lf[255]=C_h_intern(&lf[255],12,"\004coreclosure");
lf[256]=C_h_intern(&lf[256],4,"last");
lf[257]=C_h_intern(&lf[257],4,"list");
lf[258]=C_h_intern(&lf[258],7,"butlast");
lf[259]=C_h_intern(&lf[259],11,"\004corelambda");
lf[260]=C_h_intern(&lf[260],9,"\004corebind");
lf[261]=C_h_intern(&lf[261],10,"\004coreunbox");
lf[262]=C_h_intern(&lf[262],8,"\004coreref");
lf[263]=C_h_intern(&lf[263],11,"\004coreupdate");
lf[264]=C_h_intern(&lf[264],13,"\004coreupdate_i");
lf[265]=C_h_intern(&lf[265],8,"\004corebox");
lf[266]=C_h_intern(&lf[266],9,"\004corecond");
lf[267]=C_h_intern(&lf[267],21,"\010compilerfold-boolean");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[269]=C_h_intern(&lf[269],31,"\010compilerinline-lambda-bindings");
lf[270]=C_h_intern(&lf[270],8,"split-at");
lf[271]=C_h_intern(&lf[271],10,"fold-right");
lf[272]=C_h_intern(&lf[272],4,"take");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[274]=C_h_intern(&lf[274],34,"\010compilercopy-node-tree-and-rename");
lf[275]=C_h_intern(&lf[275],9,"alist-ref");
lf[276]=C_h_intern(&lf[276],3,"eq\077");
lf[277]=C_h_intern(&lf[277],18,"\010compilertree-copy");
lf[278]=C_h_intern(&lf[278],4,"cons");
lf[279]=C_h_intern(&lf[279],19,"\010compilercopy-node!");
lf[280]=C_h_intern(&lf[280],19,"\010compilermatch-node");
lf[281]=C_h_intern(&lf[281],1,"a");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[283]=C_h_intern(&lf[283],37,"\010compilerexpression-has-side-effects\077");
lf[284]=C_h_intern(&lf[284],24,"foreign-callback-stub-id");
lf[285]=C_h_intern(&lf[285],4,"find");
lf[286]=C_h_intern(&lf[286],22,"foreign-callback-stubs");
lf[287]=C_h_intern(&lf[287],28,"\010compilersimple-lambda-node\077");
lf[288]=C_h_intern(&lf[288],25,"\010compilerexport-dump-hook");
lf[289]=C_h_intern(&lf[289],30,"\010compilerdump-exported-globals");
lf[290]=C_h_intern(&lf[290],26,"\010compilerblock-compilation");
lf[291]=C_h_intern(&lf[291],8,"string<\077");
lf[292]=C_h_intern(&lf[292],4,"sort");
lf[293]=C_h_intern(&lf[293],20,"\010compilerexport-list");
lf[294]=C_h_intern(&lf[294],22,"\010compilerblock-globals");
lf[295]=C_h_intern(&lf[295],19,"with-output-to-file");
lf[296]=C_h_intern(&lf[296],31,"\010compilerdump-undefined-globals");
lf[297]=C_h_intern(&lf[297],29,"\010compilercheck-global-exports");
lf[298]=C_h_intern(&lf[298],3,"var");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000,exported global variable `~S\047 is not defined");
lf[300]=C_h_intern(&lf[300],6,"delete");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\0005exported global variable `~S\047 is used but not defined");
lf[302]=C_h_intern(&lf[302],29,"\010compilercheck-global-imports");
lf[303]=C_h_intern(&lf[303],5,"redef");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\0000redefinition of imported variable `~s\047 from `~s\047");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000#variable `~s\047 used but not imported");
lf[306]=C_h_intern(&lf[306],8,"keyword\077");
lf[307]=C_h_intern(&lf[307],21,"\010compilerimport-table");
lf[308]=C_h_intern(&lf[308],27,"\010compilerexport-import-hook");
lf[309]=C_h_intern(&lf[309],28,"\010compilerlookup-exports-file");
lf[310]=C_h_intern(&lf[310],9,"read-file");
lf[311]=C_h_intern(&lf[311],21,"\010compilerverbose-mode");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\035loading exports file ~a ...~%");
lf[313]=C_h_intern(&lf[313],28,"\003sysresolve-include-filename");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\010.exports");
lf[315]=C_h_intern(&lf[315],36,"\010compilercompute-database-statistics");
lf[316]=C_h_intern(&lf[316],29,"\010compilercurrent-program-size");
lf[317]=C_h_intern(&lf[317],30,"\010compileroriginal-program-size");
lf[318]=C_h_intern(&lf[318],33,"\010compilerprint-program-statistics");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[325]=C_h_intern(&lf[325],1,"s");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[327]=C_h_intern(&lf[327],35,"\010compilerpprint-expressions-to-file");
lf[328]=C_h_intern(&lf[328],17,"close-output-port");
lf[329]=C_h_intern(&lf[329],12,"pretty-print");
lf[330]=C_h_intern(&lf[330],19,"with-output-to-port");
lf[331]=C_h_intern(&lf[331],16,"open-output-file");
lf[332]=C_h_intern(&lf[332],19,"current-output-port");
lf[333]=C_h_intern(&lf[333],27,"\010compilerforeign-type-check");
lf[334]=C_h_intern(&lf[334],4,"char");
lf[335]=C_h_intern(&lf[335],13,"unsigned-char");
lf[336]=C_h_intern(&lf[336],6,"unsafe");
lf[337]=C_h_intern(&lf[337],25,"\003sysforeign-char-argument");
lf[338]=C_h_intern(&lf[338],3,"int");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-fixnum-argument");
lf[340]=C_h_intern(&lf[340],5,"float");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-flonum-argument");
lf[342]=C_h_intern(&lf[342],7,"pointer");
lf[343]=C_h_intern(&lf[343],26,"\003sysforeign-block-argument");
lf[344]=C_h_intern(&lf[344],15,"nonnull-pointer");
lf[345]=C_h_intern(&lf[345],8,"u8vector");
lf[346]=C_h_intern(&lf[346],34,"\003sysforeign-number-vector-argument");
lf[347]=C_h_intern(&lf[347],16,"nonnull-u8vector");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[349]=C_h_intern(&lf[349],7,"integer");
lf[350]=C_h_intern(&lf[350],28,"\003sysforeign-integer-argument");
lf[351]=C_h_intern(&lf[351],16,"unsigned-integer");
lf[352]=C_h_intern(&lf[352],37,"\003sysforeign-unsigned-integer-argument");
lf[353]=C_h_intern(&lf[353],9,"c-pointer");
lf[354]=C_h_intern(&lf[354],28,"\003sysforeign-pointer-argument");
lf[355]=C_h_intern(&lf[355],17,"nonnull-c-pointer");
lf[356]=C_h_intern(&lf[356],8,"c-string");
lf[357]=C_h_intern(&lf[357],17,"\003sysmake-c-string");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-string-argument");
lf[359]=C_h_intern(&lf[359],16,"nonnull-c-string");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],18,"\003syssymbol->string");
lf[362]=C_h_intern(&lf[362],4,"this");
lf[363]=C_h_intern(&lf[363],8,"slot-ref");
lf[364]=C_h_intern(&lf[364],3,"ref");
lf[365]=C_h_intern(&lf[365],8,"function");
lf[366]=C_h_intern(&lf[366],8,"instance");
lf[367]=C_h_intern(&lf[367],12,"instance-ref");
lf[368]=C_h_intern(&lf[368],16,"nonnull-instance");
lf[369]=C_h_intern(&lf[369],5,"const");
lf[370]=C_h_intern(&lf[370],4,"enum");
lf[371]=C_h_intern(&lf[371],27,"\010compilerforeign-type-table");
lf[372]=C_h_intern(&lf[372],17,"nonnull-c-string*");
lf[373]=C_h_intern(&lf[373],26,"nonnull-unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],9,"c-string*");
lf[375]=C_h_intern(&lf[375],18,"unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],13,"c-string-list");
lf[377]=C_h_intern(&lf[377],14,"c-string-list*");
lf[378]=C_h_intern(&lf[378],18,"unsigned-integer32");
lf[379]=C_h_intern(&lf[379],13,"unsigned-long");
lf[380]=C_h_intern(&lf[380],4,"long");
lf[381]=C_h_intern(&lf[381],9,"integer32");
lf[382]=C_h_intern(&lf[382],17,"nonnull-u16vector");
lf[383]=C_h_intern(&lf[383],16,"nonnull-s8vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s16vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-u32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-f32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f64vector");
lf[389]=C_h_intern(&lf[389],9,"u16vector");
lf[390]=C_h_intern(&lf[390],8,"s8vector");
lf[391]=C_h_intern(&lf[391],9,"s16vector");
lf[392]=C_h_intern(&lf[392],9,"u32vector");
lf[393]=C_h_intern(&lf[393],9,"s32vector");
lf[394]=C_h_intern(&lf[394],9,"f32vector");
lf[395]=C_h_intern(&lf[395],9,"f64vector");
lf[396]=C_h_intern(&lf[396],22,"nonnull-scheme-pointer");
lf[397]=C_h_intern(&lf[397],12,"nonnull-blob");
lf[398]=C_h_intern(&lf[398],19,"nonnull-byte-vector");
lf[399]=C_h_intern(&lf[399],11,"byte-vector");
lf[400]=C_h_intern(&lf[400],4,"blob");
lf[401]=C_h_intern(&lf[401],14,"scheme-pointer");
lf[402]=C_h_intern(&lf[402],6,"double");
lf[403]=C_h_intern(&lf[403],6,"number");
lf[404]=C_h_intern(&lf[404],12,"unsigned-int");
lf[405]=C_h_intern(&lf[405],5,"short");
lf[406]=C_h_intern(&lf[406],14,"unsigned-short");
lf[407]=C_h_intern(&lf[407],4,"byte");
lf[408]=C_h_intern(&lf[408],13,"unsigned-byte");
lf[409]=C_h_intern(&lf[409],5,"int32");
lf[410]=C_h_intern(&lf[410],14,"unsigned-int32");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[412]=C_h_intern(&lf[412],36,"\010compilerforeign-type-convert-result");
lf[413]=C_h_intern(&lf[413],38,"\010compilerforeign-type-convert-argument");
lf[414]=C_h_intern(&lf[414],27,"\010compilerfinal-foreign-type");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[416]=C_h_intern(&lf[416],37,"\010compilerestimate-foreign-result-size");
lf[417]=C_h_intern(&lf[417],9,"integer64");
lf[418]=C_h_intern(&lf[418],4,"bool");
lf[419]=C_h_intern(&lf[419],4,"void");
lf[420]=C_h_intern(&lf[420],13,"scheme-object");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[422]=C_h_intern(&lf[422],46,"\010compilerestimate-foreign-result-location-size");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[425]=C_h_intern(&lf[425],30,"\010compilerfinish-foreign-result");
lf[426]=C_h_intern(&lf[426],17,"\003syspeek-c-string");
lf[427]=C_h_intern(&lf[427],25,"\003syspeek-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],26,"\003syspeek-and-free-c-string");
lf[429]=C_h_intern(&lf[429],34,"\003syspeek-and-free-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],17,"\003sysintern-symbol");
lf[431]=C_h_intern(&lf[431],22,"\003syspeek-c-string-list");
lf[432]=C_h_intern(&lf[432],31,"\003syspeek-and-free-c-string-list");
lf[433]=C_h_intern(&lf[433],35,"\010tinyclosmake-instance-from-pointer");
lf[434]=C_h_intern(&lf[434],4,"make");
lf[435]=C_h_intern(&lf[435],28,"\010compilerscan-used-variables");
lf[436]=C_h_intern(&lf[436],28,"\010compilerscan-free-variables");
lf[437]=C_h_intern(&lf[437],11,"lset-adjoin");
lf[438]=C_h_intern(&lf[438],25,"\010compilertopological-sort");
lf[439]=C_h_intern(&lf[439],7,"colored");
lf[440]=C_h_intern(&lf[440],23,"\010compilerchop-separator");
lf[441]=C_h_intern(&lf[441],9,"substring");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[443]=C_h_intern(&lf[443],23,"\010compilerchop-extension");
lf[444]=C_h_intern(&lf[444],22,"\010compilerprint-version");
lf[445]=C_h_intern(&lf[445],5,"print");
lf[446]=C_h_intern(&lf[446],15,"chicken-version");
lf[447]=C_h_intern(&lf[447],6,"print*");
lf[448]=C_h_intern(&lf[448],9,"\003syserror");
lf[449]=C_h_intern(&lf[449],20,"\010compilerprint-usage");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\021\244Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012    -quiet               "
"       do not display compile information\012\012  File and pathname options:\012\012    -ou"
"tput-file FILENAME       specifies output-filename, default is \047out.c\047\012    -incl"
"ude-path PATHNAME      specifies alternative path for included files\012    -to-std"
"out                  write compiled file to stdout instead of file\012\012  Language o"
"ptions:\012\012    -feature SYMBOL             register feature identifier\012\012  Syntax r"
"elated options:\012\012    -case-insensitive           don\047t preserve case of read sym"
"bols\012    -keyword-style STYLE        allow alternative keyword syntax (none, pre"
"fix or suffix)\012    -run-time-macros            macros are made available at run-"
"time\012\012  Translation options:\012\012    -explicit-use               do not use units \047"
"library\047 and \047eval\047 by default\012    -check-syntax               stop compilation "
"after macro-expansion\012    -analyze-only               stop compilation after fir"
"st analysis pass\012\012  Debugging options:\012\012    -no-warnings                disable "
"warnings\012    -disable-warning CLASS      disable specific class of warnings\012    "
"-debug-level NUMBER         set level of available debugging information\012    -no"
"-trace                   disable tracing information\012    -profile               "
"     executable emits profiling information \012    -profile-name FILENAME      nam"
"e of the generated profile information file\012    -accumulate-profile         exec"
"utable emits profiling information in append mode\012    -no-lambda-info           "
"  omit additional procedure-information\012    -emit-exports FILENAME      write ex"
"ported toplevel variables to FILENAME\012    -check-imports              look for u"
"ndefined toplevel variables\012    -import FILENAME            read externally expo"
"rted symbols from FILENAME\012\012  Optimization options:\012\012    -optimize-level NUMBER "
"     enable certain sets of optimization options\012    -optimize-leaf-routines    "
" enable leaf routine optimization\012    -lambda-lift                enable lambda-"
"lifting\012    -no-usual-integrations      standard procedures may be redefined\012   "
" -unsafe                     disable safety checks\012    -block                   "
"   enable block-compilation\012    -disable-interrupts         disable interrupts i"
"n compiled code\012    -fixnum-arithmetic          assume all numbers are fixnums\012 "
"   -benchmark-mode             fixnum mode, no interrupts and opt.-level 3\012    -"
"disable-stack-overflow-checks  disables detection of stack-overflows.\012    -inlin"
"e                     enable inlining\012    -inline-limit               set inlini"
"ng threshold\012\012  Configuration options:\012\012    -unit NAME                  compile "
"file as a library unit\012    -uses NAME                  declare library unit as u"
"sed.\012    -heap-size NUMBER           specifies heap-size of compiled executable\012"
"    -heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-gr"
"owth PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage "
"PERCENTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER\012    -s"
"tack-size NUMBER          specifies nursery size of compiled executable\012    -ext"
"end FILENAME            load file before compilation commences\012    -prelude EXPR"
"ESSION         add expression to front of source file\012    -postlude EXPRESSION  "
"      add expression to end of source file\012    -prologue FILENAME          inclu"
"de file before main source file\012    -epilogue FILENAME          include file aft"
"er main source file\012    -dynamic                    compile as dynamically loada"
"ble code\012    -require-extension NAME     require extension NAME in compiled code"
"\012    -extension                  compile as extension (dynamic or static)\012\012  Obs"
"cure options:\012\012    -debug MODES                display debugging output for the "
"given modes\012    -unsafe-libraries           marks the generated file as being li"
"nked\012                                with the unsafe runtime system\012    -raw    "
"                    do not generate implicit init- and exit code\011\011\011       \012    -"
"emit-external-prototypes-first  emit protoypes for callbacks before foreign\012    "
"                            declarations\012");
lf[451]=C_h_intern(&lf[451],36,"\010compilermake-block-variable-literal");
lf[452]=C_h_intern(&lf[452],22,"block-variable-literal");
lf[453]=C_h_intern(&lf[453],32,"\010compilerblock-variable-literal\077");
lf[454]=C_h_intern(&lf[454],32,"block-variable-literal-name-set!");
lf[455]=C_h_intern(&lf[455],36,"\010compilerblock-variable-literal-name");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[457]=C_h_intern(&lf[457],6,"random");
lf[458]=C_h_intern(&lf[458],15,"current-seconds");
lf[459]=C_h_intern(&lf[459],23,"\010compilerset-real-name!");
lf[460]=C_h_intern(&lf[460],24,"\010compilerreal-name-table");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[462]=C_h_intern(&lf[462],19,"\010compilerreal-name2");
lf[463]=C_h_intern(&lf[463],32,"\010compilerdisplay-real-name-table");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[465]=C_h_intern(&lf[465],28,"\010compilersource-info->string");
lf[466]=C_h_intern(&lf[466],4,"conc");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[469]=C_h_intern(&lf[469],11,"make-string");
lf[470]=C_h_intern(&lf[470],3,"max");
lf[471]=C_h_intern(&lf[471],12,"string-null\077");
lf[472]=C_h_intern(&lf[472],19,"\010compilerdump-nodes");
lf[473]=C_h_intern(&lf[473],19,"\003syswrite-char/port");
lf[474]=C_h_intern(&lf[474],19,"\003sysstandard-output");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[478]=C_h_intern(&lf[478],18,"\003sysuser-read-hook");
lf[479]=C_h_intern(&lf[479],15,"foreign-declare");
lf[480]=C_h_intern(&lf[480],7,"declare");
lf[481]=C_h_intern(&lf[481],34,"\010compilerscan-sharp-greater-string");
lf[482]=C_h_intern(&lf[482],18,"\003sysread-char/port");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[484]=C_h_intern(&lf[484],17,"get-output-string");
lf[485]=C_h_intern(&lf[485],18,"open-output-string");
lf[486]=C_h_intern(&lf[486],35,"\010compilerprocess-custom-declaration");
lf[487]=C_h_intern(&lf[487],29,"\010compilercustom-declare-alist");
lf[488]=C_h_intern(&lf[488],31,"\010compileremit-control-file-item");
lf[489]=C_h_intern(&lf[489],25,"\010compilercsc-control-file");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\004~S~%");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\006#%csc\012");
lf[492]=C_h_intern(&lf[492],26,"pathname-replace-extension");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[494]=C_h_intern(&lf[494],32,"\010compilerregister-compiler-macro");
lf[495]=C_h_intern(&lf[495],29,"\010compilercompiler-macro-table");
lf[496]=C_h_intern(&lf[496],4,"eval");
lf[497]=C_h_intern(&lf[497],6,"\000whole");
lf[498]=C_h_intern(&lf[498],7,"call/cc");
lf[499]=C_h_intern(&lf[499],11,"make-vector");
lf[500]=C_h_intern(&lf[500],27,"condition-property-accessor");
lf[501]=C_h_intern(&lf[501],3,"exn");
lf[502]=C_h_intern(&lf[502],7,"message");
lf[503]=C_h_intern(&lf[503],19,"condition-predicate");
C_register_lf2(lf,504,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1443 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1446 in k1443 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1449 in k1446 in k1443 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate(&lf[3],lf[4]);
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1463,tmp=(C_word)a,a+=2,tmp));
t5=C_set_block_item(lf[6],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[7],0,C_SCHEME_END_OF_LIST);
t7=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1468,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1495,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1535,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1564,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1583,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[37]+1,C_retrieve(lf[31]));
t13=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1608,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1611,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1654,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1722,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1758,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1779,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1804,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[52]+1,C_retrieve(lf[53]));
t21=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1848,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1942,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1998,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2005,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2012,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2059,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2071,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2134,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2165,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2211,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2241,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2287,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2347,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2430,tmp=(C_word)a,a+=2,tmp));
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 310  condition-predicate */
t36=C_retrieve(lf[503]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,lf[501]);}

/* k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 311  condition-property-accessor */
t3=C_retrieve(lf[500]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[501],lf[502]);}

/* k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[134]+1,C_retrieve(lf[135]));
t4=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2908,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2911,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2968,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3029,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3047,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3065,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3111,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3163,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3220,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3230,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3266,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3290,tmp=(C_word)a,a+=2,tmp));
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3309,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3719,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3725,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3731,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3740,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[224]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3749,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3758,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3767,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3776,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3785,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3791,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3800,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3809,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4317,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4611,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4659,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4752,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4930,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4964,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[280]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5026,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5221,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5307,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5399,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5405,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5491,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5522,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5566,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5624,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5630,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5681,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5761,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5800,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5836,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6691,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6722,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6753,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6793,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7112,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[425]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7422,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[435]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7698,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[436]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7776,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7935,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8132,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[443]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8161,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[444]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8203,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[449]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8241,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[451]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8253,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[453]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8259,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[454]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8265,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[455]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8274,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8283,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[459]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8327,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8333,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[462]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8412,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[463]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8424,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[465]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8436,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[471]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8512,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[472]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8518,tmp=(C_word)a,a+=2,tmp));
t76=C_retrieve(lf[478]);
t77=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8605,a[2]=t76,tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[481]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8630,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[486]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8699,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[488]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8762,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[494]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8791,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8902,tmp=(C_word)a,a+=2,tmp));
t83=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t83+1)))(2,t83,C_SCHEME_UNDEFINED);}

/* ##compiler#big-fixnum? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8902,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8791,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8795,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[495]))){
t6=t5;
f_8795(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8900,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1485 make-vector */
t7=*((C_word*)lf[499]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k8898 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[495]+1,t1);
t3=((C_word*)t0)[2];
f_8795(t3,t2);}

/* k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8795,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1486 call/cc */
t3=*((C_word*)lf[498]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8800,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8804,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1488 gensym */
t4=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8802 in a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8804,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8807,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8840,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8840(t8,t4,((C_word*)t0)[2]);}

/* loop in k8802 in a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8840,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[497],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8856,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=t5;
f_8856(2,t7,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 1494 return */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8884,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* support.scm: 1497 loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8882 in loop in k8802 in a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8884,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8854 in loop in k8802 in a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cddr(((C_word*)t0)[4]));}

/* k8805 in k8802 in a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8810,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8814,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)((C_word*)t0)[3])[1]);
t5=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,lf[105],t5);
t7=(C_word)C_a_i_list(&a,2,lf[172],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_a_i_list(&a,3,lf[142],t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[105],t4,t8);
/* support.scm: 1501 eval */
t10=C_retrieve(lf[496]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,t9);}

/* k8812 in k8805 in k8802 in a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1498 ##sys#hash-table-set! */
t2=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[495]),((C_word*)t0)[2],t1);}

/* k8808 in k8805 in k8802 in a8799 in k8793 in ##compiler#register-compiler-macro in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#emit-control-file-item in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8762,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8766,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[489]))){
t4=t3;
f_8766(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8773,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8789,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1471 pathname-replace-extension */
t6=C_retrieve(lf[492]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[248]),lf[493]);}}

/* k8787 in ##compiler#emit-control-file-item in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1471 open-output-file */
t2=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8771 in ##compiler#emit-control-file-item in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8773,2,t0,t1);}
t2=C_mutate((C_word*)lf[489]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1472 display */
t4=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[491],C_retrieve(lf[489]));}

/* k8774 in k8771 in ##compiler#emit-control-file-item in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8776,2,t0,t1);}
t2=C_retrieve(lf[5]);
t3=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8778,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
f_8766(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k8774 in k8771 in ##compiler#emit-control-file-item in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8782,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1476 close-output-port */
t3=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[489]));}

/* k8780 in ##compiler#compiler-cleanup-hook in k8774 in k8771 in ##compiler#emit-control-file-item in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1477 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8764 in ##compiler#emit-control-file-item in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1478 fprintf */
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[489]),lf[490],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8699,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[487]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8721,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_8721(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8736,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1458 open-output-file */
t14=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k8734 in ##compiler#process-custom-declaration in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[487]));
t5=C_mutate((C_word*)lf[487]+1,t4);
t6=C_retrieve(lf[5]);
t7=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8746,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8760,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1466 cons* */
t9=C_retrieve(lf[99]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8758 in k8734 in ##compiler#process-custom-declaration in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1466 emit-control-file-item */
t2=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_8746 in k8734 in ##compiler#process-custom-declaration in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8750,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1464 close-output-port */
t3=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8748 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1465 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8719 in ##compiler#process-custom-declaration in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8721,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[20]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8729,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a8725 in k8719 in ##compiler#process-custom-declaration in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8729,3,t0,t1,t2);}
/* support.scm: 1467 g1304 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8630,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8634,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1428 open-output-string */
t4=C_retrieve(lf[485]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8634,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8639,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8639(t5,((C_word*)t0)[2]);}

/* loop in k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8639,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8641 in loop in k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8643,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1431 quit */
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[483]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8661,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1433 newline */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8694,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k8692 in k8641 in loop in k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1445 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8639(t2,((C_word*)t0)[2]);}

/* k8671 in k8641 in loop in k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8673,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1438 get-output-string */
t3=C_retrieve(lf[484]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8685,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k8683 in k8671 in k8641 in loop in k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8686 in k8683 in k8671 in k8641 in loop in k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1442 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8639(t2,((C_word*)t0)[2]);}

/* k8659 in k8641 in loop in k8632 in ##compiler#scan-sharp-greater-string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1434 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8639(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8605,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8615,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1425 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k8613 in ##sys#user-read-hook in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8618,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1423 scan-sharp-greater-string */
t3=C_retrieve(lf[481]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8616 in k8613 in ##sys#user-read-hook in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[479],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[480],t2));}

/* ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8518,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8522,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8527,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8527(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8527(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8527,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8540,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1401 make-string */
t11=*((C_word*)lf[469]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t2,C_make_character(32));}

/* k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8540,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8546,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1403 printf */
t4=C_retrieve(lf[16]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[477],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8549,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8598 in k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8599,3,t0,t1,t2);}
/* loop1249 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8527(t3,t1,((C_word*)t0)[2],t2);}

/* k8547 in k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8549,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8555,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8564,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1407 printf */
t6=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[476],t5);}
else{
t4=t3;
f_8555(2,t4,C_SCHEME_UNDEFINED);}}

/* k8562 in k8547 in k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8567,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8572,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8572(t6,t2,C_fix(5));}

/* do1263 in k8562 in k8547 in k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8572,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8582,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1410 printf */
t5=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[475],t4);}}

/* k8580 in do1263 in k8562 in k8547 in k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8572(t3,((C_word*)t0)[2],t2);}

/* k8565 in k8562 in k8547 in k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[474]+1));}

/* k8553 in k8547 in k8544 in k8538 in loop in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[474]+1));}

/* k8520 in ##compiler#dump-nodes in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1413 newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8512,3,t0,t1,t2);}
/* support.scm: 1391 string-null? */
t3=C_retrieve(lf[471]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#source-info->string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8436,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8443,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cdddr(t2);
t7=t3;
f_8443(t7,(C_word)C_i_nullp(t6));}
else{
t6=t3;
f_8443(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8443(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8443(t4,C_SCHEME_FALSE);}}

/* k8441 in ##compiler#source-info->string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8443,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8455,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1384 ->string */
t6=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* ->string */
t2=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k8453 in k8441 in ##compiler#source-info->string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8462,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1385 max */
t6=*((C_word*)lf[470]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k8464 in k8453 in k8441 in ##compiler#source-info->string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1385 make-string */
t2=*((C_word*)lf[469]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k8460 in k8453 in k8441 in ##compiler#source-info->string in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1385 conc */
t2=C_retrieve(lf[466]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[467],((C_word*)t0)[3],t1,lf[468],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8430,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1376 ##sys#hash-table-for-each */
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[460]));}

/* a8429 in ##compiler#display-real-name-table in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8430,4,t0,t1,t2,t3);}
/* support.scm: 1378 printf */
t4=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[464],t2,t3);}

/* ##compiler#real-name2 in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8412,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8416,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1372 ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[460]),t2);}

/* k8414 in ##compiler#real-name2 in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1373 real-name */
t2=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8333r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8333r(t0,t1,t2,t3);}}

static void C_ccall f_8333r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8336,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8352,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1356 resolve */
f_8336(t5,t2);}

/* k8350 in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8352,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1360 ##sys#symbol->qualified-string */
t5=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
/* support.scm: 1369 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1357 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8375 in k8350 in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8381,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1361 get */
t3=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[169]);}

/* k8379 in k8375 in k8350 in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8381,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8383,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8383(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k8379 in k8375 in k8350 in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8383(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8383,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1363 resolve */
f_8336(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k8388 in loop in k8379 in k8375 in k8350 in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8390,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8403,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1366 sprintf */
t4=C_retrieve(lf[46]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[461],((C_word*)t0)[4],t1);}}

/* k8401 in k8388 in loop in k8379 in k8375 in k8350 in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8407,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1367 get */
t3=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[169]);}

/* k8405 in k8401 in k8388 in loop in k8379 in k8375 in k8350 in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1366 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8383(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8336(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8336,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8340,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1351 ##sys#hash-table-ref */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[460]),t2);}

/* k8338 in resolve in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8340,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8346,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1353 ##sys#hash-table-ref */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[460]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k8344 in k8338 in resolve in ##compiler#real-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8327,4,t0,t1,t2,t3);}
/* support.scm: 1347 ##sys#hash-table-set! */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[460]),t2,t3);}

/* ##compiler#make-random-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_8283r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8283r(t0,t1,t2);}}

static void C_ccall f_8283r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8291,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1334 gensym */
t5=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_8295(2,t6,(C_word)C_i_car(t2));}
else{
/* support.scm: 1334 ##sys#error */
t6=*((C_word*)lf[448]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k8293 in ##compiler#make-random-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8299,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1335 current-seconds */
t3=C_retrieve(lf[458]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8297 in k8293 in ##compiler#make-random-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8303,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1336 random */
t3=C_retrieve(lf[457]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k8301 in k8297 in k8293 in ##compiler#make-random-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1333 sprintf */
t2=C_retrieve(lf[46]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[456],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8289 in ##compiler#make-random-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1332 string->symbol */
t2=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8274,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[452]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* block-variable-literal-name-set! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8265,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[452]);
/* support.scm: 1325 ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* ##compiler#block-variable-literal? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8259,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[452]));}

/* ##compiler#make-block-variable-literal in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8253,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[452],t2));}

/* ##compiler#print-usage in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8245,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1224 print-version */
t3=C_retrieve(lf[444]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8243 in ##compiler#print-usage in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8248,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1225 newline */
t3=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8246 in k8243 in ##compiler#print-usage in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1226 display */
t2=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[450]);}

/* ##compiler#print-version in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_8203r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8203r(t0,t1,t2);}}

static void C_ccall f_8203r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8207,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_8207(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_8207(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[448]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k8205 in ##compiler#print-version in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1220 print* */
t3=*((C_word*)lf[447]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[4]);}
else{
t3=t2;
f_8210(2,t3,C_SCHEME_UNDEFINED);}}

/* k8208 in k8205 in ##compiler#print-version in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8217,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1221 chicken-version */
t3=C_retrieve(lf[446]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k8215 in k8208 in k8205 in ##compiler#print-version in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1221 print */
t2=*((C_word*)lf[445]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8161,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8170,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8170(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8170,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1213 substring */
t6=*((C_word*)lf[441]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1214 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8132,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8142,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_8142(t7,(C_word)C_i_memq(t6,lf[442]));}
else{
t6=t5;
f_8142(t6,C_SCHEME_FALSE);}}

/* k8140 in ##compiler#chop-separator in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1206 substring */
t2=*((C_word*)lf[441]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7935,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7944,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7991,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8026,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8063,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8114,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a8113 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8114,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1188 insert */
t5=((C_word*)t0)[2];
f_7944(t5,t1,t3,t4);}

/* k8061 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8108,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1191 caar */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k8106 in k8061 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8112,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1191 cdar */
t3=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8110 in k8106 in k8061 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1191 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8026(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8064 in k8061 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8069,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a8070 in k8064 in k8061 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8071,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8075,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1193 lookup */
t5=((C_word*)t0)[2];
f_7991(t5,t3,t4);}

/* k8073 in a8070 in k8064 in k8061 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[439]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1195 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8026(t5,((C_word*)t0)[4],t3,t4);}}

/* k8067 in k8064 in k8061 in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_8026(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8026,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8030,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1176 insert */
t5=((C_word*)t0)[2];
f_7944(t5,t4,t2,lf[439]);}

/* k8028 in visit in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8033,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8038 in k8028 in visit in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8039,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8043,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1179 lookup */
t4=((C_word*)t0)[2];
f_7991(t4,t3,t2);}

/* k8041 in a8038 in k8028 in visit in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[439]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1181 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8026(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k8031 in k8028 in visit in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7991,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7997,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7997(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7997(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7997,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8010,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8024,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1171 caar */
t5=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k8022 in loop in lookup in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1171 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8008 in loop in lookup in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1171 cdar */
t2=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1172 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7997(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7944(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7944,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7950(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7950,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7989,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1165 caar */
t5=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7987 in loop in insert in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1165 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7969 in loop in insert in ##compiler#topological-sort in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1166 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7950(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7776,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7779,a[2]=t8,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7920,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7933,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1148 walk */
t12=((C_word*)t6)[1];
f_7779(t12,t11,t2,C_SCHEME_END_OF_LIST);}

/* k7931 in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7920(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7920,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7926,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a7925 in walkeach in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7926,3,t0,t1,t2);}
/* support.scm: 1146 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7779(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7779(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7779,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[82]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t7,a[8]=t9,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t10)){
t12=t11;
f_7798(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[113]);
if(C_truep(t12)){
t13=t11;
f_7798(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[114]);
if(C_truep(t13)){
t14=t11;
f_7798(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[241]);
t15=t11;
f_7798(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[115])));}}}}

/* k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[229]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[6]))){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7817,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1130 lset-adjoin */
t5=C_retrieve(lf[437]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[5])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[104]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7829,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[6]))){
t6=t5;
f_7829(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7843,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1133 lset-adjoin */
t7=C_retrieve(lf[437]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[92]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7852,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1136 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7779(t7,t5,t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[259]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7882,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1139 decompose-lambda-list */
t8=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[9],t6,t7);}
else{
/* support.scm: 1143 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7920(t6,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[6]);}}}}}}

/* a7881 in k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7882,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7894,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1142 append */
t7=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7892 in a7881 in k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1142 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7779(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7850 in k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7852,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7863,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1137 append */
t4=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7861 in k7850 in k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1137 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7779(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7841 in k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7829(t3,t2);}

/* k7827 in k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1134 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7779(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7815 in k7796 in walk in ##compiler#scan-free-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7698,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7702,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7704,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7704(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7704,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[229]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[104]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7726,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7732,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_7732(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_7732(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[82]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7759,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_7759(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[113]);
t12=t10;
f_7759(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[114])));}}}

/* k7757 in walk in ##compiler#scan-used-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k7730 in walk in ##compiler#scan-used-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7732,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_7726(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_7726(t2,C_SCHEME_UNDEFINED);}}

/* k7724 in walk in ##compiler#scan-used-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7700 in ##compiler#scan-used-variables in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[131],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7422,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[426],t3,t6));}
else{
t6=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[427],t3,t7));}
else{
t7=(C_word)C_eqp(t4,lf[374]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[428],t3,t9));}
else{
t9=(C_word)C_eqp(t4,lf[372]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t10)){
t11=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[429],t3,t11));}
else{
t11=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t11)){
t12=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t13=(C_word)C_a_i_list(&a,3,lf[426],t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,2,lf[430],t13));}
else{
t12=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t12)){
t13=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[431],t3,t13));}
else{
t13=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t13)){
t14=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[432],t3,t14));}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_eqp(t15,lf[366]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7547,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(t2);
t21=t17;
f_7547(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_7547(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_7547(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(t2);
t18=(C_word)C_eqp(t17,lf[367]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7594,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t21))){
t22=(C_word)C_i_cdddr(t2);
t23=t19;
f_7594(t23,(C_word)C_i_nullp(t22));}
else{
t22=t19;
f_7594(t22,C_SCHEME_FALSE);}}
else{
t21=t19;
f_7594(t21,C_SCHEME_FALSE);}}
else{
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7635,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_car(t2);
t21=(C_word)C_eqp(t20,lf[368]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t23))){
t24=(C_word)C_i_cdddr(t2);
t25=t19;
f_7635(t25,(C_word)C_i_nullp(t24));}
else{
t24=t19;
f_7635(t24,C_SCHEME_FALSE);}}
else{
t23=t19;
f_7635(t23,C_SCHEME_FALSE);}}
else{
t22=t19;
f_7635(t22,C_SCHEME_FALSE);}}}}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t3);}}}}}}}}}

/* k7633 in ##compiler#finish-foreign-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7635,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,lf[82],lf[362]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,4,lf[434],t3,t4,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7592 in ##compiler#finish-foreign-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1093 g1090 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7525(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7545 in ##compiler#finish-foreign-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1093 g1090 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7525(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g1090 in ##compiler#finish-foreign-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static C_word C_fcall f_7525(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_a_i_list(&a,3,lf[433],((C_word*)t0)[2],t1));}

/* ##compiler#estimate-foreign-result-location-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7112,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7115,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7124,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7416,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1057 follow-without-loop */
t6=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a7415 in ##compiler#estimate-foreign-result-location-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7416,2,t0,t1);}
/* support.scm: 1078 quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[424],((C_word*)t0)[2]);}

/* a7123 in ##compiler#estimate-foreign-result-location-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7124,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7134,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_7134(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_7134(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_7134(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_7134(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t10)){
t11=t6;
f_7134(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t11)){
t12=t6;
f_7134(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t12)){
t13=t6;
f_7134(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t13)){
t14=t6;
f_7134(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t14)){
t15=t6;
f_7134(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_7134(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_7134(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t17)){
t18=t6;
f_7134(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t18)){
t19=t6;
f_7134(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t19)){
t20=t6;
f_7134(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t20)){
t21=t6;
f_7134(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t21)){
t22=t6;
f_7134(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t22)){
t23=t6;
f_7134(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t23)){
t24=t6;
f_7134(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_7134(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[401]);
if(C_truep(t25)){
t26=t6;
f_7134(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[396]);
if(C_truep(t26)){
t27=t6;
f_7134(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t27)){
t28=t6;
f_7134(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t28)){
t29=t6;
f_7134(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t29)){
t30=t6;
f_7134(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t30)){
t31=t6;
f_7134(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t31)){
t32=t6;
f_7134(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t32)){
t33=t6;
f_7134(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t33)){
t34=t6;
f_7134(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t34)){
t35=t6;
f_7134(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t35)){
t36=t6;
f_7134(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[376]);
t37=t6;
f_7134(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[377])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7132 in a7123 in ##compiler#estimate-foreign-result-location-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7134,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1066 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[403]));
if(C_truep(t3)){
/* support.scm: 1068 words->bytes */
t4=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[6],C_fix(2));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1070 ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t5=t4;
f_7152(2,t5,C_SCHEME_FALSE);}}}}

/* k7150 in k7132 in a7123 in ##compiler#estimate-foreign-result-location-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1072 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[364]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_7186(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_7186(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_7186(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_7186(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
t9=t4;
f_7186(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[365])));}}}}}
else{
/* support.scm: 1077 err */
f_7115(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k7184 in k7150 in k7132 in a7123 in ##compiler#estimate-foreign-result-location-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1075 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(1));}
else{
/* support.scm: 1076 err */
f_7115(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_7115(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7115,NULL,2,t1,t2);}
/* support.scm: 1056 quit */
t3=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[423],t2);}

/* ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6793,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6799,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1027 follow-without-loop */
t5=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a7105 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
/* support.scm: 1052 quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[421],((C_word*)t0)[2]);}

/* a6798 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6799,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6809,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6809(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_6809(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_6809(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_6809(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t10)){
t11=t6;
f_6809(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t11)){
t12=t6;
f_6809(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t12)){
t13=t6;
f_6809(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t13)){
t14=t6;
f_6809(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t14)){
t15=t6;
f_6809(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_6809(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_6809(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[409]);
t18=t6;
f_6809(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[410])));}}}}}}}}}}}}

/* k6807 in a6798 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6818(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=t3;
f_6818(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t5)){
t6=t3;
f_6818(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_6818(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t7)){
t8=t3;
f_6818(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t8)){
t9=t3;
f_6818(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t9)){
t10=t3;
f_6818(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t10)){
t11=t3;
f_6818(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t11)){
t12=t3;
f_6818(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
t13=t3;
f_6818(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[377])));}}}}}}}}}}}

/* k6816 in k6807 in a6798 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6818,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1037 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6830(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_6830(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t5)){
t6=t3;
f_6830(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t6)){
t7=t3;
f_6830(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t8=t3;
f_6830(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}

/* k6828 in k6816 in k6807 in a6798 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6830,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1039 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(4));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[340]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_6842(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[402]);
if(C_truep(t4)){
t5=t3;
f_6842(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
t6=t3;
f_6842(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[417])));}}}}

/* k6840 in k6828 in k6816 in k6807 in a6798 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6842,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1041 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1043 ##sys#hash-table-ref */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6848(2,t3,C_SCHEME_FALSE);}}}

/* k6846 in k6840 in k6828 in k6816 in k6807 in a6798 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1045 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[364]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6882,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_6882(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_6882(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_6882(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_6882(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t8)){
t9=t4;
f_6882(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[365]);
if(C_truep(t9)){
t10=t4;
f_6882(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[366]);
if(C_truep(t10)){
t11=t4;
f_6882(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[367]);
t12=t4;
f_6882(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[368])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k6880 in k6846 in k6840 in k6828 in k6816 in k6807 in a6798 in ##compiler#estimate-foreign-result-size in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1049 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6753,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6759,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6787,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1014 follow-without-loop */
t5=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a6786 in ##compiler#final-foreign-type in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
/* support.scm: 1021 quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[415],((C_word*)t0)[2]);}

/* a6758 in ##compiler#final-foreign-type in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6759,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6763,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1017 ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[371]),t2);}
else{
t5=t4;
f_6763(2,t5,C_SCHEME_FALSE);}}

/* k6761 in a6758 in ##compiler#final-foreign-type in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1019 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6722,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6726,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6735,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1008 ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_6726(t5,C_SCHEME_FALSE);}}

/* k6733 in ##compiler#foreign-type-convert-argument in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6735,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_6726(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6726(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6726(t2,C_SCHEME_FALSE);}}

/* k6724 in ##compiler#foreign-type-convert-argument in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6691,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6704,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1001 ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_6695(t5,C_SCHEME_FALSE);}}

/* k6702 in ##compiler#foreign-type-convert-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6704,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_6695(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6695(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6695(t2,C_SCHEME_FALSE);}}

/* k6693 in ##compiler#foreign-type-convert-result in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6695(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5836,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6685,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 902  follow-without-loop */
t6=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a6684 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6685,2,t0,t1);}
/* support.scm: 994  quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[411],((C_word*)t0)[2]);}

/* a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5842,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5848,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5848(t7,t1,t2);}

/* repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5848,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[334]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[335]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[4]:(C_word)C_a_i_list(&a,2,lf[337],((C_word*)t0)[4])));}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5873(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[404]);
if(C_truep(t8)){
t9=t7;
f_5873(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t9)){
t10=t7;
f_5873(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t10)){
t11=t7;
f_5873(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t11)){
t12=t7;
f_5873(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t12)){
t13=t7;
f_5873(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[409]);
t14=t7;
f_5873(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[410])));}}}}}}}}

/* k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5873,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[339],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5888(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t5=t3;
f_5888(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[403])));}}}

/* k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5888,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[341],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5903(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
if(C_truep(t4)){
t5=t3;
f_5903(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t6=t3;
f_5903(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[401])));}}}}

/* k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5903,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5906,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 912  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5941(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
if(C_truep(t4)){
t5=t3;
f_5941(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
t6=t3;
f_5941(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[398])));}}}}

/* k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5941,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[343],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5956(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t4)){
t5=t3;
f_5956(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t5)){
t6=t3;
f_5956(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t6)){
t7=t3;
f_5956(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t7)){
t8=t3;
f_5956(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t8)){
t9=t3;
f_5956(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
t10=t3;
f_5956(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[395])));}}}}}}}}

/* k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5956,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5959,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 924  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5998(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_5998(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t5)){
t6=t3;
f_5998(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t6)){
t7=t3;
f_5998(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t7)){
t8=t3;
f_5998(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t8)){
t9=t3;
f_5998(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
t10=t3;
f_5998(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[388])));}}}}}}}}

/* k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5998,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[348]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[82],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[346],t4,((C_word*)t0)[6]));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6025(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
t5=t3;
f_6025(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[381])));}}}

/* k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6025,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[350],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6040(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_6040(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6040,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[352],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6055(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_6055(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6055,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6058,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 944  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[354],((C_word*)t0)[7]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6099(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t6=t4;
f_6099(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}}

/* k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6102,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 952  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6144(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t5=t3;
f_6144(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}

/* k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6144,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[357],((C_word*)t0)[6]));}
else{
t2=(C_word)C_a_i_list(&a,2,lf[358],((C_word*)t0)[6]);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[357],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[336]))){
t3=(C_word)C_a_i_list(&a,2,lf[361],((C_word*)t0)[6]);
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[357],t3));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[361],((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,2,lf[358],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[357],t4));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 968  ##sys#hash-table-ref */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t4=t3;
f_6187(2,t4,C_SCHEME_FALSE);}}}}

/* k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6187,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 970  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6215,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6247,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[364]);
if(C_truep(t6)){
/* support.scm: 972  g877 */
t7=t4;
f_6247(t7,((C_word*)t0)[5]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[342]);
if(C_truep(t8)){
/* support.scm: 972  g877 */
t9=t4;
f_6247(t9,((C_word*)t0)[5]);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[365]);
if(C_truep(t10)){
/* support.scm: 972  g877 */
t11=t4;
f_6247(t11,((C_word*)t0)[5]);}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[353]);
if(C_truep(t12)){
/* support.scm: 972  g877 */
t13=t4;
f_6247(t13,((C_word*)t0)[5]);}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[366]);
if(C_truep(t14)){
/* support.scm: 972  g878 */
t15=t3;
f_6215(t15,((C_word*)t0)[5]);}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[367]);
if(C_truep(t16)){
/* support.scm: 972  g878 */
t17=t3;
f_6215(t17,((C_word*)t0)[5]);}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[368]);
if(C_truep(t18)){
t19=(C_word)C_a_i_list(&a,2,lf[82],lf[362]);
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[363],((C_word*)t0)[3],t19));}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[369]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6359(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6359(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[370]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6391(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6391(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[344]);
if(C_truep(t24)){
/* support.scm: 972  g882 */
t25=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t25))(2,t25,f_6210(C_a_i(&a,6),t2));}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[355]);
/* support.scm: 972  g882 */
t27=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t27))(2,t27,(C_truep(t26)?f_6210(C_a_i(&a,6),t2):((C_word*)t0)[3]));}}}}}}}}}}}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6389 in k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6391,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,2,lf[350],((C_word*)t0)[2])):((C_word*)t0)[2]));}

/* k6357 in k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* support.scm: 972  repeat */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5848(t3,((C_word*)t0)[3],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g877 in k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6247,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6251,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 974  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6249 in g877 in k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6251,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[354],t1);
t5=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[101],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[92],t3,t6));}

/* g878 in k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6215,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6219,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 980  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6217 in g878 in k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6219,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[82],lf[362]);
t5=(C_word)C_a_i_list(&a,3,lf[363],((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,4,lf[101],t1,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[92],t3,t7));}

/* g882 in k6185 in k6142 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static C_word C_fcall f_6210(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_a_i_list(&a,2,lf[354],((C_word*)t0)[2]));}

/* k6100 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6102,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6117,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t5=t4;
f_6117(t5,(C_word)C_a_i_list(&a,2,lf[357],t1));}
else{
t5=(C_word)C_a_i_list(&a,2,lf[358],t1);
t6=t4;
f_6117(t6,(C_word)C_a_i_list(&a,2,lf[357],t5));}}

/* k6115 in k6100 in k6097 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_6117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6117,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[101],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t3));}

/* k6056 in k6053 in k6038 in k6023 in k5996 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6058,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[354],t1);
t5=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[101],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[92],t3,t6));}

/* k5957 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5959,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5974,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t5=t4;
f_5974(t5,t1);}
else{
t5=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[2]);
t6=t4;
f_5974(t6,(C_word)C_a_i_list(&a,3,lf[346],t5,t1));}}

/* k5972 in k5957 in k5954 in k5939 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5974,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[101],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t3));}

/* k5904 in k5901 in k5886 in k5871 in repeat in a5841 in ##compiler#foreign-type-check in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5906,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_truep(C_retrieve(lf[336]))?t1:(C_word)C_a_i_list(&a,2,lf[343],t1));
t5=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[101],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[92],t3,t6));}

/* ##compiler#pprint-expressions-to-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5800,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5804,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 883  open-output-file */
t5=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
/* support.scm: 883  current-output-port */
t5=*((C_word*)lf[332]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5802 in ##compiler#pprint-expressions-to-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5807,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 884  with-output-to-port */
t4=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a5814 in k5802 in ##compiler#pprint-expressions-to-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5821,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5820 in a5814 in k5802 in ##compiler#pprint-expressions-to-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5821,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5825,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 888  pretty-print */
t4=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5823 in a5820 in a5814 in k5802 in ##compiler#pprint-expressions-to-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 889  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5805 in k5802 in ##compiler#pprint-expressions-to-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 891  close-output-port */
t2=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5761,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5767,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5773,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a5772 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5773,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5780,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 871  debugging */
t10=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[325],lf[326]);}

/* k5778 in a5772 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5780,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5783,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 872  printf */
t3=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[324],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5781 in k5778 in a5772 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 873  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[323],((C_word*)t0)[2]);}

/* k5784 in k5781 in k5778 in a5772 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 874  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[322],((C_word*)t0)[2]);}

/* k5787 in k5784 in k5781 in k5778 in a5772 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 875  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[321],((C_word*)t0)[2]);}

/* k5790 in k5787 in k5784 in k5781 in k5778 in a5772 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 876  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[320],((C_word*)t0)[2]);}

/* k5793 in k5790 in k5787 in k5784 in k5781 in k5778 in a5772 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 877  printf */
t2=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[319],((C_word*)t0)[2]);}

/* a5766 in ##compiler#print-program-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5767,2,t0,t1);}
/* support.scm: 870  compute-database-statistics */
t2=C_retrieve(lf[315]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5681,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5685,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5690,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 846  ##sys#hash-table-for-each */
t15=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a5689 in ##compiler#compute-database-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5690,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5695 in a5689 in ##compiler#compute-database-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5696,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[200]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[183]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[259],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t5,lf[188]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* k5683 in ##compiler#compute-database-statistics in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 860  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[316]),C_retrieve(lf[317]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5630,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5634,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5675,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5679,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 814  ->string */
t6=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k5677 in ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 814  string-append */
t2=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[314]);}

/* k5673 in ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 813  ##sys#resolve-include-filename */
t2=C_retrieve(lf[313]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5632 in ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5643,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 816  file-exists? */
t3=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5641 in k5632 in ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5643,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[311]))){
/* support.scm: 818  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[312],((C_word*)t0)[2]);}
else{
t3=t2;
f_5646(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5644 in k5641 in k5632 in ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5651,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5668,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 824  read-file */
t4=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5666 in k5644 in k5641 in k5632 in ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5650 in k5644 in k5641 in k5632 in ##compiler#lookup-exports-file in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5651,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 822  ##sys#hash-table-set! */
t3=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[307]),t2,((C_word*)t0)[2]);}
else{
/* support.scm: 823  export-import-hook */
t3=C_retrieve(lf[308]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}}

/* ##compiler#export-import-hook in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5624,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#check-global-imports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5566,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5572,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 797  ##sys#hash-table-for-each */
t4=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5571 in ##compiler#check-global-imports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5572,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5576,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 799  ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[307]),t2);}

/* k5574 in a5571 in ##compiler#check-global-imports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5576,2,t0,t1);}
t2=(C_word)C_i_assq(lf[187],((C_word*)t0)[4]);
t3=(C_word)C_i_assq(lf[198],((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(lf[200],((C_word*)t0)[4]))){
if(C_truep(t3)){
if(C_truep(t1)){
/* support.scm: 805  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],lf[303],lf[304],((C_word*)t0)[2],t1);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=t1;
if(C_truep(t5)){
t6=t4;
f_5603(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5622,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 806  keyword? */
t7=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}}
else{
t5=t4;
f_5603(t5,C_SCHEME_FALSE);}}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5620 in k5574 in a5571 in ##compiler#check-global-imports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5603(t2,(C_word)C_i_not(t1));}

/* k5601 in k5574 in a5571 in ##compiler#check-global-imports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 807  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[298],lf[305],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#check-global-exports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5522,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[293]))){
t3=C_retrieve(lf[293]);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5529,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5540,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 788  ##sys#hash-table-for-each */
t7=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5539 in ##compiler#check-global-exports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5540,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5544,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5551,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t6=(C_word)C_i_assq(lf[198],t3);
t7=t5;
f_5551(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_5551(t6,C_SCHEME_FALSE);}}

/* k5549 in a5539 in ##compiler#check-global-exports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 791  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[298],lf[301],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5544(2,t2,C_SCHEME_UNDEFINED);}}

/* k5542 in a5539 in ##compiler#check-global-exports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 792  delete */
t3=C_retrieve(lf[300]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[276]+1));}

/* k5546 in k5542 in a5539 in ##compiler#check-global-exports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5527 in ##compiler#check-global-exports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5534,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a5533 in k5527 in ##compiler#check-global-exports in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5534,3,t0,t1,t2);}
/* ##compiler#compiler-warning */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[298],lf[299],t2);}

/* ##compiler#dump-undefined-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5491,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5497,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 777  ##sys#hash-table-for-each */
t4=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5496 in ##compiler#dump-undefined-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5497,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5504,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[200],t3))){
t5=(C_word)C_i_assq(lf[198],t3);
t6=t4;
f_5504(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5504(t5,C_SCHEME_FALSE);}}

/* k5502 in a5496 in ##compiler#dump-undefined-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5504,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5507,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 781  write */
t3=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5505 in k5502 in a5496 in ##compiler#dump-undefined-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 782  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5405,4,t0,t1,t2,t3);}
if(C_truep(C_retrieve(lf[290]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 756  with-output-to-file */
t5=C_retrieve(lf[295]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}}

/* a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5418,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5453,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 759  ##sys#hash-table-for-each */
t6=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a5452 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5453,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5460,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(lf[200],t3))){
if(C_truep((C_word)C_i_assq(lf[198],t3))){
t5=(C_truep(C_retrieve(lf[293]))?(C_word)C_i_memq(t2,C_retrieve(lf[293])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5460(t6,t5);}
else{
t6=(C_word)C_i_memq(t2,C_retrieve(lf[294]));
t7=t4;
f_5460(t7,(C_word)C_i_not(t6));}}
else{
t5=t4;
f_5460(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_5460(t5,C_SCHEME_FALSE);}}

/* k5458 in a5452 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5460,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5416 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5426,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5437,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5439,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 771  sort */
t6=C_retrieve(lf[292]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* a5438 in k5416 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5439,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* support.scm: 773  string<? */
t6=*((C_word*)lf[291]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* k5435 in k5416 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5425 in k5416 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5426,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 769  write */
t4=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5428 in a5425 in k5416 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 770  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5419 in k5416 in a5413 in ##compiler#dump-exported-globals in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 774  export-dump-hook */
t2=C_retrieve(lf[288]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#export-dump-hook in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5399,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#simple-lambda-node? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5307,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5331,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5331(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5331,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[246]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[229],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 745  every */
t15=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[240]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 747  every */
t9=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5221,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5227,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5227(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5227,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[229]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5243,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5243(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[82]);
if(C_truep(t9)){
t10=t8;
f_5243(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[113]);
if(C_truep(t10)){
t11=t8;
f_5243(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[241]);
t12=t8;
f_5243(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[233])));}}}}

/* k5241 in walk in ##compiler#expression-has-side-effects? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5243,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[259]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5257,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 728  find */
t7=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],t6,C_retrieve(lf[286]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[101]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[92]));
if(C_truep(t4)){
/* support.scm: 729  any */
t5=C_retrieve(lf[64]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a5256 in k5241 in walk in ##compiler#expression-has-side-effects? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 728  foreign-callback-stub-id */
t4=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5263 in a5256 in k5241 in walk in ##compiler#expression-has-side-effects? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5026,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5029,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5058,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5101,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5205,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 712  matchn */
t15=((C_word*)t12)[1];
f_5101(t15,t14,t2,t3);}

/* k5203 in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 715  debugging */
t7=C_retrieve(lf[13]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t2,lf[281],lf[282],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5209 in k5203 in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5101(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5101,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 701  resolve */
t4=((C_word*)t0)[4];
f_5029(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5123,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 703  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5058(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k5121 in matchn in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5123,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5136(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k5121 in matchn in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5136(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5136,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 707  resolve */
t4=((C_word*)t0)[4];
f_5029(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5167,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 709  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5101(t7,t4,t5,t6);}}}}

/* k5165 in loop in k5121 in matchn in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 710  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5136(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5058(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5058,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 694  resolve */
t4=((C_word*)t0)[3];
f_5029(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5080,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 696  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k5078 in match1 in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 696  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5058(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_5029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5029,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 689  alist-cons */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k5051 in resolve in ##compiler#match-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#copy-node! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4964,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4968,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 671  node-class-set! */
t7=C_retrieve(lf[221]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t3,t6);}

/* k4966 in ##compiler#copy-node! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 672  node-parameters-set! */
t5=C_retrieve(lf[224]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4969 in k4966 in ##compiler#copy-node! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 673  node-subexpressions-set! */
t5=C_retrieve(lf[226]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4972 in k4969 in k4966 in ##compiler#copy-node! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4985(t4,C_fix(4)));}

/* do626 in k4972 in k4969 in k4966 in ##compiler#copy-node! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static C_word C_fcall f_4985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4930,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4936,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4936(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4936,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 667  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4948 in rec in ##compiler#tree-copy in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4954,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 667  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4936(t4,t2,t3);}

/* k4952 in k4948 in rec in ##compiler#tree-copy in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4752,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4756,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 635  map */
t6=*((C_word*)lf[118]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[278]+1),t3,t4);}

/* k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4758,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4764,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 662  walk */
t6=((C_word*)t4)[1];
f_4764(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4764(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4764,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[229]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4787,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
/* support.scm: 642  rename */
f_4758(t11,t12,t3);}
else{
t11=(C_word)C_eqp(t9,lf[104]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4816,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 643  rename */
f_4758(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4832,a[2]=t3,a[3]=t13,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 646  gensym */
t15=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t13);}
else{
t13=(C_word)C_eqp(t9,lf[259]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4865,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 650  decompose-lambda-list */
t16=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4913,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 661  tree-copy */
t15=C_retrieve(lf[277]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}}}}}

/* k4911 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4916,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4920 in k4911 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4921,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4764(t3,t1,t2,((C_word*)t0)[2]);}

/* k4914 in k4911 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4864 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4865,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[93]),t2);}

/* k4867 in a4864 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 654  append */
t3=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4870 in k4867 in a4864 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4872,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 658  rename */
f_4758(t5,((C_word*)t0)[3],t1);}
else{
t6=t5;
f_4907(2,t6,C_SCHEME_FALSE);}}

/* k4905 in k4870 in k4867 in a4864 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 658  build-lambda-list */
t2=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4897 in k4870 in k4867 in a4864 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4899,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4878,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a4882 in k4897 in k4870 in k4867 in a4864 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4883,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4764(t3,t1,t2,((C_word*)t0)[2]);}

/* k4876 in k4897 in k4870 in k4867 in a4864 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[259],((C_word*)t0)[2],t1));}

/* k4830 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 647  alist-cons */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4833 in k4830 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4846,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4845 in k4833 in k4830 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4846,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4764(t3,t1,t2,((C_word*)t0)[2]);}

/* k4839 in k4833 in k4830 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[92],((C_word*)t0)[2],t1));}

/* k4814 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4816,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4803,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4807 in k4814 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4808,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4764(t3,t1,t2,((C_word*)t0)[2]);}

/* k4801 in k4814 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[104],((C_word*)t0)[2],t1));}

/* k4785 in walk in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 642  varnode */
t2=C_retrieve(lf[228]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k4754 in ##compiler#copy-node-tree-and-rename in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4758(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4758,NULL,3,t1,t2,t3);}
/* support.scm: 636  alist-ref */
t4=C_retrieve(lf[275]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[276]+1),t2);}

/* ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4659,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4665,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 613  decompose-lambda-list */
t7=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4665,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4671,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4677,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4677,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[93]),((C_word*)t0)[2]);}
else{
t5=t4;
f_4681(2,t5,((C_word*)t0)[2]);}}

/* k4679 in a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 619  copy-node-tree-and-rename */
t3=C_retrieve(lf[274]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_4684(2,t3,((C_word*)t0)[3]);}}

/* k4682 in k4679 in a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4689,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 625  last */
t5=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_4703(t4,t1);}}

/* k4742 in k4682 in k4679 in a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4720,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 627  qnode */
t4=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[273],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_4720(2,t8,(C_word)C_a_i_record(&a,4,lf[219],lf[107],t6,t7));}}

/* k4718 in k4742 in k4682 in k4679 in a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_4703(t3,(C_word)C_a_i_record(&a,4,lf[219],lf[92],((C_word*)t0)[2],t2));}

/* k4701 in k4682 in k4679 in a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4703,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 631  take */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4705 in k4701 in k4682 in k4679 in a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 621  fold-right */
t2=C_retrieve(lf[271]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4688 in k4682 in k4679 in a4676 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4689,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[219],lf[92],t5,t6));}

/* a4670 in a4664 in ##compiler#inline-lambda-bindings in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
/* support.scm: 616  split-at */
t2=C_retrieve(lf[270]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4611,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4617,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4617(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4617,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 609  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k4635 in fold in ##compiler#fold-boolean in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 610  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4617(t4,t2,t3);}

/* k4639 in k4635 in fold in ##compiler#fold-boolean in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[219],lf[106],lf[268],t2));}

/* ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4317,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4323,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4323(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4323,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[101]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4342,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_4342(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[265]);
t12=t10;
f_4342(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[266])));}}

/* k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4342,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[255]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[229]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[233]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[82]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,lf[82],t6));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 583  butlast */
t10=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[259]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[105]:lf[259]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4441,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 590  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_4323(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[246]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[240]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4474,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[113]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4498,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_4498(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_4552(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t14)){
t15=t13;
f_4552(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t16=t13;
f_4552(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[264])));}}}}}}}}}}}}}

/* k4550 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4552,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 600  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4323(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4580 in k4550 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 601  append */
t2=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4576 in k4550 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4557 in k4550 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k4561 in k4557 in k4550 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 600  cons* */
t2=C_retrieve(lf[99]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4498(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4498,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 597  reverse */
t7=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4539,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 598  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_4323(3,t10,t8,t9);}}

/* k4537 in loop in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 598  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4498(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4510 in loop in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4516,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 597  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4323(3,t4,t2,t3);}

/* k4514 in k4510 in loop in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[260],((C_word*)t0)[2],t1));}

/* k4472 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  cons* */
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[240],((C_word*)t0)[2],t1);}

/* k4439 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4418 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4414 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 583  map */
t2=*((C_word*)lf[118]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[257]+1),((C_word*)t0)[2],t1);}

/* k4402 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4408,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4412,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 584  last */
t4=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4410 in k4402 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 584  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4323(3,t2,((C_word*)t0)[2],t1);}

/* k4406 in k4402 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t1));}

/* k4364 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[255],t2));}

/* k4347 in k4340 in walk in ##compiler#build-expression-tree in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3809,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3812,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4312,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 567  walk */
t9=((C_word*)t6)[1];
f_3812(3,t9,t8,t2);}

/* k4310 in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4315,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 568  debugging */
t3=C_retrieve(lf[13]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[252],lf[253],((C_word*)((C_word*)t0)[2])[1]);}

/* k4313 in k4310 in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word *a;
loop:
a=C_alloc(83);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3812,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 502  varnode */
t3=C_retrieve(lf[228]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 503  bomb */
t3=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[232],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[233]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[219],lf[233],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[101]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[113]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3871,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3897,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[237],C_retrieve(lf[238]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_3897(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_3897(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_3897(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[92]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 523  walk */
t64=t1;
t65=t11;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3947,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 524  unzip1 */
t13=C_retrieve(lf[239]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[105]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3998,a[2]=t12,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_caddr(t2);
/* support.scm: 527  walk */
t64=t13;
t65=t14;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t11=(C_word)C_eqp(t4,lf[114]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_i_car(t2);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t13,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t12))){
t15=(C_word)C_i_car(t12);
t16=t14;
f_4038(t16,(C_word)C_eqp(lf[82],t15));}
else{
t15=t14;
f_4038(t15,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t4,lf[106]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[240]));
if(C_truep(t13)){
t14=(C_word)C_i_car(t2);
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4069,a[2]=t16,a[3]=t14,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_i_cddr(t2);
/* map */
t19=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,((C_word*)((C_word*)t0)[3])[1],t18);}
else{
t14=(C_word)C_eqp(t4,lf[241]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,t15,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,4,lf[219],lf[241],t16,C_SCHEME_END_OF_LIST));}
else{
t15=(C_word)C_eqp(t4,lf[104]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(t4,lf[98]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(t2);
t18=(C_word)C_a_i_list(&a,1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cddr(t2);
/* map */
t21=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,((C_word*)((C_word*)t0)[3])[1],t20);}
else{
t17=(C_word)C_eqp(t4,lf[242]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_i_cadr(t18);
t20=(C_word)C_i_caddr(t2);
t21=(C_word)C_i_cadr(t20);
t22=(C_word)C_i_cadddr(t2);
t23=(C_word)C_i_cadr(t22);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4164,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t23,a[6]=t21,a[7]=t19,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 546  fifth */
t25=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,t2);}
else{
t18=(C_word)C_eqp(t4,lf[107]);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t18)){
t20=t19;
f_4185(t20,t18);}
else{
t20=(C_word)C_eqp(t4,lf[115]);
if(C_truep(t20)){
t21=t19;
f_4185(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[108]);
if(C_truep(t21)){
t22=t19;
f_4185(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[109]);
t23=t19;
f_4185(t23,(C_truep(t22)?t22:(C_word)C_eqp(t4,lf[110])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k4300 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[246],lf[251],t1));}

/* k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4185,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[245]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 554  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a4227 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4228,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4242,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[250])))){
t5=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_4242(t7,C_SCHEME_TRUE);}
else{
t5=t4;
f_4242(t5,C_SCHEME_FALSE);}}

/* k4240 in a4227 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 562  real-name */
t4=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm: 564  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4247 in k4240 in a4227 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_4256(2,t3,t1);}
else{
/* support.scm: 563  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4254 in k4247 in k4240 in a4227 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4246(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[248]),((C_word*)t0)[2],t1));}

/* k4244 in k4240 in a4227 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4235,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k4233 in k4244 in k4240 in a4227 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4235,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[246],((C_word*)t0)[2],t1));}

/* a4221 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
/* support.scm: 554  get-line-2 */
t2=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4208 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[246],lf[247],t1));}

/* k4192 in k4183 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4162 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4148,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 547  sixth */
t6=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k4146 in k4162 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 547  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3812(3,t2,((C_word*)t0)[2],t1);}

/* k4142 in k4162 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[219],lf[242],((C_word*)t0)[2],t2));}

/* k4109 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4111,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[104],((C_word*)t0)[2],t1));}

/* k4067 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4036 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_4038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4038,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4024,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k4022 in k4036 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3996 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[219],lf[105],((C_word*)t0)[2],t2));}

/* k3945 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3950,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a3966 in k3945 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3967,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 525  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3812(3,t4,t1,t3);}

/* k3955 in k3945 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3965,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 526  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3812(3,t3,t2,((C_word*)t0)[2]);}

/* k3963 in k3955 in k3945 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 525  append */
t3=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3948 in k3945 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[92],((C_word*)t0)[2],t1));}

/* k3895 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3897,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 514  compiler-warning */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[235],lf[236],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3894(t2,((C_word*)t0)[2]);}}

/* k3898 in k3895 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 517  truncate */
t3=*((C_word*)lf[234]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3905 in k3898 in k3895 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3894(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k3892 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 510  qnode */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3869 in walk in ##compiler#build-node-graph in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3800,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[219],lf[82],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3791,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[219],lf[229],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3785,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[219],t2,t3,t4));}

/* node-subexpressions in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3776,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[219]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3767,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[219]);
/* support.scm: 488  ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3758,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[219]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3749,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[219]);
/* support.scm: 488  ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3740,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[219]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3731,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[219]);
/* support.scm: 488  ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3725,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[219]));}

/* f_3719 in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3719,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[219],t2,t3,t4));}

/* ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3309,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3313,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_3313(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3717,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 440  append */
t5=*((C_word*)lf[57]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[215]),C_retrieve(lf[216]),C_retrieve(lf[217]));}}

/* k3715 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3313(t3,t2);}

/* k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3313,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 443  ##sys#hash-table-for-each */
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3318,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3328,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t11,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 450  write */
t13=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}}

/* k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3418(t6,t2,((C_word*)t0)[2]);}

/* loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3418,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 454  caar */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[180]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_3444(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t5)){
t6=t4;
f_3444(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[199]);
if(C_truep(t6)){
t7=t4;
f_3444(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t7)){
t8=t4;
f_3444(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t8)){
t9=t4;
f_3444(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[156]);
if(C_truep(t9)){
t10=t4;
f_3444(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t10)){
t11=t4;
f_3444(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[202]);
if(C_truep(t11)){
t12=t4;
f_3444(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[155]);
if(C_truep(t12)){
t13=t4;
f_3444(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t13)){
t14=t4;
f_3444(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t14)){
t15=t4;
f_3444(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t15)){
t16=t4;
f_3444(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t16)){
t17=t4;
f_3444(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t17)){
t18=t4;
f_3444(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t18)){
t19=t4;
f_3444(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t19)){
t20=t4;
f_3444(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t20)){
t21=t4;
f_3444(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[211]);
if(C_truep(t21)){
t22=t4;
f_3444(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[151]);
if(C_truep(t22)){
t23=t4;
f_3444(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[212]);
if(C_truep(t23)){
t24=t4;
f_3444(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[147]);
t25=t4;
f_3444(t25,(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[213])));}}}}}}}}}}}}}}}}}}}}}

/* k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3444,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 458  caar */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[179]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[179]);
t4=((C_word*)t0)[8];
f_3431(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[183]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[179]);
if(C_truep(t4)){
t5=((C_word*)t0)[8];
f_3431(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 462  cdar */
t6=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[184]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 464  cdar */
t6=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[185]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3501(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[190]);
if(C_truep(t7)){
t8=t6;
f_3501(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[191]);
if(C_truep(t8)){
t9=t6;
f_3501(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[169]);
if(C_truep(t9)){
t10=t6;
f_3501(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[192]);
if(C_truep(t10)){
t11=t6;
f_3501(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[193]);
if(C_truep(t11)){
t12=t6;
f_3501(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[194]);
if(C_truep(t12)){
t13=t6;
f_3501(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[195]);
if(C_truep(t13)){
t14=t6;
f_3501(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[196]);
t15=t6;
f_3501(t15,(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[6],lf[197])));}}}}}}}}}}}}}

/* k3499 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3501,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 467  caar */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[187]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 469  cdar */
t4=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[188]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 471  cdar */
t5=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 472  bomb */
t5=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[189],t4);}}}}

/* k3530 in k3499 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3431(2,t3,t2);}

/* k3520 in k3499 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3431(2,t3,t2);}

/* k3506 in k3499 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3512,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 467  cdar */
t3=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3510 in k3506 in k3499 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 467  printf */
t2=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[186],((C_word*)t0)[2],t1);}

/* k3490 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3431(2,t3,t2);}

/* k3480 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3431(2,t3,t2);}

/* k3457 in k3442 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[181]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 458  printf */
t4=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[182],t3);}

/* k3429 in k3426 in loop in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 473  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3418(t3,((C_word*)t0)[2],t2);}

/* k3329 in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[179]);
t5=t3;
f_3366(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3366(t4,C_SCHEME_FALSE);}}

/* k3364 in k3329 in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3366,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 475  printf */
t7=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],lf[177],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[179]);
t4=t2;
f_3387(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3387(t3,C_SCHEME_FALSE);}}}

/* k3385 in k3364 in k3329 in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3387(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3387,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 477  printf */
t7=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[178],t6);}
else{
t2=((C_word*)t0)[2];
f_3334(2,t2,C_SCHEME_UNDEFINED);}}

/* k3332 in k3329 in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 478  printf */
t4=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[176],t3);}
else{
t3=t2;
f_3337(2,t3,C_SCHEME_UNDEFINED);}}

/* k3335 in k3332 in k3329 in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 479  printf */
t4=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[175],t3);}
else{
t3=t2;
f_3340(2,t3,C_SCHEME_UNDEFINED);}}

/* k3338 in k3335 in k3332 in k3329 in k3326 in a3317 in k3311 in ##compiler#display-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 480  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3296,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 422  ##sys#hash-table-for-each */
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[166]));}

/* a3295 in ##compiler#display-line-number-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3296,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3307,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[172]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3305 in a3295 in ##compiler#display-line-number-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 424  printf */
t2=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[171],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3266,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3272,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3272(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3272(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3272,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3282,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 418  get */
t5=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[169]);}}

/* k3280 in loop in ##compiler#find-lambda-container in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 419  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3272(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3230,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3237,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 410  ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[166]),t3);}

/* k3235 in ##compiler#get-line-2 in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_3240(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_3240(t3,C_SCHEME_FALSE);}}

/* k3238 in k3235 in ##compiler#get-line-2 in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_3240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 412  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 413  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3220,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 406  get */
t4=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[166]),t3,t2);}

/* ##compiler#count! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_3163r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3163r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3163r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3167,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 394  ##sys#hash-table-ref */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3165 in ##compiler#count! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3197,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 399  alist-cons */
t7=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 400  ##sys#hash-table-set! */
t6=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k3195 in k3165 in ##compiler#count! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3111,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3115,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 386  ##sys#hash-table-ref */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3113 in ##compiler#collect! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3142,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 390  alist-cons */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 391  ##sys#hash-table-set! */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k3140 in k3113 in ##compiler#collect! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3065,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3069,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 378  ##sys#hash-table-ref */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3067 in ##compiler#put! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3091,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 382  alist-cons */
t5=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 383  ##sys#hash-table-set! */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k3089 in k3067 in ##compiler#put! in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3047r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3047r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3047r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3051,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 372  ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3049 in ##compiler#get-all in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3051,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 374  filter-map */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a3058 in k3049 in ##compiler#get-all in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3059,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3029,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 366  ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3031 in ##compiler#get in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2968,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2972,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[157]));}

/* a3004 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3005,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 352  put! */
t4=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[156],C_SCHEME_TRUE);}

/* k3007 in a3004 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[154])))){
/* support.scm: 353  put! */
t3=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[155],C_SCHEME_TRUE);}
else{
t3=t2;
f_3012(2,t3,C_SCHEME_UNDEFINED);}}

/* k3010 in k3007 in a3004 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[153])))){
/* support.scm: 354  put! */
t2=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[150],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2970 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[152]));}

/* a2989 in k2970 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2990,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 358  put! */
t4=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[151],C_SCHEME_TRUE);}

/* k2992 in a2989 in k2970 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[149])))){
/* support.scm: 359  put! */
t2=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[150],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2973 in k2970 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[148]));}

/* a2979 in k2973 in k2970 in ##compiler#initialize-analysis-database in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2980,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 362  put! */
t4=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t3,lf[147],C_SCHEME_TRUE);}

/* ##compiler#expand-profile-lambda in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2911,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[138]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2915,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 334  gensym */
t7=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k2913 in ##compiler#expand-profile-lambda in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 335  alist-cons */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[139]));}

/* k2917 in k2913 in ##compiler#expand-profile-lambda in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=C_mutate((C_word*)lf[139]+1,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[138]+1,t3);
t5=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[140],t5,C_retrieve(lf[141]));
t7=(C_word)C_a_i_list(&a,3,lf[105],C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_list(&a,3,lf[105],((C_word*)t0)[5],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,3,lf[142],t8,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[105],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[6]);
t12=(C_word)C_a_i_list(&a,3,lf[143],t11,C_retrieve(lf[141]));
t13=(C_word)C_a_i_list(&a,3,lf[105],C_SCHEME_END_OF_LIST,t12);
t14=(C_word)C_a_i_list(&a,4,lf[144],t7,t10,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[105],((C_word*)t0)[3],t14));}

/* ##compiler#process-lambda-documentation in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2908,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2805,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2814,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2820,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2845,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2894 in a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2895r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2895r(t0,t1,t2);}}

static void C_ccall f_2895r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2901,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g237239 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2900 in a2894 in a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2850 in a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2879,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 319  with-input-from-string */
t4=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a2878 in a2850 in a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2885,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2893,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 319  read */
t4=*((C_word*)lf[127]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2891 in a2878 in a2850 in a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 319  unfold */
t2=C_retrieve(lf[128]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[129]+1),*((C_word*)lf[130]+1),((C_word*)t0)[2],t1);}

/* a2884 in a2878 in a2850 in a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2885,3,t0,t1,t2);}
/* support.scm: 319  read */
t3=*((C_word*)lf[127]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2853 in a2850 in a2844 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[125]);}
else{
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_nullp(t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[126],t1)));}}

/* a2819 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2820,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* g237239 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2825 in a2819 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 316  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k2835 in a2825 in a2819 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 317  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 318  ->string */
t2=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2832 in a2825 in a2819 in a2813 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 314  quit */
t2=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[124],((C_word*)t0)[2],t1);}

/* k2810 in ##compiler#string->expr in k2802 in k2799 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2430,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2433,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 306  walk */
t9=((C_word*)t6)[1];
f_2433(3,t9,t8,t2);}

/* k2792 in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 307  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2433,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2435,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2587,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t2);
t9=t6;
f_2587(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_2587(t8,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2638,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[92]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cadr(t2);
t11=t6;
f_2638(t11,(C_word)C_i_listp(t10));}
else{
t10=t6;
f_2638(t10,C_SCHEME_FALSE);}}
else{
t9=t6;
f_2638(t9,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2638,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2647(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g182185 */
t4=((C_word*)t0)[3];
f_2435(t4,((C_word*)t0)[2],t2,t3);}}

/* g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2647,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2657,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t6=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2748,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* cdar */
t8=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}
else{
t7=t5;
f_2694(t7,C_SCHEME_FALSE);}}}

/* k2746 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2748,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* cddar */
t3=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2694(t2,C_SCHEME_FALSE);}}

/* k2742 in k2746 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2694(t2,(C_word)C_i_nullp(t1));}

/* k2692 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2694,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* cadar */
t4=*((C_word*)lf[120]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* g182185 */
t4=((C_word*)t0)[2];
f_2435(t4,((C_word*)t0)[4],t2,t3);}}

/* k2715 in k2692 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2713,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* caar */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2711 in k2715 in k2692 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* g177222 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2647(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2655 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2660,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t3=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2658 in k2655 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2674,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[118]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2679 in k2658 in k2655 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2680,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2688,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* walk172 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2433(3,t5,t4,t3);}

/* k2686 in a2679 in k2658 in k2655 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2672 in k2658 in k2655 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2676 in k2672 in k2658 in k2655 in g177 in k2636 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[92],t2));}

/* k2585 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2587,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2607,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##compiler#collapsable-literal? */
t4=C_retrieve(lf[83]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g182185 */
t4=((C_word*)t0)[2];
f_2435(t4,((C_word*)t0)[4],t2,t3);}}

/* k2605 in k2585 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##compiler#make-random-name */
t3=C_retrieve(lf[117]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k2597 in k2605 in k2585 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* alist-cons */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2601 in k2597 in k2605 in k2585 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* g182 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2435(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2435,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[97]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2445(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[111]);
if(C_truep(t7)){
t8=t6;
f_2445(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[112]);
if(C_truep(t8)){
t9=t6;
f_2445(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[113]);
if(C_truep(t9)){
t10=t6;
f_2445(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[114]);
t11=t6;
f_2445(t11,(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[115])));}}}}}

/* k2443 in g182 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2445,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[98]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_2454(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[104]);
if(C_truep(t4)){
t5=t3;
f_2454(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[105]);
if(C_truep(t5)){
t6=t3;
f_2454(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[106]);
if(C_truep(t6)){
t7=t3;
f_2454(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[107]);
if(C_truep(t7)){
t8=t3;
f_2454(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[108]);
if(C_truep(t8)){
t9=t3;
f_2454(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[109]);
t10=t3;
f_2454(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[110])));}}}}}}}}

/* k2452 in k2443 in g182 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2454,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2465,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[101]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2478(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[102]);
t5=t3;
f_2478(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[3],lf[103])));}}}

/* k2476 in k2452 in k2443 in g182 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2478,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
/* map */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}}

/* k2483 in k2476 in k2452 in k2443 in g182 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2463 in k2452 in k2443 in g182 in walk in ##compiler#extract-mutable-constants in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 301  cons* */
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#canonicalize-begin-body in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2347,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2353,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2353(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2353(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2353,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[90]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[91]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2381,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_2381(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2418,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 277  constant? */
t8=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k2416 in loop in ##compiler#canonicalize-begin-body in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2381(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[95])));}

/* k2379 in loop in ##compiler#canonicalize-begin-body in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2381,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 279  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2353(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 280  gensym */
t3=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}}

/* k2409 in k2379 in loop in ##compiler#canonicalize-begin-body in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 281  loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2353(t7,t5,t6);}

/* k2397 in k2409 in k2379 in loop in ##compiler#canonicalize-begin-body in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2399,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t1));}

/* ##compiler#basic-literal? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2287,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 262  constant? */
t6=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}

/* k2301 in ##compiler#basic-literal? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 263  vector->list */
t4=*((C_word*)lf[88]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2309(2,t3,C_SCHEME_FALSE);}}}

/* k2343 in k2301 in ##compiler#basic-literal? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 263  every */
t2=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[86]),t1);}

/* k2307 in k2301 in ##compiler#basic-literal? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 265  basic-literal? */
t4=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k2322 in k2307 in k2301 in ##compiler#basic-literal? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 266  basic-literal? */
t3=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2241,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2245,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 252  big-fixnum? */
t5=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t3;
f_2245(t4,C_SCHEME_FALSE);}}

/* k2283 in ##compiler#immediate? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2245(t2,(C_word)C_i_not(t1));}

/* k2243 in ##compiler#immediate? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2211,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2165,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[82],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#follow-without-loop in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2134,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2140,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2140(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2140,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 230  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 231  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a2154 in loop in ##compiler#follow-without-loop in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2155,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 231  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2140(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2071,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 220  reverse */
t6=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k2083 in ##compiler#fold-inner in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2087,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2087(t5,((C_word*)t0)[2],t1);}

/* fold in k2083 in ##compiler#fold-inner in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2087,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_2095(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2116,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 225  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k2114 in fold in k2083 in ##compiler#fold-inner in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2095(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k2093 in fold in k2083 in ##compiler#fold-inner in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2059,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[76]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 215  close-input-port */
t4=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2012r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2012r(t0,t1,t2,t3);}}

static void C_ccall f_2012r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[69]))){
/* support.scm: 209  current-input-port */
t4=*((C_word*)lf[70]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2028,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 210  file-exists? */
t5=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k2026 in ##compiler#check-and-open-input-file in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 210  open-input-file */
t2=*((C_word*)lf[71]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2040(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_2040(t5,(C_word)C_i_not(t4));}}}

/* k2038 in k2026 in ##compiler#check-and-open-input-file in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_2040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 211  quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[72],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 212  quit */
t3=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[73],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2005,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub98(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1998,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub94(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1942,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 190  ->string */
t5=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1994 in ##compiler#valid-c-identifier? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[59]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1944 in ##compiler#valid-c-identifier? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1969,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 194  any */
t7=C_retrieve(lf[64]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1968 in k1944 in ##compiler#valid-c-identifier? in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1969,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1848,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1860,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[59]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1866(t5,((C_word*)t0)[2],t1);}

/* loop in k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1866,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[56]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1888,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_1888(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_1888(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[62])));}}}

/* k1886 in loop in k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1888,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_1895(t3,lf[60]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_1895(t4,(C_truep(t3)?lf[61]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1866(t4,t2,t3);}}

/* k1925 in k1886 in loop in k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1893 in k1886 in loop in k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1895,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 185  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k1909 in k1893 in k1886 in loop in k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[59]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1897 in k1893 in k1886 in loop in k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1903,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 186  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1866(t4,t2,t3);}

/* k1901 in k1897 in k1893 in k1886 in loop in k1862 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 181  append */
t2=*((C_word*)lf[57]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[58],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1858 in ##compiler#c-ify-string in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1804,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1810,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1810(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1810,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1834,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 167  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k1832 in loop in ##compiler#build-lambda-list in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1779,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 161  string->symbol */
t3=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 162  sprintf */
t4=C_retrieve(lf[46]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[50],t2);}}}

/* k1800 in ##compiler#symbolify in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 162  string->symbol */
t2=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1758,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 156  symbol->string */
t3=*((C_word*)lf[45]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* support.scm: 157  sprintf */
t3=C_retrieve(lf[46]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[47],t2);}}}

/* ##compiler#posq in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1722,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1728(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k1455 in k1452 in k1449 in k1446 in k1443 */
static C_word C_fcall f_1728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1654,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1678,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1678(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1678(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1678,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 140  err */
t4=((C_word*)t0)[3];
f_1657(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 142  err */
t5=((C_word*)t0)[3];
f_1657(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 143  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1657,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 137  real-name */
t3=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1663 in err in ##compiler#check-signature in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1669,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 138  map-llist */
t4=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[42]),t3);}

/* k1667 in k1663 in err in ##compiler#check-signature in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 136  quit */
t2=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[41],((C_word*)t0)[2],t1);}

/* map-llist in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1611,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1617,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1617(t7,t1,t3);}

/* loop in map-llist in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1617,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 131  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 132  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k1638 in loop in map-llist in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 132  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1617(t4,t2,t3);}

/* k1642 in k1638 in loop in map-llist in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1608,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[33])));}

/* ##sys#syntax-error-hook in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1583r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1583r(t0,t1,t2,t3);}}

static void C_ccall f_1583r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1587,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  current-error-port */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1585 in ##sys#syntax-error-hook in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 118  fprintf */
t3=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[36],((C_word*)t0)[2]);}

/* k1588 in k1585 in ##sys#syntax-error-hook in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1600 in k1588 in k1585 in ##sys#syntax-error-hook in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1601,3,t0,t1,t2);}
/* fprintf */
t3=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],lf[35],t2);}

/* k1591 in k1588 in k1585 in ##sys#syntax-error-hook in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 120  print-call-chain */
t3=C_retrieve(lf[32]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[33]),lf[34]);}

/* k1594 in k1591 in k1588 in k1585 in ##sys#syntax-error-hook in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 121  exit */
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1564r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1564r(t0,t1,t2,t3);}}

static void C_ccall f_1564r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1568,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  current-error-port */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1566 in quit in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1571,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1581,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 111  string-append */
t4=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[30],((C_word*)t0)[2]);}

/* k1579 in k1566 in quit in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[24]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1569 in k1566 in quit in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 112  newline */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1572 in k1569 in k1566 in quit in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 113  exit */
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1535r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1535r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1535r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1542,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[27]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[7]));
t7=t5;
f_1542(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_1542(t6,C_SCHEME_FALSE);}}

/* k1540 in ##compiler#compiler-warning in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_fcall f_1542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1542,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  current-error-port */
t3=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1543 in k1540 in ##compiler#compiler-warning in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1548,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 106  string-append */
t4=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[25],((C_word*)t0)[2]);}

/* k1553 in k1543 in k1540 in ##compiler#compiler-warning in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[24]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1546 in k1543 in k1540 in ##compiler#compiler-warning in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 107  newline */
t2=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1495r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1495r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[6])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 94   printf */
t6=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[22],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k1503 in ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 97   display */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[21]);}
else{
t3=t2;
f_1508(2,t3,C_SCHEME_UNDEFINED);}}

/* k1518 in k1503 in ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1525,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a1524 in k1518 in k1503 in ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1525,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1533,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   force */
t4=C_retrieve(lf[18]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1531 in a1524 in k1518 in k1503 in ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 98   printf */
t2=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[17],t1);}

/* k1506 in k1503 in ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   newline */
t3=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1509 in k1506 in k1503 in ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 100  flush-output */
t3=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1512 in k1509 in k1506 in k1503 in ##compiler#debugging in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1468r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1468r(t0,t1,t2);}}

static void C_ccall f_1468r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1482,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 88   string-append */
t5=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[11],t4);}
else{
/* support.scm: 89   error */
t3=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[12]);}}

/* k1480 in ##compiler#bomb in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[9]+1),t1,t2);}

/* f_1463 in k1455 in k1452 in k1449 in k1446 in k1443 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[576] = {
{"toplevelsupport.scm",(void*)C_support_toplevel},
{"f_1445support.scm",(void*)f_1445},
{"f_1448support.scm",(void*)f_1448},
{"f_1451support.scm",(void*)f_1451},
{"f_1454support.scm",(void*)f_1454},
{"f_1457support.scm",(void*)f_1457},
{"f_2801support.scm",(void*)f_2801},
{"f_2804support.scm",(void*)f_2804},
{"f_8902support.scm",(void*)f_8902},
{"f_8791support.scm",(void*)f_8791},
{"f_8900support.scm",(void*)f_8900},
{"f_8795support.scm",(void*)f_8795},
{"f_8800support.scm",(void*)f_8800},
{"f_8804support.scm",(void*)f_8804},
{"f_8840support.scm",(void*)f_8840},
{"f_8884support.scm",(void*)f_8884},
{"f_8856support.scm",(void*)f_8856},
{"f_8807support.scm",(void*)f_8807},
{"f_8814support.scm",(void*)f_8814},
{"f_8810support.scm",(void*)f_8810},
{"f_8762support.scm",(void*)f_8762},
{"f_8789support.scm",(void*)f_8789},
{"f_8773support.scm",(void*)f_8773},
{"f_8776support.scm",(void*)f_8776},
{"f_8778support.scm",(void*)f_8778},
{"f_8782support.scm",(void*)f_8782},
{"f_8766support.scm",(void*)f_8766},
{"f_8699support.scm",(void*)f_8699},
{"f_8736support.scm",(void*)f_8736},
{"f_8760support.scm",(void*)f_8760},
{"f_8746support.scm",(void*)f_8746},
{"f_8750support.scm",(void*)f_8750},
{"f_8721support.scm",(void*)f_8721},
{"f_8729support.scm",(void*)f_8729},
{"f_8630support.scm",(void*)f_8630},
{"f_8634support.scm",(void*)f_8634},
{"f_8639support.scm",(void*)f_8639},
{"f_8643support.scm",(void*)f_8643},
{"f_8694support.scm",(void*)f_8694},
{"f_8673support.scm",(void*)f_8673},
{"f_8685support.scm",(void*)f_8685},
{"f_8688support.scm",(void*)f_8688},
{"f_8661support.scm",(void*)f_8661},
{"f_8605support.scm",(void*)f_8605},
{"f_8615support.scm",(void*)f_8615},
{"f_8618support.scm",(void*)f_8618},
{"f_8518support.scm",(void*)f_8518},
{"f_8527support.scm",(void*)f_8527},
{"f_8540support.scm",(void*)f_8540},
{"f_8546support.scm",(void*)f_8546},
{"f_8599support.scm",(void*)f_8599},
{"f_8549support.scm",(void*)f_8549},
{"f_8564support.scm",(void*)f_8564},
{"f_8572support.scm",(void*)f_8572},
{"f_8582support.scm",(void*)f_8582},
{"f_8567support.scm",(void*)f_8567},
{"f_8555support.scm",(void*)f_8555},
{"f_8522support.scm",(void*)f_8522},
{"f_8512support.scm",(void*)f_8512},
{"f_8436support.scm",(void*)f_8436},
{"f_8443support.scm",(void*)f_8443},
{"f_8455support.scm",(void*)f_8455},
{"f_8466support.scm",(void*)f_8466},
{"f_8462support.scm",(void*)f_8462},
{"f_8424support.scm",(void*)f_8424},
{"f_8430support.scm",(void*)f_8430},
{"f_8412support.scm",(void*)f_8412},
{"f_8416support.scm",(void*)f_8416},
{"f_8333support.scm",(void*)f_8333},
{"f_8352support.scm",(void*)f_8352},
{"f_8377support.scm",(void*)f_8377},
{"f_8381support.scm",(void*)f_8381},
{"f_8383support.scm",(void*)f_8383},
{"f_8390support.scm",(void*)f_8390},
{"f_8403support.scm",(void*)f_8403},
{"f_8407support.scm",(void*)f_8407},
{"f_8336support.scm",(void*)f_8336},
{"f_8340support.scm",(void*)f_8340},
{"f_8346support.scm",(void*)f_8346},
{"f_8327support.scm",(void*)f_8327},
{"f_8283support.scm",(void*)f_8283},
{"f_8295support.scm",(void*)f_8295},
{"f_8299support.scm",(void*)f_8299},
{"f_8303support.scm",(void*)f_8303},
{"f_8291support.scm",(void*)f_8291},
{"f_8274support.scm",(void*)f_8274},
{"f_8265support.scm",(void*)f_8265},
{"f_8259support.scm",(void*)f_8259},
{"f_8253support.scm",(void*)f_8253},
{"f_8241support.scm",(void*)f_8241},
{"f_8245support.scm",(void*)f_8245},
{"f_8248support.scm",(void*)f_8248},
{"f_8203support.scm",(void*)f_8203},
{"f_8207support.scm",(void*)f_8207},
{"f_8210support.scm",(void*)f_8210},
{"f_8217support.scm",(void*)f_8217},
{"f_8161support.scm",(void*)f_8161},
{"f_8170support.scm",(void*)f_8170},
{"f_8132support.scm",(void*)f_8132},
{"f_8142support.scm",(void*)f_8142},
{"f_7935support.scm",(void*)f_7935},
{"f_8114support.scm",(void*)f_8114},
{"f_8063support.scm",(void*)f_8063},
{"f_8108support.scm",(void*)f_8108},
{"f_8112support.scm",(void*)f_8112},
{"f_8066support.scm",(void*)f_8066},
{"f_8071support.scm",(void*)f_8071},
{"f_8075support.scm",(void*)f_8075},
{"f_8069support.scm",(void*)f_8069},
{"f_8026support.scm",(void*)f_8026},
{"f_8030support.scm",(void*)f_8030},
{"f_8039support.scm",(void*)f_8039},
{"f_8043support.scm",(void*)f_8043},
{"f_8033support.scm",(void*)f_8033},
{"f_7991support.scm",(void*)f_7991},
{"f_7997support.scm",(void*)f_7997},
{"f_8024support.scm",(void*)f_8024},
{"f_8010support.scm",(void*)f_8010},
{"f_7944support.scm",(void*)f_7944},
{"f_7950support.scm",(void*)f_7950},
{"f_7989support.scm",(void*)f_7989},
{"f_7971support.scm",(void*)f_7971},
{"f_7776support.scm",(void*)f_7776},
{"f_7933support.scm",(void*)f_7933},
{"f_7920support.scm",(void*)f_7920},
{"f_7926support.scm",(void*)f_7926},
{"f_7779support.scm",(void*)f_7779},
{"f_7798support.scm",(void*)f_7798},
{"f_7882support.scm",(void*)f_7882},
{"f_7894support.scm",(void*)f_7894},
{"f_7852support.scm",(void*)f_7852},
{"f_7863support.scm",(void*)f_7863},
{"f_7843support.scm",(void*)f_7843},
{"f_7829support.scm",(void*)f_7829},
{"f_7817support.scm",(void*)f_7817},
{"f_7698support.scm",(void*)f_7698},
{"f_7704support.scm",(void*)f_7704},
{"f_7759support.scm",(void*)f_7759},
{"f_7732support.scm",(void*)f_7732},
{"f_7726support.scm",(void*)f_7726},
{"f_7702support.scm",(void*)f_7702},
{"f_7422support.scm",(void*)f_7422},
{"f_7635support.scm",(void*)f_7635},
{"f_7594support.scm",(void*)f_7594},
{"f_7547support.scm",(void*)f_7547},
{"f_7525support.scm",(void*)f_7525},
{"f_7112support.scm",(void*)f_7112},
{"f_7416support.scm",(void*)f_7416},
{"f_7124support.scm",(void*)f_7124},
{"f_7134support.scm",(void*)f_7134},
{"f_7152support.scm",(void*)f_7152},
{"f_7186support.scm",(void*)f_7186},
{"f_7115support.scm",(void*)f_7115},
{"f_6793support.scm",(void*)f_6793},
{"f_7106support.scm",(void*)f_7106},
{"f_6799support.scm",(void*)f_6799},
{"f_6809support.scm",(void*)f_6809},
{"f_6818support.scm",(void*)f_6818},
{"f_6830support.scm",(void*)f_6830},
{"f_6842support.scm",(void*)f_6842},
{"f_6848support.scm",(void*)f_6848},
{"f_6882support.scm",(void*)f_6882},
{"f_6753support.scm",(void*)f_6753},
{"f_6787support.scm",(void*)f_6787},
{"f_6759support.scm",(void*)f_6759},
{"f_6763support.scm",(void*)f_6763},
{"f_6722support.scm",(void*)f_6722},
{"f_6735support.scm",(void*)f_6735},
{"f_6726support.scm",(void*)f_6726},
{"f_6691support.scm",(void*)f_6691},
{"f_6704support.scm",(void*)f_6704},
{"f_6695support.scm",(void*)f_6695},
{"f_5836support.scm",(void*)f_5836},
{"f_6685support.scm",(void*)f_6685},
{"f_5842support.scm",(void*)f_5842},
{"f_5848support.scm",(void*)f_5848},
{"f_5873support.scm",(void*)f_5873},
{"f_5888support.scm",(void*)f_5888},
{"f_5903support.scm",(void*)f_5903},
{"f_5941support.scm",(void*)f_5941},
{"f_5956support.scm",(void*)f_5956},
{"f_5998support.scm",(void*)f_5998},
{"f_6025support.scm",(void*)f_6025},
{"f_6040support.scm",(void*)f_6040},
{"f_6055support.scm",(void*)f_6055},
{"f_6099support.scm",(void*)f_6099},
{"f_6144support.scm",(void*)f_6144},
{"f_6187support.scm",(void*)f_6187},
{"f_6391support.scm",(void*)f_6391},
{"f_6359support.scm",(void*)f_6359},
{"f_6247support.scm",(void*)f_6247},
{"f_6251support.scm",(void*)f_6251},
{"f_6215support.scm",(void*)f_6215},
{"f_6219support.scm",(void*)f_6219},
{"f_6210support.scm",(void*)f_6210},
{"f_6102support.scm",(void*)f_6102},
{"f_6117support.scm",(void*)f_6117},
{"f_6058support.scm",(void*)f_6058},
{"f_5959support.scm",(void*)f_5959},
{"f_5974support.scm",(void*)f_5974},
{"f_5906support.scm",(void*)f_5906},
{"f_5800support.scm",(void*)f_5800},
{"f_5804support.scm",(void*)f_5804},
{"f_5815support.scm",(void*)f_5815},
{"f_5821support.scm",(void*)f_5821},
{"f_5825support.scm",(void*)f_5825},
{"f_5807support.scm",(void*)f_5807},
{"f_5761support.scm",(void*)f_5761},
{"f_5773support.scm",(void*)f_5773},
{"f_5780support.scm",(void*)f_5780},
{"f_5783support.scm",(void*)f_5783},
{"f_5786support.scm",(void*)f_5786},
{"f_5789support.scm",(void*)f_5789},
{"f_5792support.scm",(void*)f_5792},
{"f_5795support.scm",(void*)f_5795},
{"f_5767support.scm",(void*)f_5767},
{"f_5681support.scm",(void*)f_5681},
{"f_5690support.scm",(void*)f_5690},
{"f_5696support.scm",(void*)f_5696},
{"f_5685support.scm",(void*)f_5685},
{"f_5630support.scm",(void*)f_5630},
{"f_5679support.scm",(void*)f_5679},
{"f_5675support.scm",(void*)f_5675},
{"f_5634support.scm",(void*)f_5634},
{"f_5643support.scm",(void*)f_5643},
{"f_5646support.scm",(void*)f_5646},
{"f_5668support.scm",(void*)f_5668},
{"f_5651support.scm",(void*)f_5651},
{"f_5624support.scm",(void*)f_5624},
{"f_5566support.scm",(void*)f_5566},
{"f_5572support.scm",(void*)f_5572},
{"f_5576support.scm",(void*)f_5576},
{"f_5622support.scm",(void*)f_5622},
{"f_5603support.scm",(void*)f_5603},
{"f_5522support.scm",(void*)f_5522},
{"f_5540support.scm",(void*)f_5540},
{"f_5551support.scm",(void*)f_5551},
{"f_5544support.scm",(void*)f_5544},
{"f_5548support.scm",(void*)f_5548},
{"f_5529support.scm",(void*)f_5529},
{"f_5534support.scm",(void*)f_5534},
{"f_5491support.scm",(void*)f_5491},
{"f_5497support.scm",(void*)f_5497},
{"f_5504support.scm",(void*)f_5504},
{"f_5507support.scm",(void*)f_5507},
{"f_5405support.scm",(void*)f_5405},
{"f_5414support.scm",(void*)f_5414},
{"f_5453support.scm",(void*)f_5453},
{"f_5460support.scm",(void*)f_5460},
{"f_5418support.scm",(void*)f_5418},
{"f_5439support.scm",(void*)f_5439},
{"f_5437support.scm",(void*)f_5437},
{"f_5426support.scm",(void*)f_5426},
{"f_5430support.scm",(void*)f_5430},
{"f_5421support.scm",(void*)f_5421},
{"f_5399support.scm",(void*)f_5399},
{"f_5307support.scm",(void*)f_5307},
{"f_5331support.scm",(void*)f_5331},
{"f_5221support.scm",(void*)f_5221},
{"f_5227support.scm",(void*)f_5227},
{"f_5243support.scm",(void*)f_5243},
{"f_5257support.scm",(void*)f_5257},
{"f_5265support.scm",(void*)f_5265},
{"f_5026support.scm",(void*)f_5026},
{"f_5205support.scm",(void*)f_5205},
{"f_5211support.scm",(void*)f_5211},
{"f_5101support.scm",(void*)f_5101},
{"f_5123support.scm",(void*)f_5123},
{"f_5136support.scm",(void*)f_5136},
{"f_5167support.scm",(void*)f_5167},
{"f_5058support.scm",(void*)f_5058},
{"f_5080support.scm",(void*)f_5080},
{"f_5029support.scm",(void*)f_5029},
{"f_5053support.scm",(void*)f_5053},
{"f_4964support.scm",(void*)f_4964},
{"f_4968support.scm",(void*)f_4968},
{"f_4971support.scm",(void*)f_4971},
{"f_4974support.scm",(void*)f_4974},
{"f_4985support.scm",(void*)f_4985},
{"f_4930support.scm",(void*)f_4930},
{"f_4936support.scm",(void*)f_4936},
{"f_4950support.scm",(void*)f_4950},
{"f_4954support.scm",(void*)f_4954},
{"f_4752support.scm",(void*)f_4752},
{"f_4756support.scm",(void*)f_4756},
{"f_4764support.scm",(void*)f_4764},
{"f_4913support.scm",(void*)f_4913},
{"f_4921support.scm",(void*)f_4921},
{"f_4916support.scm",(void*)f_4916},
{"f_4865support.scm",(void*)f_4865},
{"f_4869support.scm",(void*)f_4869},
{"f_4872support.scm",(void*)f_4872},
{"f_4907support.scm",(void*)f_4907},
{"f_4899support.scm",(void*)f_4899},
{"f_4883support.scm",(void*)f_4883},
{"f_4878support.scm",(void*)f_4878},
{"f_4832support.scm",(void*)f_4832},
{"f_4835support.scm",(void*)f_4835},
{"f_4846support.scm",(void*)f_4846},
{"f_4841support.scm",(void*)f_4841},
{"f_4816support.scm",(void*)f_4816},
{"f_4808support.scm",(void*)f_4808},
{"f_4803support.scm",(void*)f_4803},
{"f_4787support.scm",(void*)f_4787},
{"f_4758support.scm",(void*)f_4758},
{"f_4659support.scm",(void*)f_4659},
{"f_4665support.scm",(void*)f_4665},
{"f_4677support.scm",(void*)f_4677},
{"f_4681support.scm",(void*)f_4681},
{"f_4684support.scm",(void*)f_4684},
{"f_4744support.scm",(void*)f_4744},
{"f_4720support.scm",(void*)f_4720},
{"f_4703support.scm",(void*)f_4703},
{"f_4707support.scm",(void*)f_4707},
{"f_4689support.scm",(void*)f_4689},
{"f_4671support.scm",(void*)f_4671},
{"f_4611support.scm",(void*)f_4611},
{"f_4617support.scm",(void*)f_4617},
{"f_4637support.scm",(void*)f_4637},
{"f_4641support.scm",(void*)f_4641},
{"f_4317support.scm",(void*)f_4317},
{"f_4323support.scm",(void*)f_4323},
{"f_4342support.scm",(void*)f_4342},
{"f_4552support.scm",(void*)f_4552},
{"f_4582support.scm",(void*)f_4582},
{"f_4578support.scm",(void*)f_4578},
{"f_4559support.scm",(void*)f_4559},
{"f_4563support.scm",(void*)f_4563},
{"f_4498support.scm",(void*)f_4498},
{"f_4539support.scm",(void*)f_4539},
{"f_4512support.scm",(void*)f_4512},
{"f_4516support.scm",(void*)f_4516},
{"f_4474support.scm",(void*)f_4474},
{"f_4441support.scm",(void*)f_4441},
{"f_4420support.scm",(void*)f_4420},
{"f_4416support.scm",(void*)f_4416},
{"f_4404support.scm",(void*)f_4404},
{"f_4412support.scm",(void*)f_4412},
{"f_4408support.scm",(void*)f_4408},
{"f_4366support.scm",(void*)f_4366},
{"f_4349support.scm",(void*)f_4349},
{"f_3809support.scm",(void*)f_3809},
{"f_4312support.scm",(void*)f_4312},
{"f_4315support.scm",(void*)f_4315},
{"f_3812support.scm",(void*)f_3812},
{"f_4302support.scm",(void*)f_4302},
{"f_4185support.scm",(void*)f_4185},
{"f_4228support.scm",(void*)f_4228},
{"f_4242support.scm",(void*)f_4242},
{"f_4249support.scm",(void*)f_4249},
{"f_4256support.scm",(void*)f_4256},
{"f_4246support.scm",(void*)f_4246},
{"f_4235support.scm",(void*)f_4235},
{"f_4222support.scm",(void*)f_4222},
{"f_4210support.scm",(void*)f_4210},
{"f_4194support.scm",(void*)f_4194},
{"f_4164support.scm",(void*)f_4164},
{"f_4148support.scm",(void*)f_4148},
{"f_4144support.scm",(void*)f_4144},
{"f_4111support.scm",(void*)f_4111},
{"f_4069support.scm",(void*)f_4069},
{"f_4038support.scm",(void*)f_4038},
{"f_4024support.scm",(void*)f_4024},
{"f_3998support.scm",(void*)f_3998},
{"f_3947support.scm",(void*)f_3947},
{"f_3967support.scm",(void*)f_3967},
{"f_3957support.scm",(void*)f_3957},
{"f_3965support.scm",(void*)f_3965},
{"f_3950support.scm",(void*)f_3950},
{"f_3897support.scm",(void*)f_3897},
{"f_3900support.scm",(void*)f_3900},
{"f_3907support.scm",(void*)f_3907},
{"f_3894support.scm",(void*)f_3894},
{"f_3871support.scm",(void*)f_3871},
{"f_3800support.scm",(void*)f_3800},
{"f_3791support.scm",(void*)f_3791},
{"f_3785support.scm",(void*)f_3785},
{"f_3776support.scm",(void*)f_3776},
{"f_3767support.scm",(void*)f_3767},
{"f_3758support.scm",(void*)f_3758},
{"f_3749support.scm",(void*)f_3749},
{"f_3740support.scm",(void*)f_3740},
{"f_3731support.scm",(void*)f_3731},
{"f_3725support.scm",(void*)f_3725},
{"f_3719support.scm",(void*)f_3719},
{"f_3309support.scm",(void*)f_3309},
{"f_3717support.scm",(void*)f_3717},
{"f_3313support.scm",(void*)f_3313},
{"f_3318support.scm",(void*)f_3318},
{"f_3328support.scm",(void*)f_3328},
{"f_3418support.scm",(void*)f_3418},
{"f_3428support.scm",(void*)f_3428},
{"f_3444support.scm",(void*)f_3444},
{"f_3501support.scm",(void*)f_3501},
{"f_3532support.scm",(void*)f_3532},
{"f_3522support.scm",(void*)f_3522},
{"f_3508support.scm",(void*)f_3508},
{"f_3512support.scm",(void*)f_3512},
{"f_3492support.scm",(void*)f_3492},
{"f_3482support.scm",(void*)f_3482},
{"f_3459support.scm",(void*)f_3459},
{"f_3431support.scm",(void*)f_3431},
{"f_3331support.scm",(void*)f_3331},
{"f_3366support.scm",(void*)f_3366},
{"f_3387support.scm",(void*)f_3387},
{"f_3334support.scm",(void*)f_3334},
{"f_3337support.scm",(void*)f_3337},
{"f_3340support.scm",(void*)f_3340},
{"f_3290support.scm",(void*)f_3290},
{"f_3296support.scm",(void*)f_3296},
{"f_3307support.scm",(void*)f_3307},
{"f_3266support.scm",(void*)f_3266},
{"f_3272support.scm",(void*)f_3272},
{"f_3282support.scm",(void*)f_3282},
{"f_3230support.scm",(void*)f_3230},
{"f_3237support.scm",(void*)f_3237},
{"f_3240support.scm",(void*)f_3240},
{"f_3220support.scm",(void*)f_3220},
{"f_3163support.scm",(void*)f_3163},
{"f_3167support.scm",(void*)f_3167},
{"f_3197support.scm",(void*)f_3197},
{"f_3111support.scm",(void*)f_3111},
{"f_3115support.scm",(void*)f_3115},
{"f_3142support.scm",(void*)f_3142},
{"f_3065support.scm",(void*)f_3065},
{"f_3069support.scm",(void*)f_3069},
{"f_3091support.scm",(void*)f_3091},
{"f_3047support.scm",(void*)f_3047},
{"f_3051support.scm",(void*)f_3051},
{"f_3059support.scm",(void*)f_3059},
{"f_3029support.scm",(void*)f_3029},
{"f_3033support.scm",(void*)f_3033},
{"f_2968support.scm",(void*)f_2968},
{"f_3005support.scm",(void*)f_3005},
{"f_3009support.scm",(void*)f_3009},
{"f_3012support.scm",(void*)f_3012},
{"f_2972support.scm",(void*)f_2972},
{"f_2990support.scm",(void*)f_2990},
{"f_2994support.scm",(void*)f_2994},
{"f_2975support.scm",(void*)f_2975},
{"f_2980support.scm",(void*)f_2980},
{"f_2911support.scm",(void*)f_2911},
{"f_2915support.scm",(void*)f_2915},
{"f_2919support.scm",(void*)f_2919},
{"f_2908support.scm",(void*)f_2908},
{"f_2805support.scm",(void*)f_2805},
{"f_2814support.scm",(void*)f_2814},
{"f_2845support.scm",(void*)f_2845},
{"f_2895support.scm",(void*)f_2895},
{"f_2901support.scm",(void*)f_2901},
{"f_2851support.scm",(void*)f_2851},
{"f_2879support.scm",(void*)f_2879},
{"f_2893support.scm",(void*)f_2893},
{"f_2885support.scm",(void*)f_2885},
{"f_2855support.scm",(void*)f_2855},
{"f_2820support.scm",(void*)f_2820},
{"f_2826support.scm",(void*)f_2826},
{"f_2837support.scm",(void*)f_2837},
{"f_2834support.scm",(void*)f_2834},
{"f_2812support.scm",(void*)f_2812},
{"f_2430support.scm",(void*)f_2430},
{"f_2794support.scm",(void*)f_2794},
{"f_2433support.scm",(void*)f_2433},
{"f_2638support.scm",(void*)f_2638},
{"f_2647support.scm",(void*)f_2647},
{"f_2748support.scm",(void*)f_2748},
{"f_2744support.scm",(void*)f_2744},
{"f_2694support.scm",(void*)f_2694},
{"f_2717support.scm",(void*)f_2717},
{"f_2713support.scm",(void*)f_2713},
{"f_2657support.scm",(void*)f_2657},
{"f_2660support.scm",(void*)f_2660},
{"f_2680support.scm",(void*)f_2680},
{"f_2688support.scm",(void*)f_2688},
{"f_2674support.scm",(void*)f_2674},
{"f_2678support.scm",(void*)f_2678},
{"f_2587support.scm",(void*)f_2587},
{"f_2607support.scm",(void*)f_2607},
{"f_2599support.scm",(void*)f_2599},
{"f_2603support.scm",(void*)f_2603},
{"f_2435support.scm",(void*)f_2435},
{"f_2445support.scm",(void*)f_2445},
{"f_2454support.scm",(void*)f_2454},
{"f_2478support.scm",(void*)f_2478},
{"f_2485support.scm",(void*)f_2485},
{"f_2465support.scm",(void*)f_2465},
{"f_2347support.scm",(void*)f_2347},
{"f_2353support.scm",(void*)f_2353},
{"f_2418support.scm",(void*)f_2418},
{"f_2381support.scm",(void*)f_2381},
{"f_2411support.scm",(void*)f_2411},
{"f_2399support.scm",(void*)f_2399},
{"f_2287support.scm",(void*)f_2287},
{"f_2303support.scm",(void*)f_2303},
{"f_2345support.scm",(void*)f_2345},
{"f_2309support.scm",(void*)f_2309},
{"f_2324support.scm",(void*)f_2324},
{"f_2241support.scm",(void*)f_2241},
{"f_2285support.scm",(void*)f_2285},
{"f_2245support.scm",(void*)f_2245},
{"f_2211support.scm",(void*)f_2211},
{"f_2165support.scm",(void*)f_2165},
{"f_2134support.scm",(void*)f_2134},
{"f_2140support.scm",(void*)f_2140},
{"f_2155support.scm",(void*)f_2155},
{"f_2071support.scm",(void*)f_2071},
{"f_2085support.scm",(void*)f_2085},
{"f_2087support.scm",(void*)f_2087},
{"f_2116support.scm",(void*)f_2116},
{"f_2095support.scm",(void*)f_2095},
{"f_2059support.scm",(void*)f_2059},
{"f_2012support.scm",(void*)f_2012},
{"f_2028support.scm",(void*)f_2028},
{"f_2040support.scm",(void*)f_2040},
{"f_2005support.scm",(void*)f_2005},
{"f_1998support.scm",(void*)f_1998},
{"f_1942support.scm",(void*)f_1942},
{"f_1996support.scm",(void*)f_1996},
{"f_1946support.scm",(void*)f_1946},
{"f_1969support.scm",(void*)f_1969},
{"f_1848support.scm",(void*)f_1848},
{"f_1864support.scm",(void*)f_1864},
{"f_1866support.scm",(void*)f_1866},
{"f_1888support.scm",(void*)f_1888},
{"f_1927support.scm",(void*)f_1927},
{"f_1895support.scm",(void*)f_1895},
{"f_1911support.scm",(void*)f_1911},
{"f_1899support.scm",(void*)f_1899},
{"f_1903support.scm",(void*)f_1903},
{"f_1860support.scm",(void*)f_1860},
{"f_1804support.scm",(void*)f_1804},
{"f_1810support.scm",(void*)f_1810},
{"f_1834support.scm",(void*)f_1834},
{"f_1779support.scm",(void*)f_1779},
{"f_1802support.scm",(void*)f_1802},
{"f_1758support.scm",(void*)f_1758},
{"f_1722support.scm",(void*)f_1722},
{"f_1728support.scm",(void*)f_1728},
{"f_1654support.scm",(void*)f_1654},
{"f_1678support.scm",(void*)f_1678},
{"f_1657support.scm",(void*)f_1657},
{"f_1665support.scm",(void*)f_1665},
{"f_1669support.scm",(void*)f_1669},
{"f_1611support.scm",(void*)f_1611},
{"f_1617support.scm",(void*)f_1617},
{"f_1640support.scm",(void*)f_1640},
{"f_1644support.scm",(void*)f_1644},
{"f_1608support.scm",(void*)f_1608},
{"f_1583support.scm",(void*)f_1583},
{"f_1587support.scm",(void*)f_1587},
{"f_1590support.scm",(void*)f_1590},
{"f_1601support.scm",(void*)f_1601},
{"f_1593support.scm",(void*)f_1593},
{"f_1596support.scm",(void*)f_1596},
{"f_1564support.scm",(void*)f_1564},
{"f_1568support.scm",(void*)f_1568},
{"f_1581support.scm",(void*)f_1581},
{"f_1571support.scm",(void*)f_1571},
{"f_1574support.scm",(void*)f_1574},
{"f_1535support.scm",(void*)f_1535},
{"f_1542support.scm",(void*)f_1542},
{"f_1545support.scm",(void*)f_1545},
{"f_1555support.scm",(void*)f_1555},
{"f_1548support.scm",(void*)f_1548},
{"f_1495support.scm",(void*)f_1495},
{"f_1505support.scm",(void*)f_1505},
{"f_1520support.scm",(void*)f_1520},
{"f_1525support.scm",(void*)f_1525},
{"f_1533support.scm",(void*)f_1533},
{"f_1508support.scm",(void*)f_1508},
{"f_1511support.scm",(void*)f_1511},
{"f_1514support.scm",(void*)f_1514},
{"f_1468support.scm",(void*)f_1468},
{"f_1482support.scm",(void*)f_1482},
{"f_1463support.scm",(void*)f_1463},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
