/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-07 10:49
   Version 3.3.4 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   compiled 2008-07-29 on pequod (Linux)
   command line: support.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[504];
static double C_possibly_force_alignment;


/* from k2012 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k2005 */
static C_word C_fcall stub94(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub94(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8906)
static void C_ccall f_8906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8795)
static void C_ccall f_8795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8904)
static void C_ccall f_8904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8799)
static void C_fcall f_8799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8808)
static void C_ccall f_8808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8844)
static void C_fcall f_8844(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8860)
static void C_ccall f_8860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8818)
static void C_ccall f_8818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8793)
static void C_ccall f_8793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_ccall f_8777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8770)
static void C_fcall f_8770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_ccall f_8764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_ccall f_8733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8634)
static void C_ccall f_8634(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8638)
static void C_ccall f_8638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8643)
static void C_fcall f_8643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8647)
static void C_ccall f_8647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8698)
static void C_ccall f_8698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8689)
static void C_ccall f_8689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8692)
static void C_ccall f_8692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8665)
static void C_ccall f_8665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8622)
static void C_ccall f_8622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_ccall f_8522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8531)
static void C_fcall f_8531(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8550)
static void C_ccall f_8550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_ccall f_8603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8553)
static void C_ccall f_8553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8576)
static void C_fcall f_8576(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8586)
static void C_ccall f_8586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8571)
static void C_ccall f_8571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8559)
static void C_ccall f_8559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8516)
static void C_ccall f_8516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8440)
static void C_ccall f_8440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8447)
static void C_fcall f_8447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8470)
static void C_ccall f_8470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8466)
static void C_ccall f_8466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8434)
static void C_ccall f_8434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8416)
static void C_ccall f_8416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8420)
static void C_ccall f_8420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8385)
static void C_ccall f_8385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8387)
static void C_fcall f_8387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8407)
static void C_ccall f_8407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_fcall f_8340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8344)
static void C_ccall f_8344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8257)
static void C_ccall f_8257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8245)
static void C_ccall f_8245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8252)
static void C_ccall f_8252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8211)
static void C_ccall f_8211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8214)
static void C_ccall f_8214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8174)
static void C_fcall f_8174(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8146)
static void C_fcall f_8146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8118)
static void C_ccall f_8118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8070)
static void C_ccall f_8070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8073)
static void C_ccall f_8073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8030)
static void C_fcall f_8030(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7995)
static void C_fcall f_7995(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8001)
static void C_fcall f_8001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_fcall f_7948(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7954)
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7993)
static void C_ccall f_7993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7937)
static void C_ccall f_7937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7924)
static void C_fcall f_7924(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7930)
static void C_ccall f_7930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7783)
static void C_fcall f_7783(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7802)
static void C_fcall f_7802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7886)
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7898)
static void C_ccall f_7898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_fcall f_7833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7821)
static void C_ccall f_7821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7763)
static void C_fcall f_7763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7736)
static void C_fcall f_7736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7730)
static void C_fcall f_7730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7706)
static void C_ccall f_7706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7639)
static void C_fcall f_7639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_fcall f_7598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_fcall f_7551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7529)
static C_word C_fcall f_7529(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7138)
static void C_fcall f_7138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_fcall f_7190(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7119)
static void C_fcall f_7119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6813)
static void C_fcall f_6813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_fcall f_6822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6834)
static void C_fcall f_6834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_fcall f_6846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_fcall f_6886(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_fcall f_6730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_fcall f_6699(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6689)
static void C_ccall f_6689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5852)
static void C_fcall f_5852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5877)
static void C_fcall f_5877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_fcall f_5892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_fcall f_5907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_fcall f_5945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_fcall f_5960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6002)
static void C_fcall f_6002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6029)
static void C_fcall f_6029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_fcall f_6044(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_fcall f_6059(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_fcall f_6103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6148)
static void C_fcall f_6148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_fcall f_6395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_fcall f_6251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_fcall f_6219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6223)
static void C_ccall f_6223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6214)
static C_word C_fcall f_6214(C_word *a,C_word t0);
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_fcall f_6121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5978)
static void C_fcall f_5978(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_fcall f_5607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5555)
static void C_fcall f_5555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5508)
static void C_fcall f_5508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5511)
static void C_ccall f_5511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5464)
static void C_fcall f_5464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5247)
static void C_fcall f_5247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_fcall f_5105(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_fcall f_5062(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static C_word C_fcall f_4989(C_word t0,C_word t1);
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4940)
static void C_fcall f_4940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_fcall f_4768(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_fcall f_4762(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_fcall f_4707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4621)
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4346)
static void C_fcall f_4346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_fcall f_4556(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_fcall f_4502(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_fcall f_4189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4246)
static void C_fcall f_4246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_fcall f_4042(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_fcall f_3901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_fcall f_3898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_fcall f_3317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_fcall f_3422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_fcall f_3448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_fcall f_3505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_fcall f_3370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_fcall f_3391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3276)
static void C_fcall f_3276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_fcall f_3244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2642)
static void C_fcall f_2642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_fcall f_2698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_fcall f_2591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_fcall f_2439(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2449)
static void C_fcall f_2449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_fcall f_2458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_fcall f_2482(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2357)
static void C_fcall f_2357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_fcall f_2385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_fcall f_2249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2144)
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_fcall f_2091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_fcall f_2099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_fcall f_2044(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_fcall f_1870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1892)
static void C_fcall f_1892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_fcall f_1899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1814)
static void C_fcall f_1814(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1732)
static C_word C_fcall f_1732(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1682)
static void C_fcall f_1682(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1661)
static void C_fcall f_1661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1621)
static void C_fcall f_1621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1546)
static void C_fcall f_1546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8799)
static void C_fcall trf_8799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8799(t0,t1);}

C_noret_decl(trf_8844)
static void C_fcall trf_8844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8844(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8844(t0,t1,t2);}

C_noret_decl(trf_8770)
static void C_fcall trf_8770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8770(t0,t1);}

C_noret_decl(trf_8643)
static void C_fcall trf_8643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8643(t0,t1);}

C_noret_decl(trf_8531)
static void C_fcall trf_8531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8531(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8531(t0,t1,t2,t3);}

C_noret_decl(trf_8576)
static void C_fcall trf_8576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8576(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8576(t0,t1,t2);}

C_noret_decl(trf_8447)
static void C_fcall trf_8447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8447(t0,t1);}

C_noret_decl(trf_8387)
static void C_fcall trf_8387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8387(t0,t1,t2,t3);}

C_noret_decl(trf_8340)
static void C_fcall trf_8340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8340(t0,t1);}

C_noret_decl(trf_8174)
static void C_fcall trf_8174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8174(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8174(t0,t1,t2);}

C_noret_decl(trf_8146)
static void C_fcall trf_8146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8146(t0,t1);}

C_noret_decl(trf_8030)
static void C_fcall trf_8030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8030(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8030(t0,t1,t2,t3);}

C_noret_decl(trf_7995)
static void C_fcall trf_7995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7995(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7995(t0,t1,t2);}

C_noret_decl(trf_8001)
static void C_fcall trf_8001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8001(t0,t1,t2);}

C_noret_decl(trf_7948)
static void C_fcall trf_7948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7948(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7948(t0,t1,t2,t3);}

C_noret_decl(trf_7954)
static void C_fcall trf_7954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7954(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7954(t0,t1,t2);}

C_noret_decl(trf_7924)
static void C_fcall trf_7924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7924(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7924(t0,t1,t2,t3);}

C_noret_decl(trf_7783)
static void C_fcall trf_7783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7783(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7783(t0,t1,t2,t3);}

C_noret_decl(trf_7802)
static void C_fcall trf_7802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7802(t0,t1);}

C_noret_decl(trf_7833)
static void C_fcall trf_7833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7833(t0,t1);}

C_noret_decl(trf_7763)
static void C_fcall trf_7763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7763(t0,t1);}

C_noret_decl(trf_7736)
static void C_fcall trf_7736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7736(t0,t1);}

C_noret_decl(trf_7730)
static void C_fcall trf_7730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7730(t0,t1);}

C_noret_decl(trf_7639)
static void C_fcall trf_7639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7639(t0,t1);}

C_noret_decl(trf_7598)
static void C_fcall trf_7598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7598(t0,t1);}

C_noret_decl(trf_7551)
static void C_fcall trf_7551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7551(t0,t1);}

C_noret_decl(trf_7138)
static void C_fcall trf_7138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7138(t0,t1);}

C_noret_decl(trf_7190)
static void C_fcall trf_7190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7190(t0,t1);}

C_noret_decl(trf_7119)
static void C_fcall trf_7119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7119(t0,t1);}

C_noret_decl(trf_6813)
static void C_fcall trf_6813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6813(t0,t1);}

C_noret_decl(trf_6822)
static void C_fcall trf_6822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6822(t0,t1);}

C_noret_decl(trf_6834)
static void C_fcall trf_6834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6834(t0,t1);}

C_noret_decl(trf_6846)
static void C_fcall trf_6846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6846(t0,t1);}

C_noret_decl(trf_6886)
static void C_fcall trf_6886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6886(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6886(t0,t1);}

C_noret_decl(trf_6730)
static void C_fcall trf_6730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6730(t0,t1);}

C_noret_decl(trf_6699)
static void C_fcall trf_6699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6699(t0,t1);}

C_noret_decl(trf_5852)
static void C_fcall trf_5852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5852(t0,t1,t2);}

C_noret_decl(trf_5877)
static void C_fcall trf_5877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5877(t0,t1);}

C_noret_decl(trf_5892)
static void C_fcall trf_5892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5892(t0,t1);}

C_noret_decl(trf_5907)
static void C_fcall trf_5907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5907(t0,t1);}

C_noret_decl(trf_5945)
static void C_fcall trf_5945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5945(t0,t1);}

C_noret_decl(trf_5960)
static void C_fcall trf_5960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5960(t0,t1);}

C_noret_decl(trf_6002)
static void C_fcall trf_6002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6002(t0,t1);}

C_noret_decl(trf_6029)
static void C_fcall trf_6029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6029(t0,t1);}

C_noret_decl(trf_6044)
static void C_fcall trf_6044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6044(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6044(t0,t1);}

C_noret_decl(trf_6059)
static void C_fcall trf_6059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6059(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6059(t0,t1);}

C_noret_decl(trf_6103)
static void C_fcall trf_6103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6103(t0,t1);}

C_noret_decl(trf_6148)
static void C_fcall trf_6148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6148(t0,t1);}

C_noret_decl(trf_6395)
static void C_fcall trf_6395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6395(t0,t1);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6363(t0,t1);}

C_noret_decl(trf_6251)
static void C_fcall trf_6251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6251(t0,t1);}

C_noret_decl(trf_6219)
static void C_fcall trf_6219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6219(t0,t1);}

C_noret_decl(trf_6121)
static void C_fcall trf_6121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6121(t0,t1);}

C_noret_decl(trf_5978)
static void C_fcall trf_5978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5978(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5978(t0,t1);}

C_noret_decl(trf_5607)
static void C_fcall trf_5607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5607(t0,t1);}

C_noret_decl(trf_5555)
static void C_fcall trf_5555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5555(t0,t1);}

C_noret_decl(trf_5508)
static void C_fcall trf_5508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5508(t0,t1);}

C_noret_decl(trf_5464)
static void C_fcall trf_5464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5464(t0,t1);}

C_noret_decl(trf_5247)
static void C_fcall trf_5247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5247(t0,t1);}

C_noret_decl(trf_5105)
static void C_fcall trf_5105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5105(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5105(t0,t1,t2,t3);}

C_noret_decl(trf_5140)
static void C_fcall trf_5140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5140(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5140(t0,t1,t2,t3);}

C_noret_decl(trf_5062)
static void C_fcall trf_5062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5062(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5062(t0,t1,t2,t3);}

C_noret_decl(trf_5033)
static void C_fcall trf_5033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5033(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5033(t0,t1,t2,t3);}

C_noret_decl(trf_4940)
static void C_fcall trf_4940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4940(t0,t1,t2);}

C_noret_decl(trf_4768)
static void C_fcall trf_4768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4768(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4768(t0,t1,t2,t3);}

C_noret_decl(trf_4762)
static void C_fcall trf_4762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4762(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4762(t0,t1,t2);}

C_noret_decl(trf_4707)
static void C_fcall trf_4707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4707(t0,t1);}

C_noret_decl(trf_4621)
static void C_fcall trf_4621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4621(t0,t1,t2);}

C_noret_decl(trf_4346)
static void C_fcall trf_4346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4346(t0,t1);}

C_noret_decl(trf_4556)
static void C_fcall trf_4556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4556(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4556(t0,t1);}

C_noret_decl(trf_4502)
static void C_fcall trf_4502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4502(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4502(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4189)
static void C_fcall trf_4189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4189(t0,t1);}

C_noret_decl(trf_4246)
static void C_fcall trf_4246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4246(t0,t1);}

C_noret_decl(trf_4042)
static void C_fcall trf_4042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4042(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4042(t0,t1);}

C_noret_decl(trf_3901)
static void C_fcall trf_3901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3901(t0,t1);}

C_noret_decl(trf_3898)
static void C_fcall trf_3898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3898(t0,t1);}

C_noret_decl(trf_3317)
static void C_fcall trf_3317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3317(t0,t1);}

C_noret_decl(trf_3422)
static void C_fcall trf_3422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3422(t0,t1,t2);}

C_noret_decl(trf_3448)
static void C_fcall trf_3448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3448(t0,t1);}

C_noret_decl(trf_3505)
static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3505(t0,t1);}

C_noret_decl(trf_3370)
static void C_fcall trf_3370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3370(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3370(t0,t1);}

C_noret_decl(trf_3391)
static void C_fcall trf_3391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3391(t0,t1);}

C_noret_decl(trf_3276)
static void C_fcall trf_3276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3276(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3276(t0,t1,t2);}

C_noret_decl(trf_3244)
static void C_fcall trf_3244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3244(t0,t1);}

C_noret_decl(trf_2642)
static void C_fcall trf_2642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2642(t0,t1);}

C_noret_decl(trf_2651)
static void C_fcall trf_2651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2651(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2651(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2698)
static void C_fcall trf_2698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2698(t0,t1);}

C_noret_decl(trf_2591)
static void C_fcall trf_2591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2591(t0,t1);}

C_noret_decl(trf_2439)
static void C_fcall trf_2439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2439(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2439(t0,t1,t2,t3);}

C_noret_decl(trf_2449)
static void C_fcall trf_2449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2449(t0,t1);}

C_noret_decl(trf_2458)
static void C_fcall trf_2458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2458(t0,t1);}

C_noret_decl(trf_2482)
static void C_fcall trf_2482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2482(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2482(t0,t1);}

C_noret_decl(trf_2357)
static void C_fcall trf_2357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2357(t0,t1,t2);}

C_noret_decl(trf_2385)
static void C_fcall trf_2385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2385(t0,t1);}

C_noret_decl(trf_2249)
static void C_fcall trf_2249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2249(t0,t1);}

C_noret_decl(trf_2144)
static void C_fcall trf_2144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2144(t0,t1,t2,t3);}

C_noret_decl(trf_2091)
static void C_fcall trf_2091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2091(t0,t1,t2);}

C_noret_decl(trf_2099)
static void C_fcall trf_2099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2099(t0,t1);}

C_noret_decl(trf_2044)
static void C_fcall trf_2044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2044(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2044(t0,t1);}

C_noret_decl(trf_1870)
static void C_fcall trf_1870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1870(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1870(t0,t1,t2);}

C_noret_decl(trf_1892)
static void C_fcall trf_1892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1892(t0,t1);}

C_noret_decl(trf_1899)
static void C_fcall trf_1899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1899(t0,t1);}

C_noret_decl(trf_1814)
static void C_fcall trf_1814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1814(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1814(t0,t1,t2,t3);}

C_noret_decl(trf_1682)
static void C_fcall trf_1682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1682(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1682(t0,t1,t2,t3);}

C_noret_decl(trf_1661)
static void C_fcall trf_1661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1661(t0,t1);}

C_noret_decl(trf_1621)
static void C_fcall trf_1621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1621(t0,t1,t2);}

C_noret_decl(trf_1546)
static void C_fcall trf_1546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1546(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5104)){
C_save(t1);
C_rereclaim2(5104*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,504);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000C\012CHICKEN\012(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[5]=C_h_intern(&lf[5],30,"\010compilercompiler-cleanup-hook");
lf[6]=C_h_intern(&lf[6],26,"\010compilerdebugging-chicken");
lf[7]=C_h_intern(&lf[7],26,"\010compilerdisabled-warnings");
lf[8]=C_h_intern(&lf[8],13,"\010compilerbomb");
lf[9]=C_h_intern(&lf[9],5,"error");
lf[10]=C_h_intern(&lf[10],13,"string-append");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\034[internal compiler screwup] ");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\033[internal compiler screwup]");
lf[13]=C_h_intern(&lf[13],18,"\010compilerdebugging");
lf[14]=C_h_intern(&lf[14],12,"flush-output");
lf[15]=C_h_intern(&lf[15],7,"newline");
lf[16]=C_h_intern(&lf[16],6,"printf");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[18]=C_h_intern(&lf[18],5,"force");
lf[19]=C_h_intern(&lf[19],12,"\003sysfor-each");
lf[20]=C_h_intern(&lf[20],7,"display");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],7,"fprintf");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[26]=C_h_intern(&lf[26],18,"current-error-port");
lf[27]=C_h_intern(&lf[27],20,"\003syswarnings-enabled");
lf[28]=C_h_intern(&lf[28],4,"quit");
lf[29]=C_h_intern(&lf[29],4,"exit");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[31]=C_h_intern(&lf[31],21,"\003syssyntax-error-hook");
lf[32]=C_h_intern(&lf[32],16,"print-call-chain");
lf[33]=C_h_intern(&lf[33],18,"\003syscurrent-thread");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[37]=C_h_intern(&lf[37],12,"syntax-error");
lf[38]=C_h_intern(&lf[38],31,"\010compileremit-syntax-trace-info");
lf[39]=C_h_intern(&lf[39],9,"map-llist");
lf[40]=C_h_intern(&lf[40],24,"\010compilercheck-signature");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[42]=C_h_intern(&lf[42],18,"\010compilerreal-name");
lf[43]=C_h_intern(&lf[43],13,"\010compilerposq");
lf[44]=C_h_intern(&lf[44],18,"\010compilerstringify");
lf[45]=C_h_intern(&lf[45],14,"symbol->string");
lf[46]=C_h_intern(&lf[46],7,"sprintf");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[48]=C_h_intern(&lf[48],18,"\010compilersymbolify");
lf[49]=C_h_intern(&lf[49],14,"string->symbol");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[51]=C_h_intern(&lf[51],26,"\010compilerbuild-lambda-list");
lf[52]=C_h_intern(&lf[52],29,"\010compilerstring->c-identifier");
lf[53]=C_h_intern(&lf[53],24,"\003sysstring->c-identifier");
lf[54]=C_h_intern(&lf[54],21,"\010compilerc-ify-string");
lf[55]=C_h_intern(&lf[55],16,"\003syslist->string");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[57]=C_h_intern(&lf[57],6,"append");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[59]=C_h_intern(&lf[59],16,"\003sysstring->list");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[63]=C_h_intern(&lf[63],28,"\010compilervalid-c-identifier\077");
lf[64]=C_h_intern(&lf[64],3,"any");
lf[65]=C_h_intern(&lf[65],8,"->string");
lf[66]=C_h_intern(&lf[66],14,"\010compilerwords");
lf[67]=C_h_intern(&lf[67],21,"\010compilerwords->bytes");
lf[68]=C_h_intern(&lf[68],34,"\010compilercheck-and-open-input-file");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[70]=C_h_intern(&lf[70],18,"current-input-port");
lf[71]=C_h_intern(&lf[71],15,"open-input-file");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[74]=C_h_intern(&lf[74],12,"file-exists\077");
lf[75]=C_h_intern(&lf[75],33,"\010compilerclose-checked-input-file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[77]=C_h_intern(&lf[77],16,"close-input-port");
lf[78]=C_h_intern(&lf[78],19,"\010compilerfold-inner");
lf[79]=C_h_intern(&lf[79],7,"reverse");
lf[80]=C_h_intern(&lf[80],28,"\010compilerfollow-without-loop");
lf[81]=C_h_intern(&lf[81],18,"\010compilerconstant\077");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],29,"\010compilercollapsable-literal\077");
lf[84]=C_h_intern(&lf[84],19,"\010compilerimmediate\077");
lf[85]=C_h_intern(&lf[85],20,"\010compilerbig-fixnum\077");
lf[86]=C_h_intern(&lf[86],23,"\010compilerbasic-literal\077");
lf[87]=C_h_intern(&lf[87],5,"every");
lf[88]=C_h_intern(&lf[88],12,"vector->list");
lf[89]=C_h_intern(&lf[89],32,"\010compilercanonicalize-begin-body");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_h_intern(&lf[92],3,"let");
lf[93]=C_h_intern(&lf[93],6,"gensym");
lf[94]=C_h_intern(&lf[94],1,"t");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[96]=C_h_intern(&lf[96],34,"\010compilerextract-mutable-constants");
lf[97]=C_h_intern(&lf[97],12,"\004coreinclude");
lf[98]=C_h_intern(&lf[98],9,"\004coreset!");
lf[99]=C_h_intern(&lf[99],5,"cons*");
lf[100]=C_h_intern(&lf[100],7,"\003sysmap");
lf[101]=C_h_intern(&lf[101],2,"if");
lf[102]=C_h_intern(&lf[102],20,"\004corecompiletimeonly");
lf[103]=C_h_intern(&lf[103],19,"\004corecompiletimetoo");
lf[104]=C_h_intern(&lf[104],4,"set!");
lf[105]=C_h_intern(&lf[105],6,"lambda");
lf[106]=C_h_intern(&lf[106],11,"\004coreinline");
lf[107]=C_h_intern(&lf[107],20,"\004coreinline_allocate");
lf[108]=C_h_intern(&lf[108],18,"\004coreinline_update");
lf[109]=C_h_intern(&lf[109],19,"\004coreinline_loc_ref");
lf[110]=C_h_intern(&lf[110],22,"\004coreinline_loc_update");
lf[111]=C_h_intern(&lf[111],12,"\004coredeclare");
lf[112]=C_h_intern(&lf[112],14,"\004coreimmutable");
lf[113]=C_h_intern(&lf[113],14,"\004coreundefined");
lf[114]=C_h_intern(&lf[114],14,"\004coreprimitive");
lf[115]=C_h_intern(&lf[115],15,"\004coreinline_ref");
lf[116]=C_h_intern(&lf[116],10,"alist-cons");
lf[117]=C_h_intern(&lf[117],25,"\010compilermake-random-name");
lf[118]=C_h_intern(&lf[118],3,"map");
lf[119]=C_h_intern(&lf[119],4,"caar");
lf[120]=C_h_intern(&lf[120],5,"cadar");
lf[121]=C_h_intern(&lf[121],5,"cddar");
lf[122]=C_h_intern(&lf[122],4,"cdar");
lf[123]=C_h_intern(&lf[123],21,"\010compilerstring->expr");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[125]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[126]=C_h_intern(&lf[126],5,"begin");
lf[127]=C_h_intern(&lf[127],4,"read");
lf[128]=C_h_intern(&lf[128],6,"unfold");
lf[129]=C_h_intern(&lf[129],11,"eof-object\077");
lf[130]=C_h_intern(&lf[130],6,"values");
lf[131]=C_h_intern(&lf[131],22,"with-input-from-string");
lf[132]=C_h_intern(&lf[132],22,"with-exception-handler");
lf[133]=C_h_intern(&lf[133],30,"call-with-current-continuation");
lf[134]=C_h_intern(&lf[134],30,"\010compilerdecompose-lambda-list");
lf[135]=C_h_intern(&lf[135],25,"\003sysdecompose-lambda-list");
lf[136]=C_h_intern(&lf[136],37,"\010compilerprocess-lambda-documentation");
lf[137]=C_h_intern(&lf[137],30,"\010compilerexpand-profile-lambda");
lf[138]=C_h_intern(&lf[138],29,"\010compilerprofile-lambda-index");
lf[139]=C_h_intern(&lf[139],28,"\010compilerprofile-lambda-list");
lf[140]=C_h_intern(&lf[140],17,"\003sysprofile-entry");
lf[141]=C_h_intern(&lf[141],33,"\010compilerprofile-info-vector-name");
lf[142]=C_h_intern(&lf[142],5,"apply");
lf[143]=C_h_intern(&lf[143],16,"\003sysprofile-exit");
lf[144]=C_h_intern(&lf[144],16,"\003sysdynamic-wind");
lf[145]=C_h_intern(&lf[145],37,"\010compilerinitialize-analysis-database");
lf[146]=C_h_intern(&lf[146],13,"\010compilerput!");
lf[147]=C_h_intern(&lf[147],8,"constant");
lf[148]=C_h_intern(&lf[148],26,"\010compilermutable-constants");
lf[149]=C_h_intern(&lf[149],35,"\010compilerfoldable-extended-bindings");
lf[150]=C_h_intern(&lf[150],8,"foldable");
lf[151]=C_h_intern(&lf[151],16,"extended-binding");
lf[152]=C_h_intern(&lf[152],17,"extended-bindings");
lf[153]=C_h_intern(&lf[153],35,"\010compilerfoldable-standard-bindings");
lf[154]=C_h_intern(&lf[154],41,"\010compilerside-effecting-standard-bindings");
lf[155]=C_h_intern(&lf[155],14,"side-effecting");
lf[156]=C_h_intern(&lf[156],16,"standard-binding");
lf[157]=C_h_intern(&lf[157],17,"standard-bindings");
lf[158]=C_h_intern(&lf[158],12,"\010compilerget");
lf[159]=C_h_intern(&lf[159],18,"\003syshash-table-ref");
lf[160]=C_h_intern(&lf[160],16,"\010compilerget-all");
lf[161]=C_h_intern(&lf[161],10,"filter-map");
lf[162]=C_h_intern(&lf[162],19,"\003syshash-table-set!");
lf[163]=C_h_intern(&lf[163],17,"\010compilercollect!");
lf[164]=C_h_intern(&lf[164],15,"\010compilercount!");
lf[165]=C_h_intern(&lf[165],17,"\010compilerget-line");
lf[166]=C_h_intern(&lf[166],24,"\003sysline-number-database");
lf[167]=C_h_intern(&lf[167],19,"\010compilerget-line-2");
lf[168]=C_h_intern(&lf[168],30,"\010compilerfind-lambda-container");
lf[169]=C_h_intern(&lf[169],12,"contained-in");
lf[170]=C_h_intern(&lf[170],37,"\010compilerdisplay-line-number-database");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[172]=C_h_intern(&lf[172],3,"cdr");
lf[173]=C_h_intern(&lf[173],23,"\003syshash-table-for-each");
lf[174]=C_h_intern(&lf[174],34,"\010compilerdisplay-analysis-database");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[179]=C_h_intern(&lf[179],7,"unknown");
lf[180]=C_h_intern(&lf[180],8,"captured");
lf[181]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[183]=C_h_intern(&lf[183],5,"value");
lf[184]=C_h_intern(&lf[184],15,"potential-value");
lf[185]=C_h_intern(&lf[185],10,"replacable");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[187]=C_h_intern(&lf[187],10,"references");
lf[188]=C_h_intern(&lf[188],10,"call-sites");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[190]=C_h_intern(&lf[190],4,"home");
lf[191]=C_h_intern(&lf[191],8,"contains");
lf[192]=C_h_intern(&lf[192],8,"use-expr");
lf[193]=C_h_intern(&lf[193],12,"closure-size");
lf[194]=C_h_intern(&lf[194],14,"rest-parameter");
lf[195]=C_h_intern(&lf[195],16,"o-r/access-count");
lf[196]=C_h_intern(&lf[196],18,"captured-variables");
lf[197]=C_h_intern(&lf[197],13,"explicit-rest");
lf[198]=C_h_intern(&lf[198],8,"assigned");
lf[199]=C_h_intern(&lf[199],5,"boxed");
lf[200]=C_h_intern(&lf[200],6,"global");
lf[201]=C_h_intern(&lf[201],12,"contractable");
lf[202]=C_h_intern(&lf[202],16,"assigned-locally");
lf[203]=C_h_intern(&lf[203],11,"collapsable");
lf[204]=C_h_intern(&lf[204],9,"removable");
lf[205]=C_h_intern(&lf[205],9,"undefined");
lf[206]=C_h_intern(&lf[206],9,"replacing");
lf[207]=C_h_intern(&lf[207],6,"unused");
lf[208]=C_h_intern(&lf[208],6,"simple");
lf[209]=C_h_intern(&lf[209],9,"inlinable");
lf[210]=C_h_intern(&lf[210],13,"inline-export");
lf[211]=C_h_intern(&lf[211],21,"has-unused-parameters");
lf[212]=C_h_intern(&lf[212],12,"customizable");
lf[213]=C_h_intern(&lf[213],10,"boxed-rest");
lf[214]=C_h_intern(&lf[214],5,"write");
lf[215]=C_h_intern(&lf[215],34,"\010compilerdefault-standard-bindings");
lf[216]=C_h_intern(&lf[216],34,"\010compilerdefault-extended-bindings");
lf[217]=C_h_intern(&lf[217],26,"\010compilerinternal-bindings");
lf[218]=C_h_intern(&lf[218],9,"make-node");
lf[219]=C_h_intern(&lf[219],4,"node");
lf[220]=C_h_intern(&lf[220],5,"node\077");
lf[221]=C_h_intern(&lf[221],15,"node-class-set!");
lf[222]=C_h_intern(&lf[222],14,"\003sysblock-set!");
lf[223]=C_h_intern(&lf[223],10,"node-class");
lf[224]=C_h_intern(&lf[224],20,"node-parameters-set!");
lf[225]=C_h_intern(&lf[225],15,"node-parameters");
lf[226]=C_h_intern(&lf[226],24,"node-subexpressions-set!");
lf[227]=C_h_intern(&lf[227],19,"node-subexpressions");
lf[228]=C_h_intern(&lf[228],16,"\010compilervarnode");
lf[229]=C_h_intern(&lf[229],13,"\004corevariable");
lf[230]=C_h_intern(&lf[230],14,"\010compilerqnode");
lf[231]=C_h_intern(&lf[231],25,"\010compilerbuild-node-graph");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[233]=C_h_intern(&lf[233],15,"\004coreglobal-ref");
lf[234]=C_h_intern(&lf[234],8,"truncate");
lf[235]=C_h_intern(&lf[235],4,"type");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[237]=C_h_intern(&lf[237],6,"fixnum");
lf[238]=C_h_intern(&lf[238],11,"number-type");
lf[239]=C_h_intern(&lf[239],6,"unzip1");
lf[240]=C_h_intern(&lf[240],13,"\004corecallunit");
lf[241]=C_h_intern(&lf[241],9,"\004coreproc");
lf[242]=C_h_intern(&lf[242],29,"\004coreforeign-callback-wrapper");
lf[243]=C_h_intern(&lf[243],5,"sixth");
lf[244]=C_h_intern(&lf[244],5,"fifth");
lf[245]=C_h_intern(&lf[245],8,"\004coreapp");
lf[246]=C_h_intern(&lf[246],9,"\004corecall");
lf[247]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[248]=C_h_intern(&lf[248],24,"\010compilersource-filename");
lf[249]=C_h_intern(&lf[249],28,"\003syssymbol->qualified-string");
lf[250]=C_h_intern(&lf[250],34,"\010compileralways-bound-to-procedure");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[252]=C_h_intern(&lf[252],1,"o");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[254]=C_h_intern(&lf[254],30,"\010compilerbuild-expression-tree");
lf[255]=C_h_intern(&lf[255],12,"\004coreclosure");
lf[256]=C_h_intern(&lf[256],4,"last");
lf[257]=C_h_intern(&lf[257],4,"list");
lf[258]=C_h_intern(&lf[258],7,"butlast");
lf[259]=C_h_intern(&lf[259],11,"\004corelambda");
lf[260]=C_h_intern(&lf[260],9,"\004corebind");
lf[261]=C_h_intern(&lf[261],10,"\004coreunbox");
lf[262]=C_h_intern(&lf[262],8,"\004coreref");
lf[263]=C_h_intern(&lf[263],11,"\004coreupdate");
lf[264]=C_h_intern(&lf[264],13,"\004coreupdate_i");
lf[265]=C_h_intern(&lf[265],8,"\004corebox");
lf[266]=C_h_intern(&lf[266],9,"\004corecond");
lf[267]=C_h_intern(&lf[267],21,"\010compilerfold-boolean");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[269]=C_h_intern(&lf[269],31,"\010compilerinline-lambda-bindings");
lf[270]=C_h_intern(&lf[270],8,"split-at");
lf[271]=C_h_intern(&lf[271],10,"fold-right");
lf[272]=C_h_intern(&lf[272],4,"take");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[274]=C_h_intern(&lf[274],34,"\010compilercopy-node-tree-and-rename");
lf[275]=C_h_intern(&lf[275],9,"alist-ref");
lf[276]=C_h_intern(&lf[276],3,"eq\077");
lf[277]=C_h_intern(&lf[277],18,"\010compilertree-copy");
lf[278]=C_h_intern(&lf[278],4,"cons");
lf[279]=C_h_intern(&lf[279],19,"\010compilercopy-node!");
lf[280]=C_h_intern(&lf[280],19,"\010compilermatch-node");
lf[281]=C_h_intern(&lf[281],1,"a");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[283]=C_h_intern(&lf[283],37,"\010compilerexpression-has-side-effects\077");
lf[284]=C_h_intern(&lf[284],24,"foreign-callback-stub-id");
lf[285]=C_h_intern(&lf[285],4,"find");
lf[286]=C_h_intern(&lf[286],22,"foreign-callback-stubs");
lf[287]=C_h_intern(&lf[287],28,"\010compilersimple-lambda-node\077");
lf[288]=C_h_intern(&lf[288],25,"\010compilerexport-dump-hook");
lf[289]=C_h_intern(&lf[289],30,"\010compilerdump-exported-globals");
lf[290]=C_h_intern(&lf[290],26,"\010compilerblock-compilation");
lf[291]=C_h_intern(&lf[291],8,"string<\077");
lf[292]=C_h_intern(&lf[292],4,"sort");
lf[293]=C_h_intern(&lf[293],20,"\010compilerexport-list");
lf[294]=C_h_intern(&lf[294],22,"\010compilerblock-globals");
lf[295]=C_h_intern(&lf[295],19,"with-output-to-file");
lf[296]=C_h_intern(&lf[296],31,"\010compilerdump-undefined-globals");
lf[297]=C_h_intern(&lf[297],29,"\010compilercheck-global-exports");
lf[298]=C_h_intern(&lf[298],3,"var");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000,exported global variable `~S\047 is not defined");
lf[300]=C_h_intern(&lf[300],6,"delete");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\0005exported global variable `~S\047 is used but not defined");
lf[302]=C_h_intern(&lf[302],29,"\010compilercheck-global-imports");
lf[303]=C_h_intern(&lf[303],5,"redef");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\0000redefinition of imported variable `~s\047 from `~s\047");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000#variable `~s\047 used but not imported");
lf[306]=C_h_intern(&lf[306],8,"keyword\077");
lf[307]=C_h_intern(&lf[307],21,"\010compilerimport-table");
lf[308]=C_h_intern(&lf[308],27,"\010compilerexport-import-hook");
lf[309]=C_h_intern(&lf[309],28,"\010compilerlookup-exports-file");
lf[310]=C_h_intern(&lf[310],9,"read-file");
lf[311]=C_h_intern(&lf[311],21,"\010compilerverbose-mode");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\035loading exports file ~a ...~%");
lf[313]=C_h_intern(&lf[313],28,"\003sysresolve-include-filename");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\010.exports");
lf[315]=C_h_intern(&lf[315],36,"\010compilercompute-database-statistics");
lf[316]=C_h_intern(&lf[316],29,"\010compilercurrent-program-size");
lf[317]=C_h_intern(&lf[317],30,"\010compileroriginal-program-size");
lf[318]=C_h_intern(&lf[318],33,"\010compilerprint-program-statistics");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[325]=C_h_intern(&lf[325],1,"s");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[327]=C_h_intern(&lf[327],35,"\010compilerpprint-expressions-to-file");
lf[328]=C_h_intern(&lf[328],17,"close-output-port");
lf[329]=C_h_intern(&lf[329],12,"pretty-print");
lf[330]=C_h_intern(&lf[330],19,"with-output-to-port");
lf[331]=C_h_intern(&lf[331],16,"open-output-file");
lf[332]=C_h_intern(&lf[332],19,"current-output-port");
lf[333]=C_h_intern(&lf[333],27,"\010compilerforeign-type-check");
lf[334]=C_h_intern(&lf[334],4,"char");
lf[335]=C_h_intern(&lf[335],13,"unsigned-char");
lf[336]=C_h_intern(&lf[336],6,"unsafe");
lf[337]=C_h_intern(&lf[337],25,"\003sysforeign-char-argument");
lf[338]=C_h_intern(&lf[338],3,"int");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-fixnum-argument");
lf[340]=C_h_intern(&lf[340],5,"float");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-flonum-argument");
lf[342]=C_h_intern(&lf[342],7,"pointer");
lf[343]=C_h_intern(&lf[343],26,"\003sysforeign-block-argument");
lf[344]=C_h_intern(&lf[344],15,"nonnull-pointer");
lf[345]=C_h_intern(&lf[345],8,"u8vector");
lf[346]=C_h_intern(&lf[346],34,"\003sysforeign-number-vector-argument");
lf[347]=C_h_intern(&lf[347],16,"nonnull-u8vector");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[349]=C_h_intern(&lf[349],7,"integer");
lf[350]=C_h_intern(&lf[350],28,"\003sysforeign-integer-argument");
lf[351]=C_h_intern(&lf[351],16,"unsigned-integer");
lf[352]=C_h_intern(&lf[352],37,"\003sysforeign-unsigned-integer-argument");
lf[353]=C_h_intern(&lf[353],9,"c-pointer");
lf[354]=C_h_intern(&lf[354],28,"\003sysforeign-pointer-argument");
lf[355]=C_h_intern(&lf[355],17,"nonnull-c-pointer");
lf[356]=C_h_intern(&lf[356],8,"c-string");
lf[357]=C_h_intern(&lf[357],17,"\003sysmake-c-string");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-string-argument");
lf[359]=C_h_intern(&lf[359],16,"nonnull-c-string");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],18,"\003syssymbol->string");
lf[362]=C_h_intern(&lf[362],4,"this");
lf[363]=C_h_intern(&lf[363],8,"slot-ref");
lf[364]=C_h_intern(&lf[364],3,"ref");
lf[365]=C_h_intern(&lf[365],8,"function");
lf[366]=C_h_intern(&lf[366],8,"instance");
lf[367]=C_h_intern(&lf[367],12,"instance-ref");
lf[368]=C_h_intern(&lf[368],16,"nonnull-instance");
lf[369]=C_h_intern(&lf[369],5,"const");
lf[370]=C_h_intern(&lf[370],4,"enum");
lf[371]=C_h_intern(&lf[371],27,"\010compilerforeign-type-table");
lf[372]=C_h_intern(&lf[372],17,"nonnull-c-string*");
lf[373]=C_h_intern(&lf[373],26,"nonnull-unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],9,"c-string*");
lf[375]=C_h_intern(&lf[375],18,"unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],13,"c-string-list");
lf[377]=C_h_intern(&lf[377],14,"c-string-list*");
lf[378]=C_h_intern(&lf[378],18,"unsigned-integer32");
lf[379]=C_h_intern(&lf[379],13,"unsigned-long");
lf[380]=C_h_intern(&lf[380],4,"long");
lf[381]=C_h_intern(&lf[381],9,"integer32");
lf[382]=C_h_intern(&lf[382],17,"nonnull-u16vector");
lf[383]=C_h_intern(&lf[383],16,"nonnull-s8vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s16vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-u32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-f32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f64vector");
lf[389]=C_h_intern(&lf[389],9,"u16vector");
lf[390]=C_h_intern(&lf[390],8,"s8vector");
lf[391]=C_h_intern(&lf[391],9,"s16vector");
lf[392]=C_h_intern(&lf[392],9,"u32vector");
lf[393]=C_h_intern(&lf[393],9,"s32vector");
lf[394]=C_h_intern(&lf[394],9,"f32vector");
lf[395]=C_h_intern(&lf[395],9,"f64vector");
lf[396]=C_h_intern(&lf[396],22,"nonnull-scheme-pointer");
lf[397]=C_h_intern(&lf[397],12,"nonnull-blob");
lf[398]=C_h_intern(&lf[398],19,"nonnull-byte-vector");
lf[399]=C_h_intern(&lf[399],11,"byte-vector");
lf[400]=C_h_intern(&lf[400],4,"blob");
lf[401]=C_h_intern(&lf[401],14,"scheme-pointer");
lf[402]=C_h_intern(&lf[402],6,"double");
lf[403]=C_h_intern(&lf[403],6,"number");
lf[404]=C_h_intern(&lf[404],12,"unsigned-int");
lf[405]=C_h_intern(&lf[405],5,"short");
lf[406]=C_h_intern(&lf[406],14,"unsigned-short");
lf[407]=C_h_intern(&lf[407],4,"byte");
lf[408]=C_h_intern(&lf[408],13,"unsigned-byte");
lf[409]=C_h_intern(&lf[409],5,"int32");
lf[410]=C_h_intern(&lf[410],14,"unsigned-int32");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[412]=C_h_intern(&lf[412],36,"\010compilerforeign-type-convert-result");
lf[413]=C_h_intern(&lf[413],38,"\010compilerforeign-type-convert-argument");
lf[414]=C_h_intern(&lf[414],27,"\010compilerfinal-foreign-type");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[416]=C_h_intern(&lf[416],37,"\010compilerestimate-foreign-result-size");
lf[417]=C_h_intern(&lf[417],9,"integer64");
lf[418]=C_h_intern(&lf[418],4,"bool");
lf[419]=C_h_intern(&lf[419],4,"void");
lf[420]=C_h_intern(&lf[420],13,"scheme-object");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[422]=C_h_intern(&lf[422],46,"\010compilerestimate-foreign-result-location-size");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[425]=C_h_intern(&lf[425],30,"\010compilerfinish-foreign-result");
lf[426]=C_h_intern(&lf[426],17,"\003syspeek-c-string");
lf[427]=C_h_intern(&lf[427],25,"\003syspeek-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],26,"\003syspeek-and-free-c-string");
lf[429]=C_h_intern(&lf[429],34,"\003syspeek-and-free-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],17,"\003sysintern-symbol");
lf[431]=C_h_intern(&lf[431],22,"\003syspeek-c-string-list");
lf[432]=C_h_intern(&lf[432],31,"\003syspeek-and-free-c-string-list");
lf[433]=C_h_intern(&lf[433],35,"\010tinyclosmake-instance-from-pointer");
lf[434]=C_h_intern(&lf[434],4,"make");
lf[435]=C_h_intern(&lf[435],28,"\010compilerscan-used-variables");
lf[436]=C_h_intern(&lf[436],28,"\010compilerscan-free-variables");
lf[437]=C_h_intern(&lf[437],11,"lset-adjoin");
lf[438]=C_h_intern(&lf[438],25,"\010compilertopological-sort");
lf[439]=C_h_intern(&lf[439],7,"colored");
lf[440]=C_h_intern(&lf[440],23,"\010compilerchop-separator");
lf[441]=C_h_intern(&lf[441],9,"substring");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[443]=C_h_intern(&lf[443],23,"\010compilerchop-extension");
lf[444]=C_h_intern(&lf[444],22,"\010compilerprint-version");
lf[445]=C_h_intern(&lf[445],5,"print");
lf[446]=C_h_intern(&lf[446],15,"chicken-version");
lf[447]=C_h_intern(&lf[447],6,"print*");
lf[448]=C_h_intern(&lf[448],9,"\003syserror");
lf[449]=C_h_intern(&lf[449],20,"\010compilerprint-usage");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\021\244Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012    -quiet               "
"       do not display compile information\012\012  File and pathname options:\012\012    -ou"
"tput-file FILENAME       specifies output-filename, default is \047out.c\047\012    -incl"
"ude-path PATHNAME      specifies alternative path for included files\012    -to-std"
"out                  write compiled file to stdout instead of file\012\012  Language o"
"ptions:\012\012    -feature SYMBOL             register feature identifier\012\012  Syntax r"
"elated options:\012\012    -case-insensitive           don\047t preserve case of read sym"
"bols\012    -keyword-style STYLE        allow alternative keyword syntax (none, pre"
"fix or suffix)\012    -run-time-macros            macros are made available at run-"
"time\012\012  Translation options:\012\012    -explicit-use               do not use units \047"
"library\047 and \047eval\047 by default\012    -check-syntax               stop compilation "
"after macro-expansion\012    -analyze-only               stop compilation after fir"
"st analysis pass\012\012  Debugging options:\012\012    -no-warnings                disable "
"warnings\012    -disable-warning CLASS      disable specific class of warnings\012    "
"-debug-level NUMBER         set level of available debugging information\012    -no"
"-trace                   disable tracing information\012    -profile               "
"     executable emits profiling information \012    -profile-name FILENAME      nam"
"e of the generated profile information file\012    -accumulate-profile         exec"
"utable emits profiling information in append mode\012    -no-lambda-info           "
"  omit additional procedure-information\012    -emit-exports FILENAME      write ex"
"ported toplevel variables to FILENAME\012    -check-imports              look for u"
"ndefined toplevel variables\012    -import FILENAME            read externally expo"
"rted symbols from FILENAME\012\012  Optimization options:\012\012    -optimize-level NUMBER "
"     enable certain sets of optimization options\012    -optimize-leaf-routines    "
" enable leaf routine optimization\012    -lambda-lift                enable lambda-"
"lifting\012    -no-usual-integrations      standard procedures may be redefined\012   "
" -unsafe                     disable safety checks\012    -block                   "
"   enable block-compilation\012    -disable-interrupts         disable interrupts i"
"n compiled code\012    -fixnum-arithmetic          assume all numbers are fixnums\012 "
"   -benchmark-mode             fixnum mode, no interrupts and opt.-level 3\012    -"
"disable-stack-overflow-checks  disables detection of stack-overflows.\012    -inlin"
"e                     enable inlining\012    -inline-limit               set inlini"
"ng threshold\012\012  Configuration options:\012\012    -unit NAME                  compile "
"file as a library unit\012    -uses NAME                  declare library unit as u"
"sed.\012    -heap-size NUMBER           specifies heap-size of compiled executable\012"
"    -heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-gr"
"owth PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage "
"PERCENTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER\012    -s"
"tack-size NUMBER          specifies nursery size of compiled executable\012    -ext"
"end FILENAME            load file before compilation commences\012    -prelude EXPR"
"ESSION         add expression to front of source file\012    -postlude EXPRESSION  "
"      add expression to end of source file\012    -prologue FILENAME          inclu"
"de file before main source file\012    -epilogue FILENAME          include file aft"
"er main source file\012    -dynamic                    compile as dynamically loada"
"ble code\012    -require-extension NAME     require extension NAME in compiled code"
"\012    -extension                  compile as extension (dynamic or static)\012\012  Obs"
"cure options:\012\012    -debug MODES                display debugging output for the "
"given modes\012    -unsafe-libraries           marks the generated file as being li"
"nked\012                                with the unsafe runtime system\012    -raw    "
"                    do not generate implicit init- and exit code\011\011\011       \012    -"
"emit-external-prototypes-first  emit protoypes for callbacks before foreign\012    "
"                            declarations\012");
lf[451]=C_h_intern(&lf[451],36,"\010compilermake-block-variable-literal");
lf[452]=C_h_intern(&lf[452],22,"block-variable-literal");
lf[453]=C_h_intern(&lf[453],32,"\010compilerblock-variable-literal\077");
lf[454]=C_h_intern(&lf[454],32,"block-variable-literal-name-set!");
lf[455]=C_h_intern(&lf[455],36,"\010compilerblock-variable-literal-name");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[457]=C_h_intern(&lf[457],6,"random");
lf[458]=C_h_intern(&lf[458],15,"current-seconds");
lf[459]=C_h_intern(&lf[459],23,"\010compilerset-real-name!");
lf[460]=C_h_intern(&lf[460],24,"\010compilerreal-name-table");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[462]=C_h_intern(&lf[462],19,"\010compilerreal-name2");
lf[463]=C_h_intern(&lf[463],32,"\010compilerdisplay-real-name-table");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[465]=C_h_intern(&lf[465],28,"\010compilersource-info->string");
lf[466]=C_h_intern(&lf[466],4,"conc");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[469]=C_h_intern(&lf[469],11,"make-string");
lf[470]=C_h_intern(&lf[470],3,"max");
lf[471]=C_h_intern(&lf[471],12,"string-null\077");
lf[472]=C_h_intern(&lf[472],19,"\010compilerdump-nodes");
lf[473]=C_h_intern(&lf[473],19,"\003syswrite-char/port");
lf[474]=C_h_intern(&lf[474],19,"\003sysstandard-output");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[478]=C_h_intern(&lf[478],18,"\003sysuser-read-hook");
lf[479]=C_h_intern(&lf[479],15,"foreign-declare");
lf[480]=C_h_intern(&lf[480],7,"declare");
lf[481]=C_h_intern(&lf[481],34,"\010compilerscan-sharp-greater-string");
lf[482]=C_h_intern(&lf[482],18,"\003sysread-char/port");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[484]=C_h_intern(&lf[484],17,"get-output-string");
lf[485]=C_h_intern(&lf[485],18,"open-output-string");
lf[486]=C_h_intern(&lf[486],35,"\010compilerprocess-custom-declaration");
lf[487]=C_h_intern(&lf[487],29,"\010compilercustom-declare-alist");
lf[488]=C_h_intern(&lf[488],31,"\010compileremit-control-file-item");
lf[489]=C_h_intern(&lf[489],25,"\010compilercsc-control-file");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\004~S~%");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\006#%csc\012");
lf[492]=C_h_intern(&lf[492],26,"pathname-replace-extension");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[494]=C_h_intern(&lf[494],32,"\010compilerregister-compiler-macro");
lf[495]=C_h_intern(&lf[495],29,"\010compilercompiler-macro-table");
lf[496]=C_h_intern(&lf[496],4,"eval");
lf[497]=C_h_intern(&lf[497],6,"\000whole");
lf[498]=C_h_intern(&lf[498],7,"call/cc");
lf[499]=C_h_intern(&lf[499],11,"make-vector");
lf[500]=C_h_intern(&lf[500],27,"condition-property-accessor");
lf[501]=C_h_intern(&lf[501],3,"exn");
lf[502]=C_h_intern(&lf[502],7,"message");
lf[503]=C_h_intern(&lf[503],19,"condition-predicate");
C_register_lf2(lf,504,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1444 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1447 in k1444 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1450 in k1447 in k1444 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1461,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate(&lf[3],lf[4]);
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1467,tmp=(C_word)a,a+=2,tmp));
t5=C_set_block_item(lf[6],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[7],0,C_SCHEME_END_OF_LIST);
t7=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1472,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1499,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[23]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1539,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1568,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1587,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[37]+1,C_retrieve(lf[31]));
t13=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1612,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1615,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1658,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1726,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1762,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1783,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1808,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[52]+1,C_retrieve(lf[53]));
t21=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1852,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1946,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2002,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2009,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2016,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2063,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2075,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2138,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2169,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2215,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2245,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2291,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2351,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2434,tmp=(C_word)a,a+=2,tmp));
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 310  condition-predicate */
t36=C_retrieve(lf[503]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,lf[501]);}

/* k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 311  condition-property-accessor */
t3=C_retrieve(lf[500]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[501],lf[502]);}

/* k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[134]+1,C_retrieve(lf[135]));
t4=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2912,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2915,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2972,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3033,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3051,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3069,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3115,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3167,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3224,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3234,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3270,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3294,tmp=(C_word)a,a+=2,tmp));
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3723,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3729,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3735,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[223]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3744,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[224]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3753,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3762,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3771,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3780,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3789,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3795,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3804,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3813,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4321,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4615,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4663,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4756,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4934,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4968,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[280]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5030,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5225,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5311,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5403,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5409,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5495,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5526,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5570,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5628,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5634,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5685,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5765,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5804,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5840,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6695,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6726,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6757,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6797,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7116,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[425]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7426,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[435]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7702,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[436]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7780,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7939,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8136,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[443]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8165,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[444]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8207,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[449]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8245,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[451]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8257,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[453]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8263,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[454]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8269,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[455]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8278,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8287,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[459]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8331,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8337,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[462]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8416,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[463]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8428,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[465]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8440,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[471]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8516,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[472]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8522,tmp=(C_word)a,a+=2,tmp));
t76=C_retrieve(lf[478]);
t77=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8609,a[2]=t76,tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[481]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8634,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[486]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8703,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[488]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8766,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[494]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8795,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8906,tmp=(C_word)a,a+=2,tmp));
t83=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t83+1)))(2,t83,C_SCHEME_UNDEFINED);}

/* ##compiler#big-fixnum? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8906,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8795,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8799,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[495]))){
t6=t5;
f_8799(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8904,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1485 make-vector */
t7=*((C_word*)lf[499]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k8902 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[495]+1,t1);
t3=((C_word*)t0)[2];
f_8799(t3,t2);}

/* k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8799,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1486 call/cc */
t3=*((C_word*)lf[498]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8804,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8808,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1488 gensym */
t4=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8806 in a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8808,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8811,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8844,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8844(t8,t4,((C_word*)t0)[2]);}

/* loop in k8806 in a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8844(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8844,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[497],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8860,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=t5;
f_8860(2,t7,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 1494 return */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8888,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* support.scm: 1497 loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8886 in loop in k8806 in a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8888,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8858 in loop in k8806 in a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cddr(((C_word*)t0)[4]));}

/* k8809 in k8806 in a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8814,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8818,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)((C_word*)t0)[3])[1]);
t5=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,lf[105],t5);
t7=(C_word)C_a_i_list(&a,2,lf[172],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_a_i_list(&a,3,lf[142],t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[105],t4,t8);
/* support.scm: 1501 eval */
t10=C_retrieve(lf[496]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,t9);}

/* k8816 in k8809 in k8806 in a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1498 ##sys#hash-table-set! */
t2=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[495]),((C_word*)t0)[2],t1);}

/* k8812 in k8809 in k8806 in a8803 in k8797 in ##compiler#register-compiler-macro in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#emit-control-file-item in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8766,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8770,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[489]))){
t4=t3;
f_8770(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8777,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8793,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1471 pathname-replace-extension */
t6=C_retrieve(lf[492]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[248]),lf[493]);}}

/* k8791 in ##compiler#emit-control-file-item in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1471 open-output-file */
t2=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8775 in ##compiler#emit-control-file-item in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8777,2,t0,t1);}
t2=C_mutate((C_word*)lf[489]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1472 display */
t4=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[491],C_retrieve(lf[489]));}

/* k8778 in k8775 in ##compiler#emit-control-file-item in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8780,2,t0,t1);}
t2=C_retrieve(lf[5]);
t3=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8782,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
f_8770(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k8778 in k8775 in ##compiler#emit-control-file-item in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8786,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1476 close-output-port */
t3=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[489]));}

/* k8784 in ##compiler#compiler-cleanup-hook in k8778 in k8775 in ##compiler#emit-control-file-item in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1477 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8768 in ##compiler#emit-control-file-item in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1478 fprintf */
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[489]),lf[490],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8703,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[487]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8725,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_8725(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8740,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1458 open-output-file */
t14=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k8738 in ##compiler#process-custom-declaration in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8740,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[487]));
t5=C_mutate((C_word*)lf[487]+1,t4);
t6=C_retrieve(lf[5]);
t7=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8750,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1466 cons* */
t9=C_retrieve(lf[99]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8762 in k8738 in ##compiler#process-custom-declaration in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1466 emit-control-file-item */
t2=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_8750 in k8738 in ##compiler#process-custom-declaration in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8754,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1464 close-output-port */
t3=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8752 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1465 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8723 in ##compiler#process-custom-declaration in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8725,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[20]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8733,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a8729 in k8723 in ##compiler#process-custom-declaration in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8733,3,t0,t1,t2);}
/* support.scm: 1467 g1304 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8634(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8634,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8638,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1428 open-output-string */
t4=C_retrieve(lf[485]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8638,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8643,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8643(t5,((C_word*)t0)[2]);}

/* loop in k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8643,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8645 in loop in k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8647,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1431 quit */
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[483]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8665,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1433 newline */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8677,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8698,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k8696 in k8645 in loop in k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1445 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8643(t2,((C_word*)t0)[2]);}

/* k8675 in k8645 in loop in k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8677,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1438 get-output-string */
t3=C_retrieve(lf[484]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8689,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k8687 in k8675 in k8645 in loop in k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8692,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8690 in k8687 in k8675 in k8645 in loop in k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1442 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8643(t2,((C_word*)t0)[2]);}

/* k8663 in k8645 in loop in k8636 in ##compiler#scan-sharp-greater-string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1434 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8643(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8609,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8619,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[482]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1425 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k8617 in ##sys#user-read-hook in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8622,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1423 scan-sharp-greater-string */
t3=C_retrieve(lf[481]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8620 in k8617 in ##sys#user-read-hook in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8622,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[479],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[480],t2));}

/* ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8522,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8526,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8531,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8531(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8531(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8531,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8544,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1401 make-string */
t11=*((C_word*)lf[469]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t2,C_make_character(32));}

/* k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8544,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8550,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1403 printf */
t4=C_retrieve(lf[16]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[477],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8553,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8602 in k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8603,3,t0,t1,t2);}
/* loop1249 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8531(t3,t1,((C_word*)t0)[2],t2);}

/* k8551 in k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8553,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8568,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1407 printf */
t6=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[476],t5);}
else{
t4=t3;
f_8559(2,t4,C_SCHEME_UNDEFINED);}}

/* k8566 in k8551 in k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8571,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8576,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8576(t6,t2,C_fix(5));}

/* do1263 in k8566 in k8551 in k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8576(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8576,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8586,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1410 printf */
t5=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[475],t4);}}

/* k8584 in do1263 in k8566 in k8551 in k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8576(t3,((C_word*)t0)[2],t2);}

/* k8569 in k8566 in k8551 in k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[474]+1));}

/* k8557 in k8551 in k8548 in k8542 in loop in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[473]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[474]+1));}

/* k8524 in ##compiler#dump-nodes in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1413 newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8516,3,t0,t1,t2);}
/* support.scm: 1391 string-null? */
t3=C_retrieve(lf[471]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#source-info->string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8447,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cdddr(t2);
t7=t3;
f_8447(t7,(C_word)C_i_nullp(t6));}
else{
t6=t3;
f_8447(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8447(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8447(t4,C_SCHEME_FALSE);}}

/* k8445 in ##compiler#source-info->string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8447,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8459,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1384 ->string */
t6=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* ->string */
t2=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k8457 in k8445 in ##compiler#source-info->string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8466,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8470,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1385 max */
t6=*((C_word*)lf[470]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k8468 in k8457 in k8445 in ##compiler#source-info->string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1385 make-string */
t2=*((C_word*)lf[469]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k8464 in k8457 in k8445 in ##compiler#source-info->string in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1385 conc */
t2=C_retrieve(lf[466]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[467],((C_word*)t0)[3],t1,lf[468],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8434,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1376 ##sys#hash-table-for-each */
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[460]));}

/* a8433 in ##compiler#display-real-name-table in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8434,4,t0,t1,t2,t3);}
/* support.scm: 1378 printf */
t4=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[464],t2,t3);}

/* ##compiler#real-name2 in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8416,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8420,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1372 ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[460]),t2);}

/* k8418 in ##compiler#real-name2 in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1373 real-name */
t2=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8337r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8337r(t0,t1,t2,t3);}}

static void C_ccall f_8337r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8340,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8356,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1356 resolve */
f_8340(t5,t2);}

/* k8354 in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8356,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1360 ##sys#symbol->qualified-string */
t5=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
/* support.scm: 1369 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1357 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8379 in k8354 in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8385,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1361 get */
t3=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[169]);}

/* k8383 in k8379 in k8354 in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8385,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8387,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8387(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k8383 in k8379 in k8354 in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8387(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8387,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1363 resolve */
f_8340(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k8392 in loop in k8383 in k8379 in k8354 in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8394,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8407,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1366 sprintf */
t4=C_retrieve(lf[46]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[461],((C_word*)t0)[4],t1);}}

/* k8405 in k8392 in loop in k8383 in k8379 in k8354 in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8411,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1367 get */
t3=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[169]);}

/* k8409 in k8405 in k8392 in loop in k8383 in k8379 in k8354 in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1366 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8387(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8340(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8340,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8344,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1351 ##sys#hash-table-ref */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[460]),t2);}

/* k8342 in resolve in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8344,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8350,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1353 ##sys#hash-table-ref */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[460]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k8348 in k8342 in resolve in ##compiler#real-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8331,4,t0,t1,t2,t3);}
/* support.scm: 1347 ##sys#hash-table-set! */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[460]),t2,t3);}

/* ##compiler#make-random-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_8287r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8287r(t0,t1,t2);}}

static void C_ccall f_8287r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8295,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8299,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1334 gensym */
t5=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_8299(2,t6,(C_word)C_i_car(t2));}
else{
/* support.scm: 1334 ##sys#error */
t6=*((C_word*)lf[448]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k8297 in ##compiler#make-random-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8303,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1335 current-seconds */
t3=C_retrieve(lf[458]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8301 in k8297 in ##compiler#make-random-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8307,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1336 random */
t3=C_retrieve(lf[457]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k8305 in k8301 in k8297 in ##compiler#make-random-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1333 sprintf */
t2=C_retrieve(lf[46]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[456],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8293 in ##compiler#make-random-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1332 string->symbol */
t2=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8278,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[452]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* block-variable-literal-name-set! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8269,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[452]);
/* support.scm: 1325 ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* ##compiler#block-variable-literal? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8263,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[452]));}

/* ##compiler#make-block-variable-literal in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8257,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[452],t2));}

/* ##compiler#print-usage in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8249,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1224 print-version */
t3=C_retrieve(lf[444]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8247 in ##compiler#print-usage in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8252,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1225 newline */
t3=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8250 in k8247 in ##compiler#print-usage in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1226 display */
t2=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[450]);}

/* ##compiler#print-version in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_8207r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8207r(t0,t1,t2);}}

static void C_ccall f_8207r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8211,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_8211(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_8211(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[448]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k8209 in ##compiler#print-version in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1220 print* */
t3=*((C_word*)lf[447]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[4]);}
else{
t3=t2;
f_8214(2,t3,C_SCHEME_UNDEFINED);}}

/* k8212 in k8209 in ##compiler#print-version in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1221 chicken-version */
t3=C_retrieve(lf[446]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k8219 in k8212 in k8209 in ##compiler#print-version in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1221 print */
t2=*((C_word*)lf[445]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8165,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8174,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8174(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8174(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8174,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1213 substring */
t6=*((C_word*)lf[441]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1214 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8136,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8146,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_8146(t7,(C_word)C_i_memq(t6,lf[442]));}
else{
t6=t5;
f_8146(t6,C_SCHEME_FALSE);}}

/* k8144 in ##compiler#chop-separator in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1206 substring */
t2=*((C_word*)lf[441]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7939,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7948,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7995,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8030,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8067,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8118,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a8117 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8118,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1188 insert */
t5=((C_word*)t0)[2];
f_7948(t5,t1,t3,t4);}

/* k8065 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8112,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1191 caar */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k8110 in k8065 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8116,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1191 cdar */
t3=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8114 in k8110 in k8065 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1191 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8030(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8068 in k8065 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8073,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8075,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a8074 in k8068 in k8065 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8075,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1193 lookup */
t5=((C_word*)t0)[2];
f_7995(t5,t3,t4);}

/* k8077 in a8074 in k8068 in k8065 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[439]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1195 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8030(t5,((C_word*)t0)[4],t3,t4);}}

/* k8071 in k8068 in k8065 in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8030(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8030,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8034,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1176 insert */
t5=((C_word*)t0)[2];
f_7948(t5,t4,t2,lf[439]);}

/* k8032 in visit in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8037,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8042 in k8032 in visit in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8043,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8047,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1179 lookup */
t4=((C_word*)t0)[2];
f_7995(t4,t3,t2);}

/* k8045 in a8042 in k8032 in visit in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[439]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1181 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8030(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k8035 in k8032 in visit in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8037,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7995(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7995,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8001,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8001(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_8001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8001,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8014,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8028,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1171 caar */
t5=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k8026 in loop in lookup in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1171 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8012 in loop in lookup in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1171 cdar */
t2=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1172 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8001(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7948(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7948,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7954(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7954,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7993,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1165 caar */
t5=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7991 in loop in insert in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1165 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7973 in loop in insert in ##compiler#topological-sort in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1166 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7954(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7780,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7783,a[2]=t8,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7924,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7937,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1148 walk */
t12=((C_word*)t6)[1];
f_7783(t12,t11,t2,C_SCHEME_END_OF_LIST);}

/* k7935 in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7924(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7924,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7930,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a7929 in walkeach in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7930,3,t0,t1,t2);}
/* support.scm: 1146 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7783(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7783(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7783,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[82]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t7,a[8]=t9,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t10)){
t12=t11;
f_7802(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[113]);
if(C_truep(t12)){
t13=t11;
f_7802(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[114]);
if(C_truep(t13)){
t14=t11;
f_7802(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[241]);
t15=t11;
f_7802(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[115])));}}}}

/* k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7802,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[229]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[6]))){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7821,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1130 lset-adjoin */
t5=C_retrieve(lf[437]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[5])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[104]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7833,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[6]))){
t6=t5;
f_7833(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7847,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1133 lset-adjoin */
t7=C_retrieve(lf[437]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[92]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7856,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1136 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7783(t7,t5,t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[259]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1139 decompose-lambda-list */
t8=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[9],t6,t7);}
else{
/* support.scm: 1143 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7924(t6,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[6]);}}}}}}

/* a7885 in k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7886,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7898,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1142 append */
t7=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7896 in a7885 in k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1142 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7783(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7854 in k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7867,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1137 append */
t4=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7865 in k7854 in k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1137 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7783(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7845 in k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7833(t3,t2);}

/* k7831 in k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1134 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7783(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7819 in k7800 in walk in ##compiler#scan-free-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7702,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7706,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7708,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7708(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7708,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[229]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[104]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7730,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7736,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_7736(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_7736(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[82]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7763,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_7763(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[113]);
t12=t10;
f_7763(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[114])));}}}

/* k7761 in walk in ##compiler#scan-used-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k7734 in walk in ##compiler#scan-used-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7736,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_7730(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_7730(t2,C_SCHEME_UNDEFINED);}}

/* k7728 in walk in ##compiler#scan-used-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7704 in ##compiler#scan-used-variables in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[131],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7426,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[426],t3,t6));}
else{
t6=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[427],t3,t7));}
else{
t7=(C_word)C_eqp(t4,lf[374]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[428],t3,t9));}
else{
t9=(C_word)C_eqp(t4,lf[372]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t10)){
t11=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[429],t3,t11));}
else{
t11=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t11)){
t12=(C_word)C_a_i_list(&a,2,lf[82],C_fix(0));
t13=(C_word)C_a_i_list(&a,3,lf[426],t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,2,lf[430],t13));}
else{
t12=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t12)){
t13=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[431],t3,t13));}
else{
t13=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t13)){
t14=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[432],t3,t14));}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7529,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_eqp(t15,lf[366]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7551,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(t2);
t21=t17;
f_7551(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_7551(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_7551(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(t2);
t18=(C_word)C_eqp(t17,lf[367]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7598,a[2]=t3,a[3]=t14,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t21))){
t22=(C_word)C_i_cdddr(t2);
t23=t19;
f_7598(t23,(C_word)C_i_nullp(t22));}
else{
t22=t19;
f_7598(t22,C_SCHEME_FALSE);}}
else{
t21=t19;
f_7598(t21,C_SCHEME_FALSE);}}
else{
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7639,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_car(t2);
t21=(C_word)C_eqp(t20,lf[368]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t23))){
t24=(C_word)C_i_cdddr(t2);
t25=t19;
f_7639(t25,(C_word)C_i_nullp(t24));}
else{
t24=t19;
f_7639(t24,C_SCHEME_FALSE);}}
else{
t23=t19;
f_7639(t23,C_SCHEME_FALSE);}}
else{
t22=t19;
f_7639(t22,C_SCHEME_FALSE);}}}}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t3);}}}}}}}}}

/* k7637 in ##compiler#finish-foreign-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7639,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,lf[82],lf[362]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,4,lf[434],t3,t4,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7596 in ##compiler#finish-foreign-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7598,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1093 g1090 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7529(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k7549 in ##compiler#finish-foreign-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* support.scm: 1093 g1090 */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7529(C_a_i(&a,9),((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g1090 in ##compiler#finish-foreign-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static C_word C_fcall f_7529(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_a_i_list(&a,3,lf[433],((C_word*)t0)[2],t1));}

/* ##compiler#estimate-foreign-result-location-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7116,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7119,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7128,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1057 follow-without-loop */
t6=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a7419 in ##compiler#estimate-foreign-result-location-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7420,2,t0,t1);}
/* support.scm: 1078 quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[424],((C_word*)t0)[2]);}

/* a7127 in ##compiler#estimate-foreign-result-location-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7128,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7138,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_7138(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_7138(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_7138(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_7138(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t10)){
t11=t6;
f_7138(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t11)){
t12=t6;
f_7138(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t12)){
t13=t6;
f_7138(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t13)){
t14=t6;
f_7138(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t14)){
t15=t6;
f_7138(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_7138(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_7138(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t17)){
t18=t6;
f_7138(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t18)){
t19=t6;
f_7138(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t19)){
t20=t6;
f_7138(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t20)){
t21=t6;
f_7138(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t21)){
t22=t6;
f_7138(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t22)){
t23=t6;
f_7138(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t23)){
t24=t6;
f_7138(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_7138(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[401]);
if(C_truep(t25)){
t26=t6;
f_7138(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[396]);
if(C_truep(t26)){
t27=t6;
f_7138(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t27)){
t28=t6;
f_7138(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t28)){
t29=t6;
f_7138(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t29)){
t30=t6;
f_7138(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t30)){
t31=t6;
f_7138(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t31)){
t32=t6;
f_7138(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t32)){
t33=t6;
f_7138(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t33)){
t34=t6;
f_7138(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t34)){
t35=t6;
f_7138(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t35)){
t36=t6;
f_7138(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[376]);
t37=t6;
f_7138(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[377])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7136 in a7127 in ##compiler#estimate-foreign-result-location-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7138,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1066 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[403]));
if(C_truep(t3)){
/* support.scm: 1068 words->bytes */
t4=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[6],C_fix(2));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1070 ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t5=t4;
f_7156(2,t5,C_SCHEME_FALSE);}}}}

/* k7154 in k7136 in a7127 in ##compiler#estimate-foreign-result-location-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7156,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1072 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[364]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_7190(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_7190(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_7190(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_7190(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
t9=t4;
f_7190(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[365])));}}}}}
else{
/* support.scm: 1077 err */
f_7119(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k7188 in k7154 in k7136 in a7127 in ##compiler#estimate-foreign-result-location-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7190(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1075 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(1));}
else{
/* support.scm: 1076 err */
f_7119(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_7119(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7119,NULL,2,t1,t2);}
/* support.scm: 1056 quit */
t3=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[423],t2);}

/* ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6797,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6803,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1027 follow-without-loop */
t5=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a7109 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7110,2,t0,t1);}
/* support.scm: 1052 quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[421],((C_word*)t0)[2]);}

/* a6802 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6803,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6813,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6813(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_6813(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_6813(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_6813(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t10)){
t11=t6;
f_6813(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t11)){
t12=t6;
f_6813(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t12)){
t13=t6;
f_6813(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t13)){
t14=t6;
f_6813(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t14)){
t15=t6;
f_6813(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_6813(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_6813(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[409]);
t18=t6;
f_6813(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[410])));}}}}}}}}}}}}

/* k6811 in a6802 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6813,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6822(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=t3;
f_6822(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t5)){
t6=t3;
f_6822(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_6822(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t7)){
t8=t3;
f_6822(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t8)){
t9=t3;
f_6822(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t9)){
t10=t3;
f_6822(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t10)){
t11=t3;
f_6822(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t11)){
t12=t3;
f_6822(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
t13=t3;
f_6822(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[377])));}}}}}}}}}}}

/* k6820 in k6811 in a6802 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6822,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1037 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6834(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_6834(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t5)){
t6=t3;
f_6834(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t6)){
t7=t3;
f_6834(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t8=t3;
f_6834(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}

/* k6832 in k6820 in k6811 in a6802 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6834,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1039 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(4));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[340]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_6846(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[402]);
if(C_truep(t4)){
t5=t3;
f_6846(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
t6=t3;
f_6846(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[417])));}}}}

/* k6844 in k6832 in k6820 in k6811 in a6802 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6846,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 1041 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1043 ##sys#hash-table-ref */
t3=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6852(2,t3,C_SCHEME_FALSE);}}}

/* k6850 in k6844 in k6832 in k6820 in k6811 in a6802 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1045 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[364]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_6886(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_6886(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_6886(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_6886(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t8)){
t9=t4;
f_6886(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[365]);
if(C_truep(t9)){
t10=t4;
f_6886(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[366]);
if(C_truep(t10)){
t11=t4;
f_6886(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[367]);
t12=t4;
f_6886(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[368])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k6884 in k6850 in k6844 in k6832 in k6820 in k6811 in a6802 in ##compiler#estimate-foreign-result-size in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6886(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1049 words->bytes */
t2=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6757,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6763,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6791,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1014 follow-without-loop */
t5=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a6790 in ##compiler#final-foreign-type in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6791,2,t0,t1);}
/* support.scm: 1021 quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[415],((C_word*)t0)[2]);}

/* a6762 in ##compiler#final-foreign-type in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6763,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6767,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1017 ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[371]),t2);}
else{
t5=t4;
f_6767(2,t5,C_SCHEME_FALSE);}}

/* k6765 in a6762 in ##compiler#final-foreign-type in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1019 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6726,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6730,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6739,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1008 ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_6730(t5,C_SCHEME_FALSE);}}

/* k6737 in ##compiler#foreign-type-convert-argument in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6739,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_6730(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6730(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6730(t2,C_SCHEME_FALSE);}}

/* k6728 in ##compiler#foreign-type-convert-argument in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6695,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6699,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6708,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1001 ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_6699(t5,C_SCHEME_FALSE);}}

/* k6706 in ##compiler#foreign-type-convert-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6708,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_6699(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_6699(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_6699(t2,C_SCHEME_FALSE);}}

/* k6697 in ##compiler#foreign-type-convert-result in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5840,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6689,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 902  follow-without-loop */
t6=C_retrieve(lf[80]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a6688 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6689,2,t0,t1);}
/* support.scm: 994  quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[411],((C_word*)t0)[2]);}

/* a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5846,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5852,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5852(t7,t1,t2);}

/* repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5852,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[334]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[335]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[4]:(C_word)C_a_i_list(&a,2,lf[337],((C_word*)t0)[4])));}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5877(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[404]);
if(C_truep(t8)){
t9=t7;
f_5877(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t9)){
t10=t7;
f_5877(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t10)){
t11=t7;
f_5877(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t11)){
t12=t7;
f_5877(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t12)){
t13=t7;
f_5877(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[409]);
t14=t7;
f_5877(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[410])));}}}}}}}}

/* k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5877,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[339],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5892(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t5=t3;
f_5892(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[403])));}}}

/* k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5892,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[341],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5907(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
if(C_truep(t4)){
t5=t3;
f_5907(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t6=t3;
f_5907(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[401])));}}}}

/* k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5907,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5910,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 912  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5945(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
if(C_truep(t4)){
t5=t3;
f_5945(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
t6=t3;
f_5945(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[398])));}}}}

/* k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5945,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[343],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5960(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t4)){
t5=t3;
f_5960(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t5)){
t6=t3;
f_5960(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t6)){
t7=t3;
f_5960(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t7)){
t8=t3;
f_5960(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t8)){
t9=t3;
f_5960(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
t10=t3;
f_5960(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[395])));}}}}}}}}

/* k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5960,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 924  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6002(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_6002(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t5)){
t6=t3;
f_6002(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t6)){
t7=t3;
f_6002(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t7)){
t8=t3;
f_6002(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t8)){
t9=t3;
f_6002(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
t10=t3;
f_6002(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[388])));}}}}}}}}

/* k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6002,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[348]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[82],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[346],t4,((C_word*)t0)[6]));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6029(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
t5=t3;
f_6029(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[381])));}}}

/* k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6029,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[350],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6044(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_6044(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6044(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6044,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[6]:(C_word)C_a_i_list(&a,2,lf[352],((C_word*)t0)[6])));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6059(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_6059(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6059(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6059,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 944  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[354],((C_word*)t0)[7]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6103(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t6=t4;
f_6103(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}}

/* k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6103,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 952  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6148(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t5=t3;
f_6148(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}

/* k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6148,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[357],((C_word*)t0)[6]));}
else{
t2=(C_word)C_a_i_list(&a,2,lf[358],((C_word*)t0)[6]);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[357],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[336]))){
t3=(C_word)C_a_i_list(&a,2,lf[361],((C_word*)t0)[6]);
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[357],t3));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[361],((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,2,lf[358],t3);
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[357],t4));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 968  ##sys#hash-table-ref */
t4=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t4=t3;
f_6191(2,t4,C_SCHEME_FALSE);}}}}

/* k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 970  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6214,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6219,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6251,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[364]);
if(C_truep(t6)){
/* support.scm: 972  g877 */
t7=t4;
f_6251(t7,((C_word*)t0)[5]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[342]);
if(C_truep(t8)){
/* support.scm: 972  g877 */
t9=t4;
f_6251(t9,((C_word*)t0)[5]);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[365]);
if(C_truep(t10)){
/* support.scm: 972  g877 */
t11=t4;
f_6251(t11,((C_word*)t0)[5]);}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[353]);
if(C_truep(t12)){
/* support.scm: 972  g877 */
t13=t4;
f_6251(t13,((C_word*)t0)[5]);}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[366]);
if(C_truep(t14)){
/* support.scm: 972  g878 */
t15=t3;
f_6219(t15,((C_word*)t0)[5]);}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[367]);
if(C_truep(t16)){
/* support.scm: 972  g878 */
t17=t3;
f_6219(t17,((C_word*)t0)[5]);}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[368]);
if(C_truep(t18)){
t19=(C_word)C_a_i_list(&a,2,lf[82],lf[362]);
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[363],((C_word*)t0)[3],t19));}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[369]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6363(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6363(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[370]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6395(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6395(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[344]);
if(C_truep(t24)){
/* support.scm: 972  g882 */
t25=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t25))(2,t25,f_6214(C_a_i(&a,6),t2));}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[355]);
/* support.scm: 972  g882 */
t27=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t27))(2,t27,(C_truep(t26)?f_6214(C_a_i(&a,6),t2):((C_word*)t0)[3]));}}}}}}}}}}}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6393 in k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6395,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_truep(C_retrieve(lf[336]))?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,2,lf[350],((C_word*)t0)[2])):((C_word*)t0)[2]));}

/* k6361 in k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* support.scm: 972  repeat */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5852(t3,((C_word*)t0)[3],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* g877 in k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6251,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6255,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 974  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6253 in g877 in k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6255,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[354],t1);
t5=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[101],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[92],t3,t6));}

/* g878 in k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6219,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6223,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 980  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6221 in g878 in k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6223,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[82],lf[362]);
t5=(C_word)C_a_i_list(&a,3,lf[363],((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t7=(C_word)C_a_i_list(&a,4,lf[101],t1,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[92],t3,t7));}

/* g882 in k6189 in k6146 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static C_word C_fcall f_6214(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_a_i_list(&a,2,lf[354],((C_word*)t0)[2]));}

/* k6104 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6121,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t5=t4;
f_6121(t5,(C_word)C_a_i_list(&a,2,lf[357],t1));}
else{
t5=(C_word)C_a_i_list(&a,2,lf[358],t1);
t6=t4;
f_6121(t6,(C_word)C_a_i_list(&a,2,lf[357],t5));}}

/* k6119 in k6104 in k6101 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_6121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6121,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[101],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t3));}

/* k6060 in k6057 in k6042 in k6027 in k6000 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6062,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[354],t1);
t5=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[101],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[92],t3,t6));}

/* k5961 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5963,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5978,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t5=t4;
f_5978(t5,t1);}
else{
t5=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[2]);
t6=t4;
f_5978(t6,(C_word)C_a_i_list(&a,3,lf[346],t5,t1));}}

/* k5976 in k5961 in k5958 in k5943 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5978(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5978,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,4,lf[101],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t3));}

/* k5908 in k5905 in k5890 in k5875 in repeat in a5845 in ##compiler#foreign-type-check in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_truep(C_retrieve(lf[336]))?t1:(C_word)C_a_i_list(&a,2,lf[343],t1));
t5=(C_word)C_a_i_list(&a,2,lf[82],C_SCHEME_FALSE);
t6=(C_word)C_a_i_list(&a,4,lf[101],t1,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[92],t3,t6));}

/* ##compiler#pprint-expressions-to-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5804,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5808,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 883  open-output-file */
t5=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
/* support.scm: 883  current-output-port */
t5=*((C_word*)lf[332]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k5806 in ##compiler#pprint-expressions-to-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5811,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 884  with-output-to-port */
t4=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a5818 in k5806 in ##compiler#pprint-expressions-to-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5825,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5824 in a5818 in k5806 in ##compiler#pprint-expressions-to-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5825,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 888  pretty-print */
t4=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5827 in a5824 in a5818 in k5806 in ##compiler#pprint-expressions-to-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 889  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5809 in k5806 in ##compiler#pprint-expressions-to-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 891  close-output-port */
t2=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5765,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5777,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a5776 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5777,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5784,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 871  debugging */
t10=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[325],lf[326]);}

/* k5782 in a5776 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5784,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 872  printf */
t3=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[324],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5785 in k5782 in a5776 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 873  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[323],((C_word*)t0)[2]);}

/* k5788 in k5785 in k5782 in a5776 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 874  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[322],((C_word*)t0)[2]);}

/* k5791 in k5788 in k5785 in k5782 in a5776 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 875  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[321],((C_word*)t0)[2]);}

/* k5794 in k5791 in k5788 in k5785 in k5782 in a5776 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 876  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[320],((C_word*)t0)[2]);}

/* k5797 in k5794 in k5791 in k5788 in k5785 in k5782 in a5776 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 877  printf */
t2=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[319],((C_word*)t0)[2]);}

/* a5770 in ##compiler#print-program-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
/* support.scm: 870  compute-database-statistics */
t2=C_retrieve(lf[315]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5685,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5689,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5694,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 846  ##sys#hash-table-for-each */
t15=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a5693 in ##compiler#compute-database-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5694,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5699 in a5693 in ##compiler#compute-database-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5700,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[200]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[183]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[259],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t5,lf[188]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* k5687 in ##compiler#compute-database-statistics in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 860  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[316]),C_retrieve(lf[317]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5634,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5638,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5679,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5683,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 814  ->string */
t6=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k5681 in ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 814  string-append */
t2=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[314]);}

/* k5677 in ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 813  ##sys#resolve-include-filename */
t2=C_retrieve(lf[313]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5636 in ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5647,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 816  file-exists? */
t3=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5645 in k5636 in ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5647,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[311]))){
/* support.scm: 818  printf */
t3=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[312],((C_word*)t0)[2]);}
else{
t3=t2;
f_5650(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5648 in k5645 in k5636 in ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5655,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5672,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 824  read-file */
t4=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5670 in k5648 in k5645 in k5636 in ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5654 in k5648 in k5645 in k5636 in ##compiler#lookup-exports-file in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5655,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 822  ##sys#hash-table-set! */
t3=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[307]),t2,((C_word*)t0)[2]);}
else{
/* support.scm: 823  export-import-hook */
t3=C_retrieve(lf[308]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}}

/* ##compiler#export-import-hook in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5628,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#check-global-imports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5570,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5576,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 797  ##sys#hash-table-for-each */
t4=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5575 in ##compiler#check-global-imports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5576,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5580,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 799  ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[307]),t2);}

/* k5578 in a5575 in ##compiler#check-global-imports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(C_word)C_i_assq(lf[187],((C_word*)t0)[4]);
t3=(C_word)C_i_assq(lf[198],((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(lf[200],((C_word*)t0)[4]))){
if(C_truep(t3)){
if(C_truep(t1)){
/* support.scm: 805  compiler-warning */
t4=C_retrieve(lf[23]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],lf[303],lf[304],((C_word*)t0)[2],t1);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=t1;
if(C_truep(t5)){
t6=t4;
f_5607(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5626,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 806  keyword? */
t7=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}}
else{
t5=t4;
f_5607(t5,C_SCHEME_FALSE);}}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5624 in k5578 in a5575 in ##compiler#check-global-imports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5607(t2,(C_word)C_i_not(t1));}

/* k5605 in k5578 in a5575 in ##compiler#check-global-imports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 807  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[298],lf[305],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#check-global-exports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5526,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[293]))){
t3=C_retrieve(lf[293]);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5544,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 788  ##sys#hash-table-for-each */
t7=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5543 in ##compiler#check-global-exports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5544,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5548,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5555,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t6=(C_word)C_i_assq(lf[198],t3);
t7=t5;
f_5555(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_5555(t6,C_SCHEME_FALSE);}}

/* k5553 in a5543 in ##compiler#check-global-exports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 791  compiler-warning */
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[298],lf[301],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5548(2,t2,C_SCHEME_UNDEFINED);}}

/* k5546 in a5543 in ##compiler#check-global-exports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 792  delete */
t3=C_retrieve(lf[300]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[276]+1));}

/* k5550 in k5546 in a5543 in ##compiler#check-global-exports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5531 in ##compiler#check-global-exports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5538,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a5537 in k5531 in ##compiler#check-global-exports in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5538,3,t0,t1,t2);}
/* ##compiler#compiler-warning */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[298],lf[299],t2);}

/* ##compiler#dump-undefined-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5495,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5501,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 777  ##sys#hash-table-for-each */
t4=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a5500 in ##compiler#dump-undefined-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5501,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5508,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[200],t3))){
t5=(C_word)C_i_assq(lf[198],t3);
t6=t4;
f_5508(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5508(t5,C_SCHEME_FALSE);}}

/* k5506 in a5500 in ##compiler#dump-undefined-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5508,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5511,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 781  write */
t3=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5509 in k5506 in a5500 in ##compiler#dump-undefined-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 782  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5409,4,t0,t1,t2,t3);}
if(C_truep(C_retrieve(lf[290]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5418,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 756  with-output-to-file */
t5=C_retrieve(lf[295]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}}

/* a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5422,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5457,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 759  ##sys#hash-table-for-each */
t6=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a5456 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5457,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5464,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(lf[200],t3))){
if(C_truep((C_word)C_i_assq(lf[198],t3))){
t5=(C_truep(C_retrieve(lf[293]))?(C_word)C_i_memq(t2,C_retrieve(lf[293])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5464(t6,t5);}
else{
t6=(C_word)C_i_memq(t2,C_retrieve(lf[294]));
t7=t4;
f_5464(t7,(C_word)C_i_not(t6));}}
else{
t5=t4;
f_5464(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_5464(t5,C_SCHEME_FALSE);}}

/* k5462 in a5456 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5464,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5420 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5430,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5441,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5443,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 771  sort */
t6=C_retrieve(lf[292]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* a5442 in k5420 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5443,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* support.scm: 773  string<? */
t6=*((C_word*)lf[291]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* k5439 in k5420 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5429 in k5420 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5430,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5434,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 769  write */
t4=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5432 in a5429 in k5420 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 770  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5423 in k5420 in a5417 in ##compiler#dump-exported-globals in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 774  export-dump-hook */
t2=C_retrieve(lf[288]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#export-dump-hook in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5403,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* ##compiler#simple-lambda-node? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5311,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5335(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5335,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[246]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[229],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 745  every */
t15=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[240]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 747  every */
t9=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5225,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5231,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5231(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5231,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[229]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5247,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5247(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[82]);
if(C_truep(t9)){
t10=t8;
f_5247(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[113]);
if(C_truep(t10)){
t11=t8;
f_5247(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[241]);
t12=t8;
f_5247(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[233])));}}}}

/* k5245 in walk in ##compiler#expression-has-side-effects? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5247,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[259]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5261,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 728  find */
t7=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],t6,C_retrieve(lf[286]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[101]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[92]));
if(C_truep(t4)){
/* support.scm: 729  any */
t5=C_retrieve(lf[64]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a5260 in k5245 in walk in ##compiler#expression-has-side-effects? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5261,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 728  foreign-callback-stub-id */
t4=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5267 in a5260 in k5245 in walk in ##compiler#expression-has-side-effects? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5030,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5033,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5105,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5209,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 712  matchn */
t15=((C_word*)t12)[1];
f_5105(t15,t14,t2,t3);}

/* k5207 in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5209,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 715  debugging */
t7=C_retrieve(lf[13]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t2,lf[281],lf[282],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5213 in k5207 in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5105(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5105,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 701  resolve */
t4=((C_word*)t0)[4];
f_5033(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5127,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 703  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5062(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k5125 in matchn in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5140,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5140(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k5125 in matchn in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5140,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 707  resolve */
t4=((C_word*)t0)[4];
f_5033(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5171,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 709  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5105(t7,t4,t5,t6);}}}}

/* k5169 in loop in k5125 in matchn in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 710  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5140(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5062(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5062,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 694  resolve */
t4=((C_word*)t0)[3];
f_5033(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5084,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 696  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k5082 in match1 in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 696  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5062(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5033,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5057,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 689  alist-cons */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k5055 in resolve in ##compiler#match-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#copy-node! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4968,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4972,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 671  node-class-set! */
t7=C_retrieve(lf[221]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t3,t6);}

/* k4970 in ##compiler#copy-node! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 672  node-parameters-set! */
t5=C_retrieve(lf[224]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4973 in k4970 in ##compiler#copy-node! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 673  node-subexpressions-set! */
t5=C_retrieve(lf[226]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}

/* k4976 in k4973 in k4970 in ##compiler#copy-node! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4978,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4989(t4,C_fix(4)));}

/* do626 in k4976 in k4973 in k4970 in ##compiler#copy-node! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static C_word C_fcall f_4989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4934,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4940,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4940(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4940,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 667  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4952 in rec in ##compiler#tree-copy in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4958,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 667  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4940(t4,t2,t3);}

/* k4956 in k4952 in rec in ##compiler#tree-copy in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4958,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4756,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4760,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 635  map */
t6=*((C_word*)lf[118]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[278]+1),t3,t4);}

/* k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4762,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4768,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 662  walk */
t6=((C_word*)t4)[1];
f_4768(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4768(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4768,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[229]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4791,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
/* support.scm: 642  rename */
f_4762(t11,t12,t3);}
else{
t11=(C_word)C_eqp(t9,lf[104]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4820,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 643  rename */
f_4762(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4836,a[2]=t3,a[3]=t13,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 646  gensym */
t15=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t13);}
else{
t13=(C_word)C_eqp(t9,lf[259]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4869,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 650  decompose-lambda-list */
t16=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4917,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 661  tree-copy */
t15=C_retrieve(lf[277]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}}}}}

/* k4915 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4920,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4924 in k4915 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4925,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4768(t3,t1,t2,((C_word*)t0)[2]);}

/* k4918 in k4915 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4920,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4868 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4869,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[93]),t2);}

/* k4871 in a4868 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 654  append */
t3=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4874 in k4871 in a4868 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 658  rename */
f_4762(t5,((C_word*)t0)[3],t1);}
else{
t6=t5;
f_4911(2,t6,C_SCHEME_FALSE);}}

/* k4909 in k4874 in k4871 in a4868 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 658  build-lambda-list */
t2=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4901 in k4874 in k4871 in a4868 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4903,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4882,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a4886 in k4901 in k4874 in k4871 in a4868 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4887,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4768(t3,t1,t2,((C_word*)t0)[2]);}

/* k4880 in k4901 in k4874 in k4871 in a4868 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[259],((C_word*)t0)[2],t1));}

/* k4834 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 647  alist-cons */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4837 in k4834 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4845,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4850,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4849 in k4837 in k4834 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4850,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4768(t3,t1,t2,((C_word*)t0)[2]);}

/* k4843 in k4837 in k4834 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4845,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[92],((C_word*)t0)[2],t1));}

/* k4818 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4820,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4807,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4811 in k4818 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4812,3,t0,t1,t2);}
/* walk572 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4768(t3,t1,t2,((C_word*)t0)[2]);}

/* k4805 in k4818 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[104],((C_word*)t0)[2],t1));}

/* k4789 in walk in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 642  varnode */
t2=C_retrieve(lf[228]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k4758 in ##compiler#copy-node-tree-and-rename in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4762(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4762,NULL,3,t1,t2,t3);}
/* support.scm: 636  alist-ref */
t4=C_retrieve(lf[275]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[276]+1),t2);}

/* ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4663,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4669,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 613  decompose-lambda-list */
t7=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4669,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4675,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4681,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4681,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[93]),((C_word*)t0)[2]);}
else{
t5=t4;
f_4685(2,t5,((C_word*)t0)[2]);}}

/* k4683 in a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4688,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 619  copy-node-tree-and-rename */
t3=C_retrieve(lf[274]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_4688(2,t3,((C_word*)t0)[3]);}}

/* k4686 in k4683 in a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4693,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 625  last */
t5=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_4707(t4,t1);}}

/* k4746 in k4686 in k4683 in a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4724,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 627  qnode */
t4=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[273],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_4724(2,t8,(C_word)C_a_i_record(&a,4,lf[219],lf[107],t6,t7));}}

/* k4722 in k4746 in k4686 in k4683 in a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_4707(t3,(C_word)C_a_i_record(&a,4,lf[219],lf[92],((C_word*)t0)[2],t2));}

/* k4705 in k4686 in k4683 in a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4707,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 631  take */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4709 in k4705 in k4686 in k4683 in a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 621  fold-right */
t2=C_retrieve(lf[271]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4692 in k4686 in k4683 in a4680 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4693,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[219],lf[92],t5,t6));}

/* a4674 in a4668 in ##compiler#inline-lambda-bindings in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
/* support.scm: 616  split-at */
t2=C_retrieve(lf[270]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4615,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4621,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4621(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4621,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 609  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k4639 in fold in ##compiler#fold-boolean in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 610  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4621(t4,t2,t3);}

/* k4643 in k4639 in fold in ##compiler#fold-boolean in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[219],lf[106],lf[268],t2));}

/* ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4321,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4327,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4327(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4327,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[101]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4346,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_4346(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[265]);
t12=t10;
f_4346(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[266])));}}

/* k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4346,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[255]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[229]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[233]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[82]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,lf[82],t6));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 583  butlast */
t10=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[259]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[105]:lf[259]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4445,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 590  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_4327(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[246]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[240]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4478,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[113]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4502,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_4502(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_4556(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t14)){
t15=t13;
f_4556(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t16=t13;
f_4556(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[264])));}}}}}}}}}}}}}

/* k4554 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4556(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4556,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 600  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4327(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4584 in k4554 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 601  append */
t2=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4580 in k4554 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4561 in k4554 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k4565 in k4561 in k4554 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 600  cons* */
t2=C_retrieve(lf[99]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4502(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4502,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 597  reverse */
t7=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4543,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 598  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_4327(3,t10,t8,t9);}}

/* k4541 in loop in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 598  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4502(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4514 in loop in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4520,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 597  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4327(3,t4,t2,t3);}

/* k4518 in k4514 in loop in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[260],((C_word*)t0)[2],t1));}

/* k4476 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  cons* */
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[240],((C_word*)t0)[2],t1);}

/* k4443 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4422 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4418 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 583  map */
t2=*((C_word*)lf[118]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[257]+1),((C_word*)t0)[2],t1);}

/* k4406 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4412,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4416,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 584  last */
t4=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4414 in k4406 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 584  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4327(3,t2,((C_word*)t0)[2],t1);}

/* k4410 in k4406 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t1));}

/* k4368 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[255],t2));}

/* k4351 in k4344 in walk in ##compiler#build-expression-tree in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3813,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3816,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4316,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 567  walk */
t9=((C_word*)t6)[1];
f_3816(3,t9,t8,t2);}

/* k4314 in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4319,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 568  debugging */
t3=C_retrieve(lf[13]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[252],lf[253],((C_word*)((C_word*)t0)[2])[1]);}

/* k4317 in k4314 in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word *a;
loop:
a=C_alloc(83);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3816,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 502  varnode */
t3=C_retrieve(lf[228]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 503  bomb */
t3=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[232],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[233]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[219],lf[233],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[101]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[113]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3875,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3898,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3901,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[237],C_retrieve(lf[238]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_3901(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_3901(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_3901(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[92]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 523  walk */
t64=t1;
t65=t11;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3951,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 524  unzip1 */
t13=C_retrieve(lf[239]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[105]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4002,a[2]=t12,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_caddr(t2);
/* support.scm: 527  walk */
t64=t13;
t65=t14;
t1=t64;
t2=t65;
c=3;
goto loop;}
else{
t11=(C_word)C_eqp(t4,lf[114]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_i_car(t2);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t13,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t12))){
t15=(C_word)C_i_car(t12);
t16=t14;
f_4042(t16,(C_word)C_eqp(lf[82],t15));}
else{
t15=t14;
f_4042(t15,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t4,lf[106]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[240]));
if(C_truep(t13)){
t14=(C_word)C_i_car(t2);
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4073,a[2]=t16,a[3]=t14,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_i_cddr(t2);
/* map */
t19=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,((C_word*)((C_word*)t0)[3])[1],t18);}
else{
t14=(C_word)C_eqp(t4,lf[241]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,t15,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,4,lf[219],lf[241],t16,C_SCHEME_END_OF_LIST));}
else{
t15=(C_word)C_eqp(t4,lf[104]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(t4,lf[98]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(t2);
t18=(C_word)C_a_i_list(&a,1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cddr(t2);
/* map */
t21=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,((C_word*)((C_word*)t0)[3])[1],t20);}
else{
t17=(C_word)C_eqp(t4,lf[242]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_i_cadr(t18);
t20=(C_word)C_i_caddr(t2);
t21=(C_word)C_i_cadr(t20);
t22=(C_word)C_i_cadddr(t2);
t23=(C_word)C_i_cadr(t22);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4168,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t23,a[6]=t21,a[7]=t19,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 546  fifth */
t25=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,t2);}
else{
t18=(C_word)C_eqp(t4,lf[107]);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t18)){
t20=t19;
f_4189(t20,t18);}
else{
t20=(C_word)C_eqp(t4,lf[115]);
if(C_truep(t20)){
t21=t19;
f_4189(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[108]);
if(C_truep(t21)){
t22=t19;
f_4189(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[109]);
t23=t19;
f_4189(t23,(C_truep(t22)?t22:(C_word)C_eqp(t4,lf[110])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k4304 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[246],lf[251],t1));}

/* k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4189,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4198,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[245]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4214,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 554  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a4231 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4232,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4246,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[250])))){
t5=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_4246(t7,C_SCHEME_TRUE);}
else{
t5=t4;
f_4246(t5,C_SCHEME_FALSE);}}

/* k4244 in a4231 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4246,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 562  real-name */
t4=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm: 564  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4251 in k4244 in a4231 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_4260(2,t3,t1);}
else{
/* support.scm: 563  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4258 in k4251 in k4244 in a4231 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4260,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4250(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[248]),((C_word*)t0)[2],t1));}

/* k4248 in k4244 in a4231 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4239,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k4237 in k4248 in k4244 in a4231 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[246],((C_word*)t0)[2],t1));}

/* a4225 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
/* support.scm: 554  get-line-2 */
t2=C_retrieve(lf[167]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4212 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[246],lf[247],t1));}

/* k4196 in k4187 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4166 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4148,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 547  sixth */
t6=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k4150 in k4166 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 547  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3816(3,t2,((C_word*)t0)[2],t1);}

/* k4146 in k4166 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[219],lf[242],((C_word*)t0)[2],t2));}

/* k4113 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[104],((C_word*)t0)[2],t1));}

/* k4071 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4040 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_4042(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4042,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4028,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k4026 in k4040 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4000 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[219],lf[105],((C_word*)t0)[2],t2));}

/* k3949 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a3970 in k3949 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3971,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 525  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3816(3,t4,t1,t3);}

/* k3959 in k3949 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3969,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 526  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3816(3,t3,t2,((C_word*)t0)[2]);}

/* k3967 in k3959 in k3949 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 525  append */
t3=*((C_word*)lf[57]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3952 in k3949 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],lf[92],((C_word*)t0)[2],t1));}

/* k3899 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3901,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 514  compiler-warning */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[235],lf[236],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3898(t2,((C_word*)t0)[2]);}}

/* k3902 in k3899 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 517  truncate */
t3=*((C_word*)lf[234]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3909 in k3902 in k3899 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3898(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k3896 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 510  qnode */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3873 in walk in ##compiler#build-node-graph in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[219],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3804,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[219],lf[82],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3795,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[219],lf[229],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3789,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[219],t2,t3,t4));}

/* node-subexpressions in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3780,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[219]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3771,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[219]);
/* support.scm: 488  ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3762,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[219]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3753,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[219]);
/* support.scm: 488  ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3744,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[219]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3735,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[219]);
/* support.scm: 488  ##sys#block-set! */
t5=*((C_word*)lf[222]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3729,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[219]));}

/* f_3723 in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3723,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[219],t2,t3,t4));}

/* ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3313,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3317,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_3317(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3721,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 440  append */
t5=*((C_word*)lf[57]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[215]),C_retrieve(lf[216]),C_retrieve(lf[217]));}}

/* k3719 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3317(t3,t2);}

/* k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3317,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 443  ##sys#hash-table-for-each */
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3322,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3332,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t11,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 450  write */
t13=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}}

/* k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3422(t6,t2,((C_word*)t0)[2]);}

/* loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3422,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 454  caar */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[180]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_3448(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t5)){
t6=t4;
f_3448(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[199]);
if(C_truep(t6)){
t7=t4;
f_3448(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t7)){
t8=t4;
f_3448(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t8)){
t9=t4;
f_3448(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[156]);
if(C_truep(t9)){
t10=t4;
f_3448(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t10)){
t11=t4;
f_3448(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[202]);
if(C_truep(t11)){
t12=t4;
f_3448(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[155]);
if(C_truep(t12)){
t13=t4;
f_3448(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[203]);
if(C_truep(t13)){
t14=t4;
f_3448(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t14)){
t15=t4;
f_3448(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t15)){
t16=t4;
f_3448(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t16)){
t17=t4;
f_3448(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t17)){
t18=t4;
f_3448(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t18)){
t19=t4;
f_3448(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t19)){
t20=t4;
f_3448(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t20)){
t21=t4;
f_3448(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[211]);
if(C_truep(t21)){
t22=t4;
f_3448(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[151]);
if(C_truep(t22)){
t23=t4;
f_3448(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[212]);
if(C_truep(t23)){
t24=t4;
f_3448(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[147]);
t25=t4;
f_3448(t25,(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[213])));}}}}}}}}}}}}}}}}}}}}}

/* k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3448,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 458  caar */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[179]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[179]);
t4=((C_word*)t0)[8];
f_3435(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[183]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[179]);
if(C_truep(t4)){
t5=((C_word*)t0)[8];
f_3435(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 462  cdar */
t6=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[184]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 464  cdar */
t6=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[185]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3505(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[190]);
if(C_truep(t7)){
t8=t6;
f_3505(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[191]);
if(C_truep(t8)){
t9=t6;
f_3505(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[169]);
if(C_truep(t9)){
t10=t6;
f_3505(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[192]);
if(C_truep(t10)){
t11=t6;
f_3505(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[193]);
if(C_truep(t11)){
t12=t6;
f_3505(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[194]);
if(C_truep(t12)){
t13=t6;
f_3505(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[195]);
if(C_truep(t13)){
t14=t6;
f_3505(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[196]);
t15=t6;
f_3505(t15,(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[6],lf[197])));}}}}}}}}}}}}}

/* k3503 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3505,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3512,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 467  caar */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[187]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 469  cdar */
t4=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[188]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 471  cdar */
t5=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 472  bomb */
t5=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[189],t4);}}}}

/* k3534 in k3503 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3435(2,t3,t2);}

/* k3524 in k3503 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3435(2,t3,t2);}

/* k3510 in k3503 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 467  cdar */
t3=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3514 in k3510 in k3503 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 467  printf */
t2=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[186],((C_word*)t0)[2],t1);}

/* k3494 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3435(2,t3,t2);}

/* k3484 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3435(2,t3,t2);}

/* k3461 in k3446 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[181]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 458  printf */
t4=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[182],t3);}

/* k3433 in k3430 in loop in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 473  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3422(t3,((C_word*)t0)[2],t2);}

/* k3333 in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[179]);
t5=t3;
f_3370(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3370(t4,C_SCHEME_FALSE);}}

/* k3368 in k3333 in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3370,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 475  printf */
t7=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],lf[177],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[179]);
t4=t2;
f_3391(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3391(t3,C_SCHEME_FALSE);}}}

/* k3389 in k3368 in k3333 in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3391,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 477  printf */
t7=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[178],t6);}
else{
t2=((C_word*)t0)[2];
f_3338(2,t2,C_SCHEME_UNDEFINED);}}

/* k3336 in k3333 in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 478  printf */
t4=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[176],t3);}
else{
t3=t2;
f_3341(2,t3,C_SCHEME_UNDEFINED);}}

/* k3339 in k3336 in k3333 in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 479  printf */
t4=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[175],t3);}
else{
t3=t2;
f_3344(2,t3,C_SCHEME_UNDEFINED);}}

/* k3342 in k3339 in k3336 in k3333 in k3330 in a3321 in k3315 in ##compiler#display-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 480  newline */
t2=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3300,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 422  ##sys#hash-table-for-each */
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[166]));}

/* a3299 in ##compiler#display-line-number-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3300,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[172]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3309 in a3299 in ##compiler#display-line-number-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 424  printf */
t2=C_retrieve(lf[16]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[171],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3270,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3276,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3276(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3276(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3276,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3286,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 418  get */
t5=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[169]);}}

/* k3284 in loop in ##compiler#find-lambda-container in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 419  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3276(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3234,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3241,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 410  ##sys#hash-table-ref */
t5=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[166]),t3);}

/* k3239 in ##compiler#get-line-2 in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_3244(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_3244(t3,C_SCHEME_FALSE);}}

/* k3242 in k3239 in ##compiler#get-line-2 in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_3244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 412  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 413  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3224,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 406  get */
t4=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[166]),t3,t2);}

/* ##compiler#count! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_3167r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3167r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3167r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3171,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 394  ##sys#hash-table-ref */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3169 in ##compiler#count! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3201,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 399  alist-cons */
t7=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 400  ##sys#hash-table-set! */
t6=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k3199 in k3169 in ##compiler#count! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3115,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3119,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 386  ##sys#hash-table-ref */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3117 in ##compiler#collect! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 390  alist-cons */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 391  ##sys#hash-table-set! */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k3144 in k3117 in ##compiler#collect! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3069,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3073,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 378  ##sys#hash-table-ref */
t7=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k3071 in ##compiler#put! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3095,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 382  alist-cons */
t5=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 383  ##sys#hash-table-set! */
t4=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k3093 in k3071 in ##compiler#put! in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3051r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3051r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3051r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3055,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 372  ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3053 in ##compiler#get-all in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 374  filter-map */
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a3062 in k3053 in ##compiler#get-all in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3063,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3033,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3037,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 366  ##sys#hash-table-ref */
t6=C_retrieve(lf[159]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k3035 in ##compiler#get in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2972,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3009,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[157]));}

/* a3008 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3009,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 352  put! */
t4=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[156],C_SCHEME_TRUE);}

/* k3011 in a3008 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[154])))){
/* support.scm: 353  put! */
t3=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[155],C_SCHEME_TRUE);}
else{
t3=t2;
f_3016(2,t3,C_SCHEME_UNDEFINED);}}

/* k3014 in k3011 in a3008 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[153])))){
/* support.scm: 354  put! */
t2=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[150],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2974 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[152]));}

/* a2993 in k2974 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2994,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 358  put! */
t4=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[151],C_SCHEME_TRUE);}

/* k2996 in a2993 in k2974 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[149])))){
/* support.scm: 359  put! */
t2=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[150],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2977 in k2974 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[148]));}

/* a2983 in k2977 in k2974 in ##compiler#initialize-analysis-database in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2984,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 362  put! */
t4=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t3,lf[147],C_SCHEME_TRUE);}

/* ##compiler#expand-profile-lambda in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2915,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[138]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2919,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 334  gensym */
t7=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k2917 in ##compiler#expand-profile-lambda in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 335  alist-cons */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[139]));}

/* k2921 in k2917 in ##compiler#expand-profile-lambda in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=C_mutate((C_word*)lf[139]+1,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[138]+1,t3);
t5=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[140],t5,C_retrieve(lf[141]));
t7=(C_word)C_a_i_list(&a,3,lf[105],C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_list(&a,3,lf[105],((C_word*)t0)[5],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,3,lf[142],t8,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[105],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[6]);
t12=(C_word)C_a_i_list(&a,3,lf[143],t11,C_retrieve(lf[141]));
t13=(C_word)C_a_i_list(&a,3,lf[105],C_SCHEME_END_OF_LIST,t12);
t14=(C_word)C_a_i_list(&a,4,lf[144],t7,t10,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[105],((C_word*)t0)[3],t14));}

/* ##compiler#process-lambda-documentation in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2912,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2809,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2816,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2818,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2849,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2898 in a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2899r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2899r(t0,t1,t2);}}

static void C_ccall f_2899r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g237239 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2904 in a2898 in a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2905,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2854 in a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2883,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 319  with-input-from-string */
t4=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a2882 in a2854 in a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2889,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2897,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 319  read */
t4=*((C_word*)lf[127]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2895 in a2882 in a2854 in a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 319  unfold */
t2=C_retrieve(lf[128]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[129]+1),*((C_word*)lf[130]+1),((C_word*)t0)[2],t1);}

/* a2888 in a2882 in a2854 in a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2889,3,t0,t1,t2);}
/* support.scm: 319  read */
t3=*((C_word*)lf[127]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2857 in a2854 in a2848 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[125]);}
else{
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_nullp(t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[126],t1)));}}

/* a2823 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2824,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* g237239 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2829 in a2823 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 316  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k2839 in a2829 in a2823 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 317  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 318  ->string */
t2=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2836 in a2829 in a2823 in a2817 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 314  quit */
t2=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[124],((C_word*)t0)[2],t1);}

/* k2814 in ##compiler#string->expr in k2806 in k2803 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2434,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2437,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2798,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 306  walk */
t9=((C_word*)t6)[1];
f_2437(3,t9,t8,t2);}

/* k2796 in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 307  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2437,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2591,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t2);
t9=t6;
f_2591(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_2591(t8,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2642,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[92]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cadr(t2);
t11=t6;
f_2642(t11,(C_word)C_i_listp(t10));}
else{
t10=t6;
f_2642(t10,C_SCHEME_FALSE);}}
else{
t9=t6;
f_2642(t9,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2642,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2651(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g182185 */
t4=((C_word*)t0)[3];
f_2439(t4,((C_word*)t0)[2],t2,t3);}}

/* g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2651,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2661,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t6=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2752,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* cdar */
t8=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}
else{
t7=t5;
f_2698(t7,C_SCHEME_FALSE);}}}

/* k2750 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2752,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* cddar */
t3=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2698(t2,C_SCHEME_FALSE);}}

/* k2746 in k2750 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2698(t2,(C_word)C_i_nullp(t1));}

/* k2696 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2698,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* cadar */
t4=*((C_word*)lf[120]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* g182185 */
t4=((C_word*)t0)[2];
f_2439(t4,((C_word*)t0)[4],t2,t3);}}

/* k2719 in k2696 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2717,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* caar */
t4=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2715 in k2719 in k2696 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* g177222 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2651(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2659 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2664,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* reverse */
t3=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2662 in k2659 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2678,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[118]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2683 in k2662 in k2659 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2684,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2692,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* walk172 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2437(3,t5,t4,t3);}

/* k2690 in a2683 in k2662 in k2659 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2676 in k2662 in k2659 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2680 in k2676 in k2662 in k2659 in g177 in k2640 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[92],t2));}

/* k2589 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2611,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##compiler#collapsable-literal? */
t4=C_retrieve(lf[83]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g182185 */
t4=((C_word*)t0)[2];
f_2439(t4,((C_word*)t0)[4],t2,t3);}}

/* k2609 in k2589 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##compiler#make-random-name */
t3=C_retrieve(lf[117]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k2601 in k2609 in k2589 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* alist-cons */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2605 in k2601 in k2609 in k2589 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* g182 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2439(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2439,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[97]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2449(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[111]);
if(C_truep(t7)){
t8=t6;
f_2449(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[112]);
if(C_truep(t8)){
t9=t6;
f_2449(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[113]);
if(C_truep(t9)){
t10=t6;
f_2449(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[114]);
t11=t6;
f_2449(t11,(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[115])));}}}}}

/* k2447 in g182 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2449,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[98]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_2458(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[104]);
if(C_truep(t4)){
t5=t3;
f_2458(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[105]);
if(C_truep(t5)){
t6=t3;
f_2458(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[106]);
if(C_truep(t6)){
t7=t3;
f_2458(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[107]);
if(C_truep(t7)){
t8=t3;
f_2458(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[108]);
if(C_truep(t8)){
t9=t3;
f_2458(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[109]);
t10=t3;
f_2458(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[110])));}}}}}}}}

/* k2456 in k2447 in g182 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2458,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2469,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[101]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2482(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[102]);
t5=t3;
f_2482(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[3],lf[103])));}}}

/* k2480 in k2456 in k2447 in g182 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2482(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2482,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
/* map */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}}

/* k2487 in k2480 in k2456 in k2447 in g182 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2467 in k2456 in k2447 in g182 in walk in ##compiler#extract-mutable-constants in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 301  cons* */
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#canonicalize-begin-body in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2351,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2357(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2357,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[90]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[91]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2385,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_2385(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2422,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 277  constant? */
t8=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k2420 in loop in ##compiler#canonicalize-begin-body in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2385(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[95])));}

/* k2383 in loop in ##compiler#canonicalize-begin-body in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2385,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 279  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2357(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 280  gensym */
t3=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}}

/* k2413 in k2383 in loop in ##compiler#canonicalize-begin-body in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 281  loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2357(t7,t5,t6);}

/* k2401 in k2413 in k2383 in loop in ##compiler#canonicalize-begin-body in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[2],t1));}

/* ##compiler#basic-literal? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2291,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 262  constant? */
t6=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}

/* k2305 in ##compiler#basic-literal? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2349,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 263  vector->list */
t4=*((C_word*)lf[88]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2313(2,t3,C_SCHEME_FALSE);}}}

/* k2347 in k2305 in ##compiler#basic-literal? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 263  every */
t2=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[86]),t1);}

/* k2311 in k2305 in ##compiler#basic-literal? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 265  basic-literal? */
t4=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k2326 in k2311 in k2305 in ##compiler#basic-literal? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 266  basic-literal? */
t3=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2245,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 252  big-fixnum? */
t5=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t3;
f_2249(t4,C_SCHEME_FALSE);}}

/* k2287 in ##compiler#immediate? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2249(t2,(C_word)C_i_not(t1));}

/* k2247 in ##compiler#immediate? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2215,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2169,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[82],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#follow-without-loop in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2138,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2144,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2144(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2144,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 230  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2159,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 231  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a2158 in loop in ##compiler#follow-without-loop in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2159,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 231  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2144(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2075,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 220  reverse */
t6=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k2087 in ##compiler#fold-inner in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2091(t5,((C_word*)t0)[2],t1);}

/* fold in k2087 in ##compiler#fold-inner in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2091,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_2099(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2120,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 225  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k2118 in fold in k2087 in ##compiler#fold-inner in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2099(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k2097 in fold in k2087 in ##compiler#fold-inner in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2063,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[76]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 215  close-input-port */
t4=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2016r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2016r(t0,t1,t2,t3);}}

static void C_ccall f_2016r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[69]))){
/* support.scm: 209  current-input-port */
t4=*((C_word*)lf[70]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2032,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 210  file-exists? */
t5=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k2030 in ##compiler#check-and-open-input-file in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 210  open-input-file */
t2=*((C_word*)lf[71]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2044(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_2044(t5,(C_word)C_i_not(t4));}}}

/* k2042 in k2030 in ##compiler#check-and-open-input-file in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_2044(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 211  quit */
t2=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[72],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 212  quit */
t3=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[73],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2009,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub98(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2002,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub94(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1946,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1950,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2000,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 190  ->string */
t5=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1998 in ##compiler#valid-c-identifier? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[59]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1948 in ##compiler#valid-c-identifier? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1950,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1973,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 194  any */
t7=C_retrieve(lf[64]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1972 in k1948 in ##compiler#valid-c-identifier? in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1973,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1868,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[59]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1870(t5,((C_word*)t0)[2],t1);}

/* loop in k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1870,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[56]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1892,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_1892(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_1892(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[62])));}}}

/* k1890 in loop in k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1892,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_1899(t3,lf[60]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_1899(t4,(C_truep(t3)?lf[61]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1870(t4,t2,t3);}}

/* k1929 in k1890 in loop in k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1897 in k1890 in loop in k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1899,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 185  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k1913 in k1897 in k1890 in loop in k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[59]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1901 in k1897 in k1890 in loop in k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1907,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 186  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1870(t4,t2,t3);}

/* k1905 in k1901 in k1897 in k1890 in loop in k1866 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 181  append */
t2=*((C_word*)lf[57]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[58],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1862 in ##compiler#c-ify-string in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1808,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1814,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1814(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1814(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1814,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1838,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 167  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k1836 in loop in ##compiler#build-lambda-list in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 161  string->symbol */
t3=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1806,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 162  sprintf */
t4=C_retrieve(lf[46]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[50],t2);}}}

/* k1804 in ##compiler#symbolify in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 162  string->symbol */
t2=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1762,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 156  symbol->string */
t3=*((C_word*)lf[45]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* support.scm: 157  sprintf */
t3=C_retrieve(lf[46]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[47],t2);}}}

/* ##compiler#posq in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1726,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1732(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static C_word C_fcall f_1732(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1658,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1661,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1682,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1682(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1682(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1682,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 140  err */
t4=((C_word*)t0)[3];
f_1661(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 142  err */
t5=((C_word*)t0)[3];
f_1661(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 143  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1661,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 137  real-name */
t3=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1667 in err in ##compiler#check-signature in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1673,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 138  map-llist */
t4=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[42]),t3);}

/* k1671 in k1667 in err in ##compiler#check-signature in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 136  quit */
t2=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[41],((C_word*)t0)[2],t1);}

/* map-llist in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1615,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1621,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1621(t7,t1,t3);}

/* loop in map-llist in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1621,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 131  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 132  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k1642 in loop in map-llist in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1648,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 132  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1621(t4,t2,t3);}

/* k1646 in k1642 in loop in map-llist in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1612,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[33])));}

/* ##sys#syntax-error-hook in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1587r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1587r(t0,t1,t2,t3);}}

static void C_ccall f_1587r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1591,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  current-error-port */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1589 in ##sys#syntax-error-hook in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 118  fprintf */
t3=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[36],((C_word*)t0)[2]);}

/* k1592 in k1589 in ##sys#syntax-error-hook in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1604 in k1592 in k1589 in ##sys#syntax-error-hook in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1605,3,t0,t1,t2);}
/* fprintf */
t3=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],lf[35],t2);}

/* k1595 in k1592 in k1589 in ##sys#syntax-error-hook in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 120  print-call-chain */
t3=C_retrieve(lf[32]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[33]),lf[34]);}

/* k1598 in k1595 in k1592 in k1589 in ##sys#syntax-error-hook in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 121  exit */
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1568r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1568r(t0,t1,t2,t3);}}

static void C_ccall f_1568r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1572,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  current-error-port */
t5=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1570 in quit in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1575,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 111  string-append */
t4=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[30],((C_word*)t0)[2]);}

/* k1583 in k1570 in quit in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[24]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1573 in k1570 in quit in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 112  newline */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1576 in k1573 in k1570 in quit in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 113  exit */
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1539r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1539r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1539r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1546,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[27]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[7]));
t7=t5;
f_1546(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_1546(t6,C_SCHEME_FALSE);}}

/* k1544 in ##compiler#compiler-warning in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_fcall f_1546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1546,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  current-error-port */
t3=C_retrieve(lf[26]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1547 in k1544 in ##compiler#compiler-warning in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1552,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 106  string-append */
t4=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[25],((C_word*)t0)[2]);}

/* k1557 in k1547 in k1544 in ##compiler#compiler-warning in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[24]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1550 in k1547 in k1544 in ##compiler#compiler-warning in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 107  newline */
t2=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1499r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1499r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1499r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[6])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1509,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 94   printf */
t6=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[22],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k1507 in ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 97   display */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[21]);}
else{
t3=t2;
f_1512(2,t3,C_SCHEME_UNDEFINED);}}

/* k1522 in k1507 in ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1529,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a1528 in k1522 in k1507 in ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1529,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1537,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   force */
t4=C_retrieve(lf[18]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1535 in a1528 in k1522 in k1507 in ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 98   printf */
t2=C_retrieve(lf[16]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[17],t1);}

/* k1510 in k1507 in ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   newline */
t3=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1513 in k1510 in k1507 in ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 100  flush-output */
t3=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1516 in k1513 in k1510 in k1507 in ##compiler#debugging in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1472r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1472r(t0,t1,t2);}}

static void C_ccall f_1472r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1486,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 88   string-append */
t5=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[11],t4);}
else{
/* support.scm: 89   error */
t3=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[12]);}}

/* k1484 in ##compiler#bomb in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[9]+1),t1,t2);}

/* f_1467 in k1459 in k1456 in k1453 in k1450 in k1447 in k1444 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1467,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[577] = {
{"toplevelsupport.scm",(void*)C_support_toplevel},
{"f_1446support.scm",(void*)f_1446},
{"f_1449support.scm",(void*)f_1449},
{"f_1452support.scm",(void*)f_1452},
{"f_1455support.scm",(void*)f_1455},
{"f_1458support.scm",(void*)f_1458},
{"f_1461support.scm",(void*)f_1461},
{"f_2805support.scm",(void*)f_2805},
{"f_2808support.scm",(void*)f_2808},
{"f_8906support.scm",(void*)f_8906},
{"f_8795support.scm",(void*)f_8795},
{"f_8904support.scm",(void*)f_8904},
{"f_8799support.scm",(void*)f_8799},
{"f_8804support.scm",(void*)f_8804},
{"f_8808support.scm",(void*)f_8808},
{"f_8844support.scm",(void*)f_8844},
{"f_8888support.scm",(void*)f_8888},
{"f_8860support.scm",(void*)f_8860},
{"f_8811support.scm",(void*)f_8811},
{"f_8818support.scm",(void*)f_8818},
{"f_8814support.scm",(void*)f_8814},
{"f_8766support.scm",(void*)f_8766},
{"f_8793support.scm",(void*)f_8793},
{"f_8777support.scm",(void*)f_8777},
{"f_8780support.scm",(void*)f_8780},
{"f_8782support.scm",(void*)f_8782},
{"f_8786support.scm",(void*)f_8786},
{"f_8770support.scm",(void*)f_8770},
{"f_8703support.scm",(void*)f_8703},
{"f_8740support.scm",(void*)f_8740},
{"f_8764support.scm",(void*)f_8764},
{"f_8750support.scm",(void*)f_8750},
{"f_8754support.scm",(void*)f_8754},
{"f_8725support.scm",(void*)f_8725},
{"f_8733support.scm",(void*)f_8733},
{"f_8634support.scm",(void*)f_8634},
{"f_8638support.scm",(void*)f_8638},
{"f_8643support.scm",(void*)f_8643},
{"f_8647support.scm",(void*)f_8647},
{"f_8698support.scm",(void*)f_8698},
{"f_8677support.scm",(void*)f_8677},
{"f_8689support.scm",(void*)f_8689},
{"f_8692support.scm",(void*)f_8692},
{"f_8665support.scm",(void*)f_8665},
{"f_8609support.scm",(void*)f_8609},
{"f_8619support.scm",(void*)f_8619},
{"f_8622support.scm",(void*)f_8622},
{"f_8522support.scm",(void*)f_8522},
{"f_8531support.scm",(void*)f_8531},
{"f_8544support.scm",(void*)f_8544},
{"f_8550support.scm",(void*)f_8550},
{"f_8603support.scm",(void*)f_8603},
{"f_8553support.scm",(void*)f_8553},
{"f_8568support.scm",(void*)f_8568},
{"f_8576support.scm",(void*)f_8576},
{"f_8586support.scm",(void*)f_8586},
{"f_8571support.scm",(void*)f_8571},
{"f_8559support.scm",(void*)f_8559},
{"f_8526support.scm",(void*)f_8526},
{"f_8516support.scm",(void*)f_8516},
{"f_8440support.scm",(void*)f_8440},
{"f_8447support.scm",(void*)f_8447},
{"f_8459support.scm",(void*)f_8459},
{"f_8470support.scm",(void*)f_8470},
{"f_8466support.scm",(void*)f_8466},
{"f_8428support.scm",(void*)f_8428},
{"f_8434support.scm",(void*)f_8434},
{"f_8416support.scm",(void*)f_8416},
{"f_8420support.scm",(void*)f_8420},
{"f_8337support.scm",(void*)f_8337},
{"f_8356support.scm",(void*)f_8356},
{"f_8381support.scm",(void*)f_8381},
{"f_8385support.scm",(void*)f_8385},
{"f_8387support.scm",(void*)f_8387},
{"f_8394support.scm",(void*)f_8394},
{"f_8407support.scm",(void*)f_8407},
{"f_8411support.scm",(void*)f_8411},
{"f_8340support.scm",(void*)f_8340},
{"f_8344support.scm",(void*)f_8344},
{"f_8350support.scm",(void*)f_8350},
{"f_8331support.scm",(void*)f_8331},
{"f_8287support.scm",(void*)f_8287},
{"f_8299support.scm",(void*)f_8299},
{"f_8303support.scm",(void*)f_8303},
{"f_8307support.scm",(void*)f_8307},
{"f_8295support.scm",(void*)f_8295},
{"f_8278support.scm",(void*)f_8278},
{"f_8269support.scm",(void*)f_8269},
{"f_8263support.scm",(void*)f_8263},
{"f_8257support.scm",(void*)f_8257},
{"f_8245support.scm",(void*)f_8245},
{"f_8249support.scm",(void*)f_8249},
{"f_8252support.scm",(void*)f_8252},
{"f_8207support.scm",(void*)f_8207},
{"f_8211support.scm",(void*)f_8211},
{"f_8214support.scm",(void*)f_8214},
{"f_8221support.scm",(void*)f_8221},
{"f_8165support.scm",(void*)f_8165},
{"f_8174support.scm",(void*)f_8174},
{"f_8136support.scm",(void*)f_8136},
{"f_8146support.scm",(void*)f_8146},
{"f_7939support.scm",(void*)f_7939},
{"f_8118support.scm",(void*)f_8118},
{"f_8067support.scm",(void*)f_8067},
{"f_8112support.scm",(void*)f_8112},
{"f_8116support.scm",(void*)f_8116},
{"f_8070support.scm",(void*)f_8070},
{"f_8075support.scm",(void*)f_8075},
{"f_8079support.scm",(void*)f_8079},
{"f_8073support.scm",(void*)f_8073},
{"f_8030support.scm",(void*)f_8030},
{"f_8034support.scm",(void*)f_8034},
{"f_8043support.scm",(void*)f_8043},
{"f_8047support.scm",(void*)f_8047},
{"f_8037support.scm",(void*)f_8037},
{"f_7995support.scm",(void*)f_7995},
{"f_8001support.scm",(void*)f_8001},
{"f_8028support.scm",(void*)f_8028},
{"f_8014support.scm",(void*)f_8014},
{"f_7948support.scm",(void*)f_7948},
{"f_7954support.scm",(void*)f_7954},
{"f_7993support.scm",(void*)f_7993},
{"f_7975support.scm",(void*)f_7975},
{"f_7780support.scm",(void*)f_7780},
{"f_7937support.scm",(void*)f_7937},
{"f_7924support.scm",(void*)f_7924},
{"f_7930support.scm",(void*)f_7930},
{"f_7783support.scm",(void*)f_7783},
{"f_7802support.scm",(void*)f_7802},
{"f_7886support.scm",(void*)f_7886},
{"f_7898support.scm",(void*)f_7898},
{"f_7856support.scm",(void*)f_7856},
{"f_7867support.scm",(void*)f_7867},
{"f_7847support.scm",(void*)f_7847},
{"f_7833support.scm",(void*)f_7833},
{"f_7821support.scm",(void*)f_7821},
{"f_7702support.scm",(void*)f_7702},
{"f_7708support.scm",(void*)f_7708},
{"f_7763support.scm",(void*)f_7763},
{"f_7736support.scm",(void*)f_7736},
{"f_7730support.scm",(void*)f_7730},
{"f_7706support.scm",(void*)f_7706},
{"f_7426support.scm",(void*)f_7426},
{"f_7639support.scm",(void*)f_7639},
{"f_7598support.scm",(void*)f_7598},
{"f_7551support.scm",(void*)f_7551},
{"f_7529support.scm",(void*)f_7529},
{"f_7116support.scm",(void*)f_7116},
{"f_7420support.scm",(void*)f_7420},
{"f_7128support.scm",(void*)f_7128},
{"f_7138support.scm",(void*)f_7138},
{"f_7156support.scm",(void*)f_7156},
{"f_7190support.scm",(void*)f_7190},
{"f_7119support.scm",(void*)f_7119},
{"f_6797support.scm",(void*)f_6797},
{"f_7110support.scm",(void*)f_7110},
{"f_6803support.scm",(void*)f_6803},
{"f_6813support.scm",(void*)f_6813},
{"f_6822support.scm",(void*)f_6822},
{"f_6834support.scm",(void*)f_6834},
{"f_6846support.scm",(void*)f_6846},
{"f_6852support.scm",(void*)f_6852},
{"f_6886support.scm",(void*)f_6886},
{"f_6757support.scm",(void*)f_6757},
{"f_6791support.scm",(void*)f_6791},
{"f_6763support.scm",(void*)f_6763},
{"f_6767support.scm",(void*)f_6767},
{"f_6726support.scm",(void*)f_6726},
{"f_6739support.scm",(void*)f_6739},
{"f_6730support.scm",(void*)f_6730},
{"f_6695support.scm",(void*)f_6695},
{"f_6708support.scm",(void*)f_6708},
{"f_6699support.scm",(void*)f_6699},
{"f_5840support.scm",(void*)f_5840},
{"f_6689support.scm",(void*)f_6689},
{"f_5846support.scm",(void*)f_5846},
{"f_5852support.scm",(void*)f_5852},
{"f_5877support.scm",(void*)f_5877},
{"f_5892support.scm",(void*)f_5892},
{"f_5907support.scm",(void*)f_5907},
{"f_5945support.scm",(void*)f_5945},
{"f_5960support.scm",(void*)f_5960},
{"f_6002support.scm",(void*)f_6002},
{"f_6029support.scm",(void*)f_6029},
{"f_6044support.scm",(void*)f_6044},
{"f_6059support.scm",(void*)f_6059},
{"f_6103support.scm",(void*)f_6103},
{"f_6148support.scm",(void*)f_6148},
{"f_6191support.scm",(void*)f_6191},
{"f_6395support.scm",(void*)f_6395},
{"f_6363support.scm",(void*)f_6363},
{"f_6251support.scm",(void*)f_6251},
{"f_6255support.scm",(void*)f_6255},
{"f_6219support.scm",(void*)f_6219},
{"f_6223support.scm",(void*)f_6223},
{"f_6214support.scm",(void*)f_6214},
{"f_6106support.scm",(void*)f_6106},
{"f_6121support.scm",(void*)f_6121},
{"f_6062support.scm",(void*)f_6062},
{"f_5963support.scm",(void*)f_5963},
{"f_5978support.scm",(void*)f_5978},
{"f_5910support.scm",(void*)f_5910},
{"f_5804support.scm",(void*)f_5804},
{"f_5808support.scm",(void*)f_5808},
{"f_5819support.scm",(void*)f_5819},
{"f_5825support.scm",(void*)f_5825},
{"f_5829support.scm",(void*)f_5829},
{"f_5811support.scm",(void*)f_5811},
{"f_5765support.scm",(void*)f_5765},
{"f_5777support.scm",(void*)f_5777},
{"f_5784support.scm",(void*)f_5784},
{"f_5787support.scm",(void*)f_5787},
{"f_5790support.scm",(void*)f_5790},
{"f_5793support.scm",(void*)f_5793},
{"f_5796support.scm",(void*)f_5796},
{"f_5799support.scm",(void*)f_5799},
{"f_5771support.scm",(void*)f_5771},
{"f_5685support.scm",(void*)f_5685},
{"f_5694support.scm",(void*)f_5694},
{"f_5700support.scm",(void*)f_5700},
{"f_5689support.scm",(void*)f_5689},
{"f_5634support.scm",(void*)f_5634},
{"f_5683support.scm",(void*)f_5683},
{"f_5679support.scm",(void*)f_5679},
{"f_5638support.scm",(void*)f_5638},
{"f_5647support.scm",(void*)f_5647},
{"f_5650support.scm",(void*)f_5650},
{"f_5672support.scm",(void*)f_5672},
{"f_5655support.scm",(void*)f_5655},
{"f_5628support.scm",(void*)f_5628},
{"f_5570support.scm",(void*)f_5570},
{"f_5576support.scm",(void*)f_5576},
{"f_5580support.scm",(void*)f_5580},
{"f_5626support.scm",(void*)f_5626},
{"f_5607support.scm",(void*)f_5607},
{"f_5526support.scm",(void*)f_5526},
{"f_5544support.scm",(void*)f_5544},
{"f_5555support.scm",(void*)f_5555},
{"f_5548support.scm",(void*)f_5548},
{"f_5552support.scm",(void*)f_5552},
{"f_5533support.scm",(void*)f_5533},
{"f_5538support.scm",(void*)f_5538},
{"f_5495support.scm",(void*)f_5495},
{"f_5501support.scm",(void*)f_5501},
{"f_5508support.scm",(void*)f_5508},
{"f_5511support.scm",(void*)f_5511},
{"f_5409support.scm",(void*)f_5409},
{"f_5418support.scm",(void*)f_5418},
{"f_5457support.scm",(void*)f_5457},
{"f_5464support.scm",(void*)f_5464},
{"f_5422support.scm",(void*)f_5422},
{"f_5443support.scm",(void*)f_5443},
{"f_5441support.scm",(void*)f_5441},
{"f_5430support.scm",(void*)f_5430},
{"f_5434support.scm",(void*)f_5434},
{"f_5425support.scm",(void*)f_5425},
{"f_5403support.scm",(void*)f_5403},
{"f_5311support.scm",(void*)f_5311},
{"f_5335support.scm",(void*)f_5335},
{"f_5225support.scm",(void*)f_5225},
{"f_5231support.scm",(void*)f_5231},
{"f_5247support.scm",(void*)f_5247},
{"f_5261support.scm",(void*)f_5261},
{"f_5269support.scm",(void*)f_5269},
{"f_5030support.scm",(void*)f_5030},
{"f_5209support.scm",(void*)f_5209},
{"f_5215support.scm",(void*)f_5215},
{"f_5105support.scm",(void*)f_5105},
{"f_5127support.scm",(void*)f_5127},
{"f_5140support.scm",(void*)f_5140},
{"f_5171support.scm",(void*)f_5171},
{"f_5062support.scm",(void*)f_5062},
{"f_5084support.scm",(void*)f_5084},
{"f_5033support.scm",(void*)f_5033},
{"f_5057support.scm",(void*)f_5057},
{"f_4968support.scm",(void*)f_4968},
{"f_4972support.scm",(void*)f_4972},
{"f_4975support.scm",(void*)f_4975},
{"f_4978support.scm",(void*)f_4978},
{"f_4989support.scm",(void*)f_4989},
{"f_4934support.scm",(void*)f_4934},
{"f_4940support.scm",(void*)f_4940},
{"f_4954support.scm",(void*)f_4954},
{"f_4958support.scm",(void*)f_4958},
{"f_4756support.scm",(void*)f_4756},
{"f_4760support.scm",(void*)f_4760},
{"f_4768support.scm",(void*)f_4768},
{"f_4917support.scm",(void*)f_4917},
{"f_4925support.scm",(void*)f_4925},
{"f_4920support.scm",(void*)f_4920},
{"f_4869support.scm",(void*)f_4869},
{"f_4873support.scm",(void*)f_4873},
{"f_4876support.scm",(void*)f_4876},
{"f_4911support.scm",(void*)f_4911},
{"f_4903support.scm",(void*)f_4903},
{"f_4887support.scm",(void*)f_4887},
{"f_4882support.scm",(void*)f_4882},
{"f_4836support.scm",(void*)f_4836},
{"f_4839support.scm",(void*)f_4839},
{"f_4850support.scm",(void*)f_4850},
{"f_4845support.scm",(void*)f_4845},
{"f_4820support.scm",(void*)f_4820},
{"f_4812support.scm",(void*)f_4812},
{"f_4807support.scm",(void*)f_4807},
{"f_4791support.scm",(void*)f_4791},
{"f_4762support.scm",(void*)f_4762},
{"f_4663support.scm",(void*)f_4663},
{"f_4669support.scm",(void*)f_4669},
{"f_4681support.scm",(void*)f_4681},
{"f_4685support.scm",(void*)f_4685},
{"f_4688support.scm",(void*)f_4688},
{"f_4748support.scm",(void*)f_4748},
{"f_4724support.scm",(void*)f_4724},
{"f_4707support.scm",(void*)f_4707},
{"f_4711support.scm",(void*)f_4711},
{"f_4693support.scm",(void*)f_4693},
{"f_4675support.scm",(void*)f_4675},
{"f_4615support.scm",(void*)f_4615},
{"f_4621support.scm",(void*)f_4621},
{"f_4641support.scm",(void*)f_4641},
{"f_4645support.scm",(void*)f_4645},
{"f_4321support.scm",(void*)f_4321},
{"f_4327support.scm",(void*)f_4327},
{"f_4346support.scm",(void*)f_4346},
{"f_4556support.scm",(void*)f_4556},
{"f_4586support.scm",(void*)f_4586},
{"f_4582support.scm",(void*)f_4582},
{"f_4563support.scm",(void*)f_4563},
{"f_4567support.scm",(void*)f_4567},
{"f_4502support.scm",(void*)f_4502},
{"f_4543support.scm",(void*)f_4543},
{"f_4516support.scm",(void*)f_4516},
{"f_4520support.scm",(void*)f_4520},
{"f_4478support.scm",(void*)f_4478},
{"f_4445support.scm",(void*)f_4445},
{"f_4424support.scm",(void*)f_4424},
{"f_4420support.scm",(void*)f_4420},
{"f_4408support.scm",(void*)f_4408},
{"f_4416support.scm",(void*)f_4416},
{"f_4412support.scm",(void*)f_4412},
{"f_4370support.scm",(void*)f_4370},
{"f_4353support.scm",(void*)f_4353},
{"f_3813support.scm",(void*)f_3813},
{"f_4316support.scm",(void*)f_4316},
{"f_4319support.scm",(void*)f_4319},
{"f_3816support.scm",(void*)f_3816},
{"f_4306support.scm",(void*)f_4306},
{"f_4189support.scm",(void*)f_4189},
{"f_4232support.scm",(void*)f_4232},
{"f_4246support.scm",(void*)f_4246},
{"f_4253support.scm",(void*)f_4253},
{"f_4260support.scm",(void*)f_4260},
{"f_4250support.scm",(void*)f_4250},
{"f_4239support.scm",(void*)f_4239},
{"f_4226support.scm",(void*)f_4226},
{"f_4214support.scm",(void*)f_4214},
{"f_4198support.scm",(void*)f_4198},
{"f_4168support.scm",(void*)f_4168},
{"f_4152support.scm",(void*)f_4152},
{"f_4148support.scm",(void*)f_4148},
{"f_4115support.scm",(void*)f_4115},
{"f_4073support.scm",(void*)f_4073},
{"f_4042support.scm",(void*)f_4042},
{"f_4028support.scm",(void*)f_4028},
{"f_4002support.scm",(void*)f_4002},
{"f_3951support.scm",(void*)f_3951},
{"f_3971support.scm",(void*)f_3971},
{"f_3961support.scm",(void*)f_3961},
{"f_3969support.scm",(void*)f_3969},
{"f_3954support.scm",(void*)f_3954},
{"f_3901support.scm",(void*)f_3901},
{"f_3904support.scm",(void*)f_3904},
{"f_3911support.scm",(void*)f_3911},
{"f_3898support.scm",(void*)f_3898},
{"f_3875support.scm",(void*)f_3875},
{"f_3804support.scm",(void*)f_3804},
{"f_3795support.scm",(void*)f_3795},
{"f_3789support.scm",(void*)f_3789},
{"f_3780support.scm",(void*)f_3780},
{"f_3771support.scm",(void*)f_3771},
{"f_3762support.scm",(void*)f_3762},
{"f_3753support.scm",(void*)f_3753},
{"f_3744support.scm",(void*)f_3744},
{"f_3735support.scm",(void*)f_3735},
{"f_3729support.scm",(void*)f_3729},
{"f_3723support.scm",(void*)f_3723},
{"f_3313support.scm",(void*)f_3313},
{"f_3721support.scm",(void*)f_3721},
{"f_3317support.scm",(void*)f_3317},
{"f_3322support.scm",(void*)f_3322},
{"f_3332support.scm",(void*)f_3332},
{"f_3422support.scm",(void*)f_3422},
{"f_3432support.scm",(void*)f_3432},
{"f_3448support.scm",(void*)f_3448},
{"f_3505support.scm",(void*)f_3505},
{"f_3536support.scm",(void*)f_3536},
{"f_3526support.scm",(void*)f_3526},
{"f_3512support.scm",(void*)f_3512},
{"f_3516support.scm",(void*)f_3516},
{"f_3496support.scm",(void*)f_3496},
{"f_3486support.scm",(void*)f_3486},
{"f_3463support.scm",(void*)f_3463},
{"f_3435support.scm",(void*)f_3435},
{"f_3335support.scm",(void*)f_3335},
{"f_3370support.scm",(void*)f_3370},
{"f_3391support.scm",(void*)f_3391},
{"f_3338support.scm",(void*)f_3338},
{"f_3341support.scm",(void*)f_3341},
{"f_3344support.scm",(void*)f_3344},
{"f_3294support.scm",(void*)f_3294},
{"f_3300support.scm",(void*)f_3300},
{"f_3311support.scm",(void*)f_3311},
{"f_3270support.scm",(void*)f_3270},
{"f_3276support.scm",(void*)f_3276},
{"f_3286support.scm",(void*)f_3286},
{"f_3234support.scm",(void*)f_3234},
{"f_3241support.scm",(void*)f_3241},
{"f_3244support.scm",(void*)f_3244},
{"f_3224support.scm",(void*)f_3224},
{"f_3167support.scm",(void*)f_3167},
{"f_3171support.scm",(void*)f_3171},
{"f_3201support.scm",(void*)f_3201},
{"f_3115support.scm",(void*)f_3115},
{"f_3119support.scm",(void*)f_3119},
{"f_3146support.scm",(void*)f_3146},
{"f_3069support.scm",(void*)f_3069},
{"f_3073support.scm",(void*)f_3073},
{"f_3095support.scm",(void*)f_3095},
{"f_3051support.scm",(void*)f_3051},
{"f_3055support.scm",(void*)f_3055},
{"f_3063support.scm",(void*)f_3063},
{"f_3033support.scm",(void*)f_3033},
{"f_3037support.scm",(void*)f_3037},
{"f_2972support.scm",(void*)f_2972},
{"f_3009support.scm",(void*)f_3009},
{"f_3013support.scm",(void*)f_3013},
{"f_3016support.scm",(void*)f_3016},
{"f_2976support.scm",(void*)f_2976},
{"f_2994support.scm",(void*)f_2994},
{"f_2998support.scm",(void*)f_2998},
{"f_2979support.scm",(void*)f_2979},
{"f_2984support.scm",(void*)f_2984},
{"f_2915support.scm",(void*)f_2915},
{"f_2919support.scm",(void*)f_2919},
{"f_2923support.scm",(void*)f_2923},
{"f_2912support.scm",(void*)f_2912},
{"f_2809support.scm",(void*)f_2809},
{"f_2818support.scm",(void*)f_2818},
{"f_2849support.scm",(void*)f_2849},
{"f_2899support.scm",(void*)f_2899},
{"f_2905support.scm",(void*)f_2905},
{"f_2855support.scm",(void*)f_2855},
{"f_2883support.scm",(void*)f_2883},
{"f_2897support.scm",(void*)f_2897},
{"f_2889support.scm",(void*)f_2889},
{"f_2859support.scm",(void*)f_2859},
{"f_2824support.scm",(void*)f_2824},
{"f_2830support.scm",(void*)f_2830},
{"f_2841support.scm",(void*)f_2841},
{"f_2838support.scm",(void*)f_2838},
{"f_2816support.scm",(void*)f_2816},
{"f_2434support.scm",(void*)f_2434},
{"f_2798support.scm",(void*)f_2798},
{"f_2437support.scm",(void*)f_2437},
{"f_2642support.scm",(void*)f_2642},
{"f_2651support.scm",(void*)f_2651},
{"f_2752support.scm",(void*)f_2752},
{"f_2748support.scm",(void*)f_2748},
{"f_2698support.scm",(void*)f_2698},
{"f_2721support.scm",(void*)f_2721},
{"f_2717support.scm",(void*)f_2717},
{"f_2661support.scm",(void*)f_2661},
{"f_2664support.scm",(void*)f_2664},
{"f_2684support.scm",(void*)f_2684},
{"f_2692support.scm",(void*)f_2692},
{"f_2678support.scm",(void*)f_2678},
{"f_2682support.scm",(void*)f_2682},
{"f_2591support.scm",(void*)f_2591},
{"f_2611support.scm",(void*)f_2611},
{"f_2603support.scm",(void*)f_2603},
{"f_2607support.scm",(void*)f_2607},
{"f_2439support.scm",(void*)f_2439},
{"f_2449support.scm",(void*)f_2449},
{"f_2458support.scm",(void*)f_2458},
{"f_2482support.scm",(void*)f_2482},
{"f_2489support.scm",(void*)f_2489},
{"f_2469support.scm",(void*)f_2469},
{"f_2351support.scm",(void*)f_2351},
{"f_2357support.scm",(void*)f_2357},
{"f_2422support.scm",(void*)f_2422},
{"f_2385support.scm",(void*)f_2385},
{"f_2415support.scm",(void*)f_2415},
{"f_2403support.scm",(void*)f_2403},
{"f_2291support.scm",(void*)f_2291},
{"f_2307support.scm",(void*)f_2307},
{"f_2349support.scm",(void*)f_2349},
{"f_2313support.scm",(void*)f_2313},
{"f_2328support.scm",(void*)f_2328},
{"f_2245support.scm",(void*)f_2245},
{"f_2289support.scm",(void*)f_2289},
{"f_2249support.scm",(void*)f_2249},
{"f_2215support.scm",(void*)f_2215},
{"f_2169support.scm",(void*)f_2169},
{"f_2138support.scm",(void*)f_2138},
{"f_2144support.scm",(void*)f_2144},
{"f_2159support.scm",(void*)f_2159},
{"f_2075support.scm",(void*)f_2075},
{"f_2089support.scm",(void*)f_2089},
{"f_2091support.scm",(void*)f_2091},
{"f_2120support.scm",(void*)f_2120},
{"f_2099support.scm",(void*)f_2099},
{"f_2063support.scm",(void*)f_2063},
{"f_2016support.scm",(void*)f_2016},
{"f_2032support.scm",(void*)f_2032},
{"f_2044support.scm",(void*)f_2044},
{"f_2009support.scm",(void*)f_2009},
{"f_2002support.scm",(void*)f_2002},
{"f_1946support.scm",(void*)f_1946},
{"f_2000support.scm",(void*)f_2000},
{"f_1950support.scm",(void*)f_1950},
{"f_1973support.scm",(void*)f_1973},
{"f_1852support.scm",(void*)f_1852},
{"f_1868support.scm",(void*)f_1868},
{"f_1870support.scm",(void*)f_1870},
{"f_1892support.scm",(void*)f_1892},
{"f_1931support.scm",(void*)f_1931},
{"f_1899support.scm",(void*)f_1899},
{"f_1915support.scm",(void*)f_1915},
{"f_1903support.scm",(void*)f_1903},
{"f_1907support.scm",(void*)f_1907},
{"f_1864support.scm",(void*)f_1864},
{"f_1808support.scm",(void*)f_1808},
{"f_1814support.scm",(void*)f_1814},
{"f_1838support.scm",(void*)f_1838},
{"f_1783support.scm",(void*)f_1783},
{"f_1806support.scm",(void*)f_1806},
{"f_1762support.scm",(void*)f_1762},
{"f_1726support.scm",(void*)f_1726},
{"f_1732support.scm",(void*)f_1732},
{"f_1658support.scm",(void*)f_1658},
{"f_1682support.scm",(void*)f_1682},
{"f_1661support.scm",(void*)f_1661},
{"f_1669support.scm",(void*)f_1669},
{"f_1673support.scm",(void*)f_1673},
{"f_1615support.scm",(void*)f_1615},
{"f_1621support.scm",(void*)f_1621},
{"f_1644support.scm",(void*)f_1644},
{"f_1648support.scm",(void*)f_1648},
{"f_1612support.scm",(void*)f_1612},
{"f_1587support.scm",(void*)f_1587},
{"f_1591support.scm",(void*)f_1591},
{"f_1594support.scm",(void*)f_1594},
{"f_1605support.scm",(void*)f_1605},
{"f_1597support.scm",(void*)f_1597},
{"f_1600support.scm",(void*)f_1600},
{"f_1568support.scm",(void*)f_1568},
{"f_1572support.scm",(void*)f_1572},
{"f_1585support.scm",(void*)f_1585},
{"f_1575support.scm",(void*)f_1575},
{"f_1578support.scm",(void*)f_1578},
{"f_1539support.scm",(void*)f_1539},
{"f_1546support.scm",(void*)f_1546},
{"f_1549support.scm",(void*)f_1549},
{"f_1559support.scm",(void*)f_1559},
{"f_1552support.scm",(void*)f_1552},
{"f_1499support.scm",(void*)f_1499},
{"f_1509support.scm",(void*)f_1509},
{"f_1524support.scm",(void*)f_1524},
{"f_1529support.scm",(void*)f_1529},
{"f_1537support.scm",(void*)f_1537},
{"f_1512support.scm",(void*)f_1512},
{"f_1515support.scm",(void*)f_1515},
{"f_1518support.scm",(void*)f_1518},
{"f_1472support.scm",(void*)f_1472},
{"f_1486support.scm",(void*)f_1486},
{"f_1467support.scm",(void*)f_1467},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
