/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-07 15:25
   Version 4.0.0x1 - SVN rev. 12338
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-11-03 on dill (Linux)
   command line: support.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[505];
static double C_possibly_force_alignment;


/* from k4429 */
static C_word C_fcall stub331(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub331(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4422 */
static C_word C_fcall stub326(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub326(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11908)
static void C_ccall f_11908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11913)
static void C_ccall f_11913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11902)
static void C_ccall f_11902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11874)
static void C_ccall f_11874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11874)
static void C_ccall f_11874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11878)
static void C_ccall f_11878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11853)
static void C_ccall f_11853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11857)
static void C_ccall f_11857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11820)
static void C_ccall f_11820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11825)
static void C_ccall f_11825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11825)
static void C_ccall f_11825r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11829)
static void C_ccall f_11829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11787)
static void C_ccall f_11787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11792)
static void C_ccall f_11792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11792)
static void C_ccall f_11792r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11796)
static void C_ccall f_11796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11763)
static void C_ccall f_11763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11734)
static void C_ccall f_11734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11761)
static void C_ccall f_11761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11745)
static void C_ccall f_11745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11748)
static void C_ccall f_11748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11750)
static void C_ccall f_11750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11754)
static void C_ccall f_11754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11738)
static void C_fcall f_11738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11671)
static void C_ccall f_11671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11708)
static void C_ccall f_11708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11732)
static void C_ccall f_11732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11718)
static void C_ccall f_11718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11722)
static void C_ccall f_11722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11693)
static void C_ccall f_11693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11701)
static void C_ccall f_11701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11602)
static void C_ccall f_11602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11606)
static void C_ccall f_11606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11611)
static void C_fcall f_11611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11615)
static void C_ccall f_11615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11666)
static void C_ccall f_11666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11645)
static void C_ccall f_11645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11657)
static void C_ccall f_11657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11660)
static void C_ccall f_11660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11633)
static void C_ccall f_11633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11569)
static void C_ccall f_11569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11579)
static void C_ccall f_11579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11582)
static void C_ccall f_11582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11467)
static void C_ccall f_11467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11476)
static void C_fcall f_11476(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11563)
static void C_ccall f_11563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11480)
static void C_ccall f_11480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11558)
static void C_ccall f_11558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11483)
static void C_ccall f_11483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11553)
static void C_ccall f_11553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11486)
static void C_ccall f_11486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11489)
static void C_ccall f_11489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11495)
static void C_ccall f_11495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11548)
static void C_ccall f_11548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11498)
static void C_ccall f_11498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11513)
static void C_ccall f_11513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11521)
static void C_fcall f_11521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11531)
static void C_ccall f_11531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11516)
static void C_ccall f_11516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11504)
static void C_ccall f_11504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11471)
static void C_ccall f_11471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11461)
static void C_ccall f_11461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11415)
static void C_ccall f_11415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11434)
static void C_ccall f_11434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11445)
static void C_ccall f_11445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11441)
static void C_ccall f_11441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11403)
static void C_ccall f_11403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11409)
static void C_ccall f_11409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11391)
static void C_ccall f_11391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11395)
static void C_ccall f_11395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11312)
static void C_ccall f_11312(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11312)
static void C_ccall f_11312r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11331)
static void C_ccall f_11331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11356)
static void C_ccall f_11356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11360)
static void C_ccall f_11360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11362)
static void C_fcall f_11362(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11369)
static void C_ccall f_11369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11386)
static void C_ccall f_11386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11315)
static void C_fcall f_11315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11319)
static void C_ccall f_11319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11325)
static void C_ccall f_11325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11306)
static void C_ccall f_11306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11262)
static void C_ccall f_11262(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11262)
static void C_ccall f_11262r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11274)
static void C_ccall f_11274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11278)
static void C_ccall f_11278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11282)
static void C_ccall f_11282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11270)
static void C_ccall f_11270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11253)
static void C_ccall f_11253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11247)
static void C_ccall f_11247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11241)
static void C_ccall f_11241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11229)
static void C_ccall f_11229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11233)
static void C_ccall f_11233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11236)
static void C_ccall f_11236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11191)
static void C_ccall f_11191(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11191)
static void C_ccall f_11191r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11195)
static void C_ccall f_11195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11198)
static void C_ccall f_11198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11205)
static void C_ccall f_11205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11149)
static void C_ccall f_11149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11158)
static void C_fcall f_11158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11120)
static void C_ccall f_11120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11130)
static void C_fcall f_11130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10923)
static void C_ccall f_10923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11102)
static void C_ccall f_11102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11051)
static void C_ccall f_11051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11096)
static void C_ccall f_11096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11100)
static void C_ccall f_11100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11054)
static void C_ccall f_11054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11059)
static void C_ccall f_11059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11063)
static void C_ccall f_11063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11057)
static void C_ccall f_11057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11014)
static void C_fcall f_11014(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11027)
static void C_ccall f_11027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11031)
static void C_ccall f_11031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11021)
static void C_ccall f_11021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_fcall f_10979(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10985)
static void C_fcall f_10985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11012)
static void C_ccall f_11012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10932)
static void C_fcall f_10932(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10938)
static void C_fcall f_10938(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10977)
static void C_ccall f_10977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10959)
static void C_ccall f_10959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10736)
static void C_ccall f_10736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10918)
static void C_ccall f_10918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10905)
static void C_fcall f_10905(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10911)
static void C_ccall f_10911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10739)
static void C_fcall f_10739(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10743)
static void C_ccall f_10743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10894)
static void C_ccall f_10894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10746)
static void C_ccall f_10746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10889)
static void C_ccall f_10889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10749)
static void C_ccall f_10749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10758)
static void C_fcall f_10758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10852)
static void C_ccall f_10852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10864)
static void C_ccall f_10864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10822)
static void C_ccall f_10822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10833)
static void C_ccall f_10833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10813)
static void C_ccall f_10813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10799)
static void C_fcall f_10799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10777)
static void C_ccall f_10777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10783)
static void C_ccall f_10783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10787)
static void C_ccall f_10787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10643)
static void C_ccall f_10643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10730)
static void C_ccall f_10730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10653)
static void C_ccall f_10653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10656)
static void C_ccall f_10656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10709)
static void C_fcall f_10709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10695)
static void C_ccall f_10695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10677)
static void C_fcall f_10677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10671)
static void C_fcall f_10671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10647)
static void C_ccall f_10647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10351)
static void C_ccall f_10351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10547)
static void C_fcall f_10547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10568)
static void C_fcall f_10568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10345)
static void C_ccall f_10345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10053)
static void C_ccall f_10053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10063)
static void C_fcall f_10063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10081)
static void C_ccall f_10081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10115)
static void C_fcall f_10115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10044)
static void C_fcall f_10044(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10035)
static void C_ccall f_10035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9728)
static void C_ccall f_9728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9738)
static void C_fcall f_9738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9747)
static void C_fcall f_9747(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_fcall f_9759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9771)
static void C_fcall f_9771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9777)
static void C_ccall f_9777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9811)
static void C_fcall f_9811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9682)
static void C_ccall f_9682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9716)
static void C_ccall f_9716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9688)
static void C_ccall f_9688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9651)
static void C_ccall f_9651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9664)
static void C_ccall f_9664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9655)
static void C_fcall f_9655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9620)
static void C_ccall f_9620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9633)
static void C_ccall f_9633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9624)
static void C_fcall f_9624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8573)
static void C_ccall f_8573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9614)
static void C_ccall f_9614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8579)
static void C_ccall f_8579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8585)
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8614)
static void C_fcall f_8614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8633)
static void C_fcall f_8633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_fcall f_8652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_fcall f_8722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_fcall f_8741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8823)
static void C_fcall f_8823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8862)
static void C_fcall f_8862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_fcall f_8881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8900)
static void C_fcall f_8900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_fcall f_8980(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9065)
static void C_fcall f_9065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_fcall f_9174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9244)
static void C_ccall f_9244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9177)
static void C_ccall f_9177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9014)
static void C_fcall f_9014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8775)
static void C_fcall f_8775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_fcall f_8686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8537)
static void C_ccall f_8537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8541)
static void C_ccall f_8541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8558)
static void C_ccall f_8558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8498)
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8517)
static void C_ccall f_8517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8520)
static void C_ccall f_8520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8523)
static void C_ccall f_8523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8504)
static void C_ccall f_8504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8421)
static void C_ccall f_8421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8427)
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8474)
static void C_ccall f_8474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8416)
static void C_ccall f_8416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8391)
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8401)
static void C_ccall f_8401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8366)
static void C_ccall f_8366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8373)
static void C_fcall f_8373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8238)
static void C_ccall f_8238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8354)
static void C_ccall f_8354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8242)
static void C_ccall f_8242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8262)
static void C_ccall f_8262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8266)
static void C_ccall f_8266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8338)
static void C_ccall f_8338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8275)
static void C_ccall f_8275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8314)
static void C_ccall f_8314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8305)
static void C_ccall f_8305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8137)
static void C_ccall f_8137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8143)
static void C_ccall f_8143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8232)
static void C_ccall f_8232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8150)
static void C_ccall f_8150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8159)
static void C_fcall f_8159(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8185)
static void C_ccall f_8185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8173)
static void C_ccall f_8173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7992)
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8104)
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8091)
static void C_ccall f_8091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8078)
static void C_ccall f_8078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8021)
static void C_ccall f_8021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8027)
static void C_fcall f_8027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_fcall f_7949(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7971)
static void C_ccall f_7971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_fcall f_7920(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_fcall f_7860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7681)
static void C_ccall f_7681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7720)
static void C_fcall f_7720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7809)
static void C_ccall f_7809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7753)
static void C_fcall f_7753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7656)
static void C_ccall f_7656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7576)
static void C_ccall f_7576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7597)
static void C_ccall f_7597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7556)
static void C_ccall f_7556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7546)
static void C_ccall f_7546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_ccall f_7538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static C_word C_fcall f_7506(C_word t0,C_word t1);
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7457)
static void C_fcall f_7457(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_fcall f_7242(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7382)
static void C_ccall f_7382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7338)
static void C_ccall f_7338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7331)
static void C_ccall f_7331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_fcall f_7236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7123)
static void C_ccall f_7123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7192)
static void C_ccall f_7192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7184)
static void C_ccall f_7184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7069)
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7095)
static void C_ccall f_7095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_fcall f_6755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6989)
static void C_fcall f_6989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_fcall f_6927(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6953)
static void C_ccall f_6953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6829)
static void C_ccall f_6829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6728)
static void C_ccall f_6728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6563)
static void C_fcall f_6563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_fcall f_6641(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6522)
static void C_ccall f_6522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6388)
static void C_fcall f_6388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6276)
static void C_ccall f_6276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6222)
static void C_fcall f_6222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_fcall f_6219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6091)
static void C_ccall f_6091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_fcall f_5533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5696)
static void C_fcall f_5696(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5722)
static void C_fcall f_5722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_fcall f_5795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_fcall f_5586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_fcall f_5617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_fcall f_5648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5492)
static void C_fcall f_5492(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_fcall f_5460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4794)
static void C_fcall f_4794(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_fcall f_4822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_fcall f_4686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4561)
static void C_fcall f_4561(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_fcall f_4508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_fcall f_4516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_fcall f_4461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_fcall f_4287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4309)
static void C_fcall f_4309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_fcall f_4316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4231)
static void C_fcall f_4231(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4149)
static C_word C_fcall f_4149(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4099)
static void C_fcall f_4099(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4078)
static void C_fcall f_4078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4038)
static void C_fcall f_4038(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3963)
static void C_fcall f_3963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11738)
static void C_fcall trf_11738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11738(t0,t1);}

C_noret_decl(trf_11611)
static void C_fcall trf_11611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11611(t0,t1);}

C_noret_decl(trf_11476)
static void C_fcall trf_11476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11476(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11476(t0,t1,t2,t3);}

C_noret_decl(trf_11521)
static void C_fcall trf_11521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11521(t0,t1,t2);}

C_noret_decl(trf_11362)
static void C_fcall trf_11362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11362(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11362(t0,t1,t2,t3);}

C_noret_decl(trf_11315)
static void C_fcall trf_11315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11315(t0,t1);}

C_noret_decl(trf_11158)
static void C_fcall trf_11158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11158(t0,t1,t2);}

C_noret_decl(trf_11130)
static void C_fcall trf_11130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11130(t0,t1);}

C_noret_decl(trf_11014)
static void C_fcall trf_11014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11014(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11014(t0,t1,t2,t3);}

C_noret_decl(trf_10979)
static void C_fcall trf_10979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10979(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10979(t0,t1,t2);}

C_noret_decl(trf_10985)
static void C_fcall trf_10985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10985(t0,t1,t2);}

C_noret_decl(trf_10932)
static void C_fcall trf_10932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10932(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10932(t0,t1,t2,t3);}

C_noret_decl(trf_10938)
static void C_fcall trf_10938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10938(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10938(t0,t1,t2);}

C_noret_decl(trf_10905)
static void C_fcall trf_10905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10905(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10905(t0,t1,t2,t3);}

C_noret_decl(trf_10739)
static void C_fcall trf_10739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10739(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10739(t0,t1,t2,t3);}

C_noret_decl(trf_10758)
static void C_fcall trf_10758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10758(t0,t1);}

C_noret_decl(trf_10799)
static void C_fcall trf_10799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10799(t0,t1);}

C_noret_decl(trf_10709)
static void C_fcall trf_10709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10709(t0,t1);}

C_noret_decl(trf_10677)
static void C_fcall trf_10677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10677(t0,t1);}

C_noret_decl(trf_10671)
static void C_fcall trf_10671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10671(t0,t1);}

C_noret_decl(trf_10547)
static void C_fcall trf_10547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10547(t0,t1);}

C_noret_decl(trf_10568)
static void C_fcall trf_10568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10568(t0,t1);}

C_noret_decl(trf_10063)
static void C_fcall trf_10063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10063(t0,t1);}

C_noret_decl(trf_10115)
static void C_fcall trf_10115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10115(t0,t1);}

C_noret_decl(trf_10044)
static void C_fcall trf_10044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10044(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10044(t0,t1);}

C_noret_decl(trf_9738)
static void C_fcall trf_9738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9738(t0,t1);}

C_noret_decl(trf_9747)
static void C_fcall trf_9747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9747(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9747(t0,t1);}

C_noret_decl(trf_9759)
static void C_fcall trf_9759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9759(t0,t1);}

C_noret_decl(trf_9771)
static void C_fcall trf_9771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9771(t0,t1);}

C_noret_decl(trf_9811)
static void C_fcall trf_9811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9811(t0,t1);}

C_noret_decl(trf_9655)
static void C_fcall trf_9655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9655(t0,t1);}

C_noret_decl(trf_9624)
static void C_fcall trf_9624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9624(t0,t1);}

C_noret_decl(trf_8585)
static void C_fcall trf_8585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8585(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8585(t0,t1,t2);}

C_noret_decl(trf_8614)
static void C_fcall trf_8614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8614(t0,t1);}

C_noret_decl(trf_8633)
static void C_fcall trf_8633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8633(t0,t1);}

C_noret_decl(trf_8652)
static void C_fcall trf_8652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8652(t0,t1);}

C_noret_decl(trf_8722)
static void C_fcall trf_8722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8722(t0,t1);}

C_noret_decl(trf_8741)
static void C_fcall trf_8741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8741(t0,t1);}

C_noret_decl(trf_8823)
static void C_fcall trf_8823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8823(t0,t1);}

C_noret_decl(trf_8862)
static void C_fcall trf_8862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8862(t0,t1);}

C_noret_decl(trf_8881)
static void C_fcall trf_8881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8881(t0,t1);}

C_noret_decl(trf_8900)
static void C_fcall trf_8900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8900(t0,t1);}

C_noret_decl(trf_8980)
static void C_fcall trf_8980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8980(t0,t1);}

C_noret_decl(trf_9065)
static void C_fcall trf_9065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9065(t0,t1);}

C_noret_decl(trf_9174)
static void C_fcall trf_9174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9174(t0,t1);}

C_noret_decl(trf_9014)
static void C_fcall trf_9014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9014(t0,t1);}

C_noret_decl(trf_8775)
static void C_fcall trf_8775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8775(t0,t1);}

C_noret_decl(trf_8686)
static void C_fcall trf_8686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8686(t0,t1);}

C_noret_decl(trf_8373)
static void C_fcall trf_8373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8373(t0,t1);}

C_noret_decl(trf_8159)
static void C_fcall trf_8159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8159(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8159(t0,t1);}

C_noret_decl(trf_7992)
static void C_fcall trf_7992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7992(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7992(t0,t1,t2,t3);}

C_noret_decl(trf_8027)
static void C_fcall trf_8027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8027(t0,t1,t2,t3);}

C_noret_decl(trf_7949)
static void C_fcall trf_7949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7949(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7949(t0,t1,t2,t3);}

C_noret_decl(trf_7920)
static void C_fcall trf_7920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7920(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7920(t0,t1,t2,t3);}

C_noret_decl(trf_7860)
static void C_fcall trf_7860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7860(t0,t1);}

C_noret_decl(trf_7720)
static void C_fcall trf_7720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7720(t0,t1);}

C_noret_decl(trf_7753)
static void C_fcall trf_7753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7753(t0,t1);}

C_noret_decl(trf_7457)
static void C_fcall trf_7457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7457(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7457(t0,t1,t2);}

C_noret_decl(trf_7242)
static void C_fcall trf_7242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7242(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7242(t0,t1,t2,t3);}

C_noret_decl(trf_7236)
static void C_fcall trf_7236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7236(t0,t1,t2);}

C_noret_decl(trf_7069)
static void C_fcall trf_7069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7069(t0,t1,t2);}

C_noret_decl(trf_6755)
static void C_fcall trf_6755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6755(t0,t1);}

C_noret_decl(trf_6989)
static void C_fcall trf_6989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6989(t0,t1);}

C_noret_decl(trf_6927)
static void C_fcall trf_6927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6927(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6927(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6563)
static void C_fcall trf_6563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6563(t0,t1);}

C_noret_decl(trf_6641)
static void C_fcall trf_6641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6641(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6641(t0,t1);}

C_noret_decl(trf_6388)
static void C_fcall trf_6388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6388(t0,t1);}

C_noret_decl(trf_6222)
static void C_fcall trf_6222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6222(t0,t1);}

C_noret_decl(trf_6219)
static void C_fcall trf_6219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6219(t0,t1);}

C_noret_decl(trf_5533)
static void C_fcall trf_5533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5533(t0,t1);}

C_noret_decl(trf_5696)
static void C_fcall trf_5696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5696(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5696(t0,t1,t2);}

C_noret_decl(trf_5722)
static void C_fcall trf_5722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5722(t0,t1);}

C_noret_decl(trf_5795)
static void C_fcall trf_5795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5795(t0,t1);}

C_noret_decl(trf_5586)
static void C_fcall trf_5586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5586(t0,t1);}

C_noret_decl(trf_5617)
static void C_fcall trf_5617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5617(t0,t1);}

C_noret_decl(trf_5648)
static void C_fcall trf_5648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5648(t0,t1);}

C_noret_decl(trf_5492)
static void C_fcall trf_5492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5492(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5492(t0,t1,t2);}

C_noret_decl(trf_5460)
static void C_fcall trf_5460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5460(t0,t1);}

C_noret_decl(trf_4794)
static void C_fcall trf_4794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4794(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4794(t0,t1,t2);}

C_noret_decl(trf_4822)
static void C_fcall trf_4822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4822(t0,t1);}

C_noret_decl(trf_4686)
static void C_fcall trf_4686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4686(t0,t1);}

C_noret_decl(trf_4561)
static void C_fcall trf_4561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4561(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4561(t0,t1,t2,t3);}

C_noret_decl(trf_4508)
static void C_fcall trf_4508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4508(t0,t1,t2);}

C_noret_decl(trf_4516)
static void C_fcall trf_4516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4516(t0,t1);}

C_noret_decl(trf_4461)
static void C_fcall trf_4461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4461(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4461(t0,t1);}

C_noret_decl(trf_4287)
static void C_fcall trf_4287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4287(t0,t1,t2);}

C_noret_decl(trf_4309)
static void C_fcall trf_4309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4309(t0,t1);}

C_noret_decl(trf_4316)
static void C_fcall trf_4316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4316(t0,t1);}

C_noret_decl(trf_4231)
static void C_fcall trf_4231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4231(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4231(t0,t1,t2,t3);}

C_noret_decl(trf_4099)
static void C_fcall trf_4099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4099(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4099(t0,t1,t2,t3);}

C_noret_decl(trf_4078)
static void C_fcall trf_4078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4078(t0,t1);}

C_noret_decl(trf_4038)
static void C_fcall trf_4038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4038(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4038(t0,t1,t2);}

C_noret_decl(trf_3963)
static void C_fcall trf_3963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3963(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5120)){
C_save(t1);
C_rereclaim2(5120*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,505);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],12,"flush-output");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],6,"printf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[15]=C_h_intern(&lf[15],5,"force");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[20]=C_h_intern(&lf[20],25,"\010compilercompiler-warning");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],20,"\003syswarnings-enabled");
lf[25]=C_h_intern(&lf[25],4,"quit");
lf[26]=C_h_intern(&lf[26],4,"exit");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[28]=C_h_intern(&lf[28],21,"\003syssyntax-error-hook");
lf[29]=C_h_intern(&lf[29],16,"print-call-chain");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[34]=C_h_intern(&lf[34],12,"syntax-error");
lf[35]=C_h_intern(&lf[35],31,"\010compileremit-syntax-trace-info");
lf[36]=C_h_intern(&lf[36],9,"map-llist");
lf[37]=C_h_intern(&lf[37],24,"\010compilercheck-signature");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[39]=C_h_intern(&lf[39],18,"\010compilerreal-name");
lf[40]=C_h_intern(&lf[40],13,"\010compilerposq");
lf[41]=C_h_intern(&lf[41],18,"\010compilerstringify");
lf[42]=C_h_intern(&lf[42],14,"symbol->string");
lf[43]=C_h_intern(&lf[43],7,"sprintf");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[45]=C_h_intern(&lf[45],18,"\010compilersymbolify");
lf[46]=C_h_intern(&lf[46],14,"string->symbol");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[48]=C_h_intern(&lf[48],26,"\010compilerbuild-lambda-list");
lf[49]=C_h_intern(&lf[49],29,"\010compilerstring->c-identifier");
lf[50]=C_h_intern(&lf[50],24,"\003sysstring->c-identifier");
lf[51]=C_h_intern(&lf[51],21,"\010compilerc-ify-string");
lf[52]=C_h_intern(&lf[52],16,"\003syslist->string");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[54]=C_h_intern(&lf[54],6,"append");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[56]=C_h_intern(&lf[56],16,"\003sysstring->list");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[60]=C_h_intern(&lf[60],28,"\010compilervalid-c-identifier\077");
lf[61]=C_h_intern(&lf[61],3,"any");
lf[62]=C_h_intern(&lf[62],8,"->string");
lf[63]=C_h_intern(&lf[63],14,"\010compilerwords");
lf[64]=C_h_intern(&lf[64],21,"\010compilerwords->bytes");
lf[65]=C_h_intern(&lf[65],34,"\010compilercheck-and-open-input-file");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[67]=C_h_intern(&lf[67],18,"current-input-port");
lf[68]=C_h_intern(&lf[68],15,"open-input-file");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[71]=C_h_intern(&lf[71],12,"file-exists\077");
lf[72]=C_h_intern(&lf[72],33,"\010compilerclose-checked-input-file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[74]=C_h_intern(&lf[74],16,"close-input-port");
lf[75]=C_h_intern(&lf[75],19,"\010compilerfold-inner");
lf[76]=C_h_intern(&lf[76],7,"reverse");
lf[77]=C_h_intern(&lf[77],28,"\010compilerfollow-without-loop");
lf[78]=C_h_intern(&lf[78],21,"\010compilersort-symbols");
lf[79]=C_h_intern(&lf[79],8,"string<\077");
lf[80]=C_h_intern(&lf[80],4,"sort");
lf[81]=C_h_intern(&lf[81],18,"\010compilerconstant\077");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],29,"\010compilercollapsable-literal\077");
lf[84]=C_h_intern(&lf[84],19,"\010compilerimmediate\077");
lf[85]=C_h_intern(&lf[85],20,"\010compilerbig-fixnum\077");
lf[86]=C_h_intern(&lf[86],23,"\010compilerbasic-literal\077");
lf[87]=C_h_intern(&lf[87],5,"every");
lf[88]=C_h_intern(&lf[88],12,"vector->list");
lf[89]=C_h_intern(&lf[89],32,"\010compilercanonicalize-begin-body");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_h_intern(&lf[92],3,"let");
lf[93]=C_h_intern(&lf[93],6,"gensym");
lf[94]=C_h_intern(&lf[94],1,"t");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[96]=C_h_intern(&lf[96],21,"\010compilerstring->expr");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[99]=C_h_intern(&lf[99],5,"begin");
lf[100]=C_h_intern(&lf[100],10,"\003sysappend");
lf[101]=C_h_intern(&lf[101],4,"read");
lf[102]=C_h_intern(&lf[102],6,"unfold");
lf[103]=C_h_intern(&lf[103],11,"eof-object\077");
lf[104]=C_h_intern(&lf[104],6,"values");
lf[105]=C_h_intern(&lf[105],22,"with-input-from-string");
lf[106]=C_h_intern(&lf[106],22,"with-exception-handler");
lf[107]=C_h_intern(&lf[107],30,"call-with-current-continuation");
lf[108]=C_h_intern(&lf[108],30,"\010compilerdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],25,"\003sysdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],37,"\010compilerprocess-lambda-documentation");
lf[111]=C_h_intern(&lf[111],30,"\010compilerexpand-profile-lambda");
lf[112]=C_h_intern(&lf[112],29,"\010compilerprofile-lambda-index");
lf[113]=C_h_intern(&lf[113],28,"\010compilerprofile-lambda-list");
lf[114]=C_h_intern(&lf[114],33,"\010compilerprofile-info-vector-name");
lf[115]=C_h_intern(&lf[115],17,"\003sysprofile-entry");
lf[116]=C_h_intern(&lf[116],6,"lambda");
lf[117]=C_h_intern(&lf[117],5,"apply");
lf[118]=C_h_intern(&lf[118],16,"\003sysprofile-exit");
lf[119]=C_h_intern(&lf[119],16,"\003sysdynamic-wind");
lf[120]=C_h_intern(&lf[120],10,"alist-cons");
lf[121]=C_h_intern(&lf[121],37,"\010compilerinitialize-analysis-database");
lf[122]=C_h_intern(&lf[122],35,"\010compilerfoldable-extended-bindings");
lf[123]=C_h_intern(&lf[123],13,"\010compilerput!");
lf[124]=C_h_intern(&lf[124],8,"foldable");
lf[125]=C_h_intern(&lf[125],8,"\003sysput!");
lf[126]=C_h_intern(&lf[126],9,"\003syserror");
lf[127]=C_h_intern(&lf[127],18,"\010compilerintrinsic");
lf[128]=C_h_intern(&lf[128],8,"extended");
lf[129]=C_h_intern(&lf[129],17,"extended-bindings");
lf[130]=C_h_intern(&lf[130],35,"\010compilerfoldable-standard-bindings");
lf[131]=C_h_intern(&lf[131],41,"\010compilerside-effecting-standard-bindings");
lf[132]=C_h_intern(&lf[132],14,"side-effecting");
lf[133]=C_h_intern(&lf[133],8,"standard");
lf[134]=C_h_intern(&lf[134],17,"standard-bindings");
lf[135]=C_h_intern(&lf[135],12,"\010compilerget");
lf[136]=C_h_intern(&lf[136],18,"\003syshash-table-ref");
lf[137]=C_h_intern(&lf[137],16,"\010compilerget-all");
lf[138]=C_h_intern(&lf[138],10,"filter-map");
lf[139]=C_h_intern(&lf[139],19,"\003syshash-table-set!");
lf[140]=C_h_intern(&lf[140],17,"\010compilercollect!");
lf[141]=C_h_intern(&lf[141],15,"\010compilercount!");
lf[142]=C_h_intern(&lf[142],17,"\010compilerget-line");
lf[143]=C_h_intern(&lf[143],24,"\003sysline-number-database");
lf[144]=C_h_intern(&lf[144],19,"\010compilerget-line-2");
lf[145]=C_h_intern(&lf[145],30,"\010compilerfind-lambda-container");
lf[146]=C_h_intern(&lf[146],12,"contained-in");
lf[147]=C_h_intern(&lf[147],37,"\010compilerdisplay-line-number-database");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[149]=C_h_intern(&lf[149],7,"\003sysmap");
lf[150]=C_h_intern(&lf[150],3,"cdr");
lf[151]=C_h_intern(&lf[151],23,"\003syshash-table-for-each");
lf[152]=C_h_intern(&lf[152],34,"\010compilerdisplay-analysis-database");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\010\011lval=~s");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[158]=C_h_intern(&lf[158],7,"unknown");
lf[159]=C_h_intern(&lf[159],8,"captured");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[162]=C_h_intern(&lf[162],4,"caar");
lf[163]=C_h_intern(&lf[163],5,"value");
lf[164]=C_h_intern(&lf[164],4,"cdar");
lf[165]=C_h_intern(&lf[165],11,"local-value");
lf[166]=C_h_intern(&lf[166],15,"potential-value");
lf[167]=C_h_intern(&lf[167],10,"replacable");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[169]=C_h_intern(&lf[169],10,"references");
lf[170]=C_h_intern(&lf[170],10,"call-sites");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[172]=C_h_intern(&lf[172],4,"home");
lf[173]=C_h_intern(&lf[173],8,"contains");
lf[174]=C_h_intern(&lf[174],8,"use-expr");
lf[175]=C_h_intern(&lf[175],12,"closure-size");
lf[176]=C_h_intern(&lf[176],14,"rest-parameter");
lf[177]=C_h_intern(&lf[177],16,"o-r/access-count");
lf[178]=C_h_intern(&lf[178],18,"captured-variables");
lf[179]=C_h_intern(&lf[179],13,"explicit-rest");
lf[180]=C_h_intern(&lf[180],8,"assigned");
lf[181]=C_h_intern(&lf[181],5,"boxed");
lf[182]=C_h_intern(&lf[182],6,"global");
lf[183]=C_h_intern(&lf[183],12,"contractable");
lf[184]=C_h_intern(&lf[184],16,"standard-binding");
lf[185]=C_h_intern(&lf[185],16,"assigned-locally");
lf[186]=C_h_intern(&lf[186],11,"collapsable");
lf[187]=C_h_intern(&lf[187],9,"removable");
lf[188]=C_h_intern(&lf[188],9,"undefined");
lf[189]=C_h_intern(&lf[189],9,"replacing");
lf[190]=C_h_intern(&lf[190],6,"unused");
lf[191]=C_h_intern(&lf[191],6,"simple");
lf[192]=C_h_intern(&lf[192],9,"inlinable");
lf[193]=C_h_intern(&lf[193],13,"inline-export");
lf[194]=C_h_intern(&lf[194],21,"has-unused-parameters");
lf[195]=C_h_intern(&lf[195],16,"extended-binding");
lf[196]=C_h_intern(&lf[196],12,"customizable");
lf[197]=C_h_intern(&lf[197],8,"constant");
lf[198]=C_h_intern(&lf[198],10,"boxed-rest");
lf[199]=C_h_intern(&lf[199],11,"hidden-refs");
lf[200]=C_h_intern(&lf[200],5,"write");
lf[201]=C_h_intern(&lf[201],34,"\010compilerdefault-standard-bindings");
lf[202]=C_h_intern(&lf[202],34,"\010compilerdefault-extended-bindings");
lf[203]=C_h_intern(&lf[203],26,"\010compilerinternal-bindings");
lf[204]=C_h_intern(&lf[204],9,"make-node");
lf[205]=C_h_intern(&lf[205],4,"node");
lf[206]=C_h_intern(&lf[206],5,"node\077");
lf[207]=C_h_intern(&lf[207],15,"node-class-set!");
lf[208]=C_h_intern(&lf[208],14,"\003sysblock-set!");
lf[209]=C_h_intern(&lf[209],10,"node-class");
lf[210]=C_h_intern(&lf[210],20,"node-parameters-set!");
lf[211]=C_h_intern(&lf[211],15,"node-parameters");
lf[212]=C_h_intern(&lf[212],24,"node-subexpressions-set!");
lf[213]=C_h_intern(&lf[213],19,"node-subexpressions");
lf[214]=C_h_intern(&lf[214],16,"\010compilervarnode");
lf[215]=C_h_intern(&lf[215],13,"\004corevariable");
lf[216]=C_h_intern(&lf[216],14,"\010compilerqnode");
lf[217]=C_h_intern(&lf[217],25,"\010compilerbuild-node-graph");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[219]=C_h_intern(&lf[219],15,"\004coreglobal-ref");
lf[220]=C_h_intern(&lf[220],2,"if");
lf[221]=C_h_intern(&lf[221],14,"\004coreundefined");
lf[222]=C_h_intern(&lf[222],8,"truncate");
lf[223]=C_h_intern(&lf[223],4,"type");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[225]=C_h_intern(&lf[225],6,"fixnum");
lf[226]=C_h_intern(&lf[226],11,"number-type");
lf[227]=C_h_intern(&lf[227],6,"unzip1");
lf[228]=C_h_intern(&lf[228],11,"\004corelambda");
lf[229]=C_h_intern(&lf[229],14,"\004coreprimitive");
lf[230]=C_h_intern(&lf[230],11,"\004coreinline");
lf[231]=C_h_intern(&lf[231],13,"\004corecallunit");
lf[232]=C_h_intern(&lf[232],9,"\004coreproc");
lf[233]=C_h_intern(&lf[233],4,"set!");
lf[234]=C_h_intern(&lf[234],9,"\004coreset!");
lf[235]=C_h_intern(&lf[235],29,"\004coreforeign-callback-wrapper");
lf[236]=C_h_intern(&lf[236],5,"sixth");
lf[237]=C_h_intern(&lf[237],5,"fifth");
lf[238]=C_h_intern(&lf[238],20,"\004coreinline_allocate");
lf[239]=C_h_intern(&lf[239],8,"\004coreapp");
lf[240]=C_h_intern(&lf[240],9,"\004corecall");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[242]=C_h_intern(&lf[242],24,"\010compilersource-filename");
lf[243]=C_h_intern(&lf[243],28,"\003syssymbol->qualified-string");
lf[244]=C_h_intern(&lf[244],7,"\003sysget");
lf[245]=C_h_intern(&lf[245],34,"\010compileralways-bound-to-procedure");
lf[246]=C_h_intern(&lf[246],15,"\004coreinline_ref");
lf[247]=C_h_intern(&lf[247],18,"\004coreinline_update");
lf[248]=C_h_intern(&lf[248],19,"\004coreinline_loc_ref");
lf[249]=C_h_intern(&lf[249],22,"\004coreinline_loc_update");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[251]=C_h_intern(&lf[251],1,"o");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[253]=C_h_intern(&lf[253],30,"\010compilerbuild-expression-tree");
lf[254]=C_h_intern(&lf[254],12,"\004coreclosure");
lf[255]=C_h_intern(&lf[255],4,"last");
lf[256]=C_h_intern(&lf[256],3,"map");
lf[257]=C_h_intern(&lf[257],4,"list");
lf[258]=C_h_intern(&lf[258],7,"butlast");
lf[259]=C_h_intern(&lf[259],5,"cons*");
lf[260]=C_h_intern(&lf[260],9,"\004corebind");
lf[261]=C_h_intern(&lf[261],10,"\004coreunbox");
lf[262]=C_h_intern(&lf[262],8,"\004coreref");
lf[263]=C_h_intern(&lf[263],11,"\004coreupdate");
lf[264]=C_h_intern(&lf[264],13,"\004coreupdate_i");
lf[265]=C_h_intern(&lf[265],8,"\004corebox");
lf[266]=C_h_intern(&lf[266],9,"\004corecond");
lf[267]=C_h_intern(&lf[267],21,"\010compilerfold-boolean");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[269]=C_h_intern(&lf[269],31,"\010compilerinline-lambda-bindings");
lf[270]=C_h_intern(&lf[270],8,"split-at");
lf[271]=C_h_intern(&lf[271],10,"fold-right");
lf[272]=C_h_intern(&lf[272],4,"take");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[274]=C_h_intern(&lf[274],34,"\010compilercopy-node-tree-and-rename");
lf[275]=C_h_intern(&lf[275],9,"alist-ref");
lf[276]=C_h_intern(&lf[276],3,"eq\077");
lf[277]=C_h_intern(&lf[277],1,"f");
lf[278]=C_h_intern(&lf[278],18,"\010compilertree-copy");
lf[279]=C_h_intern(&lf[279],4,"cons");
lf[280]=C_h_intern(&lf[280],19,"\010compilercopy-node!");
lf[281]=C_h_intern(&lf[281],20,"\010compilernode->sexpr");
lf[282]=C_h_intern(&lf[282],20,"\010compilersexpr->node");
lf[283]=C_h_intern(&lf[283],32,"\010compileremit-global-inline-file");
lf[284]=C_h_intern(&lf[284],5,"print");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[286]=C_h_intern(&lf[286],1,"i");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[289]=C_h_intern(&lf[289],2,"pp");
lf[290]=C_h_intern(&lf[290],3,"yes");
lf[291]=C_h_intern(&lf[291],2,"no");
lf[292]=C_h_intern(&lf[292],24,"\010compilerinline-max-size");
lf[293]=C_h_intern(&lf[293],15,"\010compilerinline");
lf[294]=C_h_intern(&lf[294],22,"\010compilerinline-global");
lf[295]=C_h_intern(&lf[295],26,"\010compilervariable-visible\077");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[299]=C_h_intern(&lf[299],15,"chicken-version");
lf[300]=C_h_intern(&lf[300],19,"with-output-to-file");
lf[301]=C_h_intern(&lf[301],25,"\010compilerload-inline-file");
lf[302]=C_h_intern(&lf[302],20,"with-input-from-file");
lf[303]=C_h_intern(&lf[303],19,"\010compilermatch-node");
lf[304]=C_h_intern(&lf[304],1,"a");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[306]=C_h_intern(&lf[306],37,"\010compilerexpression-has-side-effects\077");
lf[307]=C_h_intern(&lf[307],24,"foreign-callback-stub-id");
lf[308]=C_h_intern(&lf[308],4,"find");
lf[309]=C_h_intern(&lf[309],22,"foreign-callback-stubs");
lf[310]=C_h_intern(&lf[310],28,"\010compilersimple-lambda-node\077");
lf[311]=C_h_intern(&lf[311],31,"\010compilerdump-undefined-globals");
lf[312]=C_h_intern(&lf[312],28,"\003systoplevel-definition-hook");
lf[313]=C_h_intern(&lf[313],22,"\010compilerhide-variable");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[315]=C_h_intern(&lf[315],36,"\010compilercompute-database-statistics");
lf[316]=C_h_intern(&lf[316],29,"\010compilercurrent-program-size");
lf[317]=C_h_intern(&lf[317],30,"\010compileroriginal-program-size");
lf[318]=C_h_intern(&lf[318],33,"\010compilerprint-program-statistics");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[325]=C_h_intern(&lf[325],1,"s");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[327]=C_h_intern(&lf[327],35,"\010compilerpprint-expressions-to-file");
lf[328]=C_h_intern(&lf[328],17,"close-output-port");
lf[329]=C_h_intern(&lf[329],12,"pretty-print");
lf[330]=C_h_intern(&lf[330],19,"with-output-to-port");
lf[331]=C_h_intern(&lf[331],16,"open-output-file");
lf[332]=C_h_intern(&lf[332],19,"current-output-port");
lf[333]=C_h_intern(&lf[333],27,"\010compilerforeign-type-check");
lf[334]=C_h_intern(&lf[334],4,"char");
lf[335]=C_h_intern(&lf[335],13,"unsigned-char");
lf[336]=C_h_intern(&lf[336],6,"unsafe");
lf[337]=C_h_intern(&lf[337],25,"\003sysforeign-char-argument");
lf[338]=C_h_intern(&lf[338],3,"int");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-fixnum-argument");
lf[340]=C_h_intern(&lf[340],5,"float");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-flonum-argument");
lf[342]=C_h_intern(&lf[342],7,"pointer");
lf[343]=C_h_intern(&lf[343],26,"\003sysforeign-block-argument");
lf[344]=C_h_intern(&lf[344],15,"nonnull-pointer");
lf[345]=C_h_intern(&lf[345],8,"u8vector");
lf[346]=C_h_intern(&lf[346],34,"\003sysforeign-number-vector-argument");
lf[347]=C_h_intern(&lf[347],16,"nonnull-u8vector");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[349]=C_h_intern(&lf[349],7,"integer");
lf[350]=C_h_intern(&lf[350],28,"\003sysforeign-integer-argument");
lf[351]=C_h_intern(&lf[351],16,"unsigned-integer");
lf[352]=C_h_intern(&lf[352],37,"\003sysforeign-unsigned-integer-argument");
lf[353]=C_h_intern(&lf[353],9,"c-pointer");
lf[354]=C_h_intern(&lf[354],28,"\003sysforeign-pointer-argument");
lf[355]=C_h_intern(&lf[355],17,"nonnull-c-pointer");
lf[356]=C_h_intern(&lf[356],8,"c-string");
lf[357]=C_h_intern(&lf[357],17,"\003sysmake-c-string");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-string-argument");
lf[359]=C_h_intern(&lf[359],16,"nonnull-c-string");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],18,"\003syssymbol->string");
lf[362]=C_h_intern(&lf[362],3,"ref");
lf[363]=C_h_intern(&lf[363],8,"instance");
lf[364]=C_h_intern(&lf[364],12,"instance-ref");
lf[365]=C_h_intern(&lf[365],4,"this");
lf[366]=C_h_intern(&lf[366],8,"slot-ref");
lf[367]=C_h_intern(&lf[367],16,"nonnull-instance");
lf[368]=C_h_intern(&lf[368],5,"const");
lf[369]=C_h_intern(&lf[369],4,"enum");
lf[370]=C_h_intern(&lf[370],8,"function");
lf[371]=C_h_intern(&lf[371],27,"\010compilerforeign-type-table");
lf[372]=C_h_intern(&lf[372],17,"nonnull-c-string*");
lf[373]=C_h_intern(&lf[373],26,"nonnull-unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],9,"c-string*");
lf[375]=C_h_intern(&lf[375],18,"unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],13,"c-string-list");
lf[377]=C_h_intern(&lf[377],14,"c-string-list*");
lf[378]=C_h_intern(&lf[378],18,"unsigned-integer32");
lf[379]=C_h_intern(&lf[379],13,"unsigned-long");
lf[380]=C_h_intern(&lf[380],4,"long");
lf[381]=C_h_intern(&lf[381],9,"integer32");
lf[382]=C_h_intern(&lf[382],17,"nonnull-u16vector");
lf[383]=C_h_intern(&lf[383],16,"nonnull-s8vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s16vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-u32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-f32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f64vector");
lf[389]=C_h_intern(&lf[389],9,"u16vector");
lf[390]=C_h_intern(&lf[390],8,"s8vector");
lf[391]=C_h_intern(&lf[391],9,"s16vector");
lf[392]=C_h_intern(&lf[392],9,"u32vector");
lf[393]=C_h_intern(&lf[393],9,"s32vector");
lf[394]=C_h_intern(&lf[394],9,"f32vector");
lf[395]=C_h_intern(&lf[395],9,"f64vector");
lf[396]=C_h_intern(&lf[396],22,"nonnull-scheme-pointer");
lf[397]=C_h_intern(&lf[397],12,"nonnull-blob");
lf[398]=C_h_intern(&lf[398],19,"nonnull-byte-vector");
lf[399]=C_h_intern(&lf[399],11,"byte-vector");
lf[400]=C_h_intern(&lf[400],4,"blob");
lf[401]=C_h_intern(&lf[401],14,"scheme-pointer");
lf[402]=C_h_intern(&lf[402],6,"double");
lf[403]=C_h_intern(&lf[403],6,"number");
lf[404]=C_h_intern(&lf[404],12,"unsigned-int");
lf[405]=C_h_intern(&lf[405],5,"short");
lf[406]=C_h_intern(&lf[406],14,"unsigned-short");
lf[407]=C_h_intern(&lf[407],4,"byte");
lf[408]=C_h_intern(&lf[408],13,"unsigned-byte");
lf[409]=C_h_intern(&lf[409],5,"int32");
lf[410]=C_h_intern(&lf[410],14,"unsigned-int32");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[412]=C_h_intern(&lf[412],36,"\010compilerforeign-type-convert-result");
lf[413]=C_h_intern(&lf[413],38,"\010compilerforeign-type-convert-argument");
lf[414]=C_h_intern(&lf[414],27,"\010compilerfinal-foreign-type");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[416]=C_h_intern(&lf[416],37,"\010compilerestimate-foreign-result-size");
lf[417]=C_h_intern(&lf[417],9,"integer64");
lf[418]=C_h_intern(&lf[418],4,"bool");
lf[419]=C_h_intern(&lf[419],4,"void");
lf[420]=C_h_intern(&lf[420],13,"scheme-object");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[422]=C_h_intern(&lf[422],46,"\010compilerestimate-foreign-result-location-size");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[425]=C_h_intern(&lf[425],30,"\010compilerfinish-foreign-result");
lf[426]=C_h_intern(&lf[426],17,"\003syspeek-c-string");
lf[427]=C_h_intern(&lf[427],25,"\003syspeek-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],26,"\003syspeek-and-free-c-string");
lf[429]=C_h_intern(&lf[429],34,"\003syspeek-and-free-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],17,"\003sysintern-symbol");
lf[431]=C_h_intern(&lf[431],22,"\003syspeek-c-string-list");
lf[432]=C_h_intern(&lf[432],31,"\003syspeek-and-free-c-string-list");
lf[433]=C_h_intern(&lf[433],35,"\010tinyclosmake-instance-from-pointer");
lf[434]=C_h_intern(&lf[434],4,"make");
lf[435]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[436]=C_h_intern(&lf[436],28,"\010compilerscan-used-variables");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-free-variables");
lf[438]=C_h_intern(&lf[438],11,"lset-adjoin");
lf[439]=C_h_intern(&lf[439],25,"\010compilertopological-sort");
lf[440]=C_h_intern(&lf[440],7,"colored");
lf[441]=C_h_intern(&lf[441],23,"\010compilerchop-separator");
lf[442]=C_h_intern(&lf[442],9,"substring");
lf[443]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[444]=C_h_intern(&lf[444],23,"\010compilerchop-extension");
lf[445]=C_h_intern(&lf[445],22,"\010compilerprint-version");
lf[446]=C_h_intern(&lf[446],6,"print*");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000:(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[448]=C_h_intern(&lf[448],20,"\010compilerprint-usage");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\022\330Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012    -quiet               "
"       do not display compile information\012\012  File and pathname options:\012\012    -ou"
"tput-file FILENAME       specifies output-filename, default is \047out.c\047\012    -incl"
"ude-path PATHNAME      specifies alternative path for included files\012    -to-std"
"out                  write compiled file to stdout instead of file\012\012  Language o"
"ptions:\012\012    -feature SYMBOL             register feature identifier\012\012  Syntax r"
"elated options:\012\012    -case-insensitive           don\047t preserve case of read sym"
"bols\012    -keyword-style STYLE        allow alternative keyword syntax (none, pre"
"fix or suffix)\012    -compile-syntax             macros are made available at run-"
"time\012    -emit-import-library MODULE write compile-time module information into "
"separate file\012\012  Translation options:\012\012    -explicit-use               do not us"
"e units \047library\047 and \047eval\047 by default\012    -check-syntax               stop com"
"pilation after macro-expansion\012    -analyze-only               stop compilation "
"after first analysis pass\012\012  Debugging options:\012\012    -no-warnings               "
" disable warnings\012    -disable-warning CLASS      disable specific class of warn"
"ings\012    -debug-level NUMBER         set level of available debugging informatio"
"n\012    -no-trace                   disable tracing information\012    -profile      "
"              executable emits profiling information \012    -profile-name FILENAME"
"      name of the generated profile information file\012    -accumulate-profile    "
"     executable emits profiling information in append mode\012    -no-lambda-info  "
"           omit additional procedure-information\012\012  Optimization options:\012\012    -"
"optimize-level NUMBER      enable certain sets of optimization options\012    -opti"
"mize-leaf-routines     enable leaf routine optimization\012    -lambda-lift        "
"        enable lambda-lifting\012    -no-usual-integrations      standard procedure"
"s may be redefined\012    -unsafe                     disable safety checks\012    -lo"
"cal                      assume globals are only modified in current file\012    -b"
"lock                      enable block-compilation\012    -disable-interrupts      "
"   disable interrupts in compiled code\012    -fixnum-arithmetic          assume al"
"l numbers are fixnums\012    -benchmark-mode             equivalent to \047-block -opt"
"imize-level 4\012                                 -debug-level 0 -fixnum-arithmetic"
" -lambda-lift \012                                 -disable-interrupts -inline\047\012   "
" -disable-stack-overflow-checks  \012                                disables detec"
"tion of stack-overflows.\012    -inline                     enable inlining\012    -in"
"line-limit               set inlining threshold\012    -inline-global              "
"enable cross-module inlining\012    -emit-inline-file FILENAME  generate file with "
"globally inlinable procedures\012                                (implies -inline -"
"local)\012\012  Configuration options:\012\012    -unit NAME                  compile file a"
"s a library unit\012    -uses NAME                  declare library unit as used.\012 "
"   -heap-size NUMBER           specifies heap-size of compiled executable\012    -h"
"eap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-growth P"
"ERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage PERCEN"
"TAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER\012    -stack-s"
"ize NUMBER          specifies nursery size of compiled executable\012    -extend FI"
"LENAME            load file before compilation commences\012    -prelude EXPRESSION"
"         add expression to front of source file\012    -postlude EXPRESSION        "
"add expression to end of source file\012    -prologue FILENAME          include fil"
"e before main source file\012    -epilogue FILENAME          include file after mai"
"n source file\012    -dynamic                    compile as dynamically loadable co"
"de\012    -require-extension NAME     require and import extension NAME\012    -extens"
"ion                  compile as extension (dynamic or static)\012\012  Obscure options"
":\012\012    -debug MODES                display debugging output for the given modes\012"
"    -unsafe-libraries           marks the generated file as being linked\012       "
"                         with the unsafe runtime system\012    -raw                "
"        do not generate implicit init- and exit code\011\011\011       \012    -emit-externa"
"l-prototypes-first  emit protoypes for callbacks before foreign\012                "
"                declarations\012");
lf[450]=C_h_intern(&lf[450],36,"\010compilermake-block-variable-literal");
lf[451]=C_h_intern(&lf[451],22,"block-variable-literal");
lf[452]=C_h_intern(&lf[452],32,"\010compilerblock-variable-literal\077");
lf[453]=C_h_intern(&lf[453],36,"\010compilerblock-variable-literal-name");
lf[454]=C_h_intern(&lf[454],25,"\010compilermake-random-name");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[456]=C_h_intern(&lf[456],6,"random");
lf[457]=C_h_intern(&lf[457],15,"current-seconds");
lf[458]=C_h_intern(&lf[458],23,"\010compilerset-real-name!");
lf[459]=C_h_intern(&lf[459],24,"\010compilerreal-name-table");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[461]=C_h_intern(&lf[461],19,"\010compilerreal-name2");
lf[462]=C_h_intern(&lf[462],32,"\010compilerdisplay-real-name-table");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[464]=C_h_intern(&lf[464],28,"\010compilersource-info->string");
lf[465]=C_h_intern(&lf[465],4,"conc");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[468]=C_h_intern(&lf[468],11,"make-string");
lf[469]=C_h_intern(&lf[469],3,"max");
lf[470]=C_h_intern(&lf[470],12,"string-null\077");
lf[471]=C_h_intern(&lf[471],19,"\010compilerdump-nodes");
lf[472]=C_h_intern(&lf[472],19,"\003syswrite-char/port");
lf[473]=C_h_intern(&lf[473],19,"\003sysstandard-output");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[477]=C_h_intern(&lf[477],18,"\003sysuser-read-hook");
lf[478]=C_h_intern(&lf[478],15,"foreign-declare");
lf[479]=C_h_intern(&lf[479],7,"declare");
lf[480]=C_h_intern(&lf[480],34,"\010compilerscan-sharp-greater-string");
lf[481]=C_h_intern(&lf[481],18,"\003sysread-char/port");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[483]=C_h_intern(&lf[483],17,"get-output-string");
lf[484]=C_h_intern(&lf[484],18,"open-output-string");
lf[485]=C_h_intern(&lf[485],35,"\010compilerprocess-custom-declaration");
lf[486]=C_h_intern(&lf[486],29,"\010compilercustom-declare-alist");
lf[487]=C_h_intern(&lf[487],31,"\010compileremit-control-file-item");
lf[488]=C_h_intern(&lf[488],25,"\010compilercsc-control-file");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\004~S~%");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\006#%csc\012");
lf[491]=C_h_intern(&lf[491],26,"pathname-replace-extension");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[493]=C_h_intern(&lf[493],19,"\010compilervisibility");
lf[494]=C_h_intern(&lf[494],6,"hidden");
lf[495]=C_h_intern(&lf[495],24,"\010compilerexport-variable");
lf[496]=C_h_intern(&lf[496],8,"exported");
lf[497]=C_h_intern(&lf[497],26,"\010compilerblock-compilation");
lf[498]=C_h_intern(&lf[498],22,"\010compilermark-variable");
lf[499]=C_h_intern(&lf[499],22,"\010compilervariable-mark");
lf[500]=C_h_intern(&lf[500],19,"\010compilerintrinsic\077");
lf[501]=C_h_intern(&lf[501],27,"condition-property-accessor");
lf[502]=C_h_intern(&lf[502],3,"exn");
lf[503]=C_h_intern(&lf[503],7,"message");
lf[504]=C_h_intern(&lf[504],19,"condition-predicate");
C_register_lf2(lf,505,create_ptable());
t2=C_mutate(&lf[0] /* (set! c655 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3865,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3863 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3866 in k3863 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3869 in k3866 in k3863 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3884,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3889,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3916,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[20]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3956,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3985,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[28]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4004,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[34]+1 /* (set! syntax-error ...) */,C_retrieve(lf[28]));
t11=C_mutate((C_word*)lf[35]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4029,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[36]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4032,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[37]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4075,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[40]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4143,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4179,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[45]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4200,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[48]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4225,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[49]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[50]));
t19=C_mutate((C_word*)lf[51]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4269,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[60]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4363,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[63]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4419,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[64]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4426,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[65]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4433,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[72]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4480,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[75]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4492,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[77]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4555,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4586,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4606,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[83]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4652,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[84]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4682,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[86]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4728,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[89]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4788,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 287  condition-predicate */
t34=C_retrieve(lf[504]);
((C_proc3)C_retrieve_proc(t34))(3,t34,t33,lf[502]);}

/* k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 288  condition-property-accessor */
t3=C_retrieve(lf[501]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[502],lf[503]);}

/* k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word ab[169],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[108]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[109]));
t4=C_mutate((C_word*)lf[110]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4996,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4999,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_TRUE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[121]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5140,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[135]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5249,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[137]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5267,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[123]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5285,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[140]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5331,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[141]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5383,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[142]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5440,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[144]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5450,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[145]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5486,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[147]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5510,tmp=(C_word)a,a+=2,tmp));
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_mutate((C_word*)lf[152]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5529,a[2]=t19,tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6019,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[206]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6025,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[207]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6031,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[209]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6040,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[210]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6049,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[211]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6058,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[212]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6067,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[213]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6076,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6085,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[214]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6091,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[216]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6106,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[217]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6121,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[253]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6730,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[267]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7063,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[269]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7117,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[274]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7230,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[278]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7451,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[280]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7485,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[281]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7562,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[282]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7613,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[283]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7646,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[301]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7848,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[303]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7917,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[306]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8137,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[310]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8238,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[311]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8360,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[312]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8391,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[315]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8412,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[318]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8498,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[327]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8537,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[333]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8573,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[412]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9620,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[413]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9651,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[414]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9682,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[416]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9722,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[422]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10041,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[425]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10351,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[436]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10643,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[437]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10736,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[439]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10923,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[441]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11120,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[444]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11149,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[445]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11191,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[448]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11229,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[450]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11241,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[452]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11247,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[453]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11253,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[454]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11262,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[458]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11306,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[39]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11312,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[461]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11391,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[462]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11403,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[464]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11415,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[470]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11461,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[471]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11467,tmp=(C_word)a,a+=2,tmp));
t76=C_retrieve(lf[477]);
t77=C_mutate((C_word*)lf[477]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11569,a[2]=t76,tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[480]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11602,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[485]+1 /* (set! process-custom-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11671,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[487]+1 /* (set! emit-control-file-item ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11734,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[85]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11763,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[313]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11787,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[495]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11820,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[295]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11853,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[498]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11874,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[499]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11902,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[500]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11908,tmp=(C_word)a,a+=2,tmp));
t88=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t88+1)))(2,t88,C_SCHEME_UNDEFINED);}

/* ##compiler#intrinsic? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11908,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11913,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[127]);}

/* f_11913 in ##compiler#intrinsic? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11913,4,t0,t1,t2,t3);}
/* ##sys#get */
t4=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* ##compiler#variable-mark in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11902,4,t0,t1,t2,t3);}
/* support.scm: 1508 ##sys#get */
t4=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* ##compiler#mark-variable in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11874r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11874r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11878,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11878(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11878(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11876 in ##compiler#mark-variable in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1505 ##sys#put! */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11853,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11857,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1498 ##sys#get */
t4=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[493]);}

/* k11855 in ##compiler#variable-visible? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[494]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[496]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[497]))));}}

/* ##compiler#export-variable in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11820,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11825,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[493],lf[496]);}

/* f_11825 in ##compiler#export-variable in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11825r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11825r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11825r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11829,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11829(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11829(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11827 */
static void C_ccall f_11829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#hide-variable in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11787,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11792,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[493],lf[494]);}

/* f_11792 in ##compiler#hide-variable in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11792r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11792r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11792r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11796,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11796(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11796(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11794 */
static void C_ccall f_11796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#big-fixnum? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11763,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#emit-control-file-item in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11734,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11738,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[488]))){
t4=t3;
f_11738(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11745,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11761,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1470 pathname-replace-extension */
t6=C_retrieve(lf[491]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[242]),lf[492]);}}

/* k11759 in ##compiler#emit-control-file-item in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1470 open-output-file */
t2=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k11743 in ##compiler#emit-control-file-item in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11745,2,t0,t1);}
t2=C_mutate((C_word*)lf[488]+1 /* (set! csc-control-file ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1471 display */
t4=*((C_word*)lf[17]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[490],C_retrieve(lf[488]));}

/* k11746 in k11743 in ##compiler#emit-control-file-item in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11748,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11750,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
f_11738(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k11746 in k11743 in ##compiler#emit-control-file-item in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11754,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1475 close-output-port */
t3=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[488]));}

/* k11752 in ##compiler#compiler-cleanup-hook in k11746 in k11743 in ##compiler#emit-control-file-item in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1476 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k11736 in ##compiler#emit-control-file-item in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1477 fprintf */
t2=C_retrieve(lf[21]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[488]),lf[489],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11671,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[486]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11693,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_11693(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11708,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1457 open-output-file */
t14=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k11706 in ##compiler#process-custom-declaration in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11708,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[486]));
t5=C_mutate((C_word*)lf[486]+1 /* (set! custom-declare-alist ...) */,t4);
t6=C_retrieve(lf[2]);
t7=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11718,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11732,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1465 cons* */
t9=C_retrieve(lf[259]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11730 in k11706 in ##compiler#process-custom-declaration in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1465 emit-control-file-item */
t2=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_11718 in k11706 in ##compiler#process-custom-declaration in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11722,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1463 close-output-port */
t3=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k11720 */
static void C_ccall f_11722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1464 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k11691 in ##compiler#process-custom-declaration in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11693,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[17]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11701,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a11697 in k11691 in ##compiler#process-custom-declaration in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11701,3,t0,t1,t2);}
/* g360936103616 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11602,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11606,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1427 open-output-string */
t4=C_retrieve(lf[484]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11606,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11611,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11611(t5,((C_word*)t0)[2]);}

/* loop in k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11611,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11613 in loop in k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11615,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1430 quit */
t2=C_retrieve(lf[25]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[482]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11633,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1432 newline */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11645,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11666,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11664 in k11613 in loop in k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1444 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11611(t2,((C_word*)t0)[2]);}

/* k11643 in k11613 in loop in k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11645,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1437 get-output-string */
t3=C_retrieve(lf[483]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11657,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11655 in k11643 in k11613 in loop in k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11660,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11658 in k11655 in k11643 in k11613 in loop in k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1441 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11611(t2,((C_word*)t0)[2]);}

/* k11631 in k11613 in loop in k11604 in ##compiler#scan-sharp-greater-string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1433 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11611(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11569,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11579,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1424 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k11577 in ##sys#user-read-hook in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11582,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1422 scan-sharp-greater-string */
t3=C_retrieve(lf[480]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k11580 in k11577 in ##sys#user-read-hook in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11582,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[478],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[479],t4));}

/* ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11467,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11471,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11476,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11476(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11476(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11476,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11480,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11563,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_11563 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11563,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11483,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11558,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_11558 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11558,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11486,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11553,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11553 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11553,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1400 make-string */
t3=*((C_word*)lf[468]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_make_character(32));}

/* k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11489,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11495,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1402 printf */
t4=C_retrieve(lf[13]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[476],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11498,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11547 in k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11548,3,t0,t1,t2);}
/* loop3482 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11476(t3,t1,((C_word*)t0)[2],t2);}

/* k11496 in k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11498,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11513,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1406 printf */
t6=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[475],t5);}
else{
t4=t3;
f_11504(2,t4,C_SCHEME_UNDEFINED);}}

/* k11511 in k11496 in k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11516,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11521,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11521(t6,t2,C_fix(5));}

/* doloop3512 in k11511 in k11496 in k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11521,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11531,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1409 printf */
t5=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[474],t4);}}

/* k11529 in doloop3512 in k11511 in k11496 in k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11521(t3,((C_word*)t0)[2],t2);}

/* k11514 in k11511 in k11496 in k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[473]+1));}

/* k11502 in k11496 in k11493 in k11487 in k11484 in k11481 in k11478 in loop in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[472]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[473]+1));}

/* k11469 in ##compiler#dump-nodes in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1412 newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11461,3,t0,t1,t2);}
/* support.scm: 1390 string-null? */
t3=C_retrieve(lf[470]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#source-info->string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11415,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11434,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1383 ->string */
t7=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1385 ->string */
t3=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11432 in ##compiler#source-info->string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11441,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11445,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1384 max */
t6=*((C_word*)lf[469]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k11443 in k11432 in ##compiler#source-info->string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1384 make-string */
t2=*((C_word*)lf[468]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k11439 in k11432 in ##compiler#source-info->string in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1384 conc */
t2=C_retrieve(lf[465]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[466],((C_word*)t0)[3],t1,lf[467],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11409,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1373 ##sys#hash-table-for-each */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[459]));}

/* a11408 in ##compiler#display-real-name-table in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11409,4,t0,t1,t2,t3);}
/* support.scm: 1375 printf */
t4=C_retrieve(lf[13]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[463],t2,t3);}

/* ##compiler#real-name2 in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11391,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11395,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1369 ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[459]),t2);}

/* k11393 in ##compiler#real-name2 in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1370 real-name */
t2=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11312(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11312r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11312r(t0,t1,t2,t3);}}

static void C_ccall f_11312r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11315,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11331,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1353 resolve */
f_11315(t5,t2);}

/* k11329 in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11331,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1357 ##sys#symbol->qualified-string */
t5=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
/* support.scm: 1366 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1354 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11354 in k11329 in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11360,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1358 get */
t3=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[146]);}

/* k11358 in k11354 in k11329 in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11360,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11362,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11362(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11358 in k11354 in k11329 in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11362(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11362,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1360 resolve */
f_11315(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11367 in loop in k11358 in k11354 in k11329 in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11369,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11382,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1363 sprintf */
t4=C_retrieve(lf[43]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[460],((C_word*)t0)[4],t1);}}

/* k11380 in k11367 in loop in k11358 in k11354 in k11329 in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11386,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1364 get */
t3=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[146]);}

/* k11384 in k11380 in k11367 in loop in k11358 in k11354 in k11329 in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1363 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11362(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11315(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11315,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11319,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1348 ##sys#hash-table-ref */
t4=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[459]),t2);}

/* k11317 in resolve in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11319,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11325,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1350 ##sys#hash-table-ref */
t3=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[459]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11323 in k11317 in resolve in ##compiler#real-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11306,4,t0,t1,t2,t3);}
/* support.scm: 1344 ##sys#hash-table-set! */
t4=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[459]),t2,t3);}

/* ##compiler#make-random-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11262(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_11262r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11262r(t0,t1,t2);}}

static void C_ccall f_11262r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11270,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11274,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1331 gensym */
t5=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11274(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k11272 in ##compiler#make-random-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11278,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1332 current-seconds */
t3=C_retrieve(lf[457]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11276 in k11272 in ##compiler#make-random-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11282,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1333 random */
t3=C_retrieve(lf[456]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k11280 in k11276 in k11272 in ##compiler#make-random-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1330 sprintf */
t2=C_retrieve(lf[43]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[455],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11268 in ##compiler#make-random-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1329 string->symbol */
t2=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11253,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[451]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11247,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[451]));}

/* ##compiler#make-block-variable-literal in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11241,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[451],t2));}

/* ##compiler#print-usage in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1214 print-version */
t3=C_retrieve(lf[445]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11231 in ##compiler#print-usage in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1215 newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11234 in k11231 in ##compiler#print-usage in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1216 display */
t2=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[449]);}

/* ##compiler#print-version in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11191(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_11191r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11191r(t0,t1,t2);}}

static void C_ccall f_11191r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11195,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_11195(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_11195(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k11193 in ##compiler#print-version in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1210 print* */
t3=*((C_word*)lf[446]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[447]);}
else{
t3=t2;
f_11198(2,t3,C_SCHEME_UNDEFINED);}}

/* k11196 in k11193 in ##compiler#print-version in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11205,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1211 chicken-version */
t3=C_retrieve(lf[299]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k11203 in k11196 in k11193 in ##compiler#print-version in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1211 print */
t2=*((C_word*)lf[284]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11149,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11158,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11158(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11158,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1203 substring */
t6=*((C_word*)lf[442]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1204 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11120,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11130,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_11130(t7,(C_word)C_i_memq(t6,lf[443]));}
else{
t6=t5;
f_11130(t6,C_SCHEME_FALSE);}}

/* k11128 in ##compiler#chop-separator in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1196 substring */
t2=*((C_word*)lf[442]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10923,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10932,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10979,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11014,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11051,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11102,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a11101 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11102,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1178 insert */
t5=((C_word*)t0)[2];
f_10932(t5,t1,t3,t4);}

/* k11049 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11096,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1181 caar */
t4=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k11094 in k11049 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11100,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1181 cdar */
t3=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k11098 in k11094 in k11049 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1181 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11014(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11052 in k11049 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11057,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a11058 in k11052 in k11049 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11059,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11063,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1183 lookup */
t5=((C_word*)t0)[2];
f_10979(t5,t3,t4);}

/* k11061 in a11058 in k11052 in k11049 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[440]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1185 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11014(t5,((C_word*)t0)[4],t3,t4);}}

/* k11055 in k11052 in k11049 in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_11014(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11014,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11018,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1166 insert */
t5=((C_word*)t0)[2];
f_10932(t5,t4,t2,lf[440]);}

/* k11016 in visit in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11021,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11026 in k11016 in visit in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11027,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11031,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1169 lookup */
t4=((C_word*)t0)[2];
f_10979(t4,t3,t2);}

/* k11029 in a11026 in k11016 in visit in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[440]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1171 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11014(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k11019 in k11016 in visit in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11021,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10979(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10979,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10985,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10985(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10985,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11012,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1161 caar */
t5=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k11010 in loop in lookup in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_11012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1161 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10996 in loop in lookup in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1161 cdar */
t2=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1162 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10985(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10932(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10932,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10938,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10938(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10938(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10938,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10977,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1155 caar */
t5=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k10975 in loop in insert in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1155 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10957 in loop in insert in ##compiler#topological-sort in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1156 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10938(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10736,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10739,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10905,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10918,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1138 walk */
t14=((C_word*)t8)[1];
f_10739(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10916 in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1139 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10905(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10905,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10911,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10910 in walkeach in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10911,3,t0,t1,t2);}
/* support.scm: 1136 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10739(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10739(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10739,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10743,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10899,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10899 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10899,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10894,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10894 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10894,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10889,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10889 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10889,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10749,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[82]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_10758(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[221]);
if(C_truep(t4)){
t5=t3;
f_10758(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[229]);
if(C_truep(t5)){
t6=t3;
f_10758(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[232]);
t7=t3;
f_10758(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[246])));}}}}

/* k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10758,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[215]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10777,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1118 lset-adjoin */
t5=C_retrieve(lf[438]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[233]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10799(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10813,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1123 lset-adjoin */
t7=C_retrieve(lf[438]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[92]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10822,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1126 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10739(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[228]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10852,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1129 decompose-lambda-list */
t8=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1133 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10905(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10851 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10852,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10864,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1132 append */
t7=*((C_word*)lf[54]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10862 in a10851 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1132 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10739(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10820 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10822,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10833,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1127 append */
t4=*((C_word*)lf[54]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10831 in k10820 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1127 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10739(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10811 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10799(t3,t2);}

/* k10797 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1124 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10739(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10775 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10777,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1119 variable-visible? */
t4=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k10781 in k10775 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10783,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10787,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1120 lset-adjoin */
t3=C_retrieve(lf[438]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10785 in k10781 in k10775 in k10756 in k10747 in k10744 in k10741 in walk in ##compiler#scan-free-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10643,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10647,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10649,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10649(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10649,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10653,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10730,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10730 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10730,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10725,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10725 in k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10725,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10654 in k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10656,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[215]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[233]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10696,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10709,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_10709(t6,t4);}
else{
t6=(C_word)C_eqp(t1,lf[221]);
t7=t5;
f_10709(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[229])));}}}

/* k10707 in k10654 in k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* f_10696 in k10654 in k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10696,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10693 in k10654 in k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10695,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10671,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10677,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_10677(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_10677(t5,C_SCHEME_FALSE);}}

/* k10675 in k10693 in k10654 in k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10677,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10671(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10671(t2,C_SCHEME_UNDEFINED);}}

/* k10669 in k10693 in k10654 in k10651 in walk in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10645 in ##compiler#scan-used-variables in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10351,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[426],t9));}
else{
t6=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[427],t10));}
else{
t7=(C_word)C_eqp(t4,lf[374]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[82],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[428],t12));}
else{
t9=(C_word)C_eqp(t4,lf[372]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[82],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[429],t14));}
else{
t11=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[82],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[426],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[430],t17));}
else{
t12=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[82],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[431],t16));}
else{
t13=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[82],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[432],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10547,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_10547(t18,(C_word)C_i_memq(t17,lf[435]));}
else{
t17=t14;
f_10547(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_10547(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k10545 in ##compiler#finish-foreign-result in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[433],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_10568(t6,(C_word)C_eqp(lf[367],t5));}
else{
t5=t2;
f_10568(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10568(t3,C_SCHEME_FALSE);}}}

/* k10566 in k10545 in ##compiler#finish-foreign-result in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10568,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[82],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[434],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10041,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10044,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10053,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1042 follow-without-loop */
t6=C_retrieve(lf[77]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a10344 in ##compiler#estimate-foreign-result-location-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10345,2,t0,t1);}
/* support.scm: 1063 quit */
t2=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[424],((C_word*)t0)[2]);}

/* a10052 in ##compiler#estimate-foreign-result-location-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10053,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10063,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_10063(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_10063(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_10063(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_10063(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t10)){
t11=t6;
f_10063(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t11)){
t12=t6;
f_10063(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t12)){
t13=t6;
f_10063(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t13)){
t14=t6;
f_10063(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t14)){
t15=t6;
f_10063(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_10063(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_10063(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t17)){
t18=t6;
f_10063(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t18)){
t19=t6;
f_10063(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t19)){
t20=t6;
f_10063(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t20)){
t21=t6;
f_10063(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t21)){
t22=t6;
f_10063(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t22)){
t23=t6;
f_10063(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t23)){
t24=t6;
f_10063(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_10063(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[401]);
if(C_truep(t25)){
t26=t6;
f_10063(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[396]);
if(C_truep(t26)){
t27=t6;
f_10063(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t27)){
t28=t6;
f_10063(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t28)){
t29=t6;
f_10063(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t29)){
t30=t6;
f_10063(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t30)){
t31=t6;
f_10063(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t31)){
t32=t6;
f_10063(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t32)){
t33=t6;
f_10063(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t33)){
t34=t6;
f_10063(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t34)){
t35=t6;
f_10063(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t35)){
t36=t6;
f_10063(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[376]);
t37=t6;
f_10063(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[377])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k10061 in a10052 in ##compiler#estimate-foreign-result-location-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10063,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[403]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub331(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1055 ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t5=t4;
f_10081(2,t5,C_SCHEME_FALSE);}}}}

/* k10079 in k10061 in a10052 in ##compiler#estimate-foreign-result-location-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10081,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1057 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_10115(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_10115(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_10115(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_10115(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
t9=t4;
f_10115(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[370])));}}}}}
else{
/* support.scm: 1062 err */
f_10044(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k10113 in k10079 in k10061 in a10052 in ##compiler#estimate-foreign-result-location-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1061 err */
f_10044(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_10044(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10044,NULL,2,t1,t2);}
/* support.scm: 1041 quit */
t3=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[423],t2);}

/* ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9722,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9728,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10035,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1012 follow-without-loop */
t5=C_retrieve(lf[77]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a10034 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_10035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10035,2,t0,t1);}
/* support.scm: 1037 quit */
t2=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[421],((C_word*)t0)[2]);}

/* a9727 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9728,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9738,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9738(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9738(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_9738(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_9738(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t10)){
t11=t6;
f_9738(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t11)){
t12=t6;
f_9738(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t12)){
t13=t6;
f_9738(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t13)){
t14=t6;
f_9738(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t14)){
t15=t6;
f_9738(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_9738(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_9738(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[409]);
t18=t6;
f_9738(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[410])));}}}}}}}}}}}}

/* k9736 in a9727 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9738,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9747(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=t3;
f_9747(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t5)){
t6=t3;
f_9747(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_9747(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t7)){
t8=t3;
f_9747(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t8)){
t9=t3;
f_9747(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t9)){
t10=t3;
f_9747(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t10)){
t11=t3;
f_9747(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t11)){
t12=t3;
f_9747(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
t13=t3;
f_9747(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[377])));}}}}}}}}}}}

/* k9745 in k9736 in a9727 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9747(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9747,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9759(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_9759(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t5)){
t6=t3;
f_9759(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t6)){
t7=t3;
f_9759(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t8=t3;
f_9759(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}

/* k9757 in k9745 in k9736 in a9727 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9759,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[340]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9771(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[402]);
if(C_truep(t4)){
t5=t3;
f_9771(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
t6=t3;
f_9771(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[417])));}}}}

/* k9769 in k9757 in k9745 in k9736 in a9727 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9771,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1028 ##sys#hash-table-ref */
t3=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9777(2,t3,C_SCHEME_FALSE);}}}

/* k9775 in k9769 in k9757 in k9745 in k9736 in a9727 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9777,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1030 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9811,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9811(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9811(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_9811(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_9811(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t8)){
t9=t4;
f_9811(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[370]);
if(C_truep(t9)){
t10=t4;
f_9811(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[363]);
if(C_truep(t10)){
t11=t4;
f_9811(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[364]);
t12=t4;
f_9811(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[367])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9809 in k9775 in k9769 in k9757 in k9745 in k9736 in a9727 in ##compiler#estimate-foreign-result-size in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9682,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9688,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9716,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 999  follow-without-loop */
t5=C_retrieve(lf[77]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a9715 in ##compiler#final-foreign-type in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9716,2,t0,t1);}
/* support.scm: 1006 quit */
t2=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[415],((C_word*)t0)[2]);}

/* a9687 in ##compiler#final-foreign-type in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9688,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9692,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1002 ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[371]),t2);}
else{
t5=t4;
f_9692(2,t5,C_SCHEME_FALSE);}}

/* k9690 in a9687 in ##compiler#final-foreign-type in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1004 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9651,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9655,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9664,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 993  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_9655(t5,C_SCHEME_FALSE);}}

/* k9662 in ##compiler#foreign-type-convert-argument in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9664,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9655(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9655(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9655(t2,C_SCHEME_FALSE);}}

/* k9653 in ##compiler#foreign-type-convert-argument in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9620,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9624,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9633,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 986  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_9624(t5,C_SCHEME_FALSE);}}

/* k9631 in ##compiler#foreign-type-convert-result in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9633,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_9624(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9624(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9624(t2,C_SCHEME_FALSE);}}

/* k9622 in ##compiler#foreign-type-convert-result in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8573,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9614,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 887  follow-without-loop */
t6=C_retrieve(lf[77]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a9613 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9614,2,t0,t1);}
/* support.scm: 979  quit */
t2=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[411],((C_word*)t0)[2]);}

/* a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8579,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8585,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8585(t7,t1,t2);}

/* repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8585,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[334]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[335]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[336]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[337],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8614(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[404]);
if(C_truep(t8)){
t9=t7;
f_8614(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t9)){
t10=t7;
f_8614(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t10)){
t11=t7;
f_8614(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t11)){
t12=t7;
f_8614(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t12)){
t13=t7;
f_8614(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[409]);
t14=t7;
f_8614(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[410])));}}}}}}}}

/* k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8614,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[339],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8633(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
t5=t3;
f_8633(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[403])));}}}

/* k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8633,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[341],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8652(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
if(C_truep(t4)){
t5=t3;
f_8652(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t6=t3;
f_8652(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[401])));}}}}

/* k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8652,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8655,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 897  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8722(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
if(C_truep(t4)){
t5=t3;
f_8722(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
t6=t3;
f_8722(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[398])));}}}}

/* k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8722,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[343],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8741(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t4)){
t5=t3;
f_8741(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t5)){
t6=t3;
f_8741(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t6)){
t7=t3;
f_8741(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t7)){
t8=t3;
f_8741(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t8)){
t9=t3;
f_8741(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
t10=t3;
f_8741(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[395])));}}}}}}}}

/* k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8741,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 909  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8823(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_8823(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t5)){
t6=t3;
f_8823(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t6)){
t7=t3;
f_8823(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t7)){
t8=t3;
f_8823(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t8)){
t9=t3;
f_8823(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
t10=t3;
f_8823(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[388])));}}}}}}}}

/* k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8823,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[348]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[82],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[346],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8862(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
t5=t3;
f_8862(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[381])));}}}

/* k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8862,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[350],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8881(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_8881(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8881,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[352],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8900(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_8900(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8900,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8903,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 929  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[354],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8980(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t6=t4;
f_8980(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}}

/* k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8980,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8983,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 937  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9065(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t5=t3;
f_9065(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}

/* k9063 in k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9065,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[357],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[358],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[357],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[336]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[357],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[358],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[357],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 953  ##sys#hash-table-ref */
t4=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t4=t3;
f_9140(2,t4,C_SCHEME_FALSE);}}}}

/* k9138 in k9063 in k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 955  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9174(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
t6=t4;
f_9174(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[370]);
t7=t4;
f_9174(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[353])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k9172 in k9138 in k9063 in k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9174,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9177,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 959  gensym */
t3=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[363]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[364]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9244,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 965  gensym */
t5=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[366],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 972  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8585(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[336]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[350],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[344]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[355]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[354],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9242 in k9172 in k9138 in k9063 in k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9244,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[366],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[82],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[220],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[92],t17));}

/* k9175 in k9172 in k9138 in k9063 in k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_9177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9177,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k8981 in k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9014,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_9014(t7,(C_word)C_a_i_cons(&a,2,lf[357],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[358],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_9014(t9,(C_word)C_a_i_cons(&a,2,lf[357],t8));}}

/* k9012 in k8981 in k8978 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_9014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9014,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8901 in k8898 in k8879 in k8860 in k8821 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8903,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k8742 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8775,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8775(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8775(t10,(C_word)C_a_i_cons(&a,2,lf[346],t9));}}

/* k8773 in k8742 in k8739 in k8720 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8775,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8653 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8655,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8686(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8686(t7,(C_word)C_a_i_cons(&a,2,lf[343],t6));}}

/* k8684 in k8653 in k8650 in k8631 in k8612 in repeat in a8578 in ##compiler#foreign-type-check in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8686,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* ##compiler#pprint-expressions-to-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8537,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8541,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 868  open-output-file */
t5=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
/* support.scm: 868  current-output-port */
t5=*((C_word*)lf[332]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8539 in ##compiler#pprint-expressions-to-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8544,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8552,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 869  with-output-to-port */
t4=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a8551 in k8539 in ##compiler#pprint-expressions-to-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8558,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a8557 in a8551 in k8539 in ##compiler#pprint-expressions-to-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8558,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8562,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 873  pretty-print */
t4=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k8560 in a8557 in a8551 in k8539 in ##compiler#pprint-expressions-to-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 874  newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8542 in k8539 in ##compiler#pprint-expressions-to-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 876  close-output-port */
t2=*((C_word*)lf[328]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8498,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8504,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8510,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a8509 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8510,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8517,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 856  debugging */
t10=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[325],lf[326]);}

/* k8515 in a8509 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8517,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8520,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 857  printf */
t3=C_retrieve(lf[13]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[324],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8518 in k8515 in a8509 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 858  printf */
t3=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[323],((C_word*)t0)[2]);}

/* k8521 in k8518 in k8515 in a8509 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 859  printf */
t3=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[322],((C_word*)t0)[2]);}

/* k8524 in k8521 in k8518 in k8515 in a8509 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 860  printf */
t3=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[321],((C_word*)t0)[2]);}

/* k8527 in k8524 in k8521 in k8518 in k8515 in a8509 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 861  printf */
t3=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[320],((C_word*)t0)[2]);}

/* k8530 in k8527 in k8524 in k8521 in k8518 in k8515 in a8509 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 862  printf */
t2=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[319],((C_word*)t0)[2]);}

/* a8503 in ##compiler#print-program-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8504,2,t0,t1);}
/* support.scm: 855  compute-database-statistics */
t2=C_retrieve(lf[315]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8412,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8416,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8421,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 831  ##sys#hash-table-for-each */
t15=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a8420 in ##compiler#compute-database-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8421,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a8426 in a8420 in ##compiler#compute-database-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8427,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[182]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[163]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8469,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cdr(t2);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8474,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t8=(C_word)C_eqp(t5,lf[170]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* f_8474 in a8426 in a8420 in ##compiler#compute-database-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8474,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8467 in a8426 in a8420 in ##compiler#compute-database-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[228],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8414 in ##compiler#compute-database-statistics in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 845  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[316]),C_retrieve(lf[317]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8391,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8401,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 808  debugging */
t8=C_retrieve(lf[10]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[251],lf[314],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k8399 in ##sys#toplevel-definition-hook in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 809  hide-variable */
t2=C_retrieve(lf[313]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8360,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8366,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 794  ##sys#hash-table-for-each */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a8365 in ##compiler#dump-undefined-globals in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8366,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8373,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[182],t3))){
t5=(C_word)C_i_assq(lf[180],t3);
t6=t4;
f_8373(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8373(t5,C_SCHEME_FALSE);}}

/* k8371 in a8365 in ##compiler#dump-undefined-globals in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8373,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8376,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 798  write */
t3=*((C_word*)lf[200]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8374 in k8371 in a8365 in ##compiler#dump-undefined-globals in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 799  newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8242,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8354,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8354 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8354,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8242,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
if(C_truep((C_word)C_i_cadr(t1))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8262,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8262(3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8262,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8266,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8343,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8343 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8343,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8266,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[240]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8320,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(t1,lf[231]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8337,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8338,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}}

/* f_8338 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8338,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8335 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 788  every */
t2=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* f_8320 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8320,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8273 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8275,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8314,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8315,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8315 in k8273 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8315,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8312 in k8273 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8314,2,t0,t1);}
t2=(C_word)C_eqp(lf[215],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8306,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8306 in k8312 in k8273 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8306,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8303 in k8312 in k8273 in k8264 in rec in k8240 in ##compiler#simple-lambda-node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 786  every */
t5=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8137,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8143,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8143(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8143,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8147,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8232,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8232 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8232,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8150,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8227,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_8227 in k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8227,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8148 in k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8150,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[215]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8159(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
if(C_truep(t4)){
t5=t3;
f_8159(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[221]);
if(C_truep(t5)){
t6=t3;
f_8159(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[232]);
t7=t3;
f_8159(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[219])));}}}}

/* k8157 in k8148 in k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8159,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8185,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8186,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[220]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[92]));
if(C_truep(t4)){
/* support.scm: 770  any */
t5=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* f_8186 in k8157 in k8148 in k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8186,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8183 in k8157 in k8148 in k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8185,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8173,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 769  find */
t4=C_retrieve(lf[308]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t3,C_retrieve(lf[309]));}

/* a8172 in k8183 in k8157 in k8148 in k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8173,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8181,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 769  foreign-callback-stub-id */
t4=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k8179 in a8172 in k8183 in k8157 in k8148 in k8145 in walk in ##compiler#expression-has-side-effects? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7917,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7920,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7949,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7992,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8111,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 753  matchn */
t15=((C_word*)t12)[1];
f_7992(t15,t14,t2,t3);}

/* k8109 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8111,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8117,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8131,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8131 in k8109 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8131,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8119 in k8109 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8125,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8126,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8126 in k8119 in k8109 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8126,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8123 in k8119 in k8109 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 756  debugging */
t2=C_retrieve(lf[10]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[304],lf[305],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8115 in k8109 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7992,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 742  resolve */
t4=((C_word*)t0)[4];
f_7920(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8104,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* f_8104 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8104,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8099,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8086,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8091,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_8091 in k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8091,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8084 in k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* support.scm: 744  match1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7949(t3,((C_word*)t0)[2],t1,t2);}

/* k8012 in k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8014,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8078,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8078 in k8012 in k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8078,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8019 in k8012 in k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8021,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8027,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8027(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8019 in k8012 in k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_8027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8027,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 748  resolve */
t4=((C_word*)t0)[4];
f_7920(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8058,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 750  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7992(t7,t4,t5,t6);}}}}

/* k8056 in loop in k8019 in k8012 in k8097 in matchn in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 751  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8027(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7949(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7949,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 735  resolve */
t4=((C_word*)t0)[3];
f_7920(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7971,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 737  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7969 in match1 in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 737  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7949(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7920(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7920,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7944,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 730  alist-cons */
t6=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7942 in resolve in ##compiler#match-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7848,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7854,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 710  with-input-from-file */
t4=C_retrieve(lf[302]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a7853 in ##compiler#load-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7860,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7860(t5,t1);}

/* loop in a7853 in ##compiler#load-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7860,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7864,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 713  read */
t3=*((C_word*)lf[101]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7862 in loop in a7853 in ##compiler#load-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7864,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7884,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 718  sexpr->node */
t6=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k7882 in k7862 in loop in a7853 in ##compiler#load-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7885,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[294],t1);}

/* f_7885 in k7882 in k7862 in loop in a7853 in ##compiler#load-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_7885r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7885r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7885r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7889,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7889(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7889(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k7887 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7871 in k7862 in loop in a7853 in ##compiler#load-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 719  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7860(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7646,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7650,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7677,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 679  with-output-to-file */
t8=C_retrieve(lf[300]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t2,t7);}

/* a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 681  chicken-version */
t4=C_retrieve(lf[299]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7844 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 681  print */
t2=*((C_word*)lf[284]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[2],lf[296],t1,lf[297],C_retrieve(lf[242]),lf[298]);}

/* k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7684,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 683  ##sys#hash-table-for-each */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7689,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 685  variable-visible? */
t5=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[165],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7832,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7838,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],lf[294]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_7838 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7838,4,t0,t1,t2,t3);}
/* ##sys#get */
t4=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* k7830 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7833,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_7833 in k7830 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7833,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[205]));}

/* k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7828,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[163],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7720(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[158],t5);
t7=t4;
f_7720(t7,(C_word)C_i_not(t6));}}}

/* k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7720,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[192],((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7809,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7809 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7809,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7729,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(t1);
/* support.scm: 693  get */
t4=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],t3,lf[191]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7736 in k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 694  get */
t3=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[199]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7798 in k7736 in k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7800,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7792,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[293]);}}

/* f_7792 in k7798 in k7736 in k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7792,4,t0,t1,t2,t3);}
/* ##sys#get */
t4=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* k7748 in k7798 in k7736 in k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[290]);
if(C_truep(t3)){
t4=t2;
f_7753(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[291]);
if(C_truep(t4)){
t5=t2;
f_7753(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[292]);
t7=t2;
f_7753(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7751 in k7748 in k7798 in k7736 in k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7753,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7760,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7771,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 701  node->sexpr */
t7=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7769 in k7751 in k7748 in k7798 in k7736 in k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7771,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 701  pp */
t3=C_retrieve(lf[289]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k7758 in k7751 in k7748 in k7798 in k7736 in k7727 in k7718 in k7826 in k7694 in a7688 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 702  newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k7682 in k7679 in a7676 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 704  print */
t2=*((C_word*)lf[284]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[288]);}

/* k7648 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 706  debugging */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[286],lf[287]);}
else{
t3=t2;
f_7656(2,t3,C_SCHEME_FALSE);}}

/* k7654 in k7648 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7656,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7661,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7669,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 707  sort-symbols */
t4=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7667 in k7654 in k7648 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7660 in k7654 in k7648 in ##compiler#emit-global-inline-file in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7661,3,t0,t1,t2);}
/* print */
t3=*((C_word*)lf[284]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[285],t2);}

/* ##compiler#sexpr->node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7613,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7619,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7619(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7619,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7635,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k7633 in walk in ##compiler#sexpr->node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7636,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7636 in k7633 in walk in ##compiler#sexpr->node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7636,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7562,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7568,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7568(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7568,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7576,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7607,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7607 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7607,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7574 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7602,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7602 in k7574 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7602,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7582 in k7574 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7596,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7597,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_7597 in k7582 in k7574 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7597,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7594 in k7582 in k7574 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k7590 in k7582 in k7574 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7586 in k7582 in k7574 in walk in ##compiler#node->sexpr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7588,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7485,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7489,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7556,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_7556 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7556,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7553 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 658  node-class-set! */
t2=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7546,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7547,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7547 in k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7547,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7544 in k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 659  node-parameters-set! */
t2=C_retrieve(lf[210]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7490 in k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7538,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7538 in k7490 in k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7538,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7535 in k7490 in k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 660  node-subexpressions-set! */
t2=C_retrieve(lf[212]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7493 in k7490 in k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7495,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7506(t4,C_fix(4)));}

/* doloop1599 in k7493 in k7490 in k7487 in ##compiler#copy-node! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static C_word C_fcall f_7506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7451,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7457,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7457(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7457(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7457,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7471,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 654  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7469 in rec in ##compiler#tree-copy in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7475,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 654  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7457(t4,t2,t3);}

/* k7473 in k7469 in rec in ##compiler#tree-copy in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7475,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7230,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7234,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 622  map */
t6=*((C_word*)lf[256]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[279]+1),t3,t4);}

/* k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7236,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7242,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 649  walk */
t6=((C_word*)t4)[1];
f_7242(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7242(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7242,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7246,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7442,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7442 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7442,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7437,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7437 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7432,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7432 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7432,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7252,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[215]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7265,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 629  rename */
f_7236(t3,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(t1,lf[233]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 630  rename */
f_7236(t4,t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7317,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 633  gensym */
t7=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t5=(C_word)C_eqp(t1,lf[228]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7357,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 637  decompose-lambda-list */
t8=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[7],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 648  tree-copy */
t7=C_retrieve(lf[278]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}}}}}

/* k7414 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7420,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7426 in k7414 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7427,3,t0,t1,t2);}
/* walk1477 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7242(t3,t1,t2,((C_word*)t0)[2]);}

/* k7418 in k7414 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7421,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7421 in k7418 in k7414 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7421,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7357,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[93]),t2);}

/* k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 641  append */
t3=*((C_word*)lf[54]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k7362 in k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 644  gensym */
t3=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[277]);}

/* k7388 in k7362 in k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7390,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7398,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 645  rename */
f_7236(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_7406(2,t5,C_SCHEME_FALSE);}}

/* k7404 in k7388 in k7362 in k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 645  build-lambda-list */
t2=C_retrieve(lf[48]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7396 in k7388 in k7362 in k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7398,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7375,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7381 in k7396 in k7388 in k7362 in k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7382,3,t0,t1,t2);}
/* walk1477 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7242(t3,t1,t2,((C_word*)t0)[2]);}

/* k7373 in k7396 in k7388 in k7362 in k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7376,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[228],((C_word*)t0)[2],t1);}

/* f_7376 in k7373 in k7396 in k7388 in k7362 in k7359 in a7356 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7376,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7315 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7320,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 634  alist-cons */
t3=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7318 in k7315 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7320,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7331,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7338,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7337 in k7318 in k7315 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7338,3,t0,t1,t2);}
/* walk1477 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7242(t3,t1,t2,((C_word*)t0)[2]);}

/* k7329 in k7318 in k7315 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7332,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_7332 in k7329 in k7318 in k7315 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7332,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7299 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7301,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7286,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7292 in k7299 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7293,3,t0,t1,t2);}
/* walk1477 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7242(t3,t1,t2,((C_word*)t0)[2]);}

/* k7284 in k7299 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7287,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[233],((C_word*)t0)[2],t1);}

/* f_7287 in k7284 in k7299 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7287,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7263 in k7250 in k7247 in k7244 in walk in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 629  varnode */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k7232 in ##compiler#copy-node-tree-and-rename in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7236(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7236,NULL,3,t1,t2,t3);}
/* support.scm: 623  alist-ref */
t4=C_retrieve(lf[275]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[276]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7117,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7123,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 600  decompose-lambda-list */
t7=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7123,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7129,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7135,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7135,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[93]),((C_word*)t0)[2]);}
else{
t5=t4;
f_7139(2,t5,((C_word*)t0)[2]);}}

/* k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 606  copy-node-tree-and-rename */
t3=C_retrieve(lf[274]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_7142(2,t3,((C_word*)t0)[3]);}}

/* k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7147,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7168,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7222,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 612  last */
t5=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7168(2,t4,t1);}}

/* k7220 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7222,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7192,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 614  qnode */
t4=C_retrieve(lf[216]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[273],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7206,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[238],t6,((C_word*)t0)[2]);}}

/* f_7206 in k7220 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7206,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7190 in k7220 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7192,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7184,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t2);}

/* f_7184 in k7190 in k7220 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7184,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k7166 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7172,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 618  take */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7170 in k7166 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 608  fold-right */
t2=C_retrieve(lf[271]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7146 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7147,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7160,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[92],t5,t6);}

/* f_7160 in a7146 in k7140 in k7137 in a7134 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7160,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* a7128 in a7122 in ##compiler#inline-lambda-bindings in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7129,2,t0,t1);}
/* support.scm: 603  split-at */
t2=C_retrieve(lf[270]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7063,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7069,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7069(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7069,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7095,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 596  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k7093 in fold in ##compiler#fold-boolean in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7099,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 597  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7069(t4,t2,t3);}

/* k7097 in k7093 in fold in ##compiler#fold-boolean in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7099,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7087,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[230],lf[268],t2);}

/* f_7087 in k7097 in k7093 in fold in ##compiler#fold-boolean in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7087,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6730,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6736,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6736(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6736,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6740,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7057,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7057 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7057,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6743,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7052,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7052 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7052,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6746,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7047,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7047 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7047,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6746,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[220]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6755(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[265]);
t5=t3;
f_6755(t5,(C_truep(t4)?t4:(C_word)C_eqp(t1,lf[266])));}}

/* k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6755,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[254]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6779,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6783,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[215]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[219]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[82]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[82],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 570  butlast */
t10=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[116]:lf[228]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6870,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 577  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6736(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[240]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[231]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6903,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[221]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6927,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6927(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6989,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_6989(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t14)){
t15=t13;
f_6989(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t16=t13;
f_6989(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[264])));}}}}}}}}}}}}}

/* k6987 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6989,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 587  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6736(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7015,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7019,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k7017 in k6987 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 588  append */
t2=*((C_word*)lf[54]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7013 in k6987 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7015,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6994 in k6987 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7000,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k6998 in k6994 in k6987 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 587  cons* */
t2=C_retrieve(lf[259]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6927(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6927,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6945,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 584  reverse */
t7=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6976,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 585  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6736(3,t10,t8,t9);}}

/* k6974 in loop in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 585  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6927(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6943 in loop in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6953,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 584  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6736(3,t4,t2,t3);}

/* k6951 in k6943 in loop in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[260],t3));}

/* k6901 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 579  cons* */
t2=C_retrieve(lf[259]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[231],((C_word*)t0)[2],t1);}

/* k6868 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6870,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6847 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6843 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 570  map */
t2=*((C_word*)lf[256]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[257]+1),((C_word*)t0)[2],t1);}

/* k6827 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6837,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6841,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 571  last */
t4=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6839 in k6827 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 571  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6736(3,t2,((C_word*)t0)[2],t1);}

/* k6835 in k6827 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6837,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* k6781 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6777 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[254],t2));}

/* k6760 in k6753 in k6744 in k6741 in k6738 in walk in ##compiler#build-expression-tree in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6121,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6124,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6725,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 554  walk */
t9=((C_word*)t6)[1];
f_6124(3,t9,t8,t2);}

/* k6723 in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6728,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 555  debugging */
t3=C_retrieve(lf[10]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[251],lf[252],((C_word*)((C_word*)t0)[2])[1]);}

/* k6726 in k6723 in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word *a;
loop:
a=C_alloc(8);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_6124,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 488  varnode */
t3=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 489  bomb */
t3=C_retrieve(lf[5]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[218],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[219]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6166,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[219],t7,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(t4,lf[220]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[221]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6194,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6219,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6222,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[225],C_retrieve(lf[226]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_6222(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_6222(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_6222(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[92]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 509  walk */
t65=t1;
t66=t11;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6276,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 510  unzip1 */
t13=C_retrieve(lf[227]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[116]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[228]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6340,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 514  walk */
t65=t14;
t66=t15;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[229]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6388,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6388(t17,(C_word)C_eqp(lf[82],t16));}
else{
t16=t15;
f_6388(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[230]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[231]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6425,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[232]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6452,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,lf[232],t17,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t4,lf[233]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[234]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6480,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6542,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 533  fifth */
t26=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[238]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6563,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6563(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[246]);
if(C_truep(t21)){
t22=t20;
f_6563(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[247]);
if(C_truep(t22)){
t23=t20;
f_6563(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[248]);
t24=t20;
f_6563(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[249])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6713,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6711 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6714,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[240],lf[250],t1);}

/* f_6714 in k6711 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6714,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6563,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6578,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[239]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6600,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6614,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6620,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6641,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6664,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6669,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[245]);}

/* f_6669 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6669,4,t0,t1,t2,t3);}
/* ##sys#get */
t4=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* k6662 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6641(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6641(t2,C_SCHEME_FALSE);}}

/* k6639 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6641(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6641,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6645,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 549  real-name */
t4=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm: 551  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6646 in k6639 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6655(2,t3,t1);}
else{
/* support.scm: 550  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6653 in k6646 in k6639 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6655,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6645(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[242]),((C_word*)t0)[2],t1));}

/* k6643 in k6639 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6645,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6632,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6630 in k6643 in k6639 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6633,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[240],((C_word*)t0)[2],t1);}

/* f_6633 in k6630 in k6643 in k6639 in a6619 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6633,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* a6613 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6614,2,t0,t1);}
/* support.scm: 541  get-line-2 */
t2=C_retrieve(lf[144]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k6598 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6601,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[240],lf[241],t1);}

/* f_6601 in k6598 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6601,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6576 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6579,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6579 in k6576 in k6561 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6579,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6540 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6542,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6522,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 534  sixth */
t6=C_retrieve(lf[236]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6524 in k6540 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 534  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6124(3,t2,((C_word*)t0)[2],t1);}

/* k6520 in k6540 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6522,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6514,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[235],((C_word*)t0)[2],t2);}

/* f_6514 in k6520 in k6540 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6514,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6478 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6481,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[233],((C_word*)t0)[2],t1);}

/* f_6481 in k6478 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6481,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* f_6452 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6452,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6423 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6426,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6426 in k6423 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6426,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6386 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6388,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6372,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6370 in k6386 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6373,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6373 in k6370 in k6386 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6373,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6338 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6340,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6332,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[116],((C_word*)t0)[2],t2);}

/* f_6332 in k6338 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6332,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6274 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6280,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6299,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6298 in k6274 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6299,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 511  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6124(3,t4,t1,t3);}

/* k6287 in k6274 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6297,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 512  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6124(3,t3,t2,((C_word*)t0)[2]);}

/* k6295 in k6287 in k6274 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 511  append */
t3=*((C_word*)lf[54]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6278 in k6274 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6281,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_6281 in k6278 in k6274 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6281,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* k6220 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6222,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 500  compiler-warning */
t3=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[223],lf[224],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6219(t2,((C_word*)t0)[2]);}}

/* k6223 in k6220 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 503  truncate */
t3=*((C_word*)lf[222]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6230 in k6223 in k6220 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6219(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k6217 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_6219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 496  qnode */
t2=C_retrieve(lf[216]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6192 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6195,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* f_6195 in k6192 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6195,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* f_6166 in walk in ##compiler#build-node-graph in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6166,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#qnode in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6106,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6115,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[82],t3,C_SCHEME_END_OF_LIST);}

/* f_6115 in ##compiler#qnode in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6115,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#varnode in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6091,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6100,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[215],t3,C_SCHEME_END_OF_LIST);}

/* f_6100 in ##compiler#varnode in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6100,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* make-node in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6085,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* node-subexpressions in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6076,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6067,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6058,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6049,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6040,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6031,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6025,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[205]));}

/* f_6019 in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6019,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5529,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5533,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5533(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6017,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 419  append */
t5=*((C_word*)lf[54]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[201]),C_retrieve(lf[202]),C_retrieve(lf[203]));}}

/* k6015 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5533(t3,t2);}

/* k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5533,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 422  ##sys#hash-table-for-each */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5538,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5548,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 430  write */
t15=*((C_word*)lf[200]+1);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t2);}}

/* k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5696,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5696(t6,t2,((C_word*)t0)[2]);}

/* loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5696(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5696,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 434  caar */
t4=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5709,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[159]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5722(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t5)){
t6=t4;
f_5722(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t6)){
t7=t4;
f_5722(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t7)){
t8=t4;
f_5722(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t8)){
t9=t4;
f_5722(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t9)){
t10=t4;
f_5722(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[124]);
if(C_truep(t10)){
t11=t4;
f_5722(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t11)){
t12=t4;
f_5722(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[132]);
if(C_truep(t12)){
t13=t4;
f_5722(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t13)){
t14=t4;
f_5722(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t14)){
t15=t4;
f_5722(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t15)){
t16=t4;
f_5722(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t16)){
t17=t4;
f_5722(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t17)){
t18=t4;
f_5722(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t18)){
t19=t4;
f_5722(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t19)){
t20=t4;
f_5722(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t20)){
t21=t4;
f_5722(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t21)){
t22=t4;
f_5722(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t22)){
t23=t4;
f_5722(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t23)){
t24=t4;
f_5722(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t24)){
t25=t4;
f_5722(t25,t24);}
else{
t25=(C_word)C_eqp(t1,lf[198]);
t26=t4;
f_5722(t26,(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[199])));}}}}}}}}}}}}}}}}}}}}}}

/* k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5722,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5737,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 438  caar */
t3=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[158]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[158]);
t4=((C_word*)t0)[9];
f_5709(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[163]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[158]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5709(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5760,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 442  cdar */
t6=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[165]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[158]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5709(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 444  cdar */
t7=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[166]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5786,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 446  cdar */
t7=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[167]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5795(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[172]);
if(C_truep(t8)){
t9=t7;
f_5795(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t9)){
t10=t7;
f_5795(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[146]);
if(C_truep(t10)){
t11=t7;
f_5795(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t11)){
t12=t7;
f_5795(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t12)){
t13=t7;
f_5795(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t13)){
t14=t7;
f_5795(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
if(C_truep(t14)){
t15=t7;
f_5795(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[178]);
t16=t7;
f_5795(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[179])));}}}}}}}}}}}}}}

/* k5793 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5795,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 449  caar */
t3=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[169]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5816,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 451  cdar */
t4=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[170]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5826,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 453  cdar */
t5=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 454  bomb */
t5=C_retrieve(lf[5]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[171],t4);}}}}

/* k5824 in k5793 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5709(2,t3,t2);}

/* k5814 in k5793 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5709(2,t3,t2);}

/* k5800 in k5793 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5806,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 449  cdar */
t3=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5804 in k5800 in k5793 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 449  printf */
t2=C_retrieve(lf[13]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[168],((C_word*)t0)[2],t1);}

/* k5784 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5709(2,t3,t2);}

/* k5774 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5709(2,t3,t2);}

/* k5758 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5709(2,t3,t2);}

/* k5735 in k5720 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[160]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 438  printf */
t4=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[161],t3);}

/* k5707 in k5704 in loop in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 455  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5696(t3,((C_word*)t0)[2],t2);}

/* k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[158]);
t5=t3;
f_5586(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5586(t4,C_SCHEME_FALSE);}}

/* k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5586,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5607,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[158]);
t4=t2;
f_5617(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5617(t3,C_SCHEME_FALSE);}}}

/* k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5638,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[158]);
t4=t2;
f_5648(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5648(t3,C_SCHEME_FALSE);}}}

/* k5646 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5648,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5669,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_5554(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5669 in k5646 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5669,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5657 in k5646 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5664,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5664 in k5657 in k5646 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5664,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5661 in k5657 in k5646 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 461  printf */
t3=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[157],t2);}

/* f_5638 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5638,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5626 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5633,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5633 in k5626 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5633,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5630 in k5626 in k5615 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 459  printf */
t3=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[156],t2);}

/* f_5607 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5607,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5595 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5602,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5602 in k5595 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5602,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5599 in k5595 in k5584 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5601,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 457  printf */
t3=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[155],t2);}

/* k5552 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 462  printf */
t4=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[154],t3);}
else{
t3=t2;
f_5557(2,t3,C_SCHEME_UNDEFINED);}}

/* k5555 in k5552 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 463  printf */
t4=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[153],t3);}
else{
t3=t2;
f_5560(2,t3,C_SCHEME_UNDEFINED);}}

/* k5558 in k5555 in k5552 in k5549 in k5546 in a5537 in k5531 in ##compiler#display-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 464  newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5516,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 401  ##sys#hash-table-for-each */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[143]));}

/* a5515 in ##compiler#display-line-number-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5516,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5527,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[150]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5525 in a5515 in ##compiler#display-line-number-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 403  printf */
t2=C_retrieve(lf[13]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[148],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5486,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5492,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5492(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5492(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5492,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5502,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 397  get */
t5=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[146]);}}

/* k5500 in loop in ##compiler#find-lambda-container in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 398  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5492(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5450,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5457,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 389  ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[143]),t3);}

/* k5455 in ##compiler#get-line-2 in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5460(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5460(t3,C_SCHEME_FALSE);}}

/* k5458 in k5455 in ##compiler#get-line-2 in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_5460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 391  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 392  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5440,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 385  get */
t4=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[143]),t3,t2);}

/* ##compiler#count! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5383r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5383r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5383r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5387,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 373  ##sys#hash-table-ref */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k5385 in ##compiler#count! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5417,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 378  alist-cons */
t7=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 379  ##sys#hash-table-set! */
t6=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5415 in k5385 in ##compiler#count! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5331,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5335,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 365  ##sys#hash-table-ref */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k5333 in ##compiler#collect! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5335,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5362,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 369  alist-cons */
t6=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 370  ##sys#hash-table-set! */
t4=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5360 in k5333 in ##compiler#collect! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5285,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5289,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 357  ##sys#hash-table-ref */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k5287 in ##compiler#put! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5289,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5311,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 361  alist-cons */
t5=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 362  ##sys#hash-table-set! */
t4=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5309 in k5287 in ##compiler#put! in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5267r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5267r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5267r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 351  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5269 in ##compiler#get-all in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5279,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 353  filter-map */
t3=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5278 in k5269 in ##compiler#get-all in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5279,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5249,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5253,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 345  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5251 in ##compiler#get in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5140,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5144,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[134]));}

/* a5194 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5195,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5221,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[127],lf[133]);}
else{
t4=t3;
f_5199(2,t4,C_SCHEME_UNDEFINED);}}

/* f_5221 in a5194 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5221r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5221r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5221r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5225,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5225(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5225(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5223 */
static void C_ccall f_5225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5197 in a5194 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[131])))){
/* support.scm: 333  put! */
t3=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[132],C_SCHEME_TRUE);}
else{
t3=t2;
f_5202(2,t3,C_SCHEME_UNDEFINED);}}

/* k5200 in k5197 in a5194 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[130])))){
/* support.scm: 334  put! */
t2=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[124],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5142 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[129]));}

/* a5149 in k5142 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5150,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5167,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[127],lf[128]);}
else{
t4=t3;
f_5154(2,t4,C_SCHEME_UNDEFINED);}}

/* f_5167 in a5149 in k5142 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5167r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5167r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5167r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5171,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5171(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5171(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[126]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5169 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5152 in a5149 in k5142 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[122])))){
/* support.scm: 340  put! */
t2=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[124],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5145 in k5142 in ##compiler#initialize-analysis-database in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4999,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[112]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5003,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 311  gensym */
t7=C_retrieve(lf[93]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k5001 in ##compiler#expand-profile-lambda in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5007,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 312  alist-cons */
t3=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[113]));}

/* k5005 in k5001 in ##compiler#expand-profile-lambda in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5007,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[112]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[115],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[116],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[116],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[117],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[116],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[82],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[118],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[116],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[119],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[116],t35));}

/* ##compiler#process-lambda-documentation in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4996,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4889,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4896,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[107]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4898,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4904,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4929,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4982 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4983r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4983r(t0,t1,t2);}}

static void C_ccall f_4983r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4988 in a4982 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4934 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4939,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4967,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 296  with-input-from-string */
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a4966 in a4934 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4973,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4981,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 296  read */
t4=*((C_word*)lf[101]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4979 in a4966 in a4934 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 296  unfold */
t2=C_retrieve(lf[102]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[103]+1),*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* a4972 in a4966 in a4934 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4973,3,t0,t1,t2);}
/* support.scm: 296  read */
t3=*((C_word*)lf[101]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k4937 in a4934 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4939,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[98]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4959 in k4937 in a4934 in a4928 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* a4903 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4904,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4909 in a4903 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4921,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 293  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4919 in a4909 in a4903 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 294  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 295  ->string */
t2=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4916 in a4909 in a4903 in a4897 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 291  quit */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* k4894 in ##compiler#string->expr in k4886 in k4883 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4788,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4794,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4794(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4794(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4794,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[90]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[91]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4822,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4822(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4871,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 280  constant? */
t8=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k4869 in loop in ##compiler#canonicalize-begin-body in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4822(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[95])));}

/* k4820 in loop in ##compiler#canonicalize-begin-body in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4822,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 282  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4794(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 283  gensym */
t3=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[94]);}}

/* k4858 in k4820 in loop in ##compiler#canonicalize-begin-body in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 284  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4794(t8,t6,t7);}

/* k4846 in k4858 in k4820 in loop in ##compiler#canonicalize-begin-body in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* ##compiler#basic-literal? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4728,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4744,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 265  constant? */
t6=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}

/* k4742 in ##compiler#basic-literal? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4786,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 266  vector->list */
t4=*((C_word*)lf[88]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4750(2,t3,C_SCHEME_FALSE);}}}

/* k4784 in k4742 in ##compiler#basic-literal? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 266  every */
t2=C_retrieve(lf[87]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[86]),t1);}

/* k4748 in k4742 in ##compiler#basic-literal? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 268  basic-literal? */
t4=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4763 in k4748 in k4742 in ##compiler#basic-literal? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 269  basic-literal? */
t3=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4682,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4686,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4726,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 255  big-fixnum? */
t5=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t3;
f_4686(t4,C_SCHEME_FALSE);}}

/* k4724 in ##compiler#immediate? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4686(t2,(C_word)C_i_not(t1));}

/* k4684 in ##compiler#immediate? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4652,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4606,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[82],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4586,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4592,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 234  sort */
t4=C_retrieve(lf[80]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a4591 in ##compiler#sort-symbols in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4592,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4600,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 234  symbol->string */
t5=*((C_word*)lf[42]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4598 in a4591 in ##compiler#sort-symbols in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4604,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 234  symbol->string */
t3=*((C_word*)lf[42]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4602 in k4598 in a4591 in ##compiler#sort-symbols in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 234  string<? */
t2=*((C_word*)lf[79]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4555,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4561,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4561(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4561(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4561,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 230  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 231  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4575 in loop in ##compiler#follow-without-loop in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4576,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 231  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4561(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4492,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4506,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 220  reverse */
t6=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k4504 in ##compiler#fold-inner in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4506,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4508,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4508(t5,((C_word*)t0)[2],t1);}

/* fold in k4504 in ##compiler#fold-inner in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4508,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4516(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 225  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4535 in fold in k4504 in ##compiler#fold-inner in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4516(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4514 in fold in k4504 in ##compiler#fold-inner in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4480,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[73]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 215  close-input-port */
t4=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4433r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4433r(t0,t1,t2,t3);}}

static void C_ccall f_4433r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[66]))){
/* support.scm: 209  current-input-port */
t4=*((C_word*)lf[67]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4449,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 210  file-exists? */
t5=C_retrieve(lf[71]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k4447 in ##compiler#check-and-open-input-file in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 210  open-input-file */
t2=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4461(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4461(t5,(C_word)C_i_not(t4));}}}

/* k4459 in k4447 in ##compiler#check-and-open-input-file in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 211  quit */
t2=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[69],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 212  quit */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[70],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4426,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4419,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub326(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4363,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4367,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 190  ->string */
t5=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4415 in ##compiler#valid-c-identifier? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4365 in ##compiler#valid-c-identifier? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4390,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 194  any */
t7=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4389 in k4365 in ##compiler#valid-c-identifier? in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4390,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4269,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4281,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4285,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4287,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4287(t5,((C_word*)t0)[2],t1);}

/* loop in k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4287,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[53]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4309,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4309(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4309(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[59])));}}}

/* k4307 in loop in k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4309,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4316(t3,lf[57]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4316(t4,(C_truep(t3)?lf[58]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4287(t4,t2,t3);}}

/* k4346 in k4307 in loop in k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4314 in k4307 in loop in k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4316,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 185  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4330 in k4314 in k4307 in loop in k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4318 in k4314 in k4307 in loop in k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4324,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 186  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4287(t4,t2,t3);}

/* k4322 in k4318 in k4314 in k4307 in loop in k4283 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 181  append */
t2=*((C_word*)lf[54]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[55],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4279 in ##compiler#c-ify-string in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[52]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4225,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4231,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4231(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4231(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4231,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4255,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 167  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4253 in loop in ##compiler#build-lambda-list in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4255,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4200,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 161  string->symbol */
t3=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4223,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 162  sprintf */
t4=C_retrieve(lf[43]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[47],t2);}}}

/* k4221 in ##compiler#symbolify in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 162  string->symbol */
t2=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4179,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 156  symbol->string */
t3=*((C_word*)lf[42]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* support.scm: 157  sprintf */
t3=C_retrieve(lf[43]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[44],t2);}}}

/* ##compiler#posq in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4143,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4149(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static C_word C_fcall f_4149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4075,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4078,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4099,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4099(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4099(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4099,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 140  err */
t4=((C_word*)t0)[3];
f_4078(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 142  err */
t5=((C_word*)t0)[3];
f_4078(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 143  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4078,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 137  real-name */
t3=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4084 in err in ##compiler#check-signature in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4090,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 138  map-llist */
t4=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[39]),t3);}

/* k4088 in k4084 in err in ##compiler#check-signature in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 136  quit */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}

/* map-llist in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4032,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4038(t7,t1,t3);}

/* loop in map-llist in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_4038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4038,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 131  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 132  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4059 in loop in map-llist in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4065,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 132  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4038(t4,t2,t3);}

/* k4063 in k4059 in loop in map-llist in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4029,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[30])));}

/* ##sys#syntax-error-hook in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4004r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4004r(t0,t1,t2,t3);}}

static void C_ccall f_4004r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4008,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  current-error-port */
t5=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4006 in ##sys#syntax-error-hook in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 118  fprintf */
t3=C_retrieve(lf[21]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[33],((C_word*)t0)[2]);}

/* k4009 in k4006 in ##sys#syntax-error-hook in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4021 in k4009 in k4006 in ##sys#syntax-error-hook in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4022,3,t0,t1,t2);}
/* fprintf */
t3=C_retrieve(lf[21]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],lf[32],t2);}

/* k4012 in k4009 in k4006 in ##sys#syntax-error-hook in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 120  print-call-chain */
t3=C_retrieve(lf[29]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[30]),lf[31]);}

/* k4015 in k4012 in k4009 in k4006 in ##sys#syntax-error-hook in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 121  exit */
t2=C_retrieve(lf[26]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3985r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3985r(t0,t1,t2,t3);}}

static void C_ccall f_3985r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3989,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  current-error-port */
t5=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3987 in quit in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3992,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 111  string-append */
t4=*((C_word*)lf[7]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[27],((C_word*)t0)[2]);}

/* k4000 in k3987 in quit in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3990 in k3987 in quit in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 112  newline */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3993 in k3990 in k3987 in quit in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 113  exit */
t2=C_retrieve(lf[26]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3956r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3956r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3956r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3963,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[24]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_3963(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3963(t6,C_SCHEME_FALSE);}}

/* k3961 in ##compiler#compiler-warning in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_fcall f_3963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3963,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  current-error-port */
t3=C_retrieve(lf[23]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3964 in k3961 in ##compiler#compiler-warning in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3969,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 106  string-append */
t4=*((C_word*)lf[7]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[22],((C_word*)t0)[2]);}

/* k3974 in k3964 in k3961 in ##compiler#compiler-warning in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3967 in k3964 in k3961 in ##compiler#compiler-warning in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 107  newline */
t2=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3916r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3916r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3926,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 94   printf */
t6=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[19],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3924 in ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 97   display */
t4=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[18]);}
else{
t3=t2;
f_3929(2,t3,C_SCHEME_UNDEFINED);}}

/* k3939 in k3924 in ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3946,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3945 in k3939 in k3924 in ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3946,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3954,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   force */
t4=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3952 in a3945 in k3939 in k3924 in ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 98   printf */
t2=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[14],t1);}

/* k3927 in k3924 in ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3930 in k3927 in k3924 in ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 100  flush-output */
t3=*((C_word*)lf[11]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3933 in k3930 in k3927 in k3924 in ##compiler#debugging in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3889r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3889r(t0,t1,t2);}}

static void C_ccall f_3889r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3903,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 88   string-append */
t5=*((C_word*)lf[7]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[8],t4);}
else{
/* support.scm: 89   error */
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[9]);}}

/* k3901 in ##compiler#bomb in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* f_3884 in k3878 in k3875 in k3872 in k3869 in k3866 in k3863 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3884,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[680] = {
{"toplevelsupport.scm",(void*)C_support_toplevel},
{"f_3865support.scm",(void*)f_3865},
{"f_3868support.scm",(void*)f_3868},
{"f_3871support.scm",(void*)f_3871},
{"f_3874support.scm",(void*)f_3874},
{"f_3877support.scm",(void*)f_3877},
{"f_3880support.scm",(void*)f_3880},
{"f_4885support.scm",(void*)f_4885},
{"f_4888support.scm",(void*)f_4888},
{"f_11908support.scm",(void*)f_11908},
{"f_11913support.scm",(void*)f_11913},
{"f_11902support.scm",(void*)f_11902},
{"f_11874support.scm",(void*)f_11874},
{"f_11878support.scm",(void*)f_11878},
{"f_11853support.scm",(void*)f_11853},
{"f_11857support.scm",(void*)f_11857},
{"f_11820support.scm",(void*)f_11820},
{"f_11825support.scm",(void*)f_11825},
{"f_11829support.scm",(void*)f_11829},
{"f_11787support.scm",(void*)f_11787},
{"f_11792support.scm",(void*)f_11792},
{"f_11796support.scm",(void*)f_11796},
{"f_11763support.scm",(void*)f_11763},
{"f_11734support.scm",(void*)f_11734},
{"f_11761support.scm",(void*)f_11761},
{"f_11745support.scm",(void*)f_11745},
{"f_11748support.scm",(void*)f_11748},
{"f_11750support.scm",(void*)f_11750},
{"f_11754support.scm",(void*)f_11754},
{"f_11738support.scm",(void*)f_11738},
{"f_11671support.scm",(void*)f_11671},
{"f_11708support.scm",(void*)f_11708},
{"f_11732support.scm",(void*)f_11732},
{"f_11718support.scm",(void*)f_11718},
{"f_11722support.scm",(void*)f_11722},
{"f_11693support.scm",(void*)f_11693},
{"f_11701support.scm",(void*)f_11701},
{"f_11602support.scm",(void*)f_11602},
{"f_11606support.scm",(void*)f_11606},
{"f_11611support.scm",(void*)f_11611},
{"f_11615support.scm",(void*)f_11615},
{"f_11666support.scm",(void*)f_11666},
{"f_11645support.scm",(void*)f_11645},
{"f_11657support.scm",(void*)f_11657},
{"f_11660support.scm",(void*)f_11660},
{"f_11633support.scm",(void*)f_11633},
{"f_11569support.scm",(void*)f_11569},
{"f_11579support.scm",(void*)f_11579},
{"f_11582support.scm",(void*)f_11582},
{"f_11467support.scm",(void*)f_11467},
{"f_11476support.scm",(void*)f_11476},
{"f_11563support.scm",(void*)f_11563},
{"f_11480support.scm",(void*)f_11480},
{"f_11558support.scm",(void*)f_11558},
{"f_11483support.scm",(void*)f_11483},
{"f_11553support.scm",(void*)f_11553},
{"f_11486support.scm",(void*)f_11486},
{"f_11489support.scm",(void*)f_11489},
{"f_11495support.scm",(void*)f_11495},
{"f_11548support.scm",(void*)f_11548},
{"f_11498support.scm",(void*)f_11498},
{"f_11513support.scm",(void*)f_11513},
{"f_11521support.scm",(void*)f_11521},
{"f_11531support.scm",(void*)f_11531},
{"f_11516support.scm",(void*)f_11516},
{"f_11504support.scm",(void*)f_11504},
{"f_11471support.scm",(void*)f_11471},
{"f_11461support.scm",(void*)f_11461},
{"f_11415support.scm",(void*)f_11415},
{"f_11434support.scm",(void*)f_11434},
{"f_11445support.scm",(void*)f_11445},
{"f_11441support.scm",(void*)f_11441},
{"f_11403support.scm",(void*)f_11403},
{"f_11409support.scm",(void*)f_11409},
{"f_11391support.scm",(void*)f_11391},
{"f_11395support.scm",(void*)f_11395},
{"f_11312support.scm",(void*)f_11312},
{"f_11331support.scm",(void*)f_11331},
{"f_11356support.scm",(void*)f_11356},
{"f_11360support.scm",(void*)f_11360},
{"f_11362support.scm",(void*)f_11362},
{"f_11369support.scm",(void*)f_11369},
{"f_11382support.scm",(void*)f_11382},
{"f_11386support.scm",(void*)f_11386},
{"f_11315support.scm",(void*)f_11315},
{"f_11319support.scm",(void*)f_11319},
{"f_11325support.scm",(void*)f_11325},
{"f_11306support.scm",(void*)f_11306},
{"f_11262support.scm",(void*)f_11262},
{"f_11274support.scm",(void*)f_11274},
{"f_11278support.scm",(void*)f_11278},
{"f_11282support.scm",(void*)f_11282},
{"f_11270support.scm",(void*)f_11270},
{"f_11253support.scm",(void*)f_11253},
{"f_11247support.scm",(void*)f_11247},
{"f_11241support.scm",(void*)f_11241},
{"f_11229support.scm",(void*)f_11229},
{"f_11233support.scm",(void*)f_11233},
{"f_11236support.scm",(void*)f_11236},
{"f_11191support.scm",(void*)f_11191},
{"f_11195support.scm",(void*)f_11195},
{"f_11198support.scm",(void*)f_11198},
{"f_11205support.scm",(void*)f_11205},
{"f_11149support.scm",(void*)f_11149},
{"f_11158support.scm",(void*)f_11158},
{"f_11120support.scm",(void*)f_11120},
{"f_11130support.scm",(void*)f_11130},
{"f_10923support.scm",(void*)f_10923},
{"f_11102support.scm",(void*)f_11102},
{"f_11051support.scm",(void*)f_11051},
{"f_11096support.scm",(void*)f_11096},
{"f_11100support.scm",(void*)f_11100},
{"f_11054support.scm",(void*)f_11054},
{"f_11059support.scm",(void*)f_11059},
{"f_11063support.scm",(void*)f_11063},
{"f_11057support.scm",(void*)f_11057},
{"f_11014support.scm",(void*)f_11014},
{"f_11018support.scm",(void*)f_11018},
{"f_11027support.scm",(void*)f_11027},
{"f_11031support.scm",(void*)f_11031},
{"f_11021support.scm",(void*)f_11021},
{"f_10979support.scm",(void*)f_10979},
{"f_10985support.scm",(void*)f_10985},
{"f_11012support.scm",(void*)f_11012},
{"f_10998support.scm",(void*)f_10998},
{"f_10932support.scm",(void*)f_10932},
{"f_10938support.scm",(void*)f_10938},
{"f_10977support.scm",(void*)f_10977},
{"f_10959support.scm",(void*)f_10959},
{"f_10736support.scm",(void*)f_10736},
{"f_10918support.scm",(void*)f_10918},
{"f_10905support.scm",(void*)f_10905},
{"f_10911support.scm",(void*)f_10911},
{"f_10739support.scm",(void*)f_10739},
{"f_10899support.scm",(void*)f_10899},
{"f_10743support.scm",(void*)f_10743},
{"f_10894support.scm",(void*)f_10894},
{"f_10746support.scm",(void*)f_10746},
{"f_10889support.scm",(void*)f_10889},
{"f_10749support.scm",(void*)f_10749},
{"f_10758support.scm",(void*)f_10758},
{"f_10852support.scm",(void*)f_10852},
{"f_10864support.scm",(void*)f_10864},
{"f_10822support.scm",(void*)f_10822},
{"f_10833support.scm",(void*)f_10833},
{"f_10813support.scm",(void*)f_10813},
{"f_10799support.scm",(void*)f_10799},
{"f_10777support.scm",(void*)f_10777},
{"f_10783support.scm",(void*)f_10783},
{"f_10787support.scm",(void*)f_10787},
{"f_10643support.scm",(void*)f_10643},
{"f_10649support.scm",(void*)f_10649},
{"f_10730support.scm",(void*)f_10730},
{"f_10653support.scm",(void*)f_10653},
{"f_10725support.scm",(void*)f_10725},
{"f_10656support.scm",(void*)f_10656},
{"f_10709support.scm",(void*)f_10709},
{"f_10696support.scm",(void*)f_10696},
{"f_10695support.scm",(void*)f_10695},
{"f_10677support.scm",(void*)f_10677},
{"f_10671support.scm",(void*)f_10671},
{"f_10647support.scm",(void*)f_10647},
{"f_10351support.scm",(void*)f_10351},
{"f_10547support.scm",(void*)f_10547},
{"f_10568support.scm",(void*)f_10568},
{"f_10041support.scm",(void*)f_10041},
{"f_10345support.scm",(void*)f_10345},
{"f_10053support.scm",(void*)f_10053},
{"f_10063support.scm",(void*)f_10063},
{"f_10081support.scm",(void*)f_10081},
{"f_10115support.scm",(void*)f_10115},
{"f_10044support.scm",(void*)f_10044},
{"f_9722support.scm",(void*)f_9722},
{"f_10035support.scm",(void*)f_10035},
{"f_9728support.scm",(void*)f_9728},
{"f_9738support.scm",(void*)f_9738},
{"f_9747support.scm",(void*)f_9747},
{"f_9759support.scm",(void*)f_9759},
{"f_9771support.scm",(void*)f_9771},
{"f_9777support.scm",(void*)f_9777},
{"f_9811support.scm",(void*)f_9811},
{"f_9682support.scm",(void*)f_9682},
{"f_9716support.scm",(void*)f_9716},
{"f_9688support.scm",(void*)f_9688},
{"f_9692support.scm",(void*)f_9692},
{"f_9651support.scm",(void*)f_9651},
{"f_9664support.scm",(void*)f_9664},
{"f_9655support.scm",(void*)f_9655},
{"f_9620support.scm",(void*)f_9620},
{"f_9633support.scm",(void*)f_9633},
{"f_9624support.scm",(void*)f_9624},
{"f_8573support.scm",(void*)f_8573},
{"f_9614support.scm",(void*)f_9614},
{"f_8579support.scm",(void*)f_8579},
{"f_8585support.scm",(void*)f_8585},
{"f_8614support.scm",(void*)f_8614},
{"f_8633support.scm",(void*)f_8633},
{"f_8652support.scm",(void*)f_8652},
{"f_8722support.scm",(void*)f_8722},
{"f_8741support.scm",(void*)f_8741},
{"f_8823support.scm",(void*)f_8823},
{"f_8862support.scm",(void*)f_8862},
{"f_8881support.scm",(void*)f_8881},
{"f_8900support.scm",(void*)f_8900},
{"f_8980support.scm",(void*)f_8980},
{"f_9065support.scm",(void*)f_9065},
{"f_9140support.scm",(void*)f_9140},
{"f_9174support.scm",(void*)f_9174},
{"f_9244support.scm",(void*)f_9244},
{"f_9177support.scm",(void*)f_9177},
{"f_8983support.scm",(void*)f_8983},
{"f_9014support.scm",(void*)f_9014},
{"f_8903support.scm",(void*)f_8903},
{"f_8744support.scm",(void*)f_8744},
{"f_8775support.scm",(void*)f_8775},
{"f_8655support.scm",(void*)f_8655},
{"f_8686support.scm",(void*)f_8686},
{"f_8537support.scm",(void*)f_8537},
{"f_8541support.scm",(void*)f_8541},
{"f_8552support.scm",(void*)f_8552},
{"f_8558support.scm",(void*)f_8558},
{"f_8562support.scm",(void*)f_8562},
{"f_8544support.scm",(void*)f_8544},
{"f_8498support.scm",(void*)f_8498},
{"f_8510support.scm",(void*)f_8510},
{"f_8517support.scm",(void*)f_8517},
{"f_8520support.scm",(void*)f_8520},
{"f_8523support.scm",(void*)f_8523},
{"f_8526support.scm",(void*)f_8526},
{"f_8529support.scm",(void*)f_8529},
{"f_8532support.scm",(void*)f_8532},
{"f_8504support.scm",(void*)f_8504},
{"f_8412support.scm",(void*)f_8412},
{"f_8421support.scm",(void*)f_8421},
{"f_8427support.scm",(void*)f_8427},
{"f_8474support.scm",(void*)f_8474},
{"f_8469support.scm",(void*)f_8469},
{"f_8416support.scm",(void*)f_8416},
{"f_8391support.scm",(void*)f_8391},
{"f_8401support.scm",(void*)f_8401},
{"f_8360support.scm",(void*)f_8360},
{"f_8366support.scm",(void*)f_8366},
{"f_8373support.scm",(void*)f_8373},
{"f_8376support.scm",(void*)f_8376},
{"f_8238support.scm",(void*)f_8238},
{"f_8354support.scm",(void*)f_8354},
{"f_8242support.scm",(void*)f_8242},
{"f_8262support.scm",(void*)f_8262},
{"f_8343support.scm",(void*)f_8343},
{"f_8266support.scm",(void*)f_8266},
{"f_8338support.scm",(void*)f_8338},
{"f_8337support.scm",(void*)f_8337},
{"f_8320support.scm",(void*)f_8320},
{"f_8275support.scm",(void*)f_8275},
{"f_8315support.scm",(void*)f_8315},
{"f_8314support.scm",(void*)f_8314},
{"f_8306support.scm",(void*)f_8306},
{"f_8305support.scm",(void*)f_8305},
{"f_8137support.scm",(void*)f_8137},
{"f_8143support.scm",(void*)f_8143},
{"f_8232support.scm",(void*)f_8232},
{"f_8147support.scm",(void*)f_8147},
{"f_8227support.scm",(void*)f_8227},
{"f_8150support.scm",(void*)f_8150},
{"f_8159support.scm",(void*)f_8159},
{"f_8186support.scm",(void*)f_8186},
{"f_8185support.scm",(void*)f_8185},
{"f_8173support.scm",(void*)f_8173},
{"f_8181support.scm",(void*)f_8181},
{"f_7917support.scm",(void*)f_7917},
{"f_8111support.scm",(void*)f_8111},
{"f_8131support.scm",(void*)f_8131},
{"f_8121support.scm",(void*)f_8121},
{"f_8126support.scm",(void*)f_8126},
{"f_8125support.scm",(void*)f_8125},
{"f_8117support.scm",(void*)f_8117},
{"f_7992support.scm",(void*)f_7992},
{"f_8104support.scm",(void*)f_8104},
{"f_8099support.scm",(void*)f_8099},
{"f_8091support.scm",(void*)f_8091},
{"f_8086support.scm",(void*)f_8086},
{"f_8014support.scm",(void*)f_8014},
{"f_8078support.scm",(void*)f_8078},
{"f_8021support.scm",(void*)f_8021},
{"f_8027support.scm",(void*)f_8027},
{"f_8058support.scm",(void*)f_8058},
{"f_7949support.scm",(void*)f_7949},
{"f_7971support.scm",(void*)f_7971},
{"f_7920support.scm",(void*)f_7920},
{"f_7944support.scm",(void*)f_7944},
{"f_7848support.scm",(void*)f_7848},
{"f_7854support.scm",(void*)f_7854},
{"f_7860support.scm",(void*)f_7860},
{"f_7864support.scm",(void*)f_7864},
{"f_7884support.scm",(void*)f_7884},
{"f_7885support.scm",(void*)f_7885},
{"f_7889support.scm",(void*)f_7889},
{"f_7873support.scm",(void*)f_7873},
{"f_7646support.scm",(void*)f_7646},
{"f_7677support.scm",(void*)f_7677},
{"f_7846support.scm",(void*)f_7846},
{"f_7681support.scm",(void*)f_7681},
{"f_7689support.scm",(void*)f_7689},
{"f_7696support.scm",(void*)f_7696},
{"f_7838support.scm",(void*)f_7838},
{"f_7832support.scm",(void*)f_7832},
{"f_7833support.scm",(void*)f_7833},
{"f_7828support.scm",(void*)f_7828},
{"f_7720support.scm",(void*)f_7720},
{"f_7809support.scm",(void*)f_7809},
{"f_7729support.scm",(void*)f_7729},
{"f_7738support.scm",(void*)f_7738},
{"f_7800support.scm",(void*)f_7800},
{"f_7792support.scm",(void*)f_7792},
{"f_7750support.scm",(void*)f_7750},
{"f_7753support.scm",(void*)f_7753},
{"f_7771support.scm",(void*)f_7771},
{"f_7760support.scm",(void*)f_7760},
{"f_7684support.scm",(void*)f_7684},
{"f_7650support.scm",(void*)f_7650},
{"f_7656support.scm",(void*)f_7656},
{"f_7669support.scm",(void*)f_7669},
{"f_7661support.scm",(void*)f_7661},
{"f_7613support.scm",(void*)f_7613},
{"f_7619support.scm",(void*)f_7619},
{"f_7635support.scm",(void*)f_7635},
{"f_7636support.scm",(void*)f_7636},
{"f_7562support.scm",(void*)f_7562},
{"f_7568support.scm",(void*)f_7568},
{"f_7607support.scm",(void*)f_7607},
{"f_7576support.scm",(void*)f_7576},
{"f_7602support.scm",(void*)f_7602},
{"f_7584support.scm",(void*)f_7584},
{"f_7597support.scm",(void*)f_7597},
{"f_7596support.scm",(void*)f_7596},
{"f_7592support.scm",(void*)f_7592},
{"f_7588support.scm",(void*)f_7588},
{"f_7485support.scm",(void*)f_7485},
{"f_7556support.scm",(void*)f_7556},
{"f_7555support.scm",(void*)f_7555},
{"f_7489support.scm",(void*)f_7489},
{"f_7547support.scm",(void*)f_7547},
{"f_7546support.scm",(void*)f_7546},
{"f_7492support.scm",(void*)f_7492},
{"f_7538support.scm",(void*)f_7538},
{"f_7537support.scm",(void*)f_7537},
{"f_7495support.scm",(void*)f_7495},
{"f_7506support.scm",(void*)f_7506},
{"f_7451support.scm",(void*)f_7451},
{"f_7457support.scm",(void*)f_7457},
{"f_7471support.scm",(void*)f_7471},
{"f_7475support.scm",(void*)f_7475},
{"f_7230support.scm",(void*)f_7230},
{"f_7234support.scm",(void*)f_7234},
{"f_7242support.scm",(void*)f_7242},
{"f_7442support.scm",(void*)f_7442},
{"f_7246support.scm",(void*)f_7246},
{"f_7437support.scm",(void*)f_7437},
{"f_7249support.scm",(void*)f_7249},
{"f_7432support.scm",(void*)f_7432},
{"f_7252support.scm",(void*)f_7252},
{"f_7416support.scm",(void*)f_7416},
{"f_7427support.scm",(void*)f_7427},
{"f_7420support.scm",(void*)f_7420},
{"f_7421support.scm",(void*)f_7421},
{"f_7357support.scm",(void*)f_7357},
{"f_7361support.scm",(void*)f_7361},
{"f_7364support.scm",(void*)f_7364},
{"f_7390support.scm",(void*)f_7390},
{"f_7406support.scm",(void*)f_7406},
{"f_7398support.scm",(void*)f_7398},
{"f_7382support.scm",(void*)f_7382},
{"f_7375support.scm",(void*)f_7375},
{"f_7376support.scm",(void*)f_7376},
{"f_7317support.scm",(void*)f_7317},
{"f_7320support.scm",(void*)f_7320},
{"f_7338support.scm",(void*)f_7338},
{"f_7331support.scm",(void*)f_7331},
{"f_7332support.scm",(void*)f_7332},
{"f_7301support.scm",(void*)f_7301},
{"f_7293support.scm",(void*)f_7293},
{"f_7286support.scm",(void*)f_7286},
{"f_7287support.scm",(void*)f_7287},
{"f_7265support.scm",(void*)f_7265},
{"f_7236support.scm",(void*)f_7236},
{"f_7117support.scm",(void*)f_7117},
{"f_7123support.scm",(void*)f_7123},
{"f_7135support.scm",(void*)f_7135},
{"f_7139support.scm",(void*)f_7139},
{"f_7142support.scm",(void*)f_7142},
{"f_7222support.scm",(void*)f_7222},
{"f_7206support.scm",(void*)f_7206},
{"f_7192support.scm",(void*)f_7192},
{"f_7184support.scm",(void*)f_7184},
{"f_7168support.scm",(void*)f_7168},
{"f_7172support.scm",(void*)f_7172},
{"f_7147support.scm",(void*)f_7147},
{"f_7160support.scm",(void*)f_7160},
{"f_7129support.scm",(void*)f_7129},
{"f_7063support.scm",(void*)f_7063},
{"f_7069support.scm",(void*)f_7069},
{"f_7095support.scm",(void*)f_7095},
{"f_7099support.scm",(void*)f_7099},
{"f_7087support.scm",(void*)f_7087},
{"f_6730support.scm",(void*)f_6730},
{"f_6736support.scm",(void*)f_6736},
{"f_7057support.scm",(void*)f_7057},
{"f_6740support.scm",(void*)f_6740},
{"f_7052support.scm",(void*)f_7052},
{"f_6743support.scm",(void*)f_6743},
{"f_7047support.scm",(void*)f_7047},
{"f_6746support.scm",(void*)f_6746},
{"f_6755support.scm",(void*)f_6755},
{"f_6989support.scm",(void*)f_6989},
{"f_7019support.scm",(void*)f_7019},
{"f_7015support.scm",(void*)f_7015},
{"f_6996support.scm",(void*)f_6996},
{"f_7000support.scm",(void*)f_7000},
{"f_6927support.scm",(void*)f_6927},
{"f_6976support.scm",(void*)f_6976},
{"f_6945support.scm",(void*)f_6945},
{"f_6953support.scm",(void*)f_6953},
{"f_6903support.scm",(void*)f_6903},
{"f_6870support.scm",(void*)f_6870},
{"f_6849support.scm",(void*)f_6849},
{"f_6845support.scm",(void*)f_6845},
{"f_6829support.scm",(void*)f_6829},
{"f_6841support.scm",(void*)f_6841},
{"f_6837support.scm",(void*)f_6837},
{"f_6783support.scm",(void*)f_6783},
{"f_6779support.scm",(void*)f_6779},
{"f_6762support.scm",(void*)f_6762},
{"f_6121support.scm",(void*)f_6121},
{"f_6725support.scm",(void*)f_6725},
{"f_6728support.scm",(void*)f_6728},
{"f_6124support.scm",(void*)f_6124},
{"f_6713support.scm",(void*)f_6713},
{"f_6714support.scm",(void*)f_6714},
{"f_6563support.scm",(void*)f_6563},
{"f_6620support.scm",(void*)f_6620},
{"f_6669support.scm",(void*)f_6669},
{"f_6664support.scm",(void*)f_6664},
{"f_6641support.scm",(void*)f_6641},
{"f_6648support.scm",(void*)f_6648},
{"f_6655support.scm",(void*)f_6655},
{"f_6645support.scm",(void*)f_6645},
{"f_6632support.scm",(void*)f_6632},
{"f_6633support.scm",(void*)f_6633},
{"f_6614support.scm",(void*)f_6614},
{"f_6600support.scm",(void*)f_6600},
{"f_6601support.scm",(void*)f_6601},
{"f_6578support.scm",(void*)f_6578},
{"f_6579support.scm",(void*)f_6579},
{"f_6542support.scm",(void*)f_6542},
{"f_6526support.scm",(void*)f_6526},
{"f_6522support.scm",(void*)f_6522},
{"f_6514support.scm",(void*)f_6514},
{"f_6480support.scm",(void*)f_6480},
{"f_6481support.scm",(void*)f_6481},
{"f_6452support.scm",(void*)f_6452},
{"f_6425support.scm",(void*)f_6425},
{"f_6426support.scm",(void*)f_6426},
{"f_6388support.scm",(void*)f_6388},
{"f_6372support.scm",(void*)f_6372},
{"f_6373support.scm",(void*)f_6373},
{"f_6340support.scm",(void*)f_6340},
{"f_6332support.scm",(void*)f_6332},
{"f_6276support.scm",(void*)f_6276},
{"f_6299support.scm",(void*)f_6299},
{"f_6289support.scm",(void*)f_6289},
{"f_6297support.scm",(void*)f_6297},
{"f_6280support.scm",(void*)f_6280},
{"f_6281support.scm",(void*)f_6281},
{"f_6222support.scm",(void*)f_6222},
{"f_6225support.scm",(void*)f_6225},
{"f_6232support.scm",(void*)f_6232},
{"f_6219support.scm",(void*)f_6219},
{"f_6194support.scm",(void*)f_6194},
{"f_6195support.scm",(void*)f_6195},
{"f_6166support.scm",(void*)f_6166},
{"f_6106support.scm",(void*)f_6106},
{"f_6115support.scm",(void*)f_6115},
{"f_6091support.scm",(void*)f_6091},
{"f_6100support.scm",(void*)f_6100},
{"f_6085support.scm",(void*)f_6085},
{"f_6076support.scm",(void*)f_6076},
{"f_6067support.scm",(void*)f_6067},
{"f_6058support.scm",(void*)f_6058},
{"f_6049support.scm",(void*)f_6049},
{"f_6040support.scm",(void*)f_6040},
{"f_6031support.scm",(void*)f_6031},
{"f_6025support.scm",(void*)f_6025},
{"f_6019support.scm",(void*)f_6019},
{"f_5529support.scm",(void*)f_5529},
{"f_6017support.scm",(void*)f_6017},
{"f_5533support.scm",(void*)f_5533},
{"f_5538support.scm",(void*)f_5538},
{"f_5548support.scm",(void*)f_5548},
{"f_5696support.scm",(void*)f_5696},
{"f_5706support.scm",(void*)f_5706},
{"f_5722support.scm",(void*)f_5722},
{"f_5795support.scm",(void*)f_5795},
{"f_5826support.scm",(void*)f_5826},
{"f_5816support.scm",(void*)f_5816},
{"f_5802support.scm",(void*)f_5802},
{"f_5806support.scm",(void*)f_5806},
{"f_5786support.scm",(void*)f_5786},
{"f_5776support.scm",(void*)f_5776},
{"f_5760support.scm",(void*)f_5760},
{"f_5737support.scm",(void*)f_5737},
{"f_5709support.scm",(void*)f_5709},
{"f_5551support.scm",(void*)f_5551},
{"f_5586support.scm",(void*)f_5586},
{"f_5617support.scm",(void*)f_5617},
{"f_5648support.scm",(void*)f_5648},
{"f_5669support.scm",(void*)f_5669},
{"f_5659support.scm",(void*)f_5659},
{"f_5664support.scm",(void*)f_5664},
{"f_5663support.scm",(void*)f_5663},
{"f_5638support.scm",(void*)f_5638},
{"f_5628support.scm",(void*)f_5628},
{"f_5633support.scm",(void*)f_5633},
{"f_5632support.scm",(void*)f_5632},
{"f_5607support.scm",(void*)f_5607},
{"f_5597support.scm",(void*)f_5597},
{"f_5602support.scm",(void*)f_5602},
{"f_5601support.scm",(void*)f_5601},
{"f_5554support.scm",(void*)f_5554},
{"f_5557support.scm",(void*)f_5557},
{"f_5560support.scm",(void*)f_5560},
{"f_5510support.scm",(void*)f_5510},
{"f_5516support.scm",(void*)f_5516},
{"f_5527support.scm",(void*)f_5527},
{"f_5486support.scm",(void*)f_5486},
{"f_5492support.scm",(void*)f_5492},
{"f_5502support.scm",(void*)f_5502},
{"f_5450support.scm",(void*)f_5450},
{"f_5457support.scm",(void*)f_5457},
{"f_5460support.scm",(void*)f_5460},
{"f_5440support.scm",(void*)f_5440},
{"f_5383support.scm",(void*)f_5383},
{"f_5387support.scm",(void*)f_5387},
{"f_5417support.scm",(void*)f_5417},
{"f_5331support.scm",(void*)f_5331},
{"f_5335support.scm",(void*)f_5335},
{"f_5362support.scm",(void*)f_5362},
{"f_5285support.scm",(void*)f_5285},
{"f_5289support.scm",(void*)f_5289},
{"f_5311support.scm",(void*)f_5311},
{"f_5267support.scm",(void*)f_5267},
{"f_5271support.scm",(void*)f_5271},
{"f_5279support.scm",(void*)f_5279},
{"f_5249support.scm",(void*)f_5249},
{"f_5253support.scm",(void*)f_5253},
{"f_5140support.scm",(void*)f_5140},
{"f_5195support.scm",(void*)f_5195},
{"f_5221support.scm",(void*)f_5221},
{"f_5225support.scm",(void*)f_5225},
{"f_5199support.scm",(void*)f_5199},
{"f_5202support.scm",(void*)f_5202},
{"f_5144support.scm",(void*)f_5144},
{"f_5150support.scm",(void*)f_5150},
{"f_5167support.scm",(void*)f_5167},
{"f_5171support.scm",(void*)f_5171},
{"f_5154support.scm",(void*)f_5154},
{"f_5147support.scm",(void*)f_5147},
{"f_4999support.scm",(void*)f_4999},
{"f_5003support.scm",(void*)f_5003},
{"f_5007support.scm",(void*)f_5007},
{"f_4996support.scm",(void*)f_4996},
{"f_4889support.scm",(void*)f_4889},
{"f_4898support.scm",(void*)f_4898},
{"f_4929support.scm",(void*)f_4929},
{"f_4983support.scm",(void*)f_4983},
{"f_4989support.scm",(void*)f_4989},
{"f_4935support.scm",(void*)f_4935},
{"f_4967support.scm",(void*)f_4967},
{"f_4981support.scm",(void*)f_4981},
{"f_4973support.scm",(void*)f_4973},
{"f_4939support.scm",(void*)f_4939},
{"f_4961support.scm",(void*)f_4961},
{"f_4904support.scm",(void*)f_4904},
{"f_4910support.scm",(void*)f_4910},
{"f_4921support.scm",(void*)f_4921},
{"f_4918support.scm",(void*)f_4918},
{"f_4896support.scm",(void*)f_4896},
{"f_4788support.scm",(void*)f_4788},
{"f_4794support.scm",(void*)f_4794},
{"f_4871support.scm",(void*)f_4871},
{"f_4822support.scm",(void*)f_4822},
{"f_4860support.scm",(void*)f_4860},
{"f_4848support.scm",(void*)f_4848},
{"f_4728support.scm",(void*)f_4728},
{"f_4744support.scm",(void*)f_4744},
{"f_4786support.scm",(void*)f_4786},
{"f_4750support.scm",(void*)f_4750},
{"f_4765support.scm",(void*)f_4765},
{"f_4682support.scm",(void*)f_4682},
{"f_4726support.scm",(void*)f_4726},
{"f_4686support.scm",(void*)f_4686},
{"f_4652support.scm",(void*)f_4652},
{"f_4606support.scm",(void*)f_4606},
{"f_4586support.scm",(void*)f_4586},
{"f_4592support.scm",(void*)f_4592},
{"f_4600support.scm",(void*)f_4600},
{"f_4604support.scm",(void*)f_4604},
{"f_4555support.scm",(void*)f_4555},
{"f_4561support.scm",(void*)f_4561},
{"f_4576support.scm",(void*)f_4576},
{"f_4492support.scm",(void*)f_4492},
{"f_4506support.scm",(void*)f_4506},
{"f_4508support.scm",(void*)f_4508},
{"f_4537support.scm",(void*)f_4537},
{"f_4516support.scm",(void*)f_4516},
{"f_4480support.scm",(void*)f_4480},
{"f_4433support.scm",(void*)f_4433},
{"f_4449support.scm",(void*)f_4449},
{"f_4461support.scm",(void*)f_4461},
{"f_4426support.scm",(void*)f_4426},
{"f_4419support.scm",(void*)f_4419},
{"f_4363support.scm",(void*)f_4363},
{"f_4417support.scm",(void*)f_4417},
{"f_4367support.scm",(void*)f_4367},
{"f_4390support.scm",(void*)f_4390},
{"f_4269support.scm",(void*)f_4269},
{"f_4285support.scm",(void*)f_4285},
{"f_4287support.scm",(void*)f_4287},
{"f_4309support.scm",(void*)f_4309},
{"f_4348support.scm",(void*)f_4348},
{"f_4316support.scm",(void*)f_4316},
{"f_4332support.scm",(void*)f_4332},
{"f_4320support.scm",(void*)f_4320},
{"f_4324support.scm",(void*)f_4324},
{"f_4281support.scm",(void*)f_4281},
{"f_4225support.scm",(void*)f_4225},
{"f_4231support.scm",(void*)f_4231},
{"f_4255support.scm",(void*)f_4255},
{"f_4200support.scm",(void*)f_4200},
{"f_4223support.scm",(void*)f_4223},
{"f_4179support.scm",(void*)f_4179},
{"f_4143support.scm",(void*)f_4143},
{"f_4149support.scm",(void*)f_4149},
{"f_4075support.scm",(void*)f_4075},
{"f_4099support.scm",(void*)f_4099},
{"f_4078support.scm",(void*)f_4078},
{"f_4086support.scm",(void*)f_4086},
{"f_4090support.scm",(void*)f_4090},
{"f_4032support.scm",(void*)f_4032},
{"f_4038support.scm",(void*)f_4038},
{"f_4061support.scm",(void*)f_4061},
{"f_4065support.scm",(void*)f_4065},
{"f_4029support.scm",(void*)f_4029},
{"f_4004support.scm",(void*)f_4004},
{"f_4008support.scm",(void*)f_4008},
{"f_4011support.scm",(void*)f_4011},
{"f_4022support.scm",(void*)f_4022},
{"f_4014support.scm",(void*)f_4014},
{"f_4017support.scm",(void*)f_4017},
{"f_3985support.scm",(void*)f_3985},
{"f_3989support.scm",(void*)f_3989},
{"f_4002support.scm",(void*)f_4002},
{"f_3992support.scm",(void*)f_3992},
{"f_3995support.scm",(void*)f_3995},
{"f_3956support.scm",(void*)f_3956},
{"f_3963support.scm",(void*)f_3963},
{"f_3966support.scm",(void*)f_3966},
{"f_3976support.scm",(void*)f_3976},
{"f_3969support.scm",(void*)f_3969},
{"f_3916support.scm",(void*)f_3916},
{"f_3926support.scm",(void*)f_3926},
{"f_3941support.scm",(void*)f_3941},
{"f_3946support.scm",(void*)f_3946},
{"f_3954support.scm",(void*)f_3954},
{"f_3929support.scm",(void*)f_3929},
{"f_3932support.scm",(void*)f_3932},
{"f_3935support.scm",(void*)f_3935},
{"f_3889support.scm",(void*)f_3889},
{"f_3903support.scm",(void*)f_3903},
{"f_3884support.scm",(void*)f_3884},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
