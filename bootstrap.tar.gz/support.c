/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-01-07 10:52
   Version 4.0.0x5 - SVN rev. 12936
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2009-01-05 on dill (Linux)
   command line: support.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[510];
static double C_possibly_force_alignment;


/* from k4427 */
static C_word C_fcall stub331(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub331(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4420 */
static C_word C_fcall stub326(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub326(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11871)
static void C_ccall f_11871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11885)
static void C_ccall f_11885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11889)
static void C_ccall f_11889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11900)
static void C_ccall f_11900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11912)
static void C_ccall f_11912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11920)
static void C_ccall f_11920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11924)
static void C_ccall f_11924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11883)
static void C_ccall f_11883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11874)
static void C_ccall f_11874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11877)
static void C_ccall f_11877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11858)
static void C_ccall f_11858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11863)
static void C_ccall f_11863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11847)
static void C_ccall f_11847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11852)
static void C_ccall f_11852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11841)
static void C_ccall f_11841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11813)
static void C_ccall f_11813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11813)
static void C_ccall f_11813r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11817)
static void C_ccall f_11817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11792)
static void C_ccall f_11792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11796)
static void C_ccall f_11796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11759)
static void C_ccall f_11759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11764)
static void C_ccall f_11764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11764)
static void C_ccall f_11764r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11768)
static void C_ccall f_11768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11726)
static void C_ccall f_11726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11731)
static void C_ccall f_11731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11731)
static void C_ccall f_11731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11735)
static void C_ccall f_11735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11702)
static void C_ccall f_11702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11633)
static void C_ccall f_11633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11637)
static void C_ccall f_11637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11642)
static void C_fcall f_11642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11646)
static void C_ccall f_11646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11676)
static void C_ccall f_11676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11688)
static void C_ccall f_11688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11691)
static void C_ccall f_11691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11664)
static void C_ccall f_11664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11600)
static void C_ccall f_11600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11610)
static void C_ccall f_11610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11613)
static void C_ccall f_11613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11498)
static void C_ccall f_11498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11507)
static void C_fcall f_11507(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11594)
static void C_ccall f_11594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11511)
static void C_ccall f_11511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11589)
static void C_ccall f_11589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11514)
static void C_ccall f_11514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11584)
static void C_ccall f_11584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11517)
static void C_ccall f_11517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11520)
static void C_ccall f_11520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11526)
static void C_ccall f_11526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11579)
static void C_ccall f_11579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11529)
static void C_ccall f_11529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11544)
static void C_ccall f_11544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11552)
static void C_fcall f_11552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11562)
static void C_ccall f_11562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11547)
static void C_ccall f_11547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11535)
static void C_ccall f_11535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11502)
static void C_ccall f_11502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11492)
static void C_ccall f_11492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11446)
static void C_ccall f_11446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11465)
static void C_ccall f_11465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11476)
static void C_ccall f_11476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11472)
static void C_ccall f_11472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11434)
static void C_ccall f_11434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11440)
static void C_ccall f_11440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11422)
static void C_ccall f_11422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11426)
static void C_ccall f_11426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11343)
static void C_ccall f_11343(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11343)
static void C_ccall f_11343r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11362)
static void C_ccall f_11362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11387)
static void C_ccall f_11387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11391)
static void C_ccall f_11391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11393)
static void C_fcall f_11393(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11400)
static void C_ccall f_11400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11413)
static void C_ccall f_11413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11346)
static void C_fcall f_11346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11350)
static void C_ccall f_11350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11356)
static void C_ccall f_11356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11337)
static void C_ccall f_11337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11293)
static void C_ccall f_11293(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11293)
static void C_ccall f_11293r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11309)
static void C_ccall f_11309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11313)
static void C_ccall f_11313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11301)
static void C_ccall f_11301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11284)
static void C_ccall f_11284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11278)
static void C_ccall f_11278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11272)
static void C_ccall f_11272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11260)
static void C_ccall f_11260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11264)
static void C_ccall f_11264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11267)
static void C_ccall f_11267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11222)
static void C_ccall f_11222(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11222)
static void C_ccall f_11222r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11226)
static void C_ccall f_11226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11229)
static void C_ccall f_11229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11236)
static void C_ccall f_11236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11180)
static void C_ccall f_11180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11189)
static void C_fcall f_11189(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11151)
static void C_ccall f_11151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11161)
static void C_fcall f_11161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10954)
static void C_ccall f_10954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11133)
static void C_ccall f_11133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11127)
static void C_ccall f_11127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11131)
static void C_ccall f_11131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11090)
static void C_ccall f_11090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11094)
static void C_ccall f_11094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11088)
static void C_ccall f_11088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11045)
static void C_fcall f_11045(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11049)
static void C_ccall f_11049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11062)
static void C_ccall f_11062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11052)
static void C_ccall f_11052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11010)
static void C_fcall f_11010(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11016)
static void C_fcall f_11016(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11043)
static void C_ccall f_11043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11029)
static void C_ccall f_11029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10963)
static void C_fcall f_10963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10969)
static void C_fcall f_10969(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11008)
static void C_ccall f_11008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10990)
static void C_ccall f_10990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_ccall f_10767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10949)
static void C_ccall f_10949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10936)
static void C_fcall f_10936(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10942)
static void C_ccall f_10942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10770)
static void C_fcall f_10770(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10930)
static void C_ccall f_10930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10925)
static void C_ccall f_10925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10777)
static void C_ccall f_10777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10920)
static void C_ccall f_10920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10780)
static void C_ccall f_10780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10789)
static void C_fcall f_10789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10883)
static void C_ccall f_10883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10853)
static void C_ccall f_10853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10864)
static void C_ccall f_10864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10844)
static void C_ccall f_10844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10830)
static void C_fcall f_10830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10808)
static void C_ccall f_10808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10814)
static void C_ccall f_10814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10818)
static void C_ccall f_10818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10674)
static void C_ccall f_10674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10680)
static void C_ccall f_10680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10761)
static void C_ccall f_10761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10684)
static void C_ccall f_10684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10756)
static void C_ccall f_10756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10687)
static void C_ccall f_10687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10740)
static void C_fcall f_10740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10726)
static void C_ccall f_10726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10708)
static void C_fcall f_10708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10702)
static void C_fcall f_10702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10678)
static void C_ccall f_10678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10382)
static void C_ccall f_10382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10578)
static void C_fcall f_10578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10599)
static void C_fcall f_10599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10072)
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10376)
static void C_ccall f_10376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10084)
static void C_ccall f_10084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10094)
static void C_fcall f_10094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10146)
static void C_fcall f_10146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10075)
static void C_fcall f_10075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9753)
static void C_ccall f_9753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9769)
static void C_fcall f_9769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9778)
static void C_fcall f_9778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9790)
static void C_fcall f_9790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9802)
static void C_fcall f_9802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9808)
static void C_ccall f_9808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9842)
static void C_fcall f_9842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9723)
static void C_ccall f_9723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9682)
static void C_ccall f_9682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9695)
static void C_ccall f_9695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9686)
static void C_fcall f_9686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9651)
static void C_ccall f_9651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9664)
static void C_ccall f_9664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9655)
static void C_fcall f_9655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8604)
static void C_ccall f_8604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9645)
static void C_ccall f_9645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8616)
static void C_fcall f_8616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8645)
static void C_fcall f_8645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_fcall f_8664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8683)
static void C_fcall f_8683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8753)
static void C_fcall f_8753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8772)
static void C_fcall f_8772(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8854)
static void C_fcall f_8854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8893)
static void C_fcall f_8893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8912)
static void C_fcall f_8912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8931)
static void C_fcall f_8931(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9011)
static void C_fcall f_9011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9096)
static void C_fcall f_9096(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9205)
static void C_fcall f_9205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9275)
static void C_ccall f_9275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9208)
static void C_ccall f_9208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9014)
static void C_ccall f_9014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9045)
static void C_fcall f_9045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8775)
static void C_ccall f_8775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8806)
static void C_fcall f_8806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8717)
static void C_fcall f_8717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8572)
static void C_ccall f_8572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8583)
static void C_ccall f_8583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8589)
static void C_ccall f_8589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_ccall f_8575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8541)
static void C_ccall f_8541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8551)
static void C_ccall f_8551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8557)
static void C_ccall f_8557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_ccall f_8560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8563)
static void C_ccall f_8563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8535)
static void C_ccall f_8535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8443)
static void C_ccall f_8443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8452)
static void C_ccall f_8452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8500)
static void C_ccall f_8500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8447)
static void C_ccall f_8447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8422)
static void C_ccall f_8422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8391)
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8397)
static void C_ccall f_8397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8404)
static void C_fcall f_8404(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8407)
static void C_ccall f_8407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8385)
static void C_ccall f_8385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8374)
static void C_ccall f_8374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8368)
static void C_ccall f_8368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8346)
static void C_ccall f_8346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8336)
static void C_ccall f_8336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8168)
static void C_ccall f_8168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8174)
static void C_ccall f_8174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8178)
static void C_ccall f_8178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8258)
static void C_ccall f_8258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8190)
static void C_fcall f_8190(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8216)
static void C_ccall f_8216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8152)
static void C_ccall f_8152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8148)
static void C_ccall f_8148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8023)
static void C_fcall f_8023(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8135)
static void C_ccall f_8135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8045)
static void C_ccall f_8045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8052)
static void C_ccall f_8052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8058)
static void C_fcall f_8058(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8089)
static void C_ccall f_8089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7980)
static void C_fcall f_7980(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7951)
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7891)
static void C_fcall f_7891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7895)
static void C_ccall f_7895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7720)
static void C_ccall f_7720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7751)
static void C_fcall f_7751(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_ccall f_7769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7831)
static void C_ccall f_7831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7784)
static void C_fcall f_7784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7681)
static void C_ccall f_7681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7666)
static void C_ccall f_7666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7593)
static void C_ccall f_7593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7615)
static void C_ccall f_7615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7628)
static void C_ccall f_7628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_ccall f_7623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7526)
static void C_ccall f_7526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static C_word C_fcall f_7537(C_word t0,C_word t1);
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7488)
static void C_fcall f_7488(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7502)
static void C_ccall f_7502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_ccall f_7506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7273)
static void C_fcall f_7273(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7283)
static void C_ccall f_7283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7388)
static void C_ccall f_7388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7318)
static void C_ccall f_7318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7267)
static void C_fcall f_7267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7148)
static void C_ccall f_7148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7170)
static void C_ccall f_7170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7173)
static void C_ccall f_7173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7237)
static void C_ccall f_7237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_ccall f_7215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7178)
static void C_ccall f_7178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7100)
static void C_fcall f_7100(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7126)
static void C_ccall f_7126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6774)
static void C_ccall f_6774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_fcall f_6786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_fcall f_7020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_fcall f_6958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6984)
static void C_ccall f_6984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6934)
static void C_ccall f_6934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6810)
static void C_ccall f_6810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6155)
static void C_ccall f_6155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6594)
static void C_fcall f_6594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6672)
static void C_fcall f_6672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6609)
static void C_ccall f_6609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6557)
static void C_ccall f_6557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6456)
static void C_ccall f_6456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6419)
static void C_fcall f_6419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_ccall f_6328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6253)
static void C_fcall f_6253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6256)
static void C_ccall f_6256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_fcall f_6250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6226)
static void C_ccall f_6226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_fcall f_5576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_fcall f_5739(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_fcall f_5765(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_fcall f_5838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_fcall f_5629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5660)
static void C_fcall f_5660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_fcall f_5691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5676)
static void C_ccall f_5676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5535)
static void C_fcall f_5535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_fcall f_5503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5374)
static void C_ccall f_5374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4792)
static void C_fcall f_4792(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_fcall f_4820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4559)
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_fcall f_4506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_fcall f_4514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_fcall f_4459(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_fcall f_4285(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4307)
static void C_fcall f_4307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_fcall f_4314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4229)
static void C_fcall f_4229(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4147)
static C_word C_fcall f_4147(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4097)
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4076)
static void C_fcall f_4076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4036)
static void C_fcall f_4036(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3961)
static void C_fcall f_3961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11642)
static void C_fcall trf_11642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11642(t0,t1);}

C_noret_decl(trf_11507)
static void C_fcall trf_11507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11507(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11507(t0,t1,t2,t3);}

C_noret_decl(trf_11552)
static void C_fcall trf_11552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11552(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11552(t0,t1,t2);}

C_noret_decl(trf_11393)
static void C_fcall trf_11393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11393(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11393(t0,t1,t2,t3);}

C_noret_decl(trf_11346)
static void C_fcall trf_11346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11346(t0,t1);}

C_noret_decl(trf_11189)
static void C_fcall trf_11189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11189(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11189(t0,t1,t2);}

C_noret_decl(trf_11161)
static void C_fcall trf_11161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11161(t0,t1);}

C_noret_decl(trf_11045)
static void C_fcall trf_11045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11045(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11045(t0,t1,t2,t3);}

C_noret_decl(trf_11010)
static void C_fcall trf_11010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11010(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11010(t0,t1,t2);}

C_noret_decl(trf_11016)
static void C_fcall trf_11016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11016(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11016(t0,t1,t2);}

C_noret_decl(trf_10963)
static void C_fcall trf_10963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10963(t0,t1,t2,t3);}

C_noret_decl(trf_10969)
static void C_fcall trf_10969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10969(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10969(t0,t1,t2);}

C_noret_decl(trf_10936)
static void C_fcall trf_10936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10936(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10936(t0,t1,t2,t3);}

C_noret_decl(trf_10770)
static void C_fcall trf_10770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10770(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10770(t0,t1,t2,t3);}

C_noret_decl(trf_10789)
static void C_fcall trf_10789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10789(t0,t1);}

C_noret_decl(trf_10830)
static void C_fcall trf_10830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10830(t0,t1);}

C_noret_decl(trf_10740)
static void C_fcall trf_10740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10740(t0,t1);}

C_noret_decl(trf_10708)
static void C_fcall trf_10708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10708(t0,t1);}

C_noret_decl(trf_10702)
static void C_fcall trf_10702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10702(t0,t1);}

C_noret_decl(trf_10578)
static void C_fcall trf_10578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10578(t0,t1);}

C_noret_decl(trf_10599)
static void C_fcall trf_10599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10599(t0,t1);}

C_noret_decl(trf_10094)
static void C_fcall trf_10094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10094(t0,t1);}

C_noret_decl(trf_10146)
static void C_fcall trf_10146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10146(t0,t1);}

C_noret_decl(trf_10075)
static void C_fcall trf_10075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10075(t0,t1);}

C_noret_decl(trf_9769)
static void C_fcall trf_9769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9769(t0,t1);}

C_noret_decl(trf_9778)
static void C_fcall trf_9778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9778(t0,t1);}

C_noret_decl(trf_9790)
static void C_fcall trf_9790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9790(t0,t1);}

C_noret_decl(trf_9802)
static void C_fcall trf_9802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9802(t0,t1);}

C_noret_decl(trf_9842)
static void C_fcall trf_9842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9842(t0,t1);}

C_noret_decl(trf_9686)
static void C_fcall trf_9686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9686(t0,t1);}

C_noret_decl(trf_9655)
static void C_fcall trf_9655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9655(t0,t1);}

C_noret_decl(trf_8616)
static void C_fcall trf_8616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8616(t0,t1,t2);}

C_noret_decl(trf_8645)
static void C_fcall trf_8645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8645(t0,t1);}

C_noret_decl(trf_8664)
static void C_fcall trf_8664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8664(t0,t1);}

C_noret_decl(trf_8683)
static void C_fcall trf_8683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8683(t0,t1);}

C_noret_decl(trf_8753)
static void C_fcall trf_8753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8753(t0,t1);}

C_noret_decl(trf_8772)
static void C_fcall trf_8772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8772(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8772(t0,t1);}

C_noret_decl(trf_8854)
static void C_fcall trf_8854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8854(t0,t1);}

C_noret_decl(trf_8893)
static void C_fcall trf_8893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8893(t0,t1);}

C_noret_decl(trf_8912)
static void C_fcall trf_8912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8912(t0,t1);}

C_noret_decl(trf_8931)
static void C_fcall trf_8931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8931(t0,t1);}

C_noret_decl(trf_9011)
static void C_fcall trf_9011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9011(t0,t1);}

C_noret_decl(trf_9096)
static void C_fcall trf_9096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9096(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9096(t0,t1);}

C_noret_decl(trf_9205)
static void C_fcall trf_9205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9205(t0,t1);}

C_noret_decl(trf_9045)
static void C_fcall trf_9045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9045(t0,t1);}

C_noret_decl(trf_8806)
static void C_fcall trf_8806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8806(t0,t1);}

C_noret_decl(trf_8717)
static void C_fcall trf_8717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8717(t0,t1);}

C_noret_decl(trf_8404)
static void C_fcall trf_8404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8404(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8404(t0,t1);}

C_noret_decl(trf_8190)
static void C_fcall trf_8190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8190(t0,t1);}

C_noret_decl(trf_8023)
static void C_fcall trf_8023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8023(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8023(t0,t1,t2,t3);}

C_noret_decl(trf_8058)
static void C_fcall trf_8058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8058(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8058(t0,t1,t2,t3);}

C_noret_decl(trf_7980)
static void C_fcall trf_7980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7980(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7980(t0,t1,t2,t3);}

C_noret_decl(trf_7951)
static void C_fcall trf_7951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7951(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7951(t0,t1,t2,t3);}

C_noret_decl(trf_7891)
static void C_fcall trf_7891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7891(t0,t1);}

C_noret_decl(trf_7751)
static void C_fcall trf_7751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7751(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7751(t0,t1);}

C_noret_decl(trf_7784)
static void C_fcall trf_7784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7784(t0,t1);}

C_noret_decl(trf_7488)
static void C_fcall trf_7488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7488(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7488(t0,t1,t2);}

C_noret_decl(trf_7273)
static void C_fcall trf_7273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7273(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7273(t0,t1,t2,t3);}

C_noret_decl(trf_7267)
static void C_fcall trf_7267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7267(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7267(t0,t1,t2);}

C_noret_decl(trf_7100)
static void C_fcall trf_7100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7100(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7100(t0,t1,t2);}

C_noret_decl(trf_6786)
static void C_fcall trf_6786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6786(t0,t1);}

C_noret_decl(trf_7020)
static void C_fcall trf_7020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7020(t0,t1);}

C_noret_decl(trf_6958)
static void C_fcall trf_6958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6958(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6958(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6594)
static void C_fcall trf_6594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6594(t0,t1);}

C_noret_decl(trf_6672)
static void C_fcall trf_6672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6672(t0,t1);}

C_noret_decl(trf_6419)
static void C_fcall trf_6419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6419(t0,t1);}

C_noret_decl(trf_6253)
static void C_fcall trf_6253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6253(t0,t1);}

C_noret_decl(trf_6250)
static void C_fcall trf_6250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6250(t0,t1);}

C_noret_decl(trf_5576)
static void C_fcall trf_5576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5576(t0,t1);}

C_noret_decl(trf_5739)
static void C_fcall trf_5739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5739(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5739(t0,t1,t2);}

C_noret_decl(trf_5765)
static void C_fcall trf_5765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5765(t0,t1);}

C_noret_decl(trf_5838)
static void C_fcall trf_5838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5838(t0,t1);}

C_noret_decl(trf_5629)
static void C_fcall trf_5629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5629(t0,t1);}

C_noret_decl(trf_5660)
static void C_fcall trf_5660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5660(t0,t1);}

C_noret_decl(trf_5691)
static void C_fcall trf_5691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5691(t0,t1);}

C_noret_decl(trf_5535)
static void C_fcall trf_5535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5535(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5535(t0,t1,t2);}

C_noret_decl(trf_5503)
static void C_fcall trf_5503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5503(t0,t1);}

C_noret_decl(trf_4792)
static void C_fcall trf_4792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4792(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4792(t0,t1,t2);}

C_noret_decl(trf_4820)
static void C_fcall trf_4820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4820(t0,t1);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4684(t0,t1);}

C_noret_decl(trf_4559)
static void C_fcall trf_4559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4559(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4559(t0,t1,t2,t3);}

C_noret_decl(trf_4506)
static void C_fcall trf_4506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4506(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4506(t0,t1,t2);}

C_noret_decl(trf_4514)
static void C_fcall trf_4514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4514(t0,t1);}

C_noret_decl(trf_4459)
static void C_fcall trf_4459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4459(t0,t1);}

C_noret_decl(trf_4285)
static void C_fcall trf_4285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4285(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4285(t0,t1,t2);}

C_noret_decl(trf_4307)
static void C_fcall trf_4307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4307(t0,t1);}

C_noret_decl(trf_4314)
static void C_fcall trf_4314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4314(t0,t1);}

C_noret_decl(trf_4229)
static void C_fcall trf_4229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4229(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4229(t0,t1,t2,t3);}

C_noret_decl(trf_4097)
static void C_fcall trf_4097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4097(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4097(t0,t1,t2,t3);}

C_noret_decl(trf_4076)
static void C_fcall trf_4076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4076(t0,t1);}

C_noret_decl(trf_4036)
static void C_fcall trf_4036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4036(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4036(t0,t1,t2);}

C_noret_decl(trf_3961)
static void C_fcall trf_3961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3961(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5190)){
C_save(t1);
C_rereclaim2(5190*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,510);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],12,"flush-output");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],6,"printf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[15]=C_h_intern(&lf[15],5,"force");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[20]=C_h_intern(&lf[20],25,"\010compilercompiler-warning");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],20,"\003syswarnings-enabled");
lf[25]=C_h_intern(&lf[25],4,"quit");
lf[26]=C_h_intern(&lf[26],4,"exit");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[28]=C_h_intern(&lf[28],21,"\003syssyntax-error-hook");
lf[29]=C_h_intern(&lf[29],16,"print-call-chain");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[34]=C_h_intern(&lf[34],12,"syntax-error");
lf[35]=C_h_intern(&lf[35],31,"\010compileremit-syntax-trace-info");
lf[36]=C_h_intern(&lf[36],9,"map-llist");
lf[37]=C_h_intern(&lf[37],24,"\010compilercheck-signature");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[39]=C_h_intern(&lf[39],18,"\010compilerreal-name");
lf[40]=C_h_intern(&lf[40],13,"\010compilerposq");
lf[41]=C_h_intern(&lf[41],18,"\010compilerstringify");
lf[42]=C_h_intern(&lf[42],14,"symbol->string");
lf[43]=C_h_intern(&lf[43],7,"sprintf");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[45]=C_h_intern(&lf[45],18,"\010compilersymbolify");
lf[46]=C_h_intern(&lf[46],14,"string->symbol");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[48]=C_h_intern(&lf[48],26,"\010compilerbuild-lambda-list");
lf[49]=C_h_intern(&lf[49],29,"\010compilerstring->c-identifier");
lf[50]=C_h_intern(&lf[50],24,"\003sysstring->c-identifier");
lf[51]=C_h_intern(&lf[51],21,"\010compilerc-ify-string");
lf[52]=C_h_intern(&lf[52],16,"\003syslist->string");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[54]=C_h_intern(&lf[54],6,"append");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[56]=C_h_intern(&lf[56],16,"\003sysstring->list");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[60]=C_h_intern(&lf[60],28,"\010compilervalid-c-identifier\077");
lf[61]=C_h_intern(&lf[61],3,"any");
lf[62]=C_h_intern(&lf[62],8,"->string");
lf[63]=C_h_intern(&lf[63],14,"\010compilerwords");
lf[64]=C_h_intern(&lf[64],21,"\010compilerwords->bytes");
lf[65]=C_h_intern(&lf[65],34,"\010compilercheck-and-open-input-file");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[67]=C_h_intern(&lf[67],18,"current-input-port");
lf[68]=C_h_intern(&lf[68],15,"open-input-file");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[71]=C_h_intern(&lf[71],12,"file-exists\077");
lf[72]=C_h_intern(&lf[72],33,"\010compilerclose-checked-input-file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[74]=C_h_intern(&lf[74],16,"close-input-port");
lf[75]=C_h_intern(&lf[75],19,"\010compilerfold-inner");
lf[76]=C_h_intern(&lf[76],7,"reverse");
lf[77]=C_h_intern(&lf[77],28,"\010compilerfollow-without-loop");
lf[78]=C_h_intern(&lf[78],21,"\010compilersort-symbols");
lf[79]=C_h_intern(&lf[79],8,"string<\077");
lf[80]=C_h_intern(&lf[80],4,"sort");
lf[81]=C_h_intern(&lf[81],18,"\010compilerconstant\077");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],29,"\010compilercollapsable-literal\077");
lf[84]=C_h_intern(&lf[84],19,"\010compilerimmediate\077");
lf[85]=C_h_intern(&lf[85],20,"\010compilerbig-fixnum\077");
lf[86]=C_h_intern(&lf[86],23,"\010compilerbasic-literal\077");
lf[87]=C_h_intern(&lf[87],5,"every");
lf[88]=C_h_intern(&lf[88],12,"vector->list");
lf[89]=C_h_intern(&lf[89],32,"\010compilercanonicalize-begin-body");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_h_intern(&lf[92],3,"let");
lf[93]=C_h_intern(&lf[93],6,"gensym");
lf[94]=C_h_intern(&lf[94],1,"t");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[96]=C_h_intern(&lf[96],21,"\010compilerstring->expr");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[99]=C_h_intern(&lf[99],5,"begin");
lf[100]=C_h_intern(&lf[100],10,"\003sysappend");
lf[101]=C_h_intern(&lf[101],4,"read");
lf[102]=C_h_intern(&lf[102],6,"unfold");
lf[103]=C_h_intern(&lf[103],11,"eof-object\077");
lf[104]=C_h_intern(&lf[104],6,"values");
lf[105]=C_h_intern(&lf[105],22,"with-input-from-string");
lf[106]=C_h_intern(&lf[106],22,"with-exception-handler");
lf[107]=C_h_intern(&lf[107],30,"call-with-current-continuation");
lf[108]=C_h_intern(&lf[108],30,"\010compilerdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],25,"\003sysdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],37,"\010compilerprocess-lambda-documentation");
lf[111]=C_h_intern(&lf[111],21,"\010compilerllist-length");
lf[112]=C_h_intern(&lf[112],30,"\010compilerexpand-profile-lambda");
lf[113]=C_h_intern(&lf[113],29,"\010compilerprofile-lambda-index");
lf[114]=C_h_intern(&lf[114],28,"\010compilerprofile-lambda-list");
lf[115]=C_h_intern(&lf[115],33,"\010compilerprofile-info-vector-name");
lf[116]=C_h_intern(&lf[116],17,"\003sysprofile-entry");
lf[117]=C_h_intern(&lf[117],6,"lambda");
lf[118]=C_h_intern(&lf[118],5,"apply");
lf[119]=C_h_intern(&lf[119],16,"\003sysprofile-exit");
lf[120]=C_h_intern(&lf[120],16,"\003sysdynamic-wind");
lf[121]=C_h_intern(&lf[121],10,"alist-cons");
lf[122]=C_h_intern(&lf[122],37,"\010compilerinitialize-analysis-database");
lf[123]=C_h_intern(&lf[123],8,"\003sysput!");
lf[124]=C_h_intern(&lf[124],9,"\003syserror");
lf[125]=C_h_intern(&lf[125],18,"\010compilerintrinsic");
lf[126]=C_h_intern(&lf[126],8,"internal");
lf[127]=C_h_intern(&lf[127],26,"\010compilerinternal-bindings");
lf[128]=C_h_intern(&lf[128],8,"extended");
lf[129]=C_h_intern(&lf[129],17,"extended-bindings");
lf[130]=C_h_intern(&lf[130],26,"\010compilerfoldable-bindings");
lf[131]=C_h_intern(&lf[131],17,"\010compilerfoldable");
lf[132]=C_h_intern(&lf[132],8,"standard");
lf[133]=C_h_intern(&lf[133],17,"standard-bindings");
lf[134]=C_h_intern(&lf[134],12,"\010compilerget");
lf[135]=C_h_intern(&lf[135],18,"\003syshash-table-ref");
lf[136]=C_h_intern(&lf[136],16,"\010compilerget-all");
lf[137]=C_h_intern(&lf[137],10,"filter-map");
lf[138]=C_h_intern(&lf[138],13,"\010compilerput!");
lf[139]=C_h_intern(&lf[139],19,"\003syshash-table-set!");
lf[140]=C_h_intern(&lf[140],17,"\010compilercollect!");
lf[141]=C_h_intern(&lf[141],15,"\010compilercount!");
lf[142]=C_h_intern(&lf[142],17,"\010compilerget-line");
lf[143]=C_h_intern(&lf[143],24,"\003sysline-number-database");
lf[144]=C_h_intern(&lf[144],19,"\010compilerget-line-2");
lf[145]=C_h_intern(&lf[145],30,"\010compilerfind-lambda-container");
lf[146]=C_h_intern(&lf[146],12,"contained-in");
lf[147]=C_h_intern(&lf[147],37,"\010compilerdisplay-line-number-database");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[149]=C_h_intern(&lf[149],7,"\003sysmap");
lf[150]=C_h_intern(&lf[150],3,"cdr");
lf[151]=C_h_intern(&lf[151],23,"\003syshash-table-for-each");
lf[152]=C_h_intern(&lf[152],34,"\010compilerdisplay-analysis-database");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\010\011lval=~s");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[158]=C_h_intern(&lf[158],7,"unknown");
lf[159]=C_h_intern(&lf[159],8,"captured");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\011undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003"
"uud\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[162]=C_h_intern(&lf[162],4,"caar");
lf[163]=C_h_intern(&lf[163],5,"value");
lf[164]=C_h_intern(&lf[164],4,"cdar");
lf[165]=C_h_intern(&lf[165],11,"local-value");
lf[166]=C_h_intern(&lf[166],15,"potential-value");
lf[167]=C_h_intern(&lf[167],10,"replacable");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[169]=C_h_intern(&lf[169],10,"references");
lf[170]=C_h_intern(&lf[170],10,"call-sites");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[172]=C_h_intern(&lf[172],4,"home");
lf[173]=C_h_intern(&lf[173],8,"contains");
lf[174]=C_h_intern(&lf[174],8,"use-expr");
lf[175]=C_h_intern(&lf[175],12,"closure-size");
lf[176]=C_h_intern(&lf[176],14,"rest-parameter");
lf[177]=C_h_intern(&lf[177],16,"o-r/access-count");
lf[178]=C_h_intern(&lf[178],18,"captured-variables");
lf[179]=C_h_intern(&lf[179],13,"explicit-rest");
lf[180]=C_h_intern(&lf[180],8,"assigned");
lf[181]=C_h_intern(&lf[181],5,"boxed");
lf[182]=C_h_intern(&lf[182],6,"global");
lf[183]=C_h_intern(&lf[183],12,"contractable");
lf[184]=C_h_intern(&lf[184],16,"standard-binding");
lf[185]=C_h_intern(&lf[185],16,"assigned-locally");
lf[186]=C_h_intern(&lf[186],11,"collapsable");
lf[187]=C_h_intern(&lf[187],9,"removable");
lf[188]=C_h_intern(&lf[188],9,"undefined");
lf[189]=C_h_intern(&lf[189],9,"replacing");
lf[190]=C_h_intern(&lf[190],6,"unused");
lf[191]=C_h_intern(&lf[191],6,"simple");
lf[192]=C_h_intern(&lf[192],9,"inlinable");
lf[193]=C_h_intern(&lf[193],13,"inline-export");
lf[194]=C_h_intern(&lf[194],21,"has-unused-parameters");
lf[195]=C_h_intern(&lf[195],16,"extended-binding");
lf[196]=C_h_intern(&lf[196],12,"customizable");
lf[197]=C_h_intern(&lf[197],8,"constant");
lf[198]=C_h_intern(&lf[198],10,"boxed-rest");
lf[199]=C_h_intern(&lf[199],11,"hidden-refs");
lf[200]=C_h_intern(&lf[200],5,"write");
lf[201]=C_h_intern(&lf[201],34,"\010compilerdefault-standard-bindings");
lf[202]=C_h_intern(&lf[202],34,"\010compilerdefault-extended-bindings");
lf[203]=C_h_intern(&lf[203],9,"make-node");
lf[204]=C_h_intern(&lf[204],4,"node");
lf[205]=C_h_intern(&lf[205],5,"node\077");
lf[206]=C_h_intern(&lf[206],15,"node-class-set!");
lf[207]=C_h_intern(&lf[207],14,"\003sysblock-set!");
lf[208]=C_h_intern(&lf[208],10,"node-class");
lf[209]=C_h_intern(&lf[209],20,"node-parameters-set!");
lf[210]=C_h_intern(&lf[210],15,"node-parameters");
lf[211]=C_h_intern(&lf[211],24,"node-subexpressions-set!");
lf[212]=C_h_intern(&lf[212],19,"node-subexpressions");
lf[213]=C_h_intern(&lf[213],16,"\010compilervarnode");
lf[214]=C_h_intern(&lf[214],13,"\004corevariable");
lf[215]=C_h_intern(&lf[215],14,"\010compilerqnode");
lf[216]=C_h_intern(&lf[216],25,"\010compilerbuild-node-graph");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[218]=C_h_intern(&lf[218],15,"\004coreglobal-ref");
lf[219]=C_h_intern(&lf[219],2,"if");
lf[220]=C_h_intern(&lf[220],14,"\004coreundefined");
lf[221]=C_h_intern(&lf[221],8,"truncate");
lf[222]=C_h_intern(&lf[222],4,"type");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[224]=C_h_intern(&lf[224],6,"fixnum");
lf[225]=C_h_intern(&lf[225],11,"number-type");
lf[226]=C_h_intern(&lf[226],6,"unzip1");
lf[227]=C_h_intern(&lf[227],11,"\004corelambda");
lf[228]=C_h_intern(&lf[228],14,"\004coreprimitive");
lf[229]=C_h_intern(&lf[229],11,"\004coreinline");
lf[230]=C_h_intern(&lf[230],13,"\004corecallunit");
lf[231]=C_h_intern(&lf[231],9,"\004coreproc");
lf[232]=C_h_intern(&lf[232],4,"set!");
lf[233]=C_h_intern(&lf[233],9,"\004coreset!");
lf[234]=C_h_intern(&lf[234],29,"\004coreforeign-callback-wrapper");
lf[235]=C_h_intern(&lf[235],5,"sixth");
lf[236]=C_h_intern(&lf[236],5,"fifth");
lf[237]=C_h_intern(&lf[237],20,"\004coreinline_allocate");
lf[238]=C_h_intern(&lf[238],8,"\004coreapp");
lf[239]=C_h_intern(&lf[239],9,"\004corecall");
lf[240]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[241]=C_h_intern(&lf[241],24,"\010compilersource-filename");
lf[242]=C_h_intern(&lf[242],28,"\003syssymbol->qualified-string");
lf[243]=C_h_intern(&lf[243],7,"\003sysget");
lf[244]=C_h_intern(&lf[244],34,"\010compileralways-bound-to-procedure");
lf[245]=C_h_intern(&lf[245],15,"\004coreinline_ref");
lf[246]=C_h_intern(&lf[246],18,"\004coreinline_update");
lf[247]=C_h_intern(&lf[247],19,"\004coreinline_loc_ref");
lf[248]=C_h_intern(&lf[248],22,"\004coreinline_loc_update");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[250]=C_h_intern(&lf[250],1,"o");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[252]=C_h_intern(&lf[252],30,"\010compilerbuild-expression-tree");
lf[253]=C_h_intern(&lf[253],12,"\004coreclosure");
lf[254]=C_h_intern(&lf[254],4,"last");
lf[255]=C_h_intern(&lf[255],3,"map");
lf[256]=C_h_intern(&lf[256],4,"list");
lf[257]=C_h_intern(&lf[257],7,"butlast");
lf[258]=C_h_intern(&lf[258],5,"cons*");
lf[259]=C_h_intern(&lf[259],9,"\004corebind");
lf[260]=C_h_intern(&lf[260],10,"\004coreunbox");
lf[261]=C_h_intern(&lf[261],8,"\004coreref");
lf[262]=C_h_intern(&lf[262],11,"\004coreupdate");
lf[263]=C_h_intern(&lf[263],13,"\004coreupdate_i");
lf[264]=C_h_intern(&lf[264],8,"\004corebox");
lf[265]=C_h_intern(&lf[265],9,"\004corecond");
lf[266]=C_h_intern(&lf[266],21,"\010compilerfold-boolean");
lf[267]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[268]=C_h_intern(&lf[268],31,"\010compilerinline-lambda-bindings");
lf[269]=C_h_intern(&lf[269],8,"split-at");
lf[270]=C_h_intern(&lf[270],10,"fold-right");
lf[271]=C_h_intern(&lf[271],4,"take");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[273]=C_h_intern(&lf[273],34,"\010compilercopy-node-tree-and-rename");
lf[274]=C_h_intern(&lf[274],9,"alist-ref");
lf[275]=C_h_intern(&lf[275],3,"eq\077");
lf[276]=C_h_intern(&lf[276],1,"f");
lf[277]=C_h_intern(&lf[277],18,"\010compilertree-copy");
lf[278]=C_h_intern(&lf[278],4,"cons");
lf[279]=C_h_intern(&lf[279],19,"\010compilercopy-node!");
lf[280]=C_h_intern(&lf[280],20,"\010compilernode->sexpr");
lf[281]=C_h_intern(&lf[281],20,"\010compilersexpr->node");
lf[282]=C_h_intern(&lf[282],32,"\010compileremit-global-inline-file");
lf[283]=C_h_intern(&lf[283],5,"print");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[285]=C_h_intern(&lf[285],1,"i");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[288]=C_h_intern(&lf[288],2,"pp");
lf[289]=C_h_intern(&lf[289],3,"yes");
lf[290]=C_h_intern(&lf[290],2,"no");
lf[291]=C_h_intern(&lf[291],24,"\010compilerinline-max-size");
lf[292]=C_h_intern(&lf[292],15,"\010compilerinline");
lf[293]=C_h_intern(&lf[293],22,"\010compilerinline-global");
lf[294]=C_h_intern(&lf[294],26,"\010compilervariable-visible\077");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[298]=C_h_intern(&lf[298],15,"chicken-version");
lf[299]=C_h_intern(&lf[299],19,"with-output-to-file");
lf[300]=C_h_intern(&lf[300],25,"\010compilerload-inline-file");
lf[301]=C_h_intern(&lf[301],20,"with-input-from-file");
lf[302]=C_h_intern(&lf[302],19,"\010compilermatch-node");
lf[303]=C_h_intern(&lf[303],1,"a");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[305]=C_h_intern(&lf[305],37,"\010compilerexpression-has-side-effects\077");
lf[306]=C_h_intern(&lf[306],24,"foreign-callback-stub-id");
lf[307]=C_h_intern(&lf[307],4,"find");
lf[308]=C_h_intern(&lf[308],22,"foreign-callback-stubs");
lf[309]=C_h_intern(&lf[309],28,"\010compilersimple-lambda-node\077");
lf[310]=C_h_intern(&lf[310],31,"\010compilerdump-undefined-globals");
lf[311]=C_h_intern(&lf[311],28,"\003systoplevel-definition-hook");
lf[312]=C_h_intern(&lf[312],22,"\010compilerhide-variable");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[314]=C_h_intern(&lf[314],36,"\010compilercompute-database-statistics");
lf[315]=C_h_intern(&lf[315],29,"\010compilercurrent-program-size");
lf[316]=C_h_intern(&lf[316],30,"\010compileroriginal-program-size");
lf[317]=C_h_intern(&lf[317],33,"\010compilerprint-program-statistics");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[324]=C_h_intern(&lf[324],1,"s");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[326]=C_h_intern(&lf[326],35,"\010compilerpprint-expressions-to-file");
lf[327]=C_h_intern(&lf[327],17,"close-output-port");
lf[328]=C_h_intern(&lf[328],12,"pretty-print");
lf[329]=C_h_intern(&lf[329],19,"with-output-to-port");
lf[330]=C_h_intern(&lf[330],16,"open-output-file");
lf[331]=C_h_intern(&lf[331],19,"current-output-port");
lf[332]=C_h_intern(&lf[332],27,"\010compilerforeign-type-check");
lf[333]=C_h_intern(&lf[333],4,"char");
lf[334]=C_h_intern(&lf[334],13,"unsigned-char");
lf[335]=C_h_intern(&lf[335],6,"unsafe");
lf[336]=C_h_intern(&lf[336],25,"\003sysforeign-char-argument");
lf[337]=C_h_intern(&lf[337],3,"int");
lf[338]=C_h_intern(&lf[338],27,"\003sysforeign-fixnum-argument");
lf[339]=C_h_intern(&lf[339],5,"float");
lf[340]=C_h_intern(&lf[340],27,"\003sysforeign-flonum-argument");
lf[341]=C_h_intern(&lf[341],7,"pointer");
lf[342]=C_h_intern(&lf[342],26,"\003sysforeign-block-argument");
lf[343]=C_h_intern(&lf[343],15,"nonnull-pointer");
lf[344]=C_h_intern(&lf[344],8,"u8vector");
lf[345]=C_h_intern(&lf[345],34,"\003sysforeign-number-vector-argument");
lf[346]=C_h_intern(&lf[346],16,"nonnull-u8vector");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[348]=C_h_intern(&lf[348],7,"integer");
lf[349]=C_h_intern(&lf[349],28,"\003sysforeign-integer-argument");
lf[350]=C_h_intern(&lf[350],16,"unsigned-integer");
lf[351]=C_h_intern(&lf[351],37,"\003sysforeign-unsigned-integer-argument");
lf[352]=C_h_intern(&lf[352],9,"c-pointer");
lf[353]=C_h_intern(&lf[353],28,"\003sysforeign-pointer-argument");
lf[354]=C_h_intern(&lf[354],17,"nonnull-c-pointer");
lf[355]=C_h_intern(&lf[355],8,"c-string");
lf[356]=C_h_intern(&lf[356],17,"\003sysmake-c-string");
lf[357]=C_h_intern(&lf[357],27,"\003sysforeign-string-argument");
lf[358]=C_h_intern(&lf[358],16,"nonnull-c-string");
lf[359]=C_h_intern(&lf[359],6,"symbol");
lf[360]=C_h_intern(&lf[360],18,"\003syssymbol->string");
lf[361]=C_h_intern(&lf[361],3,"ref");
lf[362]=C_h_intern(&lf[362],8,"instance");
lf[363]=C_h_intern(&lf[363],12,"instance-ref");
lf[364]=C_h_intern(&lf[364],4,"this");
lf[365]=C_h_intern(&lf[365],8,"slot-ref");
lf[366]=C_h_intern(&lf[366],16,"nonnull-instance");
lf[367]=C_h_intern(&lf[367],5,"const");
lf[368]=C_h_intern(&lf[368],4,"enum");
lf[369]=C_h_intern(&lf[369],8,"function");
lf[370]=C_h_intern(&lf[370],27,"\010compilerforeign-type-table");
lf[371]=C_h_intern(&lf[371],17,"nonnull-c-string*");
lf[372]=C_h_intern(&lf[372],26,"nonnull-unsigned-c-string*");
lf[373]=C_h_intern(&lf[373],9,"c-string*");
lf[374]=C_h_intern(&lf[374],18,"unsigned-c-string*");
lf[375]=C_h_intern(&lf[375],13,"c-string-list");
lf[376]=C_h_intern(&lf[376],14,"c-string-list*");
lf[377]=C_h_intern(&lf[377],18,"unsigned-integer32");
lf[378]=C_h_intern(&lf[378],13,"unsigned-long");
lf[379]=C_h_intern(&lf[379],4,"long");
lf[380]=C_h_intern(&lf[380],9,"integer32");
lf[381]=C_h_intern(&lf[381],17,"nonnull-u16vector");
lf[382]=C_h_intern(&lf[382],16,"nonnull-s8vector");
lf[383]=C_h_intern(&lf[383],17,"nonnull-s16vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-u32vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-s32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-f32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-f64vector");
lf[388]=C_h_intern(&lf[388],9,"u16vector");
lf[389]=C_h_intern(&lf[389],8,"s8vector");
lf[390]=C_h_intern(&lf[390],9,"s16vector");
lf[391]=C_h_intern(&lf[391],9,"u32vector");
lf[392]=C_h_intern(&lf[392],9,"s32vector");
lf[393]=C_h_intern(&lf[393],9,"f32vector");
lf[394]=C_h_intern(&lf[394],9,"f64vector");
lf[395]=C_h_intern(&lf[395],22,"nonnull-scheme-pointer");
lf[396]=C_h_intern(&lf[396],12,"nonnull-blob");
lf[397]=C_h_intern(&lf[397],19,"nonnull-byte-vector");
lf[398]=C_h_intern(&lf[398],11,"byte-vector");
lf[399]=C_h_intern(&lf[399],4,"blob");
lf[400]=C_h_intern(&lf[400],14,"scheme-pointer");
lf[401]=C_h_intern(&lf[401],6,"double");
lf[402]=C_h_intern(&lf[402],6,"number");
lf[403]=C_h_intern(&lf[403],12,"unsigned-int");
lf[404]=C_h_intern(&lf[404],5,"short");
lf[405]=C_h_intern(&lf[405],14,"unsigned-short");
lf[406]=C_h_intern(&lf[406],4,"byte");
lf[407]=C_h_intern(&lf[407],13,"unsigned-byte");
lf[408]=C_h_intern(&lf[408],5,"int32");
lf[409]=C_h_intern(&lf[409],14,"unsigned-int32");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[411]=C_h_intern(&lf[411],36,"\010compilerforeign-type-convert-result");
lf[412]=C_h_intern(&lf[412],38,"\010compilerforeign-type-convert-argument");
lf[413]=C_h_intern(&lf[413],27,"\010compilerfinal-foreign-type");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[415]=C_h_intern(&lf[415],37,"\010compilerestimate-foreign-result-size");
lf[416]=C_h_intern(&lf[416],9,"integer64");
lf[417]=C_h_intern(&lf[417],4,"bool");
lf[418]=C_h_intern(&lf[418],4,"void");
lf[419]=C_h_intern(&lf[419],13,"scheme-object");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[421]=C_h_intern(&lf[421],46,"\010compilerestimate-foreign-result-location-size");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[424]=C_h_intern(&lf[424],30,"\010compilerfinish-foreign-result");
lf[425]=C_h_intern(&lf[425],17,"\003syspeek-c-string");
lf[426]=C_h_intern(&lf[426],25,"\003syspeek-nonnull-c-string");
lf[427]=C_h_intern(&lf[427],26,"\003syspeek-and-free-c-string");
lf[428]=C_h_intern(&lf[428],34,"\003syspeek-and-free-nonnull-c-string");
lf[429]=C_h_intern(&lf[429],17,"\003sysintern-symbol");
lf[430]=C_h_intern(&lf[430],22,"\003syspeek-c-string-list");
lf[431]=C_h_intern(&lf[431],31,"\003syspeek-and-free-c-string-list");
lf[432]=C_h_intern(&lf[432],35,"\010tinyclosmake-instance-from-pointer");
lf[433]=C_h_intern(&lf[433],4,"make");
lf[434]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[435]=C_h_intern(&lf[435],28,"\010compilerscan-used-variables");
lf[436]=C_h_intern(&lf[436],28,"\010compilerscan-free-variables");
lf[437]=C_h_intern(&lf[437],11,"lset-adjoin");
lf[438]=C_h_intern(&lf[438],25,"\010compilertopological-sort");
lf[439]=C_h_intern(&lf[439],7,"colored");
lf[440]=C_h_intern(&lf[440],23,"\010compilerchop-separator");
lf[441]=C_h_intern(&lf[441],9,"substring");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[443]=C_h_intern(&lf[443],23,"\010compilerchop-extension");
lf[444]=C_h_intern(&lf[444],22,"\010compilerprint-version");
lf[445]=C_h_intern(&lf[445],6,"print*");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[447]=C_h_intern(&lf[447],20,"\010compilerprint-usage");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\0238Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012\012  File and pathname opti"
"ons:\012\012    -output-file FILENAME       specifies output-filename, default is \047out"
".c\047\012    -include-path PATHNAME      specifies alternative path for included file"
"s\012    -to-stdout                  write compiled file to stdout instead of file\012"
"\012  Language options:\012\012    -feature SYMBOL             register feature identifie"
"r\012\012  Syntax related options:\012\012    -case-insensitive           don\047t preserve cas"
"e of read symbols\012    -keyword-style STYLE        allow alternative keyword synt"
"ax (none, prefix or suffix)\012    -compile-syntax             macros are made avai"
"lable at run-time\012    -emit-import-library MODULE write compile-time module info"
"rmation into separate file\012\012  Translation options:\012\012    -explicit-use           "
"    do not use units \047library\047 and \047eval\047 by default\012    -check-syntax          "
"     stop compilation after macro-expansion\012    -analyze-only               stop"
" compilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings  "
"              disable warnings\012    -disable-warning CLASS      disable specific "
"class of warnings\012    -debug-level NUMBER         set level of available debuggi"
"ng information\012    -no-trace                   disable tracing information\012    -"
"profile                    executable emits profiling information \012    -profile-"
"name FILENAME      name of the generated profile information file\012    -accumulat"
"e-profile         executable emits profiling information in append mode\012    -no-"
"lambda-info             omit additional procedure-information\012\012  Optimization op"
"tions:\012\012    -optimize-level NUMBER      enable certain sets of optimization opti"
"ons\012    -optimize-leaf-routines     enable leaf routine optimization\012    -lambda"
"-lift                enable lambda-lifting\012    -no-usual-integrations      stand"
"ard procedures may be redefined\012    -unsafe                     disable safety c"
"hecks\012    -local                      assume globals are only modified in curren"
"t file\012    -block                      enable block-compilation\012    -disable-int"
"errupts         disable interrupts in compiled code\012    -fixnum-arithmetic      "
"    assume all numbers are fixnums\012    -benchmark-mode             equivalent to"
" \047-block -optimize-level 4\012                                 -debug-level 0 -fixn"
"um-arithmetic -lambda-lift \012                                 -disable-interrupts"
" -inline\047\012    -disable-stack-overflow-checks  \012                                d"
"isables detection of stack-overflows.\012    -inline                     enable inl"
"ining\012    -inline-limit               set inlining threshold\012    -inline-global "
"             enable cross-module inlining\012    -emit-inline-file FILENAME  genera"
"te file with globally inlinable procedures\012                                (impl"
"ies -inline -local)\012\012  Configuration options:\012\012    -unit NAME                  c"
"ompile file as a library unit\012    -uses NAME                  declare library un"
"it as used.\012    -heap-size NUMBER           specifies heap-size of compiled exec"
"utable\012    -heap-initial-size NUMBER   specifies heap-size at startup time\012    -"
"heap-growth PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shr"
"inkage PERCENTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER"
"\012    -stack-size NUMBER          specifies nursery size of compiled executable\012 "
"   -extend FILENAME            load file before compilation commences\012    -prelu"
"de EXPRESSION         add expression to front of source file\012    -postlude EXPRE"
"SSION        add expression to end of source file\012    -prologue FILENAME        "
"  include file before main source file\012    -epilogue FILENAME          include f"
"ile after main source file\012    -dynamic                    compile as dynamicall"
"y loadable code\012    -require-extension NAME     require and import extension NAM"
"E\012    -static-extension NAME      import extension NAME but link statically (if "
"available)\012    -extension                  compile as extension (dynamic or stat"
"ic)\012    -ignore-repository          do not refer to repository for extensions\012\012 "
" Obscure options:\012\012    -debug MODES                display debugging output for "
"the given modes\012    -unsafe-libraries           marks the generated file as bein"
"g linked\012                                with the unsafe runtime system\012    -raw"
"                        do not generate implicit init- and exit code\011\011\011       \012 "
"   -emit-external-prototypes-first  emit protoypes for callbacks before foreign\012"
"                                declarations\012");
lf[449]=C_h_intern(&lf[449],36,"\010compilermake-block-variable-literal");
lf[450]=C_h_intern(&lf[450],22,"block-variable-literal");
lf[451]=C_h_intern(&lf[451],32,"\010compilerblock-variable-literal\077");
lf[452]=C_h_intern(&lf[452],36,"\010compilerblock-variable-literal-name");
lf[453]=C_h_intern(&lf[453],25,"\010compilermake-random-name");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[455]=C_h_intern(&lf[455],6,"random");
lf[456]=C_h_intern(&lf[456],15,"current-seconds");
lf[457]=C_h_intern(&lf[457],23,"\010compilerset-real-name!");
lf[458]=C_h_intern(&lf[458],24,"\010compilerreal-name-table");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[460]=C_h_intern(&lf[460],19,"\010compilerreal-name2");
lf[461]=C_h_intern(&lf[461],32,"\010compilerdisplay-real-name-table");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[463]=C_h_intern(&lf[463],28,"\010compilersource-info->string");
lf[464]=C_h_intern(&lf[464],4,"conc");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[467]=C_h_intern(&lf[467],11,"make-string");
lf[468]=C_h_intern(&lf[468],3,"max");
lf[469]=C_h_intern(&lf[469],12,"string-null\077");
lf[470]=C_h_intern(&lf[470],19,"\010compilerdump-nodes");
lf[471]=C_h_intern(&lf[471],19,"\003syswrite-char/port");
lf[472]=C_h_intern(&lf[472],19,"\003sysstandard-output");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[476]=C_h_intern(&lf[476],18,"\003sysuser-read-hook");
lf[477]=C_h_intern(&lf[477],15,"foreign-declare");
lf[478]=C_h_intern(&lf[478],7,"declare");
lf[479]=C_h_intern(&lf[479],34,"\010compilerscan-sharp-greater-string");
lf[480]=C_h_intern(&lf[480],18,"\003sysread-char/port");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[482]=C_h_intern(&lf[482],17,"get-output-string");
lf[483]=C_h_intern(&lf[483],18,"open-output-string");
lf[484]=C_h_intern(&lf[484],19,"\010compilervisibility");
lf[485]=C_h_intern(&lf[485],6,"hidden");
lf[486]=C_h_intern(&lf[486],24,"\010compilerexport-variable");
lf[487]=C_h_intern(&lf[487],8,"exported");
lf[488]=C_h_intern(&lf[488],26,"\010compilerblock-compilation");
lf[489]=C_h_intern(&lf[489],22,"\010compilermark-variable");
lf[490]=C_h_intern(&lf[490],22,"\010compilervariable-mark");
lf[491]=C_h_intern(&lf[491],19,"\010compilerintrinsic\077");
lf[492]=C_h_intern(&lf[492],9,"foldable\077");
lf[493]=C_h_intern(&lf[493],35,"\010compilercompiler-macro-environment");
lf[494]=C_h_intern(&lf[494],7,"cdb-get");
lf[495]=C_h_intern(&lf[495],8,"cdb-put!");
lf[496]=C_h_intern(&lf[496],16,"\003sysmacro-subset");
lf[497]=C_h_intern(&lf[497],28,"\003sysextend-macro-environment");
lf[498]=C_h_intern(&lf[498],19,"define-rewrite-rule");
lf[499]=C_h_intern(&lf[499],24,"\004coredefine-rewrite-rule");
lf[500]=C_h_intern(&lf[500],5,"cdadr");
lf[501]=C_h_intern(&lf[501],5,"caadr");
lf[502]=C_h_intern(&lf[502],16,"\003syscheck-syntax");
lf[503]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[504]=C_h_intern(&lf[504],18,"\003syser-transformer");
lf[505]=C_h_intern(&lf[505],21,"\003sysmacro-environment");
lf[506]=C_h_intern(&lf[506],27,"condition-property-accessor");
lf[507]=C_h_intern(&lf[507],3,"exn");
lf[508]=C_h_intern(&lf[508],7,"message");
lf[509]=C_h_intern(&lf[509],19,"condition-predicate");
C_register_lf2(lf,510,create_ptable());
t2=C_mutate(&lf[0] /* (set! c659 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3863,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3861 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3864 in k3861 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3867 in k3864 in k3861 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3882,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3887,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3914,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[20]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3954,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3983,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[28]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4002,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[34]+1 /* (set! syntax-error ...) */,C_retrieve(lf[28]));
t11=C_mutate((C_word*)lf[35]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4027,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[36]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4030,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[37]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4073,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[40]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4141,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4177,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[45]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4198,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[48]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4223,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[49]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[50]));
t19=C_mutate((C_word*)lf[51]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4267,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[60]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4361,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[63]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4417,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[64]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4424,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[65]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4431,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[72]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4478,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[75]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4490,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[77]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4553,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4584,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4604,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[83]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4650,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[84]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4680,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[86]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4726,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[89]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4786,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 286  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[509]))(3,*((C_word*)lf[509]+1),t33,lf[507]);}

/* k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 287  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[506]))(4,*((C_word*)lf[506]+1),t2,lf[507],lf[508]);}

/* k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word ab[172],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[108]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[109]));
t4=C_mutate((C_word*)lf[110]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4994,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4997,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[112]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5000,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[122]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5141,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[134]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5292,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[136]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5310,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[138]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5328,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[140]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5374,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[141]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5426,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[142]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5483,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[144]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5493,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[145]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5529,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[147]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5553,tmp=(C_word)a,a+=2,tmp));
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_mutate((C_word*)lf[152]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5572,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[203]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6050,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[205]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6056,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[206]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6062,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[208]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6071,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[209]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6080,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[210]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6089,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[211]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6098,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[212]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6107,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[203]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6116,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[213]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6122,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[215]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6137,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[216]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6152,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[252]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6761,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[266]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7094,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[268]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7148,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[273]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7261,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[277]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7482,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[279]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7516,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[280]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7593,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[281]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7644,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[282]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7677,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[300]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7879,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[302]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7948,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[305]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8168,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[309]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8269,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[310]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8391,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[311]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8422,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[314]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8443,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[317]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8529,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[326]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8568,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[332]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8604,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[411]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9651,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[412]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9682,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[413]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9713,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[415]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9753,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[421]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10072,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[424]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10382,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[435]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10674,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[436]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10767,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[438]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10954,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[440]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11151,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[443]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11180,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[444]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11222,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[447]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11260,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[449]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11272,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[451]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11278,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[452]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11284,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[453]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11293,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[457]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11337,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[39]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11343,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[460]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11422,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[461]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11434,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[463]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11446,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[469]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11492,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[470]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11498,tmp=(C_word)a,a+=2,tmp));
t77=C_retrieve(lf[476]);
t78=C_mutate((C_word*)lf[476]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11600,a[2]=t77,tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[479]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11633,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[85]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11702,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[312]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11726,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[486]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11759,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[294]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11792,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[489]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11813,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[490]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11841,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[491]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11847,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[492]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11858,tmp=(C_word)a,a+=2,tmp));
t88=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1491 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[505]))(2,*((C_word*)lf[505]+1),t88);}

/* k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11874,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11885,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1495 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[504]))(3,*((C_word*)lf[504]+1),t3,t4);}

/* a11884 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11885,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11889,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1497 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[502]))(5,*((C_word*)lf[502]+1),t5,lf[498],t2,lf[503]);}

/* k11887 in a11884 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1499 caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[501]+1)))(3,*((C_word*)lf[501]+1),t2,((C_word*)t0)[3]);}

/* k11898 in k11887 in a11884 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1499 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[117]);}

/* k11910 in k11898 in k11887 in a11884 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1499 cdadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[500]+1)))(3,*((C_word*)lf[500]+1),t2,((C_word*)t0)[2]);}

/* k11918 in k11910 in k11898 in k11887 in a11884 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11922 in k11918 in k11910 in k11898 in k11887 in a11884 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[499],t5));}

/* k11881 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1492 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[497]))(5,*((C_word*)lf[497]+1),((C_word*)t0)[2],lf[498],C_SCHEME_END_OF_LIST,t1);}

/* k11872 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11877,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1500 ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[496]))(3,*((C_word*)lf[496]+1),t2,((C_word*)t0)[2]);}

/* k11875 in k11872 in k11869 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate((C_word*)lf[493]+1 /* (set! compiler-macro-environment ...) */,t1);
t3=C_mutate((C_word*)lf[494]+1 /* (set! cdb-get ...) */,C_retrieve(lf[134]));
t4=C_mutate((C_word*)lf[495]+1 /* (set! cdb-put! ...) */,C_retrieve(lf[138]));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* foldable? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11863,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[131]);}

/* f_11863 in foldable? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11863,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t1,t2,t3);}

/* ##compiler#intrinsic? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11847,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11852,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[125]);}

/* f_11852 in ##compiler#intrinsic? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11852,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t1,t2,t3);}

/* ##compiler#variable-mark in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11841,4,t0,t1,t2,t3);}
/* support.scm: 1482 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11813r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11813r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11813r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11817,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11817(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11817(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11815 in ##compiler#mark-variable in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1479 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11792,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11796,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1472 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t3,t2,lf[484]);}

/* k11794 in ##compiler#variable-visible? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[485]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[487]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[488]))));}}

/* ##compiler#export-variable in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11759,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11764,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[484],lf[487]);}

/* f_11764 in ##compiler#export-variable in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11764r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11764r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11764r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11768,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11768(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11768(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11766 */
static void C_ccall f_11768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#hide-variable in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11726,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11731,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[484],lf[485]);}

/* f_11731 in ##compiler#hide-variable in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11731r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11731r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11731r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11735,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11735(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11735(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11733 */
static void C_ccall f_11735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#big-fixnum? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11702,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11633,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11637,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1434 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[483]))(2,*((C_word*)lf[483]+1),t3);}

/* k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11637,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11642,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11642(t5,((C_word*)t0)[2]);}

/* loop in k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11642,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[480]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11644 in loop in k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11646,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1437 quit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[5],lf[481]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11664,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1439 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11676,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[480]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11697,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[471]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11695 in k11644 in loop in k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1451 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11642(t2,((C_word*)t0)[2]);}

/* k11674 in k11644 in loop in k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11676,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1444 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[482]))(3,*((C_word*)lf[482]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11688,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[471]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11686 in k11674 in k11644 in loop in k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11691,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[471]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11689 in k11686 in k11674 in k11644 in loop in k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1448 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11642(t2,((C_word*)t0)[2]);}

/* k11662 in k11644 in loop in k11635 in ##compiler#scan-sharp-greater-string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1440 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11642(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11600,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11610,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[480]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1431 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k11608 in ##sys#user-read-hook in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1429 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[479]))(3,*((C_word*)lf[479]+1),t2,((C_word*)t0)[2]);}

/* k11611 in k11608 in ##sys#user-read-hook in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11613,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[477],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[478],t4));}

/* ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11498,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11502,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11507,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11507(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11507(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11507,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11511,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11594,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_11594 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11594,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11514,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11589,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_11589 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11589,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11517,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11584,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11584 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11584,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1407 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[467]+1)))(4,*((C_word*)lf[467]+1),t2,((C_word*)t0)[7],C_make_character(32));}

/* k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11520,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11526,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1409 printf */
((C_proc6)C_retrieve_symbol_proc(lf[13]))(6,*((C_word*)lf[13]+1),t3,lf[475],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11529,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11578 in k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11579,3,t0,t1,t2);}
/* loop3509 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11507(t3,t1,((C_word*)t0)[2],t2);}

/* k11527 in k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11529,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11544,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1413 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t4,lf[474],t5);}
else{
t4=t3;
f_11535(2,t4,C_SCHEME_UNDEFINED);}}

/* k11542 in k11527 in k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11547,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11552,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11552(t6,t2,C_fix(5));}

/* doloop3539 in k11542 in k11527 in k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11552,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11562,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1416 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,lf[473],t4);}}

/* k11560 in doloop3539 in k11542 in k11527 in k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11552(t3,((C_word*)t0)[2],t2);}

/* k11545 in k11542 in k11527 in k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[471]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[472]+1));}

/* k11533 in k11527 in k11524 in k11518 in k11515 in k11512 in k11509 in loop in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[471]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[472]+1));}

/* k11500 in ##compiler#dump-nodes in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1419 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* string-null? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11492,3,t0,t1,t2);}
/* support.scm: 1397 string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[469]))(3,*((C_word*)lf[469]+1),t1,t2);}

/* ##compiler#source-info->string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11446,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11465,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1390 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1392 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11463 in ##compiler#source-info->string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11472,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1391 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[468]+1)))(4,*((C_word*)lf[468]+1),t3,C_fix(0),t5);}

/* k11474 in k11463 in ##compiler#source-info->string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1391 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[467]+1)))(4,*((C_word*)lf[467]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k11470 in k11463 in ##compiler#source-info->string in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1391 conc */
((C_proc8)C_retrieve_symbol_proc(lf[464]))(8,*((C_word*)lf[464]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[465],((C_word*)t0)[3],t1,lf[466],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11440,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1380 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[151]))(4,*((C_word*)lf[151]+1),t1,t2,C_retrieve(lf[458]));}

/* a11439 in ##compiler#display-real-name-table in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11440,4,t0,t1,t2,t3);}
/* support.scm: 1382 printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t1,lf[462],t2,t3);}

/* ##compiler#real-name2 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11422,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11426,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1376 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t4,C_retrieve(lf[458]),t2);}

/* k11424 in ##compiler#real-name2 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1377 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11343(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11343r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11343r(t0,t1,t2,t3);}}

static void C_ccall f_11343r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11346,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11362,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1360 resolve */
f_11346(t5,t2);}

/* k11360 in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11362,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1364 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[242]))(3,*((C_word*)lf[242]+1),t4,t1);}
else{
/* support.scm: 1373 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[242]))(3,*((C_word*)lf[242]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1361 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[242]))(3,*((C_word*)lf[242]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11385 in k11360 in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11391,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1365 get */
((C_proc5)C_retrieve_symbol_proc(lf[134]))(5,*((C_word*)lf[134]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[146]);}

/* k11389 in k11385 in k11360 in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11391,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11393,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11393(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11389 in k11385 in k11360 in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11393(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11393,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11400,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1367 resolve */
f_11346(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11398 in loop in k11389 in k11385 in k11360 in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11400,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11413,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1370 sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),t3,lf[459],((C_word*)t0)[4],t1);}}

/* k11411 in k11398 in loop in k11389 in k11385 in k11360 in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11417,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1371 get */
((C_proc5)C_retrieve_symbol_proc(lf[134]))(5,*((C_word*)lf[134]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[146]);}

/* k11415 in k11411 in k11398 in loop in k11389 in k11385 in k11360 in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1370 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11393(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11346(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11346,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11350,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1355 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t3,C_retrieve(lf[458]),t2);}

/* k11348 in resolve in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11350,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11356,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1357 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t2,C_retrieve(lf[458]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11354 in k11348 in resolve in ##compiler#real-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11337,4,t0,t1,t2,t3);}
/* support.scm: 1351 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t1,C_retrieve(lf[458]),t2,t3);}

/* ##compiler#make-random-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11293(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_11293r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11293r(t0,t1,t2);}}

static void C_ccall f_11293r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11301,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11305,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1338 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11305(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k11303 in ##compiler#make-random-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11309,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1339 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[456]))(2,*((C_word*)lf[456]+1),t2);}

/* k11307 in k11303 in ##compiler#make-random-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11313,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1340 random */
((C_proc3)C_retrieve_symbol_proc(lf[455]))(3,*((C_word*)lf[455]+1),t2,C_fix(1000));}

/* k11311 in k11307 in k11303 in ##compiler#make-random-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1337 sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[43]))(6,*((C_word*)lf[43]+1),((C_word*)t0)[4],lf[454],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11299 in ##compiler#make-random-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1336 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11284,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[450]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11278,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[450]));}

/* ##compiler#make-block-variable-literal in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11272,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[450],t2));}

/* ##compiler#print-usage in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11264,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1220 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[444]))(2,*((C_word*)lf[444]+1),t2);}

/* k11262 in ##compiler#print-usage in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1221 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k11265 in k11262 in ##compiler#print-usage in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1222 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[448]);}

/* ##compiler#print-version in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11222(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_11222r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11222r(t0,t1,t2);}}

static void C_ccall f_11222r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11226,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_11226(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_11226(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k11224 in ##compiler#print-version in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11229,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1216 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[445]+1)))(3,*((C_word*)lf[445]+1),t2,lf[446]);}
else{
t3=t2;
f_11229(2,t3,C_SCHEME_UNDEFINED);}}

/* k11227 in k11224 in ##compiler#print-version in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1217 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t2,C_SCHEME_TRUE);}

/* k11234 in k11227 in k11224 in ##compiler#print-version in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1217 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[283]+1)))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11180,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11189,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11189(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11189(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11189,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1209 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[441]+1)))(5,*((C_word*)lf[441]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1210 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11151,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11161,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_11161(t7,(C_word)C_i_memq(t6,lf[442]));}
else{
t6=t5;
f_11161(t6,C_SCHEME_FALSE);}}

/* k11159 in ##compiler#chop-separator in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1202 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[441]+1)))(5,*((C_word*)lf[441]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10954,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10963,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11010,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11045,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11082,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11133,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a11132 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11133,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1184 insert */
t5=((C_word*)t0)[2];
f_10963(t5,t1,t3,t4);}

/* k11080 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11127,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1187 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t3,((C_word*)t0)[2]);}

/* k11125 in k11080 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11131,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1187 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t2,((C_word*)t0)[2]);}

/* k11129 in k11125 in k11080 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1187 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11045(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11083 in k11080 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11088,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a11089 in k11083 in k11080 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11090,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11094,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1189 lookup */
t5=((C_word*)t0)[2];
f_11010(t5,t3,t4);}

/* k11092 in a11089 in k11083 in k11080 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[439]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1191 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11045(t5,((C_word*)t0)[4],t3,t4);}}

/* k11086 in k11083 in k11080 in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11045(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11045,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11049,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1172 insert */
t5=((C_word*)t0)[2];
f_10963(t5,t4,t2,lf[439]);}

/* k11047 in visit in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11052,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11057 in k11047 in visit in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11058,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11062,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1175 lookup */
t4=((C_word*)t0)[2];
f_11010(t4,t3,t2);}

/* k11060 in a11057 in k11047 in visit in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[439]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1177 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11045(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k11050 in k11047 in visit in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11052,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11010(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11010,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11016,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11016(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_11016(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11016,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11029,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11043,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1167 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t4,t2);}}

/* k11041 in loop in lookup in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1167 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11027 in loop in lookup in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1167 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1168 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11016(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10963,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10969,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10969(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10969(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10969,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11008,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1161 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t4,t2);}}

/* k11006 in loop in insert in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_11008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1161 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10988 in loop in insert in ##compiler#topological-sort in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1162 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10969(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10767,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10770,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10936,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10949,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1144 walk */
t14=((C_word*)t8)[1];
f_10770(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10947 in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1145 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10936(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10936,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10942,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10941 in walkeach in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10942,3,t0,t1,t2);}
/* support.scm: 1142 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10770(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10770(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10770,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10774,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10930,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10930 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10930,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10925,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10925 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10925,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10920,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10920 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10920,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10780,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[82]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_10789(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[220]);
if(C_truep(t4)){
t5=t3;
f_10789(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[228]);
if(C_truep(t5)){
t6=t3;
f_10789(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[231]);
t7=t3;
f_10789(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[245])));}}}}

/* k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10789,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[214]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10808,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1124 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[437]))(5,*((C_word*)lf[437]+1),t4,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[232]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10830,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10830(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10844,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1129 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[437]))(5,*((C_word*)lf[437]+1),t6,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[92]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10853,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1132 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10770(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[227]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10883,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1135 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1139 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10936(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10882 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10883,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10895,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1138 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t6,t2,((C_word*)t0)[2]);}

/* k10893 in a10882 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1138 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10770(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10851 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10853,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10864,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1133 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10862 in k10851 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1133 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10770(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10842 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10830(t3,t2);}

/* k10828 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1130 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10770(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10806 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10808,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1125 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[294]))(3,*((C_word*)lf[294]+1),t3,((C_word*)t0)[2]);}

/* k10812 in k10806 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10814,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10818,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1126 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[437]))(5,*((C_word*)lf[437]+1),t2,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10816 in k10812 in k10806 in k10787 in k10778 in k10775 in k10772 in walk in ##compiler#scan-free-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10674,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10678,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10680,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10680(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10680,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10684,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10761,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10761 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10761,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10756,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10756 in k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10756,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10685 in k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10687,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[214]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[232]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10727,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10740,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_10740(t6,t4);}
else{
t6=(C_word)C_eqp(t1,lf[220]);
t7=t5;
f_10740(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[228])));}}}

/* k10738 in k10685 in k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* f_10727 in k10685 in k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10727,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10724 in k10685 in k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10726,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10708,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_10708(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_10708(t5,C_SCHEME_FALSE);}}

/* k10706 in k10724 in k10685 in k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10708,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10702(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10702(t2,C_SCHEME_UNDEFINED);}}

/* k10700 in k10724 in k10685 in k10682 in walk in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10676 in ##compiler#scan-used-variables in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10382,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[425],t9));}
else{
t6=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[426],t10));}
else{
t7=(C_word)C_eqp(t4,lf[373]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[374]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[82],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[427],t12));}
else{
t9=(C_word)C_eqp(t4,lf[371]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[372]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[82],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[428],t14));}
else{
t11=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[82],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[425],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[429],t17));}
else{
t12=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[82],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[430],t16));}
else{
t13=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[82],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[431],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10578,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_10578(t18,(C_word)C_i_memq(t17,lf[434]));}
else{
t17=t14;
f_10578(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_10578(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k10576 in ##compiler#finish-foreign-result in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10578,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[432],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_10599(t6,(C_word)C_eqp(lf[366],t5));}
else{
t5=t2;
f_10599(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10599(t3,C_SCHEME_FALSE);}}}

/* k10597 in k10576 in ##compiler#finish-foreign-result in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10599,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[364],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[82],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[433],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10072,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10075,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10084,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10376,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1048 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t4,t5);}

/* a10375 in ##compiler#estimate-foreign-result-location-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10376,2,t0,t1);}
/* support.scm: 1069 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[423],((C_word*)t0)[2]);}

/* a10083 in ##compiler#estimate-foreign-result-location-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10084,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[333]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10094,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_10094(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t7)){
t8=t6;
f_10094(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t8)){
t9=t6;
f_10094(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[417]);
if(C_truep(t9)){
t10=t6;
f_10094(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t10)){
t11=t6;
f_10094(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[334]);
if(C_truep(t11)){
t12=t6;
f_10094(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[403]);
if(C_truep(t12)){
t13=t6;
f_10094(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t13)){
t14=t6;
f_10094(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t14)){
t15=t6;
f_10094(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t15)){
t16=t6;
f_10094(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t16)){
t17=t6;
f_10094(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[352]);
if(C_truep(t17)){
t18=t6;
f_10094(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[341]);
if(C_truep(t18)){
t19=t6;
f_10094(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t19)){
t20=t6;
f_10094(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[350]);
if(C_truep(t20)){
t21=t6;
f_10094(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[348]);
if(C_truep(t21)){
t22=t6;
f_10094(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[339]);
if(C_truep(t22)){
t23=t6;
f_10094(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t23)){
t24=t6;
f_10094(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t24)){
t25=t6;
f_10094(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[400]);
if(C_truep(t25)){
t26=t6;
f_10094(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[395]);
if(C_truep(t26)){
t27=t6;
f_10094(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t27)){
t28=t6;
f_10094(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t28)){
t29=t6;
f_10094(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t29)){
t30=t6;
f_10094(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t30)){
t31=t6;
f_10094(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t31)){
t32=t6;
f_10094(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t32)){
t33=t6;
f_10094(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t33)){
t34=t6;
f_10094(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t34)){
t35=t6;
f_10094(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[371]);
if(C_truep(t35)){
t36=t6;
f_10094(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[375]);
t37=t6;
f_10094(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[376])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k10092 in a10083 in ##compiler#estimate-foreign-result-location-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10094,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[401]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[402]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub331(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1061 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t4,C_retrieve(lf[370]),((C_word*)t0)[3]);}
else{
t5=t4;
f_10112(2,t5,C_SCHEME_FALSE);}}}}

/* k10110 in k10092 in a10083 in ##compiler#estimate-foreign-result-location-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10112,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1063 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[361]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_10146(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t5)){
t6=t4;
f_10146(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[341]);
if(C_truep(t6)){
t7=t4;
f_10146(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[352]);
if(C_truep(t7)){
t8=t4;
f_10146(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[354]);
t9=t4;
f_10146(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[369])));}}}}}
else{
/* support.scm: 1068 err */
f_10075(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k10144 in k10110 in k10092 in a10083 in ##compiler#estimate-foreign-result-location-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1067 err */
f_10075(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_10075(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10075,NULL,2,t1,t2);}
/* support.scm: 1047 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[422],t2);}

/* ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9753,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9759,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10066,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1018 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a10065 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_10066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10066,2,t0,t1);}
/* support.scm: 1043 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[420],((C_word*)t0)[2]);}

/* a9758 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9759,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[333]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9769,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9769(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t7)){
t8=t6;
f_9769(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t8)){
t9=t6;
f_9769(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[417]);
if(C_truep(t9)){
t10=t6;
f_9769(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[418]);
if(C_truep(t10)){
t11=t6;
f_9769(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t11)){
t12=t6;
f_9769(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t12)){
t13=t6;
f_9769(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[334]);
if(C_truep(t13)){
t14=t6;
f_9769(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[403]);
if(C_truep(t14)){
t15=t6;
f_9769(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t15)){
t16=t6;
f_9769(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t16)){
t17=t6;
f_9769(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[408]);
t18=t6;
f_9769(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[409])));}}}}}}}}}}}}

/* k9767 in a9758 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9769,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9778(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[358]);
if(C_truep(t4)){
t5=t3;
f_9778(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[352]);
if(C_truep(t5)){
t6=t3;
f_9778(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[354]);
if(C_truep(t6)){
t7=t3;
f_9778(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t7)){
t8=t3;
f_9778(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t8)){
t9=t3;
f_9778(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t9)){
t10=t3;
f_9778(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t10)){
t11=t3;
f_9778(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t11)){
t12=t3;
f_9778(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
t13=t3;
f_9778(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[376])));}}}}}}}}}}}

/* k9776 in k9767 in a9758 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9778,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[350]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9790(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t4)){
t5=t3;
f_9790(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[348]);
if(C_truep(t5)){
t6=t3;
f_9790(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[378]);
if(C_truep(t6)){
t7=t3;
f_9790(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
t8=t3;
f_9790(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[377])));}}}}}}

/* k9788 in k9776 in k9767 in a9758 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9790,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[339]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9802(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[401]);
if(C_truep(t4)){
t5=t3;
f_9802(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[402]);
t6=t3;
f_9802(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[416])));}}}}

/* k9800 in k9788 in k9776 in k9767 in a9758 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9802,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1034 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t2,C_retrieve(lf[370]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9808(2,t3,C_SCHEME_FALSE);}}}

/* k9806 in k9800 in k9788 in k9776 in k9767 in a9758 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9808,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1036 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[361]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9842,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9842(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t5)){
t6=t4;
f_9842(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[341]);
if(C_truep(t6)){
t7=t4;
f_9842(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[352]);
if(C_truep(t7)){
t8=t4;
f_9842(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[354]);
if(C_truep(t8)){
t9=t4;
f_9842(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[369]);
if(C_truep(t9)){
t10=t4;
f_9842(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[362]);
if(C_truep(t10)){
t11=t4;
f_9842(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[363]);
t12=t4;
f_9842(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[366])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9840 in k9806 in k9800 in k9788 in k9776 in k9767 in a9758 in ##compiler#estimate-foreign-result-size in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9713,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9719,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9747,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1005 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a9746 in ##compiler#final-foreign-type in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9747,2,t0,t1);}
/* support.scm: 1012 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[414],((C_word*)t0)[2]);}

/* a9718 in ##compiler#final-foreign-type in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9719,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9723,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1008 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t4,C_retrieve(lf[370]),t2);}
else{
t5=t4;
f_9723(2,t5,C_SCHEME_FALSE);}}

/* k9721 in a9718 in ##compiler#final-foreign-type in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1010 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9682,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9686,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9695,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 999  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t5,C_retrieve(lf[370]),t3);}
else{
t5=t4;
f_9686(t5,C_SCHEME_FALSE);}}

/* k9693 in ##compiler#foreign-type-convert-argument in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9695,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9686(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9686(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9686(t2,C_SCHEME_FALSE);}}

/* k9684 in ##compiler#foreign-type-convert-argument in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9651,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9655,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9664,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 992  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t5,C_retrieve(lf[370]),t3);}
else{
t5=t4;
f_9655(t5,C_SCHEME_FALSE);}}

/* k9662 in ##compiler#foreign-type-convert-result in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9664,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_9655(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9655(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9655(t2,C_SCHEME_FALSE);}}

/* k9653 in ##compiler#foreign-type-convert-result in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8604,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8610,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9645,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 893  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[77]))(5,*((C_word*)lf[77]+1),t1,t3,t4,t5);}

/* a9644 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9645,2,t0,t1);}
/* support.scm: 985  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[410],((C_word*)t0)[2]);}

/* a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8610,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8616,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8616(t7,t1,t2);}

/* repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8616,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[333]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[334]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[335]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[336],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[337]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8645(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[403]);
if(C_truep(t8)){
t9=t7;
f_8645(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[404]);
if(C_truep(t9)){
t10=t7;
f_8645(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t10)){
t11=t7;
f_8645(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t11)){
t12=t7;
f_8645(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t12)){
t13=t7;
f_8645(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[408]);
t14=t7;
f_8645(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[409])));}}}}}}}}

/* k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8645,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[338],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[339]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8664(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[401]);
t5=t3;
f_8664(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[402])));}}}

/* k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8664,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[340],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[341]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8683(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[398]);
if(C_truep(t4)){
t5=t3;
f_8683(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
t6=t3;
f_8683(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[400])));}}}}

/* k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8683,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 903  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[343]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8753(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
if(C_truep(t4)){
t5=t3;
f_8753(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
t6=t3;
f_8753(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[397])));}}}}

/* k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8753,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[342],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8772(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[388]);
if(C_truep(t4)){
t5=t3;
f_8772(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t5)){
t6=t3;
f_8772(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t6)){
t7=t3;
f_8772(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t7)){
t8=t3;
f_8772(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t8)){
t9=t3;
f_8772(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
t10=t3;
f_8772(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[394])));}}}}}}}}

/* k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8772(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8772,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8775,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 915  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[346]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8854(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t4)){
t5=t3;
f_8854(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t5)){
t6=t3;
f_8854(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t6)){
t7=t3;
f_8854(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t7)){
t8=t3;
f_8854(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t8)){
t9=t3;
f_8854(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
t10=t3;
f_8854(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[387])));}}}}}}}}

/* k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8854,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[347]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[82],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[345],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[348]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8893(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
t5=t3;
f_8893(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[380])));}}}

/* k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8893,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[349],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[350]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8912(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[377]);
t5=t3;
f_8912(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[378])));}}}

/* k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8912,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[351],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[352]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8931(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[375]);
t5=t3;
f_8931(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[376])));}}}

/* k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8931,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 935  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[354]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[353],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_9011(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[373]);
t6=t4;
f_9011(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[374])));}}}}

/* k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9011,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9014,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 943  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[358]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9096(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[371]);
t5=t3;
f_9096(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[372])));}}}

/* k9094 in k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9096(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9096,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[356],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[357],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[356],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[335]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[360],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[356],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[360],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[357],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[356],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 959  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t3,C_retrieve(lf[370]),((C_word*)t0)[3]);}
else{
t4=t3;
f_9171(2,t4,C_SCHEME_FALSE);}}}}

/* k9169 in k9094 in k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9171,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 961  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[361]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9205(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[341]);
if(C_truep(t5)){
t6=t4;
f_9205(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[369]);
t7=t4;
f_9205(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[352])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k9203 in k9169 in k9094 in k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9205,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9208,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 965  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[362]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[363]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9275,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 971  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[366]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[364],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[365],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 978  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8616(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[335]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[349],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[343]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[354]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[353],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9273 in k9203 in k9169 in k9094 in k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9275,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[364],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[365],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[82],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[219],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[92],t17));}

/* k9206 in k9203 in k9169 in k9094 in k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9208,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[353],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[219],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k9012 in k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_9014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9014,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9045,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[335]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_9045(t7,(C_word)C_a_i_cons(&a,2,lf[356],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[357],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_9045(t9,(C_word)C_a_i_cons(&a,2,lf[356],t8));}}

/* k9043 in k9012 in k9009 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_9045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9045,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[219],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8932 in k8929 in k8910 in k8891 in k8852 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8934,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[353],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[219],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[92],t14));}

/* k8773 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8806,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[335]))){
t6=t5;
f_8806(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8806(t10,(C_word)C_a_i_cons(&a,2,lf[345],t9));}}

/* k8804 in k8773 in k8770 in k8751 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8806,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[219],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* k8684 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8686,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8717,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[335]))){
t6=t5;
f_8717(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8717(t7,(C_word)C_a_i_cons(&a,2,lf[342],t6));}}

/* k8715 in k8684 in k8681 in k8662 in k8643 in repeat in a8609 in ##compiler#foreign-type-check in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8717,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[219],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[92],t9));}

/* ##compiler#pprint-expressions-to-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8568,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8572,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 874  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[330]+1)))(3,*((C_word*)lf[330]+1),t4,t3);}
else{
/* support.scm: 874  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[331]+1)))(2,*((C_word*)lf[331]+1),t4);}}

/* k8570 in ##compiler#pprint-expressions-to-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8575,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 875  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[329]))(4,*((C_word*)lf[329]+1),t2,t1,t3);}

/* a8582 in k8570 in ##compiler#pprint-expressions-to-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8589,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a8588 in a8582 in k8570 in ##compiler#pprint-expressions-to-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8589,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8593,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 879  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),t3,t2);}

/* k8591 in a8588 in a8582 in k8570 in ##compiler#pprint-expressions-to-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 880  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k8573 in k8570 in ##compiler#pprint-expressions-to-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 882  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[327]+1)))(3,*((C_word*)lf[327]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8529,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8541,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a8540 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8541,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8548,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 862  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t9,lf[324],lf[325]);}

/* k8546 in a8540 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8548,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 863  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t2,lf[323],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8549 in k8546 in a8540 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 864  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[322],((C_word*)t0)[2]);}

/* k8552 in k8549 in k8546 in a8540 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 865  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[321],((C_word*)t0)[2]);}

/* k8555 in k8552 in k8549 in k8546 in a8540 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 866  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[320],((C_word*)t0)[2]);}

/* k8558 in k8555 in k8552 in k8549 in k8546 in a8540 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 867  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[319],((C_word*)t0)[2]);}

/* k8561 in k8558 in k8555 in k8552 in k8549 in k8546 in a8540 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 868  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[318],((C_word*)t0)[2]);}

/* a8534 in ##compiler#print-program-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8535,2,t0,t1);}
/* support.scm: 861  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[314]))(3,*((C_word*)lf[314]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8443,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8447,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8452,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 837  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[151]))(4,*((C_word*)lf[151]+1),t13,t14,t2);}

/* a8451 in ##compiler#compute-database-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8452,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a8457 in a8451 in ##compiler#compute-database-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8458,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[182]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[163]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8500,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cdr(t2);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8505,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t8=(C_word)C_eqp(t5,lf[170]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* f_8505 in a8457 in a8451 in ##compiler#compute-database-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8505,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8498 in a8457 in a8451 in ##compiler#compute-database-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[227],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8445 in ##compiler#compute-database-statistics in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 851  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[315]),C_retrieve(lf[316]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8422,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8432,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 814  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t7,lf[250],lf[313],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k8430 in ##sys#toplevel-definition-hook in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 815  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[312]))(3,*((C_word*)lf[312]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8391,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8397,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 800  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[151]))(4,*((C_word*)lf[151]+1),t1,t3,t2);}

/* a8396 in ##compiler#dump-undefined-globals in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8397,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8404,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[182],t3))){
t5=(C_word)C_i_assq(lf[180],t3);
t6=t4;
f_8404(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8404(t5,C_SCHEME_FALSE);}}

/* k8402 in a8396 in ##compiler#dump-undefined-globals in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8404(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8404,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8407,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 804  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[200]+1)))(3,*((C_word*)lf[200]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8405 in k8402 in a8396 in ##compiler#dump-undefined-globals in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 805  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8269,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8273,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8385,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8385 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8385,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8273,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
if(C_truep((C_word)C_i_cadr(t1))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8293,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8293(3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8293,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8297,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8374,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8374 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8374,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8297,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[239]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8351,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(t1,lf[230]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8369,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}}

/* f_8369 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8369,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8366 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 794  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* f_8351 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8351,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8304 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8306,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8345,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8346,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8346 in k8304 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8346,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8343 in k8304 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8345,2,t0,t1);}
t2=(C_word)C_eqp(lf[214],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8337,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8337 in k8343 in k8304 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8337,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8334 in k8343 in k8304 in k8295 in rec in k8271 in ##compiler#simple-lambda-node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 792  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8168,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8174,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8174(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8174,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8178,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8263,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8263 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8263,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8181,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8258,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_8258 in k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8258,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8179 in k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8181,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[214]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8190(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[82]);
if(C_truep(t4)){
t5=t3;
f_8190(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[220]);
if(C_truep(t5)){
t6=t3;
f_8190(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[231]);
t7=t3;
f_8190(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[218])));}}}}

/* k8188 in k8179 in k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8190(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8190,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[227]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8216,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8217,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[219]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[92]));
if(C_truep(t4)){
/* support.scm: 776  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* f_8217 in k8188 in k8179 in k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8217,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8214 in k8188 in k8179 in k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8216,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8204,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 775  find */
((C_proc4)C_retrieve_symbol_proc(lf[307]))(4,*((C_word*)lf[307]+1),((C_word*)t0)[2],t3,C_retrieve(lf[308]));}

/* a8203 in k8214 in k8188 in k8179 in k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8204,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 775  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[306]))(3,*((C_word*)lf[306]+1),t3,t2);}

/* k8210 in a8203 in k8214 in k8188 in k8179 in k8176 in walk in ##compiler#expression-has-side-effects? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7948,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7951,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7980,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8023,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8142,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 759  matchn */
t15=((C_word*)t12)[1];
f_8023(t15,t14,t2,t3);}

/* k8140 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8162,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8162 in k8140 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8162,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8150 in k8140 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8156,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8157,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8157 in k8150 in k8140 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8157,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8154 in k8150 in k8140 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 762  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[10]))(7,*((C_word*)lf[10]+1),((C_word*)t0)[4],lf[303],lf[304],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8146 in k8140 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8023(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8023,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 748  resolve */
t4=((C_word*)t0)[4];
f_7951(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8130,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8135,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* f_8135 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8135,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8130,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8117,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8122,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_8122 in k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8122,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8115 in k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* support.scm: 750  match1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7980(t3,((C_word*)t0)[2],t1,t2);}

/* k8043 in k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8045,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8109,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8109 in k8043 in k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8109,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8050 in k8043 in k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8052,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8058,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8058(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8050 in k8043 in k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_8058(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8058,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 754  resolve */
t4=((C_word*)t0)[4];
f_7951(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8089,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 756  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8023(t7,t4,t5,t6);}}}}

/* k8087 in loop in k8050 in k8043 in k8128 in matchn in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 757  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8058(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7980(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7980,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 741  resolve */
t4=((C_word*)t0)[3];
f_7951(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8002,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 743  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k8000 in match1 in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 743  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7980(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7951,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7975,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 736  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7973 in resolve in ##compiler#match-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7879,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7885,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 716  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[301]))(4,*((C_word*)lf[301]+1),t1,t2,t3);}

/* a7884 in ##compiler#load-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7885,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7891,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7891(t5,t1);}

/* loop in a7884 in ##compiler#load-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7891,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7895,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 719  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t2);}

/* k7893 in loop in a7884 in ##compiler#load-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7895,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7915,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 724  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t4,t5);}}

/* k7913 in k7893 in loop in a7884 in ##compiler#load-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7916,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[293],t1);}

/* f_7916 in k7913 in k7893 in loop in a7884 in ##compiler#load-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_7916r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7916r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7920,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7920(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7920(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k7918 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7902 in k7893 in loop in a7884 in ##compiler#load-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 725  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7891(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7677,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7681,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7708,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 685  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[299]))(4,*((C_word*)lf[299]+1),t6,t2,t7);}

/* a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7877,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 687  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[298]))(2,*((C_word*)lf[298]+1),t3);}

/* k7875 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 687  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[283]+1)))(7,*((C_word*)lf[283]+1),((C_word*)t0)[2],lf[295],t1,lf[296],C_retrieve(lf[241]),lf[297]);}

/* k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7715,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 689  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[151]))(4,*((C_word*)lf[151]+1),t2,t3,((C_word*)t0)[2]);}

/* a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7720,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 691  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[294]))(3,*((C_word*)lf[294]+1),t4,t2);}

/* k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7727,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[165],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7863,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7869,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],lf[293]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_7869 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7869,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t1,t2,t3);}

/* k7861 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7864,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_7864 in k7861 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7864,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[204]));}

/* k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7859,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[163],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7751(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[158],t5);
t7=t4;
f_7751(t7,(C_word)C_i_not(t6));}}}

/* k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7751(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7751,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[192],((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7840,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7840 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7840,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7760,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(t1);
/* support.scm: 699  get */
((C_proc5)C_retrieve_symbol_proc(lf[134]))(5,*((C_word*)lf[134]+1),t2,((C_word*)t0)[2],t3,lf[191]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7767 in k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7769,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 700  get */
((C_proc5)C_retrieve_symbol_proc(lf[134]))(5,*((C_word*)lf[134]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[199]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7829 in k7767 in k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7831,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7823,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[292]);}}

/* f_7823 in k7829 in k7767 in k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7823,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t1,t2,t3);}

/* k7779 in k7829 in k7767 in k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[289]);
if(C_truep(t3)){
t4=t2;
f_7784(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[290]);
if(C_truep(t4)){
t5=t2;
f_7784(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[291]);
t7=t2;
f_7784(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7782 in k7779 in k7829 in k7767 in k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7784,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7802,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 707  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7800 in k7782 in k7779 in k7829 in k7767 in k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 707  pp */
((C_proc3)C_retrieve_symbol_proc(lf[288]))(3,*((C_word*)lf[288]+1),((C_word*)t0)[2],t2);}

/* k7789 in k7782 in k7779 in k7829 in k7767 in k7758 in k7749 in k7857 in k7725 in a7719 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 708  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k7713 in k7710 in a7707 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 710  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[283]+1)))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],lf[287]);}

/* k7679 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 712  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t2,lf[285],lf[286]);}
else{
t3=t2;
f_7687(2,t3,C_SCHEME_FALSE);}}

/* k7685 in k7679 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7687,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7692,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7700,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 713  sort-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[78]))(3,*((C_word*)lf[78]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7698 in k7685 in k7679 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7691 in k7685 in k7679 in ##compiler#emit-global-inline-file in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7692,3,t0,t1,t2);}
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[283]+1)))(4,*((C_word*)lf[283]+1),t1,lf[284],t2);}

/* ##compiler#sexpr->node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7644,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7650,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7650(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7650,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7666,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k7664 in walk in ##compiler#sexpr->node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7667,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7667 in k7664 in walk in ##compiler#sexpr->node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7667,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7593,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7599,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7599(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7599,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7607,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7638,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7638 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7638,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7605 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7633,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7633 in k7605 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7633,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7613 in k7605 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7623,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7627,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7628,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_7628 in k7613 in k7605 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7628,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7625 in k7613 in k7605 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k7621 in k7613 in k7605 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7617 in k7613 in k7605 in walk in ##compiler#node->sexpr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7619,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7516,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7520,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7586,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7587,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_7587 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7587,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7584 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 664  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7578,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7578 in k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7578,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7575 in k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 665  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7521 in k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7568,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7569,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7569 in k7521 in k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7569,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7566 in k7521 in k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 666  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7524 in k7521 in k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7526,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7537(t4,C_fix(4)));}

/* doloop1626 in k7524 in k7521 in k7518 in ##compiler#copy-node! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static C_word C_fcall f_7537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7482,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7488,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7488(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7488(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7488,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7502,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 660  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7500 in rec in ##compiler#tree-copy in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7506,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 660  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7488(t4,t2,t3);}

/* k7504 in k7500 in rec in ##compiler#tree-copy in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7506,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7261,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7265,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 628  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[255]+1)))(5,*((C_word*)lf[255]+1),t5,*((C_word*)lf[278]+1),t3,t4);}

/* k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7267,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7273,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 655  walk */
t6=((C_word*)t4)[1];
f_7273(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7273(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7273,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7277,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7473,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7473 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7473,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7280,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7468,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7468 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7468,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7463,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7463 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7463,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7283,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[214]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7296,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 635  rename */
f_7267(t3,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(t1,lf[232]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 636  rename */
f_7267(t4,t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7348,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 639  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t6,t5);}
else{
t5=(C_word)C_eqp(t1,lf[227]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7388,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 643  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),((C_word*)t0)[7],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 654  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t6,((C_word*)t0)[6]);}}}}}

/* k7445 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7451,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7457 in k7445 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7458,3,t0,t1,t2);}
/* walk1504 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7273(t3,t1,t2,((C_word*)t0)[2]);}

/* k7449 in k7445 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7452,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7452 in k7449 in k7445 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7452,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7388,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[93]),t2);}

/* k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 647  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t2,t1,((C_word*)t0)[2]);}

/* k7393 in k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 650  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[276]);}

/* k7419 in k7393 in k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7421,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7429,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 651  rename */
f_7267(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_7437(2,t5,C_SCHEME_FALSE);}}

/* k7435 in k7419 in k7393 in k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 651  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7427 in k7419 in k7393 in k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7429,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7406,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7412 in k7427 in k7419 in k7393 in k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7413,3,t0,t1,t2);}
/* walk1504 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7273(t3,t1,t2,((C_word*)t0)[2]);}

/* k7404 in k7427 in k7419 in k7393 in k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7407,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[227],((C_word*)t0)[2],t1);}

/* f_7407 in k7404 in k7427 in k7419 in k7393 in k7390 in a7387 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7407,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k7346 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7351,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 640  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7349 in k7346 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7351,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7362,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7369,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7368 in k7349 in k7346 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7369,3,t0,t1,t2);}
/* walk1504 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7273(t3,t1,t2,((C_word*)t0)[2]);}

/* k7360 in k7349 in k7346 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7363,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_7363 in k7360 in k7349 in k7346 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7363,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k7330 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7332,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7317,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7323 in k7330 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7324,3,t0,t1,t2);}
/* walk1504 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7273(t3,t1,t2,((C_word*)t0)[2]);}

/* k7315 in k7330 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7318,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[232],((C_word*)t0)[2],t1);}

/* f_7318 in k7315 in k7330 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7318,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k7294 in k7281 in k7278 in k7275 in walk in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 635  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),((C_word*)t0)[2],t1);}

/* rename in k7263 in ##compiler#copy-node-tree-and-rename in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7267(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7267,NULL,3,t1,t2,t3);}
/* support.scm: 629  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[274]))(6,*((C_word*)lf[274]+1),t1,t2,t3,*((C_word*)lf[275]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7148,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7154,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 606  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),t1,t2,t6);}

/* a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7154,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7160,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7166,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7166,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[93]),((C_word*)t0)[2]);}
else{
t5=t4;
f_7170(2,t5,((C_word*)t0)[2]);}}

/* k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7173,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 612  copy-node-tree-and-rename */
((C_proc5)C_retrieve_symbol_proc(lf[273]))(5,*((C_word*)lf[273]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_7173(2,t3,((C_word*)t0)[3]);}}

/* k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7178,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7199,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7253,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 618  last */
((C_proc3)C_retrieve_symbol_proc(lf[254]))(3,*((C_word*)lf[254]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7199(2,t4,t1);}}

/* k7251 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7253,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7223,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 620  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[272],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7237,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[237],t6,((C_word*)t0)[2]);}}

/* f_7237 in k7251 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7237,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k7221 in k7251 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7223,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7215,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t2);}

/* f_7215 in k7221 in k7251 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7215,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k7197 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7203,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 624  take */
((C_proc4)C_retrieve_symbol_proc(lf[271]))(4,*((C_word*)lf[271]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7201 in k7197 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 614  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[270]))(6,*((C_word*)lf[270]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7177 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7178,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7191,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[92],t5,t6);}

/* f_7191 in a7177 in k7171 in k7168 in a7165 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7191,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* a7159 in a7153 in ##compiler#inline-lambda-bindings in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7160,2,t0,t1);}
/* support.scm: 609  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[269]))(4,*((C_word*)lf[269]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7094,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7100,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7100(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7100(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7100,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7126,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 602  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k7124 in fold in ##compiler#fold-boolean in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7130,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 603  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7100(t4,t2,t3);}

/* k7128 in k7124 in fold in ##compiler#fold-boolean in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7130,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7118,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[229],lf[267],t2);}

/* f_7118 in k7128 in k7124 in fold in ##compiler#fold-boolean in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7118,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6761,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6767,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6767(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6767,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6771,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7088,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7088 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7088,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6774,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7083,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7083 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7083,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6777,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7078,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7078 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7078,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6777,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[219]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6786(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[264]);
t5=t3;
f_6786(t5,(C_truep(t4)?t4:(C_word)C_eqp(t1,lf[265])));}}

/* k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_6786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6786,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6793,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[253]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6810,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6814,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[214]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[218]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[82]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[82],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6876,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 576  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[257]))(3,*((C_word*)lf[257]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[227]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[117]:lf[227]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6901,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 583  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6767(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[239]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[230]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6934,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[220]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[259]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6958,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6958(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_7020(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
if(C_truep(t14)){
t15=t13;
f_7020(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
t16=t13;
f_7020(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[263])));}}}}}}}}}}}}}

/* k7018 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_7020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7020,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 593  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6767(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7050,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k7048 in k7018 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 594  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7044 in k7018 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7046,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7025 in k7018 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7031,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k7029 in k7025 in k7018 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 593  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[258]))(6,*((C_word*)lf[258]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_6958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6958,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6976,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 590  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7007,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 591  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6767(3,t10,t8,t9);}}

/* k7005 in loop in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 591  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6958(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6974 in loop in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6984,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 590  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6767(3,t4,t2,t3);}

/* k6982 in k6974 in loop in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6984,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[259],t3));}

/* k6932 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 585  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[258]))(5,*((C_word*)lf[258]+1),((C_word*)t0)[3],lf[230],((C_word*)t0)[2],t1);}

/* k6899 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6901,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6878 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6874 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 576  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[255]+1)))(5,*((C_word*)lf[255]+1),((C_word*)t0)[3],*((C_word*)lf[256]+1),((C_word*)t0)[2],t1);}

/* k6858 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6872,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 577  last */
((C_proc3)C_retrieve_symbol_proc(lf[254]))(3,*((C_word*)lf[254]+1),t3,((C_word*)t0)[2]);}

/* k6870 in k6858 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 577  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6767(3,t2,((C_word*)t0)[2],t1);}

/* k6866 in k6858 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6868,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* k6812 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6808 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6810,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[253],t2));}

/* k6791 in k6784 in k6775 in k6772 in k6769 in walk in ##compiler#build-expression-tree in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6152,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6155,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 560  walk */
t9=((C_word*)t6)[1];
f_6155(3,t9,t8,t2);}

/* k6754 in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6759,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 561  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,lf[250],lf[251],((C_word*)((C_word*)t0)[2])[1]);}

/* k6757 in k6754 in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word *a;
loop:
a=C_alloc(8);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_6155,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 494  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 495  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t1,lf[217],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[218]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6197,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[218],t7,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(t4,lf[219]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[220]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6225,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[82]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6250,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6253,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[224],C_retrieve(lf[225]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_6253(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_6253(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_6253(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[92]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 515  walk */
t65=t1;
t66=t11;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6307,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 516  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[226]))(3,*((C_word*)lf[226]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[117]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[227]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6371,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 520  walk */
t65=t14;
t66=t15;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[228]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6419(t17,(C_word)C_eqp(lf[82],t16));}
else{
t16=t15;
f_6419(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[229]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[230]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6456,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[231]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6483,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,lf[231],t17,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t4,lf[232]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[233]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6511,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[234]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6573,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 539  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[236]))(3,*((C_word*)lf[236]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[237]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6594,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6594(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[245]);
if(C_truep(t21)){
t22=t20;
f_6594(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[246]);
if(C_truep(t22)){
t23=t20;
f_6594(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[247]);
t24=t20;
f_6594(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[248])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6744,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6742 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6745,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[239],lf[249],t1);}

/* f_6745 in k6742 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6745,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_6594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6609,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[238]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6631,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6645,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6651,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6672,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6700,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[244]);}

/* f_6700 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6700,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t1,t2,t3);}

/* k6693 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6672(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6672(t2,C_SCHEME_FALSE);}}

/* k6670 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_6672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6672,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6676,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 555  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 557  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[242]))(3,*((C_word*)lf[242]+1),t2,((C_word*)t0)[2]);}}

/* k6677 in k6670 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6686(2,t3,t1);}
else{
/* support.scm: 556  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[242]))(3,*((C_word*)lf[242]+1),t2,((C_word*)t0)[2]);}}

/* k6684 in k6677 in k6670 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6686,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6676(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[241]),((C_word*)t0)[2],t1));}

/* k6674 in k6670 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6663,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6661 in k6674 in k6670 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6664,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[239],((C_word*)t0)[2],t1);}

/* f_6664 in k6661 in k6674 in k6670 in a6650 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6664,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* a6644 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6645,2,t0,t1);}
/* support.scm: 547  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t1,((C_word*)t0)[2]);}

/* k6629 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6632,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[239],lf[240],t1);}

/* f_6632 in k6629 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6632,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6607 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6610,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6610 in k6607 in k6592 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6610,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6571 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6573,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6553,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6557,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 540  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),t5,((C_word*)t0)[2]);}

/* k6555 in k6571 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 540  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6155(3,t2,((C_word*)t0)[2],t1);}

/* k6551 in k6571 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6545,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[234],((C_word*)t0)[2],t2);}

/* f_6545 in k6551 in k6571 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6545,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6509 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6512,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[232],((C_word*)t0)[2],t1);}

/* f_6512 in k6509 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6512,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* f_6483 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6483,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6454 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6457,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6457 in k6454 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6457,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6417 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_6419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6419,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6403,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6401 in k6417 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6404,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6404 in k6401 in k6417 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6404,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6369 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6371,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6363,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[117],((C_word*)t0)[2],t2);}

/* f_6363 in k6369 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6363,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6305 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6311,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6329 in k6305 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6330,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 517  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6155(3,t4,t1,t3);}

/* k6318 in k6305 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6328,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 518  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6155(3,t3,t2,((C_word*)t0)[2]);}

/* k6326 in k6318 in k6305 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6328,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 517  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6309 in k6305 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6312,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],t1);}

/* f_6312 in k6309 in k6305 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6312,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* k6251 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_6253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6253,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 506  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,lf[222],lf[223],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6250(t2,((C_word*)t0)[2]);}}

/* k6254 in k6251 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6263,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 509  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[221]+1)))(3,*((C_word*)lf[221]+1),t2,((C_word*)t0)[2]);}

/* k6261 in k6254 in k6251 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6250(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k6248 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_6250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 502  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),((C_word*)t0)[2],t1);}

/* k6223 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6226,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* f_6226 in k6223 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6226,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* f_6197 in walk in ##compiler#build-node-graph in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6197,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* ##compiler#qnode in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6137,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6146,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[82],t3,C_SCHEME_END_OF_LIST);}

/* f_6146 in ##compiler#qnode in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6146,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* ##compiler#varnode in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6122,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6131,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[214],t3,C_SCHEME_END_OF_LIST);}

/* f_6131 in ##compiler#varnode in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6131,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* make-node in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6116,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* node-subexpressions in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6107,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[204]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6098,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[204]);
/* ##sys#block-set! */
t5=*((C_word*)lf[207]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6089,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[204]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6080,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[204]);
/* ##sys#block-set! */
t5=*((C_word*)lf[207]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6071,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[204]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6062,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[204]);
/* ##sys#block-set! */
t5=*((C_word*)lf[207]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6056,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[204]));}

/* f_6050 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6050,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[204],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5572,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5576,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5576(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6048,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 425  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),t4,C_retrieve(lf[201]),C_retrieve(lf[202]),C_retrieve(lf[127]));}}

/* k6046 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5576(t3,t2);}

/* k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5576,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 428  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[151]))(4,*((C_word*)lf[151]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5581,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5591,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 436  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[200]+1)))(3,*((C_word*)lf[200]+1),t14,t2);}}

/* k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5739(t6,t2,((C_word*)t0)[2]);}

/* loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5739(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5739,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 440  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5752,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[159]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5765(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t5)){
t6=t4;
f_5765(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t6)){
t7=t4;
f_5765(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t7)){
t8=t4;
f_5765(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t8)){
t9=t4;
f_5765(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t9)){
t10=t4;
f_5765(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t10)){
t11=t4;
f_5765(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t11)){
t12=t4;
f_5765(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t12)){
t13=t4;
f_5765(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t13)){
t14=t4;
f_5765(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t14)){
t15=t4;
f_5765(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t15)){
t16=t4;
f_5765(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t16)){
t17=t4;
f_5765(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t17)){
t18=t4;
f_5765(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t18)){
t19=t4;
f_5765(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t19)){
t20=t4;
f_5765(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t20)){
t21=t4;
f_5765(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t21)){
t22=t4;
f_5765(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t22)){
t23=t4;
f_5765(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[198]);
t24=t4;
f_5765(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[199])));}}}}}}}}}}}}}}}}}}}}

/* k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5765,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5780,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 444  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[158]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[158]);
t4=((C_word*)t0)[9];
f_5752(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[163]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[158]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5752(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 448  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[165]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[158]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5752(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 450  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[166]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5829,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 452  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[167]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5838(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[172]);
if(C_truep(t8)){
t9=t7;
f_5838(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t9)){
t10=t7;
f_5838(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[146]);
if(C_truep(t10)){
t11=t7;
f_5838(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t11)){
t12=t7;
f_5838(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t12)){
t13=t7;
f_5838(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t13)){
t14=t7;
f_5838(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
if(C_truep(t14)){
t15=t7;
f_5838(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[178]);
t16=t7;
f_5838(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[179])));}}}}}}}}}}}}}}

/* k5836 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5838,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 455  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[169]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 457  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[170]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 459  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 460  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[6],lf[171],t4);}}}}

/* k5867 in k5836 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5752(2,t3,t2);}

/* k5857 in k5836 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5752(2,t3,t2);}

/* k5843 in k5836 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5849,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 455  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[164]+1)))(3,*((C_word*)lf[164]+1),t2,((C_word*)t0)[2]);}

/* k5847 in k5843 in k5836 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 455  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[168],((C_word*)t0)[2],t1);}

/* k5827 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5752(2,t3,t2);}

/* k5817 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5752(2,t3,t2);}

/* k5801 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5752(2,t3,t2);}

/* k5778 in k5763 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[160]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 444  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[161],t3);}

/* k5750 in k5747 in loop in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 461  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5739(t3,((C_word*)t0)[2],t2);}

/* k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[158]);
t5=t3;
f_5629(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5629(t4,C_SCHEME_FALSE);}}

/* k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5629,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5650,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5660,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[158]);
t4=t2;
f_5660(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5660(t3,C_SCHEME_FALSE);}}}

/* k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5660,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5681,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[158]);
t4=t2;
f_5691(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5691(t3,C_SCHEME_FALSE);}}}

/* k5689 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5691,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5712,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_5597(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5712 in k5689 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5712,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5700 in k5689 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5707,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5707 in k5700 in k5689 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5707,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5704 in k5700 in k5689 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5706,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 467  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[157],t2);}

/* f_5681 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5681,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5669 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5676,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5676 in k5669 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5676,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5673 in k5669 in k5658 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 465  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[156],t2);}

/* f_5650 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5650,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5638 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5644,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5645,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5645 in k5638 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5645,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5642 in k5638 in k5627 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5644,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 463  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[155],t2);}

/* k5595 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 468  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[154],t3);}
else{
t3=t2;
f_5600(2,t3,C_SCHEME_UNDEFINED);}}

/* k5598 in k5595 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 469  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[153],t3);}
else{
t3=t2;
f_5603(2,t3,C_SCHEME_UNDEFINED);}}

/* k5601 in k5598 in k5595 in k5592 in k5589 in a5580 in k5574 in ##compiler#display-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 470  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5559,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 407  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[151]))(4,*((C_word*)lf[151]+1),t1,t2,C_retrieve(lf[143]));}

/* a5558 in ##compiler#display-line-number-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5559,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5570,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[150]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5568 in a5558 in ##compiler#display-line-number-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 409  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[148],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5529,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5535,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5535(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5535(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5535,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5545,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 403  get */
((C_proc5)C_retrieve_symbol_proc(lf[134]))(5,*((C_word*)lf[134]+1),t4,((C_word*)t0)[2],t2,lf[146]);}}

/* k5543 in loop in ##compiler#find-lambda-container in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 404  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5535(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5493,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5500,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 395  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t4,C_retrieve(lf[143]),t3);}

/* k5498 in ##compiler#get-line-2 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5503(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5503(t3,C_SCHEME_FALSE);}}

/* k5501 in k5498 in ##compiler#get-line-2 in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_5503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 397  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 398  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5483,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 391  get */
((C_proc5)C_retrieve_symbol_proc(lf[134]))(5,*((C_word*)lf[134]+1),t1,C_retrieve(lf[143]),t3,t2);}

/* ##compiler#count! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5426r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5426r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5426r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5430,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 379  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t6,t2,t3);}

/* k5428 in ##compiler#count! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5460,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 384  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 385  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5458 in k5428 in ##compiler#count! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5374,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5378,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 371  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t6,t2,t3);}

/* k5376 in ##compiler#collect! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5378,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5405,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 375  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 376  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5403 in k5376 in ##compiler#collect! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5328,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5332,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 363  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t6,t2,t3);}

/* k5330 in ##compiler#put! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5332,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5354,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 367  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 368  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5352 in k5330 in ##compiler#put! in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5310r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5310r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5310r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5314,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 357  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t5,t2,t3);}

/* k5312 in ##compiler#get-all in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5314,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5322,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 359  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5321 in k5312 in ##compiler#get-all in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5322,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5292,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5296,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 351  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t5,t2,t3);}

/* k5294 in ##compiler#get in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5141,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5145,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5149,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5223,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[133]));}
else{
t4=t3;
f_5145(2,t4,C_SCHEME_UNDEFINED);}}

/* a5222 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5223,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5227,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5264,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[125],lf[132]);}

/* f_5264 in a5222 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5264r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5264r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5264r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5268,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5268(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5268(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5266 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5225 in a5222 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5227,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],C_retrieve(lf[130])))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5237,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[131],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5237 in k5225 in a5222 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5237r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5237r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5237r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5241,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5241(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5241(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5239 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5147 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5190,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[129]));}

/* a5189 in k5147 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5190,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5195,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[125],lf[128]);}

/* f_5195 in a5189 in k5147 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5195r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5195r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5195r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5199,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5199(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5199(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5197 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5150 in k5147 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5157,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[127]));}

/* a5156 in k5150 in k5147 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5157,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5162,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[125],lf[126]);}

/* f_5162 in a5156 in k5150 in k5147 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5162r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5162r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5166,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5166(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5166(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5164 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5143 in ##compiler#initialize-analysis-database in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5000,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[113]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5004,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 313  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t6);}

/* k5002 in ##compiler#expand-profile-lambda in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 314  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[114]));}

/* k5006 in k5002 in ##compiler#expand-profile-lambda in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5008,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[113]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[115]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[116],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[117],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[117],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[118],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[117],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[82],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[115]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[119],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[117],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[120],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[117],t35));}

/* ##compiler#llist-length in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4997,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_length(t2));}

/* ##compiler#process-lambda-documentation in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4994,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4887,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4894,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[107]+1)))(3,*((C_word*)lf[107]+1),t3,t4);}

/* a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4896,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4902,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4927,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t1,t3,t4);}

/* a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4980 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4981r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4981r(t0,t1,t2);}}

static void C_ccall f_4981r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4987,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4986 in a4980 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4987,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4932 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4965,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 295  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t2,((C_word*)t0)[2],t3);}

/* a4964 in a4932 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4971,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4979,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 295  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t3);}

/* k4977 in a4964 in a4932 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 295  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[102]))(6,*((C_word*)lf[102]+1),((C_word*)t0)[3],*((C_word*)lf[103]+1),*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* a4970 in a4964 in a4932 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4971,3,t0,t1,t2);}
/* support.scm: 295  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t1);}

/* k4935 in a4932 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4937,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[98]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4957 in k4935 in a4932 in a4926 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4959,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[99],t1));}

/* a4901 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4902,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k573579 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4907 in a4901 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 292  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4917 in a4907 in a4901 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 293  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 294  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4914 in a4907 in a4901 in a4895 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 290  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* k4892 in ##compiler#string->expr in k4884 in k4881 in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4786,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4792,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4792(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4792(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4792,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[90]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[91]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4820,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4820(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4869,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 279  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t7,t4);}}}}

/* k4867 in loop in ##compiler#canonicalize-begin-body in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4820(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[95])));}

/* k4818 in loop in ##compiler#canonicalize-begin-body in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4820,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 281  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4792(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 282  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[94]);}}

/* k4856 in k4818 in loop in ##compiler#canonicalize-begin-body in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 283  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4792(t8,t6,t7);}

/* k4844 in k4856 in k4818 in loop in ##compiler#canonicalize-begin-body in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[92],t3));}

/* ##compiler#basic-literal? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4726,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4742,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 264  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),t5,t2);}}}

/* k4740 in ##compiler#basic-literal? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4784,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 265  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[88]+1)))(3,*((C_word*)lf[88]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4748(2,t3,C_SCHEME_FALSE);}}}

/* k4782 in k4740 in ##compiler#basic-literal? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 265  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[2],C_retrieve(lf[86]),t1);}

/* k4746 in k4740 in ##compiler#basic-literal? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 267  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4761 in k4746 in k4740 in ##compiler#basic-literal? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 268  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4680,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4684,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4724,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 254  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t4,t2);}
else{
t4=t3;
f_4684(t4,C_SCHEME_FALSE);}}

/* k4722 in ##compiler#immediate? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4684(t2,(C_word)C_i_not(t1));}

/* k4682 in ##compiler#immediate? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4650,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4604,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[82],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4584,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4590,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 233  sort */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,t3);}

/* a4589 in ##compiler#sort-symbols in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4590,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4598,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 233  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t4,t2);}

/* k4596 in a4589 in ##compiler#sort-symbols in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 233  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2]);}

/* k4600 in k4596 in a4589 in ##compiler#sort-symbols in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 233  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[79]+1)))(4,*((C_word*)lf[79]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4553,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4559(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4559,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 229  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 230  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4573 in loop in ##compiler#follow-without-loop in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4574,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 230  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4559(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4490,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4504,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 219  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t5,t3);}}

/* k4502 in ##compiler#fold-inner in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4504,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4506,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4506(t5,((C_word*)t0)[2],t1);}

/* fold in k4502 in ##compiler#fold-inner in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4506,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4514(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 224  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4533 in fold in k4502 in ##compiler#fold-inner in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4514(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4512 in fold in k4502 in ##compiler#fold-inner in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4478,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[73]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 214  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[74]+1)))(3,*((C_word*)lf[74]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4431r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4431r(t0,t1,t2,t3);}}

static void C_ccall f_4431r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[66]))){
/* support.scm: 208  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[67]+1)))(2,*((C_word*)lf[67]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4447,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 209  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),t4,t2);}}

/* k4445 in ##compiler#check-and-open-input-file in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 209  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[68]+1)))(3,*((C_word*)lf[68]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4459(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4459(t5,(C_word)C_i_not(t4));}}}

/* k4457 in k4445 in ##compiler#check-and-open-input-file in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 210  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[69],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 211  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[70],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4424,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub331(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4417,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub326(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4361,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4365,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4415,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 189  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t4,t2);}

/* k4413 in ##compiler#valid-c-identifier? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4363 in ##compiler#valid-c-identifier? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4388,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 193  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4387 in k4363 in ##compiler#valid-c-identifier? in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4388,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4267,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4279,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4283,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4283,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4285,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4285(t5,((C_word*)t0)[2],t1);}

/* loop in k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4285(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4285,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[53]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4307,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4307(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4307(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[59])));}}}

/* k4305 in loop in k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4307,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4314(t3,lf[57]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4314(t4,(C_truep(t3)?lf[58]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 186  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4285(t4,t2,t3);}}

/* k4344 in k4305 in loop in k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4312 in k4305 in loop in k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4314,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 184  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4328 in k4312 in k4305 in loop in k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4316 in k4312 in k4305 in loop in k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4322,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 185  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4285(t4,t2,t3);}

/* k4320 in k4316 in k4312 in k4305 in loop in k4281 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 180  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[54]+1)))(6,*((C_word*)lf[54]+1),((C_word*)t0)[4],lf[55],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4277 in ##compiler#c-ify-string in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[52]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4223,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4229,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4229(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4229(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4229,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4253,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 166  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4251 in loop in ##compiler#build-lambda-list in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4198,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 160  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4221,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 161  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t3,lf[47],t2);}}}

/* k4219 in ##compiler#symbolify in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 161  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4177,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 155  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t1,t2);}
else{
/* support.scm: 156  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,lf[44],t2);}}}

/* ##compiler#posq in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4141,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4147,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4147(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static C_word C_fcall f_4147(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4073,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4076,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4097,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4097(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4097,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 139  err */
t4=((C_word*)t0)[3];
f_4076(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 141  err */
t5=((C_word*)t0)[3];
f_4076(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 142  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4076,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 136  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k4082 in err in ##compiler#check-signature in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4088,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 137  map-llist */
((C_proc4)C_retrieve_symbol_proc(lf[36]))(4,*((C_word*)lf[36]+1),t2,C_retrieve(lf[39]),t3);}

/* k4086 in k4082 in err in ##compiler#check-signature in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 135  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}

/* map-llist in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4030,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4036,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4036(t7,t1,t3);}

/* loop in map-llist in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_4036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4036,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 130  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 131  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4057 in loop in map-llist in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4063,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 131  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4036(t4,t2,t3);}

/* k4061 in k4057 in loop in map-llist in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4027,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[30])));}

/* ##sys#syntax-error-hook in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4002r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4002r(t0,t1,t2,t3);}}

static void C_ccall f_4002r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4006,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 116  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k4004 in ##sys#syntax-error-hook in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t2,t1,lf[33],((C_word*)t0)[2]);}

/* k4007 in k4004 in ##sys#syntax-error-hook in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4019 in k4007 in k4004 in ##sys#syntax-error-hook in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4020,3,t0,t1,t2);}
/* fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t1,((C_word*)t0)[2],lf[32],t2);}

/* k4010 in k4007 in k4004 in ##sys#syntax-error-hook in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 119  print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[29]))(6,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[30]),lf[31]);}

/* k4013 in k4010 in k4007 in k4004 in ##sys#syntax-error-hook in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 120  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3983r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3983r(t0,t1,t2,t3);}}

static void C_ccall f_3983r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3987,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 109  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k3985 in quit in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[27],((C_word*)t0)[2]);}

/* k3998 in k3985 in quit in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3988 in k3985 in quit in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 111  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2]);}

/* k3991 in k3988 in k3985 in quit in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 112  exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3954r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3954r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3954r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[24]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_3961(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3961(t6,C_SCHEME_FALSE);}}

/* k3959 in ##compiler#compiler-warning in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_fcall f_3961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3961,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 104  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3962 in k3959 in ##compiler#compiler-warning in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3967,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[22],((C_word*)t0)[2]);}

/* k3972 in k3962 in k3959 in ##compiler#compiler-warning in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3965 in k3962 in k3959 in ##compiler#compiler-warning in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 106  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3914r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3914r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3914r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3924,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 93   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t5,lf[19],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3922 in ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 96   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_3927(2,t3,C_SCHEME_UNDEFINED);}}

/* k3937 in k3922 in ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3944,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3943 in k3937 in k3922 in ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3944,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3952,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 97   force */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k3950 in a3943 in k3937 in k3922 in ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 97   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14],t1);}

/* k3925 in k3922 in ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k3928 in k3925 in k3922 in ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t2);}

/* k3931 in k3928 in k3925 in k3922 in ##compiler#debugging in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3887r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3887r(t0,t1,t2);}}

static void C_ccall f_3887r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3901,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 87   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 88   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k3899 in ##compiler#bomb in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3876 in k3873 in k3870 in k3867 in k3864 in k3861 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[683] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3863:support_scm",(void*)f_3863},
{"f_3866:support_scm",(void*)f_3866},
{"f_3869:support_scm",(void*)f_3869},
{"f_3872:support_scm",(void*)f_3872},
{"f_3875:support_scm",(void*)f_3875},
{"f_3878:support_scm",(void*)f_3878},
{"f_4883:support_scm",(void*)f_4883},
{"f_4886:support_scm",(void*)f_4886},
{"f_11871:support_scm",(void*)f_11871},
{"f_11885:support_scm",(void*)f_11885},
{"f_11889:support_scm",(void*)f_11889},
{"f_11900:support_scm",(void*)f_11900},
{"f_11912:support_scm",(void*)f_11912},
{"f_11920:support_scm",(void*)f_11920},
{"f_11924:support_scm",(void*)f_11924},
{"f_11883:support_scm",(void*)f_11883},
{"f_11874:support_scm",(void*)f_11874},
{"f_11877:support_scm",(void*)f_11877},
{"f_11858:support_scm",(void*)f_11858},
{"f_11863:support_scm",(void*)f_11863},
{"f_11847:support_scm",(void*)f_11847},
{"f_11852:support_scm",(void*)f_11852},
{"f_11841:support_scm",(void*)f_11841},
{"f_11813:support_scm",(void*)f_11813},
{"f_11817:support_scm",(void*)f_11817},
{"f_11792:support_scm",(void*)f_11792},
{"f_11796:support_scm",(void*)f_11796},
{"f_11759:support_scm",(void*)f_11759},
{"f_11764:support_scm",(void*)f_11764},
{"f_11768:support_scm",(void*)f_11768},
{"f_11726:support_scm",(void*)f_11726},
{"f_11731:support_scm",(void*)f_11731},
{"f_11735:support_scm",(void*)f_11735},
{"f_11702:support_scm",(void*)f_11702},
{"f_11633:support_scm",(void*)f_11633},
{"f_11637:support_scm",(void*)f_11637},
{"f_11642:support_scm",(void*)f_11642},
{"f_11646:support_scm",(void*)f_11646},
{"f_11697:support_scm",(void*)f_11697},
{"f_11676:support_scm",(void*)f_11676},
{"f_11688:support_scm",(void*)f_11688},
{"f_11691:support_scm",(void*)f_11691},
{"f_11664:support_scm",(void*)f_11664},
{"f_11600:support_scm",(void*)f_11600},
{"f_11610:support_scm",(void*)f_11610},
{"f_11613:support_scm",(void*)f_11613},
{"f_11498:support_scm",(void*)f_11498},
{"f_11507:support_scm",(void*)f_11507},
{"f_11594:support_scm",(void*)f_11594},
{"f_11511:support_scm",(void*)f_11511},
{"f_11589:support_scm",(void*)f_11589},
{"f_11514:support_scm",(void*)f_11514},
{"f_11584:support_scm",(void*)f_11584},
{"f_11517:support_scm",(void*)f_11517},
{"f_11520:support_scm",(void*)f_11520},
{"f_11526:support_scm",(void*)f_11526},
{"f_11579:support_scm",(void*)f_11579},
{"f_11529:support_scm",(void*)f_11529},
{"f_11544:support_scm",(void*)f_11544},
{"f_11552:support_scm",(void*)f_11552},
{"f_11562:support_scm",(void*)f_11562},
{"f_11547:support_scm",(void*)f_11547},
{"f_11535:support_scm",(void*)f_11535},
{"f_11502:support_scm",(void*)f_11502},
{"f_11492:support_scm",(void*)f_11492},
{"f_11446:support_scm",(void*)f_11446},
{"f_11465:support_scm",(void*)f_11465},
{"f_11476:support_scm",(void*)f_11476},
{"f_11472:support_scm",(void*)f_11472},
{"f_11434:support_scm",(void*)f_11434},
{"f_11440:support_scm",(void*)f_11440},
{"f_11422:support_scm",(void*)f_11422},
{"f_11426:support_scm",(void*)f_11426},
{"f_11343:support_scm",(void*)f_11343},
{"f_11362:support_scm",(void*)f_11362},
{"f_11387:support_scm",(void*)f_11387},
{"f_11391:support_scm",(void*)f_11391},
{"f_11393:support_scm",(void*)f_11393},
{"f_11400:support_scm",(void*)f_11400},
{"f_11413:support_scm",(void*)f_11413},
{"f_11417:support_scm",(void*)f_11417},
{"f_11346:support_scm",(void*)f_11346},
{"f_11350:support_scm",(void*)f_11350},
{"f_11356:support_scm",(void*)f_11356},
{"f_11337:support_scm",(void*)f_11337},
{"f_11293:support_scm",(void*)f_11293},
{"f_11305:support_scm",(void*)f_11305},
{"f_11309:support_scm",(void*)f_11309},
{"f_11313:support_scm",(void*)f_11313},
{"f_11301:support_scm",(void*)f_11301},
{"f_11284:support_scm",(void*)f_11284},
{"f_11278:support_scm",(void*)f_11278},
{"f_11272:support_scm",(void*)f_11272},
{"f_11260:support_scm",(void*)f_11260},
{"f_11264:support_scm",(void*)f_11264},
{"f_11267:support_scm",(void*)f_11267},
{"f_11222:support_scm",(void*)f_11222},
{"f_11226:support_scm",(void*)f_11226},
{"f_11229:support_scm",(void*)f_11229},
{"f_11236:support_scm",(void*)f_11236},
{"f_11180:support_scm",(void*)f_11180},
{"f_11189:support_scm",(void*)f_11189},
{"f_11151:support_scm",(void*)f_11151},
{"f_11161:support_scm",(void*)f_11161},
{"f_10954:support_scm",(void*)f_10954},
{"f_11133:support_scm",(void*)f_11133},
{"f_11082:support_scm",(void*)f_11082},
{"f_11127:support_scm",(void*)f_11127},
{"f_11131:support_scm",(void*)f_11131},
{"f_11085:support_scm",(void*)f_11085},
{"f_11090:support_scm",(void*)f_11090},
{"f_11094:support_scm",(void*)f_11094},
{"f_11088:support_scm",(void*)f_11088},
{"f_11045:support_scm",(void*)f_11045},
{"f_11049:support_scm",(void*)f_11049},
{"f_11058:support_scm",(void*)f_11058},
{"f_11062:support_scm",(void*)f_11062},
{"f_11052:support_scm",(void*)f_11052},
{"f_11010:support_scm",(void*)f_11010},
{"f_11016:support_scm",(void*)f_11016},
{"f_11043:support_scm",(void*)f_11043},
{"f_11029:support_scm",(void*)f_11029},
{"f_10963:support_scm",(void*)f_10963},
{"f_10969:support_scm",(void*)f_10969},
{"f_11008:support_scm",(void*)f_11008},
{"f_10990:support_scm",(void*)f_10990},
{"f_10767:support_scm",(void*)f_10767},
{"f_10949:support_scm",(void*)f_10949},
{"f_10936:support_scm",(void*)f_10936},
{"f_10942:support_scm",(void*)f_10942},
{"f_10770:support_scm",(void*)f_10770},
{"f_10930:support_scm",(void*)f_10930},
{"f_10774:support_scm",(void*)f_10774},
{"f_10925:support_scm",(void*)f_10925},
{"f_10777:support_scm",(void*)f_10777},
{"f_10920:support_scm",(void*)f_10920},
{"f_10780:support_scm",(void*)f_10780},
{"f_10789:support_scm",(void*)f_10789},
{"f_10883:support_scm",(void*)f_10883},
{"f_10895:support_scm",(void*)f_10895},
{"f_10853:support_scm",(void*)f_10853},
{"f_10864:support_scm",(void*)f_10864},
{"f_10844:support_scm",(void*)f_10844},
{"f_10830:support_scm",(void*)f_10830},
{"f_10808:support_scm",(void*)f_10808},
{"f_10814:support_scm",(void*)f_10814},
{"f_10818:support_scm",(void*)f_10818},
{"f_10674:support_scm",(void*)f_10674},
{"f_10680:support_scm",(void*)f_10680},
{"f_10761:support_scm",(void*)f_10761},
{"f_10684:support_scm",(void*)f_10684},
{"f_10756:support_scm",(void*)f_10756},
{"f_10687:support_scm",(void*)f_10687},
{"f_10740:support_scm",(void*)f_10740},
{"f_10727:support_scm",(void*)f_10727},
{"f_10726:support_scm",(void*)f_10726},
{"f_10708:support_scm",(void*)f_10708},
{"f_10702:support_scm",(void*)f_10702},
{"f_10678:support_scm",(void*)f_10678},
{"f_10382:support_scm",(void*)f_10382},
{"f_10578:support_scm",(void*)f_10578},
{"f_10599:support_scm",(void*)f_10599},
{"f_10072:support_scm",(void*)f_10072},
{"f_10376:support_scm",(void*)f_10376},
{"f_10084:support_scm",(void*)f_10084},
{"f_10094:support_scm",(void*)f_10094},
{"f_10112:support_scm",(void*)f_10112},
{"f_10146:support_scm",(void*)f_10146},
{"f_10075:support_scm",(void*)f_10075},
{"f_9753:support_scm",(void*)f_9753},
{"f_10066:support_scm",(void*)f_10066},
{"f_9759:support_scm",(void*)f_9759},
{"f_9769:support_scm",(void*)f_9769},
{"f_9778:support_scm",(void*)f_9778},
{"f_9790:support_scm",(void*)f_9790},
{"f_9802:support_scm",(void*)f_9802},
{"f_9808:support_scm",(void*)f_9808},
{"f_9842:support_scm",(void*)f_9842},
{"f_9713:support_scm",(void*)f_9713},
{"f_9747:support_scm",(void*)f_9747},
{"f_9719:support_scm",(void*)f_9719},
{"f_9723:support_scm",(void*)f_9723},
{"f_9682:support_scm",(void*)f_9682},
{"f_9695:support_scm",(void*)f_9695},
{"f_9686:support_scm",(void*)f_9686},
{"f_9651:support_scm",(void*)f_9651},
{"f_9664:support_scm",(void*)f_9664},
{"f_9655:support_scm",(void*)f_9655},
{"f_8604:support_scm",(void*)f_8604},
{"f_9645:support_scm",(void*)f_9645},
{"f_8610:support_scm",(void*)f_8610},
{"f_8616:support_scm",(void*)f_8616},
{"f_8645:support_scm",(void*)f_8645},
{"f_8664:support_scm",(void*)f_8664},
{"f_8683:support_scm",(void*)f_8683},
{"f_8753:support_scm",(void*)f_8753},
{"f_8772:support_scm",(void*)f_8772},
{"f_8854:support_scm",(void*)f_8854},
{"f_8893:support_scm",(void*)f_8893},
{"f_8912:support_scm",(void*)f_8912},
{"f_8931:support_scm",(void*)f_8931},
{"f_9011:support_scm",(void*)f_9011},
{"f_9096:support_scm",(void*)f_9096},
{"f_9171:support_scm",(void*)f_9171},
{"f_9205:support_scm",(void*)f_9205},
{"f_9275:support_scm",(void*)f_9275},
{"f_9208:support_scm",(void*)f_9208},
{"f_9014:support_scm",(void*)f_9014},
{"f_9045:support_scm",(void*)f_9045},
{"f_8934:support_scm",(void*)f_8934},
{"f_8775:support_scm",(void*)f_8775},
{"f_8806:support_scm",(void*)f_8806},
{"f_8686:support_scm",(void*)f_8686},
{"f_8717:support_scm",(void*)f_8717},
{"f_8568:support_scm",(void*)f_8568},
{"f_8572:support_scm",(void*)f_8572},
{"f_8583:support_scm",(void*)f_8583},
{"f_8589:support_scm",(void*)f_8589},
{"f_8593:support_scm",(void*)f_8593},
{"f_8575:support_scm",(void*)f_8575},
{"f_8529:support_scm",(void*)f_8529},
{"f_8541:support_scm",(void*)f_8541},
{"f_8548:support_scm",(void*)f_8548},
{"f_8551:support_scm",(void*)f_8551},
{"f_8554:support_scm",(void*)f_8554},
{"f_8557:support_scm",(void*)f_8557},
{"f_8560:support_scm",(void*)f_8560},
{"f_8563:support_scm",(void*)f_8563},
{"f_8535:support_scm",(void*)f_8535},
{"f_8443:support_scm",(void*)f_8443},
{"f_8452:support_scm",(void*)f_8452},
{"f_8458:support_scm",(void*)f_8458},
{"f_8505:support_scm",(void*)f_8505},
{"f_8500:support_scm",(void*)f_8500},
{"f_8447:support_scm",(void*)f_8447},
{"f_8422:support_scm",(void*)f_8422},
{"f_8432:support_scm",(void*)f_8432},
{"f_8391:support_scm",(void*)f_8391},
{"f_8397:support_scm",(void*)f_8397},
{"f_8404:support_scm",(void*)f_8404},
{"f_8407:support_scm",(void*)f_8407},
{"f_8269:support_scm",(void*)f_8269},
{"f_8385:support_scm",(void*)f_8385},
{"f_8273:support_scm",(void*)f_8273},
{"f_8293:support_scm",(void*)f_8293},
{"f_8374:support_scm",(void*)f_8374},
{"f_8297:support_scm",(void*)f_8297},
{"f_8369:support_scm",(void*)f_8369},
{"f_8368:support_scm",(void*)f_8368},
{"f_8351:support_scm",(void*)f_8351},
{"f_8306:support_scm",(void*)f_8306},
{"f_8346:support_scm",(void*)f_8346},
{"f_8345:support_scm",(void*)f_8345},
{"f_8337:support_scm",(void*)f_8337},
{"f_8336:support_scm",(void*)f_8336},
{"f_8168:support_scm",(void*)f_8168},
{"f_8174:support_scm",(void*)f_8174},
{"f_8263:support_scm",(void*)f_8263},
{"f_8178:support_scm",(void*)f_8178},
{"f_8258:support_scm",(void*)f_8258},
{"f_8181:support_scm",(void*)f_8181},
{"f_8190:support_scm",(void*)f_8190},
{"f_8217:support_scm",(void*)f_8217},
{"f_8216:support_scm",(void*)f_8216},
{"f_8204:support_scm",(void*)f_8204},
{"f_8212:support_scm",(void*)f_8212},
{"f_7948:support_scm",(void*)f_7948},
{"f_8142:support_scm",(void*)f_8142},
{"f_8162:support_scm",(void*)f_8162},
{"f_8152:support_scm",(void*)f_8152},
{"f_8157:support_scm",(void*)f_8157},
{"f_8156:support_scm",(void*)f_8156},
{"f_8148:support_scm",(void*)f_8148},
{"f_8023:support_scm",(void*)f_8023},
{"f_8135:support_scm",(void*)f_8135},
{"f_8130:support_scm",(void*)f_8130},
{"f_8122:support_scm",(void*)f_8122},
{"f_8117:support_scm",(void*)f_8117},
{"f_8045:support_scm",(void*)f_8045},
{"f_8109:support_scm",(void*)f_8109},
{"f_8052:support_scm",(void*)f_8052},
{"f_8058:support_scm",(void*)f_8058},
{"f_8089:support_scm",(void*)f_8089},
{"f_7980:support_scm",(void*)f_7980},
{"f_8002:support_scm",(void*)f_8002},
{"f_7951:support_scm",(void*)f_7951},
{"f_7975:support_scm",(void*)f_7975},
{"f_7879:support_scm",(void*)f_7879},
{"f_7885:support_scm",(void*)f_7885},
{"f_7891:support_scm",(void*)f_7891},
{"f_7895:support_scm",(void*)f_7895},
{"f_7915:support_scm",(void*)f_7915},
{"f_7916:support_scm",(void*)f_7916},
{"f_7920:support_scm",(void*)f_7920},
{"f_7904:support_scm",(void*)f_7904},
{"f_7677:support_scm",(void*)f_7677},
{"f_7708:support_scm",(void*)f_7708},
{"f_7877:support_scm",(void*)f_7877},
{"f_7712:support_scm",(void*)f_7712},
{"f_7720:support_scm",(void*)f_7720},
{"f_7727:support_scm",(void*)f_7727},
{"f_7869:support_scm",(void*)f_7869},
{"f_7863:support_scm",(void*)f_7863},
{"f_7864:support_scm",(void*)f_7864},
{"f_7859:support_scm",(void*)f_7859},
{"f_7751:support_scm",(void*)f_7751},
{"f_7840:support_scm",(void*)f_7840},
{"f_7760:support_scm",(void*)f_7760},
{"f_7769:support_scm",(void*)f_7769},
{"f_7831:support_scm",(void*)f_7831},
{"f_7823:support_scm",(void*)f_7823},
{"f_7781:support_scm",(void*)f_7781},
{"f_7784:support_scm",(void*)f_7784},
{"f_7802:support_scm",(void*)f_7802},
{"f_7791:support_scm",(void*)f_7791},
{"f_7715:support_scm",(void*)f_7715},
{"f_7681:support_scm",(void*)f_7681},
{"f_7687:support_scm",(void*)f_7687},
{"f_7700:support_scm",(void*)f_7700},
{"f_7692:support_scm",(void*)f_7692},
{"f_7644:support_scm",(void*)f_7644},
{"f_7650:support_scm",(void*)f_7650},
{"f_7666:support_scm",(void*)f_7666},
{"f_7667:support_scm",(void*)f_7667},
{"f_7593:support_scm",(void*)f_7593},
{"f_7599:support_scm",(void*)f_7599},
{"f_7638:support_scm",(void*)f_7638},
{"f_7607:support_scm",(void*)f_7607},
{"f_7633:support_scm",(void*)f_7633},
{"f_7615:support_scm",(void*)f_7615},
{"f_7628:support_scm",(void*)f_7628},
{"f_7627:support_scm",(void*)f_7627},
{"f_7623:support_scm",(void*)f_7623},
{"f_7619:support_scm",(void*)f_7619},
{"f_7516:support_scm",(void*)f_7516},
{"f_7587:support_scm",(void*)f_7587},
{"f_7586:support_scm",(void*)f_7586},
{"f_7520:support_scm",(void*)f_7520},
{"f_7578:support_scm",(void*)f_7578},
{"f_7577:support_scm",(void*)f_7577},
{"f_7523:support_scm",(void*)f_7523},
{"f_7569:support_scm",(void*)f_7569},
{"f_7568:support_scm",(void*)f_7568},
{"f_7526:support_scm",(void*)f_7526},
{"f_7537:support_scm",(void*)f_7537},
{"f_7482:support_scm",(void*)f_7482},
{"f_7488:support_scm",(void*)f_7488},
{"f_7502:support_scm",(void*)f_7502},
{"f_7506:support_scm",(void*)f_7506},
{"f_7261:support_scm",(void*)f_7261},
{"f_7265:support_scm",(void*)f_7265},
{"f_7273:support_scm",(void*)f_7273},
{"f_7473:support_scm",(void*)f_7473},
{"f_7277:support_scm",(void*)f_7277},
{"f_7468:support_scm",(void*)f_7468},
{"f_7280:support_scm",(void*)f_7280},
{"f_7463:support_scm",(void*)f_7463},
{"f_7283:support_scm",(void*)f_7283},
{"f_7447:support_scm",(void*)f_7447},
{"f_7458:support_scm",(void*)f_7458},
{"f_7451:support_scm",(void*)f_7451},
{"f_7452:support_scm",(void*)f_7452},
{"f_7388:support_scm",(void*)f_7388},
{"f_7392:support_scm",(void*)f_7392},
{"f_7395:support_scm",(void*)f_7395},
{"f_7421:support_scm",(void*)f_7421},
{"f_7437:support_scm",(void*)f_7437},
{"f_7429:support_scm",(void*)f_7429},
{"f_7413:support_scm",(void*)f_7413},
{"f_7406:support_scm",(void*)f_7406},
{"f_7407:support_scm",(void*)f_7407},
{"f_7348:support_scm",(void*)f_7348},
{"f_7351:support_scm",(void*)f_7351},
{"f_7369:support_scm",(void*)f_7369},
{"f_7362:support_scm",(void*)f_7362},
{"f_7363:support_scm",(void*)f_7363},
{"f_7332:support_scm",(void*)f_7332},
{"f_7324:support_scm",(void*)f_7324},
{"f_7317:support_scm",(void*)f_7317},
{"f_7318:support_scm",(void*)f_7318},
{"f_7296:support_scm",(void*)f_7296},
{"f_7267:support_scm",(void*)f_7267},
{"f_7148:support_scm",(void*)f_7148},
{"f_7154:support_scm",(void*)f_7154},
{"f_7166:support_scm",(void*)f_7166},
{"f_7170:support_scm",(void*)f_7170},
{"f_7173:support_scm",(void*)f_7173},
{"f_7253:support_scm",(void*)f_7253},
{"f_7237:support_scm",(void*)f_7237},
{"f_7223:support_scm",(void*)f_7223},
{"f_7215:support_scm",(void*)f_7215},
{"f_7199:support_scm",(void*)f_7199},
{"f_7203:support_scm",(void*)f_7203},
{"f_7178:support_scm",(void*)f_7178},
{"f_7191:support_scm",(void*)f_7191},
{"f_7160:support_scm",(void*)f_7160},
{"f_7094:support_scm",(void*)f_7094},
{"f_7100:support_scm",(void*)f_7100},
{"f_7126:support_scm",(void*)f_7126},
{"f_7130:support_scm",(void*)f_7130},
{"f_7118:support_scm",(void*)f_7118},
{"f_6761:support_scm",(void*)f_6761},
{"f_6767:support_scm",(void*)f_6767},
{"f_7088:support_scm",(void*)f_7088},
{"f_6771:support_scm",(void*)f_6771},
{"f_7083:support_scm",(void*)f_7083},
{"f_6774:support_scm",(void*)f_6774},
{"f_7078:support_scm",(void*)f_7078},
{"f_6777:support_scm",(void*)f_6777},
{"f_6786:support_scm",(void*)f_6786},
{"f_7020:support_scm",(void*)f_7020},
{"f_7050:support_scm",(void*)f_7050},
{"f_7046:support_scm",(void*)f_7046},
{"f_7027:support_scm",(void*)f_7027},
{"f_7031:support_scm",(void*)f_7031},
{"f_6958:support_scm",(void*)f_6958},
{"f_7007:support_scm",(void*)f_7007},
{"f_6976:support_scm",(void*)f_6976},
{"f_6984:support_scm",(void*)f_6984},
{"f_6934:support_scm",(void*)f_6934},
{"f_6901:support_scm",(void*)f_6901},
{"f_6880:support_scm",(void*)f_6880},
{"f_6876:support_scm",(void*)f_6876},
{"f_6860:support_scm",(void*)f_6860},
{"f_6872:support_scm",(void*)f_6872},
{"f_6868:support_scm",(void*)f_6868},
{"f_6814:support_scm",(void*)f_6814},
{"f_6810:support_scm",(void*)f_6810},
{"f_6793:support_scm",(void*)f_6793},
{"f_6152:support_scm",(void*)f_6152},
{"f_6756:support_scm",(void*)f_6756},
{"f_6759:support_scm",(void*)f_6759},
{"f_6155:support_scm",(void*)f_6155},
{"f_6744:support_scm",(void*)f_6744},
{"f_6745:support_scm",(void*)f_6745},
{"f_6594:support_scm",(void*)f_6594},
{"f_6651:support_scm",(void*)f_6651},
{"f_6700:support_scm",(void*)f_6700},
{"f_6695:support_scm",(void*)f_6695},
{"f_6672:support_scm",(void*)f_6672},
{"f_6679:support_scm",(void*)f_6679},
{"f_6686:support_scm",(void*)f_6686},
{"f_6676:support_scm",(void*)f_6676},
{"f_6663:support_scm",(void*)f_6663},
{"f_6664:support_scm",(void*)f_6664},
{"f_6645:support_scm",(void*)f_6645},
{"f_6631:support_scm",(void*)f_6631},
{"f_6632:support_scm",(void*)f_6632},
{"f_6609:support_scm",(void*)f_6609},
{"f_6610:support_scm",(void*)f_6610},
{"f_6573:support_scm",(void*)f_6573},
{"f_6557:support_scm",(void*)f_6557},
{"f_6553:support_scm",(void*)f_6553},
{"f_6545:support_scm",(void*)f_6545},
{"f_6511:support_scm",(void*)f_6511},
{"f_6512:support_scm",(void*)f_6512},
{"f_6483:support_scm",(void*)f_6483},
{"f_6456:support_scm",(void*)f_6456},
{"f_6457:support_scm",(void*)f_6457},
{"f_6419:support_scm",(void*)f_6419},
{"f_6403:support_scm",(void*)f_6403},
{"f_6404:support_scm",(void*)f_6404},
{"f_6371:support_scm",(void*)f_6371},
{"f_6363:support_scm",(void*)f_6363},
{"f_6307:support_scm",(void*)f_6307},
{"f_6330:support_scm",(void*)f_6330},
{"f_6320:support_scm",(void*)f_6320},
{"f_6328:support_scm",(void*)f_6328},
{"f_6311:support_scm",(void*)f_6311},
{"f_6312:support_scm",(void*)f_6312},
{"f_6253:support_scm",(void*)f_6253},
{"f_6256:support_scm",(void*)f_6256},
{"f_6263:support_scm",(void*)f_6263},
{"f_6250:support_scm",(void*)f_6250},
{"f_6225:support_scm",(void*)f_6225},
{"f_6226:support_scm",(void*)f_6226},
{"f_6197:support_scm",(void*)f_6197},
{"f_6137:support_scm",(void*)f_6137},
{"f_6146:support_scm",(void*)f_6146},
{"f_6122:support_scm",(void*)f_6122},
{"f_6131:support_scm",(void*)f_6131},
{"f_6116:support_scm",(void*)f_6116},
{"f_6107:support_scm",(void*)f_6107},
{"f_6098:support_scm",(void*)f_6098},
{"f_6089:support_scm",(void*)f_6089},
{"f_6080:support_scm",(void*)f_6080},
{"f_6071:support_scm",(void*)f_6071},
{"f_6062:support_scm",(void*)f_6062},
{"f_6056:support_scm",(void*)f_6056},
{"f_6050:support_scm",(void*)f_6050},
{"f_5572:support_scm",(void*)f_5572},
{"f_6048:support_scm",(void*)f_6048},
{"f_5576:support_scm",(void*)f_5576},
{"f_5581:support_scm",(void*)f_5581},
{"f_5591:support_scm",(void*)f_5591},
{"f_5739:support_scm",(void*)f_5739},
{"f_5749:support_scm",(void*)f_5749},
{"f_5765:support_scm",(void*)f_5765},
{"f_5838:support_scm",(void*)f_5838},
{"f_5869:support_scm",(void*)f_5869},
{"f_5859:support_scm",(void*)f_5859},
{"f_5845:support_scm",(void*)f_5845},
{"f_5849:support_scm",(void*)f_5849},
{"f_5829:support_scm",(void*)f_5829},
{"f_5819:support_scm",(void*)f_5819},
{"f_5803:support_scm",(void*)f_5803},
{"f_5780:support_scm",(void*)f_5780},
{"f_5752:support_scm",(void*)f_5752},
{"f_5594:support_scm",(void*)f_5594},
{"f_5629:support_scm",(void*)f_5629},
{"f_5660:support_scm",(void*)f_5660},
{"f_5691:support_scm",(void*)f_5691},
{"f_5712:support_scm",(void*)f_5712},
{"f_5702:support_scm",(void*)f_5702},
{"f_5707:support_scm",(void*)f_5707},
{"f_5706:support_scm",(void*)f_5706},
{"f_5681:support_scm",(void*)f_5681},
{"f_5671:support_scm",(void*)f_5671},
{"f_5676:support_scm",(void*)f_5676},
{"f_5675:support_scm",(void*)f_5675},
{"f_5650:support_scm",(void*)f_5650},
{"f_5640:support_scm",(void*)f_5640},
{"f_5645:support_scm",(void*)f_5645},
{"f_5644:support_scm",(void*)f_5644},
{"f_5597:support_scm",(void*)f_5597},
{"f_5600:support_scm",(void*)f_5600},
{"f_5603:support_scm",(void*)f_5603},
{"f_5553:support_scm",(void*)f_5553},
{"f_5559:support_scm",(void*)f_5559},
{"f_5570:support_scm",(void*)f_5570},
{"f_5529:support_scm",(void*)f_5529},
{"f_5535:support_scm",(void*)f_5535},
{"f_5545:support_scm",(void*)f_5545},
{"f_5493:support_scm",(void*)f_5493},
{"f_5500:support_scm",(void*)f_5500},
{"f_5503:support_scm",(void*)f_5503},
{"f_5483:support_scm",(void*)f_5483},
{"f_5426:support_scm",(void*)f_5426},
{"f_5430:support_scm",(void*)f_5430},
{"f_5460:support_scm",(void*)f_5460},
{"f_5374:support_scm",(void*)f_5374},
{"f_5378:support_scm",(void*)f_5378},
{"f_5405:support_scm",(void*)f_5405},
{"f_5328:support_scm",(void*)f_5328},
{"f_5332:support_scm",(void*)f_5332},
{"f_5354:support_scm",(void*)f_5354},
{"f_5310:support_scm",(void*)f_5310},
{"f_5314:support_scm",(void*)f_5314},
{"f_5322:support_scm",(void*)f_5322},
{"f_5292:support_scm",(void*)f_5292},
{"f_5296:support_scm",(void*)f_5296},
{"f_5141:support_scm",(void*)f_5141},
{"f_5223:support_scm",(void*)f_5223},
{"f_5264:support_scm",(void*)f_5264},
{"f_5268:support_scm",(void*)f_5268},
{"f_5227:support_scm",(void*)f_5227},
{"f_5237:support_scm",(void*)f_5237},
{"f_5241:support_scm",(void*)f_5241},
{"f_5149:support_scm",(void*)f_5149},
{"f_5190:support_scm",(void*)f_5190},
{"f_5195:support_scm",(void*)f_5195},
{"f_5199:support_scm",(void*)f_5199},
{"f_5152:support_scm",(void*)f_5152},
{"f_5157:support_scm",(void*)f_5157},
{"f_5162:support_scm",(void*)f_5162},
{"f_5166:support_scm",(void*)f_5166},
{"f_5145:support_scm",(void*)f_5145},
{"f_5000:support_scm",(void*)f_5000},
{"f_5004:support_scm",(void*)f_5004},
{"f_5008:support_scm",(void*)f_5008},
{"f_4997:support_scm",(void*)f_4997},
{"f_4994:support_scm",(void*)f_4994},
{"f_4887:support_scm",(void*)f_4887},
{"f_4896:support_scm",(void*)f_4896},
{"f_4927:support_scm",(void*)f_4927},
{"f_4981:support_scm",(void*)f_4981},
{"f_4987:support_scm",(void*)f_4987},
{"f_4933:support_scm",(void*)f_4933},
{"f_4965:support_scm",(void*)f_4965},
{"f_4979:support_scm",(void*)f_4979},
{"f_4971:support_scm",(void*)f_4971},
{"f_4937:support_scm",(void*)f_4937},
{"f_4959:support_scm",(void*)f_4959},
{"f_4902:support_scm",(void*)f_4902},
{"f_4908:support_scm",(void*)f_4908},
{"f_4919:support_scm",(void*)f_4919},
{"f_4916:support_scm",(void*)f_4916},
{"f_4894:support_scm",(void*)f_4894},
{"f_4786:support_scm",(void*)f_4786},
{"f_4792:support_scm",(void*)f_4792},
{"f_4869:support_scm",(void*)f_4869},
{"f_4820:support_scm",(void*)f_4820},
{"f_4858:support_scm",(void*)f_4858},
{"f_4846:support_scm",(void*)f_4846},
{"f_4726:support_scm",(void*)f_4726},
{"f_4742:support_scm",(void*)f_4742},
{"f_4784:support_scm",(void*)f_4784},
{"f_4748:support_scm",(void*)f_4748},
{"f_4763:support_scm",(void*)f_4763},
{"f_4680:support_scm",(void*)f_4680},
{"f_4724:support_scm",(void*)f_4724},
{"f_4684:support_scm",(void*)f_4684},
{"f_4650:support_scm",(void*)f_4650},
{"f_4604:support_scm",(void*)f_4604},
{"f_4584:support_scm",(void*)f_4584},
{"f_4590:support_scm",(void*)f_4590},
{"f_4598:support_scm",(void*)f_4598},
{"f_4602:support_scm",(void*)f_4602},
{"f_4553:support_scm",(void*)f_4553},
{"f_4559:support_scm",(void*)f_4559},
{"f_4574:support_scm",(void*)f_4574},
{"f_4490:support_scm",(void*)f_4490},
{"f_4504:support_scm",(void*)f_4504},
{"f_4506:support_scm",(void*)f_4506},
{"f_4535:support_scm",(void*)f_4535},
{"f_4514:support_scm",(void*)f_4514},
{"f_4478:support_scm",(void*)f_4478},
{"f_4431:support_scm",(void*)f_4431},
{"f_4447:support_scm",(void*)f_4447},
{"f_4459:support_scm",(void*)f_4459},
{"f_4424:support_scm",(void*)f_4424},
{"f_4417:support_scm",(void*)f_4417},
{"f_4361:support_scm",(void*)f_4361},
{"f_4415:support_scm",(void*)f_4415},
{"f_4365:support_scm",(void*)f_4365},
{"f_4388:support_scm",(void*)f_4388},
{"f_4267:support_scm",(void*)f_4267},
{"f_4283:support_scm",(void*)f_4283},
{"f_4285:support_scm",(void*)f_4285},
{"f_4307:support_scm",(void*)f_4307},
{"f_4346:support_scm",(void*)f_4346},
{"f_4314:support_scm",(void*)f_4314},
{"f_4330:support_scm",(void*)f_4330},
{"f_4318:support_scm",(void*)f_4318},
{"f_4322:support_scm",(void*)f_4322},
{"f_4279:support_scm",(void*)f_4279},
{"f_4223:support_scm",(void*)f_4223},
{"f_4229:support_scm",(void*)f_4229},
{"f_4253:support_scm",(void*)f_4253},
{"f_4198:support_scm",(void*)f_4198},
{"f_4221:support_scm",(void*)f_4221},
{"f_4177:support_scm",(void*)f_4177},
{"f_4141:support_scm",(void*)f_4141},
{"f_4147:support_scm",(void*)f_4147},
{"f_4073:support_scm",(void*)f_4073},
{"f_4097:support_scm",(void*)f_4097},
{"f_4076:support_scm",(void*)f_4076},
{"f_4084:support_scm",(void*)f_4084},
{"f_4088:support_scm",(void*)f_4088},
{"f_4030:support_scm",(void*)f_4030},
{"f_4036:support_scm",(void*)f_4036},
{"f_4059:support_scm",(void*)f_4059},
{"f_4063:support_scm",(void*)f_4063},
{"f_4027:support_scm",(void*)f_4027},
{"f_4002:support_scm",(void*)f_4002},
{"f_4006:support_scm",(void*)f_4006},
{"f_4009:support_scm",(void*)f_4009},
{"f_4020:support_scm",(void*)f_4020},
{"f_4012:support_scm",(void*)f_4012},
{"f_4015:support_scm",(void*)f_4015},
{"f_3983:support_scm",(void*)f_3983},
{"f_3987:support_scm",(void*)f_3987},
{"f_4000:support_scm",(void*)f_4000},
{"f_3990:support_scm",(void*)f_3990},
{"f_3993:support_scm",(void*)f_3993},
{"f_3954:support_scm",(void*)f_3954},
{"f_3961:support_scm",(void*)f_3961},
{"f_3964:support_scm",(void*)f_3964},
{"f_3974:support_scm",(void*)f_3974},
{"f_3967:support_scm",(void*)f_3967},
{"f_3914:support_scm",(void*)f_3914},
{"f_3924:support_scm",(void*)f_3924},
{"f_3939:support_scm",(void*)f_3939},
{"f_3944:support_scm",(void*)f_3944},
{"f_3952:support_scm",(void*)f_3952},
{"f_3927:support_scm",(void*)f_3927},
{"f_3930:support_scm",(void*)f_3930},
{"f_3933:support_scm",(void*)f_3933},
{"f_3887:support_scm",(void*)f_3887},
{"f_3901:support_scm",(void*)f_3901},
{"f_3882:support_scm",(void*)f_3882},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
