/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-01 13:57
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: support.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[475];
static double C_possibly_force_alignment;


/* from k4136 */
static C_word C_fcall stub327(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub327(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4129 */
static C_word C_fcall stub322(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub322(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11014)
static void C_ccall f_11014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10985)
static void C_ccall f_10985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11012)
static void C_ccall f_11012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10996)
static void C_ccall f_10996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10999)
static void C_ccall f_10999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11001)
static void C_ccall f_11001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11005)
static void C_ccall f_11005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10989)
static void C_fcall f_10989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10922)
static void C_ccall f_10922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10959)
static void C_ccall f_10959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10983)
static void C_ccall f_10983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10969)
static void C_ccall f_10969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10944)
static void C_ccall f_10944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10952)
static void C_ccall f_10952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10853)
static void C_ccall f_10853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10857)
static void C_ccall f_10857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10862)
static void C_fcall f_10862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10866)
static void C_ccall f_10866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10917)
static void C_ccall f_10917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10896)
static void C_ccall f_10896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10908)
static void C_ccall f_10908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10911)
static void C_ccall f_10911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10820)
static void C_ccall f_10820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10830)
static void C_ccall f_10830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10833)
static void C_ccall f_10833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10718)
static void C_ccall f_10718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10727)
static void C_fcall f_10727(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10814)
static void C_ccall f_10814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10731)
static void C_ccall f_10731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10809)
static void C_ccall f_10809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10734)
static void C_ccall f_10734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10804)
static void C_ccall f_10804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10737)
static void C_ccall f_10737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10740)
static void C_ccall f_10740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10746)
static void C_ccall f_10746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10749)
static void C_ccall f_10749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10764)
static void C_ccall f_10764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10772)
static void C_fcall f_10772(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10782)
static void C_ccall f_10782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_ccall f_10767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10755)
static void C_ccall f_10755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10712)
static void C_ccall f_10712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10666)
static void C_ccall f_10666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10692)
static void C_ccall f_10692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10654)
static void C_ccall f_10654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10642)
static void C_ccall f_10642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10563)
static void C_ccall f_10563(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10563)
static void C_ccall f_10563r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10582)
static void C_ccall f_10582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10607)
static void C_ccall f_10607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10611)
static void C_ccall f_10611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10613)
static void C_fcall f_10613(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10620)
static void C_ccall f_10620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10566)
static void C_fcall f_10566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10570)
static void C_ccall f_10570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10576)
static void C_ccall f_10576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10513)
static void C_ccall f_10513(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10513)
static void C_ccall f_10513r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10525)
static void C_ccall f_10525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10529)
static void C_ccall f_10529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10504)
static void C_ccall f_10504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10498)
static void C_ccall f_10498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10492)
static void C_ccall f_10492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10480)
static void C_ccall f_10480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10484)
static void C_ccall f_10484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10487)
static void C_ccall f_10487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10442)
static void C_ccall f_10442(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10442)
static void C_ccall f_10442r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10446)
static void C_ccall f_10446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10449)
static void C_ccall f_10449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10456)
static void C_ccall f_10456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10400)
static void C_ccall f_10400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10409)
static void C_fcall f_10409(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10371)
static void C_ccall f_10371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10381)
static void C_fcall f_10381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10302)
static void C_ccall f_10302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10347)
static void C_ccall f_10347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10351)
static void C_ccall f_10351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10305)
static void C_ccall f_10305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10310)
static void C_ccall f_10310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10265)
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10269)
static void C_ccall f_10269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10282)
static void C_ccall f_10282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10230)
static void C_fcall f_10230(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10236)
static void C_fcall f_10236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10263)
static void C_ccall f_10263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10183)
static void C_fcall f_10183(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10189)
static void C_fcall f_10189(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10228)
static void C_ccall f_10228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10210)
static void C_ccall f_10210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10000)
static void C_ccall f_10000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10172)
static void C_ccall f_10172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10159)
static void C_fcall f_10159(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10165)
static void C_ccall f_10165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10003)
static void C_fcall f_10003(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10007)
static void C_ccall f_10007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10148)
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10010)
static void C_ccall f_10010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10143)
static void C_ccall f_10143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10013)
static void C_ccall f_10013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10022)
static void C_fcall f_10022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10106)
static void C_ccall f_10106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10076)
static void C_ccall f_10076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10087)
static void C_ccall f_10087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10067)
static void C_ccall f_10067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10053)
static void C_fcall f_10053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9907)
static void C_ccall f_9907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9913)
static void C_ccall f_9913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9994)
static void C_ccall f_9994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9917)
static void C_ccall f_9917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9989)
static void C_ccall f_9989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9973)
static void C_fcall f_9973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9960)
static void C_ccall f_9960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9959)
static void C_ccall f_9959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9941)
static void C_fcall f_9941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9935)
static void C_fcall f_9935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9911)
static void C_ccall f_9911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9615)
static void C_ccall f_9615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9811)
static void C_fcall f_9811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9832)
static void C_fcall f_9832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9609)
static void C_ccall f_9609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9317)
static void C_ccall f_9317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9327)
static void C_fcall f_9327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_fcall f_9379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9308)
static void C_fcall f_9308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9299)
static void C_ccall f_9299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8992)
static void C_ccall f_8992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9002)
static void C_fcall f_9002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9011)
static void C_fcall f_9011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_fcall f_9023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9035)
static void C_fcall f_9035(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9075)
static void C_fcall f_9075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8946)
static void C_ccall f_8946(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8952)
static void C_ccall f_8952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8956)
static void C_ccall f_8956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8928)
static void C_ccall f_8928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8919)
static void C_fcall f_8919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8897)
static void C_ccall f_8897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8888)
static void C_fcall f_8888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7837)
static void C_ccall f_7837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7849)
static void C_fcall f_7849(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7878)
static void C_fcall f_7878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7897)
static void C_fcall f_7897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_fcall f_7916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7986)
static void C_fcall f_7986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8005)
static void C_fcall f_8005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8087)
static void C_fcall f_8087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_fcall f_8126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8145)
static void C_fcall f_8145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8164)
static void C_fcall f_8164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8244)
static void C_fcall f_8244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_fcall f_8329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8404)
static void C_ccall f_8404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8438)
static void C_fcall f_8438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8508)
static void C_ccall f_8508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_ccall f_8441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8278)
static void C_fcall f_8278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8167)
static void C_ccall f_8167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8008)
static void C_ccall f_8008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8039)
static void C_fcall f_8039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_fcall f_7950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7801)
static void C_ccall f_7801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7805)
static void C_ccall f_7805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7816)
static void C_ccall f_7816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7676)
static void C_ccall f_7676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7680)
static void C_ccall f_7680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7664)
static void C_ccall f_7664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7610)
static void C_ccall f_7610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7628)
static void C_ccall f_7628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7639)
static void C_fcall f_7639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7622)
static void C_ccall f_7622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7592)
static void C_fcall f_7592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7573)
static void C_ccall f_7573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7556)
static void C_ccall f_7556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7534)
static void C_ccall f_7534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7366)
static void C_ccall f_7366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_fcall f_7378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7336)
static void C_ccall f_7336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7211)
static void C_fcall f_7211(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7323)
static void C_ccall f_7323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7318)
static void C_ccall f_7318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7305)
static void C_ccall f_7305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7297)
static void C_ccall f_7297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7240)
static void C_ccall f_7240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7246)
static void C_fcall f_7246(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_fcall f_7168(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_fcall f_7139(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7066)
static void C_ccall f_7066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static C_word C_fcall f_7080(C_word t0,C_word t1);
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7031)
static void C_fcall f_7031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6804)
static void C_ccall f_6804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6816)
static void C_fcall f_6816(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6823)
static void C_ccall f_6823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6994)
static void C_ccall f_6994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6938)
static void C_ccall f_6938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6905)
static void C_ccall f_6905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6810)
static void C_fcall f_6810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6709)
static void C_ccall f_6709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6643)
static void C_fcall f_6643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6329)
static void C_fcall f_6329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_fcall f_6563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6589)
static void C_ccall f_6589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6570)
static void C_ccall f_6570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_fcall f_6501(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6302)
static void C_ccall f_6302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6142)
static void C_fcall f_6142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6220)
static void C_fcall f_6220(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6211)
static void C_ccall f_6211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6105)
static void C_ccall f_6105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5967)
static void C_fcall f_5967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5801)
static void C_fcall f_5801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_fcall f_5798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_fcall f_5172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_fcall f_5297(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_fcall f_5323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_fcall f_5380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5225)
static void C_fcall f_5225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_fcall f_5256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5277)
static void C_ccall f_5277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5131)
static void C_fcall f_5131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5099)
static void C_fcall f_5099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4481)
static void C_fcall f_4481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_fcall f_4509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_fcall f_4373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4268)
static void C_fcall f_4268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_fcall f_4223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_fcall f_4168(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_fcall f_3994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_fcall f_4023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3938)
static void C_fcall f_3938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3856)
static C_word C_fcall f_3856(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3806)
static void C_fcall f_3806(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3785)
static void C_fcall f_3785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3745)
static void C_fcall f_3745(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3670)
static void C_fcall f_3670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10989)
static void C_fcall trf_10989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10989(t0,t1);}

C_noret_decl(trf_10862)
static void C_fcall trf_10862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10862(t0,t1);}

C_noret_decl(trf_10727)
static void C_fcall trf_10727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10727(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10727(t0,t1,t2,t3);}

C_noret_decl(trf_10772)
static void C_fcall trf_10772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10772(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10772(t0,t1,t2);}

C_noret_decl(trf_10613)
static void C_fcall trf_10613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10613(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10613(t0,t1,t2,t3);}

C_noret_decl(trf_10566)
static void C_fcall trf_10566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10566(t0,t1);}

C_noret_decl(trf_10409)
static void C_fcall trf_10409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10409(t0,t1,t2);}

C_noret_decl(trf_10381)
static void C_fcall trf_10381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10381(t0,t1);}

C_noret_decl(trf_10265)
static void C_fcall trf_10265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10265(t0,t1,t2,t3);}

C_noret_decl(trf_10230)
static void C_fcall trf_10230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10230(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10230(t0,t1,t2);}

C_noret_decl(trf_10236)
static void C_fcall trf_10236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10236(t0,t1,t2);}

C_noret_decl(trf_10183)
static void C_fcall trf_10183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10183(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10183(t0,t1,t2,t3);}

C_noret_decl(trf_10189)
static void C_fcall trf_10189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10189(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10189(t0,t1,t2);}

C_noret_decl(trf_10159)
static void C_fcall trf_10159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10159(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10159(t0,t1,t2,t3);}

C_noret_decl(trf_10003)
static void C_fcall trf_10003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10003(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10003(t0,t1,t2,t3);}

C_noret_decl(trf_10022)
static void C_fcall trf_10022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10022(t0,t1);}

C_noret_decl(trf_10053)
static void C_fcall trf_10053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10053(t0,t1);}

C_noret_decl(trf_9973)
static void C_fcall trf_9973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9973(t0,t1);}

C_noret_decl(trf_9941)
static void C_fcall trf_9941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9941(t0,t1);}

C_noret_decl(trf_9935)
static void C_fcall trf_9935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9935(t0,t1);}

C_noret_decl(trf_9811)
static void C_fcall trf_9811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9811(t0,t1);}

C_noret_decl(trf_9832)
static void C_fcall trf_9832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9832(t0,t1);}

C_noret_decl(trf_9327)
static void C_fcall trf_9327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9327(t0,t1);}

C_noret_decl(trf_9379)
static void C_fcall trf_9379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9379(t0,t1);}

C_noret_decl(trf_9308)
static void C_fcall trf_9308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9308(t0,t1);}

C_noret_decl(trf_9002)
static void C_fcall trf_9002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9002(t0,t1);}

C_noret_decl(trf_9011)
static void C_fcall trf_9011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9011(t0,t1);}

C_noret_decl(trf_9023)
static void C_fcall trf_9023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9023(t0,t1);}

C_noret_decl(trf_9035)
static void C_fcall trf_9035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9035(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9035(t0,t1);}

C_noret_decl(trf_9075)
static void C_fcall trf_9075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9075(t0,t1);}

C_noret_decl(trf_8919)
static void C_fcall trf_8919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8919(t0,t1);}

C_noret_decl(trf_8888)
static void C_fcall trf_8888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8888(t0,t1);}

C_noret_decl(trf_7849)
static void C_fcall trf_7849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7849(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7849(t0,t1,t2);}

C_noret_decl(trf_7878)
static void C_fcall trf_7878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7878(t0,t1);}

C_noret_decl(trf_7897)
static void C_fcall trf_7897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7897(t0,t1);}

C_noret_decl(trf_7916)
static void C_fcall trf_7916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7916(t0,t1);}

C_noret_decl(trf_7986)
static void C_fcall trf_7986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7986(t0,t1);}

C_noret_decl(trf_8005)
static void C_fcall trf_8005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8005(t0,t1);}

C_noret_decl(trf_8087)
static void C_fcall trf_8087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8087(t0,t1);}

C_noret_decl(trf_8126)
static void C_fcall trf_8126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8126(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8126(t0,t1);}

C_noret_decl(trf_8145)
static void C_fcall trf_8145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8145(t0,t1);}

C_noret_decl(trf_8164)
static void C_fcall trf_8164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8164(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8164(t0,t1);}

C_noret_decl(trf_8244)
static void C_fcall trf_8244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8244(t0,t1);}

C_noret_decl(trf_8329)
static void C_fcall trf_8329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8329(t0,t1);}

C_noret_decl(trf_8438)
static void C_fcall trf_8438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8438(t0,t1);}

C_noret_decl(trf_8278)
static void C_fcall trf_8278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8278(t0,t1);}

C_noret_decl(trf_8039)
static void C_fcall trf_8039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8039(t0,t1);}

C_noret_decl(trf_7950)
static void C_fcall trf_7950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7950(t0,t1);}

C_noret_decl(trf_7639)
static void C_fcall trf_7639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7639(t0,t1);}

C_noret_decl(trf_7592)
static void C_fcall trf_7592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7592(t0,t1);}

C_noret_decl(trf_7378)
static void C_fcall trf_7378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7378(t0,t1);}

C_noret_decl(trf_7211)
static void C_fcall trf_7211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7211(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7211(t0,t1,t2,t3);}

C_noret_decl(trf_7246)
static void C_fcall trf_7246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7246(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7246(t0,t1,t2,t3);}

C_noret_decl(trf_7168)
static void C_fcall trf_7168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7168(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7168(t0,t1,t2,t3);}

C_noret_decl(trf_7139)
static void C_fcall trf_7139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7139(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7139(t0,t1,t2,t3);}

C_noret_decl(trf_7031)
static void C_fcall trf_7031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7031(t0,t1,t2);}

C_noret_decl(trf_6816)
static void C_fcall trf_6816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6816(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6816(t0,t1,t2,t3);}

C_noret_decl(trf_6810)
static void C_fcall trf_6810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6810(t0,t1,t2);}

C_noret_decl(trf_6643)
static void C_fcall trf_6643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6643(t0,t1,t2);}

C_noret_decl(trf_6329)
static void C_fcall trf_6329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6329(t0,t1);}

C_noret_decl(trf_6563)
static void C_fcall trf_6563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6563(t0,t1);}

C_noret_decl(trf_6501)
static void C_fcall trf_6501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6501(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6501(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6142)
static void C_fcall trf_6142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6142(t0,t1);}

C_noret_decl(trf_6220)
static void C_fcall trf_6220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6220(t0,t1);}

C_noret_decl(trf_5967)
static void C_fcall trf_5967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5967(t0,t1);}

C_noret_decl(trf_5801)
static void C_fcall trf_5801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5801(t0,t1);}

C_noret_decl(trf_5798)
static void C_fcall trf_5798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5798(t0,t1);}

C_noret_decl(trf_5172)
static void C_fcall trf_5172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5172(t0,t1);}

C_noret_decl(trf_5297)
static void C_fcall trf_5297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5297(t0,t1,t2);}

C_noret_decl(trf_5323)
static void C_fcall trf_5323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5323(t0,t1);}

C_noret_decl(trf_5380)
static void C_fcall trf_5380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5380(t0,t1);}

C_noret_decl(trf_5225)
static void C_fcall trf_5225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5225(t0,t1);}

C_noret_decl(trf_5256)
static void C_fcall trf_5256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5256(t0,t1);}

C_noret_decl(trf_5131)
static void C_fcall trf_5131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5131(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5131(t0,t1,t2);}

C_noret_decl(trf_5099)
static void C_fcall trf_5099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5099(t0,t1);}

C_noret_decl(trf_4481)
static void C_fcall trf_4481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4481(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4481(t0,t1,t2);}

C_noret_decl(trf_4509)
static void C_fcall trf_4509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4509(t0,t1);}

C_noret_decl(trf_4373)
static void C_fcall trf_4373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4373(t0,t1);}

C_noret_decl(trf_4268)
static void C_fcall trf_4268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4268(t0,t1,t2,t3);}

C_noret_decl(trf_4215)
static void C_fcall trf_4215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4215(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4215(t0,t1,t2);}

C_noret_decl(trf_4223)
static void C_fcall trf_4223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4223(t0,t1);}

C_noret_decl(trf_4168)
static void C_fcall trf_4168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4168(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4168(t0,t1);}

C_noret_decl(trf_3994)
static void C_fcall trf_3994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3994(t0,t1,t2);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4016(t0,t1);}

C_noret_decl(trf_4023)
static void C_fcall trf_4023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4023(t0,t1);}

C_noret_decl(trf_3938)
static void C_fcall trf_3938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3938(t0,t1,t2,t3);}

C_noret_decl(trf_3806)
static void C_fcall trf_3806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3806(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3806(t0,t1,t2,t3);}

C_noret_decl(trf_3785)
static void C_fcall trf_3785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3785(t0,t1);}

C_noret_decl(trf_3745)
static void C_fcall trf_3745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3745(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3745(t0,t1,t2);}

C_noret_decl(trf_3670)
static void C_fcall trf_3670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3670(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4840)){
C_save(t1);
C_rereclaim2(4840*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,475);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000:(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[6]=C_h_intern(&lf[6],30,"\010compilercompiler-cleanup-hook");
lf[7]=C_h_intern(&lf[7],26,"\010compilerdebugging-chicken");
lf[8]=C_h_intern(&lf[8],26,"\010compilerdisabled-warnings");
lf[9]=C_h_intern(&lf[9],13,"\010compilerbomb");
lf[10]=C_h_intern(&lf[10],5,"error");
lf[11]=C_h_intern(&lf[11],13,"string-append");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[14]=C_h_intern(&lf[14],18,"\010compilerdebugging");
lf[15]=C_h_intern(&lf[15],12,"flush-output");
lf[16]=C_h_intern(&lf[16],7,"newline");
lf[17]=C_h_intern(&lf[17],6,"printf");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[19]=C_h_intern(&lf[19],5,"force");
lf[20]=C_h_intern(&lf[20],12,"\003sysfor-each");
lf[21]=C_h_intern(&lf[21],7,"display");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[24]=C_h_intern(&lf[24],25,"\010compilercompiler-warning");
lf[25]=C_h_intern(&lf[25],7,"fprintf");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[27]=C_h_intern(&lf[27],18,"current-error-port");
lf[28]=C_h_intern(&lf[28],20,"\003syswarnings-enabled");
lf[29]=C_h_intern(&lf[29],4,"quit");
lf[30]=C_h_intern(&lf[30],4,"exit");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[32]=C_h_intern(&lf[32],21,"\003syssyntax-error-hook");
lf[33]=C_h_intern(&lf[33],16,"print-call-chain");
lf[34]=C_h_intern(&lf[34],18,"\003syscurrent-thread");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[38]=C_h_intern(&lf[38],12,"syntax-error");
lf[39]=C_h_intern(&lf[39],31,"\010compileremit-syntax-trace-info");
lf[40]=C_h_intern(&lf[40],9,"map-llist");
lf[41]=C_h_intern(&lf[41],24,"\010compilercheck-signature");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[43]=C_h_intern(&lf[43],18,"\010compilerreal-name");
lf[44]=C_h_intern(&lf[44],13,"\010compilerposq");
lf[45]=C_h_intern(&lf[45],18,"\010compilerstringify");
lf[46]=C_h_intern(&lf[46],14,"symbol->string");
lf[47]=C_h_intern(&lf[47],7,"sprintf");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[49]=C_h_intern(&lf[49],18,"\010compilersymbolify");
lf[50]=C_h_intern(&lf[50],14,"string->symbol");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[52]=C_h_intern(&lf[52],26,"\010compilerbuild-lambda-list");
lf[53]=C_h_intern(&lf[53],29,"\010compilerstring->c-identifier");
lf[54]=C_h_intern(&lf[54],24,"\003sysstring->c-identifier");
lf[55]=C_h_intern(&lf[55],21,"\010compilerc-ify-string");
lf[56]=C_h_intern(&lf[56],16,"\003syslist->string");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[58]=C_h_intern(&lf[58],6,"append");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[60]=C_h_intern(&lf[60],16,"\003sysstring->list");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[64]=C_h_intern(&lf[64],28,"\010compilervalid-c-identifier\077");
lf[65]=C_h_intern(&lf[65],3,"any");
lf[66]=C_h_intern(&lf[66],8,"->string");
lf[67]=C_h_intern(&lf[67],14,"\010compilerwords");
lf[68]=C_h_intern(&lf[68],21,"\010compilerwords->bytes");
lf[69]=C_h_intern(&lf[69],34,"\010compilercheck-and-open-input-file");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[71]=C_h_intern(&lf[71],18,"current-input-port");
lf[72]=C_h_intern(&lf[72],15,"open-input-file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[75]=C_h_intern(&lf[75],12,"file-exists\077");
lf[76]=C_h_intern(&lf[76],33,"\010compilerclose-checked-input-file");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[78]=C_h_intern(&lf[78],16,"close-input-port");
lf[79]=C_h_intern(&lf[79],19,"\010compilerfold-inner");
lf[80]=C_h_intern(&lf[80],7,"reverse");
lf[81]=C_h_intern(&lf[81],28,"\010compilerfollow-without-loop");
lf[82]=C_h_intern(&lf[82],18,"\010compilerconstant\077");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_h_intern(&lf[84],29,"\010compilercollapsable-literal\077");
lf[85]=C_h_intern(&lf[85],19,"\010compilerimmediate\077");
lf[86]=C_h_intern(&lf[86],20,"\010compilerbig-fixnum\077");
lf[87]=C_h_intern(&lf[87],23,"\010compilerbasic-literal\077");
lf[88]=C_h_intern(&lf[88],5,"every");
lf[89]=C_h_intern(&lf[89],12,"vector->list");
lf[90]=C_h_intern(&lf[90],32,"\010compilercanonicalize-begin-body");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[93]=C_h_intern(&lf[93],3,"let");
lf[94]=C_h_intern(&lf[94],6,"gensym");
lf[95]=C_h_intern(&lf[95],1,"t");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[97]=C_h_intern(&lf[97],21,"\010compilerstring->expr");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[100]=C_h_intern(&lf[100],5,"begin");
lf[101]=C_h_intern(&lf[101],10,"\003sysappend");
lf[102]=C_h_intern(&lf[102],4,"read");
lf[103]=C_h_intern(&lf[103],6,"unfold");
lf[104]=C_h_intern(&lf[104],11,"eof-object\077");
lf[105]=C_h_intern(&lf[105],6,"values");
lf[106]=C_h_intern(&lf[106],22,"with-input-from-string");
lf[107]=C_h_intern(&lf[107],22,"with-exception-handler");
lf[108]=C_h_intern(&lf[108],30,"call-with-current-continuation");
lf[109]=C_h_intern(&lf[109],30,"\010compilerdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],25,"\003sysdecompose-lambda-list");
lf[111]=C_h_intern(&lf[111],37,"\010compilerprocess-lambda-documentation");
lf[112]=C_h_intern(&lf[112],30,"\010compilerexpand-profile-lambda");
lf[113]=C_h_intern(&lf[113],29,"\010compilerprofile-lambda-index");
lf[114]=C_h_intern(&lf[114],28,"\010compilerprofile-lambda-list");
lf[115]=C_h_intern(&lf[115],33,"\010compilerprofile-info-vector-name");
lf[116]=C_h_intern(&lf[116],17,"\003sysprofile-entry");
lf[117]=C_h_intern(&lf[117],6,"lambda");
lf[118]=C_h_intern(&lf[118],5,"apply");
lf[119]=C_h_intern(&lf[119],16,"\003sysprofile-exit");
lf[120]=C_h_intern(&lf[120],16,"\003sysdynamic-wind");
lf[121]=C_h_intern(&lf[121],10,"alist-cons");
lf[122]=C_h_intern(&lf[122],37,"\010compilerinitialize-analysis-database");
lf[123]=C_h_intern(&lf[123],13,"\010compilerput!");
lf[124]=C_h_intern(&lf[124],8,"constant");
lf[125]=C_h_intern(&lf[125],26,"\010compilermutable-constants");
lf[126]=C_h_intern(&lf[126],35,"\010compilerfoldable-extended-bindings");
lf[127]=C_h_intern(&lf[127],8,"foldable");
lf[128]=C_h_intern(&lf[128],16,"extended-binding");
lf[129]=C_h_intern(&lf[129],17,"extended-bindings");
lf[130]=C_h_intern(&lf[130],35,"\010compilerfoldable-standard-bindings");
lf[131]=C_h_intern(&lf[131],41,"\010compilerside-effecting-standard-bindings");
lf[132]=C_h_intern(&lf[132],14,"side-effecting");
lf[133]=C_h_intern(&lf[133],16,"standard-binding");
lf[134]=C_h_intern(&lf[134],17,"standard-bindings");
lf[135]=C_h_intern(&lf[135],12,"\010compilerget");
lf[136]=C_h_intern(&lf[136],18,"\003syshash-table-ref");
lf[137]=C_h_intern(&lf[137],16,"\010compilerget-all");
lf[138]=C_h_intern(&lf[138],10,"filter-map");
lf[139]=C_h_intern(&lf[139],19,"\003syshash-table-set!");
lf[140]=C_h_intern(&lf[140],17,"\010compilercollect!");
lf[141]=C_h_intern(&lf[141],15,"\010compilercount!");
lf[142]=C_h_intern(&lf[142],17,"\010compilerget-line");
lf[143]=C_h_intern(&lf[143],24,"\003sysline-number-database");
lf[144]=C_h_intern(&lf[144],19,"\010compilerget-line-2");
lf[145]=C_h_intern(&lf[145],30,"\010compilerfind-lambda-container");
lf[146]=C_h_intern(&lf[146],12,"contained-in");
lf[147]=C_h_intern(&lf[147],37,"\010compilerdisplay-line-number-database");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[149]=C_h_intern(&lf[149],7,"\003sysmap");
lf[150]=C_h_intern(&lf[150],3,"cdr");
lf[151]=C_h_intern(&lf[151],23,"\003syshash-table-for-each");
lf[152]=C_h_intern(&lf[152],34,"\010compilerdisplay-analysis-database");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[157]=C_h_intern(&lf[157],7,"unknown");
lf[158]=C_h_intern(&lf[158],8,"captured");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[161]=C_h_intern(&lf[161],4,"caar");
lf[162]=C_h_intern(&lf[162],5,"value");
lf[163]=C_h_intern(&lf[163],4,"cdar");
lf[164]=C_h_intern(&lf[164],15,"potential-value");
lf[165]=C_h_intern(&lf[165],10,"replacable");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[167]=C_h_intern(&lf[167],10,"references");
lf[168]=C_h_intern(&lf[168],10,"call-sites");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[170]=C_h_intern(&lf[170],4,"home");
lf[171]=C_h_intern(&lf[171],8,"contains");
lf[172]=C_h_intern(&lf[172],8,"use-expr");
lf[173]=C_h_intern(&lf[173],12,"closure-size");
lf[174]=C_h_intern(&lf[174],14,"rest-parameter");
lf[175]=C_h_intern(&lf[175],16,"o-r/access-count");
lf[176]=C_h_intern(&lf[176],18,"captured-variables");
lf[177]=C_h_intern(&lf[177],13,"explicit-rest");
lf[178]=C_h_intern(&lf[178],8,"assigned");
lf[179]=C_h_intern(&lf[179],5,"boxed");
lf[180]=C_h_intern(&lf[180],6,"global");
lf[181]=C_h_intern(&lf[181],12,"contractable");
lf[182]=C_h_intern(&lf[182],16,"assigned-locally");
lf[183]=C_h_intern(&lf[183],11,"collapsable");
lf[184]=C_h_intern(&lf[184],9,"removable");
lf[185]=C_h_intern(&lf[185],9,"undefined");
lf[186]=C_h_intern(&lf[186],9,"replacing");
lf[187]=C_h_intern(&lf[187],6,"unused");
lf[188]=C_h_intern(&lf[188],6,"simple");
lf[189]=C_h_intern(&lf[189],9,"inlinable");
lf[190]=C_h_intern(&lf[190],13,"inline-export");
lf[191]=C_h_intern(&lf[191],21,"has-unused-parameters");
lf[192]=C_h_intern(&lf[192],12,"customizable");
lf[193]=C_h_intern(&lf[193],10,"boxed-rest");
lf[194]=C_h_intern(&lf[194],5,"write");
lf[195]=C_h_intern(&lf[195],34,"\010compilerdefault-standard-bindings");
lf[196]=C_h_intern(&lf[196],34,"\010compilerdefault-extended-bindings");
lf[197]=C_h_intern(&lf[197],26,"\010compilerinternal-bindings");
lf[198]=C_h_intern(&lf[198],9,"make-node");
lf[199]=C_h_intern(&lf[199],4,"node");
lf[200]=C_h_intern(&lf[200],5,"node\077");
lf[201]=C_h_intern(&lf[201],15,"node-class-set!");
lf[202]=C_h_intern(&lf[202],14,"\003sysblock-set!");
lf[203]=C_h_intern(&lf[203],10,"node-class");
lf[204]=C_h_intern(&lf[204],20,"node-parameters-set!");
lf[205]=C_h_intern(&lf[205],15,"node-parameters");
lf[206]=C_h_intern(&lf[206],24,"node-subexpressions-set!");
lf[207]=C_h_intern(&lf[207],19,"node-subexpressions");
lf[208]=C_h_intern(&lf[208],16,"\010compilervarnode");
lf[209]=C_h_intern(&lf[209],13,"\004corevariable");
lf[210]=C_h_intern(&lf[210],14,"\010compilerqnode");
lf[211]=C_h_intern(&lf[211],25,"\010compilerbuild-node-graph");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[213]=C_h_intern(&lf[213],15,"\004coreglobal-ref");
lf[214]=C_h_intern(&lf[214],2,"if");
lf[215]=C_h_intern(&lf[215],14,"\004coreundefined");
lf[216]=C_h_intern(&lf[216],8,"truncate");
lf[217]=C_h_intern(&lf[217],4,"type");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[219]=C_h_intern(&lf[219],6,"fixnum");
lf[220]=C_h_intern(&lf[220],11,"number-type");
lf[221]=C_h_intern(&lf[221],6,"unzip1");
lf[222]=C_h_intern(&lf[222],11,"\004corelambda");
lf[223]=C_h_intern(&lf[223],14,"\004coreprimitive");
lf[224]=C_h_intern(&lf[224],11,"\004coreinline");
lf[225]=C_h_intern(&lf[225],13,"\004corecallunit");
lf[226]=C_h_intern(&lf[226],9,"\004coreproc");
lf[227]=C_h_intern(&lf[227],4,"set!");
lf[228]=C_h_intern(&lf[228],9,"\004coreset!");
lf[229]=C_h_intern(&lf[229],29,"\004coreforeign-callback-wrapper");
lf[230]=C_h_intern(&lf[230],5,"sixth");
lf[231]=C_h_intern(&lf[231],5,"fifth");
lf[232]=C_h_intern(&lf[232],20,"\004coreinline_allocate");
lf[233]=C_h_intern(&lf[233],8,"\004coreapp");
lf[234]=C_h_intern(&lf[234],9,"\004corecall");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[236]=C_h_intern(&lf[236],24,"\010compilersource-filename");
lf[237]=C_h_intern(&lf[237],28,"\003syssymbol->qualified-string");
lf[238]=C_h_intern(&lf[238],34,"\010compileralways-bound-to-procedure");
lf[239]=C_h_intern(&lf[239],15,"\004coreinline_ref");
lf[240]=C_h_intern(&lf[240],18,"\004coreinline_update");
lf[241]=C_h_intern(&lf[241],19,"\004coreinline_loc_ref");
lf[242]=C_h_intern(&lf[242],22,"\004coreinline_loc_update");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[244]=C_h_intern(&lf[244],1,"o");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[246]=C_h_intern(&lf[246],30,"\010compilerbuild-expression-tree");
lf[247]=C_h_intern(&lf[247],12,"\004coreclosure");
lf[248]=C_h_intern(&lf[248],4,"last");
lf[249]=C_h_intern(&lf[249],3,"map");
lf[250]=C_h_intern(&lf[250],4,"list");
lf[251]=C_h_intern(&lf[251],7,"butlast");
lf[252]=C_h_intern(&lf[252],5,"cons*");
lf[253]=C_h_intern(&lf[253],9,"\004corebind");
lf[254]=C_h_intern(&lf[254],10,"\004coreunbox");
lf[255]=C_h_intern(&lf[255],8,"\004coreref");
lf[256]=C_h_intern(&lf[256],11,"\004coreupdate");
lf[257]=C_h_intern(&lf[257],13,"\004coreupdate_i");
lf[258]=C_h_intern(&lf[258],8,"\004corebox");
lf[259]=C_h_intern(&lf[259],9,"\004corecond");
lf[260]=C_h_intern(&lf[260],21,"\010compilerfold-boolean");
lf[261]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[262]=C_h_intern(&lf[262],31,"\010compilerinline-lambda-bindings");
lf[263]=C_h_intern(&lf[263],8,"split-at");
lf[264]=C_h_intern(&lf[264],10,"fold-right");
lf[265]=C_h_intern(&lf[265],4,"take");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[267]=C_h_intern(&lf[267],34,"\010compilercopy-node-tree-and-rename");
lf[268]=C_h_intern(&lf[268],9,"alist-ref");
lf[269]=C_h_intern(&lf[269],3,"eq\077");
lf[270]=C_h_intern(&lf[270],18,"\010compilertree-copy");
lf[271]=C_h_intern(&lf[271],4,"cons");
lf[272]=C_h_intern(&lf[272],19,"\010compilercopy-node!");
lf[273]=C_h_intern(&lf[273],19,"\010compilermatch-node");
lf[274]=C_h_intern(&lf[274],1,"a");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[276]=C_h_intern(&lf[276],37,"\010compilerexpression-has-side-effects\077");
lf[277]=C_h_intern(&lf[277],24,"foreign-callback-stub-id");
lf[278]=C_h_intern(&lf[278],4,"find");
lf[279]=C_h_intern(&lf[279],22,"foreign-callback-stubs");
lf[280]=C_h_intern(&lf[280],28,"\010compilersimple-lambda-node\077");
lf[281]=C_h_intern(&lf[281],31,"\010compilerdump-undefined-globals");
lf[282]=C_h_intern(&lf[282],20,"check-global-exports");
lf[283]=C_h_intern(&lf[283],20,"\010compilerexport-list");
lf[284]=C_h_intern(&lf[284],3,"var");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000,exported global variable `~S\047 is not defined");
lf[286]=C_h_intern(&lf[286],6,"delete");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\0005exported global variable `~S\047 is used but not defined");
lf[288]=C_h_intern(&lf[288],28,"\003systoplevel-definition-hook");
lf[289]=C_h_intern(&lf[289],22,"\010compilerblock-globals");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[291]=C_h_intern(&lf[291],36,"\010compilercompute-database-statistics");
lf[292]=C_h_intern(&lf[292],29,"\010compilercurrent-program-size");
lf[293]=C_h_intern(&lf[293],30,"\010compileroriginal-program-size");
lf[294]=C_h_intern(&lf[294],33,"\010compilerprint-program-statistics");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[301]=C_h_intern(&lf[301],1,"s");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[303]=C_h_intern(&lf[303],35,"\010compilerpprint-expressions-to-file");
lf[304]=C_h_intern(&lf[304],17,"close-output-port");
lf[305]=C_h_intern(&lf[305],12,"pretty-print");
lf[306]=C_h_intern(&lf[306],19,"with-output-to-port");
lf[307]=C_h_intern(&lf[307],16,"open-output-file");
lf[308]=C_h_intern(&lf[308],19,"current-output-port");
lf[309]=C_h_intern(&lf[309],27,"\010compilerforeign-type-check");
lf[310]=C_h_intern(&lf[310],4,"char");
lf[311]=C_h_intern(&lf[311],13,"unsigned-char");
lf[312]=C_h_intern(&lf[312],6,"unsafe");
lf[313]=C_h_intern(&lf[313],25,"\003sysforeign-char-argument");
lf[314]=C_h_intern(&lf[314],3,"int");
lf[315]=C_h_intern(&lf[315],27,"\003sysforeign-fixnum-argument");
lf[316]=C_h_intern(&lf[316],5,"float");
lf[317]=C_h_intern(&lf[317],27,"\003sysforeign-flonum-argument");
lf[318]=C_h_intern(&lf[318],7,"pointer");
lf[319]=C_h_intern(&lf[319],26,"\003sysforeign-block-argument");
lf[320]=C_h_intern(&lf[320],15,"nonnull-pointer");
lf[321]=C_h_intern(&lf[321],8,"u8vector");
lf[322]=C_h_intern(&lf[322],34,"\003sysforeign-number-vector-argument");
lf[323]=C_h_intern(&lf[323],16,"nonnull-u8vector");
lf[324]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[325]=C_h_intern(&lf[325],7,"integer");
lf[326]=C_h_intern(&lf[326],28,"\003sysforeign-integer-argument");
lf[327]=C_h_intern(&lf[327],16,"unsigned-integer");
lf[328]=C_h_intern(&lf[328],37,"\003sysforeign-unsigned-integer-argument");
lf[329]=C_h_intern(&lf[329],9,"c-pointer");
lf[330]=C_h_intern(&lf[330],28,"\003sysforeign-pointer-argument");
lf[331]=C_h_intern(&lf[331],17,"nonnull-c-pointer");
lf[332]=C_h_intern(&lf[332],8,"c-string");
lf[333]=C_h_intern(&lf[333],17,"\003sysmake-c-string");
lf[334]=C_h_intern(&lf[334],27,"\003sysforeign-string-argument");
lf[335]=C_h_intern(&lf[335],16,"nonnull-c-string");
lf[336]=C_h_intern(&lf[336],6,"symbol");
lf[337]=C_h_intern(&lf[337],18,"\003syssymbol->string");
lf[338]=C_h_intern(&lf[338],3,"ref");
lf[339]=C_h_intern(&lf[339],8,"instance");
lf[340]=C_h_intern(&lf[340],12,"instance-ref");
lf[341]=C_h_intern(&lf[341],4,"this");
lf[342]=C_h_intern(&lf[342],8,"slot-ref");
lf[343]=C_h_intern(&lf[343],16,"nonnull-instance");
lf[344]=C_h_intern(&lf[344],5,"const");
lf[345]=C_h_intern(&lf[345],4,"enum");
lf[346]=C_h_intern(&lf[346],8,"function");
lf[347]=C_h_intern(&lf[347],27,"\010compilerforeign-type-table");
lf[348]=C_h_intern(&lf[348],17,"nonnull-c-string*");
lf[349]=C_h_intern(&lf[349],26,"nonnull-unsigned-c-string*");
lf[350]=C_h_intern(&lf[350],9,"c-string*");
lf[351]=C_h_intern(&lf[351],18,"unsigned-c-string*");
lf[352]=C_h_intern(&lf[352],13,"c-string-list");
lf[353]=C_h_intern(&lf[353],14,"c-string-list*");
lf[354]=C_h_intern(&lf[354],18,"unsigned-integer32");
lf[355]=C_h_intern(&lf[355],13,"unsigned-long");
lf[356]=C_h_intern(&lf[356],4,"long");
lf[357]=C_h_intern(&lf[357],9,"integer32");
lf[358]=C_h_intern(&lf[358],17,"nonnull-u16vector");
lf[359]=C_h_intern(&lf[359],16,"nonnull-s8vector");
lf[360]=C_h_intern(&lf[360],17,"nonnull-s16vector");
lf[361]=C_h_intern(&lf[361],17,"nonnull-u32vector");
lf[362]=C_h_intern(&lf[362],17,"nonnull-s32vector");
lf[363]=C_h_intern(&lf[363],17,"nonnull-f32vector");
lf[364]=C_h_intern(&lf[364],17,"nonnull-f64vector");
lf[365]=C_h_intern(&lf[365],9,"u16vector");
lf[366]=C_h_intern(&lf[366],8,"s8vector");
lf[367]=C_h_intern(&lf[367],9,"s16vector");
lf[368]=C_h_intern(&lf[368],9,"u32vector");
lf[369]=C_h_intern(&lf[369],9,"s32vector");
lf[370]=C_h_intern(&lf[370],9,"f32vector");
lf[371]=C_h_intern(&lf[371],9,"f64vector");
lf[372]=C_h_intern(&lf[372],22,"nonnull-scheme-pointer");
lf[373]=C_h_intern(&lf[373],12,"nonnull-blob");
lf[374]=C_h_intern(&lf[374],19,"nonnull-byte-vector");
lf[375]=C_h_intern(&lf[375],11,"byte-vector");
lf[376]=C_h_intern(&lf[376],4,"blob");
lf[377]=C_h_intern(&lf[377],14,"scheme-pointer");
lf[378]=C_h_intern(&lf[378],6,"double");
lf[379]=C_h_intern(&lf[379],6,"number");
lf[380]=C_h_intern(&lf[380],12,"unsigned-int");
lf[381]=C_h_intern(&lf[381],5,"short");
lf[382]=C_h_intern(&lf[382],14,"unsigned-short");
lf[383]=C_h_intern(&lf[383],4,"byte");
lf[384]=C_h_intern(&lf[384],13,"unsigned-byte");
lf[385]=C_h_intern(&lf[385],5,"int32");
lf[386]=C_h_intern(&lf[386],14,"unsigned-int32");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[388]=C_h_intern(&lf[388],36,"\010compilerforeign-type-convert-result");
lf[389]=C_h_intern(&lf[389],38,"\010compilerforeign-type-convert-argument");
lf[390]=C_h_intern(&lf[390],27,"\010compilerfinal-foreign-type");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[392]=C_h_intern(&lf[392],37,"\010compilerestimate-foreign-result-size");
lf[393]=C_h_intern(&lf[393],9,"integer64");
lf[394]=C_h_intern(&lf[394],4,"bool");
lf[395]=C_h_intern(&lf[395],4,"void");
lf[396]=C_h_intern(&lf[396],13,"scheme-object");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[398]=C_h_intern(&lf[398],46,"\010compilerestimate-foreign-result-location-size");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[401]=C_h_intern(&lf[401],30,"\010compilerfinish-foreign-result");
lf[402]=C_h_intern(&lf[402],17,"\003syspeek-c-string");
lf[403]=C_h_intern(&lf[403],25,"\003syspeek-nonnull-c-string");
lf[404]=C_h_intern(&lf[404],26,"\003syspeek-and-free-c-string");
lf[405]=C_h_intern(&lf[405],34,"\003syspeek-and-free-nonnull-c-string");
lf[406]=C_h_intern(&lf[406],17,"\003sysintern-symbol");
lf[407]=C_h_intern(&lf[407],22,"\003syspeek-c-string-list");
lf[408]=C_h_intern(&lf[408],31,"\003syspeek-and-free-c-string-list");
lf[409]=C_h_intern(&lf[409],35,"\010tinyclosmake-instance-from-pointer");
lf[410]=C_h_intern(&lf[410],4,"make");
lf[411]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[412]=C_h_intern(&lf[412],28,"\010compilerscan-used-variables");
lf[413]=C_h_intern(&lf[413],28,"\010compilerscan-free-variables");
lf[414]=C_h_intern(&lf[414],11,"lset-adjoin");
lf[415]=C_h_intern(&lf[415],25,"\010compilertopological-sort");
lf[416]=C_h_intern(&lf[416],7,"colored");
lf[417]=C_h_intern(&lf[417],23,"\010compilerchop-separator");
lf[418]=C_h_intern(&lf[418],9,"substring");
lf[419]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[420]=C_h_intern(&lf[420],23,"\010compilerchop-extension");
lf[421]=C_h_intern(&lf[421],22,"\010compilerprint-version");
lf[422]=C_h_intern(&lf[422],5,"print");
lf[423]=C_h_intern(&lf[423],15,"chicken-version");
lf[424]=C_h_intern(&lf[424],6,"print*");
lf[425]=C_h_intern(&lf[425],9,"\003syserror");
lf[426]=C_h_intern(&lf[426],20,"\010compilerprint-usage");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\0215Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012    -quiet               "
"       do not display compile information\012\012  File and pathname options:\012\012    -ou"
"tput-file FILENAME       specifies output-filename, default is \047out.c\047\012    -incl"
"ude-path PATHNAME      specifies alternative path for included files\012    -to-std"
"out                  write compiled file to stdout instead of file\012\012  Language o"
"ptions:\012\012    -feature SYMBOL             register feature identifier\012\012  Syntax r"
"elated options:\012\012    -case-insensitive           don\047t preserve case of read sym"
"bols\012    -keyword-style STYLE        allow alternative keyword syntax (none, pre"
"fix or suffix)\012    -compile-syntax             macros are made available at run-"
"time\012    -emit-import-library MODULE write compile-time module information into "
"separate file\012\012  Translation options:\012\012    -explicit-use               do not us"
"e units \047library\047 and \047eval\047 by default\012    -check-syntax               stop com"
"pilation after macro-expansion\012    -analyze-only               stop compilation "
"after first analysis pass\012\012  Debugging options:\012\012    -no-warnings               "
" disable warnings\012    -disable-warning CLASS      disable specific class of warn"
"ings\012    -debug-level NUMBER         set level of available debugging informatio"
"n\012    -no-trace                   disable tracing information\012    -profile      "
"              executable emits profiling information \012    -profile-name FILENAME"
"      name of the generated profile information file\012    -accumulate-profile    "
"     executable emits profiling information in append mode\012    -no-lambda-info  "
"           omit additional procedure-information\012\012  Optimization options:\012\012    -"
"optimize-level NUMBER      enable certain sets of optimization options\012    -opti"
"mize-leaf-routines     enable leaf routine optimization\012    -lambda-lift        "
"        enable lambda-lifting\012    -no-usual-integrations      standard procedure"
"s may be redefined\012    -unsafe                     disable safety checks\012    -bl"
"ock                      enable block-compilation\012    -disable-interrupts       "
"  disable interrupts in compiled code\012    -fixnum-arithmetic          assume all"
" numbers are fixnums\012    -benchmark-mode             fixnum mode, no interrupts "
"and opt.-level 3\012    -disable-stack-overflow-checks  \012                          "
"      disables detection of stack-overflows.\012    -inline                     ena"
"ble inlining\012    -inline-limit               set inlining threshold\012\012  Configura"
"tion options:\012\012    -unit NAME                  compile file as a library unit\012  "
"  -uses NAME                  declare library unit as used.\012    -heap-size NUMBE"
"R           specifies heap-size of compiled executable\012    -heap-initial-size NU"
"MBER   specifies heap-size at startup time\012    -heap-growth PERCENTAGE     speci"
"fies growth-rate of expanding heap\012    -heap-shrinkage PERCENTAGE  specifies shr"
"ink-rate of contracting heap\012    -nursery NUMBER\012    -stack-size NUMBER         "
" specifies nursery size of compiled executable\012    -extend FILENAME            l"
"oad file before compilation commences\012    -prelude EXPRESSION         add expres"
"sion to front of source file\012    -postlude EXPRESSION        add expression to e"
"nd of source file\012    -prologue FILENAME          include file before main sourc"
"e file\012    -epilogue FILENAME          include file after main source file\012    -"
"dynamic                    compile as dynamically loadable code\012    -require-ext"
"ension NAME     require and import extension NAME\012    -extension                "
"  compile as extension (dynamic or static)\012\012  Obscure options:\012\012    -debug MODES"
"                display debugging output for the given modes\012    -unsafe-librari"
"es           marks the generated file as being linked\012                          "
"      with the unsafe runtime system\012    -raw                        do not gene"
"rate implicit init- and exit code\011\011\011       \012    -emit-external-prototypes-first "
" emit protoypes for callbacks before foreign\012                                dec"
"larations\012");
lf[428]=C_h_intern(&lf[428],36,"\010compilermake-block-variable-literal");
lf[429]=C_h_intern(&lf[429],22,"block-variable-literal");
lf[430]=C_h_intern(&lf[430],32,"\010compilerblock-variable-literal\077");
lf[431]=C_h_intern(&lf[431],36,"\010compilerblock-variable-literal-name");
lf[432]=C_h_intern(&lf[432],25,"\010compilermake-random-name");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[434]=C_h_intern(&lf[434],6,"random");
lf[435]=C_h_intern(&lf[435],15,"current-seconds");
lf[436]=C_h_intern(&lf[436],23,"\010compilerset-real-name!");
lf[437]=C_h_intern(&lf[437],24,"\010compilerreal-name-table");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[439]=C_h_intern(&lf[439],19,"\010compilerreal-name2");
lf[440]=C_h_intern(&lf[440],32,"\010compilerdisplay-real-name-table");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[442]=C_h_intern(&lf[442],28,"\010compilersource-info->string");
lf[443]=C_h_intern(&lf[443],4,"conc");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[446]=C_h_intern(&lf[446],11,"make-string");
lf[447]=C_h_intern(&lf[447],3,"max");
lf[448]=C_h_intern(&lf[448],12,"string-null\077");
lf[449]=C_h_intern(&lf[449],19,"\010compilerdump-nodes");
lf[450]=C_h_intern(&lf[450],19,"\003syswrite-char/port");
lf[451]=C_h_intern(&lf[451],19,"\003sysstandard-output");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[455]=C_h_intern(&lf[455],18,"\003sysuser-read-hook");
lf[456]=C_h_intern(&lf[456],15,"foreign-declare");
lf[457]=C_h_intern(&lf[457],7,"declare");
lf[458]=C_h_intern(&lf[458],34,"\010compilerscan-sharp-greater-string");
lf[459]=C_h_intern(&lf[459],18,"\003sysread-char/port");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[461]=C_h_intern(&lf[461],17,"get-output-string");
lf[462]=C_h_intern(&lf[462],18,"open-output-string");
lf[463]=C_h_intern(&lf[463],35,"\010compilerprocess-custom-declaration");
lf[464]=C_h_intern(&lf[464],29,"\010compilercustom-declare-alist");
lf[465]=C_h_intern(&lf[465],31,"\010compileremit-control-file-item");
lf[466]=C_h_intern(&lf[466],25,"\010compilercsc-control-file");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\004~S~%");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\006#%csc\012");
lf[469]=C_h_intern(&lf[469],26,"pathname-replace-extension");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[471]=C_h_intern(&lf[471],27,"condition-property-accessor");
lf[472]=C_h_intern(&lf[472],3,"exn");
lf[473]=C_h_intern(&lf[473],7,"message");
lf[474]=C_h_intern(&lf[474],19,"condition-predicate");
C_register_lf2(lf,475,create_ptable());
t2=C_mutate(&lf[0] /* (set! c3182 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3572,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3570 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3573 in k3570 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3576 in k3573 in k3570 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3581,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3587,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3587,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant50 ...) */,lf[3]);
t3=C_mutate(&lf[4] /* (set! constant54 ...) */,lf[5]);
t4=C_mutate((C_word*)lf[6]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3591,tmp=(C_word)a,a+=2,tmp));
t5=C_set_block_item(lf[7] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[8] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t7=C_mutate((C_word*)lf[9]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3596,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[14]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3623,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[24]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3663,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[29]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3692,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[32]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3711,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[38]+1 /* (set! syntax-error ...) */,*((C_word*)lf[32]+1));
t13=C_mutate((C_word*)lf[39]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3736,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[40]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3739,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3782,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[44]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3850,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[45]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3886,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[49]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3907,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[52]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3932,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[53]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[54]));
t21=C_mutate((C_word*)lf[55]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3976,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[64]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4070,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[67]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4126,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[68]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4133,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[69]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4140,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[76]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4187,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[79]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4199,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4262,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[82]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4293,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[84]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4339,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[85]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4369,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[87]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4415,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[90]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4475,tmp=(C_word)a,a+=2,tmp));
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 284  condition-predicate */
t35=C_retrieve(lf[474]);
((C_proc3)C_retrieve_proc(t35))(3,t35,t34,lf[472]);}

/* k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 285  condition-property-accessor */
t3=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[472],lf[473]);}

/* k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word ab[148],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=C_mutate((C_word*)lf[97]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[109]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[110]));
t4=C_mutate((C_word*)lf[111]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4683,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[112]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4686,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[122]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4827,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[135]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4888,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[137]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4906,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[123]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4924,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[140]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4970,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[141]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5022,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[142]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5079,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[144]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5089,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[145]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5125,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[147]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5149,tmp=(C_word)a,a+=2,tmp));
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_mutate((C_word*)lf[152]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[198]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5598,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[200]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5604,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[201]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5610,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[203]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5619,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[204]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5628,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[205]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5637,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[206]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5646,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[207]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5655,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[198]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5664,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[208]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5670,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[210]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5685,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[211]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5700,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[246]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6304,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[260]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6637,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[262]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6691,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[267]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6804,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[270]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7025,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[272]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7059,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[273]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7136,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[276]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7356,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[280]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7457,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[281]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7579,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[282]+1 /* (set! check-global-exports ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7610,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[288]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7654,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[291]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7676,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[294]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7762,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[303]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7801,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[309]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7837,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[388]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8884,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[389]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8915,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[390]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8946,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[392]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8986,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[398]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9305,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[401]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9615,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[412]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9907,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[413]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10000,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[415]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10174,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[417]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10371,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[420]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10400,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[421]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10442,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[426]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10480,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[428]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10492,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[430]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10498,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[431]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10504,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[432]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10513,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[436]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10557,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[43]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10563,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[439]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10642,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[440]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10654,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[442]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10666,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[448]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10712,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[449]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10718,tmp=(C_word)a,a+=2,tmp));
t71=C_retrieve(lf[455]);
t72=C_mutate((C_word*)lf[455]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10820,a[2]=t71,tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[458]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10853,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[463]+1 /* (set! process-custom-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10922,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[465]+1 /* (set! emit-control-file-item ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10985,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[86]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11014,tmp=(C_word)a,a+=2,tmp));
t77=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t77+1)))(2,t77,C_SCHEME_UNDEFINED);}

/* ##compiler#big-fixnum? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_11014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11014,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#emit-control-file-item in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10989,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[466]))){
t4=t3;
f_10989(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10996,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11012,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1408 pathname-replace-extension */
t6=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[236]),lf[470]);}}

/* k11010 in ##compiler#emit-control-file-item in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_11012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1408 open-output-file */
t2=*((C_word*)lf[307]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10994 in ##compiler#emit-control-file-item in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10996,2,t0,t1);}
t2=C_mutate((C_word*)lf[466]+1 /* (set! csc-control-file ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1409 display */
t4=*((C_word*)lf[21]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[468],C_retrieve(lf[466]));}

/* k10997 in k10994 in ##compiler#emit-control-file-item in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10999,2,t0,t1);}
t2=*((C_word*)lf[6]+1);
t3=C_mutate((C_word*)lf[6]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11001,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
f_10989(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k10997 in k10994 in ##compiler#emit-control-file-item in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_11001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11005,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1413 close-output-port */
t3=*((C_word*)lf[304]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[466]));}

/* k11003 in ##compiler#compiler-cleanup-hook in k10997 in k10994 in ##compiler#emit-control-file-item in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_11005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1414 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k10987 in ##compiler#emit-control-file-item in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1415 fprintf */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[466]),lf[467],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10922,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[464]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10944,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_10944(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10959,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1395 open-output-file */
t14=*((C_word*)lf[307]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k10957 in ##compiler#process-custom-declaration in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10959,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[464]));
t5=C_mutate((C_word*)lf[464]+1 /* (set! custom-declare-alist ...) */,t4);
t6=*((C_word*)lf[6]+1);
t7=C_mutate((C_word*)lf[6]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10969,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10983,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1403 cons* */
t9=C_retrieve(lf[252]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10981 in k10957 in ##compiler#process-custom-declaration in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1403 emit-control-file-item */
t2=C_retrieve(lf[465]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_10969 in k10957 in ##compiler#process-custom-declaration in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10973,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1401 close-output-port */
t3=*((C_word*)lf[304]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10971 */
static void C_ccall f_10973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1402 old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k10942 in ##compiler#process-custom-declaration in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10944,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[21]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10952,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a10948 in k10942 in ##compiler#process-custom-declaration in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10952,3,t0,t1,t2);}
/* g342734283434 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10853,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10857,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1365 open-output-string */
t4=C_retrieve(lf[462]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10857,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10862,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10862(t5,((C_word*)t0)[2]);}

/* loop in k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10862,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[459]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10864 in loop in k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10866,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1368 quit */
t2=*((C_word*)lf[29]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[460]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10884,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1370 newline */
t3=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[459]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[450]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k10915 in k10864 in loop in k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1382 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10862(t2,((C_word*)t0)[2]);}

/* k10894 in k10864 in loop in k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10896,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1375 get-output-string */
t3=C_retrieve(lf[461]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10908,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[450]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k10906 in k10894 in k10864 in loop in k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[450]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10909 in k10906 in k10894 in k10864 in loop in k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1379 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10862(t2,((C_word*)t0)[2]);}

/* k10882 in k10864 in loop in k10855 in ##compiler#scan-sharp-greater-string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1371 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10862(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10820,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10830,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[459]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1362 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k10828 in ##sys#user-read-hook in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10833,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1360 scan-sharp-greater-string */
t3=C_retrieve(lf[458]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10831 in k10828 in ##sys#user-read-hook in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10833,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[456],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[457],t4));}

/* ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10718,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10727,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10727(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10727(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10727,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10731,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10814,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_10814 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10814,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10734,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10809,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_10809 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10809,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10737,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10804,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10804 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10804,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1338 make-string */
t3=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_make_character(32));}

/* k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10740,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10746,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1340 printf */
t4=C_retrieve(lf[17]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[454],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10749,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10798 in k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10799,3,t0,t1,t2);}
/* loop3300 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10727(t3,t1,((C_word*)t0)[2],t2);}

/* k10747 in k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10749,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10764,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1344 printf */
t6=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[453],t5);}
else{
t4=t3;
f_10755(2,t4,C_SCHEME_UNDEFINED);}}

/* k10762 in k10747 in k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10767,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10772,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10772(t6,t2,C_fix(5));}

/* doloop3330 in k10762 in k10747 in k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10772(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10772,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10782,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1347 printf */
t5=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[452],t4);}}

/* k10780 in doloop3330 in k10762 in k10747 in k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10772(t3,((C_word*)t0)[2],t2);}

/* k10765 in k10762 in k10747 in k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[450]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[451]+1));}

/* k10753 in k10747 in k10744 in k10738 in k10735 in k10732 in k10729 in loop in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[450]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[451]+1));}

/* k10720 in ##compiler#dump-nodes in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1350 newline */
t2=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10712,3,t0,t1,t2);}
/* support.scm: 1328 string-null? */
t3=C_retrieve(lf[448]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#source-info->string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10666,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10685,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1321 ->string */
t7=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1323 ->string */
t3=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k10683 in ##compiler#source-info->string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10692,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10696,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1322 max */
t6=*((C_word*)lf[447]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k10694 in k10683 in ##compiler#source-info->string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1322 make-string */
t2=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k10690 in k10683 in ##compiler#source-info->string in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1322 conc */
t2=C_retrieve(lf[443]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[444],((C_word*)t0)[3],t1,lf[445],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10660,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1311 ##sys#hash-table-for-each */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[437]));}

/* a10659 in ##compiler#display-real-name-table in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10660,4,t0,t1,t2,t3);}
/* support.scm: 1313 printf */
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[441],t2,t3);}

/* ##compiler#real-name2 in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10642,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10646,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1307 ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[437]),t2);}

/* k10644 in ##compiler#real-name2 in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1308 real-name */
t2=C_retrieve(lf[43]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10563(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10563r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10563r(t0,t1,t2,t3);}}

static void C_ccall f_10563r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10566,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10582,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1291 resolve */
f_10566(t5,t2);}

/* k10580 in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10582,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1295 ##sys#symbol->qualified-string */
t5=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
/* support.scm: 1304 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1292 ##sys#symbol->qualified-string */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k10605 in k10580 in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10611,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1296 get */
t3=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[146]);}

/* k10609 in k10605 in k10580 in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10611,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10613,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10613(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10609 in k10605 in k10580 in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10613(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10613,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1298 resolve */
f_10566(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k10618 in loop in k10609 in k10605 in k10580 in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10620,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10633,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1301 sprintf */
t4=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[438],((C_word*)t0)[4],t1);}}

/* k10631 in k10618 in loop in k10609 in k10605 in k10580 in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10637,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1302 get */
t3=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[146]);}

/* k10635 in k10631 in k10618 in loop in k10609 in k10605 in k10580 in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1301 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10613(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10566(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10566,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10570,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1286 ##sys#hash-table-ref */
t4=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[437]),t2);}

/* k10568 in resolve in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10570,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10576,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1288 ##sys#hash-table-ref */
t3=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[437]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k10574 in k10568 in resolve in ##compiler#real-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10557,4,t0,t1,t2,t3);}
/* support.scm: 1282 ##sys#hash-table-set! */
t4=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[437]),t2,t3);}

/* ##compiler#make-random-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10513(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_10513r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10513r(t0,t1,t2);}}

static void C_ccall f_10513r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1269 gensym */
t5=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_10525(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[425]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k10523 in ##compiler#make-random-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10529,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1270 current-seconds */
t3=C_retrieve(lf[435]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10527 in k10523 in ##compiler#make-random-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10533,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1271 random */
t3=C_retrieve(lf[434]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k10531 in k10527 in k10523 in ##compiler#make-random-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1268 sprintf */
t2=C_retrieve(lf[47]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[433],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10519 in ##compiler#make-random-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1267 string->symbol */
t2=*((C_word*)lf[50]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10504,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[429]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10498,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[429]));}

/* ##compiler#make-block-variable-literal in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10492,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[429],t2));}

/* ##compiler#print-usage in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1158 print-version */
t3=C_retrieve(lf[421]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10482 in ##compiler#print-usage in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1159 newline */
t3=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10485 in k10482 in ##compiler#print-usage in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1160 display */
t2=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[427]);}

/* ##compiler#print-version in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10442(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_10442r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10442r(t0,t1,t2);}}

static void C_ccall f_10442r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10446,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_10446(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_10446(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[425]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k10444 in ##compiler#print-version in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1154 print* */
t3=*((C_word*)lf[424]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[5]);}
else{
t3=t2;
f_10449(2,t3,C_SCHEME_UNDEFINED);}}

/* k10447 in k10444 in ##compiler#print-version in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1155 chicken-version */
t3=C_retrieve(lf[423]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k10454 in k10447 in k10444 in ##compiler#print-version in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1155 print */
t2=*((C_word*)lf[422]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10400,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10409,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10409(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10409,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1147 substring */
t6=*((C_word*)lf[418]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1148 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10371,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10381,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_10381(t7,(C_word)C_i_memq(t6,lf[419]));}
else{
t6=t5;
f_10381(t6,C_SCHEME_FALSE);}}

/* k10379 in ##compiler#chop-separator in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1140 substring */
t2=*((C_word*)lf[418]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10174,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10183,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10230,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10265,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10302,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10353,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
/* for-each */
t16=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a10352 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10353,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* support.scm: 1122 insert */
t5=((C_word*)t0)[2];
f_10183(t5,t1,t3,t4);}

/* k10300 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10347,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1125 caar */
t4=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k10345 in k10300 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10351,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1125 cdar */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10349 in k10345 in k10300 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1125 visit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10265(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10303 in k10300 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10308,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a10309 in k10303 in k10300 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10314,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 1127 lookup */
t5=((C_word*)t0)[2];
f_10230(t5,t3,t4);}

/* k10312 in a10309 in k10303 in k10300 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[416]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1129 visit */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10265(t5,((C_word*)t0)[4],t3,t4);}}

/* k10306 in k10303 in k10300 in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10265,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10269,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 1110 insert */
t5=((C_word*)t0)[2];
f_10183(t5,t4,t2,lf[416]);}

/* k10267 in visit in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10272,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10277 in k10267 in visit in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10278,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10282,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1113 lookup */
t4=((C_word*)t0)[2];
f_10230(t4,t3,t2);}

/* k10280 in a10277 in k10267 in visit in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[416]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* support.scm: 1115 visit */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10265(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k10270 in k10267 in visit in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10272,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10230(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10230,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10236,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10236(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10236(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10236,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10249,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10263,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1105 caar */
t5=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k10261 in loop in lookup in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1105 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10247 in loop in lookup in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1105 cdar */
t2=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 1106 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10236(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10183(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10183,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10189,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10189(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10189(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10189,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10228,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1099 caar */
t5=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k10226 in loop in insert in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1099 pred */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10208 in loop in insert in ##compiler#topological-sort in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 1100 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10189(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10000,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10003,a[2]=t8,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10159,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10172,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1082 walk */
t12=((C_word*)t6)[1];
f_10003(t12,t11,t2,C_SCHEME_END_OF_LIST);}

/* k10170 in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10159(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10159,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10165,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10164 in walkeach in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10165,3,t0,t1,t2);}
/* support.scm: 1080 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10003(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10003(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10003,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10007,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10153,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10153 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10153,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10148,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10148 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10148,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10143,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10143 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10143,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10013,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[83]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_10022(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[215]);
if(C_truep(t4)){
t5=t3;
f_10022(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[223]);
if(C_truep(t5)){
t6=t3;
f_10022(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[226]);
t7=t3;
f_10022(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[239])));}}}}

/* k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10022,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[209]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[6]))){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10041,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1064 lset-adjoin */
t5=C_retrieve(lf[414]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[269]+1),((C_word*)((C_word*)t0)[5])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[227]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10053,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[6]))){
t6=t5;
f_10053(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10067,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1067 lset-adjoin */
t7=C_retrieve(lf[414]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[269]+1),((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[93]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10076,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1070 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10003(t7,t5,t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[222]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10106,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1073 decompose-lambda-list */
t8=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[9],t6,t7);}
else{
/* support.scm: 1077 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10159(t6,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[6]);}}}}}}

/* a10105 in k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10106,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10118,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1076 append */
t7=*((C_word*)lf[58]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10116 in a10105 in k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1076 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10003(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10074 in k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10076,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10087,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1071 append */
t4=*((C_word*)lf[58]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10085 in k10074 in k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1071 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10003(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10065 in k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10053(t3,t2);}

/* k10051 in k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_10053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1068 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10003(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10039 in k10020 in k10011 in k10008 in k10005 in walk in ##compiler#scan-free-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_10041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9907,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9911,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9913,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_9913(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9913,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9917,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9994,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_9994 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9994,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9989,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9989 in k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9989,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9918 in k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9920,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[209]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[227]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9960,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_eqp(t1,lf[83]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9973,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_9973(t6,t4);}
else{
t6=(C_word)C_eqp(t1,lf[215]);
t7=t5;
f_9973(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[223])));}}}

/* k9971 in k9918 in k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* f_9960 in k9918 in k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9960,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9957 in k9918 in k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9959,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9935,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9941,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_9941(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_9941(t5,C_SCHEME_FALSE);}}

/* k9939 in k9957 in k9918 in k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9941,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_9935(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_9935(t2,C_SCHEME_UNDEFINED);}}

/* k9933 in k9957 in k9918 in k9915 in walk in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k9909 in ##compiler#scan-used-variables in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[116],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9615,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[332]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[402],t9));}
else{
t6=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[403],t10));}
else{
t7=(C_word)C_eqp(t4,lf[350]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[351]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[83],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[404],t12));}
else{
t9=(C_word)C_eqp(t4,lf[348]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[349]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[83],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[405],t14));}
else{
t11=(C_word)C_eqp(t4,lf[336]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[83],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[402],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[406],t17));}
else{
t12=(C_word)C_eqp(t4,lf[352]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[83],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[407],t16));}
else{
t13=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[83],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[408],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9811,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_9811(t18,(C_word)C_i_memq(t17,lf[411]));}
else{
t17=t14;
f_9811(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_9811(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k9809 in ##compiler#finish-foreign-result in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[409],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_9832(t6,(C_word)C_eqp(lf[343],t5));}
else{
t5=t2;
f_9832(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_9832(t3,C_SCHEME_FALSE);}}}

/* k9830 in k9809 in ##compiler#finish-foreign-result in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9832,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[341],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[410],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9305,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9308,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9317,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9609,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 990  follow-without-loop */
t6=*((C_word*)lf[81]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a9608 in ##compiler#estimate-foreign-result-location-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9609,2,t0,t1);}
/* support.scm: 1011 quit */
t2=*((C_word*)lf[29]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[400],((C_word*)t0)[2]);}

/* a9316 in ##compiler#estimate-foreign-result-location-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9317,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[310]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9327,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_9327(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[314]);
if(C_truep(t7)){
t8=t6;
f_9327(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t8)){
t9=t6;
f_9327(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[394]);
if(C_truep(t9)){
t10=t6;
f_9327(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t10)){
t11=t6;
f_9327(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[311]);
if(C_truep(t11)){
t12=t6;
f_9327(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t12)){
t13=t6;
f_9327(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t13)){
t14=t6;
f_9327(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t14)){
t15=t6;
f_9327(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[383]);
if(C_truep(t15)){
t16=t6;
f_9327(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[384]);
if(C_truep(t16)){
t17=t6;
f_9327(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[329]);
if(C_truep(t17)){
t18=t6;
f_9327(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[318]);
if(C_truep(t18)){
t19=t6;
f_9327(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[331]);
if(C_truep(t19)){
t20=t6;
f_9327(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[327]);
if(C_truep(t20)){
t21=t6;
f_9327(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[325]);
if(C_truep(t21)){
t22=t6;
f_9327(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[316]);
if(C_truep(t22)){
t23=t6;
f_9327(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[332]);
if(C_truep(t23)){
t24=t6;
f_9327(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[336]);
if(C_truep(t24)){
t25=t6;
f_9327(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t25)){
t26=t6;
f_9327(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t26)){
t27=t6;
f_9327(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[385]);
if(C_truep(t27)){
t28=t6;
f_9327(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[386]);
if(C_truep(t28)){
t29=t6;
f_9327(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t29)){
t30=t6;
f_9327(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t30)){
t31=t6;
f_9327(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t31)){
t32=t6;
f_9327(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t32)){
t33=t6;
f_9327(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t33)){
t34=t6;
f_9327(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[350]);
if(C_truep(t34)){
t35=t6;
f_9327(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[348]);
if(C_truep(t35)){
t36=t6;
f_9327(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[352]);
t37=t6;
f_9327(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[353])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k9325 in a9316 in ##compiler#estimate-foreign-result-location-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9327,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 999  words->bytes */
t2=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[379]));
if(C_truep(t3)){
/* support.scm: 1001 words->bytes */
t4=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[6],C_fix(2));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1003 ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[347]),((C_word*)t0)[3]);}
else{
t5=t4;
f_9345(2,t5,C_SCHEME_FALSE);}}}}

/* k9343 in k9325 in a9316 in ##compiler#estimate-foreign-result-location-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9345,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1005 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_9379(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[320]);
if(C_truep(t5)){
t6=t4;
f_9379(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[318]);
if(C_truep(t6)){
t7=t4;
f_9379(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[329]);
if(C_truep(t7)){
t8=t4;
f_9379(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[331]);
t9=t4;
f_9379(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[346])));}}}}}
else{
/* support.scm: 1010 err */
f_9308(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k9377 in k9343 in k9325 in a9316 in ##compiler#estimate-foreign-result-location-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1008 words->bytes */
t2=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(1));}
else{
/* support.scm: 1009 err */
f_9308(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9308(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9308,NULL,2,t1,t2);}
/* support.scm: 989  quit */
t3=*((C_word*)lf[29]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[399],t2);}

/* ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8986,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8992,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 960  follow-without-loop */
t5=*((C_word*)lf[81]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a9298 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9299,2,t0,t1);}
/* support.scm: 985  quit */
t2=*((C_word*)lf[29]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[397],((C_word*)t0)[2]);}

/* a8991 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8992,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[310]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9002,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9002(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[314]);
if(C_truep(t7)){
t8=t6;
f_9002(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t8)){
t9=t6;
f_9002(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[394]);
if(C_truep(t9)){
t10=t6;
f_9002(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[395]);
if(C_truep(t10)){
t11=t6;
f_9002(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t11)){
t12=t6;
f_9002(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[396]);
if(C_truep(t12)){
t13=t6;
f_9002(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[311]);
if(C_truep(t13)){
t14=t6;
f_9002(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t14)){
t15=t6;
f_9002(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[383]);
if(C_truep(t15)){
t16=t6;
f_9002(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[384]);
if(C_truep(t16)){
t17=t6;
f_9002(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[385]);
t18=t6;
f_9002(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[386])));}}}}}}}}}}}}

/* k9000 in a8991 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9002,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[332]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9011(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[335]);
if(C_truep(t4)){
t5=t3;
f_9011(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[329]);
if(C_truep(t5)){
t6=t3;
f_9011(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[331]);
if(C_truep(t6)){
t7=t3;
f_9011(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[336]);
if(C_truep(t7)){
t8=t3;
f_9011(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[350]);
if(C_truep(t8)){
t9=t3;
f_9011(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[348]);
if(C_truep(t9)){
t10=t3;
f_9011(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
if(C_truep(t10)){
t11=t3;
f_9011(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t11)){
t12=t3;
f_9011(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[352]);
t13=t3;
f_9011(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[353])));}}}}}}}}}}}

/* k9009 in k9000 in a8991 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9011,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 970  words->bytes */
t2=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[327]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9023(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
if(C_truep(t4)){
t5=t3;
f_9023(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[325]);
if(C_truep(t5)){
t6=t3;
f_9023(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_9023(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[357]);
t8=t3;
f_9023(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[354])));}}}}}}

/* k9021 in k9009 in k9000 in a8991 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9023,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 972  words->bytes */
t2=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(4));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[316]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9035(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[378]);
if(C_truep(t4)){
t5=t3;
f_9035(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
t6=t3;
f_9035(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[393])));}}}}

/* k9033 in k9021 in k9009 in k9000 in a8991 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9035(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9035,NULL,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 974  words->bytes */
t2=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 976  ##sys#hash-table-ref */
t3=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[347]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9041(2,t3,C_SCHEME_FALSE);}}}

/* k9039 in k9033 in k9021 in k9009 in k9000 in a8991 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9041,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 978  next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9075,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9075(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[320]);
if(C_truep(t5)){
t6=t4;
f_9075(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[318]);
if(C_truep(t6)){
t7=t4;
f_9075(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[329]);
if(C_truep(t7)){
t8=t4;
f_9075(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t8)){
t9=t4;
f_9075(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t9)){
t10=t4;
f_9075(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[339]);
if(C_truep(t10)){
t11=t4;
f_9075(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[340]);
t12=t4;
f_9075(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[343])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9073 in k9039 in k9033 in k9021 in k9009 in k9000 in a8991 in ##compiler#estimate-foreign-result-size in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_9075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 982  words->bytes */
t2=*((C_word*)lf[68]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8946(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8946,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8952,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8980,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 947  follow-without-loop */
t5=*((C_word*)lf[81]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a8979 in ##compiler#final-foreign-type in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
/* support.scm: 954  quit */
t2=*((C_word*)lf[29]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[391],((C_word*)t0)[2]);}

/* a8951 in ##compiler#final-foreign-type in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8952,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8956,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 950  ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[347]),t2);}
else{
t5=t4;
f_8956(2,t5,C_SCHEME_FALSE);}}

/* k8954 in a8951 in ##compiler#final-foreign-type in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 952  next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8915,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8919,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8928,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 941  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[347]),t3);}
else{
t5=t4;
f_8919(t5,C_SCHEME_FALSE);}}

/* k8926 in ##compiler#foreign-type-convert-argument in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8928,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_8919(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_8919(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8919(t2,C_SCHEME_FALSE);}}

/* k8917 in ##compiler#foreign-type-convert-argument in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8884,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8888,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8897,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 934  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[347]),t3);}
else{
t5=t4;
f_8888(t5,C_SCHEME_FALSE);}}

/* k8895 in ##compiler#foreign-type-convert-result in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8897,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_8888(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_8888(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8888(t2,C_SCHEME_FALSE);}}

/* k8886 in ##compiler#foreign-type-convert-result in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7837,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7843,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8878,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 835  follow-without-loop */
t6=*((C_word*)lf[81]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a8877 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8878,2,t0,t1);}
/* support.scm: 927  quit */
t2=*((C_word*)lf[29]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[387],((C_word*)t0)[2]);}

/* a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7843,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7849,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7849(t7,t1,t2);}

/* repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7849(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7849,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[310]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[311]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[312]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[313],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[314]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7878(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[380]);
if(C_truep(t8)){
t9=t7;
f_7878(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[381]);
if(C_truep(t9)){
t10=t7;
f_7878(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[382]);
if(C_truep(t10)){
t11=t7;
f_7878(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[383]);
if(C_truep(t11)){
t12=t7;
f_7878(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[384]);
if(C_truep(t12)){
t13=t7;
f_7878(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[385]);
t14=t7;
f_7878(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[386])));}}}}}}}}

/* k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7878,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[312]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[315],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[316]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7897(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_7897(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7897,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[312]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[317],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[318]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7916(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[375]);
if(C_truep(t4)){
t5=t3;
f_7916(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t6=t3;
f_7916(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}}

/* k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7916,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7919,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 845  gensym */
t3=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[320]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7986(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
if(C_truep(t4)){
t5=t3;
f_7986(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[373]);
t6=t3;
f_7986(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[374])));}}}}

/* k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7986,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[312]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[319],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[321]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8005(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[365]);
if(C_truep(t4)){
t5=t3;
f_8005(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[366]);
if(C_truep(t5)){
t6=t3;
f_8005(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[367]);
if(C_truep(t6)){
t7=t3;
f_8005(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[368]);
if(C_truep(t7)){
t8=t3;
f_8005(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[369]);
if(C_truep(t8)){
t9=t3;
f_8005(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[370]);
t10=t3;
f_8005(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[371])));}}}}}}}}

/* k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8005,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8008,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 857  gensym */
t3=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[323]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8087(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[358]);
if(C_truep(t4)){
t5=t3;
f_8087(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t5)){
t6=t3;
f_8087(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t6)){
t7=t3;
f_8087(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t7)){
t8=t3;
f_8087(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[362]);
if(C_truep(t8)){
t9=t3;
f_8087(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[363]);
t10=t3;
f_8087(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[364])));}}}}}}}}

/* k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8087,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[312]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[324]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[322],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[325]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8126(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t5=t3;
f_8126(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[357])));}}}

/* k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8126,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[312]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[326],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[327]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8145(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[354]);
t5=t3;
f_8145(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[355])));}}}

/* k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8145,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[312]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[328],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[329]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8164(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[352]);
t5=t3;
f_8164(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[353])));}}}

/* k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8164(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8164,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8167,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 877  gensym */
t3=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[331]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[330],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[332]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8244(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[350]);
t6=t4;
f_8244(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[351])));}}}}

/* k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8244,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 885  gensym */
t3=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[335]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8329(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[348]);
t5=t3;
f_8329(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[349])));}}}

/* k8327 in k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8329,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[312]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[333],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[334],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[333],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[336]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[312]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[337],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[333],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[337],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[334],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[333],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 901  ##sys#hash-table-ref */
t4=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[347]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8404(2,t4,C_SCHEME_FALSE);}}}}

/* k8402 in k8327 in k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8404,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 903  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8438(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[318]);
if(C_truep(t5)){
t6=t4;
f_8438(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[346]);
t7=t4;
f_8438(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[329])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k8436 in k8402 in k8327 in k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8438,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8441,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 907  gensym */
t3=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[339]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[340]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8508,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 913  gensym */
t5=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[343]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[341],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[342],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[344]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 920  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7849(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[345]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[312]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[326],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[320]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[331]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[330],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k8506 in k8436 in k8402 in k8327 in k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8508,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[341],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[342],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[83],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[214],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[93],t17));}

/* k8439 in k8436 in k8402 in k8327 in k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8441,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[330],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[214],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k8245 in k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8278,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[312]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8278(t7,(C_word)C_a_i_cons(&a,2,lf[333],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[334],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_8278(t9,(C_word)C_a_i_cons(&a,2,lf[333],t8));}}

/* k8276 in k8245 in k8242 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8278,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[214],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k8165 in k8162 in k8143 in k8124 in k8085 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8167,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[330],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[214],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k8006 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_8008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8008,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8039,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[312]))){
t6=t5;
f_8039(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8039(t10,(C_word)C_a_i_cons(&a,2,lf[322],t9));}}

/* k8037 in k8006 in k8003 in k7984 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_8039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8039,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[214],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k7917 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7919,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[312]))){
t6=t5;
f_7950(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_7950(t7,(C_word)C_a_i_cons(&a,2,lf[319],t6));}}

/* k7948 in k7917 in k7914 in k7895 in k7876 in repeat in a7842 in ##compiler#foreign-type-check in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7950,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[214],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* ##compiler#pprint-expressions-to-file in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7801,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7805,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 816  open-output-file */
t5=*((C_word*)lf[307]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
/* support.scm: 816  current-output-port */
t5=*((C_word*)lf[308]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k7803 in ##compiler#pprint-expressions-to-file in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7808,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 817  with-output-to-port */
t4=C_retrieve(lf[306]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a7815 in k7803 in ##compiler#pprint-expressions-to-file in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7822,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a7821 in a7815 in k7803 in ##compiler#pprint-expressions-to-file in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7826,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 821  pretty-print */
t4=C_retrieve(lf[305]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7824 in a7821 in a7815 in k7803 in ##compiler#pprint-expressions-to-file in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 822  newline */
t2=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k7806 in k7803 in ##compiler#pprint-expressions-to-file in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 824  close-output-port */
t2=*((C_word*)lf[304]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7762,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7768,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7774,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a7773 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7774,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7781,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 804  debugging */
t10=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[301],lf[302]);}

/* k7779 in a7773 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7781,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7784,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 805  printf */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[300],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7782 in k7779 in a7773 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 806  printf */
t3=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[299],((C_word*)t0)[2]);}

/* k7785 in k7782 in k7779 in a7773 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 807  printf */
t3=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[298],((C_word*)t0)[2]);}

/* k7788 in k7785 in k7782 in k7779 in a7773 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 808  printf */
t3=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[297],((C_word*)t0)[2]);}

/* k7791 in k7788 in k7785 in k7782 in k7779 in a7773 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 809  printf */
t3=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[296],((C_word*)t0)[2]);}

/* k7794 in k7791 in k7788 in k7785 in k7782 in k7779 in a7773 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 810  printf */
t2=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[295],((C_word*)t0)[2]);}

/* a7767 in ##compiler#print-program-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7768,2,t0,t1);}
/* support.scm: 803  compute-database-statistics */
t2=C_retrieve(lf[291]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7676,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7680,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7685,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 779  ##sys#hash-table-for-each */
t15=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a7684 in ##compiler#compute-database-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7685,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a7690 in a7684 in ##compiler#compute-database-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7691,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[180]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[162]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7733,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cdr(t2);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7738,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t8=(C_word)C_eqp(t5,lf[168]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* f_7738 in a7690 in a7684 in ##compiler#compute-database-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7738,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7731 in a7690 in a7684 in ##compiler#compute-database-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[222],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7678 in ##compiler#compute-database-statistics in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 793  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[292]),C_retrieve(lf[293]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7654,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7664,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 755  debugging */
t8=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[244],lf[290],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k7662 in ##sys#toplevel-definition-hook in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7664,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[289]));
t3=C_mutate((C_word*)lf[289]+1 /* (set! block-globals ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* check-global-exports in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7610,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[283]))){
t3=C_retrieve(lf[283]);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7617,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7628,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 741  ##sys#hash-table-for-each */
t7=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7627 in check-global-exports in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7628,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7632,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7639,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t6=(C_word)C_i_assq(lf[178],t3);
t7=t5;
f_7639(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7639(t6,C_SCHEME_FALSE);}}

/* k7637 in a7627 in check-global-exports in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 744  compiler-warning */
t2=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[284],lf[287],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7632(2,t2,C_SCHEME_UNDEFINED);}}

/* k7630 in a7627 in check-global-exports in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 745  delete */
t3=C_retrieve(lf[286]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[269]+1));}

/* k7634 in k7630 in a7627 in check-global-exports in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7615 in check-global-exports in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7622,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a7621 in k7615 in check-global-exports in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7622,3,t0,t1,t2);}
/* ##compiler#compiler-warning */
t3=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[284],lf[285],t2);}

/* ##compiler#dump-undefined-globals in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7579,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7585,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 730  ##sys#hash-table-for-each */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a7584 in ##compiler#dump-undefined-globals in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7585,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7592,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[180],t3))){
t5=(C_word)C_i_assq(lf[178],t3);
t6=t4;
f_7592(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_7592(t5,C_SCHEME_FALSE);}}

/* k7590 in a7584 in ##compiler#dump-undefined-globals in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7592,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7595,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 734  write */
t3=*((C_word*)lf[194]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7593 in k7590 in a7584 in ##compiler#dump-undefined-globals in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 735  newline */
t2=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7457,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7461,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7573,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7573 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7573,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7461,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
if(C_truep((C_word)C_i_cadr(t1))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7481,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7481(3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7485,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7562,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7562 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7562,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[234]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7539,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(t1,lf[225]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7557,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}}

/* f_7557 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7557,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7554 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 724  every */
t2=C_retrieve(lf[88]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* f_7539 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7539,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7492 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7494,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7533,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7534,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7534 in k7492 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7534,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7531 in k7492 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7533,2,t0,t1);}
t2=(C_word)C_eqp(lf[209],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7525,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_7525 in k7531 in k7492 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7525,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7522 in k7531 in k7492 in k7483 in rec in k7459 in ##compiler#simple-lambda-node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 722  every */
t5=C_retrieve(lf[88]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7356,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7362,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7362(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7362,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7366,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7451,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7451 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7451,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7369,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7446,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_7446 in k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7446,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7367 in k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7369,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[209]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7378(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[83]);
if(C_truep(t4)){
t5=t3;
f_7378(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[215]);
if(C_truep(t5)){
t6=t3;
f_7378(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[226]);
t7=t3;
f_7378(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[213])));}}}}

/* k7376 in k7367 in k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7378,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[222]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7405,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[214]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[93]));
if(C_truep(t4)){
/* support.scm: 706  any */
t5=C_retrieve(lf[65]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* f_7405 in k7376 in k7367 in k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7405,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7402 in k7376 in k7367 in k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7404,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7392,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 705  find */
t4=C_retrieve(lf[278]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t3,C_retrieve(lf[279]));}

/* a7391 in k7402 in k7376 in k7367 in k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7392,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7400,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 705  foreign-callback-stub-id */
t4=C_retrieve(lf[277]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7398 in a7391 in k7402 in k7376 in k7367 in k7364 in walk in ##compiler#expression-has-side-effects? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7136,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7139,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7168,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7211,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7330,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 689  matchn */
t15=((C_word*)t12)[1];
f_7211(t15,t14,t2,t3);}

/* k7328 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7330,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7336,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7350,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7350 in k7328 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7350,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7338 in k7328 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7345,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7345 in k7338 in k7328 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7345,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7342 in k7338 in k7328 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 692  debugging */
t2=*((C_word*)lf[14]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[274],lf[275],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7334 in k7328 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7211(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7211,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 678  resolve */
t4=((C_word*)t0)[4];
f_7139(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7318,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7323,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* f_7323 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7323,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7318,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7305,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7310,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_7310 in k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7310,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7303 in k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* support.scm: 680  match1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7168(t3,((C_word*)t0)[2],t1,t2);}

/* k7231 in k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7233,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7297,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7297 in k7231 in k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7297,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7238 in k7231 in k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7240,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7246,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7246(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k7238 in k7231 in k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7246(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7246,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 684  resolve */
t4=((C_word*)t0)[4];
f_7139(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7277,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 686  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7211(t7,t4,t5,t6);}}}}

/* k7275 in loop in k7238 in k7231 in k7316 in matchn in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 687  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7246(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7168(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7168,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 671  resolve */
t4=((C_word*)t0)[3];
f_7139(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7190,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 673  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7188 in match1 in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 673  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7168(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7139(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7139,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7163,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 666  alist-cons */
t6=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7161 in resolve in ##compiler#match-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7059,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7063,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7129,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7130,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_7130 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7130,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7127 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 648  node-class-set! */
t2=C_retrieve(lf[201]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7120,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7121,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7121 in k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7121,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7118 in k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 649  node-parameters-set! */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7064 in k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7111,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7112,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7112 in k7064 in k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7112,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7109 in k7064 in k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 650  node-subexpressions-set! */
t2=C_retrieve(lf[206]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7067 in k7064 in k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7069,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7080(t4,C_fix(4)));}

/* doloop1526 in k7067 in k7064 in k7061 in ##compiler#copy-node! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static C_word C_fcall f_7080(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7025,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7031,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7031(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_7031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7031,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7045,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 644  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7043 in rec in ##compiler#tree-copy in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7049,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 644  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7031(t4,t2,t3);}

/* k7047 in k7043 in rec in ##compiler#tree-copy in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7049,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6804,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6808,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 612  map */
t6=*((C_word*)lf[249]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[271]+1),t3,t4);}

/* k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6810,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6816,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 639  walk */
t6=((C_word*)t4)[1];
f_6816(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6816(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6816,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6820,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7016,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7016 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7016,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6823,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7011,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7011 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7011,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7006,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7006 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7006,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6826,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6839,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 619  rename */
f_6810(t3,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(t1,lf[227]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* support.scm: 620  rename */
f_6810(t4,t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(t1,lf[93]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6891,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 623  gensym */
t7=C_retrieve(lf[94]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t5=(C_word)C_eqp(t1,lf[222]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6931,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 627  decompose-lambda-list */
t8=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[7],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 638  tree-copy */
t7=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}}}}}

/* k6988 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6994,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7000 in k6988 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7001,3,t0,t1,t2);}
/* walk1404 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6816(t3,t1,t2,((C_word*)t0)[2]);}

/* k6992 in k6988 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6995,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6995 in k6992 in k6988 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6995,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6931,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[94]),t2);}

/* k6933 in a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 631  append */
t3=*((C_word*)lf[58]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6936 in k6933 in a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6938,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6980,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 635  rename */
f_6810(t5,((C_word*)t0)[3],t1);}
else{
t6=t5;
f_6980(2,t6,C_SCHEME_FALSE);}}

/* k6978 in k6936 in k6933 in a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 635  build-lambda-list */
t2=*((C_word*)lf[52]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6970 in k6936 in k6933 in a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6972,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6949,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6955 in k6970 in k6936 in k6933 in a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6956,3,t0,t1,t2);}
/* walk1404 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6816(t3,t1,t2,((C_word*)t0)[2]);}

/* k6947 in k6970 in k6936 in k6933 in a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6950,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[222],((C_word*)t0)[2],t1);}

/* f_6950 in k6947 in k6970 in k6936 in k6933 in a6930 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6950,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6889 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6894,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 624  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6892 in k6889 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6894,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6905,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6912,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6911 in k6892 in k6889 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6912,3,t0,t1,t2);}
/* walk1404 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6816(t3,t1,t2,((C_word*)t0)[2]);}

/* k6903 in k6892 in k6889 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6906,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],t1);}

/* f_6906 in k6903 in k6892 in k6889 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6906,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6873 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6875,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6860,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6866 in k6873 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6867,3,t0,t1,t2);}
/* walk1404 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6816(t3,t1,t2,((C_word*)t0)[2]);}

/* k6858 in k6873 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6861,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[227],((C_word*)t0)[2],t1);}

/* f_6861 in k6858 in k6873 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6861,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6837 in k6824 in k6821 in k6818 in walk in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 619  varnode */
t2=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k6806 in ##compiler#copy-node-tree-and-rename in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6810(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6810,NULL,3,t1,t2,t3);}
/* support.scm: 613  alist-ref */
t4=C_retrieve(lf[268]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[269]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6691,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6697,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 590  decompose-lambda-list */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6697,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6703,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6709,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6709,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[94]),((C_word*)t0)[2]);}
else{
t5=t4;
f_6713(2,t5,((C_word*)t0)[2]);}}

/* k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6716,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 596  copy-node-tree-and-rename */
t3=C_retrieve(lf[267]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_6716(2,t3,((C_word*)t0)[3]);}}

/* k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6721,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6742,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 602  last */
t5=C_retrieve(lf[248]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_6742(2,t4,t1);}}

/* k6794 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6796,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6766,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
/* support.scm: 604  qnode */
t4=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[266],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6780,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[232],t6,((C_word*)t0)[2]);}}

/* f_6780 in k6794 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6780,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6764 in k6794 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6766,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6758,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],t2);}

/* f_6758 in k6764 in k6794 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6758,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6740 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6746,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 608  take */
t3=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6744 in k6740 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 598  fold-right */
t2=C_retrieve(lf[264]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6720 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6721,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6734,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[93],t5,t6);}

/* f_6734 in a6720 in k6714 in k6711 in a6708 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6734,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* a6702 in a6696 in ##compiler#inline-lambda-bindings in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
/* support.scm: 593  split-at */
t2=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6637,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6643,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6643(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6643,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6669,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 586  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k6667 in fold in ##compiler#fold-boolean in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6673,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 587  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6643(t4,t2,t3);}

/* k6671 in k6667 in fold in ##compiler#fold-boolean in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6673,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6661,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[224],lf[261],t2);}

/* f_6661 in k6671 in k6667 in fold in ##compiler#fold-boolean in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6661,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6304,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6310,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6310(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6314,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6631,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_6631 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6631,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6626,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_6626 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6626,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6320,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6621,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_6621 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6621,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[214]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6329(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[258]);
t5=t3;
f_6329(t5,(C_truep(t4)?t4:(C_word)C_eqp(t1,lf[259])));}}

/* k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6329,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[247]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[209]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[213]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[83]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[83],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[93]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 560  butlast */
t10=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[222]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[117]:lf[222]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6444,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 567  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6310(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[234]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[225]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6477,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[215]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[253]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6501,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6501(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[254]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6563,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_6563(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[255]);
if(C_truep(t14)){
t15=t13;
f_6563(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[256]);
t16=t13;
f_6563(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[257])));}}}}}}}}}}}}}

/* k6561 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6563,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 577  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6310(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6593,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k6591 in k6561 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 578  append */
t2=*((C_word*)lf[58]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6587 in k6561 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6589,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6568 in k6561 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6574,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k6572 in k6568 in k6561 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 577  cons* */
t2=C_retrieve(lf[252]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6501(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6501,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6519,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 574  reverse */
t7=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6550,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 575  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6310(3,t10,t8,t9);}}

/* k6548 in loop in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 575  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6501(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6517 in loop in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 574  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6310(3,t4,t2,t3);}

/* k6525 in k6517 in loop in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[253],t3));}

/* k6475 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 569  cons* */
t2=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[225],((C_word*)t0)[2],t1);}

/* k6442 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6421 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6417 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 560  map */
t2=*((C_word*)lf[249]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[250]+1),((C_word*)t0)[2],t1);}

/* k6401 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6415,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 561  last */
t4=C_retrieve(lf[248]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6413 in k6401 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 561  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6310(3,t2,((C_word*)t0)[2],t1);}

/* k6409 in k6401 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* k6355 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6351 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6353,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[247],t2));}

/* k6334 in k6327 in k6318 in k6315 in k6312 in walk in ##compiler#build-expression-tree in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5700,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5703,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6299,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 544  walk */
t9=((C_word*)t6)[1];
f_5703(3,t9,t8,t2);}

/* k6297 in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6302,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 545  debugging */
t3=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[244],lf[245],((C_word*)((C_word*)t0)[2])[1]);}

/* k6300 in k6297 in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word *a;
loop:
a=C_alloc(77);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_5703,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 478  varnode */
t3=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 479  bomb */
t3=*((C_word*)lf[9]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[212],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[213]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5745,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[213],t7,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(t4,lf[214]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[215]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5773,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[83]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5798,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5801,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[219],C_retrieve(lf[220]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_5801(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_5801(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5801(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[93]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 499  walk */
t65=t1;
t66=t11;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5855,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 500  unzip1 */
t13=C_retrieve(lf[221]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[117]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[222]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5919,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 504  walk */
t65=t14;
t66=t15;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[223]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_5967(t17,(C_word)C_eqp(lf[83],t16));}
else{
t16=t15;
f_5967(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[224]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[225]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6004,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[226]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6031,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,lf[226],t17,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t4,lf[227]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[228]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6059,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[229]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6121,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 523  fifth */
t26=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[232]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6142,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6142(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[239]);
if(C_truep(t21)){
t22=t20;
f_6142(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[240]);
if(C_truep(t22)){
t23=t20;
f_6142(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[241]);
t24=t20;
f_6142(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[242])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6287,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6285 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6288,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[234],lf[243],t1);}

/* f_6288 in k6285 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6288,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6142,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6157,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[233]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6198 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6199,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6220,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[238])))){
t5=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_6220(t7,C_SCHEME_TRUE);}
else{
t5=t4;
f_6220(t5,C_SCHEME_FALSE);}}

/* k6218 in a6198 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_6220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6220,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 539  real-name */
t4=C_retrieve(lf[43]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm: 541  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6225 in k6218 in a6198 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6234(2,t3,t1);}
else{
/* support.scm: 540  ##sys#symbol->qualified-string */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6232 in k6225 in k6218 in a6198 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6234,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6224(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[236]),((C_word*)t0)[2],t1));}

/* k6222 in k6218 in a6198 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6224,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6211,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6209 in k6222 in k6218 in a6198 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6212,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[234],((C_word*)t0)[2],t1);}

/* f_6212 in k6209 in k6222 in k6218 in a6198 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6212,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* a6192 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
/* support.scm: 531  get-line-2 */
t2=C_retrieve(lf[144]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k6177 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6180,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[234],lf[235],t1);}

/* f_6180 in k6177 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6180,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6155 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6158,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6158 in k6155 in k6140 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6158,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6119 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6121,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6101,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6105,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 524  sixth */
t6=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6103 in k6119 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 524  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5703(3,t2,((C_word*)t0)[2],t1);}

/* k6099 in k6119 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6101,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6093,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[229],((C_word*)t0)[2],t2);}

/* f_6093 in k6099 in k6119 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6093,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6057 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6060,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[227],((C_word*)t0)[2],t1);}

/* f_6060 in k6057 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6060,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* f_6031 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6031,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k6002 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6005,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6005 in k6002 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6005,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k5965 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5967,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5951,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5949 in k5965 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5952,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_5952 in k5949 in k5965 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5952,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k5917 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5919,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5911,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[117],((C_word*)t0)[2],t2);}

/* f_5911 in k5917 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5911,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k5853 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5859,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5878,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5877 in k5853 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5878,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 501  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5703(3,t4,t1,t3);}

/* k5866 in k5853 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 502  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5703(3,t3,t2,((C_word*)t0)[2]);}

/* k5874 in k5866 in k5853 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5876,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 501  append */
t3=*((C_word*)lf[58]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5857 in k5853 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5860,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],t1);}

/* f_5860 in k5857 in k5853 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5860,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* k5799 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5801,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 490  compiler-warning */
t3=*((C_word*)lf[24]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[217],lf[218],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5798(t2,((C_word*)t0)[2]);}}

/* k5802 in k5799 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 493  truncate */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5809 in k5802 in k5799 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5798(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k5796 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 486  qnode */
t2=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5771 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5774,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* f_5774 in k5771 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5774,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* f_5745 in walk in ##compiler#build-node-graph in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5745,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* ##compiler#qnode in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5685,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5694,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[83],t3,C_SCHEME_END_OF_LIST);}

/* f_5694 in ##compiler#qnode in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5694,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* ##compiler#varnode in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5670,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5679,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[209],t3,C_SCHEME_END_OF_LIST);}

/* f_5679 in ##compiler#varnode in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5679,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* make-node in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5664,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* node-subexpressions in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5655,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5646,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[199]);
/* ##sys#block-set! */
t5=*((C_word*)lf[202]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5637,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5628,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[199]);
/* ##sys#block-set! */
t5=*((C_word*)lf[202]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5619,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5610,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[199]);
/* ##sys#block-set! */
t5=*((C_word*)lf[202]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5604,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[199]));}

/* f_5598 in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5598,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[199],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5168,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5172,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5172(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5596,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 414  append */
t5=*((C_word*)lf[58]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[195]),C_retrieve(lf[196]),C_retrieve(lf[197]));}}

/* k5594 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5172(t3,t2);}

/* k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5172,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 417  ##sys#hash-table-for-each */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5177,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5187,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t11,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 424  write */
t13=*((C_word*)lf[194]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}}

/* k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5297(t6,t2,((C_word*)t0)[2]);}

/* loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5297,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 428  caar */
t4=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5310,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[158]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_5323(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[178]);
if(C_truep(t5)){
t6=t4;
f_5323(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[179]);
if(C_truep(t6)){
t7=t4;
f_5323(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t7)){
t8=t4;
f_5323(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t8)){
t9=t4;
f_5323(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[133]);
if(C_truep(t9)){
t10=t4;
f_5323(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[127]);
if(C_truep(t10)){
t11=t4;
f_5323(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t11)){
t12=t4;
f_5323(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[132]);
if(C_truep(t12)){
t13=t4;
f_5323(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t13)){
t14=t4;
f_5323(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t14)){
t15=t4;
f_5323(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t15)){
t16=t4;
f_5323(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t16)){
t17=t4;
f_5323(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t17)){
t18=t4;
f_5323(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t18)){
t19=t4;
f_5323(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t19)){
t20=t4;
f_5323(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t20)){
t21=t4;
f_5323(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t21)){
t22=t4;
f_5323(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[128]);
if(C_truep(t22)){
t23=t4;
f_5323(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t23)){
t24=t4;
f_5323(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[124]);
t25=t4;
f_5323(t25,(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[193])));}}}}}}}}}}}}}}}}}}}}}

/* k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5323,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 432  caar */
t3=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[157]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[157]);
t4=((C_word*)t0)[8];
f_5310(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[162]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[157]);
if(C_truep(t4)){
t5=((C_word*)t0)[8];
f_5310(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5361,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 436  cdar */
t6=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[164]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5371,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 438  cdar */
t6=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[165]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5380(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[170]);
if(C_truep(t7)){
t8=t6;
f_5380(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[171]);
if(C_truep(t8)){
t9=t6;
f_5380(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[146]);
if(C_truep(t9)){
t10=t6;
f_5380(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[172]);
if(C_truep(t10)){
t11=t6;
f_5380(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[173]);
if(C_truep(t11)){
t12=t6;
f_5380(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[174]);
if(C_truep(t12)){
t13=t6;
f_5380(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t13)){
t14=t6;
f_5380(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[176]);
t15=t6;
f_5380(t15,(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[6],lf[177])));}}}}}}}}}}}}}

/* k5378 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5380,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5387,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 441  caar */
t3=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[167]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5401,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 443  cdar */
t4=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[168]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 445  cdar */
t5=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 446  bomb */
t5=*((C_word*)lf[9]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[169],t4);}}}}

/* k5409 in k5378 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5310(2,t3,t2);}

/* k5399 in k5378 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5310(2,t3,t2);}

/* k5385 in k5378 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5391,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 441  cdar */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5389 in k5385 in k5378 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 441  printf */
t2=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[166],((C_word*)t0)[2],t1);}

/* k5369 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5310(2,t3,t2);}

/* k5359 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5310(2,t3,t2);}

/* k5336 in k5321 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[159]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 432  printf */
t4=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[160],t3);}

/* k5308 in k5305 in loop in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 447  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5297(t3,((C_word*)t0)[2],t2);}

/* k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5193,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[157]);
t5=t3;
f_5225(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5225(t4,C_SCHEME_FALSE);}}

/* k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5225,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5246,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[157]);
t4=t2;
f_5256(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5256(t3,C_SCHEME_FALSE);}}}

/* k5254 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5256,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5277,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_5193(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5277 in k5254 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5277,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5265 in k5254 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5272,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5272 in k5265 in k5254 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5272,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5269 in k5265 in k5254 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 451  printf */
t3=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[156],t2);}

/* f_5246 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5246,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5234 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5240,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5241,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5241 in k5234 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5241,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5238 in k5234 in k5223 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 449  printf */
t3=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[155],t2);}

/* k5191 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 452  printf */
t4=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[154],t3);}
else{
t3=t2;
f_5196(2,t3,C_SCHEME_UNDEFINED);}}

/* k5194 in k5191 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 453  printf */
t4=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[153],t3);}
else{
t3=t2;
f_5199(2,t3,C_SCHEME_UNDEFINED);}}

/* k5197 in k5194 in k5191 in k5188 in k5185 in a5176 in k5170 in ##compiler#display-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 454  newline */
t2=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5155,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 396  ##sys#hash-table-for-each */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[143]));}

/* a5154 in ##compiler#display-line-number-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5155,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5166,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[150]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5164 in a5154 in ##compiler#display-line-number-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 398  printf */
t2=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[148],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5125,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5131,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5131(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5131,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5141,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 392  get */
t5=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[146]);}}

/* k5139 in loop in ##compiler#find-lambda-container in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 393  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5131(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5089,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5096,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 384  ##sys#hash-table-ref */
t5=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[143]),t3);}

/* k5094 in ##compiler#get-line-2 in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5099(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5099(t3,C_SCHEME_FALSE);}}

/* k5097 in k5094 in ##compiler#get-line-2 in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_5099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 386  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 387  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5079,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 380  get */
t4=C_retrieve(lf[135]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[143]),t3,t2);}

/* ##compiler#count! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5022r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5022r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5022r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5026,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 368  ##sys#hash-table-ref */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k5024 in ##compiler#count! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5026,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5056,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 373  alist-cons */
t7=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 374  ##sys#hash-table-set! */
t6=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5054 in k5024 in ##compiler#count! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4970,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4974,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 360  ##sys#hash-table-ref */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k4972 in ##compiler#collect! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5001,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 364  alist-cons */
t6=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 365  ##sys#hash-table-set! */
t4=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k4999 in k4972 in ##compiler#collect! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4924,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4928,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 352  ##sys#hash-table-ref */
t7=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k4926 in ##compiler#put! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4928,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4950,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 356  alist-cons */
t5=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 357  ##sys#hash-table-set! */
t4=C_retrieve(lf[139]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k4948 in k4926 in ##compiler#put! in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4906r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4906r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4906r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4910,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 346  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k4908 in ##compiler#get-all in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 348  filter-map */
t3=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a4917 in k4908 in ##compiler#get-all in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4918,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4888,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4892,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 340  ##sys#hash-table-ref */
t6=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k4890 in ##compiler#get in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4827,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4831,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4864,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[134]));}

/* a4863 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4864,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 326  put! */
t4=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[133],C_SCHEME_TRUE);}

/* k4866 in a4863 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[131])))){
/* support.scm: 327  put! */
t3=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[132],C_SCHEME_TRUE);}
else{
t3=t2;
f_4871(2,t3,C_SCHEME_UNDEFINED);}}

/* k4869 in k4866 in a4863 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[130])))){
/* support.scm: 328  put! */
t2=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[127],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4829 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[129]));}

/* a4848 in k4829 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4849,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 332  put! */
t4=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[128],C_SCHEME_TRUE);}

/* k4851 in a4848 in k4829 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[126])))){
/* support.scm: 333  put! */
t2=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[127],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4832 in k4829 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[125]));}

/* a4838 in k4832 in k4829 in ##compiler#initialize-analysis-database in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4839,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 336  put! */
t4=C_retrieve(lf[123]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t3,lf[124],C_SCHEME_TRUE);}

/* ##compiler#expand-profile-lambda in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4686,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[113]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4690,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 308  gensym */
t7=C_retrieve(lf[94]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k4688 in ##compiler#expand-profile-lambda in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 309  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[114]));}

/* k4692 in k4688 in ##compiler#expand-profile-lambda in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[113]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[115]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[116],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[117],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[117],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[118],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[117],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[83],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[115]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[119],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[117],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[120],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[117],t35));}

/* ##compiler#process-lambda-documentation in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4683,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4576,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4583,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[108]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4585,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4591,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4616,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4669 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4670r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4670r(t0,t1,t2);}}

static void C_ccall f_4670r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4676,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k562568 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4675 in a4669 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4676,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4621 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4626,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4654,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 293  with-input-from-string */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a4653 in a4621 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4660,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4668,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 293  read */
t4=*((C_word*)lf[102]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4666 in a4653 in a4621 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 293  unfold */
t2=C_retrieve(lf[103]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[104]+1),*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* a4659 in a4653 in a4621 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4660,3,t0,t1,t2);}
/* support.scm: 293  read */
t3=*((C_word*)lf[102]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k4624 in a4621 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[99]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4646 in k4624 in a4621 in a4615 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[100],t1));}

/* a4590 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4591,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k562568 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4596 in a4590 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 290  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4606 in a4596 in a4590 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 291  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 292  ->string */
t2=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4603 in a4596 in a4590 in a4584 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 288  quit */
t2=*((C_word*)lf[29]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[98],((C_word*)t0)[2],t1);}

/* k4581 in ##compiler#string->expr in k4573 in k4570 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4475,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4481,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4481(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4481,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[91]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[92]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4509,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4509(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4558,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 277  constant? */
t8=*((C_word*)lf[82]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k4556 in loop in ##compiler#canonicalize-begin-body in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4509(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[96])));}

/* k4507 in loop in ##compiler#canonicalize-begin-body in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4509,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 279  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4481(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 280  gensym */
t3=C_retrieve(lf[94]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[95]);}}

/* k4545 in k4507 in loop in ##compiler#canonicalize-begin-body in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4547,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 281  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4481(t8,t6,t7);}

/* k4533 in k4545 in k4507 in loop in ##compiler#canonicalize-begin-body in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* ##compiler#basic-literal? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4415,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4431,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 262  constant? */
t6=*((C_word*)lf[82]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}

/* k4429 in ##compiler#basic-literal? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4431,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4473,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 263  vector->list */
t4=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4437(2,t3,C_SCHEME_FALSE);}}}

/* k4471 in k4429 in ##compiler#basic-literal? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 263  every */
t2=C_retrieve(lf[88]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[87]+1),t1);}

/* k4435 in k4429 in ##compiler#basic-literal? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 265  basic-literal? */
t4=*((C_word*)lf[87]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4450 in k4435 in k4429 in ##compiler#basic-literal? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 266  basic-literal? */
t3=*((C_word*)lf[87]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4369,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4373,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4413,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 252  big-fixnum? */
t5=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t3;
f_4373(t4,C_SCHEME_FALSE);}}

/* k4411 in ##compiler#immediate? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4373(t2,(C_word)C_i_not(t1));}

/* k4371 in ##compiler#immediate? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4339,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4293,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[83],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#follow-without-loop in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4262,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4268,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4268(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4268,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 230  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 231  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4282 in loop in ##compiler#follow-without-loop in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4283,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 231  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4268(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4199,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4213,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 220  reverse */
t6=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k4211 in ##compiler#fold-inner in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4215,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4215(t5,((C_word*)t0)[2],t1);}

/* fold in k4211 in ##compiler#fold-inner in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4215,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4223(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4244,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 225  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4242 in fold in k4211 in ##compiler#fold-inner in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4223(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4221 in fold in k4211 in ##compiler#fold-inner in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4187,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[77]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 215  close-input-port */
t4=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4140r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4140r(t0,t1,t2,t3);}}

static void C_ccall f_4140r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[70]))){
/* support.scm: 209  current-input-port */
t4=*((C_word*)lf[71]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4156,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 210  file-exists? */
t5=C_retrieve(lf[75]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k4154 in ##compiler#check-and-open-input-file in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 210  open-input-file */
t2=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4168(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4168(t5,(C_word)C_i_not(t4));}}}

/* k4166 in k4154 in ##compiler#check-and-open-input-file in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4168(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 211  quit */
t2=*((C_word*)lf[29]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[73],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 212  quit */
t3=*((C_word*)lf[29]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[74],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4133,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub327(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4126,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub322(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4070,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4074,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 190  ->string */
t5=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4122 in ##compiler#valid-c-identifier? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[60]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4072 in ##compiler#valid-c-identifier? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4097,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 194  any */
t7=C_retrieve(lf[65]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4096 in k4072 in ##compiler#valid-c-identifier? in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4097,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3988,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3992,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[60]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3994,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3994(t5,((C_word*)t0)[2],t1);}

/* loop in k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_3994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3994,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[57]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4016,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4016(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4016(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[63])));}}}

/* k4014 in loop in k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4023(t3,lf[61]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4023(t4,(C_truep(t3)?lf[62]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3994(t4,t2,t3);}}

/* k4053 in k4014 in loop in k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4021 in k4014 in loop in k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_4023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4023,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 185  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4037 in k4021 in k4014 in loop in k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[60]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4025 in k4021 in k4014 in loop in k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4031,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 186  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3994(t4,t2,t3);}

/* k4029 in k4025 in k4021 in k4014 in loop in k3990 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 181  append */
t2=*((C_word*)lf[58]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[59],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3986 in ##compiler#c-ify-string in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3932,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3938,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3938(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_3938(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3938,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3962,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 167  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k3960 in loop in ##compiler#build-lambda-list in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3907,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 161  string->symbol */
t3=*((C_word*)lf[50]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3930,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 162  sprintf */
t4=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[51],t2);}}}

/* k3928 in ##compiler#symbolify in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 162  string->symbol */
t2=*((C_word*)lf[50]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3886,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 156  symbol->string */
t3=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
/* support.scm: 157  sprintf */
t3=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[48],t2);}}}

/* ##compiler#posq in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3850,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3856(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static C_word C_fcall f_3856(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3782,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3785,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3806(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_3806(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3806,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 140  err */
t4=((C_word*)t0)[3];
f_3785(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 142  err */
t5=((C_word*)t0)[3];
f_3785(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 143  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_3785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3785,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 137  real-name */
t3=C_retrieve(lf[43]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3791 in err in ##compiler#check-signature in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3797,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 138  map-llist */
t4=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[43]),t3);}

/* k3795 in k3791 in err in ##compiler#check-signature in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 136  quit */
t2=*((C_word*)lf[29]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t1);}

/* map-llist in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3739,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3745,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3745(t7,t1,t3);}

/* loop in map-llist in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_3745(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3745,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 131  proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 132  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k3766 in loop in map-llist in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3772,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 132  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3745(t4,t2,t3);}

/* k3770 in k3766 in loop in map-llist in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3772,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3736,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[34])));}

/* ##sys#syntax-error-hook in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3711r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3711r(t0,t1,t2,t3);}}

static void C_ccall f_3711r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3715,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 117  current-error-port */
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3713 in ##sys#syntax-error-hook in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 118  fprintf */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[37],((C_word*)t0)[2]);}

/* k3716 in k3713 in ##sys#syntax-error-hook in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3729,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3728 in k3716 in k3713 in ##sys#syntax-error-hook in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3729,3,t0,t1,t2);}
/* fprintf */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],lf[36],t2);}

/* k3719 in k3716 in k3713 in ##sys#syntax-error-hook in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 120  print-call-chain */
t3=C_retrieve(lf[33]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[34]),lf[35]);}

/* k3722 in k3719 in k3716 in k3713 in ##sys#syntax-error-hook in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 121  exit */
t2=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3692r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3692r(t0,t1,t2,t3);}}

static void C_ccall f_3692r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3696,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 110  current-error-port */
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3694 in quit in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3699,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 111  string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[31],((C_word*)t0)[2]);}

/* k3707 in k3694 in quit in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[25]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3697 in k3694 in quit in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 112  newline */
t3=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3700 in k3697 in k3694 in quit in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 113  exit */
t2=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3663r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3663r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3663r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3670,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[28]))){
t6=(C_word)C_i_memq(t2,*((C_word*)lf[8]+1));
t7=t5;
f_3670(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3670(t6,C_SCHEME_FALSE);}}

/* k3668 in ##compiler#compiler-warning in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_fcall f_3670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3670,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 105  current-error-port */
t3=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3671 in k3668 in ##compiler#compiler-warning in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3676,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 106  string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[26],((C_word*)t0)[2]);}

/* k3681 in k3671 in k3668 in ##compiler#compiler-warning in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[25]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3674 in k3671 in k3668 in ##compiler#compiler-warning in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 107  newline */
t2=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3623r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3623r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,*((C_word*)lf[7]+1)))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3633,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 94   printf */
t6=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[23],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3631 in ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3648,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 97   display */
t4=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[22]);}
else{
t3=t2;
f_3636(2,t3,C_SCHEME_UNDEFINED);}}

/* k3646 in k3631 in ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3653,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3652 in k3646 in k3631 in ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3653,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3661,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 98   force */
t4=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3659 in a3652 in k3646 in k3631 in ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 98   printf */
t2=C_retrieve(lf[17]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[18],t1);}

/* k3634 in k3631 in ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3639,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 99   newline */
t3=*((C_word*)lf[16]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3637 in k3634 in k3631 in ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 100  flush-output */
t3=*((C_word*)lf[15]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3640 in k3637 in k3634 in k3631 in ##compiler#debugging in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3596r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3596r(t0,t1,t2);}}

static void C_ccall f_3596r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3610,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 88   string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[12],t4);}
else{
/* support.scm: 89   error */
t3=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[13]);}}

/* k3608 in ##compiler#bomb in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[10]+1),t1,t2);}

/* f_3591 in k3585 in k3582 in k3579 in k3576 in k3573 in k3570 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3591,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[609] = {
{"toplevelsupport.scm",(void*)C_support_toplevel},
{"f_3572support.scm",(void*)f_3572},
{"f_3575support.scm",(void*)f_3575},
{"f_3578support.scm",(void*)f_3578},
{"f_3581support.scm",(void*)f_3581},
{"f_3584support.scm",(void*)f_3584},
{"f_3587support.scm",(void*)f_3587},
{"f_4572support.scm",(void*)f_4572},
{"f_4575support.scm",(void*)f_4575},
{"f_11014support.scm",(void*)f_11014},
{"f_10985support.scm",(void*)f_10985},
{"f_11012support.scm",(void*)f_11012},
{"f_10996support.scm",(void*)f_10996},
{"f_10999support.scm",(void*)f_10999},
{"f_11001support.scm",(void*)f_11001},
{"f_11005support.scm",(void*)f_11005},
{"f_10989support.scm",(void*)f_10989},
{"f_10922support.scm",(void*)f_10922},
{"f_10959support.scm",(void*)f_10959},
{"f_10983support.scm",(void*)f_10983},
{"f_10969support.scm",(void*)f_10969},
{"f_10973support.scm",(void*)f_10973},
{"f_10944support.scm",(void*)f_10944},
{"f_10952support.scm",(void*)f_10952},
{"f_10853support.scm",(void*)f_10853},
{"f_10857support.scm",(void*)f_10857},
{"f_10862support.scm",(void*)f_10862},
{"f_10866support.scm",(void*)f_10866},
{"f_10917support.scm",(void*)f_10917},
{"f_10896support.scm",(void*)f_10896},
{"f_10908support.scm",(void*)f_10908},
{"f_10911support.scm",(void*)f_10911},
{"f_10884support.scm",(void*)f_10884},
{"f_10820support.scm",(void*)f_10820},
{"f_10830support.scm",(void*)f_10830},
{"f_10833support.scm",(void*)f_10833},
{"f_10718support.scm",(void*)f_10718},
{"f_10727support.scm",(void*)f_10727},
{"f_10814support.scm",(void*)f_10814},
{"f_10731support.scm",(void*)f_10731},
{"f_10809support.scm",(void*)f_10809},
{"f_10734support.scm",(void*)f_10734},
{"f_10804support.scm",(void*)f_10804},
{"f_10737support.scm",(void*)f_10737},
{"f_10740support.scm",(void*)f_10740},
{"f_10746support.scm",(void*)f_10746},
{"f_10799support.scm",(void*)f_10799},
{"f_10749support.scm",(void*)f_10749},
{"f_10764support.scm",(void*)f_10764},
{"f_10772support.scm",(void*)f_10772},
{"f_10782support.scm",(void*)f_10782},
{"f_10767support.scm",(void*)f_10767},
{"f_10755support.scm",(void*)f_10755},
{"f_10722support.scm",(void*)f_10722},
{"f_10712support.scm",(void*)f_10712},
{"f_10666support.scm",(void*)f_10666},
{"f_10685support.scm",(void*)f_10685},
{"f_10696support.scm",(void*)f_10696},
{"f_10692support.scm",(void*)f_10692},
{"f_10654support.scm",(void*)f_10654},
{"f_10660support.scm",(void*)f_10660},
{"f_10642support.scm",(void*)f_10642},
{"f_10646support.scm",(void*)f_10646},
{"f_10563support.scm",(void*)f_10563},
{"f_10582support.scm",(void*)f_10582},
{"f_10607support.scm",(void*)f_10607},
{"f_10611support.scm",(void*)f_10611},
{"f_10613support.scm",(void*)f_10613},
{"f_10620support.scm",(void*)f_10620},
{"f_10633support.scm",(void*)f_10633},
{"f_10637support.scm",(void*)f_10637},
{"f_10566support.scm",(void*)f_10566},
{"f_10570support.scm",(void*)f_10570},
{"f_10576support.scm",(void*)f_10576},
{"f_10557support.scm",(void*)f_10557},
{"f_10513support.scm",(void*)f_10513},
{"f_10525support.scm",(void*)f_10525},
{"f_10529support.scm",(void*)f_10529},
{"f_10533support.scm",(void*)f_10533},
{"f_10521support.scm",(void*)f_10521},
{"f_10504support.scm",(void*)f_10504},
{"f_10498support.scm",(void*)f_10498},
{"f_10492support.scm",(void*)f_10492},
{"f_10480support.scm",(void*)f_10480},
{"f_10484support.scm",(void*)f_10484},
{"f_10487support.scm",(void*)f_10487},
{"f_10442support.scm",(void*)f_10442},
{"f_10446support.scm",(void*)f_10446},
{"f_10449support.scm",(void*)f_10449},
{"f_10456support.scm",(void*)f_10456},
{"f_10400support.scm",(void*)f_10400},
{"f_10409support.scm",(void*)f_10409},
{"f_10371support.scm",(void*)f_10371},
{"f_10381support.scm",(void*)f_10381},
{"f_10174support.scm",(void*)f_10174},
{"f_10353support.scm",(void*)f_10353},
{"f_10302support.scm",(void*)f_10302},
{"f_10347support.scm",(void*)f_10347},
{"f_10351support.scm",(void*)f_10351},
{"f_10305support.scm",(void*)f_10305},
{"f_10310support.scm",(void*)f_10310},
{"f_10314support.scm",(void*)f_10314},
{"f_10308support.scm",(void*)f_10308},
{"f_10265support.scm",(void*)f_10265},
{"f_10269support.scm",(void*)f_10269},
{"f_10278support.scm",(void*)f_10278},
{"f_10282support.scm",(void*)f_10282},
{"f_10272support.scm",(void*)f_10272},
{"f_10230support.scm",(void*)f_10230},
{"f_10236support.scm",(void*)f_10236},
{"f_10263support.scm",(void*)f_10263},
{"f_10249support.scm",(void*)f_10249},
{"f_10183support.scm",(void*)f_10183},
{"f_10189support.scm",(void*)f_10189},
{"f_10228support.scm",(void*)f_10228},
{"f_10210support.scm",(void*)f_10210},
{"f_10000support.scm",(void*)f_10000},
{"f_10172support.scm",(void*)f_10172},
{"f_10159support.scm",(void*)f_10159},
{"f_10165support.scm",(void*)f_10165},
{"f_10003support.scm",(void*)f_10003},
{"f_10153support.scm",(void*)f_10153},
{"f_10007support.scm",(void*)f_10007},
{"f_10148support.scm",(void*)f_10148},
{"f_10010support.scm",(void*)f_10010},
{"f_10143support.scm",(void*)f_10143},
{"f_10013support.scm",(void*)f_10013},
{"f_10022support.scm",(void*)f_10022},
{"f_10106support.scm",(void*)f_10106},
{"f_10118support.scm",(void*)f_10118},
{"f_10076support.scm",(void*)f_10076},
{"f_10087support.scm",(void*)f_10087},
{"f_10067support.scm",(void*)f_10067},
{"f_10053support.scm",(void*)f_10053},
{"f_10041support.scm",(void*)f_10041},
{"f_9907support.scm",(void*)f_9907},
{"f_9913support.scm",(void*)f_9913},
{"f_9994support.scm",(void*)f_9994},
{"f_9917support.scm",(void*)f_9917},
{"f_9989support.scm",(void*)f_9989},
{"f_9920support.scm",(void*)f_9920},
{"f_9973support.scm",(void*)f_9973},
{"f_9960support.scm",(void*)f_9960},
{"f_9959support.scm",(void*)f_9959},
{"f_9941support.scm",(void*)f_9941},
{"f_9935support.scm",(void*)f_9935},
{"f_9911support.scm",(void*)f_9911},
{"f_9615support.scm",(void*)f_9615},
{"f_9811support.scm",(void*)f_9811},
{"f_9832support.scm",(void*)f_9832},
{"f_9305support.scm",(void*)f_9305},
{"f_9609support.scm",(void*)f_9609},
{"f_9317support.scm",(void*)f_9317},
{"f_9327support.scm",(void*)f_9327},
{"f_9345support.scm",(void*)f_9345},
{"f_9379support.scm",(void*)f_9379},
{"f_9308support.scm",(void*)f_9308},
{"f_8986support.scm",(void*)f_8986},
{"f_9299support.scm",(void*)f_9299},
{"f_8992support.scm",(void*)f_8992},
{"f_9002support.scm",(void*)f_9002},
{"f_9011support.scm",(void*)f_9011},
{"f_9023support.scm",(void*)f_9023},
{"f_9035support.scm",(void*)f_9035},
{"f_9041support.scm",(void*)f_9041},
{"f_9075support.scm",(void*)f_9075},
{"f_8946support.scm",(void*)f_8946},
{"f_8980support.scm",(void*)f_8980},
{"f_8952support.scm",(void*)f_8952},
{"f_8956support.scm",(void*)f_8956},
{"f_8915support.scm",(void*)f_8915},
{"f_8928support.scm",(void*)f_8928},
{"f_8919support.scm",(void*)f_8919},
{"f_8884support.scm",(void*)f_8884},
{"f_8897support.scm",(void*)f_8897},
{"f_8888support.scm",(void*)f_8888},
{"f_7837support.scm",(void*)f_7837},
{"f_8878support.scm",(void*)f_8878},
{"f_7843support.scm",(void*)f_7843},
{"f_7849support.scm",(void*)f_7849},
{"f_7878support.scm",(void*)f_7878},
{"f_7897support.scm",(void*)f_7897},
{"f_7916support.scm",(void*)f_7916},
{"f_7986support.scm",(void*)f_7986},
{"f_8005support.scm",(void*)f_8005},
{"f_8087support.scm",(void*)f_8087},
{"f_8126support.scm",(void*)f_8126},
{"f_8145support.scm",(void*)f_8145},
{"f_8164support.scm",(void*)f_8164},
{"f_8244support.scm",(void*)f_8244},
{"f_8329support.scm",(void*)f_8329},
{"f_8404support.scm",(void*)f_8404},
{"f_8438support.scm",(void*)f_8438},
{"f_8508support.scm",(void*)f_8508},
{"f_8441support.scm",(void*)f_8441},
{"f_8247support.scm",(void*)f_8247},
{"f_8278support.scm",(void*)f_8278},
{"f_8167support.scm",(void*)f_8167},
{"f_8008support.scm",(void*)f_8008},
{"f_8039support.scm",(void*)f_8039},
{"f_7919support.scm",(void*)f_7919},
{"f_7950support.scm",(void*)f_7950},
{"f_7801support.scm",(void*)f_7801},
{"f_7805support.scm",(void*)f_7805},
{"f_7816support.scm",(void*)f_7816},
{"f_7822support.scm",(void*)f_7822},
{"f_7826support.scm",(void*)f_7826},
{"f_7808support.scm",(void*)f_7808},
{"f_7762support.scm",(void*)f_7762},
{"f_7774support.scm",(void*)f_7774},
{"f_7781support.scm",(void*)f_7781},
{"f_7784support.scm",(void*)f_7784},
{"f_7787support.scm",(void*)f_7787},
{"f_7790support.scm",(void*)f_7790},
{"f_7793support.scm",(void*)f_7793},
{"f_7796support.scm",(void*)f_7796},
{"f_7768support.scm",(void*)f_7768},
{"f_7676support.scm",(void*)f_7676},
{"f_7685support.scm",(void*)f_7685},
{"f_7691support.scm",(void*)f_7691},
{"f_7738support.scm",(void*)f_7738},
{"f_7733support.scm",(void*)f_7733},
{"f_7680support.scm",(void*)f_7680},
{"f_7654support.scm",(void*)f_7654},
{"f_7664support.scm",(void*)f_7664},
{"f_7610support.scm",(void*)f_7610},
{"f_7628support.scm",(void*)f_7628},
{"f_7639support.scm",(void*)f_7639},
{"f_7632support.scm",(void*)f_7632},
{"f_7636support.scm",(void*)f_7636},
{"f_7617support.scm",(void*)f_7617},
{"f_7622support.scm",(void*)f_7622},
{"f_7579support.scm",(void*)f_7579},
{"f_7585support.scm",(void*)f_7585},
{"f_7592support.scm",(void*)f_7592},
{"f_7595support.scm",(void*)f_7595},
{"f_7457support.scm",(void*)f_7457},
{"f_7573support.scm",(void*)f_7573},
{"f_7461support.scm",(void*)f_7461},
{"f_7481support.scm",(void*)f_7481},
{"f_7562support.scm",(void*)f_7562},
{"f_7485support.scm",(void*)f_7485},
{"f_7557support.scm",(void*)f_7557},
{"f_7556support.scm",(void*)f_7556},
{"f_7539support.scm",(void*)f_7539},
{"f_7494support.scm",(void*)f_7494},
{"f_7534support.scm",(void*)f_7534},
{"f_7533support.scm",(void*)f_7533},
{"f_7525support.scm",(void*)f_7525},
{"f_7524support.scm",(void*)f_7524},
{"f_7356support.scm",(void*)f_7356},
{"f_7362support.scm",(void*)f_7362},
{"f_7451support.scm",(void*)f_7451},
{"f_7366support.scm",(void*)f_7366},
{"f_7446support.scm",(void*)f_7446},
{"f_7369support.scm",(void*)f_7369},
{"f_7378support.scm",(void*)f_7378},
{"f_7405support.scm",(void*)f_7405},
{"f_7404support.scm",(void*)f_7404},
{"f_7392support.scm",(void*)f_7392},
{"f_7400support.scm",(void*)f_7400},
{"f_7136support.scm",(void*)f_7136},
{"f_7330support.scm",(void*)f_7330},
{"f_7350support.scm",(void*)f_7350},
{"f_7340support.scm",(void*)f_7340},
{"f_7345support.scm",(void*)f_7345},
{"f_7344support.scm",(void*)f_7344},
{"f_7336support.scm",(void*)f_7336},
{"f_7211support.scm",(void*)f_7211},
{"f_7323support.scm",(void*)f_7323},
{"f_7318support.scm",(void*)f_7318},
{"f_7310support.scm",(void*)f_7310},
{"f_7305support.scm",(void*)f_7305},
{"f_7233support.scm",(void*)f_7233},
{"f_7297support.scm",(void*)f_7297},
{"f_7240support.scm",(void*)f_7240},
{"f_7246support.scm",(void*)f_7246},
{"f_7277support.scm",(void*)f_7277},
{"f_7168support.scm",(void*)f_7168},
{"f_7190support.scm",(void*)f_7190},
{"f_7139support.scm",(void*)f_7139},
{"f_7163support.scm",(void*)f_7163},
{"f_7059support.scm",(void*)f_7059},
{"f_7130support.scm",(void*)f_7130},
{"f_7129support.scm",(void*)f_7129},
{"f_7063support.scm",(void*)f_7063},
{"f_7121support.scm",(void*)f_7121},
{"f_7120support.scm",(void*)f_7120},
{"f_7066support.scm",(void*)f_7066},
{"f_7112support.scm",(void*)f_7112},
{"f_7111support.scm",(void*)f_7111},
{"f_7069support.scm",(void*)f_7069},
{"f_7080support.scm",(void*)f_7080},
{"f_7025support.scm",(void*)f_7025},
{"f_7031support.scm",(void*)f_7031},
{"f_7045support.scm",(void*)f_7045},
{"f_7049support.scm",(void*)f_7049},
{"f_6804support.scm",(void*)f_6804},
{"f_6808support.scm",(void*)f_6808},
{"f_6816support.scm",(void*)f_6816},
{"f_7016support.scm",(void*)f_7016},
{"f_6820support.scm",(void*)f_6820},
{"f_7011support.scm",(void*)f_7011},
{"f_6823support.scm",(void*)f_6823},
{"f_7006support.scm",(void*)f_7006},
{"f_6826support.scm",(void*)f_6826},
{"f_6990support.scm",(void*)f_6990},
{"f_7001support.scm",(void*)f_7001},
{"f_6994support.scm",(void*)f_6994},
{"f_6995support.scm",(void*)f_6995},
{"f_6931support.scm",(void*)f_6931},
{"f_6935support.scm",(void*)f_6935},
{"f_6938support.scm",(void*)f_6938},
{"f_6980support.scm",(void*)f_6980},
{"f_6972support.scm",(void*)f_6972},
{"f_6956support.scm",(void*)f_6956},
{"f_6949support.scm",(void*)f_6949},
{"f_6950support.scm",(void*)f_6950},
{"f_6891support.scm",(void*)f_6891},
{"f_6894support.scm",(void*)f_6894},
{"f_6912support.scm",(void*)f_6912},
{"f_6905support.scm",(void*)f_6905},
{"f_6906support.scm",(void*)f_6906},
{"f_6875support.scm",(void*)f_6875},
{"f_6867support.scm",(void*)f_6867},
{"f_6860support.scm",(void*)f_6860},
{"f_6861support.scm",(void*)f_6861},
{"f_6839support.scm",(void*)f_6839},
{"f_6810support.scm",(void*)f_6810},
{"f_6691support.scm",(void*)f_6691},
{"f_6697support.scm",(void*)f_6697},
{"f_6709support.scm",(void*)f_6709},
{"f_6713support.scm",(void*)f_6713},
{"f_6716support.scm",(void*)f_6716},
{"f_6796support.scm",(void*)f_6796},
{"f_6780support.scm",(void*)f_6780},
{"f_6766support.scm",(void*)f_6766},
{"f_6758support.scm",(void*)f_6758},
{"f_6742support.scm",(void*)f_6742},
{"f_6746support.scm",(void*)f_6746},
{"f_6721support.scm",(void*)f_6721},
{"f_6734support.scm",(void*)f_6734},
{"f_6703support.scm",(void*)f_6703},
{"f_6637support.scm",(void*)f_6637},
{"f_6643support.scm",(void*)f_6643},
{"f_6669support.scm",(void*)f_6669},
{"f_6673support.scm",(void*)f_6673},
{"f_6661support.scm",(void*)f_6661},
{"f_6304support.scm",(void*)f_6304},
{"f_6310support.scm",(void*)f_6310},
{"f_6631support.scm",(void*)f_6631},
{"f_6314support.scm",(void*)f_6314},
{"f_6626support.scm",(void*)f_6626},
{"f_6317support.scm",(void*)f_6317},
{"f_6621support.scm",(void*)f_6621},
{"f_6320support.scm",(void*)f_6320},
{"f_6329support.scm",(void*)f_6329},
{"f_6563support.scm",(void*)f_6563},
{"f_6593support.scm",(void*)f_6593},
{"f_6589support.scm",(void*)f_6589},
{"f_6570support.scm",(void*)f_6570},
{"f_6574support.scm",(void*)f_6574},
{"f_6501support.scm",(void*)f_6501},
{"f_6550support.scm",(void*)f_6550},
{"f_6519support.scm",(void*)f_6519},
{"f_6527support.scm",(void*)f_6527},
{"f_6477support.scm",(void*)f_6477},
{"f_6444support.scm",(void*)f_6444},
{"f_6423support.scm",(void*)f_6423},
{"f_6419support.scm",(void*)f_6419},
{"f_6403support.scm",(void*)f_6403},
{"f_6415support.scm",(void*)f_6415},
{"f_6411support.scm",(void*)f_6411},
{"f_6357support.scm",(void*)f_6357},
{"f_6353support.scm",(void*)f_6353},
{"f_6336support.scm",(void*)f_6336},
{"f_5700support.scm",(void*)f_5700},
{"f_6299support.scm",(void*)f_6299},
{"f_6302support.scm",(void*)f_6302},
{"f_5703support.scm",(void*)f_5703},
{"f_6287support.scm",(void*)f_6287},
{"f_6288support.scm",(void*)f_6288},
{"f_6142support.scm",(void*)f_6142},
{"f_6199support.scm",(void*)f_6199},
{"f_6220support.scm",(void*)f_6220},
{"f_6227support.scm",(void*)f_6227},
{"f_6234support.scm",(void*)f_6234},
{"f_6224support.scm",(void*)f_6224},
{"f_6211support.scm",(void*)f_6211},
{"f_6212support.scm",(void*)f_6212},
{"f_6193support.scm",(void*)f_6193},
{"f_6179support.scm",(void*)f_6179},
{"f_6180support.scm",(void*)f_6180},
{"f_6157support.scm",(void*)f_6157},
{"f_6158support.scm",(void*)f_6158},
{"f_6121support.scm",(void*)f_6121},
{"f_6105support.scm",(void*)f_6105},
{"f_6101support.scm",(void*)f_6101},
{"f_6093support.scm",(void*)f_6093},
{"f_6059support.scm",(void*)f_6059},
{"f_6060support.scm",(void*)f_6060},
{"f_6031support.scm",(void*)f_6031},
{"f_6004support.scm",(void*)f_6004},
{"f_6005support.scm",(void*)f_6005},
{"f_5967support.scm",(void*)f_5967},
{"f_5951support.scm",(void*)f_5951},
{"f_5952support.scm",(void*)f_5952},
{"f_5919support.scm",(void*)f_5919},
{"f_5911support.scm",(void*)f_5911},
{"f_5855support.scm",(void*)f_5855},
{"f_5878support.scm",(void*)f_5878},
{"f_5868support.scm",(void*)f_5868},
{"f_5876support.scm",(void*)f_5876},
{"f_5859support.scm",(void*)f_5859},
{"f_5860support.scm",(void*)f_5860},
{"f_5801support.scm",(void*)f_5801},
{"f_5804support.scm",(void*)f_5804},
{"f_5811support.scm",(void*)f_5811},
{"f_5798support.scm",(void*)f_5798},
{"f_5773support.scm",(void*)f_5773},
{"f_5774support.scm",(void*)f_5774},
{"f_5745support.scm",(void*)f_5745},
{"f_5685support.scm",(void*)f_5685},
{"f_5694support.scm",(void*)f_5694},
{"f_5670support.scm",(void*)f_5670},
{"f_5679support.scm",(void*)f_5679},
{"f_5664support.scm",(void*)f_5664},
{"f_5655support.scm",(void*)f_5655},
{"f_5646support.scm",(void*)f_5646},
{"f_5637support.scm",(void*)f_5637},
{"f_5628support.scm",(void*)f_5628},
{"f_5619support.scm",(void*)f_5619},
{"f_5610support.scm",(void*)f_5610},
{"f_5604support.scm",(void*)f_5604},
{"f_5598support.scm",(void*)f_5598},
{"f_5168support.scm",(void*)f_5168},
{"f_5596support.scm",(void*)f_5596},
{"f_5172support.scm",(void*)f_5172},
{"f_5177support.scm",(void*)f_5177},
{"f_5187support.scm",(void*)f_5187},
{"f_5297support.scm",(void*)f_5297},
{"f_5307support.scm",(void*)f_5307},
{"f_5323support.scm",(void*)f_5323},
{"f_5380support.scm",(void*)f_5380},
{"f_5411support.scm",(void*)f_5411},
{"f_5401support.scm",(void*)f_5401},
{"f_5387support.scm",(void*)f_5387},
{"f_5391support.scm",(void*)f_5391},
{"f_5371support.scm",(void*)f_5371},
{"f_5361support.scm",(void*)f_5361},
{"f_5338support.scm",(void*)f_5338},
{"f_5310support.scm",(void*)f_5310},
{"f_5190support.scm",(void*)f_5190},
{"f_5225support.scm",(void*)f_5225},
{"f_5256support.scm",(void*)f_5256},
{"f_5277support.scm",(void*)f_5277},
{"f_5267support.scm",(void*)f_5267},
{"f_5272support.scm",(void*)f_5272},
{"f_5271support.scm",(void*)f_5271},
{"f_5246support.scm",(void*)f_5246},
{"f_5236support.scm",(void*)f_5236},
{"f_5241support.scm",(void*)f_5241},
{"f_5240support.scm",(void*)f_5240},
{"f_5193support.scm",(void*)f_5193},
{"f_5196support.scm",(void*)f_5196},
{"f_5199support.scm",(void*)f_5199},
{"f_5149support.scm",(void*)f_5149},
{"f_5155support.scm",(void*)f_5155},
{"f_5166support.scm",(void*)f_5166},
{"f_5125support.scm",(void*)f_5125},
{"f_5131support.scm",(void*)f_5131},
{"f_5141support.scm",(void*)f_5141},
{"f_5089support.scm",(void*)f_5089},
{"f_5096support.scm",(void*)f_5096},
{"f_5099support.scm",(void*)f_5099},
{"f_5079support.scm",(void*)f_5079},
{"f_5022support.scm",(void*)f_5022},
{"f_5026support.scm",(void*)f_5026},
{"f_5056support.scm",(void*)f_5056},
{"f_4970support.scm",(void*)f_4970},
{"f_4974support.scm",(void*)f_4974},
{"f_5001support.scm",(void*)f_5001},
{"f_4924support.scm",(void*)f_4924},
{"f_4928support.scm",(void*)f_4928},
{"f_4950support.scm",(void*)f_4950},
{"f_4906support.scm",(void*)f_4906},
{"f_4910support.scm",(void*)f_4910},
{"f_4918support.scm",(void*)f_4918},
{"f_4888support.scm",(void*)f_4888},
{"f_4892support.scm",(void*)f_4892},
{"f_4827support.scm",(void*)f_4827},
{"f_4864support.scm",(void*)f_4864},
{"f_4868support.scm",(void*)f_4868},
{"f_4871support.scm",(void*)f_4871},
{"f_4831support.scm",(void*)f_4831},
{"f_4849support.scm",(void*)f_4849},
{"f_4853support.scm",(void*)f_4853},
{"f_4834support.scm",(void*)f_4834},
{"f_4839support.scm",(void*)f_4839},
{"f_4686support.scm",(void*)f_4686},
{"f_4690support.scm",(void*)f_4690},
{"f_4694support.scm",(void*)f_4694},
{"f_4683support.scm",(void*)f_4683},
{"f_4576support.scm",(void*)f_4576},
{"f_4585support.scm",(void*)f_4585},
{"f_4616support.scm",(void*)f_4616},
{"f_4670support.scm",(void*)f_4670},
{"f_4676support.scm",(void*)f_4676},
{"f_4622support.scm",(void*)f_4622},
{"f_4654support.scm",(void*)f_4654},
{"f_4668support.scm",(void*)f_4668},
{"f_4660support.scm",(void*)f_4660},
{"f_4626support.scm",(void*)f_4626},
{"f_4648support.scm",(void*)f_4648},
{"f_4591support.scm",(void*)f_4591},
{"f_4597support.scm",(void*)f_4597},
{"f_4608support.scm",(void*)f_4608},
{"f_4605support.scm",(void*)f_4605},
{"f_4583support.scm",(void*)f_4583},
{"f_4475support.scm",(void*)f_4475},
{"f_4481support.scm",(void*)f_4481},
{"f_4558support.scm",(void*)f_4558},
{"f_4509support.scm",(void*)f_4509},
{"f_4547support.scm",(void*)f_4547},
{"f_4535support.scm",(void*)f_4535},
{"f_4415support.scm",(void*)f_4415},
{"f_4431support.scm",(void*)f_4431},
{"f_4473support.scm",(void*)f_4473},
{"f_4437support.scm",(void*)f_4437},
{"f_4452support.scm",(void*)f_4452},
{"f_4369support.scm",(void*)f_4369},
{"f_4413support.scm",(void*)f_4413},
{"f_4373support.scm",(void*)f_4373},
{"f_4339support.scm",(void*)f_4339},
{"f_4293support.scm",(void*)f_4293},
{"f_4262support.scm",(void*)f_4262},
{"f_4268support.scm",(void*)f_4268},
{"f_4283support.scm",(void*)f_4283},
{"f_4199support.scm",(void*)f_4199},
{"f_4213support.scm",(void*)f_4213},
{"f_4215support.scm",(void*)f_4215},
{"f_4244support.scm",(void*)f_4244},
{"f_4223support.scm",(void*)f_4223},
{"f_4187support.scm",(void*)f_4187},
{"f_4140support.scm",(void*)f_4140},
{"f_4156support.scm",(void*)f_4156},
{"f_4168support.scm",(void*)f_4168},
{"f_4133support.scm",(void*)f_4133},
{"f_4126support.scm",(void*)f_4126},
{"f_4070support.scm",(void*)f_4070},
{"f_4124support.scm",(void*)f_4124},
{"f_4074support.scm",(void*)f_4074},
{"f_4097support.scm",(void*)f_4097},
{"f_3976support.scm",(void*)f_3976},
{"f_3992support.scm",(void*)f_3992},
{"f_3994support.scm",(void*)f_3994},
{"f_4016support.scm",(void*)f_4016},
{"f_4055support.scm",(void*)f_4055},
{"f_4023support.scm",(void*)f_4023},
{"f_4039support.scm",(void*)f_4039},
{"f_4027support.scm",(void*)f_4027},
{"f_4031support.scm",(void*)f_4031},
{"f_3988support.scm",(void*)f_3988},
{"f_3932support.scm",(void*)f_3932},
{"f_3938support.scm",(void*)f_3938},
{"f_3962support.scm",(void*)f_3962},
{"f_3907support.scm",(void*)f_3907},
{"f_3930support.scm",(void*)f_3930},
{"f_3886support.scm",(void*)f_3886},
{"f_3850support.scm",(void*)f_3850},
{"f_3856support.scm",(void*)f_3856},
{"f_3782support.scm",(void*)f_3782},
{"f_3806support.scm",(void*)f_3806},
{"f_3785support.scm",(void*)f_3785},
{"f_3793support.scm",(void*)f_3793},
{"f_3797support.scm",(void*)f_3797},
{"f_3739support.scm",(void*)f_3739},
{"f_3745support.scm",(void*)f_3745},
{"f_3768support.scm",(void*)f_3768},
{"f_3772support.scm",(void*)f_3772},
{"f_3736support.scm",(void*)f_3736},
{"f_3711support.scm",(void*)f_3711},
{"f_3715support.scm",(void*)f_3715},
{"f_3718support.scm",(void*)f_3718},
{"f_3729support.scm",(void*)f_3729},
{"f_3721support.scm",(void*)f_3721},
{"f_3724support.scm",(void*)f_3724},
{"f_3692support.scm",(void*)f_3692},
{"f_3696support.scm",(void*)f_3696},
{"f_3709support.scm",(void*)f_3709},
{"f_3699support.scm",(void*)f_3699},
{"f_3702support.scm",(void*)f_3702},
{"f_3663support.scm",(void*)f_3663},
{"f_3670support.scm",(void*)f_3670},
{"f_3673support.scm",(void*)f_3673},
{"f_3683support.scm",(void*)f_3683},
{"f_3676support.scm",(void*)f_3676},
{"f_3623support.scm",(void*)f_3623},
{"f_3633support.scm",(void*)f_3633},
{"f_3648support.scm",(void*)f_3648},
{"f_3653support.scm",(void*)f_3653},
{"f_3661support.scm",(void*)f_3661},
{"f_3636support.scm",(void*)f_3636},
{"f_3639support.scm",(void*)f_3639},
{"f_3642support.scm",(void*)f_3642},
{"f_3596support.scm",(void*)f_3596},
{"f_3610support.scm",(void*)f_3610},
{"f_3591support.scm",(void*)f_3591},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
