/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:21
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[479];
static double C_possibly_force_alignment;


/* from k4242 */
static C_word C_fcall stub332(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub332(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4235 */
static C_word C_fcall stub327(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub327(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11255)
static void C_ccall f_11255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11120)
static void C_ccall f_11120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11253)
static void C_ccall f_11253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11124)
static void C_fcall f_11124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11129)
static void C_ccall f_11129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11133)
static void C_ccall f_11133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11193)
static void C_fcall f_11193(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11237)
static void C_ccall f_11237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11209)
static void C_ccall f_11209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11136)
static void C_ccall f_11136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11191)
static void C_ccall f_11191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11143)
static void C_ccall f_11143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11091)
static void C_ccall f_11091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11118)
static void C_ccall f_11118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11102)
static void C_ccall f_11102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11105)
static void C_ccall f_11105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11107)
static void C_ccall f_11107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11111)
static void C_ccall f_11111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11095)
static void C_fcall f_11095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11065)
static void C_ccall f_11065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11089)
static void C_ccall f_11089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11075)
static void C_ccall f_11075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11079)
static void C_ccall f_11079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11050)
static void C_ccall f_11050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10959)
static void C_ccall f_10959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10963)
static void C_ccall f_10963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10968)
static void C_fcall f_10968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10972)
static void C_ccall f_10972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11023)
static void C_ccall f_11023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11002)
static void C_ccall f_11002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11014)
static void C_ccall f_11014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11017)
static void C_ccall f_11017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10990)
static void C_ccall f_10990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10926)
static void C_ccall f_10926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10936)
static void C_ccall f_10936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10939)
static void C_ccall f_10939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10824)
static void C_ccall f_10824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10833)
static void C_fcall f_10833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10920)
static void C_ccall f_10920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10837)
static void C_ccall f_10837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10915)
static void C_ccall f_10915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10840)
static void C_ccall f_10840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10843)
static void C_ccall f_10843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10846)
static void C_ccall f_10846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10852)
static void C_ccall f_10852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10905)
static void C_ccall f_10905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10855)
static void C_ccall f_10855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10870)
static void C_ccall f_10870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10878)
static void C_fcall f_10878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10888)
static void C_ccall f_10888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10873)
static void C_ccall f_10873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10861)
static void C_ccall f_10861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10828)
static void C_ccall f_10828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10818)
static void C_ccall f_10818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10772)
static void C_ccall f_10772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10791)
static void C_ccall f_10791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10798)
static void C_ccall f_10798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10760)
static void C_ccall f_10760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10766)
static void C_ccall f_10766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10748)
static void C_ccall f_10748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10752)
static void C_ccall f_10752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10688)
static void C_ccall f_10688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10719)
static void C_fcall f_10719(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10726)
static void C_ccall f_10726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10739)
static void C_ccall f_10739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10743)
static void C_ccall f_10743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10672)
static void C_fcall f_10672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10682)
static void C_ccall f_10682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10663)
static void C_ccall f_10663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10619)
static void C_ccall f_10619(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10619)
static void C_ccall f_10619r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10631)
static void C_ccall f_10631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10635)
static void C_ccall f_10635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10639)
static void C_ccall f_10639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10610)
static void C_ccall f_10610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10604)
static void C_ccall f_10604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10598)
static void C_ccall f_10598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_ccall f_10590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10593)
static void C_ccall f_10593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10552)
static void C_ccall f_10552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10555)
static void C_ccall f_10555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10506)
static void C_ccall f_10506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10515)
static void C_fcall f_10515(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10477)
static void C_ccall f_10477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10487)
static void C_fcall f_10487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10459)
static void C_ccall f_10459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10408)
static void C_ccall f_10408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10453)
static void C_ccall f_10453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10457)
static void C_ccall f_10457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10411)
static void C_ccall f_10411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10416)
static void C_ccall f_10416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10420)
static void C_ccall f_10420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10414)
static void C_ccall f_10414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10371)
static void C_fcall f_10371(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10375)
static void C_ccall f_10375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10384)
static void C_ccall f_10384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10388)
static void C_ccall f_10388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10336)
static void C_fcall f_10336(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10342)
static void C_fcall f_10342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10369)
static void C_ccall f_10369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10355)
static void C_ccall f_10355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10289)
static void C_fcall f_10289(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10295)
static void C_fcall f_10295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10334)
static void C_ccall f_10334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10316)
static void C_ccall f_10316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10106)
static void C_ccall f_10106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10265)
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10271)
static void C_ccall f_10271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10109)
static void C_fcall f_10109(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10259)
static void C_ccall f_10259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10113)
static void C_ccall f_10113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10254)
static void C_ccall f_10254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10116)
static void C_ccall f_10116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10119)
static void C_ccall f_10119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10128)
static void C_fcall f_10128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10212)
static void C_ccall f_10212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10224)
static void C_ccall f_10224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10182)
static void C_ccall f_10182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10193)
static void C_ccall f_10193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10173)
static void C_ccall f_10173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10159)
static void C_fcall f_10159(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10147)
static void C_ccall f_10147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10013)
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10019)
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10100)
static void C_ccall f_10100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10023)
static void C_ccall f_10023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10095)
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10026)
static void C_ccall f_10026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10079)
static void C_fcall f_10079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10047)
static void C_fcall f_10047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10041)
static void C_fcall f_10041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10017)
static void C_ccall f_10017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9721)
static void C_ccall f_9721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9917)
static void C_fcall f_9917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9938)
static void C_fcall f_9938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9411)
static void C_ccall f_9411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9423)
static void C_ccall f_9423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9433)
static void C_fcall f_9433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9451)
static void C_ccall f_9451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9485)
static void C_fcall f_9485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9414)
static void C_fcall f_9414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9405)
static void C_ccall f_9405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9108)
static void C_fcall f_9108(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9117)
static void C_fcall f_9117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_fcall f_9129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9141)
static void C_fcall f_9141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9147)
static void C_ccall f_9147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9181)
static void C_fcall f_9181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9052)
static void C_ccall f_9052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9058)
static void C_ccall f_9058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9062)
static void C_ccall f_9062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9021)
static void C_ccall f_9021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9025)
static void C_fcall f_9025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8994)
static void C_fcall f_8994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8984)
static void C_ccall f_8984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7955)
static void C_fcall f_7955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7984)
static void C_fcall f_7984(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8003)
static void C_fcall f_8003(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8022)
static void C_fcall f_8022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8092)
static void C_fcall f_8092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_fcall f_8111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8193)
static void C_fcall f_8193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8232)
static void C_fcall f_8232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_fcall f_8251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8270)
static void C_fcall f_8270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_fcall f_8350(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_fcall f_8435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_fcall f_8544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8547)
static void C_ccall f_8547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8353)
static void C_ccall f_8353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8384)
static void C_fcall f_8384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8145)
static void C_fcall f_8145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8025)
static void C_ccall f_8025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8056)
static void C_fcall f_8056(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7911)
static void C_ccall f_7911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_ccall f_7922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7868)
static void C_ccall f_7868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7844)
static void C_ccall f_7844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7716)
static void C_ccall f_7716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7745)
static void C_fcall f_7745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7698)
static void C_fcall f_7698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7701)
static void C_ccall f_7701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7640)
static void C_ccall f_7640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7630)
static void C_ccall f_7630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7484)
static void C_fcall f_7484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7510)
static void C_ccall f_7510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7498)
static void C_ccall f_7498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7506)
static void C_ccall f_7506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_fcall f_7317(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_ccall f_7339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7403)
static void C_ccall f_7403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7346)
static void C_ccall f_7346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7352)
static void C_fcall f_7352(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_fcall f_7274(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7245)
static void C_fcall f_7245(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7269)
static void C_ccall f_7269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7226)
static void C_ccall f_7226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7218)
static void C_ccall f_7218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7186)
static C_word C_fcall f_7186(C_word t0,C_word t1);
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7137)
static void C_fcall f_7137(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_fcall f_6922(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6929)
static void C_ccall f_6929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7056)
static void C_ccall f_7056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6966)
static void C_ccall f_6966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6967)
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_fcall f_6916(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6815)
static void C_ccall f_6815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6819)
static void C_ccall f_6819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6902)
static void C_ccall f_6902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6827)
static void C_ccall f_6827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6840)
static void C_ccall f_6840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6749)
static void C_fcall f_6749(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_fcall f_6435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_fcall f_6669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static void C_ccall f_6680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_fcall f_6607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6509)
static void C_ccall f_6509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6248)
static void C_fcall f_6248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6305)
static void C_ccall f_6305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6326)
static void C_fcall f_6326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6211)
static void C_ccall f_6211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6073)
static void C_fcall f_6073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5907)
static void C_fcall f_5907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5904)
static void C_fcall f_5904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_fcall f_5278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_fcall f_5429(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_fcall f_5486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_fcall f_5331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_fcall f_5362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5237)
static void C_fcall f_5237(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_fcall f_5205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4587)
static void C_fcall f_4587(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_fcall f_4615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_fcall f_4479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4374)
static void C_fcall f_4374(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_fcall f_4321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_fcall f_4329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_fcall f_4274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_fcall f_4100(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4122)
static void C_fcall f_4122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_fcall f_4129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4044)
static void C_fcall f_4044(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3962)
static C_word C_fcall f_3962(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3912)
static void C_fcall f_3912(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3891)
static void C_fcall f_3891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3851)
static void C_fcall f_3851(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3776)
static void C_fcall f_3776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11124)
static void C_fcall trf_11124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11124(t0,t1);}

C_noret_decl(trf_11193)
static void C_fcall trf_11193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11193(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11193(t0,t1,t2);}

C_noret_decl(trf_11095)
static void C_fcall trf_11095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11095(t0,t1);}

C_noret_decl(trf_10968)
static void C_fcall trf_10968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10968(t0,t1);}

C_noret_decl(trf_10833)
static void C_fcall trf_10833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10833(t0,t1,t2,t3);}

C_noret_decl(trf_10878)
static void C_fcall trf_10878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10878(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10878(t0,t1,t2);}

C_noret_decl(trf_10719)
static void C_fcall trf_10719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10719(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10719(t0,t1,t2,t3);}

C_noret_decl(trf_10672)
static void C_fcall trf_10672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10672(t0,t1);}

C_noret_decl(trf_10515)
static void C_fcall trf_10515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10515(t0,t1,t2);}

C_noret_decl(trf_10487)
static void C_fcall trf_10487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10487(t0,t1);}

C_noret_decl(trf_10371)
static void C_fcall trf_10371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10371(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10371(t0,t1,t2,t3);}

C_noret_decl(trf_10336)
static void C_fcall trf_10336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10336(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10336(t0,t1,t2);}

C_noret_decl(trf_10342)
static void C_fcall trf_10342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10342(t0,t1,t2);}

C_noret_decl(trf_10289)
static void C_fcall trf_10289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10289(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10289(t0,t1,t2,t3);}

C_noret_decl(trf_10295)
static void C_fcall trf_10295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10295(t0,t1,t2);}

C_noret_decl(trf_10265)
static void C_fcall trf_10265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10265(t0,t1,t2,t3);}

C_noret_decl(trf_10109)
static void C_fcall trf_10109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10109(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10109(t0,t1,t2,t3);}

C_noret_decl(trf_10128)
static void C_fcall trf_10128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10128(t0,t1);}

C_noret_decl(trf_10159)
static void C_fcall trf_10159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10159(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10159(t0,t1);}

C_noret_decl(trf_10079)
static void C_fcall trf_10079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10079(t0,t1);}

C_noret_decl(trf_10047)
static void C_fcall trf_10047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10047(t0,t1);}

C_noret_decl(trf_10041)
static void C_fcall trf_10041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10041(t0,t1);}

C_noret_decl(trf_9917)
static void C_fcall trf_9917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9917(t0,t1);}

C_noret_decl(trf_9938)
static void C_fcall trf_9938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9938(t0,t1);}

C_noret_decl(trf_9433)
static void C_fcall trf_9433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9433(t0,t1);}

C_noret_decl(trf_9485)
static void C_fcall trf_9485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9485(t0,t1);}

C_noret_decl(trf_9414)
static void C_fcall trf_9414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9414(t0,t1);}

C_noret_decl(trf_9108)
static void C_fcall trf_9108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9108(t0,t1);}

C_noret_decl(trf_9117)
static void C_fcall trf_9117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9117(t0,t1);}

C_noret_decl(trf_9129)
static void C_fcall trf_9129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9129(t0,t1);}

C_noret_decl(trf_9141)
static void C_fcall trf_9141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9141(t0,t1);}

C_noret_decl(trf_9181)
static void C_fcall trf_9181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9181(t0,t1);}

C_noret_decl(trf_9025)
static void C_fcall trf_9025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9025(t0,t1);}

C_noret_decl(trf_8994)
static void C_fcall trf_8994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8994(t0,t1);}

C_noret_decl(trf_7955)
static void C_fcall trf_7955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7955(t0,t1,t2);}

C_noret_decl(trf_7984)
static void C_fcall trf_7984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7984(t0,t1);}

C_noret_decl(trf_8003)
static void C_fcall trf_8003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8003(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8003(t0,t1);}

C_noret_decl(trf_8022)
static void C_fcall trf_8022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8022(t0,t1);}

C_noret_decl(trf_8092)
static void C_fcall trf_8092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8092(t0,t1);}

C_noret_decl(trf_8111)
static void C_fcall trf_8111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8111(t0,t1);}

C_noret_decl(trf_8193)
static void C_fcall trf_8193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8193(t0,t1);}

C_noret_decl(trf_8232)
static void C_fcall trf_8232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8232(t0,t1);}

C_noret_decl(trf_8251)
static void C_fcall trf_8251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8251(t0,t1);}

C_noret_decl(trf_8270)
static void C_fcall trf_8270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8270(t0,t1);}

C_noret_decl(trf_8350)
static void C_fcall trf_8350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8350(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8350(t0,t1);}

C_noret_decl(trf_8435)
static void C_fcall trf_8435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8435(t0,t1);}

C_noret_decl(trf_8544)
static void C_fcall trf_8544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8544(t0,t1);}

C_noret_decl(trf_8384)
static void C_fcall trf_8384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8384(t0,t1);}

C_noret_decl(trf_8145)
static void C_fcall trf_8145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8145(t0,t1);}

C_noret_decl(trf_8056)
static void C_fcall trf_8056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8056(t0,t1);}

C_noret_decl(trf_7745)
static void C_fcall trf_7745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7745(t0,t1);}

C_noret_decl(trf_7698)
static void C_fcall trf_7698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7698(t0,t1);}

C_noret_decl(trf_7484)
static void C_fcall trf_7484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7484(t0,t1);}

C_noret_decl(trf_7317)
static void C_fcall trf_7317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7317(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7317(t0,t1,t2,t3);}

C_noret_decl(trf_7352)
static void C_fcall trf_7352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7352(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7352(t0,t1,t2,t3);}

C_noret_decl(trf_7274)
static void C_fcall trf_7274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7274(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7274(t0,t1,t2,t3);}

C_noret_decl(trf_7245)
static void C_fcall trf_7245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7245(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7245(t0,t1,t2,t3);}

C_noret_decl(trf_7137)
static void C_fcall trf_7137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7137(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7137(t0,t1,t2);}

C_noret_decl(trf_6922)
static void C_fcall trf_6922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6922(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6922(t0,t1,t2,t3);}

C_noret_decl(trf_6916)
static void C_fcall trf_6916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6916(t0,t1,t2);}

C_noret_decl(trf_6749)
static void C_fcall trf_6749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6749(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6749(t0,t1,t2);}

C_noret_decl(trf_6435)
static void C_fcall trf_6435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6435(t0,t1);}

C_noret_decl(trf_6669)
static void C_fcall trf_6669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6669(t0,t1);}

C_noret_decl(trf_6607)
static void C_fcall trf_6607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6607(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6607(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6248)
static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6248(t0,t1);}

C_noret_decl(trf_6326)
static void C_fcall trf_6326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6326(t0,t1);}

C_noret_decl(trf_6073)
static void C_fcall trf_6073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6073(t0,t1);}

C_noret_decl(trf_5907)
static void C_fcall trf_5907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5907(t0,t1);}

C_noret_decl(trf_5904)
static void C_fcall trf_5904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5904(t0,t1);}

C_noret_decl(trf_5278)
static void C_fcall trf_5278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5278(t0,t1);}

C_noret_decl(trf_5403)
static void C_fcall trf_5403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5403(t0,t1,t2);}

C_noret_decl(trf_5429)
static void C_fcall trf_5429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5429(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5429(t0,t1);}

C_noret_decl(trf_5486)
static void C_fcall trf_5486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5486(t0,t1);}

C_noret_decl(trf_5331)
static void C_fcall trf_5331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5331(t0,t1);}

C_noret_decl(trf_5362)
static void C_fcall trf_5362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5362(t0,t1);}

C_noret_decl(trf_5237)
static void C_fcall trf_5237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5237(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5237(t0,t1,t2);}

C_noret_decl(trf_5205)
static void C_fcall trf_5205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5205(t0,t1);}

C_noret_decl(trf_4587)
static void C_fcall trf_4587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4587(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4587(t0,t1,t2);}

C_noret_decl(trf_4615)
static void C_fcall trf_4615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4615(t0,t1);}

C_noret_decl(trf_4479)
static void C_fcall trf_4479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4479(t0,t1);}

C_noret_decl(trf_4374)
static void C_fcall trf_4374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4374(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4374(t0,t1,t2,t3);}

C_noret_decl(trf_4321)
static void C_fcall trf_4321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4321(t0,t1,t2);}

C_noret_decl(trf_4329)
static void C_fcall trf_4329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4329(t0,t1);}

C_noret_decl(trf_4274)
static void C_fcall trf_4274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4274(t0,t1);}

C_noret_decl(trf_4100)
static void C_fcall trf_4100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4100(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4100(t0,t1,t2);}

C_noret_decl(trf_4122)
static void C_fcall trf_4122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4122(t0,t1);}

C_noret_decl(trf_4129)
static void C_fcall trf_4129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4129(t0,t1);}

C_noret_decl(trf_4044)
static void C_fcall trf_4044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4044(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4044(t0,t1,t2,t3);}

C_noret_decl(trf_3912)
static void C_fcall trf_3912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3912(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3912(t0,t1,t2,t3);}

C_noret_decl(trf_3891)
static void C_fcall trf_3891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3891(t0,t1);}

C_noret_decl(trf_3851)
static void C_fcall trf_3851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3851(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3851(t0,t1,t2);}

C_noret_decl(trf_3776)
static void C_fcall trf_3776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3776(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4900)){
C_save(t1);
C_rereclaim2(4900*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,479);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000C\012CHICKEN\012(c)2008 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[4]=C_h_intern(&lf[4],30,"\010compilercompiler-cleanup-hook");
lf[5]=C_h_intern(&lf[5],26,"\010compilerdebugging-chicken");
lf[6]=C_h_intern(&lf[6],26,"\010compilerdisabled-warnings");
lf[7]=C_h_intern(&lf[7],13,"\010compilerbomb");
lf[8]=C_h_intern(&lf[8],5,"error");
lf[9]=C_h_intern(&lf[9],13,"string-append");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[12]=C_h_intern(&lf[12],18,"\010compilerdebugging");
lf[13]=C_h_intern(&lf[13],12,"flush-output");
lf[14]=C_h_intern(&lf[14],7,"newline");
lf[15]=C_h_intern(&lf[15],6,"printf");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[17]=C_h_intern(&lf[17],5,"force");
lf[18]=C_h_intern(&lf[18],12,"\003sysfor-each");
lf[19]=C_h_intern(&lf[19],7,"display");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[22]=C_h_intern(&lf[22],25,"\010compilercompiler-warning");
lf[23]=C_h_intern(&lf[23],7,"fprintf");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning: ");
lf[25]=C_h_intern(&lf[25],18,"current-error-port");
lf[26]=C_h_intern(&lf[26],20,"\003syswarnings-enabled");
lf[27]=C_h_intern(&lf[27],4,"quit");
lf[28]=C_h_intern(&lf[28],4,"exit");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\007Error: ");
lf[30]=C_h_intern(&lf[30],21,"\003syssyntax-error-hook");
lf[31]=C_h_intern(&lf[31],16,"print-call-chain");
lf[32]=C_h_intern(&lf[32],18,"\003syscurrent-thread");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[36]=C_h_intern(&lf[36],12,"syntax-error");
lf[37]=C_h_intern(&lf[37],31,"\010compileremit-syntax-trace-info");
lf[38]=C_h_intern(&lf[38],9,"map-llist");
lf[39]=C_h_intern(&lf[39],24,"\010compilercheck-signature");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[41]=C_h_intern(&lf[41],18,"\010compilerreal-name");
lf[42]=C_h_intern(&lf[42],13,"\010compilerposq");
lf[43]=C_h_intern(&lf[43],18,"\010compilerstringify");
lf[44]=C_h_intern(&lf[44],14,"symbol->string");
lf[45]=C_h_intern(&lf[45],7,"sprintf");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[47]=C_h_intern(&lf[47],18,"\010compilersymbolify");
lf[48]=C_h_intern(&lf[48],14,"string->symbol");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[50]=C_h_intern(&lf[50],26,"\010compilerbuild-lambda-list");
lf[51]=C_h_intern(&lf[51],29,"\010compilerstring->c-identifier");
lf[52]=C_h_intern(&lf[52],24,"\003sysstring->c-identifier");
lf[53]=C_h_intern(&lf[53],21,"\010compilerc-ify-string");
lf[54]=C_h_intern(&lf[54],16,"\003syslist->string");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[56]=C_h_intern(&lf[56],6,"append");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[58]=C_h_intern(&lf[58],16,"\003sysstring->list");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[62]=C_h_intern(&lf[62],28,"\010compilervalid-c-identifier\077");
lf[63]=C_h_intern(&lf[63],3,"any");
lf[64]=C_h_intern(&lf[64],8,"->string");
lf[65]=C_h_intern(&lf[65],14,"\010compilerwords");
lf[66]=C_h_intern(&lf[66],21,"\010compilerwords->bytes");
lf[67]=C_h_intern(&lf[67],34,"\010compilercheck-and-open-input-file");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[69]=C_h_intern(&lf[69],18,"current-input-port");
lf[70]=C_h_intern(&lf[70],15,"open-input-file");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[73]=C_h_intern(&lf[73],12,"file-exists\077");
lf[74]=C_h_intern(&lf[74],33,"\010compilerclose-checked-input-file");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[76]=C_h_intern(&lf[76],16,"close-input-port");
lf[77]=C_h_intern(&lf[77],19,"\010compilerfold-inner");
lf[78]=C_h_intern(&lf[78],7,"reverse");
lf[79]=C_h_intern(&lf[79],28,"\010compilerfollow-without-loop");
lf[80]=C_h_intern(&lf[80],18,"\010compilerconstant\077");
lf[81]=C_h_intern(&lf[81],5,"quote");
lf[82]=C_h_intern(&lf[82],29,"\010compilercollapsable-literal\077");
lf[83]=C_h_intern(&lf[83],19,"\010compilerimmediate\077");
lf[84]=C_h_intern(&lf[84],20,"\010compilerbig-fixnum\077");
lf[85]=C_h_intern(&lf[85],23,"\010compilerbasic-literal\077");
lf[86]=C_h_intern(&lf[86],5,"every");
lf[87]=C_h_intern(&lf[87],12,"vector->list");
lf[88]=C_h_intern(&lf[88],32,"\010compilercanonicalize-begin-body");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_h_intern(&lf[91],3,"let");
lf[92]=C_h_intern(&lf[92],6,"gensym");
lf[93]=C_h_intern(&lf[93],1,"t");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[95]=C_h_intern(&lf[95],21,"\010compilerstring->expr");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000#can not parse expression: ~s [~a]~%");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[98]=C_h_intern(&lf[98],5,"begin");
lf[99]=C_h_intern(&lf[99],10,"\003sysappend");
lf[100]=C_h_intern(&lf[100],4,"read");
lf[101]=C_h_intern(&lf[101],6,"unfold");
lf[102]=C_h_intern(&lf[102],11,"eof-object\077");
lf[103]=C_h_intern(&lf[103],6,"values");
lf[104]=C_h_intern(&lf[104],22,"with-input-from-string");
lf[105]=C_h_intern(&lf[105],22,"with-exception-handler");
lf[106]=C_h_intern(&lf[106],30,"call-with-current-continuation");
lf[107]=C_h_intern(&lf[107],30,"\010compilerdecompose-lambda-list");
lf[108]=C_h_intern(&lf[108],25,"\003sysdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],37,"\010compilerprocess-lambda-documentation");
lf[110]=C_h_intern(&lf[110],30,"\010compilerexpand-profile-lambda");
lf[111]=C_h_intern(&lf[111],29,"\010compilerprofile-lambda-index");
lf[112]=C_h_intern(&lf[112],28,"\010compilerprofile-lambda-list");
lf[113]=C_h_intern(&lf[113],33,"\010compilerprofile-info-vector-name");
lf[114]=C_h_intern(&lf[114],17,"\003sysprofile-entry");
lf[115]=C_h_intern(&lf[115],6,"lambda");
lf[116]=C_h_intern(&lf[116],5,"apply");
lf[117]=C_h_intern(&lf[117],16,"\003sysprofile-exit");
lf[118]=C_h_intern(&lf[118],16,"\003sysdynamic-wind");
lf[119]=C_h_intern(&lf[119],10,"alist-cons");
lf[120]=C_h_intern(&lf[120],37,"\010compilerinitialize-analysis-database");
lf[121]=C_h_intern(&lf[121],13,"\010compilerput!");
lf[122]=C_h_intern(&lf[122],8,"constant");
lf[123]=C_h_intern(&lf[123],26,"\010compilermutable-constants");
lf[124]=C_h_intern(&lf[124],35,"\010compilerfoldable-extended-bindings");
lf[125]=C_h_intern(&lf[125],8,"foldable");
lf[126]=C_h_intern(&lf[126],16,"extended-binding");
lf[127]=C_h_intern(&lf[127],17,"extended-bindings");
lf[128]=C_h_intern(&lf[128],35,"\010compilerfoldable-standard-bindings");
lf[129]=C_h_intern(&lf[129],41,"\010compilerside-effecting-standard-bindings");
lf[130]=C_h_intern(&lf[130],14,"side-effecting");
lf[131]=C_h_intern(&lf[131],16,"standard-binding");
lf[132]=C_h_intern(&lf[132],17,"standard-bindings");
lf[133]=C_h_intern(&lf[133],12,"\010compilerget");
lf[134]=C_h_intern(&lf[134],18,"\003syshash-table-ref");
lf[135]=C_h_intern(&lf[135],16,"\010compilerget-all");
lf[136]=C_h_intern(&lf[136],10,"filter-map");
lf[137]=C_h_intern(&lf[137],19,"\003syshash-table-set!");
lf[138]=C_h_intern(&lf[138],17,"\010compilercollect!");
lf[139]=C_h_intern(&lf[139],15,"\010compilercount!");
lf[140]=C_h_intern(&lf[140],17,"\010compilerget-line");
lf[141]=C_h_intern(&lf[141],24,"\003sysline-number-database");
lf[142]=C_h_intern(&lf[142],19,"\010compilerget-line-2");
lf[143]=C_h_intern(&lf[143],30,"\010compilerfind-lambda-container");
lf[144]=C_h_intern(&lf[144],12,"contained-in");
lf[145]=C_h_intern(&lf[145],37,"\010compilerdisplay-line-number-database");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[147]=C_h_intern(&lf[147],7,"\003sysmap");
lf[148]=C_h_intern(&lf[148],3,"cdr");
lf[149]=C_h_intern(&lf[149],23,"\003syshash-table-for-each");
lf[150]=C_h_intern(&lf[150],34,"\010compilerdisplay-analysis-database");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[155]=C_h_intern(&lf[155],7,"unknown");
lf[156]=C_h_intern(&lf[156],8,"captured");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\010foldable\376\001\000\000\003fld\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000"
"\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016side-effecting\376\001\000\000\003sef\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376\001\000\000\003col\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011undefin"
"ed\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012"
"boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[159]=C_h_intern(&lf[159],4,"caar");
lf[160]=C_h_intern(&lf[160],5,"value");
lf[161]=C_h_intern(&lf[161],4,"cdar");
lf[162]=C_h_intern(&lf[162],15,"potential-value");
lf[163]=C_h_intern(&lf[163],10,"replacable");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[165]=C_h_intern(&lf[165],10,"references");
lf[166]=C_h_intern(&lf[166],10,"call-sites");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[168]=C_h_intern(&lf[168],4,"home");
lf[169]=C_h_intern(&lf[169],8,"contains");
lf[170]=C_h_intern(&lf[170],8,"use-expr");
lf[171]=C_h_intern(&lf[171],12,"closure-size");
lf[172]=C_h_intern(&lf[172],14,"rest-parameter");
lf[173]=C_h_intern(&lf[173],16,"o-r/access-count");
lf[174]=C_h_intern(&lf[174],18,"captured-variables");
lf[175]=C_h_intern(&lf[175],13,"explicit-rest");
lf[176]=C_h_intern(&lf[176],8,"assigned");
lf[177]=C_h_intern(&lf[177],5,"boxed");
lf[178]=C_h_intern(&lf[178],6,"global");
lf[179]=C_h_intern(&lf[179],12,"contractable");
lf[180]=C_h_intern(&lf[180],16,"assigned-locally");
lf[181]=C_h_intern(&lf[181],11,"collapsable");
lf[182]=C_h_intern(&lf[182],9,"removable");
lf[183]=C_h_intern(&lf[183],9,"undefined");
lf[184]=C_h_intern(&lf[184],9,"replacing");
lf[185]=C_h_intern(&lf[185],6,"unused");
lf[186]=C_h_intern(&lf[186],6,"simple");
lf[187]=C_h_intern(&lf[187],9,"inlinable");
lf[188]=C_h_intern(&lf[188],13,"inline-export");
lf[189]=C_h_intern(&lf[189],21,"has-unused-parameters");
lf[190]=C_h_intern(&lf[190],12,"customizable");
lf[191]=C_h_intern(&lf[191],10,"boxed-rest");
lf[192]=C_h_intern(&lf[192],5,"write");
lf[193]=C_h_intern(&lf[193],34,"\010compilerdefault-standard-bindings");
lf[194]=C_h_intern(&lf[194],34,"\010compilerdefault-extended-bindings");
lf[195]=C_h_intern(&lf[195],26,"\010compilerinternal-bindings");
lf[196]=C_h_intern(&lf[196],9,"make-node");
lf[197]=C_h_intern(&lf[197],4,"node");
lf[198]=C_h_intern(&lf[198],5,"node\077");
lf[199]=C_h_intern(&lf[199],15,"node-class-set!");
lf[200]=C_h_intern(&lf[200],14,"\003sysblock-set!");
lf[201]=C_h_intern(&lf[201],10,"node-class");
lf[202]=C_h_intern(&lf[202],20,"node-parameters-set!");
lf[203]=C_h_intern(&lf[203],15,"node-parameters");
lf[204]=C_h_intern(&lf[204],24,"node-subexpressions-set!");
lf[205]=C_h_intern(&lf[205],19,"node-subexpressions");
lf[206]=C_h_intern(&lf[206],16,"\010compilervarnode");
lf[207]=C_h_intern(&lf[207],13,"\004corevariable");
lf[208]=C_h_intern(&lf[208],14,"\010compilerqnode");
lf[209]=C_h_intern(&lf[209],25,"\010compilerbuild-node-graph");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[211]=C_h_intern(&lf[211],15,"\004coreglobal-ref");
lf[212]=C_h_intern(&lf[212],2,"if");
lf[213]=C_h_intern(&lf[213],14,"\004coreundefined");
lf[214]=C_h_intern(&lf[214],8,"truncate");
lf[215]=C_h_intern(&lf[215],4,"type");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[217]=C_h_intern(&lf[217],6,"fixnum");
lf[218]=C_h_intern(&lf[218],11,"number-type");
lf[219]=C_h_intern(&lf[219],6,"unzip1");
lf[220]=C_h_intern(&lf[220],11,"\004corelambda");
lf[221]=C_h_intern(&lf[221],14,"\004coreprimitive");
lf[222]=C_h_intern(&lf[222],11,"\004coreinline");
lf[223]=C_h_intern(&lf[223],13,"\004corecallunit");
lf[224]=C_h_intern(&lf[224],9,"\004coreproc");
lf[225]=C_h_intern(&lf[225],4,"set!");
lf[226]=C_h_intern(&lf[226],9,"\004coreset!");
lf[227]=C_h_intern(&lf[227],29,"\004coreforeign-callback-wrapper");
lf[228]=C_h_intern(&lf[228],5,"sixth");
lf[229]=C_h_intern(&lf[229],5,"fifth");
lf[230]=C_h_intern(&lf[230],20,"\004coreinline_allocate");
lf[231]=C_h_intern(&lf[231],8,"\004coreapp");
lf[232]=C_h_intern(&lf[232],9,"\004corecall");
lf[233]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[234]=C_h_intern(&lf[234],24,"\010compilersource-filename");
lf[235]=C_h_intern(&lf[235],28,"\003syssymbol->qualified-string");
lf[236]=C_h_intern(&lf[236],34,"\010compileralways-bound-to-procedure");
lf[237]=C_h_intern(&lf[237],15,"\004coreinline_ref");
lf[238]=C_h_intern(&lf[238],18,"\004coreinline_update");
lf[239]=C_h_intern(&lf[239],19,"\004coreinline_loc_ref");
lf[240]=C_h_intern(&lf[240],22,"\004coreinline_loc_update");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[242]=C_h_intern(&lf[242],1,"o");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[244]=C_h_intern(&lf[244],30,"\010compilerbuild-expression-tree");
lf[245]=C_h_intern(&lf[245],12,"\004coreclosure");
lf[246]=C_h_intern(&lf[246],4,"last");
lf[247]=C_h_intern(&lf[247],3,"map");
lf[248]=C_h_intern(&lf[248],4,"list");
lf[249]=C_h_intern(&lf[249],7,"butlast");
lf[250]=C_h_intern(&lf[250],5,"cons*");
lf[251]=C_h_intern(&lf[251],9,"\004corebind");
lf[252]=C_h_intern(&lf[252],10,"\004coreunbox");
lf[253]=C_h_intern(&lf[253],8,"\004coreref");
lf[254]=C_h_intern(&lf[254],11,"\004coreupdate");
lf[255]=C_h_intern(&lf[255],13,"\004coreupdate_i");
lf[256]=C_h_intern(&lf[256],8,"\004corebox");
lf[257]=C_h_intern(&lf[257],9,"\004corecond");
lf[258]=C_h_intern(&lf[258],21,"\010compilerfold-boolean");
lf[259]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[260]=C_h_intern(&lf[260],31,"\010compilerinline-lambda-bindings");
lf[261]=C_h_intern(&lf[261],8,"split-at");
lf[262]=C_h_intern(&lf[262],10,"fold-right");
lf[263]=C_h_intern(&lf[263],4,"take");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[265]=C_h_intern(&lf[265],34,"\010compilercopy-node-tree-and-rename");
lf[266]=C_h_intern(&lf[266],9,"alist-ref");
lf[267]=C_h_intern(&lf[267],3,"eq\077");
lf[268]=C_h_intern(&lf[268],18,"\010compilertree-copy");
lf[269]=C_h_intern(&lf[269],4,"cons");
lf[270]=C_h_intern(&lf[270],19,"\010compilercopy-node!");
lf[271]=C_h_intern(&lf[271],19,"\010compilermatch-node");
lf[272]=C_h_intern(&lf[272],1,"a");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[274]=C_h_intern(&lf[274],37,"\010compilerexpression-has-side-effects\077");
lf[275]=C_h_intern(&lf[275],24,"foreign-callback-stub-id");
lf[276]=C_h_intern(&lf[276],4,"find");
lf[277]=C_h_intern(&lf[277],22,"foreign-callback-stubs");
lf[278]=C_h_intern(&lf[278],28,"\010compilersimple-lambda-node\077");
lf[279]=C_h_intern(&lf[279],31,"\010compilerdump-undefined-globals");
lf[280]=C_h_intern(&lf[280],20,"check-global-exports");
lf[281]=C_h_intern(&lf[281],20,"\010compilerexport-list");
lf[282]=C_h_intern(&lf[282],3,"var");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000,exported global variable `~S\047 is not defined");
lf[284]=C_h_intern(&lf[284],6,"delete");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\0005exported global variable `~S\047 is used but not defined");
lf[286]=C_h_intern(&lf[286],28,"\003systoplevel-definition-hook");
lf[287]=C_h_intern(&lf[287],22,"\010compilerblock-globals");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[289]=C_h_intern(&lf[289],36,"\010compilercompute-database-statistics");
lf[290]=C_h_intern(&lf[290],29,"\010compilercurrent-program-size");
lf[291]=C_h_intern(&lf[291],30,"\010compileroriginal-program-size");
lf[292]=C_h_intern(&lf[292],33,"\010compilerprint-program-statistics");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[299]=C_h_intern(&lf[299],1,"s");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[301]=C_h_intern(&lf[301],35,"\010compilerpprint-expressions-to-file");
lf[302]=C_h_intern(&lf[302],17,"close-output-port");
lf[303]=C_h_intern(&lf[303],12,"pretty-print");
lf[304]=C_h_intern(&lf[304],19,"with-output-to-port");
lf[305]=C_h_intern(&lf[305],16,"open-output-file");
lf[306]=C_h_intern(&lf[306],19,"current-output-port");
lf[307]=C_h_intern(&lf[307],27,"\010compilerforeign-type-check");
lf[308]=C_h_intern(&lf[308],4,"char");
lf[309]=C_h_intern(&lf[309],13,"unsigned-char");
lf[310]=C_h_intern(&lf[310],6,"unsafe");
lf[311]=C_h_intern(&lf[311],25,"\003sysforeign-char-argument");
lf[312]=C_h_intern(&lf[312],3,"int");
lf[313]=C_h_intern(&lf[313],27,"\003sysforeign-fixnum-argument");
lf[314]=C_h_intern(&lf[314],5,"float");
lf[315]=C_h_intern(&lf[315],27,"\003sysforeign-flonum-argument");
lf[316]=C_h_intern(&lf[316],7,"pointer");
lf[317]=C_h_intern(&lf[317],26,"\003sysforeign-block-argument");
lf[318]=C_h_intern(&lf[318],15,"nonnull-pointer");
lf[319]=C_h_intern(&lf[319],8,"u8vector");
lf[320]=C_h_intern(&lf[320],34,"\003sysforeign-number-vector-argument");
lf[321]=C_h_intern(&lf[321],16,"nonnull-u8vector");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[323]=C_h_intern(&lf[323],7,"integer");
lf[324]=C_h_intern(&lf[324],28,"\003sysforeign-integer-argument");
lf[325]=C_h_intern(&lf[325],16,"unsigned-integer");
lf[326]=C_h_intern(&lf[326],37,"\003sysforeign-unsigned-integer-argument");
lf[327]=C_h_intern(&lf[327],9,"c-pointer");
lf[328]=C_h_intern(&lf[328],28,"\003sysforeign-pointer-argument");
lf[329]=C_h_intern(&lf[329],17,"nonnull-c-pointer");
lf[330]=C_h_intern(&lf[330],8,"c-string");
lf[331]=C_h_intern(&lf[331],17,"\003sysmake-c-string");
lf[332]=C_h_intern(&lf[332],27,"\003sysforeign-string-argument");
lf[333]=C_h_intern(&lf[333],16,"nonnull-c-string");
lf[334]=C_h_intern(&lf[334],6,"symbol");
lf[335]=C_h_intern(&lf[335],18,"\003syssymbol->string");
lf[336]=C_h_intern(&lf[336],3,"ref");
lf[337]=C_h_intern(&lf[337],8,"instance");
lf[338]=C_h_intern(&lf[338],12,"instance-ref");
lf[339]=C_h_intern(&lf[339],4,"this");
lf[340]=C_h_intern(&lf[340],8,"slot-ref");
lf[341]=C_h_intern(&lf[341],16,"nonnull-instance");
lf[342]=C_h_intern(&lf[342],5,"const");
lf[343]=C_h_intern(&lf[343],4,"enum");
lf[344]=C_h_intern(&lf[344],8,"function");
lf[345]=C_h_intern(&lf[345],27,"\010compilerforeign-type-table");
lf[346]=C_h_intern(&lf[346],17,"nonnull-c-string*");
lf[347]=C_h_intern(&lf[347],26,"nonnull-unsigned-c-string*");
lf[348]=C_h_intern(&lf[348],9,"c-string*");
lf[349]=C_h_intern(&lf[349],18,"unsigned-c-string*");
lf[350]=C_h_intern(&lf[350],13,"c-string-list");
lf[351]=C_h_intern(&lf[351],14,"c-string-list*");
lf[352]=C_h_intern(&lf[352],18,"unsigned-integer32");
lf[353]=C_h_intern(&lf[353],13,"unsigned-long");
lf[354]=C_h_intern(&lf[354],4,"long");
lf[355]=C_h_intern(&lf[355],9,"integer32");
lf[356]=C_h_intern(&lf[356],17,"nonnull-u16vector");
lf[357]=C_h_intern(&lf[357],16,"nonnull-s8vector");
lf[358]=C_h_intern(&lf[358],17,"nonnull-s16vector");
lf[359]=C_h_intern(&lf[359],17,"nonnull-u32vector");
lf[360]=C_h_intern(&lf[360],17,"nonnull-s32vector");
lf[361]=C_h_intern(&lf[361],17,"nonnull-f32vector");
lf[362]=C_h_intern(&lf[362],17,"nonnull-f64vector");
lf[363]=C_h_intern(&lf[363],9,"u16vector");
lf[364]=C_h_intern(&lf[364],8,"s8vector");
lf[365]=C_h_intern(&lf[365],9,"s16vector");
lf[366]=C_h_intern(&lf[366],9,"u32vector");
lf[367]=C_h_intern(&lf[367],9,"s32vector");
lf[368]=C_h_intern(&lf[368],9,"f32vector");
lf[369]=C_h_intern(&lf[369],9,"f64vector");
lf[370]=C_h_intern(&lf[370],22,"nonnull-scheme-pointer");
lf[371]=C_h_intern(&lf[371],12,"nonnull-blob");
lf[372]=C_h_intern(&lf[372],19,"nonnull-byte-vector");
lf[373]=C_h_intern(&lf[373],11,"byte-vector");
lf[374]=C_h_intern(&lf[374],4,"blob");
lf[375]=C_h_intern(&lf[375],14,"scheme-pointer");
lf[376]=C_h_intern(&lf[376],6,"double");
lf[377]=C_h_intern(&lf[377],6,"number");
lf[378]=C_h_intern(&lf[378],12,"unsigned-int");
lf[379]=C_h_intern(&lf[379],5,"short");
lf[380]=C_h_intern(&lf[380],14,"unsigned-short");
lf[381]=C_h_intern(&lf[381],4,"byte");
lf[382]=C_h_intern(&lf[382],13,"unsigned-byte");
lf[383]=C_h_intern(&lf[383],5,"int32");
lf[384]=C_h_intern(&lf[384],14,"unsigned-int32");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[386]=C_h_intern(&lf[386],36,"\010compilerforeign-type-convert-result");
lf[387]=C_h_intern(&lf[387],38,"\010compilerforeign-type-convert-argument");
lf[388]=C_h_intern(&lf[388],27,"\010compilerfinal-foreign-type");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[390]=C_h_intern(&lf[390],37,"\010compilerestimate-foreign-result-size");
lf[391]=C_h_intern(&lf[391],9,"integer64");
lf[392]=C_h_intern(&lf[392],4,"bool");
lf[393]=C_h_intern(&lf[393],4,"void");
lf[394]=C_h_intern(&lf[394],13,"scheme-object");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[396]=C_h_intern(&lf[396],46,"\010compilerestimate-foreign-result-location-size");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\0006can not compute size of location for foreign type `~S\047");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[399]=C_h_intern(&lf[399],30,"\010compilerfinish-foreign-result");
lf[400]=C_h_intern(&lf[400],17,"\003syspeek-c-string");
lf[401]=C_h_intern(&lf[401],25,"\003syspeek-nonnull-c-string");
lf[402]=C_h_intern(&lf[402],26,"\003syspeek-and-free-c-string");
lf[403]=C_h_intern(&lf[403],34,"\003syspeek-and-free-nonnull-c-string");
lf[404]=C_h_intern(&lf[404],17,"\003sysintern-symbol");
lf[405]=C_h_intern(&lf[405],22,"\003syspeek-c-string-list");
lf[406]=C_h_intern(&lf[406],31,"\003syspeek-and-free-c-string-list");
lf[407]=C_h_intern(&lf[407],35,"\010tinyclosmake-instance-from-pointer");
lf[408]=C_h_intern(&lf[408],4,"make");
lf[409]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[410]=C_h_intern(&lf[410],28,"\010compilerscan-used-variables");
lf[411]=C_h_intern(&lf[411],28,"\010compilerscan-free-variables");
lf[412]=C_h_intern(&lf[412],11,"lset-adjoin");
lf[413]=C_h_intern(&lf[413],25,"\010compilertopological-sort");
lf[414]=C_h_intern(&lf[414],7,"colored");
lf[415]=C_h_intern(&lf[415],23,"\010compilerchop-separator");
lf[416]=C_h_intern(&lf[416],9,"substring");
lf[417]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[418]=C_h_intern(&lf[418],23,"\010compilerchop-extension");
lf[419]=C_h_intern(&lf[419],22,"\010compilerprint-version");
lf[420]=C_h_intern(&lf[420],5,"print");
lf[421]=C_h_intern(&lf[421],15,"chicken-version");
lf[422]=C_h_intern(&lf[422],6,"print*");
lf[423]=C_h_intern(&lf[423],9,"\003syserror");
lf[424]=C_h_intern(&lf[424],20,"\010compilerprint-usage");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\0215Usage: chicken FILENAME OPTION ...\012\012  FILENAME should be a complete source "
"file name with extension, or \042-\042 for\012  standard input. OPTION may be one of the "
"following:\012\012  General options:\012\012    -help                       display this tex"
"t and exit\012    -version                    display compiler version and exit\012   "
" -release                    print release number and exit\012    -verbose         "
"           display information on compilation progress\012    -quiet               "
"       do not display compile information\012\012  File and pathname options:\012\012    -ou"
"tput-file FILENAME       specifies output-filename, default is \047out.c\047\012    -incl"
"ude-path PATHNAME      specifies alternative path for included files\012    -to-std"
"out                  write compiled file to stdout instead of file\012\012  Language o"
"ptions:\012\012    -feature SYMBOL             register feature identifier\012\012  Syntax r"
"elated options:\012\012    -case-insensitive           don\047t preserve case of read sym"
"bols\012    -keyword-style STYLE        allow alternative keyword syntax (none, pre"
"fix or suffix)\012    -compile-syntax             macros are made available at run-"
"time\012    -emit-import-library MODULE write compile-time module information into "
"separate file\012\012  Translation options:\012\012    -explicit-use               do not us"
"e units \047library\047 and \047eval\047 by default\012    -check-syntax               stop com"
"pilation after macro-expansion\012    -analyze-only               stop compilation "
"after first analysis pass\012\012  Debugging options:\012\012    -no-warnings               "
" disable warnings\012    -disable-warning CLASS      disable specific class of warn"
"ings\012    -debug-level NUMBER         set level of available debugging informatio"
"n\012    -no-trace                   disable tracing information\012    -profile      "
"              executable emits profiling information \012    -profile-name FILENAME"
"      name of the generated profile information file\012    -accumulate-profile    "
"     executable emits profiling information in append mode\012    -no-lambda-info  "
"           omit additional procedure-information\012\012  Optimization options:\012\012    -"
"optimize-level NUMBER      enable certain sets of optimization options\012    -opti"
"mize-leaf-routines     enable leaf routine optimization\012    -lambda-lift        "
"        enable lambda-lifting\012    -no-usual-integrations      standard procedure"
"s may be redefined\012    -unsafe                     disable safety checks\012    -bl"
"ock                      enable block-compilation\012    -disable-interrupts       "
"  disable interrupts in compiled code\012    -fixnum-arithmetic          assume all"
" numbers are fixnums\012    -benchmark-mode             fixnum mode, no interrupts "
"and opt.-level 3\012    -disable-stack-overflow-checks  \012                          "
"      disables detection of stack-overflows.\012    -inline                     ena"
"ble inlining\012    -inline-limit               set inlining threshold\012\012  Configura"
"tion options:\012\012    -unit NAME                  compile file as a library unit\012  "
"  -uses NAME                  declare library unit as used.\012    -heap-size NUMBE"
"R           specifies heap-size of compiled executable\012    -heap-initial-size NU"
"MBER   specifies heap-size at startup time\012    -heap-growth PERCENTAGE     speci"
"fies growth-rate of expanding heap\012    -heap-shrinkage PERCENTAGE  specifies shr"
"ink-rate of contracting heap\012    -nursery NUMBER\012    -stack-size NUMBER         "
" specifies nursery size of compiled executable\012    -extend FILENAME            l"
"oad file before compilation commences\012    -prelude EXPRESSION         add expres"
"sion to front of source file\012    -postlude EXPRESSION        add expression to e"
"nd of source file\012    -prologue FILENAME          include file before main sourc"
"e file\012    -epilogue FILENAME          include file after main source file\012    -"
"dynamic                    compile as dynamically loadable code\012    -require-ext"
"ension NAME     require and import extension NAME\012    -extension                "
"  compile as extension (dynamic or static)\012\012  Obscure options:\012\012    -debug MODES"
"                display debugging output for the given modes\012    -unsafe-librari"
"es           marks the generated file as being linked\012                          "
"      with the unsafe runtime system\012    -raw                        do not gene"
"rate implicit init- and exit code\011\011\011       \012    -emit-external-prototypes-first "
" emit protoypes for callbacks before foreign\012                                dec"
"larations\012");
lf[426]=C_h_intern(&lf[426],36,"\010compilermake-block-variable-literal");
lf[427]=C_h_intern(&lf[427],22,"block-variable-literal");
lf[428]=C_h_intern(&lf[428],32,"\010compilerblock-variable-literal\077");
lf[429]=C_h_intern(&lf[429],36,"\010compilerblock-variable-literal-name");
lf[430]=C_h_intern(&lf[430],25,"\010compilermake-random-name");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[432]=C_h_intern(&lf[432],6,"random");
lf[433]=C_h_intern(&lf[433],15,"current-seconds");
lf[434]=C_h_intern(&lf[434],23,"\010compilerset-real-name!");
lf[435]=C_h_intern(&lf[435],24,"\010compilerreal-name-table");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[437]=C_h_intern(&lf[437],19,"\010compilerreal-name2");
lf[438]=C_h_intern(&lf[438],32,"\010compilerdisplay-real-name-table");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[440]=C_h_intern(&lf[440],28,"\010compilersource-info->string");
lf[441]=C_h_intern(&lf[441],4,"conc");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[444]=C_h_intern(&lf[444],11,"make-string");
lf[445]=C_h_intern(&lf[445],3,"max");
lf[446]=C_h_intern(&lf[446],12,"string-null\077");
lf[447]=C_h_intern(&lf[447],19,"\010compilerdump-nodes");
lf[448]=C_h_intern(&lf[448],19,"\003syswrite-char/port");
lf[449]=C_h_intern(&lf[449],19,"\003sysstandard-output");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[453]=C_h_intern(&lf[453],18,"\003sysuser-read-hook");
lf[454]=C_h_intern(&lf[454],15,"foreign-declare");
lf[455]=C_h_intern(&lf[455],7,"declare");
lf[456]=C_h_intern(&lf[456],34,"\010compilerscan-sharp-greater-string");
lf[457]=C_h_intern(&lf[457],18,"\003sysread-char/port");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[459]=C_h_intern(&lf[459],17,"get-output-string");
lf[460]=C_h_intern(&lf[460],18,"open-output-string");
lf[461]=C_h_intern(&lf[461],35,"\010compilerprocess-custom-declaration");
lf[462]=C_h_intern(&lf[462],29,"\010compilercustom-declare-alist");
lf[463]=C_h_intern(&lf[463],31,"\010compileremit-control-file-item");
lf[464]=C_h_intern(&lf[464],25,"\010compilercsc-control-file");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\004~S~%");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\006#%csc\012");
lf[467]=C_h_intern(&lf[467],26,"pathname-replace-extension");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[469]=C_h_intern(&lf[469],32,"\010compilerregister-compiler-macro");
lf[470]=C_h_intern(&lf[470],29,"\010compilercompiler-macro-table");
lf[471]=C_h_intern(&lf[471],4,"eval");
lf[472]=C_h_intern(&lf[472],6,"\000whole");
lf[473]=C_h_intern(&lf[473],7,"call/cc");
lf[474]=C_h_intern(&lf[474],11,"make-vector");
lf[475]=C_h_intern(&lf[475],27,"condition-property-accessor");
lf[476]=C_h_intern(&lf[476],3,"exn");
lf[477]=C_h_intern(&lf[477],7,"message");
lf[478]=C_h_intern(&lf[478],19,"condition-predicate");
C_register_lf2(lf,479,create_ptable());
t2=C_mutate(&lf[0] /* c3239 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3677 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3680 in k3677 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3683 in k3680 in k3677 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=C_mutate(&lf[2] /* constant50 ...) */,lf[3]);
t3=C_mutate((C_word*)lf[4]+1 /* compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3697,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[5] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(lf[6] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t6=C_mutate((C_word*)lf[7]+1 /* bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3702,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[12]+1 /* debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3729,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[22]+1 /* compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3769,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[27]+1 /* quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3798,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[30]+1 /* syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3817,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[36]+1 /* syntax-error ...) */,*((C_word*)lf[30]+1));
t12=C_mutate((C_word*)lf[37]+1 /* emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3842,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[38]+1 /* map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3845,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[39]+1 /* check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3888,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[42]+1 /* posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3956,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[43]+1 /* stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3992,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[47]+1 /* symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4013,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[50]+1 /* build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4038,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[51]+1 /* string->c-identifier ...) */,C_retrieve(lf[52]));
t20=C_mutate((C_word*)lf[53]+1 /* c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4082,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[62]+1 /* valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4176,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[65]+1 /* words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4232,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[66]+1 /* words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4239,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[67]+1 /* check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4246,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[74]+1 /* close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4293,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[77]+1 /* fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4305,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[79]+1 /* follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4368,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1 /* constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4399,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[82]+1 /* collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4445,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1 /* immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4475,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[85]+1 /* basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4521,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[88]+1 /* canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4581,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 284  condition-predicate");
t34=C_retrieve(lf[478]);
((C_proc3)C_retrieve_proc(t34))(3,t34,t33,lf[476]);}

/* k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 285  condition-property-accessor");
t3=C_retrieve(lf[475]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[476],lf[477]);}

/* k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word ab[150],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1 /* string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[107]+1 /* decompose-lambda-list ...) */,C_retrieve(lf[108]));
t4=C_mutate((C_word*)lf[109]+1 /* process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4789,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[110]+1 /* expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4792,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[120]+1 /* initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4933,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[133]+1 /* get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4994,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[135]+1 /* get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5012,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[121]+1 /* put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5030,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[138]+1 /* collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5076,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[139]+1 /* count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5128,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[140]+1 /* get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5185,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[142]+1 /* get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5195,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[143]+1 /* find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5231,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[145]+1 /* display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5255,tmp=(C_word)a,a+=2,tmp));
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_mutate((C_word*)lf[150]+1 /* display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5274,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[196]+1 /* make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5704,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[198]+1 /* node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5710,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[199]+1 /* node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5716,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[201]+1 /* node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5725,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[202]+1 /* node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5734,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[203]+1 /* node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5743,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[204]+1 /* node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5752,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[205]+1 /* node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5761,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[196]+1 /* make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5770,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[206]+1 /* varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5776,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[208]+1 /* qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5791,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[209]+1 /* build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5806,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[244]+1 /* build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6410,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[258]+1 /* fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6743,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[260]+1 /* inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6797,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[265]+1 /* copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6910,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[268]+1 /* tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7131,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[270]+1 /* copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7165,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[271]+1 /* match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7242,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[274]+1 /* expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7462,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[278]+1 /* simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7563,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[279]+1 /* dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7685,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[280]+1 /* check-global-exports ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7716,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[286]+1 /* toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7760,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[289]+1 /* compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7782,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[292]+1 /* print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7868,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[301]+1 /* pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7907,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[307]+1 /* foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7943,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[386]+1 /* foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8990,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[387]+1 /* foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9021,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[388]+1 /* final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9052,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[390]+1 /* estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9092,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[396]+1 /* estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9411,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[399]+1 /* finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9721,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[410]+1 /* scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10013,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[411]+1 /* scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10106,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[413]+1 /* topological-sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10280,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[415]+1 /* chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10477,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[418]+1 /* chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10506,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[419]+1 /* print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10548,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[424]+1 /* print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10586,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[426]+1 /* make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10598,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[428]+1 /* block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10604,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[429]+1 /* block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10610,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[430]+1 /* make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10619,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[434]+1 /* set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10663,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[41]+1 /* real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10669,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[437]+1 /* real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10748,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[438]+1 /* display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10760,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[440]+1 /* source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10772,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[446]+1 /* string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10818,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[447]+1 /* dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10824,tmp=(C_word)a,a+=2,tmp));
t71=C_retrieve(lf[453]);
t72=C_mutate((C_word*)lf[453]+1 /* user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10926,a[2]=t71,tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[456]+1 /* scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10959,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[461]+1 /* process-custom-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11028,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[463]+1 /* emit-control-file-item ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11091,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[469]+1 /* register-compiler-macro ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11120,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[84]+1 /* big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11255,tmp=(C_word)a,a+=2,tmp));
t78=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t78+1)))(2,t78,C_SCHEME_UNDEFINED);}

/* ##compiler#big-fixnum? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11255,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11120,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11124,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[470]))){
t6=t5;
f_11124(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11253,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1422 make-vector");
t7=*((C_word*)lf[474]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k11251 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[470]+1 /* compiler-macro-table ...) */,t1);
t3=((C_word*)t0)[2];
f_11124(t3,t2);}

/* k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_11124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11124,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1423 call/cc");
t3=*((C_word*)lf[473]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11129,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11133,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 1425 gensym");
t4=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11133,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11136,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11193,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_11193(t8,t4,((C_word*)t0)[2]);}

/* loop in k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_11193(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11193,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[472],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11209,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=t5;
f_11209(2,t7,C_SCHEME_UNDEFINED);}
else{
C_trace("support.scm: 1431 return");
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11237,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
C_trace("support.scm: 1434 loop");
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11235 in loop in k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11237,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11207 in loop in k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cddr(((C_word*)t0)[4]));}

/* k11134 in k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11139,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11143,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11191,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11189 in k11134 in k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11191,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[115],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[148],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t3,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[116],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[115],t10);
C_trace("support.scm: 1438 eval");
t12=C_retrieve(lf[471]);
((C_proc3)C_retrieve_proc(t12))(3,t12,((C_word*)t0)[2],t11);}

/* k11141 in k11134 in k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1435 ##sys#hash-table-set!");
t2=C_retrieve(lf[137]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[470]),((C_word*)t0)[2],t1);}

/* k11137 in k11134 in k11131 in a11128 in k11122 in ##compiler#register-compiler-macro in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#emit-control-file-item in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11091,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11095,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[464]))){
t4=t3;
f_11095(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11102,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11118,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1408 pathname-replace-extension");
t6=C_retrieve(lf[467]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[234]),lf[468]);}}

/* k11116 in ##compiler#emit-control-file-item in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1408 open-output-file");
t2=*((C_word*)lf[305]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k11100 in ##compiler#emit-control-file-item in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11102,2,t0,t1);}
t2=C_mutate((C_word*)lf[464]+1 /* csc-control-file ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1409 display");
t4=*((C_word*)lf[19]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[466],C_retrieve(lf[464]));}

/* k11103 in k11100 in ##compiler#emit-control-file-item in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11105,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate((C_word*)lf[4]+1 /* compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11107,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
f_11095(t4,t3);}

/* ##compiler#compiler-cleanup-hook in k11103 in k11100 in ##compiler#emit-control-file-item in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11111,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1413 close-output-port");
t3=*((C_word*)lf[302]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[464]));}

/* k11109 in ##compiler#compiler-cleanup-hook in k11103 in k11100 in ##compiler#emit-control-file-item in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1414 old");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k11093 in ##compiler#emit-control-file-item in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_11095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1415 fprintf");
t2=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[464]),lf[465],((C_word*)t0)[2]);}

/* ##compiler#process-custom-declaration in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11028,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cdddr(t2);
t8=(C_word)C_a_i_cons(&a,2,t4,t5);
t9=(C_word)C_i_assoc(t8,C_retrieve(lf[462]));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11050,a[2]=t3,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t11)[1])){
t13=t12;
f_11050(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11065,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t12,a[7]=t11,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
C_trace("support.scm: 1395 open-output-file");
t14=*((C_word*)lf[305]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t6);}}

/* k11063 in ##compiler#process-custom-declaration in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11065,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[462]));
t5=C_mutate((C_word*)lf[462]+1 /* custom-declare-alist ...) */,t4);
t6=*((C_word*)lf[4]+1);
t7=C_mutate((C_word*)lf[4]+1 /* compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11075,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11089,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1403 cons*");
t9=C_retrieve(lf[250]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11087 in k11063 in ##compiler#process-custom-declaration in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1403 emit-control-file-item");
t2=C_retrieve(lf[463]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_11075 in k11063 in ##compiler#process-custom-declaration in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11079,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1401 close-output-port");
t3=*((C_word*)lf[302]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k11077 */
static void C_ccall f_11079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1402 old");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k11048 in ##compiler#process-custom-declaration in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11050,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=*((C_word*)lf[19]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11058,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* a11054 in k11048 in ##compiler#process-custom-declaration in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11058,3,t0,t1,t2);}
C_trace("g349234933499");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10959,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10963,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1365 open-output-string");
t4=C_retrieve(lf[460]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10963,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10968,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10968(t5,((C_word*)t0)[2]);}

/* loop in k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10968,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("read-char/port");
t3=C_retrieve(lf[457]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10970 in loop in k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10972,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
C_trace("support.scm: 1368 quit");
t2=*((C_word*)lf[27]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],lf[458]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10990,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1370 newline");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("read-char/port");
t3=C_retrieve(lf[457]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11023,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[448]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11021 in k10970 in loop in k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1382 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_10968(t2,((C_word*)t0)[2]);}

/* k11000 in k10970 in loop in k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11002,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
C_trace("support.scm: 1375 get-output-string");
t3=C_retrieve(lf[459]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11014,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[448]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11012 in k11000 in k10970 in loop in k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[448]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11015 in k11012 in k11000 in k10970 in loop in k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_11017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1379 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_10968(t2,((C_word*)t0)[2]);}

/* k10988 in k10970 in loop in k10961 in ##compiler#scan-sharp-greater-string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1371 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_10968(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10926,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10936,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("read-char/port");
t6=C_retrieve(lf[457]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
C_trace("support.scm: 1362 old-hook");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k10934 in ##sys#user-read-hook in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10939,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1360 scan-sharp-greater-string");
t3=C_retrieve(lf[456]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10937 in k10934 in ##sys#user-read-hook in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10939,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[454],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[455],t4));}

/* ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10824,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10828,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10833,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10833(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10833,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10837,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10920,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_10920 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10920,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10840,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10915,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_10915 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10915,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10843,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10910,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10910 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10910,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("support.scm: 1338 make-string");
t3=*((C_word*)lf[444]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_make_character(32));}

/* k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10846,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10852,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 1340 printf");
t4=C_retrieve(lf[15]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,lf[452],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10855,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10904 in k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10905,3,t0,t1,t2);}
C_trace("loop3361");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10833(t3,t1,((C_word*)t0)[2],t2);}

/* k10853 in k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10855,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10870,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
C_trace("support.scm: 1344 printf");
t6=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[451],t5);}
else{
t4=t3;
f_10861(2,t4,C_SCHEME_UNDEFINED);}}

/* k10868 in k10853 in k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10873,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10878,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10878(t6,t2,C_fix(5));}

/* doloop3391 in k10868 in k10853 in k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10878(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10878,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10888,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
C_trace("support.scm: 1347 printf");
t5=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[450],t4);}}

/* k10886 in doloop3391 in k10868 in k10853 in k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10878(t3,((C_word*)t0)[2],t2);}

/* k10871 in k10868 in k10853 in k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[448]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[449]+1));}

/* k10859 in k10853 in k10850 in k10844 in k10841 in k10838 in k10835 in loop in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[448]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[449]+1));}

/* k10826 in ##compiler#dump-nodes in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1350 newline");
t2=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10818,3,t0,t1,t2);}
C_trace("support.scm: 1328 string-null?");
t3=C_retrieve(lf[446]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* ##compiler#source-info->string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10772,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10791,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1321 ->string");
t7=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
if(C_truep(t2)){
C_trace("support.scm: 1323 ->string");
t3=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k10789 in ##compiler#source-info->string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10798,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
C_trace("support.scm: 1322 max");
t6=*((C_word*)lf[445]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_fix(0),t5);}

/* k10800 in k10789 in ##compiler#source-info->string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1322 make-string");
t2=*((C_word*)lf[444]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k10796 in k10789 in ##compiler#source-info->string in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1322 conc");
t2=C_retrieve(lf[441]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[442],((C_word*)t0)[3],t1,lf[443],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10766,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 1311 ##sys#hash-table-for-each");
t3=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[435]));}

/* a10765 in ##compiler#display-real-name-table in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10766,4,t0,t1,t2,t3);}
C_trace("support.scm: 1313 printf");
t4=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[439],t2,t3);}

/* ##compiler#real-name2 in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10748,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10752,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1307 ##sys#hash-table-ref");
t5=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[435]),t2);}

/* k10750 in ##compiler#real-name2 in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 1308 real-name");
t2=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10669(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10669r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10669r(t0,t1,t2,t3);}}

static void C_ccall f_10669r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10672,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10688,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1291 resolve");
f_10672(t5,t2);}

/* k10686 in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10688,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1295 ##sys#symbol->qualified-string");
t5=C_retrieve(lf[235]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}
else{
C_trace("support.scm: 1304 ##sys#symbol->qualified-string");
t3=C_retrieve(lf[235]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}
else{
C_trace("support.scm: 1292 ##sys#symbol->qualified-string");
t3=C_retrieve(lf[235]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k10711 in k10686 in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10717,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1296 get");
t3=C_retrieve(lf[133]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[144]);}

/* k10715 in k10711 in k10686 in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10717,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10719,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10719(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10715 in k10711 in k10686 in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10719(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10719,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 1298 resolve");
f_10672(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k10724 in loop in k10715 in k10711 in k10686 in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10726,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10739,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1301 sprintf");
t4=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[436],((C_word*)t0)[4],t1);}}

/* k10737 in k10724 in loop in k10715 in k10711 in k10686 in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10743,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1302 get");
t3=C_retrieve(lf[133]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[144]);}

/* k10741 in k10737 in k10724 in loop in k10715 in k10711 in k10686 in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1301 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10719(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10672(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10672,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10676,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1286 ##sys#hash-table-ref");
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[435]),t2);}

/* k10674 in resolve in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10676,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10682,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1288 ##sys#hash-table-ref");
t3=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[435]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k10680 in k10674 in resolve in ##compiler#real-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10663,4,t0,t1,t2,t3);}
C_trace("support.scm: 1282 ##sys#hash-table-set!");
t4=C_retrieve(lf[137]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[435]),t2,t3);}

/* ##compiler#make-random-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10619(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_10619r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10619r(t0,t1,t2);}}

static void C_ccall f_10619r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10627,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10631,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("support.scm: 1269 gensym");
t5=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_10631(2,t6,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[423]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k10629 in ##compiler#make-random-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10635,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1270 current-seconds");
t3=C_retrieve(lf[433]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10633 in k10629 in ##compiler#make-random-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10639,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1271 random");
t3=C_retrieve(lf[432]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1000));}

/* k10637 in k10633 in k10629 in ##compiler#make-random-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1268 sprintf");
t2=C_retrieve(lf[45]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[431],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10625 in ##compiler#make-random-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1267 string->symbol");
t2=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10610,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[427]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10604,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[427]));}

/* ##compiler#make-block-variable-literal in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10598,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[427],t2));}

/* ##compiler#print-usage in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10590,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1158 print-version");
t3=C_retrieve(lf[419]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10588 in ##compiler#print-usage in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10593,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1159 newline");
t3=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10591 in k10588 in ##compiler#print-usage in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1160 display");
t2=*((C_word*)lf[19]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[425]);}

/* ##compiler#print-version in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_10548r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10548r(t0,t1,t2);}}

static void C_ccall f_10548r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10552,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_10552(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_10552(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[423]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k10550 in ##compiler#print-version in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10555,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
C_trace("support.scm: 1154 print*");
t3=*((C_word*)lf[422]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[3]);}
else{
t3=t2;
f_10555(2,t3,C_SCHEME_UNDEFINED);}}

/* k10553 in k10550 in ##compiler#print-version in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10562,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1155 chicken-version");
t3=C_retrieve(lf[421]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k10560 in k10553 in k10550 in ##compiler#print-version in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1155 print");
t2=*((C_word*)lf[420]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10506,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10515,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10515(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10515,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
C_trace("support.scm: 1147 substring");
t6=*((C_word*)lf[416]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
C_trace("support.scm: 1148 loop");
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10477,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10487,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_10487(t7,(C_word)C_i_memq(t6,lf[417]));}
else{
t6=t5;
f_10487(t6,C_SCHEME_FALSE);}}

/* k10485 in ##compiler#chop-separator in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 1140 substring");
t2=*((C_word*)lf[416]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10280,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10289,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10336,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10371,a[2]=t8,a[3]=t9,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10408,a[2]=t2,a[3]=t9,a[4]=t11,a[5]=t7,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10459,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_cdr(t2);
C_trace("for-each");
t16=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t13,t14,t15);}}

/* a10458 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10459,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
C_trace("support.scm: 1122 insert");
t5=((C_word*)t0)[2];
f_10289(t5,t1,t3,t4);}

/* k10406 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10453,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1125 caar");
t4=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k10451 in k10406 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10457,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1125 cdar");
t3=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10455 in k10451 in k10406 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1125 visit");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10371(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10409 in k10406 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10414,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("for-each");
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a10415 in k10409 in k10406 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10416,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10420,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
C_trace("support.scm: 1127 lookup");
t5=((C_word*)t0)[2];
f_10336(t5,t3,t4);}

/* k10418 in a10415 in k10409 in k10406 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,lf[414]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 1129 visit");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10371(t5,((C_word*)t0)[4],t3,t4);}}

/* k10412 in k10409 in k10406 in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* visit in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10371(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10371,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10375,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("support.scm: 1110 insert");
t5=((C_word*)t0)[2];
f_10289(t5,t4,t2,lf[414]);}

/* k10373 in visit in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10378,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10383 in k10373 in visit in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10384,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10388,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1113 lookup");
t4=((C_word*)t0)[2];
f_10336(t4,t3,t2);}

/* k10386 in a10383 in k10373 in visit in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[414]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
C_trace("support.scm: 1115 visit");
t4=((C_word*)((C_word*)t0)[3])[1];
f_10371(t4,((C_word*)t0)[4],((C_word*)t0)[2],t3);}}

/* k10376 in k10373 in visit in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10336(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10336,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10342,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10342(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in lookup in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10342,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10355,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10369,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1105 caar");
t5=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k10367 in loop in lookup in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1105 pred");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10353 in loop in lookup in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 1105 cdar");
t2=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 1106 loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_10342(t3,((C_word*)t0)[4],t2);}}

/* insert in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10289(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10289,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10295,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_10295(t7,t1,((C_word*)((C_word*)t0)[3])[1]);}

/* loop in insert in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10295,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10334,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1099 caar");
t5=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k10332 in loop in insert in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1099 pred");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10314 in loop in insert in ##compiler#topological-sort in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_cdr(t2,((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("support.scm: 1100 loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_10295(t3,((C_word*)t0)[4],t2);}}

/* ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10106,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10109,a[2]=t8,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10265,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10278,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1082 walk");
t12=((C_word*)t6)[1];
f_10109(t12,t11,t2,C_SCHEME_END_OF_LIST);}

/* k10276 in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10265,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10271,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10270 in walkeach in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10271,3,t0,t1,t2);}
C_trace("support.scm: 1080 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10109(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10109(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10109,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10113,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10259,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10259 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10259,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10254,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10254 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10254,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10249,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10249 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10249,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10119,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[81]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_10128(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[213]);
if(C_truep(t4)){
t5=t3;
f_10128(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[221]);
if(C_truep(t5)){
t6=t3;
f_10128(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[224]);
t7=t3;
f_10128(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[237])));}}}}

/* k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10128,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[207]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[6]))){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10147,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1064 lset-adjoin");
t5=C_retrieve(lf[412]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[267]+1),((C_word*)((C_word*)t0)[5])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[225]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10159,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[6]))){
t6=t5;
f_10159(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10173,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1067 lset-adjoin");
t7=C_retrieve(lf[412]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,*((C_word*)lf[267]+1),((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[91]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10182,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("support.scm: 1070 walk");
t7=((C_word*)((C_word*)t0)[3])[1];
f_10109(t7,t5,t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[220]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10212,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1073 decompose-lambda-list");
t8=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[9],t6,t7);}
else{
C_trace("support.scm: 1077 walkeach");
t6=((C_word*)((C_word*)t0)[2])[1];
f_10265(t6,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[6]);}}}}}}

/* a10211 in k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10212,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10224,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1076 append");
t7=*((C_word*)lf[56]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10222 in a10211 in k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1076 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10109(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10180 in k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10182,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10193,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1071 append");
t4=*((C_word*)lf[56]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10191 in k10180 in k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1071 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10109(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10171 in k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10159(t3,t2);}

/* k10157 in k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("support.scm: 1068 walk");
t3=((C_word*)((C_word*)t0)[4])[1];
f_10109(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10145 in k10126 in k10117 in k10114 in k10111 in walk in ##compiler#scan-free-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10013,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10017,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10019,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10019(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10019,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10023,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10100,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10100 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10100,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10095,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10095 in k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10095,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10024 in k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10026,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[207]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[225]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10066,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_eqp(t1,lf[81]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10079,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_10079(t6,t4);}
else{
t6=(C_word)C_eqp(t1,lf[213]);
t7=t5;
f_10079(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[221])));}}}

/* k10077 in k10024 in k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
C_trace("for-each");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* f_10066 in k10024 in k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10066,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10063 in k10024 in k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10065,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10041,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10047,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_10047(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_10047(t5,C_SCHEME_FALSE);}}

/* k10045 in k10063 in k10024 in k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10047,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10041(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10041(t2,C_SCHEME_UNDEFINED);}}

/* k10039 in k10063 in k10024 in k10021 in walk in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_10041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10015 in ##compiler#scan-used-variables in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_10017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[116],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9721,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[330]);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[81],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[400],t9));}
else{
t6=(C_word)C_eqp(t4,lf[333]);
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[401],t10));}
else{
t7=(C_word)C_eqp(t4,lf[348]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[349]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[81],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[402],t12));}
else{
t9=(C_word)C_eqp(t4,lf[346]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t4,lf[347]));
if(C_truep(t10)){
t11=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[81],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t3,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[403],t14));}
else{
t11=(C_word)C_eqp(t4,lf[334]);
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[81],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[400],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[404],t17));}
else{
t12=(C_word)C_eqp(t4,lf[350]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[81],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_cons(&a,2,lf[405],t16));}
else{
t13=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[81],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[406],t17));}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9917,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t15=(C_word)C_i_length(t2);
t16=(C_word)C_eqp(C_fix(3),t15);
if(C_truep(t16)){
t17=(C_word)C_i_car(t2);
t18=t14;
f_9917(t18,(C_word)C_i_memq(t17,lf[409]));}
else{
t17=t14;
f_9917(t17,C_SCHEME_FALSE);}}
else{
t15=t14;
f_9917(t15,C_SCHEME_FALSE);}}}}}}}}}

/* k9915 in ##compiler#finish-foreign-result in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9917,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[407],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_9938(t6,(C_word)C_eqp(lf[341],t5));}
else{
t5=t2;
f_9938(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_9938(t3,C_SCHEME_FALSE);}}}

/* k9936 in k9915 in ##compiler#finish-foreign-result in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9938,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[339],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[81],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[408],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9411,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9414,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9423,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9715,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 990  follow-without-loop");
t6=*((C_word*)lf[79]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a9714 in ##compiler#estimate-foreign-result-location-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9715,2,t0,t1);}
C_trace("support.scm: 1011 quit");
t2=*((C_word*)lf[27]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[398],((C_word*)t0)[2]);}

/* a9422 in ##compiler#estimate-foreign-result-location-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9423,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[308]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9433,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_9433(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[312]);
if(C_truep(t7)){
t8=t6;
f_9433(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t8)){
t9=t6;
f_9433(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[392]);
if(C_truep(t9)){
t10=t6;
f_9433(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t10)){
t11=t6;
f_9433(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[309]);
if(C_truep(t11)){
t12=t6;
f_9433(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t12)){
t13=t6;
f_9433(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t13)){
t14=t6;
f_9433(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t14)){
t15=t6;
f_9433(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t15)){
t16=t6;
f_9433(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t16)){
t17=t6;
f_9433(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[327]);
if(C_truep(t17)){
t18=t6;
f_9433(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[316]);
if(C_truep(t18)){
t19=t6;
f_9433(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[329]);
if(C_truep(t19)){
t20=t6;
f_9433(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[325]);
if(C_truep(t20)){
t21=t6;
f_9433(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[323]);
if(C_truep(t21)){
t22=t6;
f_9433(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[314]);
if(C_truep(t22)){
t23=t6;
f_9433(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[330]);
if(C_truep(t23)){
t24=t6;
f_9433(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[334]);
if(C_truep(t24)){
t25=t6;
f_9433(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t25)){
t26=t6;
f_9433(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[370]);
if(C_truep(t26)){
t27=t6;
f_9433(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[383]);
if(C_truep(t27)){
t28=t6;
f_9433(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[384]);
if(C_truep(t28)){
t29=t6;
f_9433(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t29)){
t30=t6;
f_9433(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[352]);
if(C_truep(t30)){
t31=t6;
f_9433(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t31)){
t32=t6;
f_9433(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[347]);
if(C_truep(t32)){
t33=t6;
f_9433(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[333]);
if(C_truep(t33)){
t34=t6;
f_9433(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[348]);
if(C_truep(t34)){
t35=t6;
f_9433(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[346]);
if(C_truep(t35)){
t36=t6;
f_9433(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[350]);
t37=t6;
f_9433(t37,(C_truep(t36)?t36:(C_word)C_eqp(t4,lf[351])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k9431 in a9422 in ##compiler#estimate-foreign-result-location-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9433,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("support.scm: 999  words->bytes");
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[377]));
if(C_truep(t3)){
C_trace("support.scm: 1001 words->bytes");
t4=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[6],C_fix(2));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("support.scm: 1003 ##sys#hash-table-ref");
t5=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[345]),((C_word*)t0)[3]);}
else{
t5=t4;
f_9451(2,t5,C_SCHEME_FALSE);}}}}

/* k9449 in k9431 in a9422 in ##compiler#estimate-foreign-result-location-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9451,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("support.scm: 1005 next");
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[336]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_9485(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[318]);
if(C_truep(t5)){
t6=t4;
f_9485(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t6)){
t7=t4;
f_9485(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[327]);
if(C_truep(t7)){
t8=t4;
f_9485(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[329]);
t9=t4;
f_9485(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[344])));}}}}}
else{
C_trace("support.scm: 1010 err");
f_9414(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k9483 in k9449 in k9431 in a9422 in ##compiler#estimate-foreign-result-location-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 1008 words->bytes");
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(1));}
else{
C_trace("support.scm: 1009 err");
f_9414(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9414(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9414,NULL,2,t1,t2);}
C_trace("support.scm: 989  quit");
t3=*((C_word*)lf[27]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[397],t2);}

/* ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9092,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9098,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 960  follow-without-loop");
t5=*((C_word*)lf[79]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a9404 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9405,2,t0,t1);}
C_trace("support.scm: 985  quit");
t2=*((C_word*)lf[27]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[395],((C_word*)t0)[2]);}

/* a9097 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9098,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[308]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9108,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9108(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[312]);
if(C_truep(t7)){
t8=t6;
f_9108(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t8)){
t9=t6;
f_9108(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[392]);
if(C_truep(t9)){
t10=t6;
f_9108(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[393]);
if(C_truep(t10)){
t11=t6;
f_9108(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t11)){
t12=t6;
f_9108(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[394]);
if(C_truep(t12)){
t13=t6;
f_9108(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[309]);
if(C_truep(t13)){
t14=t6;
f_9108(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t14)){
t15=t6;
f_9108(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t15)){
t16=t6;
f_9108(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t16)){
t17=t6;
f_9108(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[383]);
t18=t6;
f_9108(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[384])));}}}}}}}}}}}}

/* k9106 in a9097 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9108,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[330]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9117(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[333]);
if(C_truep(t4)){
t5=t3;
f_9117(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[327]);
if(C_truep(t5)){
t6=t3;
f_9117(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[329]);
if(C_truep(t6)){
t7=t3;
f_9117(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[334]);
if(C_truep(t7)){
t8=t3;
f_9117(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[348]);
if(C_truep(t8)){
t9=t3;
f_9117(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[346]);
if(C_truep(t9)){
t10=t3;
f_9117(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t10)){
t11=t3;
f_9117(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
if(C_truep(t11)){
t12=t3;
f_9117(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[350]);
t13=t3;
f_9117(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[4],lf[351])));}}}}}}}}}}}

/* k9115 in k9106 in a9097 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9117,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("support.scm: 970  words->bytes");
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[325]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9129(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[354]);
if(C_truep(t4)){
t5=t3;
f_9129(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[323]);
if(C_truep(t5)){
t6=t3;
f_9129(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t6)){
t7=t3;
f_9129(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
t8=t3;
f_9129(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[352])));}}}}}}

/* k9127 in k9115 in k9106 in a9097 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9129,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("support.scm: 972  words->bytes");
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],C_fix(4));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[314]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9141(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t4)){
t5=t3;
f_9141(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
t6=t3;
f_9141(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[391])));}}}}

/* k9139 in k9127 in k9115 in k9106 in a9097 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9141,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("support.scm: 974  words->bytes");
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],C_fix(4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
C_trace("support.scm: 976  ##sys#hash-table-ref");
t3=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[345]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9147(2,t3,C_SCHEME_FALSE);}}}

/* k9145 in k9139 in k9127 in k9115 in k9106 in a9097 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9147,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("support.scm: 978  next");
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[336]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9181,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9181(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[318]);
if(C_truep(t5)){
t6=t4;
f_9181(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t6)){
t7=t4;
f_9181(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[327]);
if(C_truep(t7)){
t8=t4;
f_9181(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[329]);
if(C_truep(t8)){
t9=t4;
f_9181(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t9)){
t10=t4;
f_9181(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t10)){
t11=t4;
f_9181(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[338]);
t12=t4;
f_9181(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[341])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9179 in k9145 in k9139 in k9127 in k9115 in k9106 in a9097 in ##compiler#estimate-foreign-result-size in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 982  words->bytes");
t2=*((C_word*)lf[66]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9052,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9058,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9086,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 947  follow-without-loop");
t5=*((C_word*)lf[79]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t2,t3,t4);}

/* a9085 in ##compiler#final-foreign-type in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
C_trace("support.scm: 954  quit");
t2=*((C_word*)lf[27]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[389],((C_word*)t0)[2]);}

/* a9057 in ##compiler#final-foreign-type in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9058,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9062,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("support.scm: 950  ##sys#hash-table-ref");
t5=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[345]),t2);}
else{
t5=t4;
f_9062(2,t5,C_SCHEME_FALSE);}}

/* k9060 in a9057 in ##compiler#final-foreign-type in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("support.scm: 952  next");
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9021,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9025,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9034,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 941  ##sys#hash-table-ref");
t6=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[345]),t3);}
else{
t5=t4;
f_9025(t5,C_SCHEME_FALSE);}}

/* k9032 in ##compiler#foreign-type-convert-argument in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9034,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9025(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9025(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9025(t2,C_SCHEME_FALSE);}}

/* k9023 in ##compiler#foreign-type-convert-argument in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_9025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8990,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8994,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9003,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 934  ##sys#hash-table-ref");
t6=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_retrieve(lf[345]),t3);}
else{
t5=t4;
f_8994(t5,C_SCHEME_FALSE);}}

/* k9001 in ##compiler#foreign-type-convert-result in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9003,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_8994(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_8994(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8994(t2,C_SCHEME_FALSE);}}

/* k8992 in ##compiler#foreign-type-convert-result in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7943,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7949,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8984,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 835  follow-without-loop");
t6=*((C_word*)lf[79]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,t4,t5);}

/* a8983 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8984,2,t0,t1);}
C_trace("support.scm: 927  quit");
t2=*((C_word*)lf[27]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[385],((C_word*)t0)[2]);}

/* a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7949,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7955,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7955(t7,t1,t2);}

/* repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7955,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[308]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[309]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[310]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[311],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[312]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7984(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[378]);
if(C_truep(t8)){
t9=t7;
f_7984(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[379]);
if(C_truep(t9)){
t10=t7;
f_7984(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[380]);
if(C_truep(t10)){
t11=t7;
f_7984(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[381]);
if(C_truep(t11)){
t12=t7;
f_7984(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[382]);
if(C_truep(t12)){
t13=t7;
f_7984(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[383]);
t14=t7;
f_7984(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[384])));}}}}}}}}

/* k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7984,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[310]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[313],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[314]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8003(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_8003(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8003(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8003,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[310]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[315],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[316]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8022(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[373]);
if(C_truep(t4)){
t5=t3;
f_8022(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t6=t3;
f_8022(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}}

/* k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8022,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8025,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 845  gensym");
t3=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[318]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8092(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[370]);
if(C_truep(t4)){
t5=t3;
f_8092(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[371]);
t6=t3;
f_8092(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[372])));}}}}

/* k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8092,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[310]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[317],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[319]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8111(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[363]);
if(C_truep(t4)){
t5=t3;
f_8111(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[364]);
if(C_truep(t5)){
t6=t3;
f_8111(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[365]);
if(C_truep(t6)){
t7=t3;
f_8111(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[366]);
if(C_truep(t7)){
t8=t3;
f_8111(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[367]);
if(C_truep(t8)){
t9=t3;
f_8111(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[368]);
t10=t3;
f_8111(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[369])));}}}}}}}}

/* k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8111,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8114,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 857  gensym");
t3=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[321]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8193(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
if(C_truep(t4)){
t5=t3;
f_8193(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[357]);
if(C_truep(t5)){
t6=t3;
f_8193(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[358]);
if(C_truep(t6)){
t7=t3;
f_8193(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t7)){
t8=t3;
f_8193(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t8)){
t9=t3;
f_8193(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[361]);
t10=t3;
f_8193(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[362])));}}}}}}}}

/* k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8193,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[310]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[322]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[320],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[323]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8232(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[354]);
t5=t3;
f_8232(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[355])));}}}

/* k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8232,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[310]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[324],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[325]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8251(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[352]);
t5=t3;
f_8251(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[353])));}}}

/* k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8251,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[310]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[326],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[327]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8270(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[350]);
t5=t3;
f_8270(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[351])));}}}

/* k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8270,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8273,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 877  gensym");
t3=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[329]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[328],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[330]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8350(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[348]);
t6=t4;
f_8350(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[349])));}}}}

/* k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8350(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8350,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8353,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 885  gensym");
t3=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[333]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8435(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[346]);
t5=t3;
f_8435(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[347])));}}}

/* k8433 in k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8435,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[310]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[331],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[332],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[331],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[334]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[310]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[335],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[331],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[335],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[332],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[331],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("support.scm: 901  ##sys#hash-table-ref");
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[345]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8510(2,t4,C_SCHEME_FALSE);}}}}

/* k8508 in k8433 in k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8510,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("support.scm: 903  next");
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[336]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8544(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t5)){
t6=t4;
f_8544(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[344]);
t7=t4;
f_8544(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[327])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k8542 in k8508 in k8433 in k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8544,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8547,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 907  gensym");
t3=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[337]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[338]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8614,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 913  gensym");
t5=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[341]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[339],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[340],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[342]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("support.scm: 920  repeat");
t7=((C_word*)((C_word*)t0)[2])[1];
f_7955(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[343]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[310]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[324],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[318]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[329]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[328],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k8612 in k8542 in k8508 in k8433 in k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8614,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[339],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[340],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[81],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[212],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[91],t17));}

/* k8545 in k8542 in k8508 in k8433 in k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8547,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[328],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[212],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[91],t14));}

/* k8351 in k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8353,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8384,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[310]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8384(t7,(C_word)C_a_i_cons(&a,2,lf[331],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[332],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_8384(t9,(C_word)C_a_i_cons(&a,2,lf[331],t8));}}

/* k8382 in k8351 in k8348 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8384,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[212],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* k8271 in k8268 in k8249 in k8230 in k8191 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8273,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[328],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[212],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[91],t14));}

/* k8112 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8114,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8145,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[310]))){
t6=t5;
f_8145(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[81],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8145(t10,(C_word)C_a_i_cons(&a,2,lf[320],t9));}}

/* k8143 in k8112 in k8109 in k8090 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8145,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[212],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* k8023 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_8025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8056,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[310]))){
t6=t5;
f_8056(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8056(t7,(C_word)C_a_i_cons(&a,2,lf[317],t6));}}

/* k8054 in k8023 in k8020 in k8001 in k7982 in repeat in a7948 in ##compiler#foreign-type-check in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_8056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8056,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[212],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* ##compiler#pprint-expressions-to-file in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7907,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7911,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
C_trace("support.scm: 816  open-output-file");
t5=*((C_word*)lf[305]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
C_trace("support.scm: 816  current-output-port");
t5=*((C_word*)lf[306]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k7909 in ##compiler#pprint-expressions-to-file in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7914,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 817  with-output-to-port");
t4=C_retrieve(lf[304]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}

/* a7921 in k7909 in ##compiler#pprint-expressions-to-file in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7928,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a7927 in a7921 in k7909 in ##compiler#pprint-expressions-to-file in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7928,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7932,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 821  pretty-print");
t4=C_retrieve(lf[303]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7930 in a7927 in a7921 in k7909 in ##compiler#pprint-expressions-to-file in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 822  newline");
t2=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k7912 in k7909 in ##compiler#pprint-expressions-to-file in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("support.scm: 824  close-output-port");
t2=*((C_word*)lf[302]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7868,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7874,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7880,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* a7879 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7880,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7887,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("support.scm: 804  debugging");
t10=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,lf[299],lf[300]);}

/* k7885 in a7879 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7887,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7890,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
C_trace("support.scm: 805  printf");
t3=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[298],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7888 in k7885 in a7879 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 806  printf");
t3=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[297],((C_word*)t0)[2]);}

/* k7891 in k7888 in k7885 in a7879 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 807  printf");
t3=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[296],((C_word*)t0)[2]);}

/* k7894 in k7891 in k7888 in k7885 in a7879 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 808  printf");
t3=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[295],((C_word*)t0)[2]);}

/* k7897 in k7894 in k7891 in k7888 in k7885 in a7879 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 809  printf");
t3=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[294],((C_word*)t0)[2]);}

/* k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in a7879 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 810  printf");
t2=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[293],((C_word*)t0)[2]);}

/* a7873 in ##compiler#print-program-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7874,2,t0,t1);}
C_trace("support.scm: 803  compute-database-statistics");
t2=C_retrieve(lf[289]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7782,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7786,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7791,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 779  ##sys#hash-table-for-each");
t15=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,t2);}

/* a7790 in ##compiler#compute-database-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7791,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("for-each");
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a7796 in a7790 in ##compiler#compute-database-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7797,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[178]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[160]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7839,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cdr(t2);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7844,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t8=(C_word)C_eqp(t5,lf[166]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* f_7844 in a7796 in a7790 in ##compiler#compute-database-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7844,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7837 in a7796 in a7790 in ##compiler#compute-database-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[220],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7784 in ##compiler#compute-database-statistics in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 793  values");
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[290]),C_retrieve(lf[291]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7760,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7770,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 755  debugging");
t8=*((C_word*)lf[12]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[242],lf[288],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k7768 in ##sys#toplevel-definition-hook in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7770,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[287]));
t3=C_mutate((C_word*)lf[287]+1 /* block-globals ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* check-global-exports in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7716,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[281]))){
t3=C_retrieve(lf[281]);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7723,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7734,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 741  ##sys#hash-table-for-each");
t7=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7733 in check-global-exports in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7734,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7738,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7745,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t6=(C_word)C_i_assq(lf[176],t3);
t7=t5;
f_7745(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7745(t6,C_SCHEME_FALSE);}}

/* k7743 in a7733 in check-global-exports in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 744  compiler-warning");
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[282],lf[285],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7738(2,t2,C_SCHEME_UNDEFINED);}}

/* k7736 in a7733 in check-global-exports in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 745  delete");
t3=C_retrieve(lf[284]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[267]+1));}

/* k7740 in k7736 in a7733 in check-global-exports in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7721 in check-global-exports in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7728,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a7727 in k7721 in check-global-exports in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7728,3,t0,t1,t2);}
C_trace("##compiler#compiler-warning");
t3=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[282],lf[283],t2);}

/* ##compiler#dump-undefined-globals in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7685,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7691,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 730  ##sys#hash-table-for-each");
t4=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* a7690 in ##compiler#dump-undefined-globals in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7691,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7698,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[178],t3))){
t5=(C_word)C_i_assq(lf[176],t3);
t6=t4;
f_7698(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_7698(t5,C_SCHEME_FALSE);}}

/* k7696 in a7690 in ##compiler#dump-undefined-globals in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7698,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7701,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 734  write");
t3=*((C_word*)lf[192]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7699 in k7696 in a7690 in ##compiler#dump-undefined-globals in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 735  newline");
t2=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7563,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7567,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7679,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7679 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7679,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7567,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
if(C_truep((C_word)C_i_cadr(t1))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7587(3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7587,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7591,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7668,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7668 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7668,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7591,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[232]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7645,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(t1,lf[223]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7663,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}}

/* f_7663 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7663,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7660 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 724  every");
t2=C_retrieve(lf[86]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* f_7645 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7645,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7598 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7639,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7640,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7640 in k7598 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7640,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7637 in k7598 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7639,2,t0,t1);}
t2=(C_word)C_eqp(lf[207],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7631,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_7631 in k7637 in k7598 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7631,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7628 in k7637 in k7598 in k7589 in rec in k7565 in ##compiler#simple-lambda-node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 722  every");
t5=C_retrieve(lf[86]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7462,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7468,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7468(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7468,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7472,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7557,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7557 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7557,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7475,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7552,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_7552 in k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7552,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7473 in k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7475,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[207]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7484(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[81]);
if(C_truep(t4)){
t5=t3;
f_7484(t5,t4);}
else{
t5=(C_word)C_eqp(t1,lf[213]);
if(C_truep(t5)){
t6=t3;
f_7484(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[224]);
t7=t3;
f_7484(t7,(C_truep(t6)?t6:(C_word)C_eqp(t1,lf[211])));}}}}

/* k7482 in k7473 in k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7484,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[220]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7510,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7511,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[212]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[91]));
if(C_truep(t4)){
C_trace("support.scm: 706  any");
t5=C_retrieve(lf[63]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* f_7511 in k7482 in k7473 in k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7511,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7508 in k7482 in k7473 in k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7510,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7498,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 705  find");
t4=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t3,C_retrieve(lf[277]));}

/* a7497 in k7508 in k7482 in k7473 in k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7498,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 705  foreign-callback-stub-id");
t4=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7504 in a7497 in k7508 in k7482 in k7473 in k7470 in walk in ##compiler#expression-has-side-effects? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7242,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7245,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7274,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7317,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7436,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 689  matchn");
t15=((C_word*)t12)[1];
f_7317(t15,t14,t2,t3);}

/* k7434 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7436,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7442,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7456,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7456 in k7434 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7456,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7444 in k7434 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7450,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7451,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7451 in k7444 in k7434 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7451,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7448 in k7444 in k7434 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 692  debugging");
t2=*((C_word*)lf[12]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[272],lf[273],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7440 in k7434 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7317(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7317,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
C_trace("support.scm: 678  resolve");
t4=((C_word*)t0)[4];
f_7245(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7424,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7429,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* f_7429 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7429,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7424,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7411,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7416,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_7416 in k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7416,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7409 in k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("support.scm: 680  match1");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7274(t3,((C_word*)t0)[2],t1,t2);}

/* k7337 in k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7339,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7403,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7403 in k7337 in k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7403,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7344 in k7337 in k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7346,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7352,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7352(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k7344 in k7337 in k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7352(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7352,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
C_trace("support.scm: 684  resolve");
t4=((C_word*)t0)[4];
f_7245(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7383,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
C_trace("support.scm: 686  matchn");
t7=((C_word*)((C_word*)t0)[2])[1];
f_7317(t7,t4,t5,t6);}}}}

/* k7381 in loop in k7344 in k7337 in k7422 in matchn in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 687  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_7352(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7274(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7274,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
C_trace("support.scm: 671  resolve");
t4=((C_word*)t0)[3];
f_7245(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7296,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
C_trace("support.scm: 673  match1");
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7294 in match1 in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 673  match1");
t4=((C_word*)((C_word*)t0)[3])[1];
f_7274(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7245(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7245,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7269,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 666  alist-cons");
t6=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7267 in resolve in ##compiler#match-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7165,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7169,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7235,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7236,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_7236 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7236,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7233 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 648  node-class-set!");
t2=C_retrieve(lf[199]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7227,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7227 in k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7227,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7224 in k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 649  node-parameters-set!");
t2=C_retrieve(lf[202]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7170 in k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7217,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7218,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_7218 in k7170 in k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7218,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k7215 in k7170 in k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 650  node-subexpressions-set!");
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7173 in k7170 in k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7175,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7186(t4,C_fix(4)));}

/* doloop1553 in k7173 in k7170 in k7167 in ##compiler#copy-node! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static C_word C_fcall f_7186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:(C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]));
if(C_truep(t3)){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t1);
t5=(C_word)C_i_setslot(((C_word*)t0)[2],t1,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}

/* ##compiler#tree-copy in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7131,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7137,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7137(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_7137(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7137,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
C_trace("support.scm: 644  rec");
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7149 in rec in ##compiler#tree-copy in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7155,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 644  rec");
t4=((C_word*)((C_word*)t0)[2])[1];
f_7137(t4,t2,t3);}

/* k7153 in k7149 in rec in ##compiler#tree-copy in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7155,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6910,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6914,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 612  map");
t6=*((C_word*)lf[247]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[269]+1),t3,t4);}

/* k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6916,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6922,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
C_trace("support.scm: 639  walk");
t6=((C_word*)t4)[1];
f_6922(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6922(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6922,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6926,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7122,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7122 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7122,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6929,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7117,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7117 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7117,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7112,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_7112 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7112,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6932,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6945,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
C_trace("support.scm: 619  rename");
f_6916(t3,t4,((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(t1,lf[225]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
C_trace("support.scm: 620  rename");
f_6916(t4,t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(t1,lf[91]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6997,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 623  gensym");
t7=C_retrieve(lf[92]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t5=(C_word)C_eqp(t1,lf[220]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 627  decompose-lambda-list");
t8=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[7],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 638  tree-copy");
t7=C_retrieve(lf[268]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}}}}}

/* k7094 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7100,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7106 in k7094 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7107,3,t0,t1,t2);}
C_trace("walk1428");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6922(t3,t1,t2,((C_word*)t0)[2]);}

/* k7098 in k7094 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7101,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7101 in k7098 in k7094 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7101,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7037,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
C_trace("map");
t6=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[92]),t2);}

/* k7039 in a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("support.scm: 631  append");
t3=*((C_word*)lf[56]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k7042 in k7039 in a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7044,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7078,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7086,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("support.scm: 635  rename");
f_6916(t5,((C_word*)t0)[3],t1);}
else{
t6=t5;
f_7086(2,t6,C_SCHEME_FALSE);}}

/* k7084 in k7042 in k7039 in a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 635  build-lambda-list");
t2=*((C_word*)lf[50]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7076 in k7042 in k7039 in a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7078,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7055,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t6=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7061 in k7076 in k7042 in k7039 in a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7062,3,t0,t1,t2);}
C_trace("walk1428");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6922(t3,t1,t2,((C_word*)t0)[2]);}

/* k7053 in k7076 in k7042 in k7039 in a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7056,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[220],((C_word*)t0)[2],t1);}

/* f_7056 in k7053 in k7076 in k7042 in k7039 in a7036 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7056,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6995 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 624  alist-cons");
t3=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6998 in k6995 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7000,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7011,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7018,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7017 in k6998 in k6995 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7018,3,t0,t1,t2);}
C_trace("walk1428");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6922(t3,t1,t2,((C_word*)t0)[2]);}

/* k7009 in k6998 in k6995 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7012,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[91],((C_word*)t0)[2],t1);}

/* f_7012 in k7009 in k6998 in k6995 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7012,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6979 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6981,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6966,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6972 in k6979 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6973,3,t0,t1,t2);}
C_trace("walk1428");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6922(t3,t1,t2,((C_word*)t0)[2]);}

/* k6964 in k6979 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6967,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[225],((C_word*)t0)[2],t1);}

/* f_6967 in k6964 in k6979 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6967,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6943 in k6930 in k6927 in k6924 in walk in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 619  varnode");
t2=C_retrieve(lf[206]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* rename in k6912 in ##compiler#copy-node-tree-and-rename in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6916(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6916,NULL,3,t1,t2,t3);}
C_trace("support.scm: 613  alist-ref");
t4=C_retrieve(lf[266]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,t2,t3,*((C_word*)lf[267]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6797,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6803,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 590  decompose-lambda-list");
t7=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}

/* a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6803,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6809,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6815,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t5,t6);}

/* a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6815,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("map");
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[92]),((C_word*)t0)[2]);}
else{
t5=t4;
f_6819(2,t5,((C_word*)t0)[2]);}}

/* k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6822,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("support.scm: 596  copy-node-tree-and-rename");
t3=C_retrieve(lf[265]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_6822(2,t3,((C_word*)t0)[3]);}}

/* k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6827,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6902,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 602  last");
t5=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_6848(2,t4,t1);}}

/* k6900 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6902,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6872,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
C_trace("support.scm: 604  qnode");
t4=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[264],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6886,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[230],t6,((C_word*)t0)[2]);}}

/* f_6886 in k6900 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6886,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6870 in k6900 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6872,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6864,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[91],((C_word*)t0)[2],t2);}

/* f_6864 in k6870 in k6900 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6864,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6846 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 608  take");
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6850 in k6846 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 598  fold-right");
t2=C_retrieve(lf[262]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6826 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6827,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6840,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[91],t5,t6);}

/* f_6840 in a6826 in k6820 in k6817 in a6814 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6840,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* a6808 in a6802 in ##compiler#inline-lambda-bindings in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
C_trace("support.scm: 593  split-at");
t2=C_retrieve(lf[261]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6743,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6749,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6749(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6749,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
C_trace("support.scm: 586  proc");
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k6773 in fold in ##compiler#fold-boolean in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6779,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 587  fold");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6749(t4,t2,t3);}

/* k6777 in k6773 in fold in ##compiler#fold-boolean in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6767,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[222],lf[259],t2);}

/* f_6767 in k6777 in k6773 in fold in ##compiler#fold-boolean in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6767,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6410,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6416,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6416(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6416,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6420,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6737,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_6737 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6737,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6732,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_6732 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6732,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6426,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6727,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_6727 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6727,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[212]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6435(t4,t2);}
else{
t4=(C_word)C_eqp(t1,lf[256]);
t5=t3;
f_6435(t5,(C_truep(t4)?t4:(C_word)C_eqp(t1,lf[257])));}}

/* k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6435,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6442,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[245]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6459,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6463,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[207]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[211]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[81]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[81],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 560  butlast");
t10=C_retrieve(lf[249]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[220]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[115]:lf[220]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6550,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("support.scm: 567  walk");
t13=((C_word*)((C_word*)t0)[4])[1];
f_6416(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[232]);
if(C_truep(t8)){
C_trace("map");
t9=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[223]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6583,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t12=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[213]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[251]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6607,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6607(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[252]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6669,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_6669(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[253]);
if(C_truep(t14)){
t15=t13;
f_6669(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[254]);
t16=t13;
f_6669(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[255])));}}}}}}}}}}}}}

/* k6667 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6669,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("support.scm: 577  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6416(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k6697 in k6667 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 578  append");
t2=*((C_word*)lf[56]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6693 in k6667 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6695,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6674 in k6667 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6680,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("map");
t4=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k6678 in k6674 in k6667 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 577  cons*");
t2=C_retrieve(lf[250]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6607,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 574  reverse");
t7=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6656,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
C_trace("support.scm: 575  walk");
t10=((C_word*)((C_word*)t0)[3])[1];
f_6416(3,t10,t8,t9);}}

/* k6654 in loop in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6656,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
C_trace("support.scm: 575  loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_6607(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6623 in loop in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6633,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("support.scm: 574  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6416(3,t4,t2,t3);}

/* k6631 in k6623 in loop in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[251],t3));}

/* k6581 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 569  cons*");
t2=C_retrieve(lf[250]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[223],((C_word*)t0)[2],t1);}

/* k6548 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6527 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6523 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 560  map");
t2=*((C_word*)lf[247]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[248]+1),((C_word*)t0)[2],t1);}

/* k6507 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6521,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 561  last");
t4=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6519 in k6507 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 561  walk");
t2=((C_word*)((C_word*)t0)[3])[1];
f_6416(3,t2,((C_word*)t0)[2],t1);}

/* k6515 in k6507 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6517,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[91],t3));}

/* k6461 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6457 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6459,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[245],t2));}

/* k6440 in k6433 in k6424 in k6421 in k6418 in walk in ##compiler#build-expression-tree in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6442,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5806,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5809,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6405,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 544  walk");
t9=((C_word*)t6)[1];
f_5809(3,t9,t8,t2);}

/* k6403 in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6408,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 545  debugging");
t3=*((C_word*)lf[12]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[242],lf[243],((C_word*)((C_word*)t0)[2])[1]);}

/* k6406 in k6403 in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word *a;
loop:
a=C_alloc(77);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_5809,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("support.scm: 478  varnode");
t3=C_retrieve(lf[206]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
C_trace("support.scm: 479  bomb");
t3=*((C_word*)lf[7]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[210],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[211]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5851,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[211],t7,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(t4,lf[212]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[213]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
C_trace("map");
t11=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[81]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5904,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5907,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[217],C_retrieve(lf[218]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_5907(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_5907(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5907(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[91]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("support.scm: 499  walk");
t65=t1;
t66=t11;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5961,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 500  unzip1");
t13=C_retrieve(lf[219]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[115]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[220]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6025,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
C_trace("support.scm: 504  walk");
t65=t14;
t66=t15;
t1=t65;
t2=t66;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[221]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6073,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6073(t17,(C_word)C_eqp(lf[81],t16));}
else{
t16=t15;
f_6073(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[222]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[223]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6110,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
C_trace("map");
t20=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[224]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6137,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,lf[224],t17,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t4,lf[225]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[226]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6165,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
C_trace("map");
t22=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[227]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6227,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
C_trace("support.scm: 523  fifth");
t26=C_retrieve(lf[229]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[230]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6248,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6248(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[237]);
if(C_truep(t21)){
t22=t20;
f_6248(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[238]);
if(C_truep(t22)){
t23=t20;
f_6248(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[239]);
t24=t20;
f_6248(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[240])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6393,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6391 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6394,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[232],lf[241],t1);}

/* f_6394 in k6391 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6394,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6263,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
C_trace("map");
t6=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[231]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
C_trace("map");
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6299,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6304 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6305,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6326,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[236])))){
t5=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t4;
f_6326(t7,C_SCHEME_TRUE);}
else{
t5=t4;
f_6326(t5,C_SCHEME_FALSE);}}

/* k6324 in a6304 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6326,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 539  real-name");
t4=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
C_trace("support.scm: 541  ##sys#symbol->qualified-string");
t3=C_retrieve(lf[235]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6331 in k6324 in a6304 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6340(2,t3,t1);}
else{
C_trace("support.scm: 540  ##sys#symbol->qualified-string");
t3=C_retrieve(lf[235]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6338 in k6331 in k6324 in a6304 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6340,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6330(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[234]),((C_word*)t0)[2],t1));}

/* k6328 in k6324 in a6304 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6317,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6315 in k6328 in k6324 in a6304 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6318,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[232],((C_word*)t0)[2],t1);}

/* f_6318 in k6315 in k6328 in k6324 in a6304 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6318,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* a6298 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
C_trace("support.scm: 531  get-line-2");
t2=C_retrieve(lf[142]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k6283 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6286,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[232],lf[233],t1);}

/* f_6286 in k6283 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6286,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6261 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6264,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6264 in k6261 in k6246 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6264,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6225 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6227,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6207,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6211,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 524  sixth");
t6=C_retrieve(lf[228]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6209 in k6225 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 524  walk");
t2=((C_word*)((C_word*)t0)[3])[1];
f_5809(3,t2,((C_word*)t0)[2],t1);}

/* k6205 in k6225 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6199,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[227],((C_word*)t0)[2],t2);}

/* f_6199 in k6205 in k6225 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6199,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6163 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6166,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[225],((C_word*)t0)[2],t1);}

/* f_6166 in k6163 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6166,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* f_6137 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6137,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6108 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6111,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6111 in k6108 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6111,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6071 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_6073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6073,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6057,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("map");
t6=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6055 in k6071 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6058,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6058 in k6055 in k6071 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6058,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k6023 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6025,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6017,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[115],((C_word*)t0)[2],t2);}

/* f_6017 in k6023 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6017,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k5959 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5965,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("map");
t6=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5983 in k5959 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5984,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
C_trace("support.scm: 501  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5809(3,t4,t1,t3);}

/* k5972 in k5959 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5982,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 502  walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_5809(3,t3,t2,((C_word*)t0)[2]);}

/* k5980 in k5972 in k5959 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5982,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("support.scm: 501  append");
t3=*((C_word*)lf[56]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5963 in k5959 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5966,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[91],((C_word*)t0)[2],t1);}

/* f_5966 in k5963 in k5959 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5966,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* k5905 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5907,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 490  compiler-warning");
t3=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[215],lf[216],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5904(t2,((C_word*)t0)[2]);}}

/* k5908 in k5905 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5917,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 493  truncate");
t3=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5915 in k5908 in k5905 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5904(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k5902 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 486  qnode");
t2=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5877 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5880,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* f_5880 in k5877 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5880,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* f_5851 in walk in ##compiler#build-node-graph in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5851,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* ##compiler#qnode in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5791,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5800,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[81],t3,C_SCHEME_END_OF_LIST);}

/* f_5800 in ##compiler#qnode in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5800,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* ##compiler#varnode in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5776,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5785,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[207],t3,C_SCHEME_END_OF_LIST);}

/* f_5785 in ##compiler#varnode in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5785,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* make-node in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5770,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* node-subexpressions in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5761,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[197]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5752,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[197]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5743,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[197]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5734,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[197]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5725,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[197]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5716,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[197]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5710,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[197]));}

/* f_5704 in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5704,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[197],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5274,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5278,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5278(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5702,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 414  append");
t5=*((C_word*)lf[56]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[193]),C_retrieve(lf[194]),C_retrieve(lf[195]));}}

/* k5700 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5278(t3,t2);}

/* k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5278,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5283,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 417  ##sys#hash-table-for-each");
t3=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5283,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5293,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t11,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("support.scm: 424  write");
t13=*((C_word*)lf[192]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}}

/* k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5403(t6,t2,((C_word*)t0)[2]);}

/* loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5403,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
C_trace("support.scm: 428  caar");
t4=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5416,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[156]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_5429(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[176]);
if(C_truep(t5)){
t6=t4;
f_5429(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[177]);
if(C_truep(t6)){
t7=t4;
f_5429(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[178]);
if(C_truep(t7)){
t8=t4;
f_5429(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[179]);
if(C_truep(t8)){
t9=t4;
f_5429(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[131]);
if(C_truep(t9)){
t10=t4;
f_5429(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[125]);
if(C_truep(t10)){
t11=t4;
f_5429(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t11)){
t12=t4;
f_5429(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[130]);
if(C_truep(t12)){
t13=t4;
f_5429(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t13)){
t14=t4;
f_5429(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t14)){
t15=t4;
f_5429(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t15)){
t16=t4;
f_5429(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t16)){
t17=t4;
f_5429(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t17)){
t18=t4;
f_5429(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t18)){
t19=t4;
f_5429(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t19)){
t20=t4;
f_5429(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t20)){
t21=t4;
f_5429(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t21)){
t22=t4;
f_5429(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[126]);
if(C_truep(t22)){
t23=t4;
f_5429(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t23)){
t24=t4;
f_5429(t24,t23);}
else{
t24=(C_word)C_eqp(t1,lf[122]);
t25=t4;
f_5429(t25,(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[191])));}}}}}}}}}}}}}}}}}}}}}

/* k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5429(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5429,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 432  caar");
t3=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[155]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[155]);
t4=((C_word*)t0)[8];
f_5416(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[160]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[155]);
if(C_truep(t4)){
t5=((C_word*)t0)[8];
f_5416(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 436  cdar");
t6=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[162]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5477,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 438  cdar");
t6=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[163]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5486(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[168]);
if(C_truep(t7)){
t8=t6;
f_5486(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[169]);
if(C_truep(t8)){
t9=t6;
f_5486(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[144]);
if(C_truep(t9)){
t10=t6;
f_5486(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[170]);
if(C_truep(t10)){
t11=t6;
f_5486(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[171]);
if(C_truep(t11)){
t12=t6;
f_5486(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[172]);
if(C_truep(t12)){
t13=t6;
f_5486(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[173]);
if(C_truep(t13)){
t14=t6;
f_5486(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[174]);
t15=t6;
f_5486(t15,(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[6],lf[175])));}}}}}}}}}}}}}

/* k5484 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5486,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 441  caar");
t3=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[165]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 443  cdar");
t4=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[166]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 445  cdar");
t5=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("support.scm: 446  bomb");
t5=*((C_word*)lf[7]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[167],t4);}}}}

/* k5515 in k5484 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5416(2,t3,t2);}

/* k5505 in k5484 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5416(2,t3,t2);}

/* k5491 in k5484 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5497,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 441  cdar");
t3=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5495 in k5491 in k5484 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 441  printf");
t2=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[164],((C_word*)t0)[2],t1);}

/* k5475 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5416(2,t3,t2);}

/* k5465 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5416(2,t3,t2);}

/* k5442 in k5427 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[157]);
t3=(C_word)C_i_cdr(t2);
C_trace("support.scm: 432  printf");
t4=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[158],t3);}

/* k5414 in k5411 in loop in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 447  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_5403(t3,((C_word*)t0)[2],t2);}

/* k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5299,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[155]);
t5=t3;
f_5331(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5331(t4,C_SCHEME_FALSE);}}

/* k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5331,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5352,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[155]);
t4=t2;
f_5362(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5362(t3,C_SCHEME_FALSE);}}}

/* k5360 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5362,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5383,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_5299(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5383 in k5360 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5383,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5371 in k5360 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5378,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5378 in k5371 in k5360 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5378,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5375 in k5371 in k5360 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
C_trace("support.scm: 451  printf");
t3=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[154],t2);}

/* f_5352 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5352,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5340 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5347,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* f_5347 in k5340 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5347,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5344 in k5340 in k5329 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
C_trace("support.scm: 449  printf");
t3=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[153],t2);}

/* k5297 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
C_trace("support.scm: 452  printf");
t4=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[152],t3);}
else{
t3=t2;
f_5302(2,t3,C_SCHEME_UNDEFINED);}}

/* k5300 in k5297 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
C_trace("support.scm: 453  printf");
t4=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[151],t3);}
else{
t3=t2;
f_5305(2,t3,C_SCHEME_UNDEFINED);}}

/* k5303 in k5300 in k5297 in k5294 in k5291 in a5282 in k5276 in ##compiler#display-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 454  newline");
t2=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5261,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 396  ##sys#hash-table-for-each");
t3=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[141]));}

/* a5260 in ##compiler#display-line-number-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5261,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5272,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[148]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5270 in a5260 in ##compiler#display-line-number-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 398  printf");
t2=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[146],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5231,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5237,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5237(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5237(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5237,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 392  get");
t5=C_retrieve(lf[133]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[144]);}}

/* k5245 in loop in ##compiler#find-lambda-container in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 393  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_5237(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5195,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5202,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 384  ##sys#hash-table-ref");
t5=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[141]),t3);}

/* k5200 in ##compiler#get-line-2 in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5205(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5205(t3,C_SCHEME_FALSE);}}

/* k5203 in k5200 in ##compiler#get-line-2 in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_5205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
C_trace("support.scm: 386  values");
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
C_trace("support.scm: 387  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5185,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
C_trace("support.scm: 380  get");
t4=C_retrieve(lf[133]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[141]),t3,t2);}

/* ##compiler#count! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5128r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5128r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5128r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5132,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 368  ##sys#hash-table-ref");
t7=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k5130 in ##compiler#count! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5132,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5162,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
C_trace("support.scm: 373  alist-cons");
t7=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("support.scm: 374  ##sys#hash-table-set!");
t6=C_retrieve(lf[137]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5160 in k5130 in ##compiler#count! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5076,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5080,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 360  ##sys#hash-table-ref");
t7=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k5078 in ##compiler#collect! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5080,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
C_trace("support.scm: 364  alist-cons");
t6=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
C_trace("support.scm: 365  ##sys#hash-table-set!");
t4=C_retrieve(lf[137]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5105 in k5078 in ##compiler#collect! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5030,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5034,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 352  ##sys#hash-table-ref");
t7=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k5032 in ##compiler#put! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5056,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
C_trace("support.scm: 356  alist-cons");
t5=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
C_trace("support.scm: 357  ##sys#hash-table-set!");
t4=C_retrieve(lf[137]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5054 in k5032 in ##compiler#put! in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5012r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5012r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5012r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5016,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 346  ##sys#hash-table-ref");
t6=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5014 in ##compiler#get-all in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5024,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 348  filter-map");
t3=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5023 in k5014 in ##compiler#get-all in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5024,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4994,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4998,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 340  ##sys#hash-table-ref");
t6=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k4996 in ##compiler#get in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4933,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4937,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[132]));}

/* a4969 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 326  put!");
t4=C_retrieve(lf[121]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[131],C_SCHEME_TRUE);}

/* k4972 in a4969 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[129])))){
C_trace("support.scm: 327  put!");
t3=C_retrieve(lf[121]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[130],C_SCHEME_TRUE);}
else{
t3=t2;
f_4977(2,t3,C_SCHEME_UNDEFINED);}}

/* k4975 in k4972 in a4969 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[128])))){
C_trace("support.scm: 328  put!");
t2=C_retrieve(lf[121]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[125],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4935 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[127]));}

/* a4954 in k4935 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4955,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 332  put!");
t4=C_retrieve(lf[121]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],t2,lf[126],C_SCHEME_TRUE);}

/* k4957 in a4954 in k4935 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[124])))){
C_trace("support.scm: 333  put!");
t2=C_retrieve(lf[121]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4],lf[125],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4938 in k4935 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4945,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[123]));}

/* a4944 in k4938 in k4935 in ##compiler#initialize-analysis-database in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4945,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
C_trace("support.scm: 336  put!");
t4=C_retrieve(lf[121]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t3,lf[122],C_SCHEME_TRUE);}

/* ##compiler#expand-profile-lambda in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4792,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[111]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4796,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 308  gensym");
t7=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k4794 in ##compiler#expand-profile-lambda in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 309  alist-cons");
t3=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[112]));}

/* k4798 in k4794 in ##compiler#expand-profile-lambda in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4800,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1 /* profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[111]+1 /* profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[113]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[114],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[115],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[115],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[116],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[115],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[81],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[113]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[117],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[115],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[118],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[115],t35));}

/* ##compiler#process-lambda-documentation in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4789,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4682,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4689,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("call-with-current-continuation");
t5=*((C_word*)lf[106]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4691,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4697,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4722,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("with-exception-handler");
t5=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a4775 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4776r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4776r(t0,t1,t2);}}

static void C_ccall f_4776r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("k573579");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4781 in a4775 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4782,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4727 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4732,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4760,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 293  with-input-from-string");
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a4759 in a4727 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4766,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4774,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 293  read");
t4=*((C_word*)lf[100]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4772 in a4759 in a4727 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 293  unfold");
t2=C_retrieve(lf[101]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],*((C_word*)lf[102]+1),*((C_word*)lf[103]+1),((C_word*)t0)[2],t1);}

/* a4765 in a4759 in a4727 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4766,3,t0,t1,t2);}
C_trace("support.scm: 293  read");
t3=*((C_word*)lf[100]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k4730 in a4727 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[97]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4752 in k4730 in a4727 in a4721 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4754,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[98],t1));}

/* a4696 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4697,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("k573579");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4702 in a4696 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4714,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 290  exn?");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4712 in a4702 in a4696 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 291  exn-msg");
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("support.scm: 292  ->string");
t2=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4709 in a4702 in a4696 in a4690 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 288  quit");
t2=*((C_word*)lf[27]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[96],((C_word*)t0)[2],t1);}

/* k4687 in ##compiler#string->expr in k4679 in k4676 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4581,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4587,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4587(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4587(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4587,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[89]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[90]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4615,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4615(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4664,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 277  constant?");
t8=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}}}

/* k4662 in loop in ##compiler#canonicalize-begin-body in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4615(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[94])));}

/* k4613 in loop in ##compiler#canonicalize-begin-body in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4615,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 279  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_4587(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 280  gensym");
t3=C_retrieve(lf[92]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[93]);}}

/* k4651 in k4613 in loop in ##compiler#canonicalize-begin-body in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 281  loop");
t8=((C_word*)((C_word*)t0)[2])[1];
f_4587(t8,t6,t7);}

/* k4639 in k4651 in k4613 in loop in ##compiler#canonicalize-begin-body in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[91],t3));}

/* ##compiler#basic-literal? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4521,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 262  constant?");
t6=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}

/* k4535 in ##compiler#basic-literal? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 263  vector->list");
t4=*((C_word*)lf[87]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4543(2,t3,C_SCHEME_FALSE);}}}

/* k4577 in k4535 in ##compiler#basic-literal? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 263  every");
t2=C_retrieve(lf[86]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[85]+1),t1);}

/* k4541 in k4535 in ##compiler#basic-literal? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("support.scm: 265  basic-literal?");
t4=*((C_word*)lf[85]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4556 in k4541 in k4535 in ##compiler#basic-literal? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 266  basic-literal?");
t3=*((C_word*)lf[85]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4475,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4479,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4519,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 252  big-fixnum?");
t5=C_retrieve(lf[84]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t3;
f_4479(t4,C_SCHEME_FALSE);}}

/* k4517 in ##compiler#immediate? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4479(t2,(C_word)C_i_not(t1));}

/* k4477 in ##compiler#immediate? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4445,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4399,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[81],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#follow-without-loop in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4368,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4374,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4374(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4374(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4374,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
C_trace("support.scm: 230  abort");
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 231  proc");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4388 in loop in ##compiler#follow-without-loop in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4389,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
C_trace("support.scm: 231  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_4374(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4305,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4319,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 220  reverse");
t6=*((C_word*)lf[78]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k4317 in ##compiler#fold-inner in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4321,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4321(t5,((C_word*)t0)[2],t1);}

/* fold in k4317 in ##compiler#fold-inner in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4321,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4329(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4350,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
C_trace("support.scm: 225  fold");
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4348 in fold in k4317 in ##compiler#fold-inner in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4329(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4327 in fold in k4317 in ##compiler#fold-inner in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4293,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[75]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("support.scm: 215  close-input-port");
t4=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4246r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4246r(t0,t1,t2,t3);}}

static void C_ccall f_4246r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[68]))){
C_trace("support.scm: 209  current-input-port");
t4=*((C_word*)lf[69]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4262,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 210  file-exists?");
t5=C_retrieve(lf[73]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k4260 in ##compiler#check-and-open-input-file in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
if(C_truep(t1)){
C_trace("support.scm: 210  open-input-file");
t2=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4274(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4274(t5,(C_word)C_i_not(t4));}}}

/* k4272 in k4260 in ##compiler#check-and-open-input-file in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 211  quit");
t2=*((C_word*)lf[27]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[71],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
C_trace("support.scm: 212  quit");
t3=*((C_word*)lf[27]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],lf[72],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4239,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub332(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4232,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub327(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4180,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4230,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 190  ->string");
t5=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4228 in ##compiler#valid-c-identifier? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->list");
t2=C_retrieve(lf[58]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4178 in ##compiler#valid-c-identifier? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4203,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
C_trace("support.scm: 194  any");
t7=C_retrieve(lf[63]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4202 in k4178 in ##compiler#valid-c-identifier? in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4203,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4094,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4098,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("string->list");
t5=C_retrieve(lf[58]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4098,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4100,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4100(t5,((C_word*)t0)[2],t1);}

/* loop in k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4100(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4100,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[55]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4122,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4122(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4122(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[61])));}}}

/* k4120 in loop in k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4122,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4129(t3,lf[59]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4129(t4,(C_truep(t3)?lf[60]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("support.scm: 187  loop");
t4=((C_word*)((C_word*)t0)[4])[1];
f_4100(t4,t2,t3);}}

/* k4159 in k4120 in loop in k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4161,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4127 in k4120 in loop in k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4129,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4145,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 185  number->string");
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4143 in k4127 in k4120 in loop in k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->list");
t2=C_retrieve(lf[58]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4131 in k4127 in k4120 in loop in k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4137,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 186  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_4100(t4,t2,t3);}

/* k4135 in k4131 in k4127 in k4120 in loop in k4096 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 181  append");
t2=*((C_word*)lf[56]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[57],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4092 in ##compiler#c-ify-string in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
C_trace("list->string");
t3=C_retrieve(lf[54]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4038,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4044,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4044(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_4044(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4044,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4068,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
C_trace("support.scm: 167  loop");
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4066 in loop in ##compiler#build-lambda-list in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4013,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
C_trace("support.scm: 161  string->symbol");
t3=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 162  sprintf");
t4=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[49],t2);}}}

/* k4034 in ##compiler#symbolify in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 162  string->symbol");
t2=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3992,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("support.scm: 156  symbol->string");
t3=*((C_word*)lf[44]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
C_trace("support.scm: 157  sprintf");
t3=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[46],t2);}}}

/* ##compiler#posq in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3956,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3962(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static C_word C_fcall f_3962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3888,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3912,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3912(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_3912(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3912,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("support.scm: 140  err");
t4=((C_word*)t0)[3];
f_3891(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("support.scm: 142  err");
t5=((C_word*)t0)[3];
f_3891(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
C_trace("support.scm: 143  loop");
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_3891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3891,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 137  real-name");
t3=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3897 in err in ##compiler#check-signature in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3903,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("support.scm: 138  map-llist");
t4=*((C_word*)lf[38]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve(lf[41]),t3);}

/* k3901 in k3897 in err in ##compiler#check-signature in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 136  quit");
t2=*((C_word*)lf[27]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[40],((C_word*)t0)[2],t1);}

/* map-llist in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3845,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3851,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3851(t7,t1,t3);}

/* loop in map-llist in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_3851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3851,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("support.scm: 131  proc");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
C_trace("support.scm: 132  proc");
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k3872 in loop in map-llist in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3878,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 132  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_3851(t4,t2,t3);}

/* k3876 in k3872 in loop in map-llist in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3842,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[32])));}

/* ##sys#syntax-error-hook in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3817r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3817r(t0,t1,t2,t3);}}

static void C_ccall f_3817r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3821,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 117  current-error-port");
t5=C_retrieve(lf[25]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3819 in ##sys#syntax-error-hook in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 118  fprintf");
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[35],((C_word*)t0)[2]);}

/* k3822 in k3819 in ##sys#syntax-error-hook in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3834 in k3822 in k3819 in ##sys#syntax-error-hook in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3835,3,t0,t1,t2);}
C_trace("fprintf");
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],lf[34],t2);}

/* k3825 in k3822 in k3819 in ##sys#syntax-error-hook in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 120  print-call-chain");
t3=C_retrieve(lf[31]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[32]),lf[33]);}

/* k3828 in k3825 in k3822 in k3819 in ##sys#syntax-error-hook in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 121  exit");
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3798r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3798r(t0,t1,t2,t3);}}

static void C_ccall f_3798r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3802,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 110  current-error-port");
t5=C_retrieve(lf[25]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3800 in quit in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3805,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 111  string-append");
t4=*((C_word*)lf[9]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[29],((C_word*)t0)[2]);}

/* k3813 in k3800 in quit in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[23]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3803 in k3800 in quit in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 112  newline");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3806 in k3803 in k3800 in quit in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 113  exit");
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3769r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3769r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3769r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3776,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[26]))){
t6=(C_word)C_i_memq(t2,*((C_word*)lf[6]+1));
t7=t5;
f_3776(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3776(t6,C_SCHEME_FALSE);}}

/* k3774 in ##compiler#compiler-warning in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_fcall f_3776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3776,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 105  current-error-port");
t3=C_retrieve(lf[25]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3777 in k3774 in ##compiler#compiler-warning in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3782,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 106  string-append");
t4=*((C_word*)lf[9]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[24],((C_word*)t0)[2]);}

/* k3787 in k3777 in k3774 in ##compiler#compiler-warning in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[23]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3780 in k3777 in k3774 in ##compiler#compiler-warning in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 107  newline");
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3729r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3729r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3729r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,*((C_word*)lf[5]+1)))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3739,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 94   printf");
t6=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[21],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3737 in ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 97   display");
t4=*((C_word*)lf[19]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[20]);}
else{
t3=t2;
f_3742(2,t3,C_SCHEME_UNDEFINED);}}

/* k3752 in k3737 in ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3759,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3758 in k3752 in k3737 in ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3759,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3767,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 98   force");
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3765 in a3758 in k3752 in k3737 in ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 98   printf");
t2=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[16],t1);}

/* k3740 in k3737 in ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 99   newline");
t3=*((C_word*)lf[14]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3743 in k3740 in k3737 in ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 100  flush-output");
t3=*((C_word*)lf[13]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3746 in k3743 in k3740 in k3737 in ##compiler#debugging in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3702r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3702r(t0,t1,t2);}}

static void C_ccall f_3702r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3716,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
C_trace("support.scm: 88   string-append");
t5=*((C_word*)lf[9]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[10],t4);}
else{
C_trace("support.scm: 89   error");
t3=*((C_word*)lf[8]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[11]);}}

/* k3714 in ##compiler#bomb in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[8]+1),t1,t2);}

/* f_3697 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[621] = {
{"toplevelsupport.scm",(void*)C_support_toplevel},
{"f_3679support.scm",(void*)f_3679},
{"f_3682support.scm",(void*)f_3682},
{"f_3685support.scm",(void*)f_3685},
{"f_3688support.scm",(void*)f_3688},
{"f_3691support.scm",(void*)f_3691},
{"f_3694support.scm",(void*)f_3694},
{"f_4678support.scm",(void*)f_4678},
{"f_4681support.scm",(void*)f_4681},
{"f_11255support.scm",(void*)f_11255},
{"f_11120support.scm",(void*)f_11120},
{"f_11253support.scm",(void*)f_11253},
{"f_11124support.scm",(void*)f_11124},
{"f_11129support.scm",(void*)f_11129},
{"f_11133support.scm",(void*)f_11133},
{"f_11193support.scm",(void*)f_11193},
{"f_11237support.scm",(void*)f_11237},
{"f_11209support.scm",(void*)f_11209},
{"f_11136support.scm",(void*)f_11136},
{"f_11191support.scm",(void*)f_11191},
{"f_11143support.scm",(void*)f_11143},
{"f_11139support.scm",(void*)f_11139},
{"f_11091support.scm",(void*)f_11091},
{"f_11118support.scm",(void*)f_11118},
{"f_11102support.scm",(void*)f_11102},
{"f_11105support.scm",(void*)f_11105},
{"f_11107support.scm",(void*)f_11107},
{"f_11111support.scm",(void*)f_11111},
{"f_11095support.scm",(void*)f_11095},
{"f_11028support.scm",(void*)f_11028},
{"f_11065support.scm",(void*)f_11065},
{"f_11089support.scm",(void*)f_11089},
{"f_11075support.scm",(void*)f_11075},
{"f_11079support.scm",(void*)f_11079},
{"f_11050support.scm",(void*)f_11050},
{"f_11058support.scm",(void*)f_11058},
{"f_10959support.scm",(void*)f_10959},
{"f_10963support.scm",(void*)f_10963},
{"f_10968support.scm",(void*)f_10968},
{"f_10972support.scm",(void*)f_10972},
{"f_11023support.scm",(void*)f_11023},
{"f_11002support.scm",(void*)f_11002},
{"f_11014support.scm",(void*)f_11014},
{"f_11017support.scm",(void*)f_11017},
{"f_10990support.scm",(void*)f_10990},
{"f_10926support.scm",(void*)f_10926},
{"f_10936support.scm",(void*)f_10936},
{"f_10939support.scm",(void*)f_10939},
{"f_10824support.scm",(void*)f_10824},
{"f_10833support.scm",(void*)f_10833},
{"f_10920support.scm",(void*)f_10920},
{"f_10837support.scm",(void*)f_10837},
{"f_10915support.scm",(void*)f_10915},
{"f_10840support.scm",(void*)f_10840},
{"f_10910support.scm",(void*)f_10910},
{"f_10843support.scm",(void*)f_10843},
{"f_10846support.scm",(void*)f_10846},
{"f_10852support.scm",(void*)f_10852},
{"f_10905support.scm",(void*)f_10905},
{"f_10855support.scm",(void*)f_10855},
{"f_10870support.scm",(void*)f_10870},
{"f_10878support.scm",(void*)f_10878},
{"f_10888support.scm",(void*)f_10888},
{"f_10873support.scm",(void*)f_10873},
{"f_10861support.scm",(void*)f_10861},
{"f_10828support.scm",(void*)f_10828},
{"f_10818support.scm",(void*)f_10818},
{"f_10772support.scm",(void*)f_10772},
{"f_10791support.scm",(void*)f_10791},
{"f_10802support.scm",(void*)f_10802},
{"f_10798support.scm",(void*)f_10798},
{"f_10760support.scm",(void*)f_10760},
{"f_10766support.scm",(void*)f_10766},
{"f_10748support.scm",(void*)f_10748},
{"f_10752support.scm",(void*)f_10752},
{"f_10669support.scm",(void*)f_10669},
{"f_10688support.scm",(void*)f_10688},
{"f_10713support.scm",(void*)f_10713},
{"f_10717support.scm",(void*)f_10717},
{"f_10719support.scm",(void*)f_10719},
{"f_10726support.scm",(void*)f_10726},
{"f_10739support.scm",(void*)f_10739},
{"f_10743support.scm",(void*)f_10743},
{"f_10672support.scm",(void*)f_10672},
{"f_10676support.scm",(void*)f_10676},
{"f_10682support.scm",(void*)f_10682},
{"f_10663support.scm",(void*)f_10663},
{"f_10619support.scm",(void*)f_10619},
{"f_10631support.scm",(void*)f_10631},
{"f_10635support.scm",(void*)f_10635},
{"f_10639support.scm",(void*)f_10639},
{"f_10627support.scm",(void*)f_10627},
{"f_10610support.scm",(void*)f_10610},
{"f_10604support.scm",(void*)f_10604},
{"f_10598support.scm",(void*)f_10598},
{"f_10586support.scm",(void*)f_10586},
{"f_10590support.scm",(void*)f_10590},
{"f_10593support.scm",(void*)f_10593},
{"f_10548support.scm",(void*)f_10548},
{"f_10552support.scm",(void*)f_10552},
{"f_10555support.scm",(void*)f_10555},
{"f_10562support.scm",(void*)f_10562},
{"f_10506support.scm",(void*)f_10506},
{"f_10515support.scm",(void*)f_10515},
{"f_10477support.scm",(void*)f_10477},
{"f_10487support.scm",(void*)f_10487},
{"f_10280support.scm",(void*)f_10280},
{"f_10459support.scm",(void*)f_10459},
{"f_10408support.scm",(void*)f_10408},
{"f_10453support.scm",(void*)f_10453},
{"f_10457support.scm",(void*)f_10457},
{"f_10411support.scm",(void*)f_10411},
{"f_10416support.scm",(void*)f_10416},
{"f_10420support.scm",(void*)f_10420},
{"f_10414support.scm",(void*)f_10414},
{"f_10371support.scm",(void*)f_10371},
{"f_10375support.scm",(void*)f_10375},
{"f_10384support.scm",(void*)f_10384},
{"f_10388support.scm",(void*)f_10388},
{"f_10378support.scm",(void*)f_10378},
{"f_10336support.scm",(void*)f_10336},
{"f_10342support.scm",(void*)f_10342},
{"f_10369support.scm",(void*)f_10369},
{"f_10355support.scm",(void*)f_10355},
{"f_10289support.scm",(void*)f_10289},
{"f_10295support.scm",(void*)f_10295},
{"f_10334support.scm",(void*)f_10334},
{"f_10316support.scm",(void*)f_10316},
{"f_10106support.scm",(void*)f_10106},
{"f_10278support.scm",(void*)f_10278},
{"f_10265support.scm",(void*)f_10265},
{"f_10271support.scm",(void*)f_10271},
{"f_10109support.scm",(void*)f_10109},
{"f_10259support.scm",(void*)f_10259},
{"f_10113support.scm",(void*)f_10113},
{"f_10254support.scm",(void*)f_10254},
{"f_10116support.scm",(void*)f_10116},
{"f_10249support.scm",(void*)f_10249},
{"f_10119support.scm",(void*)f_10119},
{"f_10128support.scm",(void*)f_10128},
{"f_10212support.scm",(void*)f_10212},
{"f_10224support.scm",(void*)f_10224},
{"f_10182support.scm",(void*)f_10182},
{"f_10193support.scm",(void*)f_10193},
{"f_10173support.scm",(void*)f_10173},
{"f_10159support.scm",(void*)f_10159},
{"f_10147support.scm",(void*)f_10147},
{"f_10013support.scm",(void*)f_10013},
{"f_10019support.scm",(void*)f_10019},
{"f_10100support.scm",(void*)f_10100},
{"f_10023support.scm",(void*)f_10023},
{"f_10095support.scm",(void*)f_10095},
{"f_10026support.scm",(void*)f_10026},
{"f_10079support.scm",(void*)f_10079},
{"f_10066support.scm",(void*)f_10066},
{"f_10065support.scm",(void*)f_10065},
{"f_10047support.scm",(void*)f_10047},
{"f_10041support.scm",(void*)f_10041},
{"f_10017support.scm",(void*)f_10017},
{"f_9721support.scm",(void*)f_9721},
{"f_9917support.scm",(void*)f_9917},
{"f_9938support.scm",(void*)f_9938},
{"f_9411support.scm",(void*)f_9411},
{"f_9715support.scm",(void*)f_9715},
{"f_9423support.scm",(void*)f_9423},
{"f_9433support.scm",(void*)f_9433},
{"f_9451support.scm",(void*)f_9451},
{"f_9485support.scm",(void*)f_9485},
{"f_9414support.scm",(void*)f_9414},
{"f_9092support.scm",(void*)f_9092},
{"f_9405support.scm",(void*)f_9405},
{"f_9098support.scm",(void*)f_9098},
{"f_9108support.scm",(void*)f_9108},
{"f_9117support.scm",(void*)f_9117},
{"f_9129support.scm",(void*)f_9129},
{"f_9141support.scm",(void*)f_9141},
{"f_9147support.scm",(void*)f_9147},
{"f_9181support.scm",(void*)f_9181},
{"f_9052support.scm",(void*)f_9052},
{"f_9086support.scm",(void*)f_9086},
{"f_9058support.scm",(void*)f_9058},
{"f_9062support.scm",(void*)f_9062},
{"f_9021support.scm",(void*)f_9021},
{"f_9034support.scm",(void*)f_9034},
{"f_9025support.scm",(void*)f_9025},
{"f_8990support.scm",(void*)f_8990},
{"f_9003support.scm",(void*)f_9003},
{"f_8994support.scm",(void*)f_8994},
{"f_7943support.scm",(void*)f_7943},
{"f_8984support.scm",(void*)f_8984},
{"f_7949support.scm",(void*)f_7949},
{"f_7955support.scm",(void*)f_7955},
{"f_7984support.scm",(void*)f_7984},
{"f_8003support.scm",(void*)f_8003},
{"f_8022support.scm",(void*)f_8022},
{"f_8092support.scm",(void*)f_8092},
{"f_8111support.scm",(void*)f_8111},
{"f_8193support.scm",(void*)f_8193},
{"f_8232support.scm",(void*)f_8232},
{"f_8251support.scm",(void*)f_8251},
{"f_8270support.scm",(void*)f_8270},
{"f_8350support.scm",(void*)f_8350},
{"f_8435support.scm",(void*)f_8435},
{"f_8510support.scm",(void*)f_8510},
{"f_8544support.scm",(void*)f_8544},
{"f_8614support.scm",(void*)f_8614},
{"f_8547support.scm",(void*)f_8547},
{"f_8353support.scm",(void*)f_8353},
{"f_8384support.scm",(void*)f_8384},
{"f_8273support.scm",(void*)f_8273},
{"f_8114support.scm",(void*)f_8114},
{"f_8145support.scm",(void*)f_8145},
{"f_8025support.scm",(void*)f_8025},
{"f_8056support.scm",(void*)f_8056},
{"f_7907support.scm",(void*)f_7907},
{"f_7911support.scm",(void*)f_7911},
{"f_7922support.scm",(void*)f_7922},
{"f_7928support.scm",(void*)f_7928},
{"f_7932support.scm",(void*)f_7932},
{"f_7914support.scm",(void*)f_7914},
{"f_7868support.scm",(void*)f_7868},
{"f_7880support.scm",(void*)f_7880},
{"f_7887support.scm",(void*)f_7887},
{"f_7890support.scm",(void*)f_7890},
{"f_7893support.scm",(void*)f_7893},
{"f_7896support.scm",(void*)f_7896},
{"f_7899support.scm",(void*)f_7899},
{"f_7902support.scm",(void*)f_7902},
{"f_7874support.scm",(void*)f_7874},
{"f_7782support.scm",(void*)f_7782},
{"f_7791support.scm",(void*)f_7791},
{"f_7797support.scm",(void*)f_7797},
{"f_7844support.scm",(void*)f_7844},
{"f_7839support.scm",(void*)f_7839},
{"f_7786support.scm",(void*)f_7786},
{"f_7760support.scm",(void*)f_7760},
{"f_7770support.scm",(void*)f_7770},
{"f_7716support.scm",(void*)f_7716},
{"f_7734support.scm",(void*)f_7734},
{"f_7745support.scm",(void*)f_7745},
{"f_7738support.scm",(void*)f_7738},
{"f_7742support.scm",(void*)f_7742},
{"f_7723support.scm",(void*)f_7723},
{"f_7728support.scm",(void*)f_7728},
{"f_7685support.scm",(void*)f_7685},
{"f_7691support.scm",(void*)f_7691},
{"f_7698support.scm",(void*)f_7698},
{"f_7701support.scm",(void*)f_7701},
{"f_7563support.scm",(void*)f_7563},
{"f_7679support.scm",(void*)f_7679},
{"f_7567support.scm",(void*)f_7567},
{"f_7587support.scm",(void*)f_7587},
{"f_7668support.scm",(void*)f_7668},
{"f_7591support.scm",(void*)f_7591},
{"f_7663support.scm",(void*)f_7663},
{"f_7662support.scm",(void*)f_7662},
{"f_7645support.scm",(void*)f_7645},
{"f_7600support.scm",(void*)f_7600},
{"f_7640support.scm",(void*)f_7640},
{"f_7639support.scm",(void*)f_7639},
{"f_7631support.scm",(void*)f_7631},
{"f_7630support.scm",(void*)f_7630},
{"f_7462support.scm",(void*)f_7462},
{"f_7468support.scm",(void*)f_7468},
{"f_7557support.scm",(void*)f_7557},
{"f_7472support.scm",(void*)f_7472},
{"f_7552support.scm",(void*)f_7552},
{"f_7475support.scm",(void*)f_7475},
{"f_7484support.scm",(void*)f_7484},
{"f_7511support.scm",(void*)f_7511},
{"f_7510support.scm",(void*)f_7510},
{"f_7498support.scm",(void*)f_7498},
{"f_7506support.scm",(void*)f_7506},
{"f_7242support.scm",(void*)f_7242},
{"f_7436support.scm",(void*)f_7436},
{"f_7456support.scm",(void*)f_7456},
{"f_7446support.scm",(void*)f_7446},
{"f_7451support.scm",(void*)f_7451},
{"f_7450support.scm",(void*)f_7450},
{"f_7442support.scm",(void*)f_7442},
{"f_7317support.scm",(void*)f_7317},
{"f_7429support.scm",(void*)f_7429},
{"f_7424support.scm",(void*)f_7424},
{"f_7416support.scm",(void*)f_7416},
{"f_7411support.scm",(void*)f_7411},
{"f_7339support.scm",(void*)f_7339},
{"f_7403support.scm",(void*)f_7403},
{"f_7346support.scm",(void*)f_7346},
{"f_7352support.scm",(void*)f_7352},
{"f_7383support.scm",(void*)f_7383},
{"f_7274support.scm",(void*)f_7274},
{"f_7296support.scm",(void*)f_7296},
{"f_7245support.scm",(void*)f_7245},
{"f_7269support.scm",(void*)f_7269},
{"f_7165support.scm",(void*)f_7165},
{"f_7236support.scm",(void*)f_7236},
{"f_7235support.scm",(void*)f_7235},
{"f_7169support.scm",(void*)f_7169},
{"f_7227support.scm",(void*)f_7227},
{"f_7226support.scm",(void*)f_7226},
{"f_7172support.scm",(void*)f_7172},
{"f_7218support.scm",(void*)f_7218},
{"f_7217support.scm",(void*)f_7217},
{"f_7175support.scm",(void*)f_7175},
{"f_7186support.scm",(void*)f_7186},
{"f_7131support.scm",(void*)f_7131},
{"f_7137support.scm",(void*)f_7137},
{"f_7151support.scm",(void*)f_7151},
{"f_7155support.scm",(void*)f_7155},
{"f_6910support.scm",(void*)f_6910},
{"f_6914support.scm",(void*)f_6914},
{"f_6922support.scm",(void*)f_6922},
{"f_7122support.scm",(void*)f_7122},
{"f_6926support.scm",(void*)f_6926},
{"f_7117support.scm",(void*)f_7117},
{"f_6929support.scm",(void*)f_6929},
{"f_7112support.scm",(void*)f_7112},
{"f_6932support.scm",(void*)f_6932},
{"f_7096support.scm",(void*)f_7096},
{"f_7107support.scm",(void*)f_7107},
{"f_7100support.scm",(void*)f_7100},
{"f_7101support.scm",(void*)f_7101},
{"f_7037support.scm",(void*)f_7037},
{"f_7041support.scm",(void*)f_7041},
{"f_7044support.scm",(void*)f_7044},
{"f_7086support.scm",(void*)f_7086},
{"f_7078support.scm",(void*)f_7078},
{"f_7062support.scm",(void*)f_7062},
{"f_7055support.scm",(void*)f_7055},
{"f_7056support.scm",(void*)f_7056},
{"f_6997support.scm",(void*)f_6997},
{"f_7000support.scm",(void*)f_7000},
{"f_7018support.scm",(void*)f_7018},
{"f_7011support.scm",(void*)f_7011},
{"f_7012support.scm",(void*)f_7012},
{"f_6981support.scm",(void*)f_6981},
{"f_6973support.scm",(void*)f_6973},
{"f_6966support.scm",(void*)f_6966},
{"f_6967support.scm",(void*)f_6967},
{"f_6945support.scm",(void*)f_6945},
{"f_6916support.scm",(void*)f_6916},
{"f_6797support.scm",(void*)f_6797},
{"f_6803support.scm",(void*)f_6803},
{"f_6815support.scm",(void*)f_6815},
{"f_6819support.scm",(void*)f_6819},
{"f_6822support.scm",(void*)f_6822},
{"f_6902support.scm",(void*)f_6902},
{"f_6886support.scm",(void*)f_6886},
{"f_6872support.scm",(void*)f_6872},
{"f_6864support.scm",(void*)f_6864},
{"f_6848support.scm",(void*)f_6848},
{"f_6852support.scm",(void*)f_6852},
{"f_6827support.scm",(void*)f_6827},
{"f_6840support.scm",(void*)f_6840},
{"f_6809support.scm",(void*)f_6809},
{"f_6743support.scm",(void*)f_6743},
{"f_6749support.scm",(void*)f_6749},
{"f_6775support.scm",(void*)f_6775},
{"f_6779support.scm",(void*)f_6779},
{"f_6767support.scm",(void*)f_6767},
{"f_6410support.scm",(void*)f_6410},
{"f_6416support.scm",(void*)f_6416},
{"f_6737support.scm",(void*)f_6737},
{"f_6420support.scm",(void*)f_6420},
{"f_6732support.scm",(void*)f_6732},
{"f_6423support.scm",(void*)f_6423},
{"f_6727support.scm",(void*)f_6727},
{"f_6426support.scm",(void*)f_6426},
{"f_6435support.scm",(void*)f_6435},
{"f_6669support.scm",(void*)f_6669},
{"f_6699support.scm",(void*)f_6699},
{"f_6695support.scm",(void*)f_6695},
{"f_6676support.scm",(void*)f_6676},
{"f_6680support.scm",(void*)f_6680},
{"f_6607support.scm",(void*)f_6607},
{"f_6656support.scm",(void*)f_6656},
{"f_6625support.scm",(void*)f_6625},
{"f_6633support.scm",(void*)f_6633},
{"f_6583support.scm",(void*)f_6583},
{"f_6550support.scm",(void*)f_6550},
{"f_6529support.scm",(void*)f_6529},
{"f_6525support.scm",(void*)f_6525},
{"f_6509support.scm",(void*)f_6509},
{"f_6521support.scm",(void*)f_6521},
{"f_6517support.scm",(void*)f_6517},
{"f_6463support.scm",(void*)f_6463},
{"f_6459support.scm",(void*)f_6459},
{"f_6442support.scm",(void*)f_6442},
{"f_5806support.scm",(void*)f_5806},
{"f_6405support.scm",(void*)f_6405},
{"f_6408support.scm",(void*)f_6408},
{"f_5809support.scm",(void*)f_5809},
{"f_6393support.scm",(void*)f_6393},
{"f_6394support.scm",(void*)f_6394},
{"f_6248support.scm",(void*)f_6248},
{"f_6305support.scm",(void*)f_6305},
{"f_6326support.scm",(void*)f_6326},
{"f_6333support.scm",(void*)f_6333},
{"f_6340support.scm",(void*)f_6340},
{"f_6330support.scm",(void*)f_6330},
{"f_6317support.scm",(void*)f_6317},
{"f_6318support.scm",(void*)f_6318},
{"f_6299support.scm",(void*)f_6299},
{"f_6285support.scm",(void*)f_6285},
{"f_6286support.scm",(void*)f_6286},
{"f_6263support.scm",(void*)f_6263},
{"f_6264support.scm",(void*)f_6264},
{"f_6227support.scm",(void*)f_6227},
{"f_6211support.scm",(void*)f_6211},
{"f_6207support.scm",(void*)f_6207},
{"f_6199support.scm",(void*)f_6199},
{"f_6165support.scm",(void*)f_6165},
{"f_6166support.scm",(void*)f_6166},
{"f_6137support.scm",(void*)f_6137},
{"f_6110support.scm",(void*)f_6110},
{"f_6111support.scm",(void*)f_6111},
{"f_6073support.scm",(void*)f_6073},
{"f_6057support.scm",(void*)f_6057},
{"f_6058support.scm",(void*)f_6058},
{"f_6025support.scm",(void*)f_6025},
{"f_6017support.scm",(void*)f_6017},
{"f_5961support.scm",(void*)f_5961},
{"f_5984support.scm",(void*)f_5984},
{"f_5974support.scm",(void*)f_5974},
{"f_5982support.scm",(void*)f_5982},
{"f_5965support.scm",(void*)f_5965},
{"f_5966support.scm",(void*)f_5966},
{"f_5907support.scm",(void*)f_5907},
{"f_5910support.scm",(void*)f_5910},
{"f_5917support.scm",(void*)f_5917},
{"f_5904support.scm",(void*)f_5904},
{"f_5879support.scm",(void*)f_5879},
{"f_5880support.scm",(void*)f_5880},
{"f_5851support.scm",(void*)f_5851},
{"f_5791support.scm",(void*)f_5791},
{"f_5800support.scm",(void*)f_5800},
{"f_5776support.scm",(void*)f_5776},
{"f_5785support.scm",(void*)f_5785},
{"f_5770support.scm",(void*)f_5770},
{"f_5761support.scm",(void*)f_5761},
{"f_5752support.scm",(void*)f_5752},
{"f_5743support.scm",(void*)f_5743},
{"f_5734support.scm",(void*)f_5734},
{"f_5725support.scm",(void*)f_5725},
{"f_5716support.scm",(void*)f_5716},
{"f_5710support.scm",(void*)f_5710},
{"f_5704support.scm",(void*)f_5704},
{"f_5274support.scm",(void*)f_5274},
{"f_5702support.scm",(void*)f_5702},
{"f_5278support.scm",(void*)f_5278},
{"f_5283support.scm",(void*)f_5283},
{"f_5293support.scm",(void*)f_5293},
{"f_5403support.scm",(void*)f_5403},
{"f_5413support.scm",(void*)f_5413},
{"f_5429support.scm",(void*)f_5429},
{"f_5486support.scm",(void*)f_5486},
{"f_5517support.scm",(void*)f_5517},
{"f_5507support.scm",(void*)f_5507},
{"f_5493support.scm",(void*)f_5493},
{"f_5497support.scm",(void*)f_5497},
{"f_5477support.scm",(void*)f_5477},
{"f_5467support.scm",(void*)f_5467},
{"f_5444support.scm",(void*)f_5444},
{"f_5416support.scm",(void*)f_5416},
{"f_5296support.scm",(void*)f_5296},
{"f_5331support.scm",(void*)f_5331},
{"f_5362support.scm",(void*)f_5362},
{"f_5383support.scm",(void*)f_5383},
{"f_5373support.scm",(void*)f_5373},
{"f_5378support.scm",(void*)f_5378},
{"f_5377support.scm",(void*)f_5377},
{"f_5352support.scm",(void*)f_5352},
{"f_5342support.scm",(void*)f_5342},
{"f_5347support.scm",(void*)f_5347},
{"f_5346support.scm",(void*)f_5346},
{"f_5299support.scm",(void*)f_5299},
{"f_5302support.scm",(void*)f_5302},
{"f_5305support.scm",(void*)f_5305},
{"f_5255support.scm",(void*)f_5255},
{"f_5261support.scm",(void*)f_5261},
{"f_5272support.scm",(void*)f_5272},
{"f_5231support.scm",(void*)f_5231},
{"f_5237support.scm",(void*)f_5237},
{"f_5247support.scm",(void*)f_5247},
{"f_5195support.scm",(void*)f_5195},
{"f_5202support.scm",(void*)f_5202},
{"f_5205support.scm",(void*)f_5205},
{"f_5185support.scm",(void*)f_5185},
{"f_5128support.scm",(void*)f_5128},
{"f_5132support.scm",(void*)f_5132},
{"f_5162support.scm",(void*)f_5162},
{"f_5076support.scm",(void*)f_5076},
{"f_5080support.scm",(void*)f_5080},
{"f_5107support.scm",(void*)f_5107},
{"f_5030support.scm",(void*)f_5030},
{"f_5034support.scm",(void*)f_5034},
{"f_5056support.scm",(void*)f_5056},
{"f_5012support.scm",(void*)f_5012},
{"f_5016support.scm",(void*)f_5016},
{"f_5024support.scm",(void*)f_5024},
{"f_4994support.scm",(void*)f_4994},
{"f_4998support.scm",(void*)f_4998},
{"f_4933support.scm",(void*)f_4933},
{"f_4970support.scm",(void*)f_4970},
{"f_4974support.scm",(void*)f_4974},
{"f_4977support.scm",(void*)f_4977},
{"f_4937support.scm",(void*)f_4937},
{"f_4955support.scm",(void*)f_4955},
{"f_4959support.scm",(void*)f_4959},
{"f_4940support.scm",(void*)f_4940},
{"f_4945support.scm",(void*)f_4945},
{"f_4792support.scm",(void*)f_4792},
{"f_4796support.scm",(void*)f_4796},
{"f_4800support.scm",(void*)f_4800},
{"f_4789support.scm",(void*)f_4789},
{"f_4682support.scm",(void*)f_4682},
{"f_4691support.scm",(void*)f_4691},
{"f_4722support.scm",(void*)f_4722},
{"f_4776support.scm",(void*)f_4776},
{"f_4782support.scm",(void*)f_4782},
{"f_4728support.scm",(void*)f_4728},
{"f_4760support.scm",(void*)f_4760},
{"f_4774support.scm",(void*)f_4774},
{"f_4766support.scm",(void*)f_4766},
{"f_4732support.scm",(void*)f_4732},
{"f_4754support.scm",(void*)f_4754},
{"f_4697support.scm",(void*)f_4697},
{"f_4703support.scm",(void*)f_4703},
{"f_4714support.scm",(void*)f_4714},
{"f_4711support.scm",(void*)f_4711},
{"f_4689support.scm",(void*)f_4689},
{"f_4581support.scm",(void*)f_4581},
{"f_4587support.scm",(void*)f_4587},
{"f_4664support.scm",(void*)f_4664},
{"f_4615support.scm",(void*)f_4615},
{"f_4653support.scm",(void*)f_4653},
{"f_4641support.scm",(void*)f_4641},
{"f_4521support.scm",(void*)f_4521},
{"f_4537support.scm",(void*)f_4537},
{"f_4579support.scm",(void*)f_4579},
{"f_4543support.scm",(void*)f_4543},
{"f_4558support.scm",(void*)f_4558},
{"f_4475support.scm",(void*)f_4475},
{"f_4519support.scm",(void*)f_4519},
{"f_4479support.scm",(void*)f_4479},
{"f_4445support.scm",(void*)f_4445},
{"f_4399support.scm",(void*)f_4399},
{"f_4368support.scm",(void*)f_4368},
{"f_4374support.scm",(void*)f_4374},
{"f_4389support.scm",(void*)f_4389},
{"f_4305support.scm",(void*)f_4305},
{"f_4319support.scm",(void*)f_4319},
{"f_4321support.scm",(void*)f_4321},
{"f_4350support.scm",(void*)f_4350},
{"f_4329support.scm",(void*)f_4329},
{"f_4293support.scm",(void*)f_4293},
{"f_4246support.scm",(void*)f_4246},
{"f_4262support.scm",(void*)f_4262},
{"f_4274support.scm",(void*)f_4274},
{"f_4239support.scm",(void*)f_4239},
{"f_4232support.scm",(void*)f_4232},
{"f_4176support.scm",(void*)f_4176},
{"f_4230support.scm",(void*)f_4230},
{"f_4180support.scm",(void*)f_4180},
{"f_4203support.scm",(void*)f_4203},
{"f_4082support.scm",(void*)f_4082},
{"f_4098support.scm",(void*)f_4098},
{"f_4100support.scm",(void*)f_4100},
{"f_4122support.scm",(void*)f_4122},
{"f_4161support.scm",(void*)f_4161},
{"f_4129support.scm",(void*)f_4129},
{"f_4145support.scm",(void*)f_4145},
{"f_4133support.scm",(void*)f_4133},
{"f_4137support.scm",(void*)f_4137},
{"f_4094support.scm",(void*)f_4094},
{"f_4038support.scm",(void*)f_4038},
{"f_4044support.scm",(void*)f_4044},
{"f_4068support.scm",(void*)f_4068},
{"f_4013support.scm",(void*)f_4013},
{"f_4036support.scm",(void*)f_4036},
{"f_3992support.scm",(void*)f_3992},
{"f_3956support.scm",(void*)f_3956},
{"f_3962support.scm",(void*)f_3962},
{"f_3888support.scm",(void*)f_3888},
{"f_3912support.scm",(void*)f_3912},
{"f_3891support.scm",(void*)f_3891},
{"f_3899support.scm",(void*)f_3899},
{"f_3903support.scm",(void*)f_3903},
{"f_3845support.scm",(void*)f_3845},
{"f_3851support.scm",(void*)f_3851},
{"f_3874support.scm",(void*)f_3874},
{"f_3878support.scm",(void*)f_3878},
{"f_3842support.scm",(void*)f_3842},
{"f_3817support.scm",(void*)f_3817},
{"f_3821support.scm",(void*)f_3821},
{"f_3824support.scm",(void*)f_3824},
{"f_3835support.scm",(void*)f_3835},
{"f_3827support.scm",(void*)f_3827},
{"f_3830support.scm",(void*)f_3830},
{"f_3798support.scm",(void*)f_3798},
{"f_3802support.scm",(void*)f_3802},
{"f_3815support.scm",(void*)f_3815},
{"f_3805support.scm",(void*)f_3805},
{"f_3808support.scm",(void*)f_3808},
{"f_3769support.scm",(void*)f_3769},
{"f_3776support.scm",(void*)f_3776},
{"f_3779support.scm",(void*)f_3779},
{"f_3789support.scm",(void*)f_3789},
{"f_3782support.scm",(void*)f_3782},
{"f_3729support.scm",(void*)f_3729},
{"f_3739support.scm",(void*)f_3739},
{"f_3754support.scm",(void*)f_3754},
{"f_3759support.scm",(void*)f_3759},
{"f_3767support.scm",(void*)f_3767},
{"f_3742support.scm",(void*)f_3742},
{"f_3745support.scm",(void*)f_3745},
{"f_3748support.scm",(void*)f_3748},
{"f_3702support.scm",(void*)f_3702},
{"f_3716support.scm",(void*)f_3716},
{"f_3697support.scm",(void*)f_3697},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
