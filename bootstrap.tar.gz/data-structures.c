/* Generated from data-structures.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-07-09 11:02
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   compiled 2008-07-02 on debian (Linux)
   command line: data-structures.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file data-structures.c -extend private-namespace.scm
   unit: data_structures
*/

#include "chicken.h"

#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[113];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,13),40,105,100,101,110,116,105,116,121,32,120,49,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,102,95,54,57,53,32,46,32,97,114,103,115,51,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,12),40,112,114,111,106,101,99,116,32,110,50,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,112,114,101,100,115,55,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,10),40,102,95,55,48,51,32,120,53,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,99,111,110,106,111,105,110,32,46,32,112,114,101,100,115,52,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,49,52,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,11),40,102,95,55,51,54,32,120,49,50,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,19),40,100,105,115,106,111,105,110,32,46,32,112,114,101,100,115,49,49,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,13),40,102,95,55,56,50,32,46,32,95,50,48,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,102,95,55,56,52,32,46,32,95,50,49,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,19),40,99,111,110,115,116,97,110,116,108,121,32,46,32,120,115,49,56,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,15),40,102,95,55,57,54,32,120,50,51,32,121,50,52,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,102,108,105,112,32,112,114,111,99,50,50,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,102,95,56,48,52,32,46,32,97,114,103,115,50,54,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,99,111,109,112,108,101,109,101,110,116,32,112,50,53,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,6),40,97,56,51,48,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,16),40,102,95,56,50,53,32,46,32,97,114,103,115,51,49,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,18),40,114,101,99,32,102,48,50,57,32,46,32,102,110,115,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,17),40,99,111,109,112,111,115,101,32,46,32,102,110,115,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,11),40,102,95,56,55,54,32,120,51,56,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,102,110,115,51,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,11),40,111,32,46,32,102,110,115,51,51,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,52,51,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,13),40,102,95,56,57,49,32,108,115,116,52,49,41,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,108,105,115,116,45,111,102,32,112,114,101,100,52,48,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,110,111,111,112,32,46,32,95,52,53,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,102,95,57,52,51,32,46,32,95,52,55,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,111,99,115,53,48,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,102,95,57,53,55,32,46,32,97,114,103,115,52,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,16),40,101,97,99,104,32,46,32,112,114,111,99,115,52,54,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,10),40,97,110,121,63,32,120,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,11),40,110,111,110,101,63,32,120,53,54,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,15),40,97,108,119,97,121,115,63,32,46,32,95,53,55,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,14),40,110,101,118,101,114,63,32,46,32,95,53,56,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,102,95,49,48,48,56,32,46,32,120,115,54,49,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,30),40,108,101,102,116,45,115,101,99,116,105,111,110,32,112,114,111,99,53,57,32,46,32,97,114,103,115,54,48,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,102,95,49,48,50,54,32,46,32,120,115,54,55,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,31),40,114,105,103,104,116,45,115,101,99,116,105,111,110,32,112,114,111,99,54,52,32,46,32,97,114,103,115,54,53,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,11),40,97,116,111,109,63,32,120,54,57,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,15),40,116,97,105,108,63,32,120,55,48,32,121,55,49,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,115,56,49,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,23),40,105,110,116,101,114,115,112,101,114,115,101,32,108,115,116,55,56,32,120,55,57,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,56,54,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,15),40,98,117,116,108,97,115,116,32,108,115,116,56,52,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,108,105,115,116,115,57,50,32,114,101,115,116,57,51,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,20),40,102,108,97,116,116,101,110,32,46,32,108,105,115,116,115,48,57,48,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,24),40,100,111,49,48,52,32,104,100,49,48,54,32,116,108,49,48,55,32,99,49,48,56,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,115,116,49,48,50,32,105,49,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,16),40,99,104,111,112,32,108,115,116,57,56,32,110,57,57,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,115,49,49,55,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,106,111,105,110,32,108,115,116,115,49,49,51,32,46,32,108,115,116,49,49,52,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,98,108,115,116,49,50,54,32,108,115,116,49,50,55,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,99,111,109,112,114,101,115,115,32,98,108,115,116,49,50,50,32,108,115,116,49,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,17),40,97,49,52,50,49,32,120,49,51,52,32,121,49,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,49,52,51,53,32,120,49,51,51,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,24),40,115,104,117,102,102,108,101,32,108,49,51,48,32,114,97,110,100,111,109,49,51,49,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,52,53,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,102,95,49,52,56,53,32,120,49,52,50,32,108,115,116,49,52,51,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,41),40,97,108,105,115,116,45,117,112,100,97,116,101,33,32,120,49,51,54,32,121,49,51,55,32,108,115,116,49,51,56,32,46,32,99,109,112,49,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,54,56,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,102,95,49,53,54,51,32,120,49,54,53,32,108,115,116,49,54,54,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,53,54,32,99,109,112,49,54,50,32,100,101,102,97,117,108,116,49,54,51,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,100,101,102,97,117,108,116,49,53,57,32,37,99,109,112,49,53,52,49,55,51,41,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,99,109,112,49,53,56,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,33),40,97,108,105,115,116,45,114,101,102,32,120,49,53,49,32,108,115,116,49,53,50,32,46,32,103,49,53,48,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,49,56,53,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,114,97,115,115,111,99,32,120,49,56,48,32,108,115,116,49,56,49,32,46,32,116,115,116,49,56,50,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,106,49,57,56,32,107,49,57,57,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,29),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,49,57,50,32,105,49,57,51,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,46),40,35,35,100,97,116,97,45,115,116,114,117,99,116,117,114,101,115,35,114,101,118,101,114,115,101,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,49,57,48,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,15),40,45,62,115,116,114,105,110,103,32,120,50,48,55,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,99,111,110,99,32,46,32,97,114,103,115,50,49,49,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,115,116,97,114,116,50,50,49,32,105,101,110,100,50,50,50,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,52),40,116,114,97,118,101,114,115,101,32,119,104,105,99,104,50,49,51,32,119,104,101,114,101,50,49,52,32,115,116,97,114,116,50,49,53,32,116,101,115,116,50,49,54,32,108,111,99,50,49,55,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,17),40,97,49,56,57,48,32,105,50,51,48,32,108,50,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,50,50,55,32,119,104,101,114,101,50,50,56,32,115,116,97,114,116,50,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,97,49,56,57,57,32,105,50,51,53,32,108,50,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,53),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,50,51,50,32,119,104,101,114,101,50,51,51,32,115,116,97,114,116,50,51,52,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,45),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,50,52,48,32,119,104,101,114,101,50,52,49,32,46,32,103,50,51,57,50,52,50,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,48),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,50,52,55,32,119,104,101,114,101,50,52,56,32,46,32,103,50,52,54,50,52,57,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,29),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,32,115,49,50,53,51,32,115,50,50,53,52,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,45,99,105,32,115,49,50,54,49,32,115,50,50,54,50,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,61,63,32,115,49,50,54,57,32,115,50,50,55,48,32,115,116,97,114,116,49,50,55,49,32,115,116,97,114,116,50,50,55,50,32,110,50,55,51,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,50,56,56,32,115,116,97,114,116,49,50,57,53,32,115,116,97,114,116,50,50,57,54,32,108,101,110,50,57,55,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,108,101,110,50,57,50,32,37,115,116,97,114,116,49,50,56,53,50,57,57,32,37,115,116,97,114,116,50,50,56,54,51,48,48,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,50,50,57,49,32,37,115,116,97,114,116,49,50,56,53,51,48,50,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,115,116,97,114,116,49,50,57,48,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,35),40,115,117,98,115,116,114,105,110,103,61,63,32,115,49,50,56,50,32,115,50,50,56,51,32,46,32,103,50,56,49,50,56,52,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,59),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,51,49,48,32,115,50,51,49,49,32,115,116,97,114,116,49,51,49,50,32,115,116,97,114,116,50,51,49,51,32,110,51,49,52,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,51,50,57,32,115,116,97,114,116,49,51,51,54,32,115,116,97,114,116,50,51,51,55,32,108,101,110,51,51,56,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,108,101,110,51,51,51,32,37,115,116,97,114,116,49,51,50,54,51,52,48,32,37,115,116,97,114,116,50,51,50,55,51,52,49,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,50,51,51,50,32,37,115,116,97,114,116,49,51,50,54,51,52,51,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,115,116,97,114,116,49,51,51,49,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,38),40,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,51,50,51,32,115,50,51,50,52,32,46,32,103,51,50,50,51,50,53,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,27),40,97,100,100,32,102,114,111,109,51,53,57,32,116,111,51,54,48,32,108,97,115,116,51,54,49,41,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,51,55,53,41,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,105,51,54,53,32,108,97,115,116,51,54,54,32,102,114,111,109,51,54,55,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,42),40,115,116,114,105,110,103,45,115,112,108,105,116,32,115,116,114,51,53,49,32,46,32,100,101,108,115,116,114,45,97,110,100,45,102,108,97,103,51,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,50,32,110,50,51,57,55,41,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,49,32,115,115,51,57,50,32,110,51,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,38),40,115,116,114,105,110,103,45,105,110,116,101,114,115,112,101,114,115,101,32,115,116,114,115,51,56,53,32,46,32,103,51,56,52,51,56,54,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,13),40,102,95,50,53,49,51,32,99,52,49,56,41,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,15),40,105,110,115,116,114,105,110,103,32,115,52,49,54,41,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,105,52,51,50,32,106,52,51,51,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,13),40,102,95,50,54,56,50,32,99,52,50,51,41,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,32,115,116,114,52,49,50,32,102,114,111,109,52,49,51,32,46,32,116,111,52,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,109,97,112,52,53,49,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,37),40,99,111,108,108,101,99,116,32,105,52,52,54,32,102,114,111,109,52,52,55,32,116,111,116,97,108,52,52,56,32,102,115,52,52,57,41,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,34),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,42,32,115,116,114,52,52,50,32,115,109,97,112,52,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,116,111,116,97,108,52,54,54,32,112,111,115,52,54,55,41,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,27),40,115,116,114,105,110,103,45,99,104,111,112,32,115,116,114,52,54,50,32,108,101,110,52,54,51,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,31),40,115,116,114,105,110,103,45,99,104,111,109,112,32,115,116,114,52,55,50,32,46,32,103,52,55,49,52,55,51,41,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,12),40,100,111,52,56,53,32,105,52,56,55,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,108,97,115,116,52,57,50,32,110,101,120,116,52,57,51,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,25),40,115,111,114,116,101,100,63,32,115,101,113,52,56,50,32,108,101,115,115,63,52,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,120,53,48,49,32,97,53,48,50,32,121,53,48,51,32,98,53,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,26),40,109,101,114,103,101,32,97,52,57,55,32,98,52,57,56,32,108,101,115,115,63,52,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,114,53,49,48,32,97,53,49,49,32,98,53,49,50,41,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,27),40,109,101,114,103,101,33,32,97,53,48,54,32,98,53,48,55,32,108,101,115,115,63,53,48,56,41,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,11),40,115,116,101,112,32,110,53,50,49,41,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,17),40,100,111,53,51,56,32,112,53,52,48,32,105,53,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,23),40,115,111,114,116,33,32,115,101,113,53,49,56,32,108,101,115,115,63,53,49,57,41,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,22),40,115,111,114,116,32,115,101,113,53,52,54,32,108,101,115,115,63,53,52,55,41,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,115,53,53,51,32,112,101,53,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,30),40,98,105,110,97,114,121,45,115,101,97,114,99,104,32,118,101,99,53,52,57,32,112,114,111,99,53,53,48,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,12),40,109,97,107,101,45,113,117,101,117,101,41,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,13),40,113,117,101,117,101,63,32,120,53,54,48,41,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,101,109,112,116,121,63,32,113,53,54,49,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,102,105,114,115,116,32,113,53,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,17),40,113,117,101,117,101,45,108,97,115,116,32,113,53,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,26),40,113,117,101,117,101,45,97,100,100,33,32,113,53,55,49,32,100,97,116,117,109,53,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,20),40,113,117,101,117,101,45,114,101,109,111,118,101,33,32,113,53,55,55,41,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,62,108,105,115,116,32,113,53,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,14),40,100,111,53,56,55,32,108,115,116,53,56,57,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,21),40,108,105,115,116,45,62,113,117,101,117,101,32,108,115,116,48,53,56,54,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,31),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,33,32,113,53,57,53,32,105,116,101,109,53,57,54,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,7),40,100,111,54,48,52,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,40),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,45,108,105,115,116,33,32,113,54,48,48,32,105,116,101,109,108,105,115,116,54,48,49,41};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_data_structures_toplevel)
C_externexport void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static C_word C_fcall f_3782(C_word t0);
C_noret_decl(f_3768)
static void C_fcall f_3768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3691)
static void C_fcall f_3691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3605)
static void C_fcall f_3605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_fcall f_3449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_fcall f_3463(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_fcall f_3384(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3288)
static void C_fcall f_3288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_fcall f_3329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3088)
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3020)
static void C_fcall f_3020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_fcall f_2972(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2844)
static void C_fcall f_2844(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2719)
static void C_fcall f_2719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2752)
static void C_fcall f_2752(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_fcall f_2791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_fcall f_2737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_fcall f_2562(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_fcall f_2508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2519)
static C_word C_fcall f_2519(C_word t0,C_word t1);
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_fcall f_2408(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static C_word C_fcall f_2423(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2296)
static void C_fcall f_2296(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2323)
static void C_fcall f_2323(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_fcall f_2283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2192)
static void C_fcall f_2192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_fcall f_2187(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2182)
static void C_fcall f_2182(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2177)
static void C_fcall f_2177(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2075)
static void C_fcall f_2075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_fcall f_2070(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2065)
static void C_fcall f_2065(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2060)
static void C_fcall f_2060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2031)
static void C_fcall f_2031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1838)
static void C_fcall f_1838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1859)
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1709)
static void C_fcall f_1709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_fcall f_1734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1668)
static void C_fcall f_1668(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1608)
static void C_fcall f_1608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_fcall f_1603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1534)
static void C_fcall f_1534(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1569)
static void C_fcall f_1569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_fcall f_1453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1334)
static void C_fcall f_1334(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1278)
static void C_fcall f_1278(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_fcall f_1196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1217)
static void C_fcall f_1217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1231)
static void C_ccall f_1231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1146)
static void C_fcall f_1146(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1117)
static void C_fcall f_1117(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1081)
static void C_fcall f_1081(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1059)
static C_word C_fcall f_1059(C_word t0,C_word t1);
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_963)
static void C_fcall f_963(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_891)
static void C_ccall f_891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_897)
static void C_fcall f_897(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_862)
static void C_fcall f_862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_802)
static void C_ccall f_802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_784)
static void C_ccall f_784(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_736)
static void C_ccall f_736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_742)
static void C_fcall f_742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_709)
static void C_fcall f_709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3768)
static void C_fcall trf_3768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3768(t0,t1);}

C_noret_decl(trf_3691)
static void C_fcall trf_3691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3691(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3691(t0,t1,t2);}

C_noret_decl(trf_3605)
static void C_fcall trf_3605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3605(t0,t1);}

C_noret_decl(trf_3449)
static void C_fcall trf_3449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3449(t0,t1);}

C_noret_decl(trf_3463)
static void C_fcall trf_3463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3463(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3463(t0,t1,t2,t3);}

C_noret_decl(trf_3384)
static void C_fcall trf_3384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3384(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3384(t0,t1,t2,t3);}

C_noret_decl(trf_3288)
static void C_fcall trf_3288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3288(t0,t1,t2);}

C_noret_decl(trf_3329)
static void C_fcall trf_3329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3329(t0,t1);}

C_noret_decl(trf_3156)
static void C_fcall trf_3156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3156(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3156(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3088)
static void C_fcall trf_3088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3088(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3088(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3020)
static void C_fcall trf_3020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3020(t0,t1,t2,t3);}

C_noret_decl(trf_2972)
static void C_fcall trf_2972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2972(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2972(t0,t1,t2);}

C_noret_decl(trf_2844)
static void C_fcall trf_2844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2844(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2844(t0,t1,t2,t3);}

C_noret_decl(trf_2719)
static void C_fcall trf_2719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2719(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2719(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2752)
static void C_fcall trf_2752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2752(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2752(t0,t1,t2);}

C_noret_decl(trf_2791)
static void C_fcall trf_2791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2791(t0,t1);}

C_noret_decl(trf_2737)
static void C_fcall trf_2737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2737(t0,t1);}

C_noret_decl(trf_2562)
static void C_fcall trf_2562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2562(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2562(t0,t1,t2,t3);}

C_noret_decl(trf_2508)
static void C_fcall trf_2508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2508(t0,t1);}

C_noret_decl(trf_2408)
static void C_fcall trf_2408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2408(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2408(t0,t1,t2,t3);}

C_noret_decl(trf_2296)
static void C_fcall trf_2296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2296(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2296(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2323)
static void C_fcall trf_2323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2323(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2323(t0,t1,t2);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2276(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2283)
static void C_fcall trf_2283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2283(t0,t1);}

C_noret_decl(trf_2192)
static void C_fcall trf_2192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2192(t0,t1);}

C_noret_decl(trf_2187)
static void C_fcall trf_2187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2187(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2187(t0,t1,t2);}

C_noret_decl(trf_2182)
static void C_fcall trf_2182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2182(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2182(t0,t1,t2,t3);}

C_noret_decl(trf_2177)
static void C_fcall trf_2177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2177(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2177(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2148(t0,t1);}

C_noret_decl(trf_2075)
static void C_fcall trf_2075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2075(t0,t1);}

C_noret_decl(trf_2070)
static void C_fcall trf_2070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2070(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2070(t0,t1,t2);}

C_noret_decl(trf_2065)
static void C_fcall trf_2065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2065(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2065(t0,t1,t2,t3);}

C_noret_decl(trf_2060)
static void C_fcall trf_2060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2060(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2060(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2031)
static void C_fcall trf_2031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2031(t0,t1);}

C_noret_decl(trf_1838)
static void C_fcall trf_1838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1838(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1838(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1859)
static void C_fcall trf_1859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1859(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1859(t0,t1,t2,t3);}

C_noret_decl(trf_1709)
static void C_fcall trf_1709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1709(t0,t1,t2,t3);}

C_noret_decl(trf_1734)
static void C_fcall trf_1734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1734(t0,t1,t2,t3);}

C_noret_decl(trf_1668)
static void C_fcall trf_1668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1668(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1668(t0,t1,t2);}

C_noret_decl(trf_1608)
static void C_fcall trf_1608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1608(t0,t1);}

C_noret_decl(trf_1603)
static void C_fcall trf_1603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1603(t0,t1,t2);}

C_noret_decl(trf_1534)
static void C_fcall trf_1534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1534(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1534(t0,t1,t2,t3);}

C_noret_decl(trf_1569)
static void C_fcall trf_1569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1569(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1569(t0,t1,t2);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1538(t0,t1);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1491(t0,t1,t2);}

C_noret_decl(trf_1453)
static void C_fcall trf_1453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1453(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1453(t0,t1);}

C_noret_decl(trf_1334)
static void C_fcall trf_1334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1334(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1334(t0,t1,t2,t3);}

C_noret_decl(trf_1278)
static void C_fcall trf_1278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1278(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1278(t0,t1,t2);}

C_noret_decl(trf_1196)
static void C_fcall trf_1196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1196(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1196(t0,t1,t2,t3);}

C_noret_decl(trf_1217)
static void C_fcall trf_1217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1217(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1217(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1146)
static void C_fcall trf_1146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1146(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1146(t0,t1,t2,t3);}

C_noret_decl(trf_1117)
static void C_fcall trf_1117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1117(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1117(t0,t1,t2);}

C_noret_decl(trf_1081)
static void C_fcall trf_1081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1081(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1081(t0,t1,t2);}

C_noret_decl(trf_963)
static void C_fcall trf_963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_963(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_963(t0,t1,t2);}

C_noret_decl(trf_897)
static void C_fcall trf_897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_897(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_897(t0,t1,t2);}

C_noret_decl(trf_862)
static void C_fcall trf_862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_862(t0,t1,t2);}

C_noret_decl(trf_742)
static void C_fcall trf_742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_742(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_742(t0,t1,t2);}

C_noret_decl(trf_709)
static void C_fcall trf_709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_709(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("data_structures_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1010)){
C_save(t1);
C_rereclaim2(1010*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,113);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],8,"identity");
lf[4]=C_h_intern(&lf[4],7,"project");
lf[5]=C_h_intern(&lf[5],7,"conjoin");
lf[6]=C_h_intern(&lf[6],7,"disjoin");
lf[7]=C_h_intern(&lf[7],10,"constantly");
lf[8]=C_h_intern(&lf[8],4,"flip");
lf[9]=C_h_intern(&lf[9],10,"complement");
lf[10]=C_h_intern(&lf[10],7,"compose");
lf[11]=C_h_intern(&lf[11],6,"values");
lf[12]=C_h_intern(&lf[12],1,"o");
lf[13]=C_h_intern(&lf[13],7,"list-of");
lf[14]=C_h_intern(&lf[14],4,"noop");
lf[15]=C_h_intern(&lf[15],4,"each");
lf[16]=C_h_intern(&lf[16],4,"any\077");
lf[17]=C_h_intern(&lf[17],5,"none\077");
lf[18]=C_h_intern(&lf[18],7,"always\077");
lf[19]=C_h_intern(&lf[19],6,"never\077");
lf[20]=C_h_intern(&lf[20],12,"left-section");
lf[21]=C_h_intern(&lf[21],10,"\003sysappend");
lf[22]=C_h_intern(&lf[22],17,"\003syscheck-closure");
lf[23]=C_h_intern(&lf[23],7,"reverse");
lf[24]=C_h_intern(&lf[24],13,"right-section");
lf[25]=C_h_intern(&lf[25],5,"atom\077");
lf[26]=C_h_intern(&lf[26],5,"tail\077");
lf[27]=C_h_intern(&lf[27],11,"intersperse");
lf[28]=C_h_intern(&lf[28],7,"butlast");
lf[29]=C_h_intern(&lf[29],7,"flatten");
lf[30]=C_h_intern(&lf[30],4,"chop");
lf[31]=C_h_intern(&lf[31],9,"\003syserror");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid numeric argument");
lf[33]=C_h_intern(&lf[33],4,"join");
lf[34]=C_h_intern(&lf[34],27,"\003sysnot-a-proper-list-error");
lf[35]=C_h_intern(&lf[35],8,"compress");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000%bad argument type - not a proper list");
lf[37]=C_h_intern(&lf[37],15,"\003syssignal-hook");
lf[38]=C_h_intern(&lf[38],11,"\000type-error");
lf[39]=C_h_intern(&lf[39],7,"shuffle");
lf[40]=C_h_intern(&lf[40],7,"\003sysmap");
lf[41]=C_h_intern(&lf[41],3,"cdr");
lf[42]=C_h_intern(&lf[42],5,"sort!");
lf[43]=C_h_intern(&lf[43],13,"alist-update!");
lf[44]=C_h_intern(&lf[44],4,"eqv\077");
lf[45]=C_h_intern(&lf[45],3,"eq\077");
lf[46]=C_h_intern(&lf[46],4,"assq");
lf[47]=C_h_intern(&lf[47],4,"assv");
lf[48]=C_h_intern(&lf[48],6,"equal\077");
lf[49]=C_h_intern(&lf[49],5,"assoc");
lf[50]=C_h_intern(&lf[50],9,"alist-ref");
lf[51]=C_h_intern(&lf[51],6,"rassoc");
lf[52]=C_h_intern(&lf[52],37,"\017data-structuresreverse-string-append");
lf[53]=C_h_intern(&lf[53],11,"make-string");
lf[54]=C_h_intern(&lf[54],18,"open-output-string");
lf[55]=C_h_intern(&lf[55],7,"display");
lf[56]=C_h_intern(&lf[56],6,"string");
lf[57]=C_h_intern(&lf[57],17,"get-output-string");
lf[58]=C_h_intern(&lf[58],8,"->string");
lf[59]=C_h_intern(&lf[59],14,"symbol->string");
lf[60]=C_h_intern(&lf[60],18,"\003sysnumber->string");
lf[61]=C_h_intern(&lf[61],13,"string-append");
lf[62]=C_h_intern(&lf[62],4,"conc");
lf[63]=C_h_intern(&lf[63],19,"\003syssubstring-index");
lf[64]=C_h_intern(&lf[64],15,"substring-index");
lf[65]=C_h_intern(&lf[65],22,"\003syssubstring-index-ci");
lf[66]=C_h_intern(&lf[66],18,"substring-index-ci");
lf[67]=C_h_intern(&lf[67],15,"string-compare3");
lf[68]=C_h_intern(&lf[68],18,"string-compare3-ci");
lf[69]=C_h_intern(&lf[69],15,"\003syssubstring=\077");
lf[70]=C_h_intern(&lf[70],11,"substring=\077");
lf[71]=C_h_intern(&lf[71],18,"\003syssubstring-ci=\077");
lf[72]=C_h_intern(&lf[72],14,"substring-ci=\077");
lf[73]=C_h_intern(&lf[73],12,"string-split");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\003\011\012 ");
lf[75]=C_h_intern(&lf[75],13,"\003syssubstring");
lf[76]=C_h_intern(&lf[76],18,"string-intersperse");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[78]=C_h_intern(&lf[78],19,"\003sysallocate-vector");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[80]=C_h_intern(&lf[80],12,"list->string");
lf[81]=C_h_intern(&lf[81],16,"string-translate");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid translation destination");
lf[83]=C_h_intern(&lf[83],17,"string-translate*");
lf[84]=C_h_intern(&lf[84],21,"\003sysfragments->string");
lf[85]=C_h_intern(&lf[85],11,"string-chop");
lf[86]=C_h_intern(&lf[86],12,"string-chomp");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[88]=C_h_intern(&lf[88],7,"sorted\077");
lf[89]=C_h_intern(&lf[89],5,"merge");
lf[90]=C_h_intern(&lf[90],6,"merge!");
lf[91]=C_h_intern(&lf[91],12,"vector->list");
lf[92]=C_h_intern(&lf[92],4,"sort");
lf[93]=C_h_intern(&lf[93],12,"list->vector");
lf[94]=C_h_intern(&lf[94],6,"append");
lf[95]=C_h_intern(&lf[95],13,"binary-search");
lf[96]=C_h_intern(&lf[96],10,"make-queue");
lf[97]=C_h_intern(&lf[97],5,"queue");
lf[98]=C_h_intern(&lf[98],6,"queue\077");
lf[99]=C_h_intern(&lf[99],12,"queue-empty\077");
lf[100]=C_h_intern(&lf[100],11,"queue-first");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[102]=C_h_intern(&lf[102],10,"queue-last");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[104]=C_h_intern(&lf[104],10,"queue-add!");
lf[105]=C_h_intern(&lf[105],13,"queue-remove!");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[107]=C_h_intern(&lf[107],11,"queue->list");
lf[108]=C_h_intern(&lf[108],11,"list->queue");
lf[109]=C_h_intern(&lf[109],16,"queue-push-back!");
lf[110]=C_h_intern(&lf[110],21,"queue-push-back-list!");
lf[111]=C_h_intern(&lf[111],17,"register-feature!");
lf[112]=C_h_intern(&lf[112],15,"data-structures");
C_register_lf2(lf,113,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=*((C_word*)lf[2]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_688,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm: 91   register-feature! */
t5=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[112]);}

/* k686 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[213],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_688,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_693,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_802,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_814,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_850,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_929,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_935,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_997,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1003,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[23]+1);
t20=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1018,a[2]=t19,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp));
t21=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1047,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1108,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t26=*((C_word*)lf[23]+1);
t27=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1181,a[2]=t26,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1405,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1532,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1706,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t35=*((C_word*)lf[54]+1);
t36=*((C_word*)lf[55]+1);
t37=*((C_word*)lf[56]+1);
t38=*((C_word*)lf[57]+1);
t39=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1783,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=t37,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t40=*((C_word*)lf[61]+1);
t41=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=t40,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1838,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
t43=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1885,a[2]=t42,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp));
t44=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t42,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t45=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1903,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1931,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1959,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1990,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2021,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2138,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2175,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t55=*((C_word*)lf[53]+1);
t56=*((C_word*)lf[80]+1);
t57=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=t56,a[3]=t55,a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp));
t58=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2707,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3054,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3285,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t66=*((C_word*)lf[93]+1);
t67=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3445,a[2]=t66,a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp));
t68=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3534,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3540,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3663,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3726,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3755,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t79=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t79+1)))(2,t79,C_SCHEME_UNDEFINED);}

/* queue-push-back-list! in k686 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3755,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[97],lf[110]);
t5=(C_word)C_i_check_list_2(t3,lf[110]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3765,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* data-structures.scm: 924  append */
t8=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t3,t7);}

/* k3763 in queue-push-back-list! in k686 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_3768(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3782,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
t5=t2;
f_3768(t5,f_3782(t1));}}

/* do604 in k3763 in queue-push-back-list! in k686 */
static C_word C_fcall f_3782(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* k3766 in k3763 in queue-push-back-list! in k686 */
static void C_fcall f_3768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1));}

/* queue-push-back! in k686 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3726,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[97],lf[109]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_i_setslot(t2,C_fix(1),t6);
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?(C_word)C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED));}

/* list->queue in k686 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3672,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[108]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3683,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_3683(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3691,a[2]=t2,a[3]=t7,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3691(t9,t4,t2);}}

/* do587 in list->queue in k686 */
static void C_fcall f_3691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3691,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3701,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* data-structures.scm: 900  ##sys#not-a-proper-list-error */
t8=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[108]);}
else{
t8=t5;
f_3701(2,t8,C_SCHEME_UNDEFINED);}}}

/* k3699 in do587 in list->queue in k686 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3691(t3,((C_word*)t0)[2],t2);}

/* k3681 in list->queue in k686 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[97],((C_word*)t0)[2],t1));}

/* queue->list in k686 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3663,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[97],lf[107]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k686 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3627,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[97],lf[105]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3637,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 878  ##sys#error */
t7=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[105],lf[106],t2);}
else{
t7=t5;
f_3637(2,t7,C_SCHEME_UNDEFINED);}}

/* k3635 in queue-remove! in k686 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(((C_word*)t0)[4],C_fix(0)));}

/* queue-add! in k686 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3595,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[97],lf[104]);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3605,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t7);
if(C_truep(t8)){
t9=t6;
f_3605(t9,(C_word)C_i_setslot(t2,C_fix(1),t5));}
else{
t9=(C_word)C_slot(t2,C_fix(2));
t10=t6;
f_3605(t10,(C_word)C_i_setslot(t9,C_fix(1),t5));}}

/* k3603 in queue-add! in k686 */
static void C_fcall f_3605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k686 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3574,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[97],lf[102]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3584,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 859  ##sys#error */
t7=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[102],lf[103],t2);}
else{
t7=t5;
f_3584(2,t7,C_SCHEME_UNDEFINED);}}

/* k3582 in queue-last in k686 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-first in k686 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3553,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[97],lf[100]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3563,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 848  ##sys#error */
t7=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[100],lf[101],t2);}
else{
t7=t5;
f_3563(2,t7,C_SCHEME_UNDEFINED);}}

/* k3561 in queue-first in k686 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-empty? in k686 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3540,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[97],lf[99]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* queue? in k686 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3534,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[97]));}

/* make-queue in k686 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3528,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[97],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* binary-search in k686 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3445,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3449,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3523,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 805  list->vector */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_3449(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[95]));}}

/* k3521 in binary-search in k686 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3449(t3,t2);}

/* k3447 in binary-search in k686 */
static void C_fcall f_3449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3449,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li126),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3463(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k3447 in binary-search in k686 */
static void C_fcall f_3463(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3463,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_divide(t4,C_fix(2));
t6=(C_word)C_fixnum_plus(t2,t5);
t7=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3473,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 813  proc */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t7);}

/* k3471 in loop in k3447 in binary-search in k686 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 815  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3463(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 816  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3463(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k686 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3418,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3432,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3436,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 795  vector->list */
t6=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 796  append */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k3441 in sort in k686 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 796  sort! */
t2=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3434 in sort in k686 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 795  sort! */
t2=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3430 in sort in k686 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 795  list->vector */
t2=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k686 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3285,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3288,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=((C_word)li122),tmp=(C_word)a,a+=6,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_i_vector_length(((C_word*)t4)[1]);
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3375,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 778  vector->list */
t11=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* data-structures.scm: 784  step */
t9=((C_word*)t6)[1];
f_3288(t9,t1,t8);}}

/* k3373 in sort! in k686 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 779  step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3288(t4,t3,((C_word*)t0)[2]);}

/* k3380 in k3373 in sort! in k686 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3382,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3384,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3384(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* do538 in k3380 in k3373 in sort! in k686 */
static void C_fcall f_3384(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3384,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_vector_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k686 */
static void C_fcall f_3288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3288,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3329,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3339,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 763  less? */
t10=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k3337 in step in sort! in k686 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_car(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
f_3329(t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_3329(t2,C_SCHEME_UNDEFINED);}}

/* k3327 in step in sort! in k686 */
static void C_fcall f_3329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k3296 in step in sort! in k686 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 754  step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3288(t3,t2,t1);}

/* k3299 in k3296 in step in sort! in k686 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 756  step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3288(t4,t3,t2);}

/* k3305 in k3299 in k3296 in step in sort! in k686 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 757  merge! */
t2=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k686 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3153,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3156,a[2]=t4,a[3]=t6,a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3235,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* data-structures.scm: 731  less? */
t11=t4;
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}}}

/* k3233 in merge! in k686 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_3238(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* data-structures.scm: 734  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3156(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_3258(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[4]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 739  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3156(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k3256 in k3233 in merge! in k686 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3236 in k3233 in merge! in k686 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k686 */
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3156,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3163,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_car(t3);
/* data-structures.scm: 716  less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k3161 in loop in merge! in k686 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[5],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* data-structures.scm: 721  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3156(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[5]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 727  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3156(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k686 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3054,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3088,a[2]=t4,a[3]=t10,a[4]=((C_word)li118),tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3088(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k686 */
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3088,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3095,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 699  less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t4,t2);}

/* k3093 in loop in merge in k686 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* data-structures.scm: 702  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3088(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* data-structures.scm: 706  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3088(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k3141 in k3093 in loop in merge in k686 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3113 in k3093 in loop in merge in k686 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k686 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2945,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2972,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=((C_word)li115),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2972(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3020,a[2]=t3,a[3]=t7,a[4]=((C_word)li116),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3020(t9,t1,t4,t5);}}}

/* loop in sorted? in k686 */
static void C_fcall f_3020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3020,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t3);
/* data-structures.scm: 682  less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}}

/* k3046 in loop in sorted? in k686 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 683  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3020(t4,((C_word*)t0)[4],t2,t3);}}

/* do485 in sorted? in k686 */
static void C_fcall f_2972(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2972,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_2982(2,t5,t3);}
else{
t5=(C_word)C_i_vector_ref(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[3],t6);
/* data-structures.scm: 676  less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t4,t5,t7);}}

/* k2980 in do485 in sorted? in k686 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_2972(t3,((C_word*)t0)[5],t2);}}

/* string-chomp in k686 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2893r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2893r(t0,t1,t2,t3);}}

static void C_ccall f_2893r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2897,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2897(2,t5,lf[87]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2897(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2895 in string-chomp in k686 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[86]);
t3=(C_word)C_i_check_string_2(t1,lf[86]);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
t5=(C_word)C_block_size(t1);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_fixnum_greater_or_equal_p(t4,t5);
t8=(C_truep(t7)?(C_word)C_substring_compare(((C_word*)t0)[3],t1,t6,C_fix(0),t5):C_SCHEME_FALSE);
if(C_truep(t8)){
/* data-structures.scm: 643  ##sys#substring */
t9=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t6);}
else{
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}}

/* string-chop in k686 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2829,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[85]);
t5=(C_word)C_i_check_exact_2(t3,lf[85]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2844,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=((C_word)li112),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2844(t10,t1,t6,C_fix(0));}

/* loop in string-chop in k686 */
static void C_fcall f_2844(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2844,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(t3,t2);
/* data-structures.scm: 629  ##sys#substring */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
/* data-structures.scm: 630  ##sys#substring */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k2873 in loop in string-chop in k686 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2879,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* data-structures.scm: 630  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2844(t5,t2,t3,t4);}

/* k2877 in k2873 in loop in string-chop in k686 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2862 in loop in string-chop in k686 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k686 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2707,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[83]);
t5=(C_word)C_i_check_list_2(t3,lf[83]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2719,a[2]=t3,a[3]=t8,a[4]=t2,a[5]=t6,a[6]=((C_word)li110),tmp=(C_word)a,a+=7,tmp));
/* data-structures.scm: 618  collect */
t10=((C_word*)t8)[1];
f_2719(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k686 */
static void C_fcall f_2719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2719,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2737,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 600  ##sys#substring */
t10=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_2737(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2752,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,a[9]=((C_word)li109),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_2752(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k686 */
static void C_fcall f_2752(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2752,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 604  collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2719(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2791,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2817,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 612  ##sys#substring */
t10=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_2791(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_i_cdr(t2);
/* data-structures.scm: 617  loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k2815 in loop in collect in string-translate* in k686 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_2791(t4,t3);}

/* k2789 in loop in collect in string-translate* in k686 */
static void C_fcall f_2791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2791,NULL,2,t0,t1);}
t2=(C_word)C_i_string_length(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* data-structures.scm: 613  collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2719(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k2745 in collect in string-translate* in k686 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2737(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k2735 in collect in string-translate* in k686 */
static void C_fcall f_2737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 598  reverse */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2731 in collect in string-translate* in k686 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 596  ##sys#fragments->string */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k686 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_2505r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2505r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2505r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_2542(2,t7,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=t3,a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2699,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 554  list->string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_check_string_2(t3,lf[81]);
/* data-structures.scm: 557  instring */
f_2508(t6,t3);}}}

/* k2697 in string-translate in k686 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 554  instring */
f_2508(((C_word*)t0)[2],t1);}

/* f_2682 in string-translate in k686 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2682,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k2540 in string-translate in k686 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_2545(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* data-structures.scm: 562  list->string */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t4=(C_word)C_i_check_string_2(t3,lf[81]);
t5=t2;
f_2545(2,t5,t3);}}}
else{
t3=t2;
f_2545(2,t3,C_SCHEME_FALSE);}}

/* k2543 in k2540 in string-translate in k686 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2545,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[81]);
t5=(C_word)C_block_size(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 569  make-string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k2555 in k2543 in k2540 in string-translate in k686 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word)li106),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2562(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k2555 in k2543 in k2540 in string-translate in k686 */
static void C_fcall f_2562(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2562,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* data-structures.scm: 573  ##sys#substring */
t4=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[7],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[6],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2581,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* data-structures.scm: 576  from */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}

/* k2579 in loop in k2555 in k2543 in k2540 in string-translate in k686 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[9];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 583  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2562(t7,((C_word*)t0)[4],t5,t6);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
/* data-structures.scm: 585  ##sys#error */
t4=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[81],lf[82],((C_word*)t0)[6],((C_word*)t0)[9]);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],(C_word)C_subchar(((C_word*)t0)[9],t1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 588  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2562(t7,((C_word*)t0)[4],t5,t6);}}}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* data-structures.scm: 580  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2562(t5,((C_word*)t0)[4],t4,((C_word*)t0)[7]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 579  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_2562(t6,((C_word*)t0)[4],t4,t5);}}

/* instring in string-translate in k686 */
static void C_fcall f_2508(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2508,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2513,a[2]=t2,a[3]=t3,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp));}

/* f_2513 in instring in string-translate in k686 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2513,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2519(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_2519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k686 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2390r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2390r(t0,t1,t2,t3);}}

static void C_ccall f_2390r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2394(2,t5,lf[79]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2394(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2392 in string-intersperse in k686 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(C_word)C_i_check_list_2(((C_word*)t0)[3],lf[76]);
t3=(C_word)C_i_check_string_2(t1,lf[76]);
t4=(C_word)C_block_size(t1);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2408,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2408(t8,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* loop1 in k2392 in string-intersperse in k686 */
static void C_fcall f_2408(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2408,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[77]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_fixnum_difference(t3,((C_word*)t0)[3]);
/* data-structures.scm: 517  ##sys#allocate-vector */
t6=*((C_word*)lf[78]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_i_check_string_2(t5,lf[76]);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t5);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],t3);
t10=(C_word)C_fixnum_plus(t8,t9);
/* data-structures.scm: 532  loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* data-structures.scm: 534  ##sys#not-a-proper-list-error */
t5=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k2416 in loop1 in k2392 in string-intersperse in k686 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2423(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k2416 in loop1 in k2392 in string-intersperse in k686 */
static C_word C_fcall f_2423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
C_stack_check;
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k686 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2255r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2255r(t0,t1,t2,t3);}}

static void C_ccall f_2255r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(20);
t4=(C_word)C_i_check_string_2(t2,lf[73]);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?lf[74]:(C_word)C_i_vector_ref(t3,C_fix(0)));
t7=(C_word)C_block_size(t3);
t8=(C_word)C_eqp(t7,C_fix(2));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_string_2(t6,lf[73]);
t12=(C_word)C_block_size(t6);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2276,a[2]=t2,a[3]=t14,a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2296,a[2]=t6,a[3]=t17,a[4]=t12,a[5]=t2,a[6]=t15,a[7]=t9,a[8]=t14,a[9]=t10,a[10]=((C_word)li98),tmp=(C_word)a,a+=11,tmp));
t19=((C_word*)t17)[1];
f_2296(t19,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k686 */
static void C_fcall f_2296(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2296,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* data-structures.scm: 493  add */
t8=((C_word*)t0)[6];
f_2276(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_2306(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2323,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],a[12]=((C_word)li97),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_2323(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k686 */
static void C_fcall f_2323(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2323,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* data-structures.scm: 498  loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_2296(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2362,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 502  add */
t8=((C_word*)t0)[3];
f_2276(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* data-structures.scm: 503  loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_2296(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* data-structures.scm: 504  scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k2360 in scan in loop in string-split in k686 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 502  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2296(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k2304 in loop in string-split in k686 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k686 */
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2276,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2291,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 486  ##sys#substring */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k2289 in add in string-split in k686 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2283(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_2283(t5,t4);}}

/* k2281 in k2289 in add in string-split in k686 */
static void C_fcall f_2283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k686 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_2175r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2175r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2175r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2177,a[2]=t3,a[3]=t2,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2182,a[2]=t5,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2187,a[2]=t6,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2192,a[2]=t7,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1331344 */
t9=t8;
f_2192(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2332342 */
t11=t7;
f_2187(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len333339 */
t13=t6;
f_2182(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body329335 */
t15=t5;
f_2177(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1331 in substring-ci=? in k686 */
static void C_fcall f_2192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2192,NULL,2,t0,t1);}
/* def-start2332342 */
t2=((C_word*)t0)[2];
f_2187(t2,t1,C_fix(0));}

/* def-start2332 in substring-ci=? in k686 */
static void C_fcall f_2187(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2187,NULL,3,t0,t1,t2);}
/* def-len333339 */
t3=((C_word*)t0)[2];
f_2182(t3,t1,t2,C_fix(0));}

/* def-len333 in substring-ci=? in k686 */
static void C_fcall f_2182(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2182,NULL,4,t0,t1,t2,t3);}
/* body329335 */
t4=((C_word*)t0)[2];
f_2177(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body329 in substring-ci=? in k686 */
static void C_fcall f_2177(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2177,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 471  ##sys#substring-ci=? */
t5=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring-ci=? in k686 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2138,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[72]);
t8=(C_word)C_i_check_string_2(t3,lf[72]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2148,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2148(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_2148(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k2146 in ##sys#substring-ci=? in k686 */
static void C_fcall f_2148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[72]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* substring=? in k686 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_2058r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2058r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2060,a[2]=t3,a[3]=t2,a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2065,a[2]=t5,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2070,a[2]=t6,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2075,a[2]=t7,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1290303 */
t9=t8;
f_2075(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2291301 */
t11=t7;
f_2070(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len292298 */
t13=t6;
f_2065(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body288294 */
t15=t5;
f_2060(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1290 in substring=? in k686 */
static void C_fcall f_2075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2075,NULL,2,t0,t1);}
/* def-start2291301 */
t2=((C_word*)t0)[2];
f_2070(t2,t1,C_fix(0));}

/* def-start2291 in substring=? in k686 */
static void C_fcall f_2070(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2070,NULL,3,t0,t1,t2);}
/* def-len292298 */
t3=((C_word*)t0)[2];
f_2065(t3,t1,t2,C_fix(0));}

/* def-len292 in substring=? in k686 */
static void C_fcall f_2065(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2065,NULL,4,t0,t1,t2,t3);}
/* body288294 */
t4=((C_word*)t0)[2];
f_2060(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body288 in substring=? in k686 */
static void C_fcall f_2060(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2060,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 457  ##sys#substring=? */
t5=*((C_word*)lf[69]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring=? in k686 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2021,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[70]);
t8=(C_word)C_i_check_string_2(t3,lf[70]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2031,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2031(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_2031(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k2029 in ##sys#substring=? in k686 */
static void C_fcall f_2031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[70]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* string-compare3-ci in k686 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1990,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[68]);
t5=(C_word)C_i_check_string_2(t3,lf[68]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_string_compare_case_insensitive(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* string-compare3 in k686 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1959,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[67]);
t5=(C_word)C_i_check_string_2(t3,lf[67]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_mem_compare(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* substring-index-ci in k686 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1931r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1931r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1931r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1935,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1935(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1935(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1933 in substring-index-ci in k686 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 416  ##sys#substring-index-ci */
t2=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* substring-index in k686 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1903r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1903r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1907,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1907(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1907(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1905 in substring-index in k686 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 413  ##sys#substring-index */
t2=*((C_word*)lf[63]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#substring-index-ci in k686 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1894,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1900,a[2]=t3,a[3]=t2,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 407  traverse */
f_1838(t1,t2,t3,t4,t5,lf[66]);}

/* a1899 in ##sys#substring-index-ci in k686 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1900,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* ##sys#substring-index in k686 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1885,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1891,a[2]=t3,a[3]=t2,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 401  traverse */
f_1838(t1,t2,t3,t4,t5,lf[64]);}

/* a1890 in ##sys#substring-index in k686 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1891,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k686 */
static void C_fcall f_1838(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1838,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,t6);
t8=(C_word)C_i_check_string_2(t3,t6);
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_exact_2(t4,t6);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1859,a[2]=t10,a[3]=t5,a[4]=t13,a[5]=t9,a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_1859(t15,t1,t4,t10);}

/* loop in traverse in k686 */
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1859,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 395  test */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k1870 in loop in traverse in k686 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 397  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1859(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k686 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1828r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1828r(t0,t1,t2);}}

static void C_ccall f_1828r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[58]+1),t2);}

/* k1834 in conc in k686 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k686 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* data-structures.scm: 370  symbol->string */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
/* data-structures.scm: 371  string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* data-structures.scm: 372  ##sys#number->string */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1820,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 374  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}}}}

/* k1818 in ->string in k686 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1823,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 375  display */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k1821 in k1818 in ->string in k686 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 376  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##data-structures#reverse-string-append in k686 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1706,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1709,a[2]=t4,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
/* data-structures.scm: 359  rev-string-append */
t6=((C_word*)t4)[1];
f_1709(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##data-structures#reverse-string-append in k686 */
static void C_fcall f_1709(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1709,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1725,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* data-structures.scm: 350  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* data-structures.scm: 357  make-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k1723 in rev-string-append in ##data-structures#reverse-string-append in k686 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1734,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1734(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k1723 in rev-string-append in ##data-structures#reverse-string-append in k686 */
static void C_fcall f_1734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1734,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* data-structures.scm: 355  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* rassoc in k686 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1656r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1656r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1656r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_list_2(t3,lf[51]);
t6=(C_word)C_notvemptyp(t4);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t4,C_fix(0)):*((C_word*)lf[44]+1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1668,a[2]=t2,a[3]=t7,a[4]=t9,a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1668(t11,t1,t3);}

/* loop in rassoc in k686 */
static void C_fcall f_1668(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1668,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[51]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 336  tst */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1685 in loop in rassoc in k686 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 338  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1668(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k686 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1532r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1532r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1532r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1534,a[2]=t3,a[3]=t2,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1603,a[2]=t5,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1608,a[2]=t6,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp158174 */
t8=t7;
f_1608(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default159172 */
t10=t6;
f_1603(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body156161 */
t12=t5;
f_1534(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-cmp158 in alist-ref in k686 */
static void C_fcall f_1608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1608,NULL,2,t0,t1);}
/* def-default159172 */
t2=((C_word*)t0)[2];
f_1603(t2,t1,*((C_word*)lf[44]+1));}

/* def-default159 in alist-ref in k686 */
static void C_fcall f_1603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1603,NULL,3,t0,t1,t2);}
/* body156161 */
t3=((C_word*)t0)[2];
f_1534(t3,t1,t2,C_SCHEME_FALSE);}

/* body156 in alist-ref in k686 */
static void C_fcall f_1534(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1534,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[45]+1),t2);
if(C_truep(t5)){
t6=t4;
f_1538(t6,*((C_word*)lf[46]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[44]+1),t2);
if(C_truep(t6)){
t7=t4;
f_1538(t7,*((C_word*)lf[47]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[48]+1),t2);
t8=t4;
f_1538(t8,(C_truep(t7)?*((C_word*)lf[49]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1563,a[2]=t2,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp)));}}}

/* f_1563 in body156 in alist-ref in k686 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1563,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1569,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1569(t7,t1,t3);}

/* loop */
static void C_fcall f_1569(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1569,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 321  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_1585(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1583 in loop */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 323  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1569(t3,((C_word*)t0)[5],t2);}}

/* k1536 in body156 in alist-ref in k686 */
static void C_fcall f_1538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 324  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1539 in k1536 in body156 in alist-ref in k686 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k686 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5rv,(void*)f_1446r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_1446r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1446r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t5,C_fix(0)):*((C_word*)lf[44]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1453,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[45]+1),t7);
if(C_truep(t9)){
t10=t8;
f_1453(t10,*((C_word*)lf[46]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[44]+1),t7);
if(C_truep(t10)){
t11=t8;
f_1453(t11,*((C_word*)lf[47]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[48]+1),t7);
t12=t8;
f_1453(t12,(C_truep(t11)?*((C_word*)lf[49]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1485,a[2]=t7,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp)));}}}

/* f_1485 in alist-update! in k686 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1485,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1491,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1491(t7,t1,t3);}

/* loop */
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1491,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 302  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_1507(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1505 in loop */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 304  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1491(t3,((C_word*)t0)[5],t2);}}

/* k1451 in alist-update! in k686 */
static void C_fcall f_1453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1453,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 305  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1454 in k1451 in alist-update! in k686 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k686 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1405,4,t0,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1416,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1420,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1436,a[2]=t4,a[3]=t3,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
/* map */
t8=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}

/* a1435 in shuffle in k686 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1436,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1444,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 286  random */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1442 in a1435 in shuffle in k686 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1418 in shuffle in k686 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1422,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm: 286  sort! */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a1421 in k1418 in shuffle in k686 */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1422,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k1414 in shuffle in k686 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[41]+1),t1);}

/* compress in k686 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1325,4,t0,t1,t2,t3);}
t4=lf[36];
t5=(C_word)C_i_check_list_2(t3,lf[35]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1334,a[2]=t4,a[3]=t7,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1334(t9,t1,t2,t3);}

/* loop in compress in k686 */
static void C_fcall f_1334(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1334,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 278  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 279  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
/* data-structures.scm: 277  ##sys#signal-hook */
t4=*((C_word*)lf[37]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[38],lf[35],((C_word*)t0)[2],t3);}}
else{
/* data-structures.scm: 275  ##sys#signal-hook */
t4=*((C_word*)lf[37]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[38],lf[35],((C_word*)t0)[2],t2);}}}

/* k1374 in loop in compress in k686 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k686 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1266r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1266r(t0,t1,t2,t3);}}

static void C_ccall f_1266r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[33]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1278,a[2]=t8,a[3]=t5,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1278(t10,t1,t2);}

/* loop in join in k686 */
static void C_fcall f_1278(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1278,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 266  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}
else{
/* data-structures.scm: 260  ##sys#not-a-proper-list-error */
t3=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}}

/* k1311 in loop in join in k686 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 266  ##sys#append */
t2=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k686 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1181,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[30]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1188,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* data-structures.scm: 241  ##sys#error */
t6=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[30],lf[32],t3);}
else{
t6=t5;
f_1188(2,t6,C_SCHEME_UNDEFINED);}}

/* k1186 in chop in k686 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1188,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1196(t6,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* loop in k1186 in chop in k686 */
static void C_fcall f_1196(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1196,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1217,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word)li48),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1217(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* do104 in loop in k1186 in chop in k686 */
static void C_fcall f_1217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1217,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1231,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 252  reverse */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k1229 in do104 in loop in k1186 in chop in k686 */
static void C_ccall f_1231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* data-structures.scm: 252  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1196(t4,t2,((C_word*)t0)[2],t3);}

/* k1233 in k1229 in do104 in loop in k1186 in chop in k686 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k686 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1140r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1140r(t0,t1,t2);}}

static void C_ccall f_1140r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1146,a[2]=t4,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1146(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k686 */
static void C_fcall f_1146(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1146,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1172,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 233  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1179,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 234  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k1177 in loop in flatten in k686 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1170 in loop in flatten in k686 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 233  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1146(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k686 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1108,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[28]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1117,a[2]=t5,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1117(t7,t1,t2);}

/* loop in butlast in k686 */
static void C_fcall f_1117(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1117,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1138,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 223  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k1136 in loop in butlast in k686 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k686 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1075,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1081,a[2]=t5,a[3]=t3,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1081(t7,t1,t2);}

/* loop in intersperse in k686 */
static void C_fcall f_1081(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1081,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1106,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 216  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k1104 in loop in intersperse in k686 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k686 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1047,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[26]);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1059,a[2]=t2,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_1059(t6,t3));}}

/* loop in tail? in k686 */
static C_word C_fcall f_1059(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k686 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1044,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* right-section in k686 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1018r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1018r(t0,t1,t2,t3);}}

static void C_ccall f_1018r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1022,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 190  ##sys#check-closure */
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[24]);}

/* k1020 in right-section in k686 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 191  ##sys#reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1023 in k1020 in right-section in k686 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1026,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li37),tmp=(C_word)a,a+=6,tmp));}

/* f_1026 in k1023 in k1020 in right-section in k686 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_1026r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1026r(t0,t1,t2);}}

static void C_ccall f_1026r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1038,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 193  ##sys#reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1040 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 193  ##sys#append */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1036 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 193  ##sys#reverse */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1032 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* left-section in k686 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1003r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1003r(t0,t1,t2,t3);}}

static void C_ccall f_1003r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1007,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 183  ##sys#check-closure */
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[20]);}

/* k1005 in left-section in k686 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));}

/* f_1008 in k1005 in left-section in k686 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1008r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1008r(t0,t1,t2);}}

static void C_ccall f_1008r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 185  ##sys#append */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k1014 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* never? in k686 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* always? in k686 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* none? in k686 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_994,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* any? in k686 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_991,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* each in k686 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_935r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_935r(t0,t1,t2);}}

static void C_ccall f_935r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_943,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_957,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp)));}}

/* f_957 in each in k686 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_957r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_957r(t0,t1,t2);}}

static void C_ccall f_957r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_963,a[2]=t4,a[3]=t2,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_963(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_963(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_963,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
C_apply(4,0,t1,t3,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_982,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,t3,((C_word*)t0)[3]);}}

/* k980 in loop */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 172  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_963(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_943 in each in k686 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* noop in k686 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_929,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* list-of in k686 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_889,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_891,a[2]=t2,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));}

/* f_891 in list-of in k686 */
static void C_ccall f_891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_891,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_897(t6,t1,t2);}

/* loop */
static void C_fcall f_897(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_897,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_916,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* data-structures.scm: 155  pred */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k914 in loop */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 155  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_897(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* o in k686 */
static void C_ccall f_850(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_850r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_850r(t0,t1,t2);}}

static void C_ccall f_850r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[3]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_862,a[2]=t4,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_862(t6,t1,t2);}}

/* loop in o in k686 */
static void C_fcall f_862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_862,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_876,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp)));}

/* f_876 in loop in o in k686 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_876,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_884,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_887,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 148  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_862(t5,t4,((C_word*)t0)[2]);}

/* k885 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k882 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 148  h */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* compose in k686 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_814r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_814r(t0,t1,t2);}}

static void C_ccall f_814r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_817,a[2]=t4,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[11]+1));}
else{
C_apply(4,0,t1,((C_word*)t4)[1],t2);}}

/* rec in compose in k686 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_817r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_817r(t0,t1,t2,t3);}}

static void C_ccall f_817r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_825,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp)));}

/* f_825 in rec in compose in k686 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_825r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_825r(t0,t1,t2);}}

static void C_ccall f_825r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 133  call-with-values */
C_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a830 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k837 in a830 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k686 */
static void C_ccall f_802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_802,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_804,a[2]=t2,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));}

/* f_804 in complement in k686 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_804r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_804r(t0,t1,t2);}}

static void C_ccall f_804r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_812,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k810 */
static void C_ccall f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k686 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_794,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_796,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));}

/* f_796 in flip in k686 */
static void C_ccall f_796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_796,4,t0,t1,t2,t3);}
/* data-structures.scm: 122  proc */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* constantly in k686 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_771r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_771r(t0,t1,t2);}}

static void C_ccall f_771r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_782,a[2]=t5,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_784,a[2]=t2,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));}}

/* f_784 in constantly in k686 */
static void C_ccall f_784(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_784,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_782 in constantly in k686 */
static void C_ccall f_782(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_782,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k686 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_734r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_734r(t0,t1,t2);}}

static void C_ccall f_734r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_736,a[2]=t2,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp));}

/* f_736 in disjoin in k686 */
static void C_ccall f_736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_736,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_742,a[2]=t2,a[3]=t4,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_742(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_742(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_742,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_752,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[2]);}}

/* k750 in loop */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 114  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_742(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k686 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_701r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_701r(t0,t1,t2);}}

static void C_ccall f_701r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_703,a[2]=t2,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));}

/* f_703 in conjoin in k686 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_703,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_709,a[2]=t2,a[3]=t4,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_709(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_709,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_722,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[2]);}}

/* k720 in loop */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 107  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_709(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k686 */
static void C_ccall f_693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_693,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=t2,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));}

/* f_695 in project in k686 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_695r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_695r(t0,t1,t2);}}

static void C_ccall f_695r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,((C_word*)t0)[2]));}

/* identity in k686 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_690,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[237] = {
{"topleveldata-structures.scm",(void*)C_data_structures_toplevel},
{"f_688data-structures.scm",(void*)f_688},
{"f_3755data-structures.scm",(void*)f_3755},
{"f_3765data-structures.scm",(void*)f_3765},
{"f_3782data-structures.scm",(void*)f_3782},
{"f_3768data-structures.scm",(void*)f_3768},
{"f_3726data-structures.scm",(void*)f_3726},
{"f_3672data-structures.scm",(void*)f_3672},
{"f_3691data-structures.scm",(void*)f_3691},
{"f_3701data-structures.scm",(void*)f_3701},
{"f_3683data-structures.scm",(void*)f_3683},
{"f_3663data-structures.scm",(void*)f_3663},
{"f_3627data-structures.scm",(void*)f_3627},
{"f_3637data-structures.scm",(void*)f_3637},
{"f_3595data-structures.scm",(void*)f_3595},
{"f_3605data-structures.scm",(void*)f_3605},
{"f_3574data-structures.scm",(void*)f_3574},
{"f_3584data-structures.scm",(void*)f_3584},
{"f_3553data-structures.scm",(void*)f_3553},
{"f_3563data-structures.scm",(void*)f_3563},
{"f_3540data-structures.scm",(void*)f_3540},
{"f_3534data-structures.scm",(void*)f_3534},
{"f_3528data-structures.scm",(void*)f_3528},
{"f_3445data-structures.scm",(void*)f_3445},
{"f_3523data-structures.scm",(void*)f_3523},
{"f_3449data-structures.scm",(void*)f_3449},
{"f_3463data-structures.scm",(void*)f_3463},
{"f_3473data-structures.scm",(void*)f_3473},
{"f_3418data-structures.scm",(void*)f_3418},
{"f_3443data-structures.scm",(void*)f_3443},
{"f_3436data-structures.scm",(void*)f_3436},
{"f_3432data-structures.scm",(void*)f_3432},
{"f_3285data-structures.scm",(void*)f_3285},
{"f_3375data-structures.scm",(void*)f_3375},
{"f_3382data-structures.scm",(void*)f_3382},
{"f_3384data-structures.scm",(void*)f_3384},
{"f_3288data-structures.scm",(void*)f_3288},
{"f_3339data-structures.scm",(void*)f_3339},
{"f_3329data-structures.scm",(void*)f_3329},
{"f_3298data-structures.scm",(void*)f_3298},
{"f_3301data-structures.scm",(void*)f_3301},
{"f_3307data-structures.scm",(void*)f_3307},
{"f_3153data-structures.scm",(void*)f_3153},
{"f_3235data-structures.scm",(void*)f_3235},
{"f_3258data-structures.scm",(void*)f_3258},
{"f_3238data-structures.scm",(void*)f_3238},
{"f_3156data-structures.scm",(void*)f_3156},
{"f_3163data-structures.scm",(void*)f_3163},
{"f_3054data-structures.scm",(void*)f_3054},
{"f_3088data-structures.scm",(void*)f_3088},
{"f_3095data-structures.scm",(void*)f_3095},
{"f_3143data-structures.scm",(void*)f_3143},
{"f_3115data-structures.scm",(void*)f_3115},
{"f_2945data-structures.scm",(void*)f_2945},
{"f_3020data-structures.scm",(void*)f_3020},
{"f_3048data-structures.scm",(void*)f_3048},
{"f_2972data-structures.scm",(void*)f_2972},
{"f_2982data-structures.scm",(void*)f_2982},
{"f_2893data-structures.scm",(void*)f_2893},
{"f_2897data-structures.scm",(void*)f_2897},
{"f_2829data-structures.scm",(void*)f_2829},
{"f_2844data-structures.scm",(void*)f_2844},
{"f_2875data-structures.scm",(void*)f_2875},
{"f_2879data-structures.scm",(void*)f_2879},
{"f_2864data-structures.scm",(void*)f_2864},
{"f_2707data-structures.scm",(void*)f_2707},
{"f_2719data-structures.scm",(void*)f_2719},
{"f_2752data-structures.scm",(void*)f_2752},
{"f_2817data-structures.scm",(void*)f_2817},
{"f_2791data-structures.scm",(void*)f_2791},
{"f_2747data-structures.scm",(void*)f_2747},
{"f_2737data-structures.scm",(void*)f_2737},
{"f_2733data-structures.scm",(void*)f_2733},
{"f_2505data-structures.scm",(void*)f_2505},
{"f_2699data-structures.scm",(void*)f_2699},
{"f_2682data-structures.scm",(void*)f_2682},
{"f_2542data-structures.scm",(void*)f_2542},
{"f_2545data-structures.scm",(void*)f_2545},
{"f_2557data-structures.scm",(void*)f_2557},
{"f_2562data-structures.scm",(void*)f_2562},
{"f_2581data-structures.scm",(void*)f_2581},
{"f_2508data-structures.scm",(void*)f_2508},
{"f_2513data-structures.scm",(void*)f_2513},
{"f_2519data-structures.scm",(void*)f_2519},
{"f_2390data-structures.scm",(void*)f_2390},
{"f_2394data-structures.scm",(void*)f_2394},
{"f_2408data-structures.scm",(void*)f_2408},
{"f_2418data-structures.scm",(void*)f_2418},
{"f_2423data-structures.scm",(void*)f_2423},
{"f_2255data-structures.scm",(void*)f_2255},
{"f_2296data-structures.scm",(void*)f_2296},
{"f_2323data-structures.scm",(void*)f_2323},
{"f_2362data-structures.scm",(void*)f_2362},
{"f_2306data-structures.scm",(void*)f_2306},
{"f_2276data-structures.scm",(void*)f_2276},
{"f_2291data-structures.scm",(void*)f_2291},
{"f_2283data-structures.scm",(void*)f_2283},
{"f_2175data-structures.scm",(void*)f_2175},
{"f_2192data-structures.scm",(void*)f_2192},
{"f_2187data-structures.scm",(void*)f_2187},
{"f_2182data-structures.scm",(void*)f_2182},
{"f_2177data-structures.scm",(void*)f_2177},
{"f_2138data-structures.scm",(void*)f_2138},
{"f_2148data-structures.scm",(void*)f_2148},
{"f_2058data-structures.scm",(void*)f_2058},
{"f_2075data-structures.scm",(void*)f_2075},
{"f_2070data-structures.scm",(void*)f_2070},
{"f_2065data-structures.scm",(void*)f_2065},
{"f_2060data-structures.scm",(void*)f_2060},
{"f_2021data-structures.scm",(void*)f_2021},
{"f_2031data-structures.scm",(void*)f_2031},
{"f_1990data-structures.scm",(void*)f_1990},
{"f_1959data-structures.scm",(void*)f_1959},
{"f_1931data-structures.scm",(void*)f_1931},
{"f_1935data-structures.scm",(void*)f_1935},
{"f_1903data-structures.scm",(void*)f_1903},
{"f_1907data-structures.scm",(void*)f_1907},
{"f_1894data-structures.scm",(void*)f_1894},
{"f_1900data-structures.scm",(void*)f_1900},
{"f_1885data-structures.scm",(void*)f_1885},
{"f_1891data-structures.scm",(void*)f_1891},
{"f_1838data-structures.scm",(void*)f_1838},
{"f_1859data-structures.scm",(void*)f_1859},
{"f_1872data-structures.scm",(void*)f_1872},
{"f_1828data-structures.scm",(void*)f_1828},
{"f_1836data-structures.scm",(void*)f_1836},
{"f_1783data-structures.scm",(void*)f_1783},
{"f_1820data-structures.scm",(void*)f_1820},
{"f_1823data-structures.scm",(void*)f_1823},
{"f_1706data-structures.scm",(void*)f_1706},
{"f_1709data-structures.scm",(void*)f_1709},
{"f_1725data-structures.scm",(void*)f_1725},
{"f_1734data-structures.scm",(void*)f_1734},
{"f_1656data-structures.scm",(void*)f_1656},
{"f_1668data-structures.scm",(void*)f_1668},
{"f_1687data-structures.scm",(void*)f_1687},
{"f_1532data-structures.scm",(void*)f_1532},
{"f_1608data-structures.scm",(void*)f_1608},
{"f_1603data-structures.scm",(void*)f_1603},
{"f_1534data-structures.scm",(void*)f_1534},
{"f_1563data-structures.scm",(void*)f_1563},
{"f_1569data-structures.scm",(void*)f_1569},
{"f_1585data-structures.scm",(void*)f_1585},
{"f_1538data-structures.scm",(void*)f_1538},
{"f_1541data-structures.scm",(void*)f_1541},
{"f_1446data-structures.scm",(void*)f_1446},
{"f_1485data-structures.scm",(void*)f_1485},
{"f_1491data-structures.scm",(void*)f_1491},
{"f_1507data-structures.scm",(void*)f_1507},
{"f_1453data-structures.scm",(void*)f_1453},
{"f_1456data-structures.scm",(void*)f_1456},
{"f_1405data-structures.scm",(void*)f_1405},
{"f_1436data-structures.scm",(void*)f_1436},
{"f_1444data-structures.scm",(void*)f_1444},
{"f_1420data-structures.scm",(void*)f_1420},
{"f_1422data-structures.scm",(void*)f_1422},
{"f_1416data-structures.scm",(void*)f_1416},
{"f_1325data-structures.scm",(void*)f_1325},
{"f_1334data-structures.scm",(void*)f_1334},
{"f_1376data-structures.scm",(void*)f_1376},
{"f_1266data-structures.scm",(void*)f_1266},
{"f_1278data-structures.scm",(void*)f_1278},
{"f_1313data-structures.scm",(void*)f_1313},
{"f_1181data-structures.scm",(void*)f_1181},
{"f_1188data-structures.scm",(void*)f_1188},
{"f_1196data-structures.scm",(void*)f_1196},
{"f_1217data-structures.scm",(void*)f_1217},
{"f_1231data-structures.scm",(void*)f_1231},
{"f_1235data-structures.scm",(void*)f_1235},
{"f_1140data-structures.scm",(void*)f_1140},
{"f_1146data-structures.scm",(void*)f_1146},
{"f_1179data-structures.scm",(void*)f_1179},
{"f_1172data-structures.scm",(void*)f_1172},
{"f_1108data-structures.scm",(void*)f_1108},
{"f_1117data-structures.scm",(void*)f_1117},
{"f_1138data-structures.scm",(void*)f_1138},
{"f_1075data-structures.scm",(void*)f_1075},
{"f_1081data-structures.scm",(void*)f_1081},
{"f_1106data-structures.scm",(void*)f_1106},
{"f_1047data-structures.scm",(void*)f_1047},
{"f_1059data-structures.scm",(void*)f_1059},
{"f_1044data-structures.scm",(void*)f_1044},
{"f_1018data-structures.scm",(void*)f_1018},
{"f_1022data-structures.scm",(void*)f_1022},
{"f_1025data-structures.scm",(void*)f_1025},
{"f_1026data-structures.scm",(void*)f_1026},
{"f_1042data-structures.scm",(void*)f_1042},
{"f_1038data-structures.scm",(void*)f_1038},
{"f_1034data-structures.scm",(void*)f_1034},
{"f_1003data-structures.scm",(void*)f_1003},
{"f_1007data-structures.scm",(void*)f_1007},
{"f_1008data-structures.scm",(void*)f_1008},
{"f_1016data-structures.scm",(void*)f_1016},
{"f_1000data-structures.scm",(void*)f_1000},
{"f_997data-structures.scm",(void*)f_997},
{"f_994data-structures.scm",(void*)f_994},
{"f_991data-structures.scm",(void*)f_991},
{"f_935data-structures.scm",(void*)f_935},
{"f_957data-structures.scm",(void*)f_957},
{"f_963data-structures.scm",(void*)f_963},
{"f_982data-structures.scm",(void*)f_982},
{"f_943data-structures.scm",(void*)f_943},
{"f_929data-structures.scm",(void*)f_929},
{"f_889data-structures.scm",(void*)f_889},
{"f_891data-structures.scm",(void*)f_891},
{"f_897data-structures.scm",(void*)f_897},
{"f_916data-structures.scm",(void*)f_916},
{"f_850data-structures.scm",(void*)f_850},
{"f_862data-structures.scm",(void*)f_862},
{"f_876data-structures.scm",(void*)f_876},
{"f_887data-structures.scm",(void*)f_887},
{"f_884data-structures.scm",(void*)f_884},
{"f_814data-structures.scm",(void*)f_814},
{"f_817data-structures.scm",(void*)f_817},
{"f_825data-structures.scm",(void*)f_825},
{"f_831data-structures.scm",(void*)f_831},
{"f_839data-structures.scm",(void*)f_839},
{"f_802data-structures.scm",(void*)f_802},
{"f_804data-structures.scm",(void*)f_804},
{"f_812data-structures.scm",(void*)f_812},
{"f_794data-structures.scm",(void*)f_794},
{"f_796data-structures.scm",(void*)f_796},
{"f_771data-structures.scm",(void*)f_771},
{"f_784data-structures.scm",(void*)f_784},
{"f_782data-structures.scm",(void*)f_782},
{"f_734data-structures.scm",(void*)f_734},
{"f_736data-structures.scm",(void*)f_736},
{"f_742data-structures.scm",(void*)f_742},
{"f_752data-structures.scm",(void*)f_752},
{"f_701data-structures.scm",(void*)f_701},
{"f_703data-structures.scm",(void*)f_703},
{"f_709data-structures.scm",(void*)f_709},
{"f_722data-structures.scm",(void*)f_722},
{"f_693data-structures.scm",(void*)f_693},
{"f_695data-structures.scm",(void*)f_695},
{"f_690data-structures.scm",(void*)f_690},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
