/* Generated from data-structures.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-07-30 23:11
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-28 on dill (Linux)
   command line: data-structures.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file data-structures.c -extend private-namespace.scm
   unit: data_structures
*/

#include "chicken.h"

#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[115];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,13),40,105,100,101,110,116,105,116,121,32,120,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,102,95,55,48,51,32,46,32,97,114,103,115,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,12),40,112,114,111,106,101,99,116,32,110,50,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,112,114,101,100,115,55,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,10),40,102,95,55,49,49,32,120,53,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,99,111,110,106,111,105,110,32,46,32,112,114,101,100,115,52,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,11),40,102,95,55,52,52,32,120,49,50,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,19),40,100,105,115,106,111,105,110,32,46,32,112,114,101,100,115,49,49,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,13),40,102,95,55,57,48,32,46,32,95,50,48,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,102,95,55,57,50,32,46,32,95,50,49,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,19),40,99,111,110,115,116,97,110,116,108,121,32,46,32,120,115,49,56,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,15),40,102,95,56,48,52,32,120,50,51,32,121,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,102,108,105,112,32,112,114,111,99,50,50,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,102,95,56,49,50,32,46,32,97,114,103,115,50,54,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,99,111,109,112,108,101,109,101,110,116,32,112,50,53,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,6),40,97,56,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,16),40,102,95,56,51,51,32,46,32,97,114,103,115,51,49,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,18),40,114,101,99,32,102,48,50,57,32,46,32,102,110,115,51,48,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,17),40,99,111,109,112,111,115,101,32,46,32,102,110,115,50,55,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,11),40,102,95,56,56,52,32,120,51,56,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,102,110,115,51,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,11),40,111,32,46,32,102,110,115,51,51,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,52,51,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,13),40,102,95,56,57,57,32,108,115,116,52,49,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,17),40,108,105,115,116,45,111,102,63,32,112,114,101,100,52,48,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,110,111,111,112,32,46,32,95,52,53,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,102,95,57,53,50,32,46,32,95,52,55,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,111,99,115,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,102,95,57,54,54,32,46,32,97,114,103,115,52,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,16),40,101,97,99,104,32,46,32,112,114,111,99,115,52,54,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,10),40,97,110,121,63,32,120,53,53,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,11),40,110,111,110,101,63,32,120,53,54,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,15),40,97,108,119,97,121,115,63,32,46,32,95,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,14),40,110,101,118,101,114,63,32,46,32,95,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,102,95,49,48,49,55,32,46,32,120,115,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,30),40,108,101,102,116,45,115,101,99,116,105,111,110,32,112,114,111,99,53,57,32,46,32,97,114,103,115,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,102,95,49,48,51,53,32,46,32,120,115,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,31),40,114,105,103,104,116,45,115,101,99,116,105,111,110,32,112,114,111,99,54,52,32,46,32,97,114,103,115,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,11),40,97,116,111,109,63,32,120,54,57,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,15),40,116,97,105,108,63,32,120,55,48,32,121,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,115,56,49,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,23),40,105,110,116,101,114,115,112,101,114,115,101,32,108,115,116,55,56,32,120,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,56,54,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,15),40,98,117,116,108,97,115,116,32,108,115,116,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,108,105,115,116,115,57,50,32,114,101,115,116,57,51,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,20),40,102,108,97,116,116,101,110,32,46,32,108,105,115,116,115,48,57,48,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,24),40,100,111,49,48,52,32,104,100,49,48,54,32,116,108,49,48,55,32,99,49,48,56,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,115,116,49,48,50,32,105,49,48,51,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,16),40,99,104,111,112,32,108,115,116,57,56,32,110,57,57,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,115,49,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,106,111,105,110,32,108,115,116,115,49,49,51,32,46,32,108,115,116,49,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,98,108,115,116,49,50,54,32,108,115,116,49,50,55,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,99,111,109,112,114,101,115,115,32,98,108,115,116,49,50,50,32,108,115,116,49,50,51,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,17),40,97,49,52,51,48,32,120,49,51,52,32,121,49,51,53,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,49,52,52,52,32,120,49,51,51,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,24),40,115,104,117,102,102,108,101,32,108,49,51,48,32,114,97,110,100,111,109,49,51,49,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,52,53,41,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,102,95,49,52,57,52,32,120,49,52,50,32,108,115,116,49,52,51,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,41),40,97,108,105,115,116,45,117,112,100,97,116,101,33,32,120,49,51,54,32,121,49,51,55,32,108,115,116,49,51,56,32,46,32,99,109,112,49,51,57,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,54,56,41,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,102,95,49,53,55,50,32,120,49,54,53,32,108,115,116,49,54,54,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,53,54,32,99,109,112,49,54,50,32,100,101,102,97,117,108,116,49,54,51,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,100,101,102,97,117,108,116,49,53,57,32,37,99,109,112,49,53,52,49,55,51,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,99,109,112,49,53,56,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,33),40,97,108,105,115,116,45,114,101,102,32,120,49,53,49,32,108,115,116,49,53,50,32,46,32,103,49,53,48,49,53,51,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,49,56,53,41,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,114,97,115,115,111,99,32,120,49,56,48,32,108,115,116,49,56,49,32,46,32,116,115,116,49,56,50,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,106,49,57,56,32,107,49,57,57,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,29),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,49,57,50,32,105,49,57,51,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,46),40,35,35,100,97,116,97,45,115,116,114,117,99,116,117,114,101,115,35,114,101,118,101,114,115,101,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,49,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,15),40,45,62,115,116,114,105,110,103,32,120,50,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,99,111,110,99,32,46,32,97,114,103,115,50,49,49,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,115,116,97,114,116,50,50,49,32,105,101,110,100,50,50,50,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,52),40,116,114,97,118,101,114,115,101,32,119,104,105,99,104,50,49,51,32,119,104,101,114,101,50,49,52,32,115,116,97,114,116,50,49,53,32,116,101,115,116,50,49,54,32,108,111,99,50,49,55,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,17),40,97,49,56,57,57,32,105,50,51,48,32,108,50,51,49,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,50,50,55,32,119,104,101,114,101,50,50,56,32,115,116,97,114,116,50,50,57,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,97,49,57,48,56,32,105,50,51,53,32,108,50,51,54,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,53),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,50,51,50,32,119,104,101,114,101,50,51,51,32,115,116,97,114,116,50,51,52,41,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,45),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,50,52,48,32,119,104,101,114,101,50,52,49,32,46,32,103,50,51,57,50,52,50,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,48),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,50,52,55,32,119,104,101,114,101,50,52,56,32,46,32,103,50,52,54,50,52,57,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,29),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,32,115,49,50,53,51,32,115,50,50,53,52,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,45,99,105,32,115,49,50,54,49,32,115,50,50,54,50,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,61,63,32,115,49,50,54,57,32,115,50,50,55,48,32,115,116,97,114,116,49,50,55,49,32,115,116,97,114,116,50,50,55,50,32,110,50,55,51,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,50,56,56,32,115,116,97,114,116,49,50,57,53,32,115,116,97,114,116,50,50,57,54,32,108,101,110,50,57,55,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,108,101,110,50,57,50,32,37,115,116,97,114,116,49,50,56,53,50,57,57,32,37,115,116,97,114,116,50,50,56,54,51,48,48,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,50,50,57,49,32,37,115,116,97,114,116,49,50,56,53,51,48,50,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,115,116,97,114,116,49,50,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,35),40,115,117,98,115,116,114,105,110,103,61,63,32,115,49,50,56,50,32,115,50,50,56,51,32,46,32,103,50,56,49,50,56,52,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,59),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,51,49,48,32,115,50,51,49,49,32,115,116,97,114,116,49,51,49,50,32,115,116,97,114,116,50,51,49,51,32,110,51,49,52,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,51,50,57,32,115,116,97,114,116,49,51,51,54,32,115,116,97,114,116,50,51,51,55,32,108,101,110,51,51,56,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,108,101,110,51,51,51,32,37,115,116,97,114,116,49,51,50,54,51,52,48,32,37,115,116,97,114,116,50,51,50,55,51,52,49,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,50,51,51,50,32,37,115,116,97,114,116,49,51,50,54,51,52,51,41,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,115,116,97,114,116,49,51,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,38),40,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,51,50,51,32,115,50,51,50,52,32,46,32,103,51,50,50,51,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,27),40,97,100,100,32,102,114,111,109,51,53,57,32,116,111,51,54,48,32,108,97,115,116,51,54,49,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,51,55,53,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,105,51,54,53,32,108,97,115,116,51,54,54,32,102,114,111,109,51,54,55,41,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,42),40,115,116,114,105,110,103,45,115,112,108,105,116,32,115,116,114,51,53,49,32,46,32,100,101,108,115,116,114,45,97,110,100,45,102,108,97,103,51,53,50,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,50,32,110,50,51,57,55,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,49,32,115,115,51,57,50,32,110,51,57,51,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,38),40,115,116,114,105,110,103,45,105,110,116,101,114,115,112,101,114,115,101,32,115,116,114,115,51,56,53,32,46,32,103,51,56,52,51,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,13),40,102,95,50,53,50,50,32,99,52,49,56,41,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,15),40,105,110,115,116,114,105,110,103,32,115,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,105,52,51,50,32,106,52,51,51,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,13),40,102,95,50,54,57,49,32,99,52,50,51,41,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,32,115,116,114,52,49,50,32,102,114,111,109,52,49,51,32,46,32,116,111,52,49,52,41,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,109,97,112,52,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,37),40,99,111,108,108,101,99,116,32,105,52,52,54,32,102,114,111,109,52,52,55,32,116,111,116,97,108,52,52,56,32,102,115,52,52,57,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,34),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,42,32,115,116,114,52,52,50,32,115,109,97,112,52,52,51,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,116,111,116,97,108,52,54,54,32,112,111,115,52,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,27),40,115,116,114,105,110,103,45,99,104,111,112,32,115,116,114,52,54,50,32,108,101,110,52,54,51,41,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,31),40,115,116,114,105,110,103,45,99,104,111,109,112,32,115,116,114,52,55,50,32,46,32,103,52,55,49,52,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,12),40,100,111,52,56,53,32,105,52,56,55,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,108,97,115,116,52,57,50,32,110,101,120,116,52,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,25),40,115,111,114,116,101,100,63,32,115,101,113,52,56,50,32,108,101,115,115,63,52,56,51,41,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,120,53,48,49,32,97,53,48,50,32,121,53,48,51,32,98,53,48,52,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,26),40,109,101,114,103,101,32,97,52,57,55,32,98,52,57,56,32,108,101,115,115,63,52,57,57,41,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,114,53,49,48,32,97,53,49,49,32,98,53,49,50,41,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,27),40,109,101,114,103,101,33,32,97,53,48,54,32,98,53,48,55,32,108,101,115,115,63,53,48,56,41,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,11),40,115,116,101,112,32,110,53,50,49,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,17),40,100,111,53,51,56,32,112,53,52,48,32,105,53,52,49,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,23),40,115,111,114,116,33,32,115,101,113,53,49,56,32,108,101,115,115,63,53,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,22),40,115,111,114,116,32,115,101,113,53,52,54,32,108,101,115,115,63,53,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,115,53,53,51,32,112,101,53,53,52,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,30),40,98,105,110,97,114,121,45,115,101,97,114,99,104,32,118,101,99,53,52,57,32,112,114,111,99,53,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,12),40,109,97,107,101,45,113,117,101,117,101,41,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,13),40,113,117,101,117,101,63,32,120,53,54,48,41,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,101,109,112,116,121,63,32,113,53,54,49,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,102,105,114,115,116,32,113,53,54,51,41,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,17),40,113,117,101,117,101,45,108,97,115,116,32,113,53,54,55,41,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,26),40,113,117,101,117,101,45,97,100,100,33,32,113,53,55,49,32,100,97,116,117,109,53,55,50,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,20),40,113,117,101,117,101,45,114,101,109,111,118,101,33,32,113,53,55,55,41,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,62,108,105,115,116,32,113,53,56,52,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,14),40,100,111,53,56,55,32,108,115,116,53,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,21),40,108,105,115,116,45,62,113,117,101,117,101,32,108,115,116,48,53,56,54,41,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,31),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,33,32,113,53,57,53,32,105,116,101,109,53,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,10),40,100,111,54,48,49,54,48,50,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,40),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,45,108,105,115,116,33,32,113,54,48,54,32,105,116,101,109,108,105,115,116,54,48,55,41};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0};


C_noret_decl(C_data_structures_toplevel)
C_externexport void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static C_word C_fcall f_3792(C_word t0);
C_noret_decl(f_3778)
static void C_fcall f_3778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3700)
static void C_fcall f_3700(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3614)
static void C_fcall f_3614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_fcall f_3458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_fcall f_3393(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3297)
static void C_fcall f_3297(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_fcall f_3338(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3097)
static void C_fcall f_3097(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3029)
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_fcall f_2981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2853)
static void C_fcall f_2853(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2728)
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2761)
static void C_fcall f_2761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_fcall f_2800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_fcall f_2746(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_fcall f_2571(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_fcall f_2517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2528)
static C_word C_fcall f_2528(C_word t0,C_word t1);
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_fcall f_2417(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static C_word C_fcall f_2432(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2305)
static void C_fcall f_2305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2332)
static void C_fcall f_2332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_fcall f_2285(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_fcall f_2292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2201)
static void C_fcall f_2201(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_fcall f_2196(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2191)
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2186)
static void C_fcall f_2186(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2157)
static void C_fcall f_2157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2084)
static void C_fcall f_2084(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_fcall f_2079(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2074)
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2069)
static void C_fcall f_2069(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2040)
static void C_fcall f_2040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1847)
static void C_fcall f_1847(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1868)
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_fcall f_1743(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1617)
static void C_fcall f_1617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_fcall f_1612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1578)
static void C_fcall f_1578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_fcall f_1547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1500)
static void C_fcall f_1500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_fcall f_1462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1343)
static void C_fcall f_1343(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1287)
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1226)
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_ccall f_1244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1155)
static void C_fcall f_1155(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1126)
static void C_fcall f_1126(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1090)
static void C_fcall f_1090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1056)
static void C_ccall f_1056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1068)
static C_word C_fcall f_1068(C_word t0,C_word t1);
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_972)
static void C_fcall f_972(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_905)
static void C_fcall f_905(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_870)
static void C_fcall f_870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_820)
static void C_ccall f_820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_802)
static void C_ccall f_802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_750)
static void C_fcall f_750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_717)
static void C_fcall f_717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3778)
static void C_fcall trf_3778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3778(t0,t1);}

C_noret_decl(trf_3700)
static void C_fcall trf_3700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3700(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3700(t0,t1,t2);}

C_noret_decl(trf_3614)
static void C_fcall trf_3614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3614(t0,t1);}

C_noret_decl(trf_3458)
static void C_fcall trf_3458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3458(t0,t1);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3472(t0,t1,t2,t3);}

C_noret_decl(trf_3393)
static void C_fcall trf_3393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3393(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3393(t0,t1,t2,t3);}

C_noret_decl(trf_3297)
static void C_fcall trf_3297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3297(t0,t1,t2);}

C_noret_decl(trf_3338)
static void C_fcall trf_3338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3338(t0,t1);}

C_noret_decl(trf_3165)
static void C_fcall trf_3165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3165(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3165(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3097)
static void C_fcall trf_3097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3097(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3097(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3029)
static void C_fcall trf_3029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3029(t0,t1,t2,t3);}

C_noret_decl(trf_2981)
static void C_fcall trf_2981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2981(t0,t1,t2);}

C_noret_decl(trf_2853)
static void C_fcall trf_2853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2853(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2853(t0,t1,t2,t3);}

C_noret_decl(trf_2728)
static void C_fcall trf_2728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2728(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2728(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2761)
static void C_fcall trf_2761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2761(t0,t1,t2);}

C_noret_decl(trf_2800)
static void C_fcall trf_2800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2800(t0,t1);}

C_noret_decl(trf_2746)
static void C_fcall trf_2746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2746(t0,t1);}

C_noret_decl(trf_2571)
static void C_fcall trf_2571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2571(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2571(t0,t1,t2,t3);}

C_noret_decl(trf_2517)
static void C_fcall trf_2517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2517(t0,t1);}

C_noret_decl(trf_2417)
static void C_fcall trf_2417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2417(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2417(t0,t1,t2,t3);}

C_noret_decl(trf_2305)
static void C_fcall trf_2305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2305(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2305(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2332)
static void C_fcall trf_2332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2332(t0,t1,t2);}

C_noret_decl(trf_2285)
static void C_fcall trf_2285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2285(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2285(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2292)
static void C_fcall trf_2292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2292(t0,t1);}

C_noret_decl(trf_2201)
static void C_fcall trf_2201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2201(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2201(t0,t1);}

C_noret_decl(trf_2196)
static void C_fcall trf_2196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2196(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2196(t0,t1,t2);}

C_noret_decl(trf_2191)
static void C_fcall trf_2191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2191(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2191(t0,t1,t2,t3);}

C_noret_decl(trf_2186)
static void C_fcall trf_2186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2186(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2186(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2157)
static void C_fcall trf_2157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2157(t0,t1);}

C_noret_decl(trf_2084)
static void C_fcall trf_2084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2084(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2084(t0,t1);}

C_noret_decl(trf_2079)
static void C_fcall trf_2079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2079(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2079(t0,t1,t2);}

C_noret_decl(trf_2074)
static void C_fcall trf_2074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2074(t0,t1,t2,t3);}

C_noret_decl(trf_2069)
static void C_fcall trf_2069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2069(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2069(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2040)
static void C_fcall trf_2040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2040(t0,t1);}

C_noret_decl(trf_1847)
static void C_fcall trf_1847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1847(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1847(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1868)
static void C_fcall trf_1868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1868(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1868(t0,t1,t2,t3);}

C_noret_decl(trf_1718)
static void C_fcall trf_1718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1718(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1718(t0,t1,t2,t3);}

C_noret_decl(trf_1743)
static void C_fcall trf_1743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1743(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1743(t0,t1,t2,t3);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1677(t0,t1,t2);}

C_noret_decl(trf_1617)
static void C_fcall trf_1617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1617(t0,t1);}

C_noret_decl(trf_1612)
static void C_fcall trf_1612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1612(t0,t1,t2);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1543(t0,t1,t2,t3);}

C_noret_decl(trf_1578)
static void C_fcall trf_1578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1578(t0,t1,t2);}

C_noret_decl(trf_1547)
static void C_fcall trf_1547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1547(t0,t1);}

C_noret_decl(trf_1500)
static void C_fcall trf_1500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1500(t0,t1,t2);}

C_noret_decl(trf_1462)
static void C_fcall trf_1462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1462(t0,t1);}

C_noret_decl(trf_1343)
static void C_fcall trf_1343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1343(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1343(t0,t1,t2,t3);}

C_noret_decl(trf_1287)
static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1287(t0,t1,t2);}

C_noret_decl(trf_1205)
static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1205(t0,t1,t2,t3);}

C_noret_decl(trf_1226)
static void C_fcall trf_1226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1226(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1226(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1155)
static void C_fcall trf_1155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1155(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1155(t0,t1,t2,t3);}

C_noret_decl(trf_1126)
static void C_fcall trf_1126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1126(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1126(t0,t1,t2);}

C_noret_decl(trf_1090)
static void C_fcall trf_1090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1090(t0,t1,t2);}

C_noret_decl(trf_972)
static void C_fcall trf_972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_972(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_972(t0,t1,t2);}

C_noret_decl(trf_905)
static void C_fcall trf_905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_905(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_905(t0,t1,t2);}

C_noret_decl(trf_870)
static void C_fcall trf_870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_870(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_870(t0,t1,t2);}

C_noret_decl(trf_750)
static void C_fcall trf_750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_750(t0,t1,t2);}

C_noret_decl(trf_717)
static void C_fcall trf_717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_717(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("data_structures_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1030)){
C_save(t1);
C_rereclaim2(1030*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,115);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],8,"identity");
lf[4]=C_h_intern(&lf[4],7,"project");
lf[5]=C_h_intern(&lf[5],7,"conjoin");
lf[6]=C_h_intern(&lf[6],7,"disjoin");
lf[7]=C_h_intern(&lf[7],10,"constantly");
lf[8]=C_h_intern(&lf[8],4,"flip");
lf[9]=C_h_intern(&lf[9],10,"complement");
lf[10]=C_h_intern(&lf[10],7,"compose");
lf[11]=C_h_intern(&lf[11],6,"values");
lf[12]=C_h_intern(&lf[12],1,"o");
lf[13]=C_h_intern(&lf[13],8,"list-of\077");
lf[14]=C_h_intern(&lf[14],7,"list-of");
lf[15]=C_h_intern(&lf[15],4,"noop");
lf[16]=C_h_intern(&lf[16],4,"each");
lf[17]=C_h_intern(&lf[17],4,"any\077");
lf[18]=C_h_intern(&lf[18],5,"none\077");
lf[19]=C_h_intern(&lf[19],7,"always\077");
lf[20]=C_h_intern(&lf[20],6,"never\077");
lf[21]=C_h_intern(&lf[21],12,"left-section");
lf[22]=C_h_intern(&lf[22],10,"\003sysappend");
lf[23]=C_h_intern(&lf[23],17,"\003syscheck-closure");
lf[24]=C_h_intern(&lf[24],7,"reverse");
lf[25]=C_h_intern(&lf[25],13,"right-section");
lf[26]=C_h_intern(&lf[26],5,"atom\077");
lf[27]=C_h_intern(&lf[27],5,"tail\077");
lf[28]=C_h_intern(&lf[28],11,"intersperse");
lf[29]=C_h_intern(&lf[29],7,"butlast");
lf[30]=C_h_intern(&lf[30],7,"flatten");
lf[31]=C_h_intern(&lf[31],4,"chop");
lf[32]=C_h_intern(&lf[32],9,"\003syserror");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid numeric argument");
lf[34]=C_h_intern(&lf[34],4,"join");
lf[35]=C_h_intern(&lf[35],27,"\003sysnot-a-proper-list-error");
lf[36]=C_h_intern(&lf[36],8,"compress");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000%bad argument type - not a proper list");
lf[38]=C_h_intern(&lf[38],15,"\003syssignal-hook");
lf[39]=C_h_intern(&lf[39],11,"\000type-error");
lf[40]=C_h_intern(&lf[40],7,"shuffle");
lf[41]=C_h_intern(&lf[41],7,"\003sysmap");
lf[42]=C_h_intern(&lf[42],3,"cdr");
lf[43]=C_h_intern(&lf[43],5,"sort!");
lf[44]=C_h_intern(&lf[44],13,"alist-update!");
lf[45]=C_h_intern(&lf[45],4,"eqv\077");
lf[46]=C_h_intern(&lf[46],3,"eq\077");
lf[47]=C_h_intern(&lf[47],4,"assq");
lf[48]=C_h_intern(&lf[48],4,"assv");
lf[49]=C_h_intern(&lf[49],6,"equal\077");
lf[50]=C_h_intern(&lf[50],5,"assoc");
lf[51]=C_h_intern(&lf[51],9,"alist-ref");
lf[52]=C_h_intern(&lf[52],6,"rassoc");
lf[53]=C_h_intern(&lf[53],37,"\017data-structuresreverse-string-append");
lf[54]=C_h_intern(&lf[54],11,"make-string");
lf[55]=C_h_intern(&lf[55],18,"open-output-string");
lf[56]=C_h_intern(&lf[56],7,"display");
lf[57]=C_h_intern(&lf[57],6,"string");
lf[58]=C_h_intern(&lf[58],17,"get-output-string");
lf[59]=C_h_intern(&lf[59],8,"->string");
lf[60]=C_h_intern(&lf[60],14,"symbol->string");
lf[61]=C_h_intern(&lf[61],18,"\003sysnumber->string");
lf[62]=C_h_intern(&lf[62],13,"string-append");
lf[63]=C_h_intern(&lf[63],4,"conc");
lf[64]=C_h_intern(&lf[64],19,"\003syssubstring-index");
lf[65]=C_h_intern(&lf[65],15,"substring-index");
lf[66]=C_h_intern(&lf[66],22,"\003syssubstring-index-ci");
lf[67]=C_h_intern(&lf[67],18,"substring-index-ci");
lf[68]=C_h_intern(&lf[68],15,"string-compare3");
lf[69]=C_h_intern(&lf[69],18,"string-compare3-ci");
lf[70]=C_h_intern(&lf[70],15,"\003syssubstring=\077");
lf[71]=C_h_intern(&lf[71],11,"substring=\077");
lf[72]=C_h_intern(&lf[72],18,"\003syssubstring-ci=\077");
lf[73]=C_h_intern(&lf[73],14,"substring-ci=\077");
lf[74]=C_h_intern(&lf[74],12,"string-split");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\003\011\012 ");
lf[76]=C_h_intern(&lf[76],13,"\003syssubstring");
lf[77]=C_h_intern(&lf[77],18,"string-intersperse");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[79]=C_h_intern(&lf[79],19,"\003sysallocate-vector");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[81]=C_h_intern(&lf[81],12,"list->string");
lf[82]=C_h_intern(&lf[82],16,"string-translate");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid translation destination");
lf[84]=C_h_intern(&lf[84],17,"string-translate*");
lf[85]=C_h_intern(&lf[85],21,"\003sysfragments->string");
lf[86]=C_h_intern(&lf[86],11,"string-chop");
lf[87]=C_h_intern(&lf[87],12,"string-chomp");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[89]=C_h_intern(&lf[89],7,"sorted\077");
lf[90]=C_h_intern(&lf[90],5,"merge");
lf[91]=C_h_intern(&lf[91],6,"merge!");
lf[92]=C_h_intern(&lf[92],12,"vector->list");
lf[93]=C_h_intern(&lf[93],4,"sort");
lf[94]=C_h_intern(&lf[94],12,"list->vector");
lf[95]=C_h_intern(&lf[95],6,"append");
lf[96]=C_h_intern(&lf[96],13,"binary-search");
lf[97]=C_h_intern(&lf[97],10,"make-queue");
lf[98]=C_h_intern(&lf[98],5,"queue");
lf[99]=C_h_intern(&lf[99],6,"queue\077");
lf[100]=C_h_intern(&lf[100],12,"queue-empty\077");
lf[101]=C_h_intern(&lf[101],11,"queue-first");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[103]=C_h_intern(&lf[103],10,"queue-last");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[105]=C_h_intern(&lf[105],10,"queue-add!");
lf[106]=C_h_intern(&lf[106],13,"queue-remove!");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[108]=C_h_intern(&lf[108],11,"queue->list");
lf[109]=C_h_intern(&lf[109],11,"list->queue");
lf[110]=C_h_intern(&lf[110],16,"queue-push-back!");
lf[111]=C_h_intern(&lf[111],20,"g605-1217452317.0636");
lf[112]=C_h_intern(&lf[112],21,"queue-push-back-list!");
lf[113]=C_h_intern(&lf[113],17,"register-feature!");
lf[114]=C_h_intern(&lf[114],15,"data-structures");
C_register_lf2(lf,115,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=*((C_word*)lf[2]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_696,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm: 74   register-feature! */
t5=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[114]);}

/* k694 */
static void C_ccall f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word ab[213],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_696,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_709,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_802,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_810,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_822,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[12]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_858,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_897,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[14]+1,*((C_word*)lf[13]+1));
t13=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[16]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1003,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[24]+1);
t21=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1027,a[2]=t20,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1056,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1084,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1149,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t27=*((C_word*)lf[24]+1);
t28=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1190,a[2]=t27,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t29=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1275,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1414,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1665,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1715,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t36=*((C_word*)lf[55]+1);
t37=*((C_word*)lf[56]+1);
t38=*((C_word*)lf[57]+1);
t39=*((C_word*)lf[58]+1);
t40=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1792,a[2]=t36,a[3]=t37,a[4]=t39,a[5]=t38,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t41=*((C_word*)lf[62]+1);
t42=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=t41,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t43=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
t44=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t43,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp));
t45=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=t43,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1912,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1968,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1999,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2067,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2264,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2399,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t56=*((C_word*)lf[54]+1);
t57=*((C_word*)lf[81]+1);
t58=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2514,a[2]=t57,a[3]=t56,a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp));
t59=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2716,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2838,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2954,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3294,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3427,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t67=*((C_word*)lf[94]+1);
t68=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3454,a[2]=t67,a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp));
t69=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3543,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3562,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3681,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3735,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t79=C_set_block_item(lf[111],0,C_SCHEME_END_OF_LIST);
t80=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3765,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t81=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t81+1)))(2,t81,C_SCHEME_UNDEFINED);}

/* queue-push-back-list! in k694 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3765,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[98],lf[112]);
t5=(C_word)C_i_check_list_2(t3,lf[112]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3775,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* data-structures.scm: 909  append */
t8=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t3,t7);}

/* k3773 in queue-push-back-list! in k694 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_3778(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3792,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
t5=t2;
f_3778(t5,f_3792(t1));}}

/* do601602 in k3773 in queue-push-back-list! in k694 */
static C_word C_fcall f_3792(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(t2,*((C_word*)lf[111]+1));
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* k3776 in k3773 in queue-push-back-list! in k694 */
static void C_fcall f_3778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1));}

/* queue-push-back! in k694 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3735,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[98],lf[110]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_i_setslot(t2,C_fix(1),t6);
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?(C_word)C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED));}

/* list->queue in k694 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3681,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[109]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3692,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_3692(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=t2,a[3]=t7,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3700(t9,t4,t2);}}

/* do587 in list->queue in k694 */
static void C_fcall f_3700(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3700,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3710,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* data-structures.scm: 885  ##sys#not-a-proper-list-error */
t8=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[109]);}
else{
t8=t5;
f_3710(2,t8,C_SCHEME_UNDEFINED);}}}

/* k3708 in do587 in list->queue in k694 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3700(t3,((C_word*)t0)[2],t2);}

/* k3690 in list->queue in k694 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[98],((C_word*)t0)[2],t1));}

/* queue->list in k694 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3672,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[108]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k694 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3636,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[106]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3646,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 863  ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[106],lf[107],t2);}
else{
t7=t5;
f_3646(2,t7,C_SCHEME_UNDEFINED);}}

/* k3644 in queue-remove! in k694 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(((C_word*)t0)[4],C_fix(0)));}

/* queue-add! in k694 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3604,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[98],lf[105]);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3614,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t7);
if(C_truep(t8)){
t9=t6;
f_3614(t9,(C_word)C_i_setslot(t2,C_fix(1),t5));}
else{
t9=(C_word)C_slot(t2,C_fix(2));
t10=t6;
f_3614(t10,(C_word)C_i_setslot(t9,C_fix(1),t5));}}

/* k3612 in queue-add! in k694 */
static void C_fcall f_3614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k694 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3583,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[103]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3593,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 844  ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[103],lf[104],t2);}
else{
t7=t5;
f_3593(2,t7,C_SCHEME_UNDEFINED);}}

/* k3591 in queue-last in k694 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-first in k694 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3562,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[101]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3572,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 833  ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[101],lf[102],t2);}
else{
t7=t5;
f_3572(2,t7,C_SCHEME_UNDEFINED);}}

/* k3570 in queue-first in k694 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-empty? in k694 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3549,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[98],lf[100]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* queue? in k694 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3543,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[98]));}

/* make-queue in k694 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[98],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* binary-search in k694 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3454,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3458,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3532,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 790  list->vector */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_3458(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[96]));}}

/* k3530 in binary-search in k694 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3458(t3,t2);}

/* k3456 in binary-search in k694 */
static void C_fcall f_3458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3458,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li126),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3472(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k3456 in binary-search in k694 */
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_divide(t4,C_fix(2));
t6=(C_word)C_fixnum_plus(t2,t5);
t7=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3482,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 798  proc */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t7);}

/* k3480 in loop in k3456 in binary-search in k694 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 800  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3472(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 801  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3472(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k694 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3427,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3445,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 780  vector->list */
t6=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3452,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 781  append */
t5=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k3450 in sort in k694 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 781  sort! */
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3443 in sort in k694 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 780  sort! */
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3439 in sort in k694 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 780  list->vector */
t2=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k694 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3294,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3297,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=((C_word)li122),tmp=(C_word)a,a+=6,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_i_vector_length(((C_word*)t4)[1]);
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3384,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 763  vector->list */
t11=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* data-structures.scm: 769  step */
t9=((C_word*)t6)[1];
f_3297(t9,t1,t8);}}

/* k3382 in sort! in k694 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 764  step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3297(t4,t3,((C_word*)t0)[2]);}

/* k3389 in k3382 in sort! in k694 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3393,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3393(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* do538 in k3389 in k3382 in sort! in k694 */
static void C_fcall f_3393(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3393,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_vector_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k694 */
static void C_fcall f_3297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3297,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3338,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3348,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 748  less? */
t10=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k3346 in step in sort! in k694 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_car(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
f_3338(t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_3338(t2,C_SCHEME_UNDEFINED);}}

/* k3336 in step in sort! in k694 */
static void C_fcall f_3338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k3305 in step in sort! in k694 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 739  step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3297(t3,t2,t1);}

/* k3308 in k3305 in step in sort! in k694 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 741  step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3297(t4,t3,t2);}

/* k3314 in k3308 in k3305 in step in sort! in k694 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 742  merge! */
t2=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k694 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3162,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3165,a[2]=t4,a[3]=t6,a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3244,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* data-structures.scm: 716  less? */
t11=t4;
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}}}

/* k3242 in merge! in k694 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_3247(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* data-structures.scm: 719  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3165(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_3267(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[4]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 724  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3165(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k3265 in k3242 in merge! in k694 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3245 in k3242 in merge! in k694 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k694 */
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3165,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_car(t3);
/* data-structures.scm: 701  less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k3170 in loop in merge! in k694 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[5],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* data-structures.scm: 706  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3165(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[5]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 712  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3165(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k694 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3063,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3097,a[2]=t4,a[3]=t10,a[4]=((C_word)li118),tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3097(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k694 */
static void C_fcall f_3097(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3097,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 684  less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t4,t2);}

/* k3102 in loop in merge in k694 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* data-structures.scm: 687  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3097(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* data-structures.scm: 691  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3097(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k3150 in k3102 in loop in merge in k694 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3152,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3122 in k3102 in loop in merge in k694 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k694 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2954,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2981,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=((C_word)li115),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2981(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3029,a[2]=t3,a[3]=t7,a[4]=((C_word)li116),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3029(t9,t1,t4,t5);}}}

/* loop in sorted? in k694 */
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3029,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t3);
/* data-structures.scm: 667  less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}}

/* k3055 in loop in sorted? in k694 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* data-structures.scm: 668  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3029(t4,((C_word*)t0)[4],t2,t3);}}

/* do485 in sorted? in k694 */
static void C_fcall f_2981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2981,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_2991(2,t5,t3);}
else{
t5=(C_word)C_i_vector_ref(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[3],t6);
/* data-structures.scm: 661  less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t4,t5,t7);}}

/* k2989 in do485 in sorted? in k694 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_2981(t3,((C_word*)t0)[5],t2);}}

/* string-chomp in k694 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2902r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2902r(t0,t1,t2,t3);}}

static void C_ccall f_2902r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2906,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2906(2,t5,lf[88]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2906(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2904 in string-chomp in k694 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[87]);
t3=(C_word)C_i_check_string_2(t1,lf[87]);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
t5=(C_word)C_block_size(t1);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_fixnum_greater_or_equal_p(t4,t5);
t8=(C_truep(t7)?(C_word)C_substring_compare(((C_word*)t0)[3],t1,t6,C_fix(0),t5):C_SCHEME_FALSE);
if(C_truep(t8)){
/* data-structures.scm: 628  ##sys#substring */
t9=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t6);}
else{
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}}

/* string-chop in k694 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2838,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[86]);
t5=(C_word)C_i_check_exact_2(t3,lf[86]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2853,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=((C_word)li112),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2853(t10,t1,t6,C_fix(0));}

/* loop in string-chop in k694 */
static void C_fcall f_2853(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2853,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(t3,t2);
/* data-structures.scm: 614  ##sys#substring */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
/* data-structures.scm: 615  ##sys#substring */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k2882 in loop in string-chop in k694 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2888,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* data-structures.scm: 615  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2853(t5,t2,t3,t4);}

/* k2886 in k2882 in loop in string-chop in k694 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2871 in loop in string-chop in k694 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2873,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k694 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2716,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[84]);
t5=(C_word)C_i_check_list_2(t3,lf[84]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2728,a[2]=t3,a[3]=t8,a[4]=t2,a[5]=t6,a[6]=((C_word)li110),tmp=(C_word)a,a+=7,tmp));
/* data-structures.scm: 603  collect */
t10=((C_word*)t8)[1];
f_2728(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k694 */
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2728,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2742,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2756,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 585  ##sys#substring */
t10=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_2746(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2761,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,a[9]=((C_word)li109),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_2761(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k694 */
static void C_fcall f_2761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2761,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 589  collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2728(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2800,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2826,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 597  ##sys#substring */
t10=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_2800(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_i_cdr(t2);
/* data-structures.scm: 602  loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k2824 in loop in collect in string-translate* in k694 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_2800(t4,t3);}

/* k2798 in loop in collect in string-translate* in k694 */
static void C_fcall f_2800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2800,NULL,2,t0,t1);}
t2=(C_word)C_i_string_length(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* data-structures.scm: 598  collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2728(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k2754 in collect in string-translate* in k694 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2746(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k2744 in collect in string-translate* in k694 */
static void C_fcall f_2746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 583  reverse */
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2740 in collect in string-translate* in k694 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 581  ##sys#fragments->string */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k694 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_2514r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2514r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2514r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_2551(2,t7,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2691,a[2]=t3,a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2708,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 539  list->string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_check_string_2(t3,lf[82]);
/* data-structures.scm: 542  instring */
f_2517(t6,t3);}}}

/* k2706 in string-translate in k694 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 539  instring */
f_2517(((C_word*)t0)[2],t1);}

/* f_2691 in string-translate in k694 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2691,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k2549 in string-translate in k694 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_2554(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* data-structures.scm: 547  list->string */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t4=(C_word)C_i_check_string_2(t3,lf[82]);
t5=t2;
f_2554(2,t5,t3);}}}
else{
t3=t2;
f_2554(2,t3,C_SCHEME_FALSE);}}

/* k2552 in k2549 in string-translate in k694 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[82]);
t5=(C_word)C_block_size(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 554  make-string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k2564 in k2552 in k2549 in string-translate in k694 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word)li106),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2571(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k2564 in k2552 in k2549 in string-translate in k694 */
static void C_fcall f_2571(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2571,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* data-structures.scm: 558  ##sys#substring */
t4=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[7],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[6],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2590,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* data-structures.scm: 561  from */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}

/* k2588 in loop in k2564 in k2552 in k2549 in string-translate in k694 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[9];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 568  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2571(t7,((C_word*)t0)[4],t5,t6);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
/* data-structures.scm: 570  ##sys#error */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[82],lf[83],((C_word*)t0)[6],((C_word*)t0)[9]);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],(C_word)C_subchar(((C_word*)t0)[9],t1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 573  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2571(t7,((C_word*)t0)[4],t5,t6);}}}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* data-structures.scm: 565  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2571(t5,((C_word*)t0)[4],t4,((C_word*)t0)[7]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 564  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_2571(t6,((C_word*)t0)[4],t4,t5);}}

/* instring in string-translate in k694 */
static void C_fcall f_2517(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2517,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2522,a[2]=t2,a[3]=t3,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp));}

/* f_2522 in instring in string-translate in k694 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2522,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2528(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_2528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k694 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2399r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2399r(t0,t1,t2,t3);}}

static void C_ccall f_2399r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2403(2,t5,lf[80]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2403(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2401 in string-intersperse in k694 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=(C_word)C_i_check_list_2(((C_word*)t0)[3],lf[77]);
t3=(C_word)C_i_check_string_2(t1,lf[77]);
t4=(C_word)C_block_size(t1);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2417,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2417(t8,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* loop1 in k2401 in string-intersperse in k694 */
static void C_fcall f_2417(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2417,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[78]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_fixnum_difference(t3,((C_word*)t0)[3]);
/* data-structures.scm: 502  ##sys#allocate-vector */
t6=*((C_word*)lf[79]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_i_check_string_2(t5,lf[77]);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t5);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],t3);
t10=(C_word)C_fixnum_plus(t8,t9);
/* data-structures.scm: 517  loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* data-structures.scm: 519  ##sys#not-a-proper-list-error */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k2425 in loop1 in k2401 in string-intersperse in k694 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2432,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2432(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k2425 in loop1 in k2401 in string-intersperse in k694 */
static C_word C_fcall f_2432(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
C_stack_check;
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k694 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2264r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2264r(t0,t1,t2,t3);}}

static void C_ccall f_2264r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(20);
t4=(C_word)C_i_check_string_2(t2,lf[74]);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?lf[75]:(C_word)C_i_vector_ref(t3,C_fix(0)));
t7=(C_word)C_block_size(t3);
t8=(C_word)C_eqp(t7,C_fix(2));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_string_2(t6,lf[74]);
t12=(C_word)C_block_size(t6);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2285,a[2]=t2,a[3]=t14,a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2305,a[2]=t6,a[3]=t17,a[4]=t12,a[5]=t2,a[6]=t15,a[7]=t9,a[8]=t14,a[9]=t10,a[10]=((C_word)li98),tmp=(C_word)a,a+=11,tmp));
t19=((C_word*)t17)[1];
f_2305(t19,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k694 */
static void C_fcall f_2305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2305,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2315,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* data-structures.scm: 478  add */
t8=((C_word*)t0)[6];
f_2285(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_2315(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2332,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],a[12]=((C_word)li97),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_2332(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k694 */
static void C_fcall f_2332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2332,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* data-structures.scm: 483  loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_2305(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2371,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 487  add */
t8=((C_word*)t0)[3];
f_2285(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* data-structures.scm: 488  loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_2305(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* data-structures.scm: 489  scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k2369 in scan in loop in string-split in k694 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 487  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2305(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k2313 in loop in string-split in k694 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k694 */
static void C_fcall f_2285(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2285,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2300,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 471  ##sys#substring */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k2298 in add in string-split in k694 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2292(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_2292(t5,t4);}}

/* k2290 in k2298 in add in string-split in k694 */
static void C_fcall f_2292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k694 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_2184r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2184r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2184r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2186,a[2]=t3,a[3]=t2,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2191,a[2]=t5,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=t6,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2201,a[2]=t7,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1331344 */
t9=t8;
f_2201(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2332342 */
t11=t7;
f_2196(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len333339 */
t13=t6;
f_2191(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body329335 */
t15=t5;
f_2186(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1331 in substring-ci=? in k694 */
static void C_fcall f_2201(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2201,NULL,2,t0,t1);}
/* def-start2332342 */
t2=((C_word*)t0)[2];
f_2196(t2,t1,C_fix(0));}

/* def-start2332 in substring-ci=? in k694 */
static void C_fcall f_2196(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2196,NULL,3,t0,t1,t2);}
/* def-len333339 */
t3=((C_word*)t0)[2];
f_2191(t3,t1,t2,C_fix(0));}

/* def-len333 in substring-ci=? in k694 */
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2191,NULL,4,t0,t1,t2,t3);}
/* body329335 */
t4=((C_word*)t0)[2];
f_2186(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body329 in substring-ci=? in k694 */
static void C_fcall f_2186(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2186,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 456  ##sys#substring-ci=? */
t5=*((C_word*)lf[72]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring-ci=? in k694 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2147,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[73]);
t8=(C_word)C_i_check_string_2(t3,lf[73]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2157,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2157(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_2157(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k2155 in ##sys#substring-ci=? in k694 */
static void C_fcall f_2157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[73]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[73]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* substring=? in k694 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_2067r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2067r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2067r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=t3,a[3]=t2,a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2074,a[2]=t5,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2079,a[2]=t6,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2084,a[2]=t7,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1290303 */
t9=t8;
f_2084(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2291301 */
t11=t7;
f_2079(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len292298 */
t13=t6;
f_2074(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body288294 */
t15=t5;
f_2069(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1290 in substring=? in k694 */
static void C_fcall f_2084(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2084,NULL,2,t0,t1);}
/* def-start2291301 */
t2=((C_word*)t0)[2];
f_2079(t2,t1,C_fix(0));}

/* def-start2291 in substring=? in k694 */
static void C_fcall f_2079(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2079,NULL,3,t0,t1,t2);}
/* def-len292298 */
t3=((C_word*)t0)[2];
f_2074(t3,t1,t2,C_fix(0));}

/* def-len292 in substring=? in k694 */
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2074,NULL,4,t0,t1,t2,t3);}
/* body288294 */
t4=((C_word*)t0)[2];
f_2069(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body288 in substring=? in k694 */
static void C_fcall f_2069(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2069,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 442  ##sys#substring=? */
t5=*((C_word*)lf[70]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring=? in k694 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2030,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[71]);
t8=(C_word)C_i_check_string_2(t3,lf[71]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2040,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2040(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_2040(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k2038 in ##sys#substring=? in k694 */
static void C_fcall f_2040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[71]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[71]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* string-compare3-ci in k694 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1999,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[69]);
t5=(C_word)C_i_check_string_2(t3,lf[69]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_string_compare_case_insensitive(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* string-compare3 in k694 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1968,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[68]);
t5=(C_word)C_i_check_string_2(t3,lf[68]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_mem_compare(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* substring-index-ci in k694 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1940r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1940r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1944,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1944(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1944(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1942 in substring-index-ci in k694 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 401  ##sys#substring-index-ci */
t2=*((C_word*)lf[66]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* substring-index in k694 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1912r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1912r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1912r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1916(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1916(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1914 in substring-index in k694 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 398  ##sys#substring-index */
t2=*((C_word*)lf[64]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#substring-index-ci in k694 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1903,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=t3,a[3]=t2,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 392  traverse */
f_1847(t1,t2,t3,t4,t5,lf[67]);}

/* a1908 in ##sys#substring-index-ci in k694 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1909,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* ##sys#substring-index in k694 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1894,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1900,a[2]=t3,a[3]=t2,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 386  traverse */
f_1847(t1,t2,t3,t4,t5,lf[65]);}

/* a1899 in ##sys#substring-index in k694 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1900,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k694 */
static void C_fcall f_1847(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1847,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,t6);
t8=(C_word)C_i_check_string_2(t3,t6);
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_exact_2(t4,t6);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1868,a[2]=t10,a[3]=t5,a[4]=t13,a[5]=t9,a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_1868(t15,t1,t4,t10);}

/* loop in traverse in k694 */
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1868,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 380  test */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k1879 in loop in traverse in k694 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 382  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1868(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k694 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1837r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1837r(t0,t1,t2);}}

static void C_ccall f_1837r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[59]+1),t2);}

/* k1843 in conc in k694 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k694 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1792,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* data-structures.scm: 355  symbol->string */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
/* data-structures.scm: 356  string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* data-structures.scm: 357  ##sys#number->string */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1829,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 359  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}}}}

/* k1827 in ->string in k694 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1832,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 360  display */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k1830 in k1827 in ->string in k694 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 361  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##data-structures#reverse-string-append in k694 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1715,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=t4,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
/* data-structures.scm: 344  rev-string-append */
t6=((C_word*)t4)[1];
f_1718(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##data-structures#reverse-string-append in k694 */
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1718,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1734,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* data-structures.scm: 335  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* data-structures.scm: 342  make-string */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k1732 in rev-string-append in ##data-structures#reverse-string-append in k694 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1743,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1743(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k1732 in rev-string-append in ##data-structures#reverse-string-append in k694 */
static void C_fcall f_1743(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1743,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* data-structures.scm: 340  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* rassoc in k694 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1665r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1665r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1665r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_list_2(t3,lf[52]);
t6=(C_word)C_notvemptyp(t4);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t4,C_fix(0)):*((C_word*)lf[45]+1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1677,a[2]=t2,a[3]=t7,a[4]=t9,a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1677(t11,t1,t3);}

/* loop in rassoc in k694 */
static void C_fcall f_1677(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[52]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 321  tst */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1694 in loop in rassoc in k694 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 323  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1677(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k694 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1541r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1541r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1541r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1543,a[2]=t3,a[3]=t2,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1612,a[2]=t5,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1617,a[2]=t6,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp158174 */
t8=t7;
f_1617(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default159172 */
t10=t6;
f_1612(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body156161 */
t12=t5;
f_1543(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-cmp158 in alist-ref in k694 */
static void C_fcall f_1617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1617,NULL,2,t0,t1);}
/* def-default159172 */
t2=((C_word*)t0)[2];
f_1612(t2,t1,*((C_word*)lf[45]+1));}

/* def-default159 in alist-ref in k694 */
static void C_fcall f_1612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1612,NULL,3,t0,t1,t2);}
/* body156161 */
t3=((C_word*)t0)[2];
f_1543(t3,t1,t2,C_SCHEME_FALSE);}

/* body156 in alist-ref in k694 */
static void C_fcall f_1543(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[46]+1),t2);
if(C_truep(t5)){
t6=t4;
f_1547(t6,*((C_word*)lf[47]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[45]+1),t2);
if(C_truep(t6)){
t7=t4;
f_1547(t7,*((C_word*)lf[48]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[49]+1),t2);
t8=t4;
f_1547(t8,(C_truep(t7)?*((C_word*)lf[50]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1572,a[2]=t2,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp)));}}}

/* f_1572 in body156 in alist-ref in k694 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1572,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1578,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1578(t7,t1,t3);}

/* loop */
static void C_fcall f_1578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1578,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 306  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_1594(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1592 in loop */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 308  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1578(t3,((C_word*)t0)[5],t2);}}

/* k1545 in body156 in alist-ref in k694 */
static void C_fcall f_1547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1547,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 309  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1548 in k1545 in body156 in alist-ref in k694 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k694 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5rv,(void*)f_1455r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_1455r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1455r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t5,C_fix(0)):*((C_word*)lf[45]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1462,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[46]+1),t7);
if(C_truep(t9)){
t10=t8;
f_1462(t10,*((C_word*)lf[47]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[45]+1),t7);
if(C_truep(t10)){
t11=t8;
f_1462(t11,*((C_word*)lf[48]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[49]+1),t7);
t12=t8;
f_1462(t12,(C_truep(t11)?*((C_word*)lf[50]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1494,a[2]=t7,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp)));}}}

/* f_1494 in alist-update! in k694 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1494,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1500,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1500(t7,t1,t3);}

/* loop */
static void C_fcall f_1500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1500,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 287  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_1516(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1514 in loop */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 289  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1500(t3,((C_word*)t0)[5],t2);}}

/* k1460 in alist-update! in k694 */
static void C_fcall f_1462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1462,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 290  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1463 in k1460 in alist-update! in k694 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k694 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1414,4,t0,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1425,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1445,a[2]=t4,a[3]=t3,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
/* map */
t8=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}

/* a1444 in shuffle in k694 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1445,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 271  random */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1451 in a1444 in shuffle in k694 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1427 in shuffle in k694 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1431,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm: 271  sort! */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a1430 in k1427 in shuffle in k694 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1431,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k1423 in shuffle in k694 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[42]+1),t1);}

/* compress in k694 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1334,4,t0,t1,t2,t3);}
t4=lf[37];
t5=(C_word)C_i_check_list_2(t3,lf[36]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1343,a[2]=t4,a[3]=t7,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1343(t9,t1,t2,t3);}

/* loop in compress in k694 */
static void C_fcall f_1343(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1343,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1385,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 263  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 264  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
/* data-structures.scm: 262  ##sys#signal-hook */
t4=*((C_word*)lf[38]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[39],lf[36],((C_word*)t0)[2],t3);}}
else{
/* data-structures.scm: 260  ##sys#signal-hook */
t4=*((C_word*)lf[38]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[39],lf[36],((C_word*)t0)[2],t2);}}}

/* k1383 in loop in compress in k694 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k694 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1275r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1275r(t0,t1,t2,t3);}}

static void C_ccall f_1275r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[34]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1287,a[2]=t8,a[3]=t5,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1287(t10,t1,t2);}

/* loop in join in k694 */
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1287,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 251  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}
else{
/* data-structures.scm: 245  ##sys#not-a-proper-list-error */
t3=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}}

/* k1320 in loop in join in k694 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 251  ##sys#append */
t2=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k694 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1190,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[31]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1197,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* data-structures.scm: 226  ##sys#error */
t6=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[31],lf[33],t3);}
else{
t6=t5;
f_1197(2,t6,C_SCHEME_UNDEFINED);}}

/* k1195 in chop in k694 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1197,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1205(t6,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* loop in k1195 in chop in k694 */
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1205,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1226,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word)li48),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1226(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* do104 in loop in k1195 in chop in k694 */
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1226,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1240,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 237  reverse */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k1238 in do104 in loop in k1195 in chop in k694 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1244,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* data-structures.scm: 237  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1205(t4,t2,((C_word*)t0)[2],t3);}

/* k1242 in k1238 in do104 in loop in k1195 in chop in k694 */
static void C_ccall f_1244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1244,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k694 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1149r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1149r(t0,t1,t2);}}

static void C_ccall f_1149r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1155,a[2]=t4,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1155(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k694 */
static void C_fcall f_1155(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1155,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1181,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 218  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1188,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 219  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k1186 in loop in flatten in k694 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1188,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1179 in loop in flatten in k694 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 218  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1155(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k694 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1117,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[29]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1126,a[2]=t5,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1126(t7,t1,t2);}

/* loop in butlast in k694 */
static void C_fcall f_1126(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1126,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1147,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 208  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k1145 in loop in butlast in k694 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k694 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1084,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1090,a[2]=t5,a[3]=t3,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1090(t7,t1,t2);}

/* loop in intersperse in k694 */
static void C_fcall f_1090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1090,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1115,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 201  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k1113 in loop in intersperse in k694 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k694 */
static void C_ccall f_1056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1056,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[27]);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=t2,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_1068(t6,t3));}}

/* loop in tail? in k694 */
static C_word C_fcall f_1068(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k694 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1053,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* right-section in k694 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1027r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1027r(t0,t1,t2,t3);}}

static void C_ccall f_1027r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1031,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 175  ##sys#check-closure */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[25]);}

/* k1029 in right-section in k694 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 176  ##sys#reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1032 in k1029 in right-section in k694 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1035,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li37),tmp=(C_word)a,a+=6,tmp));}

/* f_1035 in k1032 in k1029 in right-section in k694 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_1035r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1035r(t0,t1,t2);}}

static void C_ccall f_1035r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1047,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 178  ##sys#reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1049 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 178  ##sys#append */
t2=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1045 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 178  ##sys#reverse */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1041 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* left-section in k694 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1012r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1012r(t0,t1,t2,t3);}}

static void C_ccall f_1012r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1016,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 168  ##sys#check-closure */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[21]);}

/* k1014 in left-section in k694 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));}

/* f_1017 in k1014 in left-section in k694 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1017r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1017r(t0,t1,t2);}}

static void C_ccall f_1017r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 170  ##sys#append */
t4=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k1023 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* never? in k694 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* always? in k694 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* none? in k694 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1003,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* any? in k694 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1000,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* each in k694 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_944r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_944r(t0,t1,t2);}}

static void C_ccall f_944r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_952,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_966,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp)));}}

/* f_966 in each in k694 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_966r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_966r(t0,t1,t2);}}

static void C_ccall f_966r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_972,a[2]=t4,a[3]=t2,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_972(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_972(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_972,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
C_apply(4,0,t1,t3,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_991,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,t3,((C_word*)t0)[3]);}}

/* k989 in loop */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 157  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_972(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_952 in each in k694 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_952,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* noop in k694 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* list-of? in k694 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_897,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_899,a[2]=t2,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));}

/* f_899 in list-of? in k694 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_899,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_905,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_905(t6,t1,t2);}

/* loop */
static void C_fcall f_905(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_905,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_924,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* data-structures.scm: 138  pred */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k922 in loop */
static void C_ccall f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 138  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_905(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* o in k694 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_858r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_858r(t0,t1,t2);}}

static void C_ccall f_858r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[3]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_870,a[2]=t4,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_870(t6,t1,t2);}}

/* loop in o in k694 */
static void C_fcall f_870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_870,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_884,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp)));}

/* f_884 in loop in o in k694 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_884,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_892,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_895,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 131  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_870(t5,t4,((C_word*)t0)[2]);}

/* k893 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k890 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 131  h */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* compose in k694 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_822r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_822r(t0,t1,t2);}}

static void C_ccall f_822r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_825,a[2]=t4,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[11]+1));}
else{
C_apply(4,0,t1,((C_word*)t4)[1],t2);}}

/* rec in compose in k694 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_825r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_825r(t0,t1,t2,t3);}}

static void C_ccall f_825r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_833,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp)));}

/* f_833 in rec in compose in k694 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_833r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_833r(t0,t1,t2);}}

static void C_ccall f_833r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 116  call-with-values */
C_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a838 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_847,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k845 in a838 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k694 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_810,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_812,a[2]=t2,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));}

/* f_812 in complement in k694 */
static void C_ccall f_812(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_812r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_812r(t0,t1,t2);}}

static void C_ccall f_812r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_820,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k818 */
static void C_ccall f_820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k694 */
static void C_ccall f_802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_802,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_804,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));}

/* f_804 in flip in k694 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_804,4,t0,t1,t2,t3);}
/* data-structures.scm: 105  proc */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* constantly in k694 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_779r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_779r(t0,t1,t2);}}

static void C_ccall f_779r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_790,a[2]=t5,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_792,a[2]=t2,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));}}

/* f_792 in constantly in k694 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_792,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_790 in constantly in k694 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_790,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k694 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_742r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_742r(t0,t1,t2);}}

static void C_ccall f_742r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_744,a[2]=t2,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp));}

/* f_744 in disjoin in k694 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_744,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_750,a[2]=t2,a[3]=t4,a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_750(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_750,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_760,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[2]);}}

/* k758 in loop */
static void C_ccall f_760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 97   loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_750(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k694 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_709r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_709r(t0,t1,t2);}}

static void C_ccall f_709r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_711,a[2]=t2,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));}

/* f_711 in conjoin in k694 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_711,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_717,a[2]=t2,a[3]=t4,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_717(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_717,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_730,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[2]);}}

/* k728 in loop */
static void C_ccall f_730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 90   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_717(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k694 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_701,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_703,a[2]=t2,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));}

/* f_703 in project in k694 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_703r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_703r(t0,t1,t2);}}

static void C_ccall f_703r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,((C_word*)t0)[2]));}

/* identity in k694 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_698,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[237] = {
{"topleveldata-structures.scm",(void*)C_data_structures_toplevel},
{"f_696data-structures.scm",(void*)f_696},
{"f_3765data-structures.scm",(void*)f_3765},
{"f_3775data-structures.scm",(void*)f_3775},
{"f_3792data-structures.scm",(void*)f_3792},
{"f_3778data-structures.scm",(void*)f_3778},
{"f_3735data-structures.scm",(void*)f_3735},
{"f_3681data-structures.scm",(void*)f_3681},
{"f_3700data-structures.scm",(void*)f_3700},
{"f_3710data-structures.scm",(void*)f_3710},
{"f_3692data-structures.scm",(void*)f_3692},
{"f_3672data-structures.scm",(void*)f_3672},
{"f_3636data-structures.scm",(void*)f_3636},
{"f_3646data-structures.scm",(void*)f_3646},
{"f_3604data-structures.scm",(void*)f_3604},
{"f_3614data-structures.scm",(void*)f_3614},
{"f_3583data-structures.scm",(void*)f_3583},
{"f_3593data-structures.scm",(void*)f_3593},
{"f_3562data-structures.scm",(void*)f_3562},
{"f_3572data-structures.scm",(void*)f_3572},
{"f_3549data-structures.scm",(void*)f_3549},
{"f_3543data-structures.scm",(void*)f_3543},
{"f_3537data-structures.scm",(void*)f_3537},
{"f_3454data-structures.scm",(void*)f_3454},
{"f_3532data-structures.scm",(void*)f_3532},
{"f_3458data-structures.scm",(void*)f_3458},
{"f_3472data-structures.scm",(void*)f_3472},
{"f_3482data-structures.scm",(void*)f_3482},
{"f_3427data-structures.scm",(void*)f_3427},
{"f_3452data-structures.scm",(void*)f_3452},
{"f_3445data-structures.scm",(void*)f_3445},
{"f_3441data-structures.scm",(void*)f_3441},
{"f_3294data-structures.scm",(void*)f_3294},
{"f_3384data-structures.scm",(void*)f_3384},
{"f_3391data-structures.scm",(void*)f_3391},
{"f_3393data-structures.scm",(void*)f_3393},
{"f_3297data-structures.scm",(void*)f_3297},
{"f_3348data-structures.scm",(void*)f_3348},
{"f_3338data-structures.scm",(void*)f_3338},
{"f_3307data-structures.scm",(void*)f_3307},
{"f_3310data-structures.scm",(void*)f_3310},
{"f_3316data-structures.scm",(void*)f_3316},
{"f_3162data-structures.scm",(void*)f_3162},
{"f_3244data-structures.scm",(void*)f_3244},
{"f_3267data-structures.scm",(void*)f_3267},
{"f_3247data-structures.scm",(void*)f_3247},
{"f_3165data-structures.scm",(void*)f_3165},
{"f_3172data-structures.scm",(void*)f_3172},
{"f_3063data-structures.scm",(void*)f_3063},
{"f_3097data-structures.scm",(void*)f_3097},
{"f_3104data-structures.scm",(void*)f_3104},
{"f_3152data-structures.scm",(void*)f_3152},
{"f_3124data-structures.scm",(void*)f_3124},
{"f_2954data-structures.scm",(void*)f_2954},
{"f_3029data-structures.scm",(void*)f_3029},
{"f_3057data-structures.scm",(void*)f_3057},
{"f_2981data-structures.scm",(void*)f_2981},
{"f_2991data-structures.scm",(void*)f_2991},
{"f_2902data-structures.scm",(void*)f_2902},
{"f_2906data-structures.scm",(void*)f_2906},
{"f_2838data-structures.scm",(void*)f_2838},
{"f_2853data-structures.scm",(void*)f_2853},
{"f_2884data-structures.scm",(void*)f_2884},
{"f_2888data-structures.scm",(void*)f_2888},
{"f_2873data-structures.scm",(void*)f_2873},
{"f_2716data-structures.scm",(void*)f_2716},
{"f_2728data-structures.scm",(void*)f_2728},
{"f_2761data-structures.scm",(void*)f_2761},
{"f_2826data-structures.scm",(void*)f_2826},
{"f_2800data-structures.scm",(void*)f_2800},
{"f_2756data-structures.scm",(void*)f_2756},
{"f_2746data-structures.scm",(void*)f_2746},
{"f_2742data-structures.scm",(void*)f_2742},
{"f_2514data-structures.scm",(void*)f_2514},
{"f_2708data-structures.scm",(void*)f_2708},
{"f_2691data-structures.scm",(void*)f_2691},
{"f_2551data-structures.scm",(void*)f_2551},
{"f_2554data-structures.scm",(void*)f_2554},
{"f_2566data-structures.scm",(void*)f_2566},
{"f_2571data-structures.scm",(void*)f_2571},
{"f_2590data-structures.scm",(void*)f_2590},
{"f_2517data-structures.scm",(void*)f_2517},
{"f_2522data-structures.scm",(void*)f_2522},
{"f_2528data-structures.scm",(void*)f_2528},
{"f_2399data-structures.scm",(void*)f_2399},
{"f_2403data-structures.scm",(void*)f_2403},
{"f_2417data-structures.scm",(void*)f_2417},
{"f_2427data-structures.scm",(void*)f_2427},
{"f_2432data-structures.scm",(void*)f_2432},
{"f_2264data-structures.scm",(void*)f_2264},
{"f_2305data-structures.scm",(void*)f_2305},
{"f_2332data-structures.scm",(void*)f_2332},
{"f_2371data-structures.scm",(void*)f_2371},
{"f_2315data-structures.scm",(void*)f_2315},
{"f_2285data-structures.scm",(void*)f_2285},
{"f_2300data-structures.scm",(void*)f_2300},
{"f_2292data-structures.scm",(void*)f_2292},
{"f_2184data-structures.scm",(void*)f_2184},
{"f_2201data-structures.scm",(void*)f_2201},
{"f_2196data-structures.scm",(void*)f_2196},
{"f_2191data-structures.scm",(void*)f_2191},
{"f_2186data-structures.scm",(void*)f_2186},
{"f_2147data-structures.scm",(void*)f_2147},
{"f_2157data-structures.scm",(void*)f_2157},
{"f_2067data-structures.scm",(void*)f_2067},
{"f_2084data-structures.scm",(void*)f_2084},
{"f_2079data-structures.scm",(void*)f_2079},
{"f_2074data-structures.scm",(void*)f_2074},
{"f_2069data-structures.scm",(void*)f_2069},
{"f_2030data-structures.scm",(void*)f_2030},
{"f_2040data-structures.scm",(void*)f_2040},
{"f_1999data-structures.scm",(void*)f_1999},
{"f_1968data-structures.scm",(void*)f_1968},
{"f_1940data-structures.scm",(void*)f_1940},
{"f_1944data-structures.scm",(void*)f_1944},
{"f_1912data-structures.scm",(void*)f_1912},
{"f_1916data-structures.scm",(void*)f_1916},
{"f_1903data-structures.scm",(void*)f_1903},
{"f_1909data-structures.scm",(void*)f_1909},
{"f_1894data-structures.scm",(void*)f_1894},
{"f_1900data-structures.scm",(void*)f_1900},
{"f_1847data-structures.scm",(void*)f_1847},
{"f_1868data-structures.scm",(void*)f_1868},
{"f_1881data-structures.scm",(void*)f_1881},
{"f_1837data-structures.scm",(void*)f_1837},
{"f_1845data-structures.scm",(void*)f_1845},
{"f_1792data-structures.scm",(void*)f_1792},
{"f_1829data-structures.scm",(void*)f_1829},
{"f_1832data-structures.scm",(void*)f_1832},
{"f_1715data-structures.scm",(void*)f_1715},
{"f_1718data-structures.scm",(void*)f_1718},
{"f_1734data-structures.scm",(void*)f_1734},
{"f_1743data-structures.scm",(void*)f_1743},
{"f_1665data-structures.scm",(void*)f_1665},
{"f_1677data-structures.scm",(void*)f_1677},
{"f_1696data-structures.scm",(void*)f_1696},
{"f_1541data-structures.scm",(void*)f_1541},
{"f_1617data-structures.scm",(void*)f_1617},
{"f_1612data-structures.scm",(void*)f_1612},
{"f_1543data-structures.scm",(void*)f_1543},
{"f_1572data-structures.scm",(void*)f_1572},
{"f_1578data-structures.scm",(void*)f_1578},
{"f_1594data-structures.scm",(void*)f_1594},
{"f_1547data-structures.scm",(void*)f_1547},
{"f_1550data-structures.scm",(void*)f_1550},
{"f_1455data-structures.scm",(void*)f_1455},
{"f_1494data-structures.scm",(void*)f_1494},
{"f_1500data-structures.scm",(void*)f_1500},
{"f_1516data-structures.scm",(void*)f_1516},
{"f_1462data-structures.scm",(void*)f_1462},
{"f_1465data-structures.scm",(void*)f_1465},
{"f_1414data-structures.scm",(void*)f_1414},
{"f_1445data-structures.scm",(void*)f_1445},
{"f_1453data-structures.scm",(void*)f_1453},
{"f_1429data-structures.scm",(void*)f_1429},
{"f_1431data-structures.scm",(void*)f_1431},
{"f_1425data-structures.scm",(void*)f_1425},
{"f_1334data-structures.scm",(void*)f_1334},
{"f_1343data-structures.scm",(void*)f_1343},
{"f_1385data-structures.scm",(void*)f_1385},
{"f_1275data-structures.scm",(void*)f_1275},
{"f_1287data-structures.scm",(void*)f_1287},
{"f_1322data-structures.scm",(void*)f_1322},
{"f_1190data-structures.scm",(void*)f_1190},
{"f_1197data-structures.scm",(void*)f_1197},
{"f_1205data-structures.scm",(void*)f_1205},
{"f_1226data-structures.scm",(void*)f_1226},
{"f_1240data-structures.scm",(void*)f_1240},
{"f_1244data-structures.scm",(void*)f_1244},
{"f_1149data-structures.scm",(void*)f_1149},
{"f_1155data-structures.scm",(void*)f_1155},
{"f_1188data-structures.scm",(void*)f_1188},
{"f_1181data-structures.scm",(void*)f_1181},
{"f_1117data-structures.scm",(void*)f_1117},
{"f_1126data-structures.scm",(void*)f_1126},
{"f_1147data-structures.scm",(void*)f_1147},
{"f_1084data-structures.scm",(void*)f_1084},
{"f_1090data-structures.scm",(void*)f_1090},
{"f_1115data-structures.scm",(void*)f_1115},
{"f_1056data-structures.scm",(void*)f_1056},
{"f_1068data-structures.scm",(void*)f_1068},
{"f_1053data-structures.scm",(void*)f_1053},
{"f_1027data-structures.scm",(void*)f_1027},
{"f_1031data-structures.scm",(void*)f_1031},
{"f_1034data-structures.scm",(void*)f_1034},
{"f_1035data-structures.scm",(void*)f_1035},
{"f_1051data-structures.scm",(void*)f_1051},
{"f_1047data-structures.scm",(void*)f_1047},
{"f_1043data-structures.scm",(void*)f_1043},
{"f_1012data-structures.scm",(void*)f_1012},
{"f_1016data-structures.scm",(void*)f_1016},
{"f_1017data-structures.scm",(void*)f_1017},
{"f_1025data-structures.scm",(void*)f_1025},
{"f_1009data-structures.scm",(void*)f_1009},
{"f_1006data-structures.scm",(void*)f_1006},
{"f_1003data-structures.scm",(void*)f_1003},
{"f_1000data-structures.scm",(void*)f_1000},
{"f_944data-structures.scm",(void*)f_944},
{"f_966data-structures.scm",(void*)f_966},
{"f_972data-structures.scm",(void*)f_972},
{"f_991data-structures.scm",(void*)f_991},
{"f_952data-structures.scm",(void*)f_952},
{"f_938data-structures.scm",(void*)f_938},
{"f_897data-structures.scm",(void*)f_897},
{"f_899data-structures.scm",(void*)f_899},
{"f_905data-structures.scm",(void*)f_905},
{"f_924data-structures.scm",(void*)f_924},
{"f_858data-structures.scm",(void*)f_858},
{"f_870data-structures.scm",(void*)f_870},
{"f_884data-structures.scm",(void*)f_884},
{"f_895data-structures.scm",(void*)f_895},
{"f_892data-structures.scm",(void*)f_892},
{"f_822data-structures.scm",(void*)f_822},
{"f_825data-structures.scm",(void*)f_825},
{"f_833data-structures.scm",(void*)f_833},
{"f_839data-structures.scm",(void*)f_839},
{"f_847data-structures.scm",(void*)f_847},
{"f_810data-structures.scm",(void*)f_810},
{"f_812data-structures.scm",(void*)f_812},
{"f_820data-structures.scm",(void*)f_820},
{"f_802data-structures.scm",(void*)f_802},
{"f_804data-structures.scm",(void*)f_804},
{"f_779data-structures.scm",(void*)f_779},
{"f_792data-structures.scm",(void*)f_792},
{"f_790data-structures.scm",(void*)f_790},
{"f_742data-structures.scm",(void*)f_742},
{"f_744data-structures.scm",(void*)f_744},
{"f_750data-structures.scm",(void*)f_750},
{"f_760data-structures.scm",(void*)f_760},
{"f_709data-structures.scm",(void*)f_709},
{"f_711data-structures.scm",(void*)f_711},
{"f_717data-structures.scm",(void*)f_717},
{"f_730data-structures.scm",(void*)f_730},
{"f_701data-structures.scm",(void*)f_701},
{"f_703data-structures.scm",(void*)f_703},
{"f_698data-structures.scm",(void*)f_698},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
