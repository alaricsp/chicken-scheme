/* Generated from srfi-13.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-09-14 12:01
   Version 2.702 - macosx-unix-gnu-ppc - [ manyargs dload applyhook ]
   command line: srfi-13.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file srfi-13.c
   unit: srfi_13
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_14_toplevel)
C_externimport void C_ccall C_srfi_14_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[540];


C_noret_decl(C_srfi_13_toplevel)
C_externexport void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_ccall f_7538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7476)
static void C_fcall f_7476(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7482)
static void C_fcall f_7482(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7383)
static void C_fcall f_7383(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_fcall f_7414(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7358)
static void C_ccall f_7358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_ccall f_7274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7264)
static void C_ccall f_7264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7228)
static void C_ccall f_7228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7221)
static void C_ccall f_7221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7218)
static void C_ccall f_7218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7126)
static void C_ccall f_7126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7047)
static void C_fcall f_7047(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6987)
static void C_ccall f_6987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6929)
static void C_fcall f_6929(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6936)
static void C_ccall f_6936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_fcall f_6941(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6827)
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6877)
static void C_fcall f_6877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6742)
static C_word C_fcall f_6742(C_word t0,C_word t1);
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6646)
static void C_ccall f_6646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_fcall f_6651(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static C_word C_fcall f_6680(C_word t0,C_word t1);
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6543)
static void C_fcall f_6543(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6602)
static void C_fcall f_6602(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6507)
static void C_fcall f_6507(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6452)
static C_word C_fcall f_6452(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static C_word C_fcall f_6403(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6284)
static void C_fcall f_6284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6316)
static void C_fcall f_6316(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6269)
static void C_ccall f_6269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6219)
static void C_fcall f_6219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6226)
static void C_ccall f_6226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_fcall f_6120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6135)
static void C_fcall f_6135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_fcall f_5996(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5918)
static void C_ccall f_5918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5918)
static void C_ccall f_5918r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5954)
static void C_fcall f_5954(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5892)
static void C_fcall f_5892(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5905)
static void C_ccall f_5905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_fcall f_5775(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5825)
static C_word C_fcall f_5825(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5787)
static C_word C_fcall f_5787(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5724)
static C_word C_fcall f_5724(C_word t0,C_word t1);
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_fcall f_5669(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5651)
static void C_ccall f_5651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static C_word C_fcall f_5591(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_fcall f_5538(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_fcall f_5499(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static C_word C_fcall f_5460(C_word t0,C_word t1);
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_fcall f_5368(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static C_word C_fcall f_5333(C_word t0,C_word t1);
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_fcall f_5280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_fcall f_5241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static C_word C_fcall f_5202(C_word t0,C_word t1);
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_fcall f_5145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_fcall f_5110(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static C_word C_fcall f_5075(C_word t0,C_word t1);
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4759)
static void C_ccall f_4759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_fcall f_4378(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4260)
static void C_fcall f_4260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4214)
static void C_fcall f_4214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_fcall f_4132(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4150)
static void C_fcall f_4150(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static C_word C_fcall f_4185(C_word t0,C_word t1);
C_noret_decl(f_4134)
static void C_fcall f_4134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4067)
static void C_fcall f_4067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3965)
static void C_fcall f_3965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3914)
static void C_fcall f_3914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3839)
static void C_fcall f_3839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3740)
static void C_fcall f_3740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3689)
static void C_fcall f_3689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3638)
static void C_fcall f_3638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3587)
static void C_fcall f_3587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3512)
static void C_fcall f_3512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_fcall f_3356(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_fcall f_3391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_fcall f_3294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_fcall f_3329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_fcall f_2877(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_fcall f_2890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_fcall f_2903(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_fcall f_2913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_fcall f_2817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_fcall f_2822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_fcall f_2832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_fcall f_2719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_fcall f_2732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_fcall f_2745(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2755)
static void C_fcall f_2755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_fcall f_2646(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_fcall f_2659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_fcall f_2664(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2674)
static void C_fcall f_2674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_fcall f_2536(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static C_word C_fcall f_2501(C_word t0,C_word t1);
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_fcall f_2447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_fcall f_2406(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static C_word C_fcall f_2371(C_word t0,C_word t1);
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2328)
static void C_fcall f_2328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2287)
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_fcall f_2108(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_2114)
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_fcall f_2201(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_fcall f_1926(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_1932)
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_fcall f_2016(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1874)
static void C_fcall f_1874(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1828)
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_fcall f_1777(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1783)
static void C_fcall f_1783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_fcall f_1728(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_fcall f_1658(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1665)
static void C_fcall f_1665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7476)
static void C_fcall trf_7476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7476(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7476(t0,t1,t2,t3);}

C_noret_decl(trf_7482)
static void C_fcall trf_7482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7482(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7482(t0,t1,t2);}

C_noret_decl(trf_7383)
static void C_fcall trf_7383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7383(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7383(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7414)
static void C_fcall trf_7414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7414(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7414(t0,t1,t2,t3);}

C_noret_decl(trf_7047)
static void C_fcall trf_7047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7047(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7047(t0,t1,t2,t3);}

C_noret_decl(trf_6929)
static void C_fcall trf_6929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6929(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6929(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6941)
static void C_fcall trf_6941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6941(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6941(t0,t1,t2,t3);}

C_noret_decl(trf_6827)
static void C_fcall trf_6827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6827(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6827(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6877)
static void C_fcall trf_6877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6877(t0,t1);}

C_noret_decl(trf_6651)
static void C_fcall trf_6651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6651(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6651(t0,t1,t2,t3);}

C_noret_decl(trf_6543)
static void C_fcall trf_6543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6543(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6543(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6602)
static void C_fcall trf_6602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6602(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6602(t0,t1,t2,t3);}

C_noret_decl(trf_6507)
static void C_fcall trf_6507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6507(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6507(t0,t1,t2,t3);}

C_noret_decl(trf_6284)
static void C_fcall trf_6284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6284(t0,t1,t2,t3);}

C_noret_decl(trf_6316)
static void C_fcall trf_6316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6316(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6316(t0,t1,t2);}

C_noret_decl(trf_6219)
static void C_fcall trf_6219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6219(t0,t1,t2);}

C_noret_decl(trf_6120)
static void C_fcall trf_6120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6120(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6120(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6135)
static void C_fcall trf_6135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6135(t0,t1,t2);}

C_noret_decl(trf_5996)
static void C_fcall trf_5996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5996(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5996(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5954)
static void C_fcall trf_5954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5954(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5954(t0,t1,t2);}

C_noret_decl(trf_5892)
static void C_fcall trf_5892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5892(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5892(t0,t1,t2);}

C_noret_decl(trf_5775)
static void C_fcall trf_5775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5775(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5775(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5669)
static void C_fcall trf_5669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5669(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5669(t0,t1,t2,t3);}

C_noret_decl(trf_5630)
static void C_fcall trf_5630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5630(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5630(t0,t1,t2,t3);}

C_noret_decl(trf_5538)
static void C_fcall trf_5538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5538(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5538(t0,t1,t2);}

C_noret_decl(trf_5499)
static void C_fcall trf_5499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5499(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5499(t0,t1,t2);}

C_noret_decl(trf_5403)
static void C_fcall trf_5403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5403(t0,t1,t2);}

C_noret_decl(trf_5368)
static void C_fcall trf_5368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5368(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5368(t0,t1,t2);}

C_noret_decl(trf_5280)
static void C_fcall trf_5280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5280(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5280(t0,t1,t2);}

C_noret_decl(trf_5241)
static void C_fcall trf_5241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5241(t0,t1,t2);}

C_noret_decl(trf_5145)
static void C_fcall trf_5145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5145(t0,t1,t2);}

C_noret_decl(trf_5110)
static void C_fcall trf_5110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5110(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5110(t0,t1,t2);}

C_noret_decl(trf_4378)
static void C_fcall trf_4378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4378(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4378(t0,t1,t2,t3);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4384(t0,t1,t2);}

C_noret_decl(trf_4260)
static void C_fcall trf_4260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4260(t0,t1);}

C_noret_decl(trf_4214)
static void C_fcall trf_4214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4214(t0,t1);}

C_noret_decl(trf_4132)
static void C_fcall trf_4132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4132(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4132(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4150)
static void C_fcall trf_4150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4150(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4150(t0,t1,t2,t3);}

C_noret_decl(trf_4134)
static void C_fcall trf_4134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4134(t0,t1,t2,t3);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4115(t0,t1);}

C_noret_decl(trf_4067)
static void C_fcall trf_4067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4067(t0,t1);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4016(t0,t1);}

C_noret_decl(trf_3965)
static void C_fcall trf_3965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3965(t0,t1);}

C_noret_decl(trf_3914)
static void C_fcall trf_3914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3914(t0,t1);}

C_noret_decl(trf_3839)
static void C_fcall trf_3839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3839(t0,t1);}

C_noret_decl(trf_3788)
static void C_fcall trf_3788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3788(t0,t1);}

C_noret_decl(trf_3740)
static void C_fcall trf_3740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3740(t0,t1);}

C_noret_decl(trf_3689)
static void C_fcall trf_3689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3689(t0,t1);}

C_noret_decl(trf_3638)
static void C_fcall trf_3638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3638(t0,t1);}

C_noret_decl(trf_3587)
static void C_fcall trf_3587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3587(t0,t1);}

C_noret_decl(trf_3512)
static void C_fcall trf_3512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3512(t0,t1);}

C_noret_decl(trf_3356)
static void C_fcall trf_3356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3356(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_3356(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_3391)
static void C_fcall trf_3391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3391(t0,t1);}

C_noret_decl(trf_3294)
static void C_fcall trf_3294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3294(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_3294(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_3329)
static void C_fcall trf_3329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3329(t0,t1);}

C_noret_decl(trf_2877)
static void C_fcall trf_2877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2877(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2877(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2890)
static void C_fcall trf_2890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2890(t0,t1);}

C_noret_decl(trf_2903)
static void C_fcall trf_2903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2903(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2903(t0,t1,t2,t3);}

C_noret_decl(trf_2913)
static void C_fcall trf_2913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2913(t0,t1);}

C_noret_decl(trf_2804)
static void C_fcall trf_2804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2804(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2804(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2817)
static void C_fcall trf_2817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2817(t0,t1);}

C_noret_decl(trf_2822)
static void C_fcall trf_2822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2822(t0,t1,t2,t3);}

C_noret_decl(trf_2832)
static void C_fcall trf_2832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2832(t0,t1);}

C_noret_decl(trf_2719)
static void C_fcall trf_2719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2719(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2719(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2732)
static void C_fcall trf_2732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2732(t0,t1);}

C_noret_decl(trf_2745)
static void C_fcall trf_2745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2745(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2745(t0,t1,t2,t3);}

C_noret_decl(trf_2755)
static void C_fcall trf_2755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2755(t0,t1);}

C_noret_decl(trf_2646)
static void C_fcall trf_2646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2646(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2646(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2659)
static void C_fcall trf_2659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2659(t0,t1);}

C_noret_decl(trf_2664)
static void C_fcall trf_2664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2664(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2664(t0,t1,t2,t3);}

C_noret_decl(trf_2674)
static void C_fcall trf_2674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2674(t0,t1);}

C_noret_decl(trf_2623)
static void C_fcall trf_2623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2623(t0,t1,t2);}

C_noret_decl(trf_2577)
static void C_fcall trf_2577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2577(t0,t1,t2);}

C_noret_decl(trf_2536)
static void C_fcall trf_2536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2536(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2536(t0,t1,t2);}

C_noret_decl(trf_2447)
static void C_fcall trf_2447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2447(t0,t1,t2);}

C_noret_decl(trf_2406)
static void C_fcall trf_2406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2406(t0,t1,t2);}

C_noret_decl(trf_2328)
static void C_fcall trf_2328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2328(t0,t1,t2);}

C_noret_decl(trf_2287)
static void C_fcall trf_2287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2287(t0,t1,t2);}

C_noret_decl(trf_2108)
static void C_fcall trf_2108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2108(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_2108(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_2114)
static void C_fcall trf_2114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2114(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2114(t0,t1,t2,t3);}

C_noret_decl(trf_2201)
static void C_fcall trf_2201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2201(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2201(t0,t1,t2,t3);}

C_noret_decl(trf_1926)
static void C_fcall trf_1926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1926(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_1926(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_1932)
static void C_fcall trf_1932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1932(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1932(t0,t1,t2,t3);}

C_noret_decl(trf_2016)
static void C_fcall trf_2016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2016(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2016(t0,t1,t2,t3);}

C_noret_decl(trf_1874)
static void C_fcall trf_1874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1874(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1874(t0,t1,t2,t3);}

C_noret_decl(trf_1828)
static void C_fcall trf_1828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1828(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1828(t0,t1,t2,t3);}

C_noret_decl(trf_1777)
static void C_fcall trf_1777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1777(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1777(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1783)
static void C_fcall trf_1783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1783(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1783(t0,t1,t2);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1716(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1728)
static void C_fcall trf_1728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1728(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1728(t0,t1,t2,t3);}

C_noret_decl(trf_1658)
static void C_fcall trf_1658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1658(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1658(t0,t1,t2,t3);}

C_noret_decl(trf_1665)
static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1665(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr7r)
static void C_fcall tr7r(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7r(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n*3);
t7=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_13_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1100)){
C_save(t1);
C_rereclaim2(1100*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,540);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],22,"string-parse-start+end");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_static_string(C_heaptop,26,"Illegal substring END spec");
lf[5]=C_static_lambda_info(C_heaptop,7,"(a1474)");
lf[6]=C_static_string(C_heaptop,32,"Illegal substring START/END spec");
lf[7]=C_static_lambda_info(C_heaptop,20,"(a1510 end10 args11)");
lf[8]=C_static_string(C_heaptop,28,"Illegal substring START spec");
lf[9]=C_static_lambda_info(C_heaptop,39,"(string-parse-start+end proc2 s3 args4)");
lf[10]=C_h_intern(&lf[10],28,"string-parse-final-start+end");
lf[11]=C_static_lambda_info(C_heaptop,7,"(a1543)");
lf[12]=C_static_string(C_heaptop,28,"Extra arguments to procedure");
lf[13]=C_static_lambda_info(C_heaptop,28,"(a1549 rest16 start17 end18)");
lf[14]=C_static_lambda_info(C_heaptop,48,"(string-parse-final-start+end proc13 s14 args15)");
lf[15]=C_h_intern(&lf[15],18,"substring-spec-ok\077");
lf[16]=C_static_lambda_info(C_heaptop,38,"(substring-spec-ok\077 s19 start20 end21)");
lf[17]=C_h_intern(&lf[17],20,"check-substring-spec");
lf[18]=C_static_string(C_heaptop,23,"Illegal substring spec.");
lf[19]=C_static_lambda_info(C_heaptop,47,"(check-substring-spec proc22 s23 start24 end25)");
lf[20]=C_h_intern(&lf[20],16,"substring/shared");
lf[22]=C_static_lambda_info(C_heaptop,44,"(substring/shared s26 start27 . maybe-end28)");
lf[23]=C_h_intern(&lf[23],13,"\003syssubstring");
lf[24]=C_static_lambda_info(C_heaptop,37,"(%substring/shared s36 start37 end38)");
lf[25]=C_h_intern(&lf[25],11,"string-copy");
lf[26]=C_static_lambda_info(C_heaptop,7,"(a1685)");
lf[27]=C_static_lambda_info(C_heaptop,21,"(a1691 start41 end42)");
lf[28]=C_static_lambda_info(C_heaptop,37,"(string-copy s39 . maybe-start+end40)");
lf[29]=C_h_intern(&lf[29],10,"string-map");
lf[30]=C_static_lambda_info(C_heaptop,7,"(a1703)");
lf[32]=C_static_lambda_info(C_heaptop,21,"(a1709 start46 end47)");
lf[33]=C_static_lambda_info(C_heaptop,43,"(string-map proc43 s44 . maybe-start+end45)");
lf[34]=C_static_lambda_info(C_heaptop,14,"(do54 i56 j57)");
lf[35]=C_h_intern(&lf[35],11,"make-string");
lf[36]=C_static_lambda_info(C_heaptop,38,"(%string-map proc48 s49 start50 end51)");
lf[37]=C_h_intern(&lf[37],11,"string-map!");
lf[38]=C_static_lambda_info(C_heaptop,7,"(a1764)");
lf[40]=C_static_lambda_info(C_heaptop,21,"(a1770 start64 end65)");
lf[41]=C_static_lambda_info(C_heaptop,44,"(string-map! proc61 s62 . maybe-start+end63)");
lf[42]=C_static_lambda_info(C_heaptop,10,"(do70 i72)");
lf[43]=C_static_lambda_info(C_heaptop,39,"(%string-map! proc66 s67 start68 end69)");
lf[44]=C_h_intern(&lf[44],11,"string-fold");
lf[45]=C_static_lambda_info(C_heaptop,7,"(a1815)");
lf[46]=C_static_lambda_info(C_heaptop,12,"(lp v82 i83)");
lf[47]=C_static_lambda_info(C_heaptop,21,"(a1821 start79 end80)");
lf[48]=C_static_lambda_info(C_heaptop,51,"(string-fold kons75 knil76 s77 . maybe-start+end78)");
lf[49]=C_h_intern(&lf[49],17,"string-fold-right");
lf[50]=C_static_lambda_info(C_heaptop,7,"(a1857)");
lf[51]=C_static_lambda_info(C_heaptop,12,"(lp v92 i93)");
lf[52]=C_static_lambda_info(C_heaptop,21,"(a1863 start89 end90)");
lf[53]=C_static_lambda_info(C_heaptop,57,"(string-fold-right kons85 knil86 s87 . maybe-start+end88)");
lf[54]=C_h_intern(&lf[54],13,"string-unfold");
lf[55]=C_static_string(C_heaptop,0,"");
lf[56]=C_static_string(C_heaptop,0,"");
lf[57]=C_static_lambda_info(C_heaptop,13,"(f_2062 x108)");
lf[59]=C_static_lambda_info(C_heaptop,19,"(lp j133 chunks134)");
lf[60]=C_h_intern(&lf[60],3,"min");
lf[61]=C_static_lambda_info(C_heaptop,18,"(lp2 i117 seed118)");
lf[62]=C_static_lambda_info(C_heaptop,59,"(lp chunks110 nchars111 chunk112 chunk-len113 i114 seed115)");
lf[63]=C_static_lambda_info(C_heaptop,54,"(string-unfold p95 f96 g97 seed98 . base+make-final99)");
lf[64]=C_h_intern(&lf[64],19,"string-unfold-right");
lf[65]=C_static_string(C_heaptop,0,"");
lf[66]=C_static_string(C_heaptop,0,"");
lf[67]=C_static_lambda_info(C_heaptop,13,"(f_2251 x160)");
lf[68]=C_static_lambda_info(C_heaptop,19,"(lp j187 chunks188)");
lf[69]=C_static_lambda_info(C_heaptop,18,"(lp2 i169 seed170)");
lf[70]=C_static_lambda_info(C_heaptop,59,"(lp chunks162 nchars163 chunk164 chunk-len165 i166 seed167)");
lf[71]=C_static_lambda_info(C_heaptop,65,"(string-unfold-right p147 f148 g149 seed150 . base+make-final151)");
lf[72]=C_h_intern(&lf[72],15,"string-for-each");
lf[73]=C_static_lambda_info(C_heaptop,7,"(a2274)");
lf[74]=C_static_lambda_info(C_heaptop,9,"(lp i205)");
lf[75]=C_static_lambda_info(C_heaptop,23,"(a2280 start202 end203)");
lf[76]=C_static_lambda_info(C_heaptop,51,"(string-for-each proc199 s200 . maybe-start+end201)");
lf[77]=C_h_intern(&lf[77],21,"string-for-each-index");
lf[78]=C_static_lambda_info(C_heaptop,7,"(a2315)");
lf[79]=C_static_lambda_info(C_heaptop,9,"(lp i214)");
lf[80]=C_static_lambda_info(C_heaptop,23,"(a2321 start211 end212)");
lf[81]=C_static_lambda_info(C_heaptop,57,"(string-for-each-index proc208 s209 . maybe-start+end210)");
lf[82]=C_h_intern(&lf[82],12,"string-every");
lf[83]=C_static_lambda_info(C_heaptop,7,"(a2352)");
lf[84]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[85]=C_h_intern(&lf[85],18,"char-set-contains\077");
lf[86]=C_static_lambda_info(C_heaptop,9,"(lp i228)");
lf[87]=C_static_lambda_info(C_heaptop,9,"(lp i235)");
lf[88]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[89]=C_h_intern(&lf[89],9,"char-set\077");
lf[90]=C_static_lambda_info(C_heaptop,23,"(a2358 start220 end221)");
lf[91]=C_static_lambda_info(C_heaptop,52,"(string-every criteria217 s218 . maybe-start+end219)");
lf[92]=C_h_intern(&lf[92],10,"string-any");
lf[93]=C_static_lambda_info(C_heaptop,7,"(a2482)");
lf[94]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[95]=C_static_lambda_info(C_heaptop,9,"(lp i250)");
lf[96]=C_static_lambda_info(C_heaptop,9,"(lp i255)");
lf[97]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[98]=C_static_lambda_info(C_heaptop,23,"(a2488 start242 end243)");
lf[99]=C_static_lambda_info(C_heaptop,50,"(string-any criteria239 s240 . maybe-start+end241)");
lf[100]=C_h_intern(&lf[100],15,"string-tabulate");
lf[101]=C_static_lambda_info(C_heaptop,12,"(do264 i266)");
lf[102]=C_static_lambda_info(C_heaptop,32,"(string-tabulate proc261 len262)");
lf[104]=C_static_lambda_info(C_heaptop,14,"(lp i280 j281)");
lf[105]=C_static_lambda_info(C_heaptop,71,"(%string-prefix-length s1271 start1272 end1273 s2274 start2275 end2276)");
lf[107]=C_static_lambda_info(C_heaptop,14,"(lp i294 j295)");
lf[108]=C_static_lambda_info(C_heaptop,71,"(%string-suffix-length s1285 start1286 end1287 s2288 start2289 end2290)");
lf[110]=C_h_intern(&lf[110],9,"char-ci=\077");
lf[111]=C_static_lambda_info(C_heaptop,14,"(lp i308 j309)");
lf[112]=C_static_lambda_info(C_heaptop,74,"(%string-prefix-length-ci s1299 start1300 end1301 s2302 start2303 end2304)");
lf[114]=C_static_lambda_info(C_heaptop,14,"(lp i322 j323)");
lf[115]=C_static_lambda_info(C_heaptop,74,"(%string-suffix-length-ci s1313 start1314 end1315 s2316 start2317 end2318)");
lf[116]=C_h_intern(&lf[116],20,"string-prefix-length");
lf[117]=C_static_lambda_info(C_heaptop,7,"(a2967)");
lf[118]=C_static_lambda_info(C_heaptop,7,"(a2979)");
lf[119]=C_static_lambda_info(C_heaptop,25,"(a2985 start2336 end2337)");
lf[120]=C_static_lambda_info(C_heaptop,33,"(a2973 g331333 start1334 end1335)");
lf[121]=C_static_lambda_info(C_heaptop,57,"(string-prefix-length s1327 s2328 . maybe-starts+ends329)");
lf[122]=C_h_intern(&lf[122],20,"string-suffix-length");
lf[123]=C_static_lambda_info(C_heaptop,7,"(a2997)");
lf[124]=C_static_lambda_info(C_heaptop,7,"(a3009)");
lf[125]=C_static_lambda_info(C_heaptop,25,"(a3015 start2347 end2348)");
lf[126]=C_static_lambda_info(C_heaptop,33,"(a3003 g342344 start1345 end1346)");
lf[127]=C_static_lambda_info(C_heaptop,57,"(string-suffix-length s1338 s2339 . maybe-starts+ends340)");
lf[128]=C_h_intern(&lf[128],23,"string-prefix-length-ci");
lf[129]=C_static_lambda_info(C_heaptop,7,"(a3027)");
lf[130]=C_static_lambda_info(C_heaptop,7,"(a3039)");
lf[131]=C_static_lambda_info(C_heaptop,25,"(a3045 start2358 end2359)");
lf[132]=C_static_lambda_info(C_heaptop,33,"(a3033 g353355 start1356 end1357)");
lf[133]=C_static_lambda_info(C_heaptop,60,"(string-prefix-length-ci s1349 s2350 . maybe-starts+ends351)");
lf[134]=C_h_intern(&lf[134],23,"string-suffix-length-ci");
lf[135]=C_static_lambda_info(C_heaptop,7,"(a3057)");
lf[136]=C_static_lambda_info(C_heaptop,7,"(a3069)");
lf[137]=C_static_lambda_info(C_heaptop,25,"(a3075 start2369 end2370)");
lf[138]=C_static_lambda_info(C_heaptop,33,"(a3063 g364366 start1367 end1368)");
lf[139]=C_static_lambda_info(C_heaptop,60,"(string-suffix-length-ci s1360 s2361 . maybe-starts+ends362)");
lf[140]=C_h_intern(&lf[140],14,"string-prefix\077");
lf[141]=C_static_lambda_info(C_heaptop,7,"(a3087)");
lf[142]=C_static_lambda_info(C_heaptop,7,"(a3099)");
lf[143]=C_static_lambda_info(C_heaptop,25,"(a3105 start2380 end2381)");
lf[144]=C_static_lambda_info(C_heaptop,33,"(a3093 g375377 start1378 end1379)");
lf[145]=C_static_lambda_info(C_heaptop,51,"(string-prefix\077 s1371 s2372 . maybe-starts+ends373)");
lf[146]=C_h_intern(&lf[146],14,"string-suffix\077");
lf[147]=C_static_lambda_info(C_heaptop,7,"(a3117)");
lf[148]=C_static_lambda_info(C_heaptop,7,"(a3129)");
lf[149]=C_static_lambda_info(C_heaptop,25,"(a3135 start2391 end2392)");
lf[150]=C_static_lambda_info(C_heaptop,33,"(a3123 g386388 start1389 end1390)");
lf[151]=C_static_lambda_info(C_heaptop,51,"(string-suffix\077 s1382 s2383 . maybe-starts+ends384)");
lf[152]=C_h_intern(&lf[152],17,"string-prefix-ci\077");
lf[153]=C_static_lambda_info(C_heaptop,7,"(a3147)");
lf[154]=C_static_lambda_info(C_heaptop,7,"(a3159)");
lf[155]=C_static_lambda_info(C_heaptop,25,"(a3165 start2402 end2403)");
lf[156]=C_static_lambda_info(C_heaptop,33,"(a3153 g397399 start1400 end1401)");
lf[157]=C_static_lambda_info(C_heaptop,54,"(string-prefix-ci\077 s1393 s2394 . maybe-starts+ends395)");
lf[158]=C_h_intern(&lf[158],17,"string-suffix-ci\077");
lf[159]=C_static_lambda_info(C_heaptop,7,"(a3177)");
lf[160]=C_static_lambda_info(C_heaptop,7,"(a3189)");
lf[161]=C_static_lambda_info(C_heaptop,25,"(a3195 start2413 end2414)");
lf[162]=C_static_lambda_info(C_heaptop,33,"(a3183 g408410 start1411 end1412)");
lf[163]=C_static_lambda_info(C_heaptop,54,"(string-suffix-ci\077 s1404 s2405 . maybe-starts+ends406)");
lf[165]=C_static_lambda_info(C_heaptop,92,"(%string-compare s1443 start1444 end1445 s2446 start2447 end2448 proc<449 proc=4"
"50 proc>451)");
lf[167]=C_h_intern(&lf[167],9,"char-ci<\077");
lf[168]=C_static_lambda_info(C_heaptop,95,"(%string-compare-ci s1455 start1456 end1457 s2458 start2459 end2460 proc<461 pro"
"c=462 proc>463)");
lf[169]=C_h_intern(&lf[169],14,"string-compare");
lf[170]=C_static_lambda_info(C_heaptop,7,"(a3423)");
lf[171]=C_static_lambda_info(C_heaptop,7,"(a3435)");
lf[172]=C_static_lambda_info(C_heaptop,25,"(a3441 start2479 end2480)");
lf[173]=C_static_lambda_info(C_heaptop,33,"(a3429 g474476 start1477 end1478)");
lf[174]=C_static_lambda_info(C_heaptop,78,"(string-compare s1467 s2468 proc<469 proc=470 proc>471 . maybe-starts+ends472)");
lf[175]=C_h_intern(&lf[175],17,"string-compare-ci");
lf[176]=C_static_lambda_info(C_heaptop,7,"(a3453)");
lf[177]=C_static_lambda_info(C_heaptop,7,"(a3465)");
lf[178]=C_static_lambda_info(C_heaptop,25,"(a3471 start2493 end2494)");
lf[179]=C_static_lambda_info(C_heaptop,33,"(a3459 g488490 start1491 end1492)");
lf[180]=C_static_lambda_info(C_heaptop,81,"(string-compare-ci s1481 s2482 proc<483 proc=484 proc>485 . maybe-starts+ends486"
")");
lf[181]=C_h_intern(&lf[181],7,"string=");
lf[182]=C_static_lambda_info(C_heaptop,7,"(a3483)");
lf[183]=C_static_lambda_info(C_heaptop,7,"(a3495)");
lf[184]=C_static_lambda_info(C_heaptop,12,"(a3519 i508)");
lf[185]=C_static_lambda_info(C_heaptop,12,"(a3522 i509)");
lf[186]=C_h_intern(&lf[186],6,"values");
lf[187]=C_static_lambda_info(C_heaptop,25,"(a3501 start2504 end2505)");
lf[188]=C_static_lambda_info(C_heaptop,33,"(a3489 g499501 start1502 end1503)");
lf[189]=C_static_lambda_info(C_heaptop,44,"(string= s1495 s2496 . maybe-starts+ends497)");
lf[190]=C_h_intern(&lf[190],8,"string<>");
lf[191]=C_static_lambda_info(C_heaptop,7,"(a3545)");
lf[192]=C_static_lambda_info(C_heaptop,7,"(a3557)");
lf[193]=C_static_lambda_info(C_heaptop,12,"(a3581 i523)");
lf[194]=C_static_lambda_info(C_heaptop,25,"(a3563 start2519 end2520)");
lf[195]=C_static_lambda_info(C_heaptop,33,"(a3551 g514516 start1517 end1518)");
lf[196]=C_static_lambda_info(C_heaptop,45,"(string<> s1510 s2511 . maybe-starts+ends512)");
lf[197]=C_h_intern(&lf[197],7,"string<");
lf[198]=C_static_lambda_info(C_heaptop,7,"(a3612)");
lf[199]=C_static_lambda_info(C_heaptop,7,"(a3624)");
lf[200]=C_static_lambda_info(C_heaptop,12,"(a3645 i535)");
lf[201]=C_static_lambda_info(C_heaptop,12,"(a3648 i536)");
lf[202]=C_static_lambda_info(C_heaptop,25,"(a3630 start2533 end2534)");
lf[203]=C_static_lambda_info(C_heaptop,33,"(a3618 g528530 start1531 end1532)");
lf[204]=C_static_lambda_info(C_heaptop,44,"(string< s1524 s2525 . maybe-starts+ends526)");
lf[205]=C_h_intern(&lf[205],7,"string>");
lf[206]=C_static_lambda_info(C_heaptop,7,"(a3663)");
lf[207]=C_static_lambda_info(C_heaptop,7,"(a3675)");
lf[208]=C_static_lambda_info(C_heaptop,12,"(a3696 i548)");
lf[209]=C_static_lambda_info(C_heaptop,12,"(a3699 i549)");
lf[210]=C_static_lambda_info(C_heaptop,25,"(a3681 start2546 end2547)");
lf[211]=C_static_lambda_info(C_heaptop,33,"(a3669 g541543 start1544 end1545)");
lf[212]=C_static_lambda_info(C_heaptop,44,"(string> s1537 s2538 . maybe-starts+ends539)");
lf[213]=C_h_intern(&lf[213],8,"string<=");
lf[214]=C_static_lambda_info(C_heaptop,7,"(a3714)");
lf[215]=C_static_lambda_info(C_heaptop,7,"(a3726)");
lf[216]=C_static_lambda_info(C_heaptop,12,"(a3747 i561)");
lf[217]=C_static_lambda_info(C_heaptop,25,"(a3732 start2559 end2560)");
lf[218]=C_static_lambda_info(C_heaptop,33,"(a3720 g554556 start1557 end1558)");
lf[219]=C_static_lambda_info(C_heaptop,45,"(string<= s1550 s2551 . maybe-starts+ends552)");
lf[220]=C_h_intern(&lf[220],8,"string>=");
lf[221]=C_static_lambda_info(C_heaptop,7,"(a3762)");
lf[222]=C_static_lambda_info(C_heaptop,7,"(a3774)");
lf[223]=C_static_lambda_info(C_heaptop,12,"(a3795 i573)");
lf[224]=C_static_lambda_info(C_heaptop,25,"(a3780 start2571 end2572)");
lf[225]=C_static_lambda_info(C_heaptop,33,"(a3768 g566568 start1569 end1570)");
lf[226]=C_static_lambda_info(C_heaptop,45,"(string>= s1562 s2563 . maybe-starts+ends564)");
lf[227]=C_h_intern(&lf[227],10,"string-ci=");
lf[228]=C_static_lambda_info(C_heaptop,7,"(a3810)");
lf[229]=C_static_lambda_info(C_heaptop,7,"(a3822)");
lf[230]=C_static_lambda_info(C_heaptop,12,"(a3846 i587)");
lf[231]=C_static_lambda_info(C_heaptop,12,"(a3849 i588)");
lf[232]=C_static_lambda_info(C_heaptop,25,"(a3828 start2583 end2584)");
lf[233]=C_static_lambda_info(C_heaptop,33,"(a3816 g578580 start1581 end1582)");
lf[234]=C_static_lambda_info(C_heaptop,47,"(string-ci= s1574 s2575 . maybe-starts+ends576)");
lf[235]=C_h_intern(&lf[235],11,"string-ci<>");
lf[236]=C_static_lambda_info(C_heaptop,7,"(a3872)");
lf[237]=C_static_lambda_info(C_heaptop,7,"(a3884)");
lf[238]=C_static_lambda_info(C_heaptop,12,"(a3908 i602)");
lf[239]=C_static_lambda_info(C_heaptop,25,"(a3890 start2598 end2599)");
lf[240]=C_static_lambda_info(C_heaptop,33,"(a3878 g593595 start1596 end1597)");
lf[241]=C_static_lambda_info(C_heaptop,48,"(string-ci<> s1589 s2590 . maybe-starts+ends591)");
lf[242]=C_h_intern(&lf[242],10,"string-ci<");
lf[243]=C_static_lambda_info(C_heaptop,7,"(a3939)");
lf[244]=C_static_lambda_info(C_heaptop,7,"(a3951)");
lf[245]=C_static_lambda_info(C_heaptop,12,"(a3972 i614)");
lf[246]=C_static_lambda_info(C_heaptop,12,"(a3975 i615)");
lf[247]=C_static_lambda_info(C_heaptop,25,"(a3957 start2612 end2613)");
lf[248]=C_static_lambda_info(C_heaptop,33,"(a3945 g607609 start1610 end1611)");
lf[249]=C_static_lambda_info(C_heaptop,47,"(string-ci< s1603 s2604 . maybe-starts+ends605)");
lf[250]=C_h_intern(&lf[250],10,"string-ci>");
lf[251]=C_static_lambda_info(C_heaptop,7,"(a3990)");
lf[252]=C_static_lambda_info(C_heaptop,7,"(a4002)");
lf[253]=C_static_lambda_info(C_heaptop,12,"(a4023 i627)");
lf[254]=C_static_lambda_info(C_heaptop,12,"(a4026 i628)");
lf[255]=C_static_lambda_info(C_heaptop,25,"(a4008 start2625 end2626)");
lf[256]=C_static_lambda_info(C_heaptop,33,"(a3996 g620622 start1623 end1624)");
lf[257]=C_static_lambda_info(C_heaptop,47,"(string-ci> s1616 s2617 . maybe-starts+ends618)");
lf[258]=C_h_intern(&lf[258],11,"string-ci<=");
lf[259]=C_static_lambda_info(C_heaptop,7,"(a4041)");
lf[260]=C_static_lambda_info(C_heaptop,7,"(a4053)");
lf[261]=C_static_lambda_info(C_heaptop,12,"(a4074 i640)");
lf[262]=C_static_lambda_info(C_heaptop,25,"(a4059 start2638 end2639)");
lf[263]=C_static_lambda_info(C_heaptop,33,"(a4047 g633635 start1636 end1637)");
lf[264]=C_static_lambda_info(C_heaptop,48,"(string-ci<= s1629 s2630 . maybe-starts+ends631)");
lf[265]=C_h_intern(&lf[265],11,"string-ci>=");
lf[266]=C_static_lambda_info(C_heaptop,7,"(a4089)");
lf[267]=C_static_lambda_info(C_heaptop,7,"(a4101)");
lf[268]=C_static_lambda_info(C_heaptop,12,"(a4122 i652)");
lf[269]=C_static_lambda_info(C_heaptop,25,"(a4107 start2650 end2651)");
lf[270]=C_static_lambda_info(C_heaptop,33,"(a4095 g645647 start1648 end1649)");
lf[271]=C_static_lambda_info(C_heaptop,48,"(string-ci>= s1641 s2642 . maybe-starts+ends643)");
lf[273]=C_static_lambda_info(C_heaptop,16,"(iref s660 i661)");
lf[274]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[275]=C_h_intern(&lf[275],6,"modulo");
lf[276]=C_static_lambda_info(C_heaptop,16,"(lp i666 ans667)");
lf[277]=C_static_lambda_info(C_heaptop,57,"(%string-hash s653 char->int654 bound655 start656 end657)");
lf[278]=C_h_intern(&lf[278],11,"string-hash");
lf[279]=C_static_lambda_info(C_heaptop,7,"(a4221)");
lf[280]=C_h_intern(&lf[280],13,"char->integer");
lf[281]=C_static_lambda_info(C_heaptop,23,"(a4227 start677 end678)");
lf[282]=C_static_lambda_info(C_heaptop,45,"(string-hash s669 . maybe-bound+start+end670)");
lf[283]=C_h_intern(&lf[283],14,"string-hash-ci");
lf[284]=C_static_lambda_info(C_heaptop,7,"(a4267)");
lf[285]=C_static_lambda_info(C_heaptop,12,"(a4279 c691)");
lf[286]=C_static_lambda_info(C_heaptop,23,"(a4273 start689 end690)");
lf[287]=C_static_lambda_info(C_heaptop,48,"(string-hash-ci s681 . maybe-bound+start+end682)");
lf[288]=C_h_intern(&lf[288],13,"string-upcase");
lf[289]=C_static_lambda_info(C_heaptop,7,"(a4311)");
lf[290]=C_h_intern(&lf[290],11,"char-upcase");
lf[291]=C_static_lambda_info(C_heaptop,23,"(a4317 start696 end697)");
lf[292]=C_static_lambda_info(C_heaptop,41,"(string-upcase s694 . maybe-start+end695)");
lf[293]=C_h_intern(&lf[293],14,"string-upcase!");
lf[294]=C_static_lambda_info(C_heaptop,7,"(a4329)");
lf[295]=C_static_lambda_info(C_heaptop,23,"(a4335 start700 end701)");
lf[296]=C_static_lambda_info(C_heaptop,42,"(string-upcase! s698 . maybe-start+end699)");
lf[297]=C_h_intern(&lf[297],15,"string-downcase");
lf[298]=C_static_lambda_info(C_heaptop,7,"(a4347)");
lf[299]=C_h_intern(&lf[299],13,"char-downcase");
lf[300]=C_static_lambda_info(C_heaptop,23,"(a4353 start704 end705)");
lf[301]=C_static_lambda_info(C_heaptop,43,"(string-downcase s702 . maybe-start+end703)");
lf[302]=C_h_intern(&lf[302],16,"string-downcase!");
lf[303]=C_static_lambda_info(C_heaptop,7,"(a4365)");
lf[304]=C_static_lambda_info(C_heaptop,23,"(a4371 start708 end709)");
lf[305]=C_static_lambda_info(C_heaptop,44,"(string-downcase! s706 . maybe-start+end707)");
lf[307]=C_static_lambda_info(C_heaptop,13,"(a4417 c0723)");
lf[308]=C_h_intern(&lf[308],11,"string-skip");
lf[309]=C_static_lambda_info(C_heaptop,13,"(a4430 c0717)");
lf[310]=C_h_intern(&lf[310],12,"string-index");
lf[311]=C_static_lambda_info(C_heaptop,9,"(lp i714)");
lf[312]=C_static_lambda_info(C_heaptop,41,"(%string-titlecase! s710 start711 end712)");
lf[313]=C_h_intern(&lf[313],17,"string-titlecase!");
lf[314]=C_static_lambda_info(C_heaptop,7,"(a4442)");
lf[315]=C_static_lambda_info(C_heaptop,23,"(a4448 start730 end731)");
lf[316]=C_static_lambda_info(C_heaptop,45,"(string-titlecase! s728 . maybe-start+end729)");
lf[317]=C_h_intern(&lf[317],16,"string-titlecase");
lf[318]=C_static_lambda_info(C_heaptop,7,"(a4460)");
lf[319]=C_static_lambda_info(C_heaptop,23,"(a4466 start734 end735)");
lf[320]=C_static_lambda_info(C_heaptop,44,"(string-titlecase s732 . maybe-start+end733)");
lf[321]=C_h_intern(&lf[321],11,"string-take");
lf[322]=C_h_intern(&lf[322],15,"\003syscheck-range");
lf[323]=C_static_lambda_info(C_heaptop,23,"(string-take s738 n739)");
lf[324]=C_h_intern(&lf[324],17,"string-take-right");
lf[325]=C_static_lambda_info(C_heaptop,29,"(string-take-right s742 n743)");
lf[326]=C_h_intern(&lf[326],11,"string-drop");
lf[327]=C_static_lambda_info(C_heaptop,23,"(string-drop s747 n748)");
lf[328]=C_h_intern(&lf[328],17,"string-drop-right");
lf[329]=C_static_lambda_info(C_heaptop,29,"(string-drop-right s752 n753)");
lf[330]=C_h_intern(&lf[330],11,"string-trim");
lf[331]=C_h_intern(&lf[331],19,"char-set:whitespace");
lf[332]=C_static_lambda_info(C_heaptop,7,"(a4588)");
lf[333]=C_static_string(C_heaptop,0,"");
lf[334]=C_static_lambda_info(C_heaptop,23,"(a4594 start765 end766)");
lf[335]=C_static_lambda_info(C_heaptop,42,"(string-trim s757 . criteria+start+end758)");
lf[336]=C_h_intern(&lf[336],17,"string-trim-right");
lf[337]=C_static_lambda_info(C_heaptop,7,"(a4630)");
lf[338]=C_static_string(C_heaptop,0,"");
lf[339]=C_h_intern(&lf[339],17,"string-skip-right");
lf[340]=C_static_lambda_info(C_heaptop,23,"(a4636 start778 end779)");
lf[341]=C_static_lambda_info(C_heaptop,48,"(string-trim-right s770 . criteria+start+end771)");
lf[342]=C_h_intern(&lf[342],16,"string-trim-both");
lf[343]=C_static_lambda_info(C_heaptop,7,"(a4676)");
lf[344]=C_static_string(C_heaptop,0,"");
lf[345]=C_static_lambda_info(C_heaptop,23,"(a4682 start791 end792)");
lf[346]=C_static_lambda_info(C_heaptop,47,"(string-trim-both s783 . criteria+start+end784)");
lf[347]=C_h_intern(&lf[347],16,"string-pad-right");
lf[348]=C_static_lambda_info(C_heaptop,7,"(a4729)");
lf[349]=C_static_lambda_info(C_heaptop,23,"(a4735 start805 end806)");
lf[350]=C_static_lambda_info(C_heaptop,48,"(string-pad-right s796 n797 . char+start+end798)");
lf[351]=C_h_intern(&lf[351],10,"string-pad");
lf[352]=C_static_lambda_info(C_heaptop,7,"(a4787)");
lf[353]=C_static_lambda_info(C_heaptop,23,"(a4793 start820 end821)");
lf[354]=C_static_lambda_info(C_heaptop,42,"(string-pad s811 n812 . char+start+end813)");
lf[355]=C_h_intern(&lf[355],13,"string-delete");
lf[356]=C_static_lambda_info(C_heaptop,7,"(a4840)");
lf[357]=C_static_lambda_info(C_heaptop,17,"(a4873 c834 i835)");
lf[358]=C_static_lambda_info(C_heaptop,17,"(a4900 c842 i843)");
lf[359]=C_static_lambda_info(C_heaptop,17,"(a4915 c839 i840)");
lf[360]=C_h_intern(&lf[360],8,"char-set");
lf[361]=C_static_string(C_heaptop,54,"string-delete criteria not predicate, char or char-set");
lf[362]=C_static_lambda_info(C_heaptop,23,"(a4846 start829 end830)");
lf[363]=C_static_lambda_info(C_heaptop,53,"(string-delete criteria826 s827 . maybe-start+end828)");
lf[364]=C_h_intern(&lf[364],13,"string-filter");
lf[365]=C_static_lambda_info(C_heaptop,7,"(a4948)");
lf[366]=C_static_lambda_info(C_heaptop,17,"(a4981 c854 i855)");
lf[367]=C_static_lambda_info(C_heaptop,17,"(a5008 c862 i863)");
lf[368]=C_static_lambda_info(C_heaptop,17,"(a5023 c859 i860)");
lf[369]=C_static_string(C_heaptop,54,"string-delete criteria not predicate, char or char-set");
lf[370]=C_static_lambda_info(C_heaptop,23,"(a4954 start849 end850)");
lf[371]=C_static_lambda_info(C_heaptop,53,"(string-filter criteria846 s847 . maybe-start+end848)");
lf[372]=C_static_lambda_info(C_heaptop,7,"(a5056)");
lf[373]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[374]=C_static_lambda_info(C_heaptop,9,"(lp i875)");
lf[375]=C_static_lambda_info(C_heaptop,9,"(lp i878)");
lf[376]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[377]=C_static_lambda_info(C_heaptop,23,"(a5062 start869 end870)");
lf[378]=C_static_lambda_info(C_heaptop,54,"(string-index str866 criteria867 . maybe-start+end868)");
lf[379]=C_h_intern(&lf[379],18,"string-index-right");
lf[380]=C_static_lambda_info(C_heaptop,7,"(a5179)");
lf[381]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[382]=C_static_lambda_info(C_heaptop,9,"(lp i889)");
lf[383]=C_static_lambda_info(C_heaptop,9,"(lp i892)");
lf[384]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[385]=C_static_lambda_info(C_heaptop,23,"(a5185 start883 end884)");
lf[386]=C_static_lambda_info(C_heaptop,60,"(string-index-right str880 criteria881 . maybe-start+end882)");
lf[387]=C_static_lambda_info(C_heaptop,7,"(a5314)");
lf[388]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[389]=C_static_lambda_info(C_heaptop,9,"(lp i903)");
lf[390]=C_static_lambda_info(C_heaptop,9,"(lp i906)");
lf[391]=C_static_string(C_heaptop,63,"Second param is neither char-set, char, or predicate procedure.");
lf[392]=C_static_lambda_info(C_heaptop,23,"(a5320 start897 end898)");
lf[393]=C_static_lambda_info(C_heaptop,53,"(string-skip str894 criteria895 . maybe-start+end896)");
lf[394]=C_static_lambda_info(C_heaptop,7,"(a5437)");
lf[395]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[396]=C_static_lambda_info(C_heaptop,9,"(lp i917)");
lf[397]=C_static_lambda_info(C_heaptop,9,"(lp i920)");
lf[398]=C_static_string(C_heaptop,43,"CRITERIA param is neither char-set or char.");
lf[399]=C_static_lambda_info(C_heaptop,23,"(a5443 start911 end912)");
lf[400]=C_static_lambda_info(C_heaptop,59,"(string-skip-right str908 criteria909 . maybe-start+end910)");
lf[401]=C_h_intern(&lf[401],12,"string-count");
lf[402]=C_static_lambda_info(C_heaptop,7,"(a5572)");
lf[403]=C_static_lambda_info(C_heaptop,16,"(do927 count930)");
lf[404]=C_static_lambda_info(C_heaptop,21,"(do932 i934 count935)");
lf[405]=C_static_lambda_info(C_heaptop,21,"(do937 i939 count940)");
lf[406]=C_static_string(C_heaptop,43,"CRITERIA param is neither char-set or char.");
lf[407]=C_static_lambda_info(C_heaptop,23,"(a5578 start925 end926)");
lf[408]=C_static_lambda_info(C_heaptop,52,"(string-count s922 criteria923 . maybe-start+end924)");
lf[409]=C_h_intern(&lf[409],12,"string-fill!");
lf[410]=C_static_lambda_info(C_heaptop,7,"(a5707)");
lf[411]=C_static_lambda_info(C_heaptop,7,"(do947)");
lf[412]=C_static_lambda_info(C_heaptop,23,"(a5713 start945 end946)");
lf[413]=C_static_lambda_info(C_heaptop,48,"(string-fill! s942 char943 . maybe-start+end944)");
lf[414]=C_h_intern(&lf[414],12,"string-copy!");
lf[415]=C_static_lambda_info(C_heaptop,7,"(a5748)");
lf[416]=C_static_lambda_info(C_heaptop,25,"(a5754 fstart956 fend957)");
lf[417]=C_static_lambda_info(C_heaptop,61,"(string-copy! to952 tstart953 from954 . maybe-fstart+fend955)");
lf[418]=C_static_lambda_info(C_heaptop,12,"(do965 j968)");
lf[419]=C_static_lambda_info(C_heaptop,12,"(do971 j974)");
lf[420]=C_static_lambda_info(C_heaptop,57,"(%string-copy! to960 tstart961 from962 fstart963 fend964)");
lf[421]=C_h_intern(&lf[421],15,"string-contains");
lf[422]=C_static_lambda_info(C_heaptop,7,"(a5861)");
lf[423]=C_static_lambda_info(C_heaptop,7,"(a5873)");
lf[424]=C_static_lambda_info(C_heaptop,9,"(lp i991)");
lf[425]=C_static_lambda_info(C_heaptop,25,"(a5879 start2986 end2987)");
lf[426]=C_static_lambda_info(C_heaptop,33,"(a5867 g981983 start1984 end1985)");
lf[427]=C_static_lambda_info(C_heaptop,63,"(string-contains string977 substring978 . maybe-starts+ends979)");
lf[428]=C_h_intern(&lf[428],18,"string-contains-ci");
lf[429]=C_static_lambda_info(C_heaptop,7,"(a5923)");
lf[430]=C_static_lambda_info(C_heaptop,7,"(a5935)");
lf[431]=C_static_lambda_info(C_heaptop,10,"(lp i1007)");
lf[432]=C_static_lambda_info(C_heaptop,27,"(a5941 start21002 end21003)");
lf[433]=C_static_lambda_info(C_heaptop,35,"(a5929 g997999 start11000 end11001)");
lf[434]=C_static_lambda_info(C_heaptop,66,"(string-contains-ci string993 substring994 . maybe-starts+ends995)");
lf[436]=C_static_lambda_info(C_heaptop,32,"(lp ti1019 pi1020 tj1021 pj1022)");
lf[437]=C_h_intern(&lf[437],23,"make-kmp-restart-vector");
lf[438]=C_static_lambda_info(C_heaptop,85,"(%kmp-search pattern1009 text1010 c=1011 p-start1012 p-end1013 t-start1014 t-end"
"1015)");
lf[439]=C_h_intern(&lf[439],6,"char=\077");
lf[440]=C_static_lambda_info(C_heaptop,7,"(a6089)");
lf[441]=C_static_lambda_info(C_heaptop,11,"(lp2 j1046)");
lf[442]=C_static_lambda_info(C_heaptop,23,"(lp1 i1041 j1042 k1043)");
lf[443]=C_h_intern(&lf[443],11,"make-vector");
lf[444]=C_static_lambda_info(C_heaptop,35,"(a6095 rest21033 start1034 end1035)");
lf[445]=C_static_lambda_info(C_heaptop,62,"(make-kmp-restart-vector pattern1025 . maybe-c=+start+end1026)");
lf[446]=C_h_intern(&lf[446],8,"kmp-step");
lf[447]=C_static_lambda_info(C_heaptop,10,"(lp i1062)");
lf[448]=C_static_lambda_info(C_heaptop,56,"(kmp-step pat1055 rv1056 c1057 i1058 c=1059 p-start1060)");
lf[449]=C_h_intern(&lf[449],25,"string-kmp-partial-search");
lf[450]=C_static_lambda_info(C_heaptop,7,"(a6268)");
lf[451]=C_static_lambda_info(C_heaptop,12,"(lp2 vi1088)");
lf[452]=C_static_lambda_info(C_heaptop,18,"(lp si1084 vi1085)");
lf[453]=C_static_lambda_info(C_heaptop,39,"(a6274 rest21079 s-start1080 s-end1081)");
lf[454]=C_static_lambda_info(C_heaptop,85,"(string-kmp-partial-search pat1065 rv1066 s1067 i1068 . c=+p-start+s-start+s-end"
"1069)");
lf[455]=C_h_intern(&lf[455],12,"string-null\077");
lf[456]=C_static_lambda_info(C_heaptop,20,"(string-null\077 s1092)");
lf[457]=C_h_intern(&lf[457],14,"string-reverse");
lf[458]=C_static_lambda_info(C_heaptop,7,"(a6380)");
lf[459]=C_static_lambda_info(C_heaptop,14,"(do1099 j1102)");
lf[460]=C_static_lambda_info(C_heaptop,25,"(a6386 start1095 end1096)");
lf[461]=C_static_lambda_info(C_heaptop,44,"(string-reverse s1093 . maybe-start+end1094)");
lf[462]=C_h_intern(&lf[462],15,"string-reverse!");
lf[463]=C_static_lambda_info(C_heaptop,7,"(a6435)");
lf[464]=C_static_lambda_info(C_heaptop,14,"(do1110 j1113)");
lf[465]=C_static_lambda_info(C_heaptop,25,"(a6441 start1108 end1109)");
lf[466]=C_static_lambda_info(C_heaptop,45,"(string-reverse! s1106 . maybe-start+end1107)");
lf[467]=C_h_intern(&lf[467],12,"string->list");
lf[468]=C_static_lambda_info(C_heaptop,7,"(a6490)");
lf[469]=C_static_lambda_info(C_heaptop,22,"(do1122 i1124 ans1125)");
lf[470]=C_static_lambda_info(C_heaptop,25,"(a6496 start1120 end1121)");
lf[471]=C_static_lambda_info(C_heaptop,42,"(string->list s1118 . maybe-start+end1119)");
lf[472]=C_h_intern(&lf[472],20,"string-append/shared");
lf[473]=C_h_intern(&lf[473],25,"string-concatenate/shared");
lf[474]=C_static_lambda_info(C_heaptop,36,"(string-append/shared . strings1127)");
lf[475]=C_static_string(C_heaptop,0,"");
lf[476]=C_static_lambda_info(C_heaptop,22,"(lp strings1140 i1141)");
lf[477]=C_static_lambda_info(C_heaptop,37,"(lp strings1130 nchars1131 first1132)");
lf[478]=C_static_lambda_info(C_heaptop,39,"(string-concatenate/shared strings1128)");
lf[479]=C_h_intern(&lf[479],18,"string-concatenate");
lf[480]=C_static_lambda_info(C_heaptop,14,"(do1150 i1153)");
lf[481]=C_static_lambda_info(C_heaptop,22,"(lp i1157 strings1158)");
lf[482]=C_static_lambda_info(C_heaptop,32,"(string-concatenate strings1148)");
lf[483]=C_h_intern(&lf[483],26,"string-concatenate-reverse");
lf[484]=C_static_string(C_heaptop,0,"");
lf[485]=C_static_lambda_info(C_heaptop,12,"(lp lis1177)");
lf[487]=C_static_lambda_info(C_heaptop,66,"(string-concatenate-reverse string-list1164 . maybe-final+end1165)");
lf[488]=C_h_intern(&lf[488],33,"string-concatenate-reverse/shared");
lf[489]=C_static_string(C_heaptop,0,"");
lf[490]=C_static_lambda_info(C_heaptop,31,"(lp len1191 nzlist1192 lis1193)");
lf[491]=C_static_lambda_info(C_heaptop,73,"(string-concatenate-reverse/shared string-list1180 . maybe-final+end1181)");
lf[492]=C_static_lambda_info(C_heaptop,18,"(lp i1205 lis1206)");
lf[493]=C_static_lambda_info(C_heaptop,78,"(%finish-string-concatenate-reverse len1199 string-list1200 final1201 end1202)");
lf[494]=C_h_intern(&lf[494],14,"string-replace");
lf[495]=C_static_lambda_info(C_heaptop,7,"(a6980)");
lf[496]=C_static_lambda_info(C_heaptop,27,"(a6986 start21220 end21221)");
lf[497]=C_static_lambda_info(C_heaptop,72,"(string-replace s11215 s21216 start11217 end11218 . maybe-start+end1219)");
lf[498]=C_h_intern(&lf[498],15,"string-tokenize");
lf[499]=C_h_intern(&lf[499],16,"char-set:graphic");
lf[500]=C_static_lambda_info(C_heaptop,7,"(a7034)");
lf[501]=C_static_lambda_info(C_heaptop,18,"(lp i1241 ans1242)");
lf[502]=C_static_lambda_info(C_heaptop,25,"(a7040 start1238 end1239)");
lf[503]=C_static_lambda_info(C_heaptop,51,"(string-tokenize s1230 . token-chars+start+end1231)");
lf[504]=C_h_intern(&lf[504],10,"xsubstring");
lf[505]=C_static_lambda_info(C_heaptop,7,"(a7125)");
lf[506]=C_static_lambda_info(C_heaptop,25,"(a7135 start1254 end1255)");
lf[507]=C_static_lambda_info(C_heaptop,7,"(a7113)");
lf[508]=C_static_string(C_heaptop,0,"");
lf[509]=C_static_string(C_heaptop,34,"Cannot replicate empty (sub)string");
lf[511]=C_h_intern(&lf[511],5,"floor");
lf[512]=C_static_lambda_info(C_heaptop,32,"(a7157 to1259 start1260 end1261)");
lf[513]=C_static_lambda_info(C_heaptop,52,"(xsubstring s1251 from1252 . maybe-to+start+end1253)");
lf[515]=C_h_intern(&lf[515],13,"string-xcopy!");
lf[516]=C_static_lambda_info(C_heaptop,7,"(a7263)");
lf[517]=C_static_lambda_info(C_heaptop,25,"(a7273 start1272 end1273)");
lf[518]=C_static_lambda_info(C_heaptop,7,"(a7251)");
lf[519]=C_static_string(C_heaptop,34,"Cannot replicate empty (sub)string");
lf[520]=C_static_lambda_info(C_heaptop,33,"(a7295 sto1277 start1278 end1279)");
lf[521]=C_static_lambda_info(C_heaptop,79,"(string-xcopy! target1267 tstart1268 s1269 sfrom1270 . maybe-sto+start+end1271)");
lf[522]=C_static_lambda_info(C_heaptop,25,"(do1300 i1302 nspans1303)");
lf[523]=C_static_lambda_info(C_heaptop,85,"(%multispan-repcopy! target1287 tstart1288 s1289 sfrom1290 sto1291 start1292 end"
"1293)");
lf[524]=C_h_intern(&lf[524],11,"string-join");
lf[525]=C_static_string(C_heaptop,1," ");
lf[526]=C_h_intern(&lf[526],5,"infix");
lf[527]=C_static_lambda_info(C_heaptop,15,"(recur lis1321)");
lf[528]=C_static_lambda_info(C_heaptop,27,"(buildit lis1318 final1319)");
lf[529]=C_h_intern(&lf[529],12,"strict-infix");
lf[530]=C_h_intern(&lf[530],6,"prefix");
lf[531]=C_h_intern(&lf[531],6,"suffix");
lf[532]=C_static_string(C_heaptop,20,"Illegal join grammar");
lf[533]=C_static_string(C_heaptop,54,"Empty list cannot be joined with STRICT-INFIX grammar.");
lf[534]=C_static_string(C_heaptop,0,"");
lf[535]=C_static_string(C_heaptop,27,"STRINGS parameter not list.");
lf[536]=C_static_lambda_info(C_heaptop,45,"(string-join strings1307 . delim+grammar1308)");
lf[537]=C_h_intern(&lf[537],17,"register-feature!");
lf[538]=C_h_intern(&lf[538],7,"srfi-13");
lf[539]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf2(lf,540,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1438 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 64   register-feature! */
t3=*((C_word*)lf[537]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[538]);}

/* k1441 in k1438 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word ab[297],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=lf[9],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=lf[14],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1565,a[2]=lf[16],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=lf[19],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=lf[22],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1658,a[2]=lf[24],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1680,a[2]=lf[28],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=lf[33],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[31],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=lf[36],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[39],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1777,a[2]=lf[43],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=lf[48],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=lf[53],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=lf[63],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2080,a[2]=lf[71],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=lf[76],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=lf[81],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=lf[91],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2477,a[2]=lf[99],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2607,a[2]=lf[102],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate(&lf[103],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate(&lf[106],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2719,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate(&lf[109],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2804,a[2]=lf[112],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate(&lf[113],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2877,a[2]=lf[115],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2962,a[2]=lf[121],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=lf[127],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=lf[133],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=lf[139],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[140]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=lf[145],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3112,a[2]=lf[151],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=lf[157],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=lf[163],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate(&lf[164],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3294,a[2]=lf[165],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate(&lf[166],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3356,a[2]=lf[168],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=lf[174],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=lf[180],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3478,a[2]=lf[189],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[190]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3540,a[2]=lf[196],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[197]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3607,a[2]=lf[204],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3658,a[2]=lf[212],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3709,a[2]=lf[219],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=lf[226],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3805,a[2]=lf[234],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3867,a[2]=lf[241],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3934,a[2]=lf[249],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3985,a[2]=lf[257],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=lf[264],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4084,a[2]=lf[271],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate(&lf[272],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4132,a[2]=lf[277],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4204,a[2]=lf[282],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=lf[287],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=lf[292],tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[293]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4324,a[2]=lf[296],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4342,a[2]=lf[301],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4360,a[2]=lf[305],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate(&lf[306],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4378,a[2]=lf[312],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4437,a[2]=lf[316],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4455,a[2]=lf[320],tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4480,a[2]=lf[323],tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4500,a[2]=lf[325],tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=lf[327],tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4550,a[2]=lf[329],tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=lf[335],tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4619,a[2]=lf[341],tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4665,a[2]=lf[346],tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[347]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4715,a[2]=lf[350],tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[351]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4773,a[2]=lf[354],tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[355]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=lf[363],tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4943,a[2]=lf[371],tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5051,a[2]=lf[378],tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5174,a[2]=lf[386],tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5309,a[2]=lf[393],tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5432,a[2]=lf[400],tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[401]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5567,a[2]=lf[408],tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[409]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5702,a[2]=lf[413],tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5743,a[2]=lf[417],tmp=(C_word)a,a+=3,tmp));
t78=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5775,a[2]=lf[420],tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5856,a[2]=lf[427],tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[428]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5918,a[2]=lf[434],tmp=(C_word)a,a+=3,tmp));
t81=C_mutate(&lf[435],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5980,a[2]=lf[438],tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[437]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6078,a[2]=lf[445],tmp=(C_word)a,a+=3,tmp));
t83=C_mutate((C_word*)lf[446]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6213,a[2]=lf[448],tmp=(C_word)a,a+=3,tmp));
t84=C_mutate((C_word*)lf[449]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6251,a[2]=lf[454],tmp=(C_word)a,a+=3,tmp));
t85=C_mutate((C_word*)lf[455]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6372,a[2]=lf[456],tmp=(C_word)a,a+=3,tmp));
t86=C_mutate((C_word*)lf[457]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6375,a[2]=lf[461],tmp=(C_word)a,a+=3,tmp));
t87=C_mutate((C_word*)lf[462]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6430,a[2]=lf[466],tmp=(C_word)a,a+=3,tmp));
t88=C_mutate((C_word*)lf[467]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6485,a[2]=lf[471],tmp=(C_word)a,a+=3,tmp));
t89=C_mutate((C_word*)lf[472]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6531,a[2]=lf[474],tmp=(C_word)a,a+=3,tmp));
t90=C_mutate((C_word*)lf[473]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6537,a[2]=lf[478],tmp=(C_word)a,a+=3,tmp));
t91=C_mutate((C_word*)lf[479]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6639,a[2]=lf[482],tmp=(C_word)a,a+=3,tmp));
t92=C_mutate((C_word*)lf[483]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6712,a[2]=lf[487],tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[488]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6800,a[2]=lf[491],tmp=(C_word)a,a+=3,tmp));
t94=C_mutate(&lf[486],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6929,a[2]=lf[493],tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[494]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6972,a[2]=lf[497],tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[498]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7023,a[2]=lf[503],tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[504]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7105,a[2]=lf[513],tmp=(C_word)a,a+=3,tmp));
t98=C_mutate(&lf[514],*((C_word*)lf[409]+1));
t99=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7243,a[2]=lf[521],tmp=(C_word)a,a+=3,tmp));
t100=C_mutate(&lf[510],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7383,a[2]=lf[523],tmp=(C_word)a,a+=3,tmp));
t101=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7456,a[2]=lf[536],tmp=(C_word)a,a+=3,tmp));
t102=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t102+1)))(2,t102,C_SCHEME_UNDEFINED);}

/* string-join in k1441 in k1438 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_7456r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7456r(t0,t1,t2,t3);}}

static void C_ccall f_7456r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a=C_alloc(18);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[525]:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?lf[526]:(C_word)C_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t7));
if(C_truep((C_word)C_i_nullp(t11))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7476,a[2]=t5,a[3]=lf[528],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t9,lf[526]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[529]));
if(C_truep(t15)){
t16=(C_word)C_i_car(t2);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7538,a[2]=t16,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_i_cdr(t2);
/* srfi-13.scm: 1941 buildit */
t19=t12;
f_7476(t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t9,lf[530]);
if(C_truep(t16)){
/* srfi-13.scm: 1943 buildit */
t17=t12;
f_7476(t17,t13,t2,C_SCHEME_END_OF_LIST);}
else{
t17=(C_word)C_eqp(t9,lf[531]);
if(C_truep(t17)){
t18=(C_word)C_i_car(t2);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7568,a[2]=t18,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t2);
t21=(C_word)C_a_i_list(&a,1,t5);
/* srfi-13.scm: 1946 buildit */
t22=t12;
f_7476(t22,t19,t20,t21);}
else{
/* srfi-13.scm: 1948 ##sys#error */
t18=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t13,lf[524],lf[532],t9,*((C_word*)lf[524]+1));}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t13=(C_word)C_eqp(t9,lf[529]);
if(C_truep(t13)){
/* srfi-13.scm: 1957 ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t1,lf[524],lf[533],*((C_word*)lf[524]+1));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[534]);}}
else{
/* srfi-13.scm: 1952 ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t1,lf[524],lf[535],t2,*((C_word*)lf[524]+1));}}}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}

/* k7566 in string-join in k1441 in k1438 */
static void C_ccall f_7568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7568,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7521(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7536 in string-join in k1441 in k1438 */
static void C_ccall f_7538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7538,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7521(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7519 in string-join in k1441 in k1438 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1937 string-concatenate */
t2=*((C_word*)lf[479]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* buildit in string-join in k1441 in k1438 */
static void C_fcall f_7476(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7476,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7482,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=lf[527],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7482(t7,t1,t2);}

/* recur in buildit in string-join in k1441 in k1438 */
static void C_fcall f_7482(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7482,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(t2);
/* srfi-13.scm: 1933 recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k7502 in recur in buildit in string-join in k1441 in k1438 */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7504,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* %multispan-repcopy! in k1441 in k1438 */
static void C_fcall f_7383(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7383,NULL,8,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_fixnum_difference(t8,t7);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7454,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,a[6]=t9,a[7]=t8,a[8]=t5,a[9]=t6,a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1892 modulo */
t11=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t5,t9);}

/* k7452 in %multispan-repcopy! in k1441 in k1438 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7454,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1896 %string-copy! */
f_5775(t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t2,((C_word*)t0)[7]);}

/* k7394 in k7452 in %multispan-repcopy! in k1441 in k1438 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
t4=(C_word)C_fixnum_divide(t3,((C_word*)t0)[7]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[10],a[3]=t7,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=lf[522],tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_7414(t9,((C_word*)t0)[2],t5,t4);}

/* do1300 in k7394 in k7452 in %multispan-repcopy! in k1441 in k1438 */
static void C_fcall f_7414(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7414,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_fixnum_difference(t2,((C_word*)t0)[9]);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[8],t5);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[7],t6);
/* srfi-13.scm: 1907 %string-copy! */
f_5775(t1,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[7],t7);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7439,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1909 %string-copy! */
f_5775(t5,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[7],((C_word*)t0)[2]);}}

/* k7437 in do1300 in k7394 in k7452 in %multispan-repcopy! in k1441 in k1438 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7414(t4,((C_word*)t0)[2],t2,t3);}

/* string-xcopy! in k1441 in k1438 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr6r,(void*)f_7243r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_7243r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_7243r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t7=(C_word)C_i_check_exact_2(t5,lf[515]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7252,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=lf[518],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7296,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t5,a[6]=lf[520],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1856 ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a7295 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7296,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t2,((C_word*)t0)[5]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[4],t5);
t7=(C_word)C_fixnum_difference(t4,t3);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7309,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[3],a[10]=t7,a[11]=t1,a[12]=t5,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 1870 check-substring-spec */
t9=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,*((C_word*)lf[515]+1),((C_word*)t0)[3],((C_word*)t0)[4],t6);}

/* k7307 in a7295 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7309,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[12],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
/* srfi-13.scm: 1872 ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc12)(void*)(*((C_word*)t4+1)))(12,t4,((C_word*)t0)[11],lf[515],lf[519],*((C_word*)lf[515]+1),((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(C_fix(1),((C_word*)t0)[10]);
if(C_truep(t4)){
t5=(C_word)C_i_string_ref(((C_word*)t0)[7],((C_word*)t0)[4]);
/* srfi-13.scm: 1877 ##srfi13#string-fill! */
t6=lf[514];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,((C_word*)t0)[11],((C_word*)t0)[9],t5,((C_word*)t0)[8],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_fixnum_divide(((C_word*)t0)[6],((C_word*)t0)[10]);
/* srfi-13.scm: 1880 floor */
t7=*((C_word*)lf[511]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}}}

/* k7367 in k7307 in a7295 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_fixnum_divide(((C_word*)t0)[5],((C_word*)t0)[4]);
/* srfi-13.scm: 1880 floor */
t4=*((C_word*)lf[511]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k7371 in k7367 in k7307 in a7295 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7373,2,t0,t1);}
t2=((C_word*)t0)[11];
t3=(C_word)C_eqp(t2,t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7362,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 1882 modulo */
t5=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
/* srfi-13.scm: 1886 %multispan-repcopy! */
f_7383(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[2]);}}

/* k7360 in k7371 in k7367 in k7307 in a7295 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7362,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7358,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1883 modulo */
t4=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7356 in k7360 in k7371 in k7367 in k7307 in a7295 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
/* srfi-13.scm: 1881 %string-copy! */
f_5775(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a7251 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7252,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[516],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7274,a[2]=((C_word*)t0)[4],a[3]=lf[517],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1858 ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1865 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a7273 in a7251 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7274,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[515]);
/* srfi-13.scm: 1863 values */
C_values(5,0,t1,t4,t2,t3);}

/* a7263 in a7251 in string-xcopy! in k1441 in k1438 */
static void C_ccall f_7264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7264,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* srfi-13.scm: 1858 string-parse-final-start+end */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[515]+1),((C_word*)t0)[2],t2);}

/* xsubstring in k1441 in k1438 */
static void C_ccall f_7105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_7105r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7105r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7105r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t5=(C_word)C_i_check_exact_2(t3,lf[504]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7114,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[507],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7158,a[2]=t2,a[3]=t3,a[4]=lf[512],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1810 ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a7157 in xsubstring in k1441 in k1438 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7158,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(C_word)C_fixnum_difference(t2,((C_word*)t0)[3]);
t7=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[508]);}
else{
t8=(C_word)C_eqp(t5,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1826 ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc10)(void*)(*((C_word*)t9+1)))(10,t9,t1,lf[504],lf[509],*((C_word*)lf[504]+1),((C_word*)t0)[2],((C_word*)t0)[3],t2,t3,t4);}
else{
t9=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t9)){
t10=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
/* srfi-13.scm: 1830 make-string */
t11=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,t6,t10);}
else{
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7228,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[2],a[8]=t1,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
t11=(C_word)C_fixnum_divide(((C_word*)t0)[3],t5);
/* srfi-13.scm: 1833 floor */
t12=*((C_word*)lf[511]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}}}

/* k7226 in a7157 in xsubstring in k1441 in k1438 */
static void C_ccall f_7228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_divide(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 1833 floor */
t4=*((C_word*)lf[511]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k7230 in k7226 in a7157 in xsubstring in k1441 in k1438 */
static void C_ccall f_7232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7232,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(C_word)C_eqp(t2,t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7218,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1834 modulo */
t5=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1838 make-string */
t5=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k7219 in k7230 in k7226 in a7157 in xsubstring in k1441 in k1438 */
static void C_ccall f_7221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7224,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1839 %multispan-repcopy! */
f_7383(t2,t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7222 in k7219 in k7230 in k7226 in a7157 in xsubstring in k1441 in k1438 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7216 in k7230 in k7226 in a7157 in xsubstring in k1441 in k1438 */
static void C_ccall f_7218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7218,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7214,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1835 modulo */
t4=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7212 in k7216 in k7230 in k7226 in a7157 in xsubstring in k1441 in k1438 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* srfi-13.scm: 1834 ##sys#substring */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a7113 in xsubstring in k1441 in k1438 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7114,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[505],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7136,a[2]=((C_word*)t0)[4],a[3]=lf[506],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1812 ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1822 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a7135 in a7113 in xsubstring in k1441 in k1438 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7136,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[504]);
/* srfi-13.scm: 1819 values */
C_values(5,0,t1,t4,t2,t3);}

/* a7125 in a7113 in xsubstring in k1441 in k1438 */
static void C_ccall f_7126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7126,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* srfi-13.scm: 1812 string-parse-final-start+end */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[504]+1),((C_word*)t0)[2],t2);}

/* string-tokenize in k1441 in k1438 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_7023r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7023r(t0,t1,t2,t3);}}

static void C_ccall f_7023r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[499]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7035,a[2]=t7,a[3]=t2,a[4]=lf[500],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7041,a[2]=t5,a[3]=t2,a[4]=lf[502],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a7040 in string-tokenize in k1441 in k1438 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7041,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=lf[501],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7047(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in a7040 in string-tokenize in k1441 in k1438 */
static void C_fcall f_7047(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7047,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[3];
t6=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,t6))){
/* srfi-13.scm: 1767 string-index-right */
t7=*((C_word*)lf[379]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
t7=t4;
f_7051(2,t7,C_SCHEME_FALSE);}}

/* k7049 in lp in a7040 in string-tokenize in k1441 in k1438 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7051,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7060,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1770 string-skip-right */
t4=*((C_word*)lf[339]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}}

/* k7058 in k7049 in lp in a7040 in string-tokenize in k1441 in k1438 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7060,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7074,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1773 ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[4],t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7085,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1775 ##sys#substring */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7083 in k7058 in k7049 in lp in a7040 in string-tokenize in k1441 in k1438 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7085,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7072 in k7058 in k7049 in lp in a7040 in string-tokenize in k1441 in k1438 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7074,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* srfi-13.scm: 1772 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7047(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a7034 in string-tokenize in k1441 in k1438 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7035,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[498]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-replace in k1441 in k1438 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr6r,(void*)f_6972r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_6972r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_6972r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6976,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t2,a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1744 check-substring-spec */
t8=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,*((C_word*)lf[494]+1),t2,t4,t5);}

/* k6974 in string-replace in k1441 in k1438 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6981,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=lf[495],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6987,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[496],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1745 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6986 in k6974 in string-replace in k1441 in k1438 */
static void C_ccall f_6987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6987,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[5]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[4],((C_word*)t0)[3]);
t7=(C_word)C_fixnum_difference(t4,t6);
t8=(C_word)C_fixnum_plus(t7,t5);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7000,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[3],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1749 make-string */
t10=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}

/* k6998 in a6986 in k6974 in string-replace in k1441 in k1438 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 1750 %string-copy! */
f_5775(t2,t1,C_fix(0),((C_word*)t0)[7],C_fix(0),((C_word*)t0)[9]);}

/* k7001 in k6998 in a6986 in k6974 in string-replace in k1441 in k1438 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7006,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 1751 %string-copy! */
f_5775(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7004 in k7001 in k6998 in a6986 in k6974 in string-replace in k1441 in k1438 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7009,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 1752 %string-copy! */
f_5775(t2,((C_word*)t0)[7],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7007 in k7004 in k7001 in k6998 in a6986 in k6974 in string-replace in k1441 in k1438 */
static void C_ccall f_7009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6980 in k6974 in string-replace in k1441 in k1438 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6981,2,t0,t1);}
/* srfi-13.scm: 1745 string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[494]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %finish-string-concatenate-reverse in k1441 in k1438 */
static void C_fcall f_6929(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6929,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6933,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_fixnum_plus(t5,t2);
/* srfi-13.scm: 1724 make-string */
t8=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k6931 in %finish-string-concatenate-reverse in k1441 in k1438 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6936,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1725 %string-copy! */
f_5775(t2,t1,((C_word*)t0)[5],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k6934 in k6931 in %finish-string-concatenate-reverse in k1441 in k1438 */
static void C_ccall f_6936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6939,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6941,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=lf[492],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6941(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k6934 in k6931 in %finish-string-concatenate-reverse in k1441 in k1438 */
static void C_fcall f_6941(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6941,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_string_length(t4);
t7=(C_word)C_fixnum_difference(t2,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6963,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1732 %string-copy! */
f_5775(t8,((C_word*)t0)[2],t7,t4,C_fix(0),t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k6961 in lp in k6934 in k6931 in %finish-string-concatenate-reverse in k1441 in k1438 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1733 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6941(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6937 in k6934 in k6931 in %finish-string-concatenate-reverse in k1441 in k1438 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-concatenate-reverse/shared in k1441 in k1438 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6800r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6800r(t0,t1,t2,t3);}}

static void C_ccall f_6800r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[489]:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_i_string_length(t5):(C_word)C_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t7));
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_check_exact_2(t9,lf[488]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6827,a[2]=t9,a[3]=t5,a[4]=t14,a[5]=lf[490],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_6827(t16,t1,C_fix(0),C_SCHEME_FALSE,t2);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}

/* lp in string-concatenate-reverse/shared in k1441 in k1438 */
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6827,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(t4);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_fixnum_plus(t2,t6);
t8=t3;
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,C_fix(0)));
t10=(C_truep(t9)?t3:t4);
t11=(C_word)C_i_cdr(t4);
/* srfi-13.scm: 1710 lp */
t19=t1;
t20=t7;
t21=t10;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
/* srfi-13.scm: 1714 substring/shared */
t6=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_string_length(t8);
t10=t2;
t11=t6;
f_6877(t11,(C_word)C_eqp(t10,t9));}
else{
t8=t6;
f_6877(t8,C_SCHEME_FALSE);}}}}

/* k6875 in lp in string-concatenate-reverse/shared in k1441 in k1438 */
static void C_fcall f_6877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(((C_word*)t0)[5]));}
else{
/* srfi-13.scm: 1721 %finish-string-concatenate-reverse */
f_6929(((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* string-concatenate-reverse in k1441 in k1438 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_6712r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6712r(t0,t1,t2,t3);}}

static void C_ccall f_6712r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(3);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[484]:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_i_string_length(t5):(C_word)C_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t7));
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_check_exact_2(t9,lf[483]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6742,a[2]=lf[485],tmp=(C_word)a,a+=3,tmp);
t14=f_6742(C_fix(0),t2);
/* srfi-13.scm: 1695 %finish-string-concatenate-reverse */
f_6929(t1,t14,t2,t5,t9);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}

/* lp in string-concatenate-reverse in k1441 in k1438 */
static C_word C_fcall f_6742(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_fixnum_plus(t1,t4);
t6=(C_word)C_i_cdr(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t1);}}

/* string-concatenate in k1441 in k1438 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6639,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6680,a[2]=lf[480],tmp=(C_word)a,a+=3,tmp);
t4=f_6680(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6646,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1662 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k6644 in string-concatenate in k1441 in k1438 */
static void C_ccall f_6646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6649,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6651,a[2]=t1,a[3]=t4,a[4]=lf[481],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6651(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* lp in k6644 in string-concatenate in k1441 in k1438 */
static void C_fcall f_6651(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6651,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6667,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1667 %string-copy! */
f_5775(t6,((C_word*)t0)[2],t2,t4,C_fix(0),t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k6665 in lp in k6644 in string-concatenate in k1441 in k1438 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-13.scm: 1668 lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6651(t4,((C_word*)t0)[2],t2,t3);}

/* k6647 in k6644 in string-concatenate in k1441 in k1438 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* do1150 in string-concatenate in k1441 in k1438 */
static C_word C_fcall f_6680(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_car(t1);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_fixnum_plus(t2,t5);
t8=t3;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(t2);}}

/* string-concatenate/shared in k1441 in k1438 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6537,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6543,a[2]=t4,a[3]=lf[477],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6543(t6,t1,t2,C_fix(0),C_SCHEME_FALSE);}

/* lp in string-concatenate/shared in k1441 in k1438 */
static void C_fcall f_6543(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6543,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_string_length(t5);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1635 lp */
t19=t1;
t20=t6;
t21=t3;
t22=t4;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t9=(C_word)C_fixnum_plus(t3,t7);
t10=t4;
t11=(C_truep(t10)?t10:t2);
/* srfi-13.scm: 1636 lp */
t19=t1;
t20=t6;
t21=t9;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}}
else{
t5=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[475]);}
else{
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_string_length(t6);
t8=t3;
t9=(C_word)C_eqp(t8,t7);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_car(t4));}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6597,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1643 make-string */
t11=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t3);}}}}

/* k6595 in lp in string-concatenate/shared in k1441 in k1438 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6600,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6602,a[2]=t1,a[3]=t4,a[4]=lf[476],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6602(t6,t2,((C_word*)t0)[2],C_fix(0));}

/* lp in k6595 in lp in string-concatenate/shared in k1441 in k1438 */
static void C_fcall f_6602(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6602,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6618,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1648 %string-copy! */
f_5775(t6,((C_word*)t0)[2],t3,t4,C_fix(0),t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k6616 in lp in k6595 in lp in string-concatenate/shared in k1441 in k1438 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* srfi-13.scm: 1649 lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6602(t4,((C_word*)t0)[2],t2,t3);}

/* k6598 in k6595 in lp in string-concatenate/shared in k1441 in k1438 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-append/shared in k1441 in k1438 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_6531r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6531r(t0,t1,t2);}}

static void C_ccall f_6531r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-13.scm: 1626 string-concatenate/shared */
t3=*((C_word*)lf[473]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* string->list in k1441 in k1438 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_6485r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6485r(t0,t1,t2,t3);}}

static void C_ccall f_6485r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6491,a[2]=t3,a[3]=t2,a[4]=lf[468],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6497,a[2]=t2,a[3]=lf[470],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a6496 in string->list in k1441 in k1438 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6497,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6507,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[469],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6507(t8,t1,t4,C_SCHEME_END_OF_LIST);}

/* do1122 in a6496 in string->list in k1441 in k1438 */
static void C_fcall f_6507(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6507,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t10=t1;
t11=t6;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* a6490 in string->list in k1441 in k1438 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[467]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse! in k1441 in k1438 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_6430r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6430r(t0,t1,t2,t3);}}

static void C_ccall f_6430r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6436,a[2]=t3,a[3]=t2,a[4]=lf[463],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6442,a[2]=t2,a[3]=lf[465],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a6441 in string-reverse! in k1441 in k1438 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6442,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[2],a[3]=lf[464],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6452(t5,t4,t2));}

/* do1110 in a6441 in string-reverse! in k1441 in k1438 */
static C_word C_fcall f_6452(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
C_stack_check;
t3=t1;
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t1);
t6=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t7=(C_word)C_i_string_set(((C_word*)t0)[2],t1,t6);
t8=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t5);
t9=(C_word)C_fixnum_difference(t1,C_fix(1));
t10=(C_word)C_fixnum_plus(t2,C_fix(1));
t12=t9;
t13=t10;
t1=t12;
t2=t13;
goto loop;}}

/* a6435 in string-reverse! in k1441 in k1438 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6436,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[462]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse in k1441 in k1438 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_6375r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6375r(t0,t1,t2,t3);}}

static void C_ccall f_6375r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6381,a[2]=t3,a[3]=t2,a[4]=lf[458],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6387,a[2]=t2,a[3]=lf[460],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a6386 in string-reverse in k1441 in k1438 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6387,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6394,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1568 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k6392 in a6386 in string-reverse in k1441 in k1438 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6403,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=lf[459],tmp=(C_word)a,a+=5,tmp);
t4=f_6403(t3,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* do1099 in k6392 in a6386 in string-reverse in k1441 in k1438 */
static C_word C_fcall f_6403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t4);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=(C_word)C_fixnum_difference(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* a6380 in string-reverse in k1441 in k1438 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[457]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-null? in k1441 in k1438 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6372,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_null_p(t2));}

/* string-kmp-partial-search in k1441 in k1438 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr6r,(void*)f_6251r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_6251r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_6251r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(14);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?*((C_word*)lf[439]+1):(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?C_fix(0):(C_word)C_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t10));
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6269,a[2]=t14,a[3]=t4,a[4]=lf[450],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6275,a[2]=t5,a[3]=t8,a[4]=t2,a[5]=t12,a[6]=t4,a[7]=t3,a[8]=lf[453],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t15,t16);}

/* a6274 in string-kmp-partial-search in k1441 in k1438 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6275,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_vector_length(((C_word*)t0)[7]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6284,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,a[10]=lf[452],tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_6284(t9,t1,t3,((C_word*)t0)[2]);}

/* lp in a6274 in string-kmp-partial-search in k1441 in k1438 */
static void C_fcall f_6284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6284,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_eqp(t4,((C_word*)t0)[9]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_negate(t2));}
else{
t6=t2;
t7=((C_word*)t0)[8];
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}
else{
t9=(C_word)C_i_string_ref(((C_word*)t0)[7],t2);
t10=(C_word)C_fixnum_plus(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6314,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6316,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t13,a[7]=((C_word*)t0)[5],a[8]=lf[451],tmp=(C_word)a,a+=9,tmp));
t15=((C_word*)t13)[1];
f_6316(t15,t11,t3);}}}

/* lp2 in lp in a6274 in string-kmp-partial-search in k1441 in k1438 */
static void C_fcall f_6316(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6316,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6323,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_i_string_ref(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1548 c= */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k6321 in lp2 in lp in a6274 in string-kmp-partial-search in k1441 in k1438 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1552 lp2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6316(t4,((C_word*)t0)[5],t2);}}}

/* k6312 in lp in a6274 in string-kmp-partial-search in k1441 in k1438 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1546 lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6284(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6268 in string-kmp-partial-search in k1441 in k1438 */
static void C_ccall f_6269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6269,2,t0,t1);}
/* srfi-13.scm: 1537 string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[449]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* kmp-step in k1441 in k1438 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_6213,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6219,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t3,a[8]=lf[447],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_6219(t11,t1,t5);}

/* lp in kmp-step in k1441 in k1438 */
static void C_fcall f_6219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6219,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6226,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_i_string_ref(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1515 c= */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k6224 in lp in kmp-step in k1441 in k1438 */
static void C_ccall f_6226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1519 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6219(t4,((C_word*)t0)[5],t2);}}}

/* make-kmp-restart-vector in k1441 in k1438 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_6078r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6078r(t0,t1,t2,t3);}}

static void C_ccall f_6078r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[439]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6090,a[2]=t7,a[3]=t2,a[4]=lf[440],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6096,a[2]=t5,a[3]=t2,a[4]=lf[444],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a6095 in make-kmp-restart-vector in k1441 in k1438 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6096,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1469 make-vector */
t7=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,C_fix(-1));}

/* k6101 in a6095 in make-kmp-restart-vector in k1441 in k1438 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[5],C_fix(0)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6120,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=lf[442],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_6120(t8,t2,C_fix(0),C_fix(-1),((C_word*)t0)[3]);}
else{
t3=t2;
f_6106(2,t3,C_SCHEME_UNDEFINED);}}

/* lp1 in k6101 in a6095 in make-kmp-restart-vector in k1441 in k1438 */
static void C_fcall f_6120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6120,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[8]))){
t6=(C_word)C_i_string_ref(((C_word*)t0)[7],t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=((C_word*)t0)[6],a[11]=t2,a[12]=lf[441],tmp=(C_word)a,a+=13,tmp));
t10=((C_word*)t8)[1];
f_6135(t10,t1,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* lp2 in lp1 in k6101 in a6095 in make-kmp-restart-vector in k1441 in k1438 */
static void C_fcall f_6135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6135,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t4)){
t5=(C_word)C_fixnum_plus(((C_word*)t0)[11],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6162,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t5,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1487 c= */
t7=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6168,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t2,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_fixnum_plus(t2,((C_word*)t0)[3]);
t7=(C_word)C_i_string_ref(((C_word*)t0)[2],t6);
/* srfi-13.scm: 1491 c= */
t8=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,((C_word*)t0)[6],t7);}}

/* k6166 in lp2 in lp1 in k6101 in a6095 in make-kmp-restart-vector in k1441 in k1438 */
static void C_ccall f_6168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t3=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[7]);
t4=(C_word)C_i_vector_set(((C_word*)t0)[6],t2,t3);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-13.scm: 1495 lp1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6120(t6,((C_word*)t0)[3],t2,t3,t5);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[6],((C_word*)t0)[7]);
/* srfi-13.scm: 1497 lp2 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6135(t3,((C_word*)t0)[3],t2);}}

/* k6160 in lp2 in lp1 in k6101 in a6095 in make-kmp-restart-vector in k1441 in k1438 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_truep(t1)?C_fix(-1):C_fix(0));
t3=(C_word)C_i_vector_set(((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1488 lp1 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6120(t5,((C_word*)t0)[2],((C_word*)t0)[5],C_fix(0),t4);}

/* k6104 in k6101 in a6095 in make-kmp-restart-vector in k1441 in k1438 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6089 in make-kmp-restart-vector in k1441 in k1438 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6090,2,t0,t1);}
/* srfi-13.scm: 1467 string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[437]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %kmp-search in k1441 in k1438 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5980,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_fixnum_difference(t6,t5);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5987,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t5,a[6]=t3,a[7]=t9,a[8]=t7,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 1416 make-kmp-restart-vector */
t11=*((C_word*)lf[437]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,t2,t4,t5,t6);}

/* k5985 in %kmp-search in k1441 in k1438 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=lf[436],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_5996(t6,((C_word*)t0)[2],((C_word*)t0)[8],C_fix(0),t2,((C_word*)t0)[7]);}

/* lp in k5985 in %kmp-search in k1441 in k1438 */
static void C_fcall f_5996(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5996,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_eqp(t6,((C_word*)t0)[8]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_difference(t2,((C_word*)t0)[8]));}
else{
t8=t5;
t9=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6018,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t11=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
t12=(C_word)C_fixnum_plus(((C_word*)t0)[4],t3);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
/* srfi-13.scm: 1427 c= */
t14=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t14))(4,t14,t10,t11,t13);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}

/* k6016 in lp in k5985 in %kmp-search in k1441 in k1438 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[9]);
t3=(C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* srfi-13.scm: 1429 lp */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5996(t6,((C_word*)t0)[4],t2,t3,t4,t5);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[7],C_fix(1));
/* srfi-13.scm: 1433 lp */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5996(t6,((C_word*)t0)[4],t4,C_fix(0),t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1434 lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5996(t5,((C_word*)t0)[4],((C_word*)t0)[9],t2,((C_word*)t0)[7],t4);}}}

/* string-contains-ci in k1441 in k1438 */
static void C_ccall f_5918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_5918r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5918r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5918r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[421]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5924,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[429],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5930,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[433],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a5929 in string-contains-ci in k1441 in k1438 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5930,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5936,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[430],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5942,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[432],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5941 in a5929 in string-contains-ci in k1441 in k1438 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5942,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5954,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,a[9]=lf[431],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5954(t9,t1,((C_word*)t0)[2]);}

/* lp in a5941 in a5929 in string-contains-ci in k1441 in k1438 */
static void C_fcall f_5954(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5954,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1386 string-ci= */
t5=*((C_word*)lf[227]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5965 in lp in a5941 in a5929 in string-contains-ci in k1441 in k1438 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1388 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5954(t3,((C_word*)t0)[4],t2);}}

/* a5935 in a5929 in string-contains-ci in k1441 in k1438 */
static void C_ccall f_5936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5936,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5923 in string-contains-ci in k1441 in k1438 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5924,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-contains in k1441 in k1438 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_5856r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5856r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5856r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[421]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5862,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[422],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5868,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[426],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a5867 in string-contains in k1441 in k1438 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5868,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5874,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[423],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5880,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[425],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5879 in a5867 in string-contains in k1441 in k1438 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5880,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5892,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,a[9]=lf[424],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5892(t9,t1,((C_word*)t0)[2]);}

/* lp in a5879 in a5867 in string-contains in k1441 in k1438 */
static void C_fcall f_5892(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5892,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5905,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1375 string= */
t5=*((C_word*)lf[181]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5903 in lp in a5879 in a5867 in string-contains in k1441 in k1438 */
static void C_ccall f_5905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1377 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5892(t3,((C_word*)t0)[4],t2);}}

/* a5873 in a5867 in string-contains in k1441 in k1438 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5874,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5861 in string-contains in k1441 in k1438 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-copy! in k1441 in k1438 */
static void C_fcall f_5775(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5775,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=t5;
t8=t3;
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5787,a[2]=t2,a[3]=t4,a[4]=t6,a[5]=lf[418],tmp=(C_word)a,a+=6,tmp);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,f_5787(t9,t5,t3));}
else{
t9=(C_word)C_fixnum_difference(t6,C_fix(1));
t10=(C_word)C_fixnum_difference(t6,t5);
t11=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(-1),t3),t10);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5825,a[2]=t2,a[3]=t4,a[4]=t5,a[5]=lf[419],tmp=(C_word)a,a+=6,tmp);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,f_5825(t12,t9,t11));}}

/* do971 in %string-copy! in k1441 in k1438 */
static C_word C_fcall f_5825(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t6=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t5);
t7=(C_word)C_fixnum_difference(t1,C_fix(1));
t8=(C_word)C_fixnum_difference(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* do965 in %string-copy! in k1441 in k1438 */
static C_word C_fcall f_5787(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
return(C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t6=(C_word)C_i_string_set(((C_word*)t0)[2],t2,t5);
t7=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* string-copy! in k1441 in k1438 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr5r,(void*)f_5743r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5743r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5749,a[2]=t5,a[3]=t4,a[4]=lf[415],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5755,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=lf[416],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a5754 in string-copy! in k1441 in k1438 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5755,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[414]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5762,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_fixnum_difference(t3,t2);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[4],t6);
/* srfi-13.scm: 1344 check-substring-spec */
t8=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,*((C_word*)lf[414]+1),((C_word*)t0)[3],((C_word*)t0)[4],t7);}

/* k5760 in a5754 in string-copy! in k1441 in k1438 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1345 %string-copy! */
f_5775(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5748 in string-copy! in k1441 in k1438 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5749,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[414]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fill! in k1441 in k1438 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5702r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5702r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5702r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5708,a[2]=t4,a[3]=t2,a[4]=lf[410],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5714,a[2]=t3,a[3]=t2,a[4]=lf[412],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5713 in string-fill! in k1441 in k1438 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5714,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=lf[411],tmp=(C_word)a,a+=6,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5724(t5,t4));}

/* do947 in a5713 in string-fill! in k1441 in k1438 */
static C_word C_fcall f_5724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
return(C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_string_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t5=(C_word)C_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}

/* a5707 in string-fill! in k1441 in k1438 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5708,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[409]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-count in k1441 in k1438 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5567r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5567r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5567r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5573,a[2]=t4,a[3]=t2,a[4]=lf[402],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5579,a[2]=t2,a[3]=t3,a[4]=lf[407],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5578 in string-count in k1441 in k1438 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5579,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[403],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5591(t4,t2,C_fix(0)));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5625,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1310 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5623 in a5578 in string-count in k1441 in k1438 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[404],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5630(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5669,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[405],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5669(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
/* srfi-13.scm: 1322 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[401],lf[406],*((C_word*)lf[401]+1),((C_word*)t0)[4]);}}}

/* do937 in k5623 in a5578 in string-count in k1441 in k1438 */
static void C_fcall f_5669(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5669,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5690,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1319 criteria */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}}

/* k5688 in do937 in k5623 in a5578 in string-count in k1441 in k1438 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_5669(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* do932 in k5623 in a5578 in string-count in k1441 in k1438 */
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5630,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5651,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1312 char-set-contains? */
t9=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k5649 in do932 in k5623 in a5578 in string-count in k1441 in k1438 */
static void C_ccall f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_5630(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* do927 in a5578 in string-count in k1441 in k1438 */
static C_word C_fcall f_5591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
return(t2);}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
t8=(C_truep(t7)?(C_word)C_fixnum_plus(t2,C_fix(1)):t2);
t10=t5;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* a5572 in string-count in k1441 in k1438 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5573,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[401]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip-right in k1441 in k1438 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5432r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5432r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5432r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5438,a[2]=t4,a[3]=t2,a[4]=lf[394],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5444,a[2]=t2,a[3]=t3,a[4]=lf[399],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5443 in string-skip-right in k1441 in k1438 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5444,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=lf[395],tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5460(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5490,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1284 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5488 in a5443 in string-skip-right in k1441 in k1438 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[396],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5499(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[397],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5538(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1295 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[339],lf[398],*((C_word*)lf[339]+1),((C_word*)t0)[3]);}}}

/* lp in k5488 in a5443 in string-skip-right in k1441 in k1438 */
static void C_fcall f_5538(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5538,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5551,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1293 criteria */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5549 in lp in k5488 in a5443 in string-skip-right in k1441 in k1438 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1293 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5538(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k5488 in a5443 in string-skip-right in k1441 in k1438 */
static void C_fcall f_5499(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5499,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5512,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1287 char-set-contains? */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5510 in lp in k5488 in a5443 in string-skip-right in k1441 in k1438 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1288 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5499(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a5443 in string-skip-right in k1441 in k1438 */
static C_word C_fcall f_5460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=(C_word)C_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a5437 in string-skip-right in k1441 in k1438 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[339]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip in k1441 in k1438 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5309r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5309r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5309r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5315,a[2]=t4,a[3]=t2,a[4]=lf[387],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5321,a[2]=t2,a[3]=t3,a[4]=lf[392],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5320 in string-skip in k1441 in k1438 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5321,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[388],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5333(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5363,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1262 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5361 in a5320 in string-skip in k1441 in k1438 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5363,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[389],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5368(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[390],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5403(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1273 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[308],lf[391],*((C_word*)lf[308]+1),((C_word*)t0)[4]);}}}

/* lp in k5361 in a5320 in string-skip in k1441 in k1438 */
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5403,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5416,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1271 criteria */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5414 in lp in k5361 in a5320 in string-skip in k1441 in k1438 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1271 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5403(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k5361 in a5320 in string-skip in k1441 in k1438 */
static void C_fcall f_5368(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5368,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5381,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1265 char-set-contains? */
t7=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5379 in lp in k5361 in a5320 in string-skip in k1441 in k1438 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1266 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5368(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a5320 in string-skip in k1441 in k1438 */
static C_word C_fcall f_5333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a5314 in string-skip in k1441 in k1438 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5315,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[308]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index-right in k1441 in k1438 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5174r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5174r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5174r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5180,a[2]=t4,a[3]=t2,a[4]=lf[380],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5186,a[2]=t2,a[3]=t3,a[4]=lf[385],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5185 in string-index-right in k1441 in k1438 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5186,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=lf[381],tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5202(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5232,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1241 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5230 in a5185 in string-index-right in k1441 in k1438 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5232,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[382],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5241(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=lf[383],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5280(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1251 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[379],lf[384],*((C_word*)lf[379]+1),((C_word*)t0)[3]);}}}

/* lp in k5230 in a5185 in string-index-right in k1441 in k1438 */
static void C_fcall f_5280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5280,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1249 criteria */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5291 in lp in k5230 in a5185 in string-index-right in k1441 in k1438 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1250 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5280(t3,((C_word*)t0)[4],t2);}}

/* lp in k5230 in a5185 in string-index-right in k1441 in k1438 */
static void C_fcall f_5241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5241,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1244 char-set-contains? */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5252 in lp in k5230 in a5185 in string-index-right in k1441 in k1438 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1245 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5241(t3,((C_word*)t0)[4],t2);}}

/* lp in a5185 in string-index-right in k1441 in k1438 */
static C_word C_fcall f_5202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a5179 in string-index-right in k1441 in k1438 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[379]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index in k1441 in k1438 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5051r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5051r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5057,a[2]=t4,a[3]=t2,a[4]=lf[372],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5063,a[2]=t2,a[3]=t3,a[4]=lf[377],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a5062 in string-index in k1441 in k1438 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5063,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[373],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5075(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5105,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1221 char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k5103 in a5062 in string-index in k1441 in k1438 */
static void C_ccall f_5105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5105,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5110,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[374],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5110(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5145,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[375],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5145(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1231 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[310],lf[376],*((C_word*)lf[310]+1),((C_word*)t0)[4]);}}}

/* lp in k5103 in a5062 in string-index in k1441 in k1438 */
static void C_fcall f_5145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5145,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1229 criteria */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5156 in lp in k5103 in a5062 in string-index in k1441 in k1438 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1230 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5145(t3,((C_word*)t0)[4],t2);}}

/* lp in k5103 in a5062 in string-index in k1441 in k1438 */
static void C_fcall f_5110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5110,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5123,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1224 char-set-contains? */
t7=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k5121 in lp in k5103 in a5062 in string-index in k1441 in k1438 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1225 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5110(t3,((C_word*)t0)[4],t2);}}

/* lp in a5062 in string-index in k1441 in k1438 */
static C_word C_fcall f_5075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t1);}
else{
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a5056 in string-index in k1441 in k1438 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5057,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[310]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-filter in k1441 in k1438 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4943r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4943r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4943r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4949,a[2]=t4,a[3]=t3,a[4]=lf[365],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4955,a[2]=t3,a[3]=t2,a[4]=lf[370],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4955,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4968,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1177 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4998,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1186 char-set? */
t6=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k5035 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4998(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1187 char-set */
t2=*((C_word*)lf[360]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1188 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[364],lf[369],((C_word*)t0)[2]);}}}

/* k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5024,a[2]=t1,a[3]=lf[368],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1190 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5023 in k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5024,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5031,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1190 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k5029 in a5023 in k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)):((C_word*)t0)[2]));}

/* k4999 in k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1194 make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k5002 in k4999 in k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5007,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[367],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1195 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5008 in k5002 in k4999 in k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5009,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5016,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1195 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k5014 in a5008 in k5002 in k4999 in k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k5005 in k5002 in k4999 in k4996 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4966 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4971,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[366],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1178 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4981 in k4966 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4982,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4989,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1179 criteria */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4987 in a4981 in k4966 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k4969 in k4966 in a4954 in string-filter in k1441 in k1438 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1184 ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a4948 in string-filter in k1441 in k1438 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[364]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-delete in k1441 in k1438 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4835r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4835r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4835r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4841,a[2]=t4,a[3]=t3,a[4]=lf[356],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4847,a[2]=t3,a[3]=t2,a[4]=lf[362],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4847,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4860,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1150 make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4890,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1158 char-set? */
t6=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k4927 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4890(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1159 char-set */
t2=*((C_word*)lf[360]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1160 ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[355],lf[361],((C_word*)t0)[2]);}}}

/* k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4916,a[2]=t1,a[3]=lf[359],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1161 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4915 in k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4916,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4923,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1161 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4921 in a4915 in k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1))));}

/* k4891 in k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1165 make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4894 in k4891 in k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4899,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[358],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1166 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4900 in k4894 in k4891 in k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4901,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4908,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1166 char-set-contains? */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k4906 in a4900 in k4894 in k4891 in k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k4897 in k4894 in k4891 in k4888 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4858 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4863,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=lf[357],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1151 string-fold */
t4=*((C_word*)lf[44]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4873 in k4858 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4874,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4881,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1152 criteria */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4879 in a4873 in k4858 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}}

/* k4861 in k4858 in a4846 in string-delete in k1441 in k1438 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1156 ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a4840 in string-delete in k1441 in k1438 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad in k1441 in k1438 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_4773r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4773r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4773r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(C_word)C_i_check_exact_2(t3,lf[351]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4788,a[2]=t9,a[3]=t2,a[4]=lf[352],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4794,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=lf[353],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t10,t11);}

/* a4793 in string-pad in k1441 in k1438 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4794,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_fixnum_difference(t3,((C_word*)t0)[4]);
/* srfi-13.scm: 1125 %substring/shared */
f_1658(t1,((C_word*)t0)[3],t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4814,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1126 make-string */
t7=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4812 in a4793 in string-pad in k1441 in k1438 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4817,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 1127 %string-copy! */
f_5775(t2,t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4815 in k4812 in a4793 in string-pad in k1441 in k1438 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4787 in string-pad in k1441 in k1438 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4788,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[351]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad-right in k1441 in k1438 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_4715r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4715r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(C_word)C_i_check_exact_2(t3,lf[347]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4730,a[2]=t9,a[3]=t2,a[4]=lf[348],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4736,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=lf[349],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t10,t11);}

/* a4735 in string-pad-right in k1441 in k1438 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4736,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_fixnum_plus(t2,((C_word*)t0)[4]);
/* srfi-13.scm: 1114 %substring/shared */
f_1658(t1,((C_word*)t0)[3],t2,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4756,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1115 make-string */
t7=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4754 in a4735 in string-pad-right in k1441 in k1438 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4759,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1116 %string-copy! */
f_5775(t2,t1,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4757 in k4754 in a4735 in string-pad-right in k1441 in k1438 */
static void C_ccall f_4759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4729 in string-pad-right in k1441 in k1438 */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4730,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[347]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-both in k1441 in k1438 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4665r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4665r(t0,t1,t2,t3);}}

static void C_ccall f_4665r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[331]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4677,a[2]=t7,a[3]=t2,a[4]=lf[343],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4683,a[2]=t5,a[3]=t2,a[4]=lf[345],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a4682 in string-trim-both in k1441 in k1438 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4683,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4687,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1102 string-skip */
t5=*((C_word*)lf[308]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4685 in a4682 in string-trim-both in k1441 in k1438 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4701,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1104 string-skip-right */
t3=*((C_word*)lf[339]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[344]);}}

/* k4699 in k4685 in a4682 in string-trim-both in k1441 in k1438 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1104 %substring/shared */
f_1658(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4676 in string-trim-both in k1441 in k1438 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[342]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-right in k1441 in k1438 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4619r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4619r(t0,t1,t2,t3);}}

static void C_ccall f_4619r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[331]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4631,a[2]=t7,a[3]=t2,a[4]=lf[337],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4637,a[2]=t5,a[3]=t2,a[4]=lf[340],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a4636 in string-trim-right in k1441 in k1438 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4637,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1095 string-skip-right */
t5=*((C_word*)lf[339]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4639 in a4636 in string-trim-right in k1441 in k1438 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1096 %substring/shared */
f_1658(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[338]);}}

/* a4630 in string-trim-right in k1441 in k1438 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim in k1441 in k1438 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4577r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4577r(t0,t1,t2,t3);}}

static void C_ccall f_4577r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[331]+1):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4589,a[2]=t7,a[3]=t2,a[4]=lf[332],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4595,a[2]=t5,a[3]=t2,a[4]=lf[334],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}

/* a4594 in string-trim in k1441 in k1438 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4595,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4599,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1088 string-skip */
t5=*((C_word*)lf[308]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k4597 in a4594 in string-trim in k1441 in k1438 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 1089 %substring/shared */
f_1658(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[333]);}}

/* a4588 in string-trim in k1441 in k1438 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-drop-right in k1441 in k1438 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4550,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[328]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4557,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1078 ##sys#check-range */
t8=*((C_word*)lf[322]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t3,C_fix(0),t7,lf[328]);}

/* k4555 in string-drop-right in k1441 in k1438 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1082 %substring/shared */
f_1658(((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t3);}

/* string-drop in k1441 in k1438 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4527,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[326]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4534,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1069 ##sys#check-range */
t8=*((C_word*)lf[322]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t3,C_fix(0),t7,lf[326]);}

/* k4532 in string-drop in k1441 in k1438 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-13.scm: 1073 %substring/shared */
f_1658(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* string-take-right in k1441 in k1438 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4500,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[324]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4507,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1060 ##sys#check-range */
t8=*((C_word*)lf[322]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t3,C_fix(0),t7,lf[324]);}

/* k4505 in string-take-right in k1441 in k1438 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1064 %substring/shared */
f_1658(((C_word*)t0)[2],((C_word*)t0)[4],t3,t2);}

/* string-take in k1441 in k1438 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4480,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[321]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4487,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1054 ##sys#check-range */
t8=*((C_word*)lf[322]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t3,C_fix(0),t7,lf[321]);}

/* k4485 in string-take in k1441 in k1438 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1055 %substring/shared */
f_1658(((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* string-titlecase in k1441 in k1438 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4455r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4455r(t0,t1,t2,t3);}}

static void C_ccall f_4455r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4461,a[2]=t3,a[3]=t2,a[4]=lf[318],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4467,a[2]=t2,a[3]=lf[319],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4466 in string-titlecase in k1441 in k1438 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4467,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4471,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1025 ##sys#substring */
t5=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t2,t3);}

/* k4469 in a4466 in string-titlecase in k1441 in k1438 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4474,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-13.scm: 1026 %string-titlecase! */
f_4378(t2,t1,C_fix(0),t3);}

/* k4472 in k4469 in a4466 in string-titlecase in k1441 in k1438 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4460 in string-titlecase in k1441 in k1438 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[313]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-titlecase! in k1441 in k1438 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4437r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4437r(t0,t1,t2,t3);}}

static void C_ccall f_4437r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4443,a[2]=t3,a[3]=t2,a[4]=lf[314],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4449,a[2]=t2,a[3]=lf[315],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4448 in string-titlecase! in k1441 in k1438 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4449,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1021 %string-titlecase! */
f_4378(t1,((C_word*)t0)[2],t2,t3);}

/* a4442 in string-titlecase! in k1441 in k1438 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[313]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-titlecase! in k1441 in k1438 */
static void C_fcall f_4378(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4378,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4384,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=lf[311],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4384(t8,t1,t3);}

/* lp in %string-titlecase! in k1441 in k1438 */
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4384,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4431,a[2]=lf[309],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1009 string-index */
t5=*((C_word*)lf[310]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,((C_word*)t0)[4],t4,t2,((C_word*)t0)[2]);}

/* a4430 in lp in %string-titlecase! in k1441 in k1438 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4431,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k4386 in lp in %string-titlecase! in k1441 in k1438 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[5],t1);
t3=(C_word)C_u_i_char_upcase(t2);
t4=(C_word)C_i_string_set(((C_word*)t0)[5],t1,t3);
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4418,a[2]=lf[307],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1013 string-skip */
t8=*((C_word*)lf[308]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,((C_word*)t0)[5],t7,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a4417 in k4386 in lp in %string-titlecase! in k1441 in k1438 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4418,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k4398 in k4386 in lp in %string-titlecase! in k1441 in k1438 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1015 string-downcase! */
t3=*((C_word*)lf[302]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1);}
else{
/* srfi-13.scm: 1017 string-downcase! */
t2=*((C_word*)lf[302]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4404 in k4398 in k4386 in lp in %string-titlecase! in k1441 in k1438 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1016 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4384(t3,((C_word*)t0)[2],t2);}

/* string-downcase! in k1441 in k1438 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4360r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4360r(t0,t1,t2,t3);}}

static void C_ccall f_4360r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4366,a[2]=t3,a[3]=t2,a[4]=lf[303],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4372,a[2]=t2,a[3]=lf[304],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4371 in string-downcase! in k1441 in k1438 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4372,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1005 %string-map! */
f_1777(t1,*((C_word*)lf[299]+1),((C_word*)t0)[2],t2,t3);}

/* a4365 in string-downcase! in k1441 in k1438 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[302]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-downcase in k1441 in k1438 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4342r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4342r(t0,t1,t2,t3);}}

static void C_ccall f_4342r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4348,a[2]=t3,a[3]=t2,a[4]=lf[298],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4354,a[2]=t2,a[3]=lf[300],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4353 in string-downcase in k1441 in k1438 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4354,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1001 %string-map */
f_1716(t1,*((C_word*)lf[299]+1),((C_word*)t0)[2],t2,t3);}

/* a4347 in string-downcase in k1441 in k1438 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[297]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase! in k1441 in k1438 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4324r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4324r(t0,t1,t2,t3);}}

static void C_ccall f_4324r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4330,a[2]=t3,a[3]=t2,a[4]=lf[294],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4336,a[2]=t2,a[3]=lf[295],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4335 in string-upcase! in k1441 in k1438 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4336,4,t0,t1,t2,t3);}
/* srfi-13.scm: 997  %string-map! */
f_1777(t1,*((C_word*)lf[290]+1),((C_word*)t0)[2],t2,t3);}

/* a4329 in string-upcase! in k1441 in k1438 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4330,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[293]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase in k1441 in k1438 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4306r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4306r(t0,t1,t2,t3);}}

static void C_ccall f_4306r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4312,a[2]=t3,a[3]=t2,a[4]=lf[289],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4318,a[2]=t2,a[3]=lf[291],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a4317 in string-upcase in k1441 in k1438 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4318,4,t0,t1,t2,t3);}
/* srfi-13.scm: 993  %string-map */
f_1716(t1,*((C_word*)lf[290]+1),((C_word*)t0)[2],t2,t3);}

/* a4311 in string-upcase in k1441 in k1438 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[288]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash-ci in k1441 in k1438 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4250r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4250r(t0,t1,t2,t3);}}

static void C_ccall f_4250r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4260,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_4260(t13,t12);}
else{
t12=t10;
f_4260(t12,C_SCHEME_UNDEFINED);}}

/* k4258 in string-hash-ci in k1441 in k1438 */
static void C_fcall f_4260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4260,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[283]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[284],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=lf[286],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 975  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4273 in k4258 in string-hash-ci in k1441 in k1438 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4274,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=lf[285],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 976  %string-hash */
f_4132(t1,((C_word*)t0)[3],t4,((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a4279 in a4273 in k4258 in string-hash-ci in k1441 in k1438 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4280,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_downcase(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t3)));}

/* a4267 in k4258 in string-hash-ci in k1441 in k1438 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4268,2,t0,t1);}
/* srfi-13.scm: 975  string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[283]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash in k1441 in k1438 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4204r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4204r(t0,t1,t2,t3);}}

static void C_ccall f_4204r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4214,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_4214(t13,t12);}
else{
t12=t10;
f_4214(t12,C_SCHEME_UNDEFINED);}}

/* k4212 in string-hash in k1441 in k1438 */
static void C_fcall f_4214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4214,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[278]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[279],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=lf[281],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 965  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4227 in k4212 in string-hash in k1441 in k1438 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4228,4,t0,t1,t2,t3);}
/* srfi-13.scm: 966  %string-hash */
f_4132(t1,((C_word*)t0)[3],*((C_word*)lf[280]+1),((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a4221 in k4212 in string-hash in k1441 in k1438 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
/* srfi-13.scm: 965  string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[278]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-hash in k1441 in k1438 */
static void C_fcall f_4132(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4132,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4134,a[2]=t3,a[3]=lf[273],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4185,a[2]=t4,a[3]=lf[274],tmp=(C_word)a,a+=4,tmp);
t9=f_4185(t8,C_fix(65536));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4150,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=t9,a[6]=t4,a[7]=t6,a[8]=lf[276],tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_4150(t13,t1,t5,C_fix(0));}

/* lp in %string-hash in k1441 in k1438 */
static void C_fcall f_4150(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4150,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[7];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* srfi-13.scm: 955  modulo */
t6=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,((C_word*)t0)[6]);}
else{
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t7=(C_word)C_fixnum_times(C_fix(37),t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4183,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 956  iref */
t9=((C_word*)t0)[3];
f_4134(t9,t8,((C_word*)t0)[2],t2);}}

/* k4181 in lp in %string-hash in k1441 in k1438 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_and(((C_word*)t0)[5],t2);
/* srfi-13.scm: 956  lp */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4150(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* lp in %string-hash in k1441 in k1438 */
static C_word C_fcall f_4185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* iref in %string-hash in k1441 in k1438 */
static void C_fcall f_4134(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4134,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_ref(t2,t3);
/* srfi-13.scm: 950  char->int */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}

/* string-ci>= in k1441 in k1438 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_4084r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4084r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4084r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[265]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4090,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[266],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4096,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[270],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a4095 in string-ci>= in k1441 in k1438 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4096,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4102,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[267],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[269],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4107 in a4095 in string-ci>= in k1441 in k1438 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4108,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4115,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4115(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4115(t6,C_SCHEME_FALSE);}}

/* k4113 in a4107 in a4095 in string-ci>= in k1441 in k1438 */
static void C_fcall f_4115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4123,a[2]=lf[268],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 930  %string-compare-ci */
f_3356(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[186]+1),*((C_word*)lf[186]+1));}}

/* a4122 in k4113 in a4107 in a4095 in string-ci>= in k1441 in k1438 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4123,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4101 in a4095 in string-ci>= in k1441 in k1438 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4089 in string-ci>= in k1441 in k1438 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<= in k1441 in k1438 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_4036r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4036r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4036r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[258]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4042,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[259],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4048,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[263],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a4047 in string-ci<= in k1441 in k1438 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4048,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4054,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[260],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[262],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4059 in a4047 in string-ci<= in k1441 in k1438 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4060,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4067,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4067(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4067(t6,C_SCHEME_FALSE);}}

/* k4065 in a4059 in a4047 in string-ci<= in k1441 in k1438 */
static void C_fcall f_4067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4067,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4075,a[2]=lf[261],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 919  %string-compare-ci */
f_3356(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),*((C_word*)lf[186]+1),t2);}}

/* a4074 in k4065 in a4059 in a4047 in string-ci<= in k1441 in k1438 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4075,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4053 in a4047 in string-ci<= in k1441 in k1438 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4041 in string-ci<= in k1441 in k1438 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci> in k1441 in k1438 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3985r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3985r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3985r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[250]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3991,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[251],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3997,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[256],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3996 in string-ci> in k1441 in k1438 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3997,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4003,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[252],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[255],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4008 in a3996 in string-ci> in k1441 in k1438 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4009,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4016,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4016(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4016(t6,C_SCHEME_FALSE);}}

/* k4014 in a4008 in a3996 in string-ci> in k1441 in k1438 */
static void C_fcall f_4016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=lf[253],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4027,a[2]=lf[254],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 908  %string-compare-ci */
f_3356(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[186]+1));}}

/* a4026 in k4014 in a4008 in a3996 in string-ci> in k1441 in k1438 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4027,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4023 in k4014 in a4008 in a3996 in string-ci> in k1441 in k1438 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4024,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4002 in a3996 in string-ci> in k1441 in k1438 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3990 in string-ci> in k1441 in k1438 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci< in k1441 in k1438 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3934r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3934r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3934r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[242]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3940,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[243],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3946,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[248],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3945 in string-ci< in k1441 in k1438 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3946,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3952,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[244],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[247],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3957 in a3945 in string-ci< in k1441 in k1438 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3958,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3965,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3965(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3965(t6,C_SCHEME_FALSE);}}

/* k3963 in a3957 in a3945 in string-ci< in k1441 in k1438 */
static void C_fcall f_3965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3965,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3973,a[2]=lf[245],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3976,a[2]=lf[246],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 897  %string-compare-ci */
f_3356(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),t2,t3);}}

/* a3975 in k3963 in a3957 in a3945 in string-ci< in k1441 in k1438 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3976,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3972 in k3963 in a3957 in a3945 in string-ci< in k1441 in k1438 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3973,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3951 in a3945 in string-ci< in k1441 in k1438 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3939 in string-ci< in k1441 in k1438 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<> in k1441 in k1438 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3867r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3867r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3867r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[235]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3873,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[236],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3879,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[240],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3878 in string-ci<> in k1441 in k1438 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3879,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3885,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[237],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[239],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3890 in a3878 in string-ci<> in k1441 in k1438 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3891,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3914,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_3914(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_3914(t10,C_SCHEME_FALSE);}}}

/* k3912 in a3890 in a3878 in string-ci<> in k1441 in k1438 */
static void C_fcall f_3914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3909,a[2]=lf[238],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 886  %string-compare-ci */
f_3356(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[186]+1),t2,*((C_word*)lf[186]+1));}}

/* a3908 in k3912 in a3890 in a3878 in string-ci<> in k1441 in k1438 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3909,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3884 in a3878 in string-ci<> in k1441 in k1438 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3872 in string-ci<> in k1441 in k1438 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci= in k1441 in k1438 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3805r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3805r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3805r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[227]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3811,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[228],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[233],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3816 in string-ci= in k1441 in k1438 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3817,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3823,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[229],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[232],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3828 in a3816 in string-ci= in k1441 in k1438 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3829,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3839,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_3839(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_3839(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k3837 in a3828 in a3816 in string-ci= in k1441 in k1438 */
static void C_fcall f_3839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3839,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=lf[230],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3850,a[2]=lf[231],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 876  %string-compare-ci */
f_3356(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[186]+1),t3);}}

/* a3849 in k3837 in a3828 in a3816 in string-ci= in k1441 in k1438 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3850,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3846 in k3837 in a3828 in a3816 in string-ci= in k1441 in k1438 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3847,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3822 in a3816 in string-ci= in k1441 in k1438 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3810 in string-ci= in k1441 in k1438 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3811,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string>= in k1441 in k1438 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3757r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3757r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3757r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[220]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3763,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[221],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3769,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[225],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3768 in string>= in k1441 in k1438 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3769,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3775,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[222],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[224],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3780 in a3768 in string>= in k1441 in k1438 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3781,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3788,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3788(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3788(t6,C_SCHEME_FALSE);}}

/* k3786 in a3780 in a3768 in string>= in k1441 in k1438 */
static void C_fcall f_3788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3788,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3796,a[2]=lf[223],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 866  %string-compare */
f_3294(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[186]+1),*((C_word*)lf[186]+1));}}

/* a3795 in k3786 in a3780 in a3768 in string>= in k1441 in k1438 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3796,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3774 in a3768 in string>= in k1441 in k1438 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3762 in string>= in k1441 in k1438 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3763,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<= in k1441 in k1438 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3709r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3709r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3709r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[213]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3715,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[214],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3721,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[218],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3720 in string<= in k1441 in k1438 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3721,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3727,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[215],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[217],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3732 in a3720 in string<= in k1441 in k1438 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3733,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3740,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3740(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3740(t6,C_SCHEME_FALSE);}}

/* k3738 in a3732 in a3720 in string<= in k1441 in k1438 */
static void C_fcall f_3740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3740,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3748,a[2]=lf[216],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 855  %string-compare */
f_3294(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),*((C_word*)lf[186]+1),t2);}}

/* a3747 in k3738 in a3732 in a3720 in string<= in k1441 in k1438 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3748,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3726 in a3720 in string<= in k1441 in k1438 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3714 in string<= in k1441 in k1438 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string> in k1441 in k1438 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3658r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3658r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3658r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[205]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3664,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[206],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3670,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[211],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3669 in string> in k1441 in k1438 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3670,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[207],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[210],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3681 in a3669 in string> in k1441 in k1438 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3682,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3689,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3689(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3689(t6,C_SCHEME_FALSE);}}

/* k3687 in a3681 in a3669 in string> in k1441 in k1438 */
static void C_fcall f_3689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3689,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3697,a[2]=lf[208],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3700,a[2]=lf[209],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 844  %string-compare */
f_3294(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[186]+1));}}

/* a3699 in k3687 in a3681 in a3669 in string> in k1441 in k1438 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3700,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3696 in k3687 in a3681 in a3669 in string> in k1441 in k1438 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3697,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3675 in a3669 in string> in k1441 in k1438 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3663 in string> in k1441 in k1438 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string< in k1441 in k1438 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3607r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3607r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3607r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[197]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3613,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[198],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3619,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[203],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3618 in string< in k1441 in k1438 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3619,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3625,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[199],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=lf[202],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3630 in a3618 in string< in k1441 in k1438 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3631,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3638,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_3638(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_3638(t6,C_SCHEME_FALSE);}}

/* k3636 in a3630 in a3618 in string< in k1441 in k1438 */
static void C_fcall f_3638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3638,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3646,a[2]=lf[200],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=lf[201],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 833  %string-compare */
f_3294(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[186]+1),t2,t3);}}

/* a3648 in k3636 in a3630 in a3618 in string< in k1441 in k1438 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3649,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3645 in k3636 in a3630 in a3618 in string< in k1441 in k1438 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3646,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3624 in a3618 in string< in k1441 in k1438 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3612 in string< in k1441 in k1438 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<> in k1441 in k1438 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3540r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3540r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3540r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[190]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3546,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[191],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3552,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[195],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3551 in string<> in k1441 in k1438 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3552,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3558,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[192],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[194],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3563 in a3551 in string<> in k1441 in k1438 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3564,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3587,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_3587(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_3587(t10,C_SCHEME_FALSE);}}}

/* k3585 in a3563 in a3551 in string<> in k1441 in k1438 */
static void C_fcall f_3587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3587,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3582,a[2]=lf[193],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 822  %string-compare */
f_3294(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[186]+1),t2,*((C_word*)lf[186]+1));}}

/* a3581 in k3585 in a3563 in a3551 in string<> in k1441 in k1438 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3582,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3557 in a3551 in string<> in k1441 in k1438 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3545 in string<> in k1441 in k1438 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3546,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string= in k1441 in k1438 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3478r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3478r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3478r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[181]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3484,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[182],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3490,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[188],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3489 in string= in k1441 in k1438 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3490,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3496,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[183],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=lf[187],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3501 in a3489 in string= in k1441 in k1438 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3502,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3512,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_3512(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_3512(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k3510 in a3501 in a3489 in string= in k1441 in k1438 */
static void C_fcall f_3512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3512,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=lf[184],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3523,a[2]=lf[185],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 812  %string-compare */
f_3294(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[186]+1),t3);}}

/* a3522 in k3510 in a3501 in a3489 in string= in k1441 in k1438 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3523,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3519 in k3510 in a3501 in a3489 in string= in k1441 in k1438 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3520,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a3495 in a3489 in string= in k1441 in k1438 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3483 in string= in k1441 in k1438 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare-ci in k1441 in k1438 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr7r,(void*)f_3448r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_3448r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_3448r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t8=*((C_word*)lf[175]+1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3454,a[2]=t7,a[3]=t2,a[4]=t8,a[5]=lf[176],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3460,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,a[8]=lf[179],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a3459 in string-compare-ci in k1441 in k1438 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3460,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3466,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=lf[177],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=lf[178],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3471 in a3459 in string-compare-ci in k1441 in k1438 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3472,4,t0,t1,t2,t3);}
/* srfi-13.scm: 796  %string-compare-ci */
f_3356(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3465 in a3459 in string-compare-ci in k1441 in k1438 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3453 in string-compare-ci in k1441 in k1438 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare in k1441 in k1438 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr7r,(void*)f_3418r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_3418r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_3418r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t8=*((C_word*)lf[169]+1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3424,a[2]=t7,a[3]=t2,a[4]=t8,a[5]=lf[170],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3430,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,a[8]=lf[173],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a3429 in string-compare in k1441 in k1438 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3430,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3436,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=lf[171],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=lf[172],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3441 in a3429 in string-compare in k1441 in k1438 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3442,4,t0,t1,t2,t3);}
/* srfi-13.scm: 788  %string-compare */
f_3294(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3435 in a3429 in string-compare in k1441 in k1438 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3423 in string-compare in k1441 in k1438 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3424,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare-ci in k1441 in k1438 */
static void C_fcall f_3356(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3356,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_fixnum_difference(t4,t3);
t12=(C_word)C_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3366,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 773  %string-prefix-length-ci */
f_2804(t13,t2,t3,t4,t5,t6,t7);}

/* k3364 in %string-compare-ci in k1441 in k1438 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_3391(t8,((C_word*)t0)[5]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3400,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t10=(C_word)C_i_string_ref(((C_word*)t0)[4],t9);
t11=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t12=(C_word)C_i_string_ref(((C_word*)t0)[2],t11);
/* srfi-13.scm: 777  char-ci<? */
t13=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t8,t10,t12);}}}

/* k3398 in k3364 in %string-compare-ci in k1441 in k1438 */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_3391(t2,(C_truep(t1)?((C_word*)t0)[3]:((C_word*)t0)[2]));}

/* k3389 in k3364 in %string-compare-ci in k1441 in k1438 */
static void C_fcall f_3391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare in k1441 in k1438 */
static void C_fcall f_3294(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3294,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_fixnum_difference(t4,t3);
t12=(C_word)C_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3304,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t10,a[6]=t3,a[7]=t4,a[8]=t1,a[9]=t8,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 759  %string-prefix-length */
f_2646(t13,t2,t3,t4,t5,t6,t7);}

/* k3302 in %string-compare in k1441 in k1438 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
t6=(C_truep(t5)?((C_word*)t0)[10]:((C_word*)t0)[9]);
t7=t6;
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3329,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=t1;
t7=(C_word)C_eqp(t6,((C_word*)t0)[11]);
if(C_truep(t7)){
t8=t5;
f_3329(t8,((C_word*)t0)[5]);}
else{
t8=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t9=(C_word)C_i_string_ref(((C_word*)t0)[4],t8);
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t11=(C_word)C_i_string_ref(((C_word*)t0)[2],t10);
t12=(C_word)C_fixnum_lessp(t9,t11);
t13=t5;
f_3329(t13,(C_truep(t12)?((C_word*)t0)[9]:((C_word*)t0)[5]));}}}

/* k3327 in k3302 in %string-compare in k1441 in k1438 */
static void C_fcall f_3329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-ci? in k1441 in k1438 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3172r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3172r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3172r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[158]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3178,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[159],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3184,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[162],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3183 in string-suffix-ci? in k1441 in k1438 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3184,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3190,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[160],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[161],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3195 in a3183 in string-suffix-ci? in k1441 in k1438 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3196,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3288,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 743  %string-suffix-length-ci */
f_2877(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3286 in a3195 in a3183 in string-suffix-ci? in k1441 in k1438 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3189 in a3183 in string-suffix-ci? in k1441 in k1438 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3177 in string-suffix-ci? in k1441 in k1438 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3178,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-ci? in k1441 in k1438 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3142r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3142r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[152]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3148,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[153],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3154,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[156],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3153 in string-prefix-ci? in k1441 in k1438 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3154,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3160,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[154],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3166,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[155],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3165 in a3153 in string-prefix-ci? in k1441 in k1438 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3166,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 737  %string-prefix-length-ci */
f_2804(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3263 in a3165 in a3153 in string-prefix-ci? in k1441 in k1438 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3159 in a3153 in string-prefix-ci? in k1441 in k1438 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3160,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3147 in string-prefix-ci? in k1441 in k1438 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3148,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix? in k1441 in k1438 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3112r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3112r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3112r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[146]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3118,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[147],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3124,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[150],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3123 in string-suffix? in k1441 in k1438 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3124,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3130,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[148],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[149],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3135 in a3123 in string-suffix? in k1441 in k1438 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3136,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3242,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 731  %string-suffix-length */
f_2719(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3240 in a3135 in a3123 in string-suffix? in k1441 in k1438 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a3129 in a3123 in string-suffix? in k1441 in k1438 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3117 in string-suffix? in k1441 in k1438 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix? in k1441 in k1438 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3082r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3082r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[140]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3088,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[141],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3094,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[144],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3093 in string-prefix? in k1441 in k1438 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3094,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3100,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[142],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[143],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3105 in a3093 in string-prefix? in k1441 in k1438 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3106,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_fixnum_difference(t6,t5);
t9=(C_word)C_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3219,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 724  %string-prefix-length */
f_2646(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k3217 in a3105 in a3093 in string-prefix? in k1441 in k1438 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(t1,((C_word*)t0)[2]));}

/* a3099 in a3093 in string-prefix? in k1441 in k1438 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3100,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3087 in string-prefix? in k1441 in k1438 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3088,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length-ci in k1441 in k1438 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3052r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3052r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3052r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[134]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3058,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[135],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3064,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[138],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3063 in string-suffix-length-ci in k1441 in k1438 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3064,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3070,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[136],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[137],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3075 in a3063 in string-suffix-length-ci in k1441 in k1438 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3076,4,t0,t1,t2,t3);}
/* srfi-13.scm: 688  %string-suffix-length-ci */
f_2877(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3069 in a3063 in string-suffix-length-ci in k1441 in k1438 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3057 in string-suffix-length-ci in k1441 in k1438 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length-ci in k1441 in k1438 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3022r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3022r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3022r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[128]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3028,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[129],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3034,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[132],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3033 in string-prefix-length-ci in k1441 in k1438 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3034,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3040,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[130],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[131],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3045 in a3033 in string-prefix-length-ci in k1441 in k1438 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3046,4,t0,t1,t2,t3);}
/* srfi-13.scm: 683  %string-prefix-length-ci */
f_2804(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3039 in a3033 in string-prefix-length-ci in k1441 in k1438 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3027 in string-prefix-length-ci in k1441 in k1438 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length in k1441 in k1438 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2992r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2992r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2992r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[122]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2998,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[123],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3004,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[126],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a3003 in string-suffix-length in k1441 in k1438 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3004,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3010,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[124],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[125],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3015 in a3003 in string-suffix-length in k1441 in k1438 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3016,4,t0,t1,t2,t3);}
/* srfi-13.scm: 678  %string-suffix-length */
f_2719(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a3009 in a3003 in string-suffix-length in k1441 in k1438 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3010,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2997 in string-suffix-length in k1441 in k1438 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length in k1441 in k1438 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2962r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2962r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2962r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=*((C_word*)lf[116]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2968,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=lf[117],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2974,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=lf[120],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a2973 in string-prefix-length in k1441 in k1438 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2974,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2980,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[118],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=lf[119],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2985 in a2973 in string-prefix-length in k1441 in k1438 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2986,4,t0,t1,t2,t3);}
/* srfi-13.scm: 673  %string-prefix-length */
f_2646(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2979 in a2973 in string-prefix-length in k1441 in k1438 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2967 in string-prefix-length in k1441 in k1438 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-suffix-length-ci in k1441 in k1438 */
static void C_fcall f_2877(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2877,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2881,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 656  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2879 in %string-suffix-length-ci in k1441 in k1438 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_2890(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2890(t5,C_SCHEME_FALSE);}}

/* k2888 in k2879 in %string-suffix-length-ci in k1441 in k1438 */
static void C_fcall f_2890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2890,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=lf[114],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_2903(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k2888 in k2879 in %string-suffix-length-ci in k1441 in k1438 */
static void C_fcall f_2903(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2903,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2913(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t9=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
/* srfi-13.scm: 664  char-ci=? */
t10=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k2936 in lp in k2888 in k2879 in %string-suffix-length-ci in k1441 in k1438 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2913(t2,(C_word)C_i_not(t1));}

/* k2911 in lp in k2888 in k2879 in %string-suffix-length-ci in k1441 in k1438 */
static void C_fcall f_2913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 667  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2903(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length-ci in k1441 in k1438 */
static void C_fcall f_2804(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2804,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2808,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 642  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2806 in %string-prefix-length-ci in k1441 in k1438 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_2817(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2817(t5,C_SCHEME_FALSE);}}

/* k2815 in k2806 in %string-prefix-length-ci in k1441 in k1438 */
static void C_fcall f_2817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[111],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2822(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k2815 in k2806 in %string-prefix-length-ci in k1441 in k1438 */
static void C_fcall f_2822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2822,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2832(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2853,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t9=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
/* srfi-13.scm: 650  char-ci=? */
t10=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k2851 in lp in k2815 in k2806 in %string-prefix-length-ci in k1441 in k1438 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2832(t2,(C_word)C_i_not(t1));}

/* k2830 in lp in k2815 in k2806 in %string-prefix-length-ci in k1441 in k1438 */
static void C_fcall f_2832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 653  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2822(t4,((C_word*)t0)[6],t2,t3);}}

/* %string-suffix-length in k1441 in k1438 */
static void C_fcall f_2719(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2719,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2723,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 628  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2721 in %string-suffix-length in k1441 in k1438 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_2732(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2732(t5,C_SCHEME_FALSE);}}

/* k2730 in k2721 in %string-suffix-length in k1441 in k1438 */
static void C_fcall f_2732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2732,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=lf[107],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_2745(t7,((C_word*)t0)[8],t2,t3);}}

/* lp in k2730 in k2721 in %string-suffix-length in k1441 in k1438 */
static void C_fcall f_2745(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2745,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2755,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2755(t7,t5);}
else{
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_2755(t10,(C_word)C_i_not(t9));}}

/* k2753 in lp in k2730 in k2721 in %string-suffix-length in k1441 in k1438 */
static void C_fcall f_2755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 639  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2745(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length in k1441 in k1438 */
static void C_fcall f_2646(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2646,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2650,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_fixnum_difference(t4,t3);
t10=(C_word)C_fixnum_difference(t7,t6);
/* srfi-13.scm: 614  min */
t11=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k2648 in %string-prefix-length in k1441 in k1438 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_2659(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_2659(t5,C_SCHEME_FALSE);}}

/* k2657 in k2648 in %string-prefix-length in k1441 in k1438 */
static void C_fcall f_2659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2659,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[104],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2664(t5,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k2657 in k2648 in %string-prefix-length in k1441 in k1438 */
static void C_fcall f_2664(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2664,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2674(t7,t5);}
else{
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_2674(t10,(C_word)C_i_not(t9));}}

/* k2672 in lp in k2657 in k2648 in %string-prefix-length in k1441 in k1438 */
static void C_fcall f_2674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 625  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2664(t4,((C_word*)t0)[6],t2,t3);}}

/* string-tabulate in k1441 in k1438 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2607,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[100]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2614,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 596  make-string */
t6=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k2612 in string-tabulate in k1441 in k1438 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=lf[101],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2623(t7,t2,t3);}

/* do264 in k2612 in string-tabulate in k1441 in k1438 */
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2623,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2644,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 599  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k2642 in do264 in k2612 in string-tabulate in k1441 in k1438 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2623(t4,((C_word*)t0)[2],t3);}

/* k2615 in k2612 in string-tabulate in k1441 in k1438 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-any in k1441 in k1438 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2477r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2477r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2477r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2483,a[2]=t4,a[3]=t3,a[4]=lf[93],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2489,a[2]=t3,a[3]=t2,a[4]=lf[98],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2488 in string-any in k1441 in k1438 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2489,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[94],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2501(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2531,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 573  char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k2529 in a2488 in string-any in k1441 in k1438 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[95],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2536(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2577,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=lf[96],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2577(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
/* srfi-13.scm: 587  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[92],lf[97],*((C_word*)lf[92]+1),((C_word*)t0)[4]);}}}

/* lp in k2529 in a2488 in string-any in k1441 in k1438 */
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2577,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 584  criteria */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2596,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 585  criteria */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2594 in lp in k2529 in a2488 in string-any in k1441 in k1438 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* srfi-13.scm: 585  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2577(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* lp in k2529 in a2488 in string-any in k1441 in k1438 */
static void C_fcall f_2536(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2536,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 576  char-set-contains? */
t7=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k2544 in lp in k2529 in a2488 in string-any in k1441 in k1438 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 577  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2536(t3,((C_word*)t0)[4],t2);}}

/* lp in a2488 in string-any in k1441 in k1438 */
static C_word C_fcall f_2501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a2482 in string-any in k1441 in k1438 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-every in k1441 in k1438 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2347r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2347r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2347r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2353,a[2]=t4,a[3]=t3,a[4]=lf[83],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2359,a[2]=t3,a[3]=t2,a[4]=lf[90],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2358 in string-every in k1441 in k1438 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2359,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[84],tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2371(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2401,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 547  char-set? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k2399 in a2358 in string-every in k1441 in k1438 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[86],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2406(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2447,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=lf[87],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2447(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 561  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[82],lf[88],*((C_word*)lf[82]+1),((C_word*)t0)[4]);}}}

/* lp in k2399 in a2358 in string-every in k1441 in k1438 */
static void C_fcall f_2447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2447,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],t2);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 558  criteria */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2469,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 559  criteria */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2467 in lp in k2399 in a2358 in string-every in k1441 in k1438 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 559  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2447(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in k2399 in a2358 in string-every in k1441 in k1438 */
static void C_fcall f_2406(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2406,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
t5=(C_word)C_fixnum_greater_or_equal_p(t3,t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2419,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 550  char-set-contains? */
t8=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2417 in lp in k2399 in a2358 in string-every in k1441 in k1438 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 551  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2406(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in a2358 in string-every in k1441 in k1438 */
static C_word C_fcall f_2371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_greater_or_equal_p(t2,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t1);
t6=(C_word)C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* a2352 in string-every in k1441 in k1438 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each-index in k1441 in k1438 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_2310r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2310r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2310r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2316,a[2]=t4,a[3]=t3,a[4]=lf[78],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2322,a[2]=t2,a[3]=lf[80],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2321 in string-for-each-index in k1441 in k1438 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2322,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=lf[79],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2328(t7,t1,t2);}

/* lp in a2321 in string-for-each-index in k1441 in k1438 */
static void C_fcall f_2328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2328,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2338,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 537  proc */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k2336 in lp in a2321 in string-for-each-index in k1441 in k1438 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 537  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2328(t3,((C_word*)t0)[2],t2);}

/* a2315 in string-for-each-index in k1441 in k1438 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[77]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each in k1441 in k1438 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2269r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2269r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2269r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2275,a[2]=t4,a[3]=t3,a[4]=lf[73],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2281,a[2]=t2,a[3]=t3,a[4]=lf[75],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2280 in string-for-each in k1441 in k1438 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2281,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=lf[74],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2287(t7,t1,t2);}

/* lp in a2280 in string-for-each in k1441 in k1438 */
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2287,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2297,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
/* srfi-13.scm: 530  proc */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k2295 in lp in a2280 in string-for-each in k1441 in k1438 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 531  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2287(t3,((C_word*)t0)[2],t2);}

/* a2274 in string-for-each in k1441 in k1438 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2275,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[72]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-unfold-right in k1441 in k1438 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr6r,(void*)f_2080r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2080r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_2080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(12);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[65]:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=lf[67],tmp=(C_word)a,a+=3,tmp):(C_word)C_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t10));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2106,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 483  make-string */
t16=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}
else{
/* ##sys#error */
t15=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=lf[70],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2108(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(40),((C_word*)t0)[2]);}

/* lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_fcall f_2108(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2108,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t2,a[10]=t3,a[11]=t5,a[12]=((C_word*)t0)[7],a[13]=lf[69],tmp=(C_word)a,a+=14,tmp));
t11=((C_word*)t9)[1];
f_2114(t11,t1,t6,t7);}

/* lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2114,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 488  p */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 505  make-final */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 489  f */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k2122 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 490  g */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2125 in k2122 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2127,2,t0,t1);}
t2=((C_word*)t0)[10];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_i_string_set(((C_word*)t0)[9],t3,((C_word*)t0)[8]);
/* srfi-13.scm: 494  lp2 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_2114(t5,((C_word*)t0)[6],t3,t1);}
else{
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2148,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 497  min */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(4096),t3);}}

/* k2146 in k2125 in k2122 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 498  make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2149 in k2146 in k2125 in k2122 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_i_string_set(t1,t2,((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 501  lp */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2108(t6,((C_word*)t0)[3],t4,t5,t1,((C_word*)t0)[10],t2,((C_word*)t0)[2]);}

/* k2169 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_i_string_length(((C_word*)t0)[8]);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(t3,((C_word*)t0)[5]),t4);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2186,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_fixnum_plus(t5,t2);
/* srfi-13.scm: 510  make-string */
t8=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k2184 in k2169 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 511  %string-copy! */
f_5775(t2,t1,C_fix(0),((C_word*)t0)[2],C_fix(0),((C_word*)t0)[10]);}

/* k2187 in k2184 in k2169 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 512  %string-copy! */
f_5775(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2190 in k2187 in k2184 in k2169 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t5,a[6]=lf[68],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2201(t7,t2,t3,((C_word*)t0)[2]);}

/* lp in k2190 in k2187 in k2184 in k2169 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_fcall f_2201(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2201,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_string_length(t4);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2220,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 519  %string-copy! */
f_5775(t7,((C_word*)t0)[4],t2,t4,C_fix(0),t6);}
else{
/* srfi-13.scm: 521  %string-copy! */
f_5775(t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}}

/* k2218 in lp in k2190 in k2187 in k2184 in k2169 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 520  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2201(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2193 in k2190 in k2187 in k2184 in k2169 in k2236 in lp2 in lp in k2104 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2251 in string-unfold-right in k1441 in k1438 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2251,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[66]);}

/* string-unfold in k1441 in k1438 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr6r,(void*)f_1898r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_1898r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_1898r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(12);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[55]:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=lf[57],tmp=(C_word)a,a+=3,tmp):(C_word)C_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t10));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1924,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 438  make-string */
t16=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}
else{
/* ##sys#error */
t15=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=lf[62],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1926(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(0),((C_word*)t0)[2]);}

/* lp in k1922 in string-unfold in k1441 in k1438 */
static void C_fcall f_1926(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1926,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t2,a[11]=t3,a[12]=((C_word*)t0)[7],a[13]=lf[61],tmp=(C_word)a,a+=14,tmp));
t11=((C_word*)t9)[1];
f_1932(t11,t1,t6,t7);}

/* lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1932,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 443  p */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 458  make-final */
t3=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 444  f */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k1940 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 445  g */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1943 in k1940 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_i_string_set(((C_word*)t0)[8],((C_word*)t0)[10],((C_word*)t0)[7]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* srfi-13.scm: 448  lp2 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_1932(t6,((C_word*)t0)[5],t5,t1);}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1967,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 451  min */
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(4096),t4);}}

/* k1965 in k1943 in k1940 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 452  make-string */
t3=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1968 in k1965 in k1943 in k1940 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(C_word)C_i_string_set(t1,C_fix(0),((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[7],((C_word*)t0)[6]);
/* srfi-13.scm: 454  lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1926(t5,((C_word*)t0)[4],t3,t4,t1,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}

/* k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_i_string_length(((C_word*)t0)[7]);
t4=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(t3,((C_word*)t0)[6]),((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1999,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_fixnum_plus(t4,t2);
/* srfi-13.scm: 462  make-string */
t7=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k1997 in k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 463  %string-copy! */
f_5775(t2,t1,((C_word*)t0)[10],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k2000 in k1997 in k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 465  %string-copy! */
f_5775(t3,((C_word*)t0)[6],t2,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[8]);}

/* k2006 in k2000 in k1997 in k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=lf[59],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2016(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k2006 in k2000 in k1997 in k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_fcall f_2016(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2016,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_string_length(t4);
t7=(C_word)C_fixnum_difference(t2,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2038,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 472  %string-copy! */
f_5775(t8,((C_word*)t0)[2],t7,t4,C_fix(0),t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2036 in lp in k2006 in k2000 in k1997 in k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 473  lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2016(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2009 in k2006 in k2000 in k1997 in k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 474  %string-copy! */
f_5775(t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k2012 in k2009 in k2006 in k2000 in k1997 in k1985 in k2047 in lp2 in lp in k1922 in string-unfold in k1441 in k1438 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2062 in string-unfold in k1441 in k1438 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2062,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[56]);}

/* string-fold-right in k1441 in k1438 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr5r,(void*)f_1852r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1852r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1852r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=t5,a[3]=t4,a[4]=lf[50],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1864,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[52],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a1863 in string-fold-right in k1441 in k1438 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1864,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t2,a[6]=lf[51],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1874(t8,t1,((C_word*)t0)[2],t4);}

/* lp in a1863 in string-fold-right in k1441 in k1438 */
static void C_fcall f_1874(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1874,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1888,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
/* srfi-13.scm: 363  kons */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k1886 in lp in a1863 in string-fold-right in k1441 in k1438 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 363  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1874(t3,((C_word*)t0)[2],t1,t2);}

/* a1857 in string-fold-right in k1441 in k1438 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[49]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fold in k1441 in k1438 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr5r,(void*)f_1810r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1810r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1810r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(11);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1816,a[2]=t5,a[3]=t4,a[4]=lf[45],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1822,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[47],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}

/* a1821 in string-fold in k1441 in k1438 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1822,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t3,a[6]=lf[46],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1828(t7,t1,((C_word*)t0)[2],t2);}

/* lp in a1821 in string-fold in k1441 in k1438 */
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1828,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1842,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
/* srfi-13.scm: 356  kons */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k1840 in lp in a1821 in string-fold in k1441 in k1438 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 356  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1828(t3,((C_word*)t0)[2],t1,t2);}

/* a1815 in string-fold in k1441 in k1438 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[44]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map! in k1441 in k1438 */
static void C_fcall f_1777(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1777,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1783,a[2]=t2,a[3]=t7,a[4]=t3,a[5]=t5,a[6]=lf[42],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_1783(t9,t1,t4);}

/* do70 in %string-map! in k1441 in k1438 */
static void C_fcall f_1783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1783,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1804,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
/* srfi-13.scm: 350  proc */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k1802 in do70 in %string-map! in k1441 in k1438 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1783(t4,((C_word*)t0)[2],t3);}

/* string-map! in k1441 in k1438 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_1759r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1759r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=t4,a[3]=t3,a[4]=lf[38],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1771,a[2]=t3,a[3]=t2,a[4]=lf[40],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a1770 in string-map! in k1441 in k1438 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1771,4,t0,t1,t2,t3);}
/* srfi-13.scm: 345  %string-map! */
f_1777(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1764 in string-map! in k1441 in k1438 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[37]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map in k1441 in k1438 */
static void C_fcall f_1716(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_fixnum_difference(t5,t4);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1723,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 335  make-string */
t8=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}

/* k1721 in %string-map in k1441 in k1438 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1726,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=lf[34],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1728(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do54 in k1721 in %string-map in k1441 in k1438 */
static void C_fcall f_1728(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1728,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1753,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
/* srfi-13.scm: 339  proc */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k1751 in do54 in k1721 in %string-map in k1441 in k1438 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_1728(t5,((C_word*)t0)[2],t3,t4);}

/* k1724 in k1721 in %string-map in k1441 in k1438 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-map in k1441 in k1438 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_1698r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1698r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1704,a[2]=t4,a[3]=t3,a[4]=lf[30],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1710,a[2]=t3,a[3]=t2,a[4]=lf[32],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a1709 in string-map in k1441 in k1438 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1710,4,t0,t1,t2,t3);}
/* srfi-13.scm: 331  %string-map */
f_1716(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1703 in string-map in k1441 in k1438 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-copy in k1441 in k1438 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_1680r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1680r(t0,t1,t2,t3);}}

static void C_ccall f_1680r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1686,a[2]=t3,a[3]=t2,a[4]=lf[26],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1692,a[2]=t2,a[3]=lf[27],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1691 in string-copy in k1441 in k1438 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1692,4,t0,t1,t2,t3);}
/* srfi-13.scm: 296  ##sys#substring */
t4=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* a1685 in string-copy in k1441 in k1438 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[25]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %substring/shared in k1441 in k1438 */
static void C_fcall f_1658(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1658,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1665,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_i_string_length(t2);
t8=t4;
t9=t5;
f_1665(t9,(C_word)C_eqp(t8,t7));}
else{
t7=t5;
f_1665(t7,C_SCHEME_FALSE);}}

/* k1663 in %substring/shared in k1441 in k1438 */
static void C_fcall f_1665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
/* srfi-13.scm: 292  ##sys#substring */
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring/shared in k1441 in k1438 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1621r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1621r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1621r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_string_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1628,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_1628(2,t7,t5);}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_1628(2,t8,(C_word)C_i_car(t4));}
else{
/* srfi-13.scm: 275  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1626 in substring/shared in k1441 in k1438 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[20]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1634,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 277  check-substring-spec */
t4=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[20],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1632 in k1626 in substring/shared in k1441 in k1438 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 278  %substring/shared */
f_1658(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* check-substring-spec in k1441 in k1438 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1605,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1619,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 245  substring-spec-ok? */
t7=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,t5);}

/* k1617 in check-substring-spec in k1441 in k1438 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* srfi-13.scm: 246  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[6],lf[17],lf[18],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring-spec-ok? in k1441 in k1438 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1565,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_stringp(t2))){
if(C_truep((C_word)C_fixnump(t3))){
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t5))){
t6=t3;
t7=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=(C_word)C_i_string_length(t2);
t9=t4;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_fixnum_less_or_equal_p(t9,t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* string-parse-final-start+end in k1441 in k1438 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1538,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1544,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=lf[11],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=t2,a[3]=lf[13],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a1549 in string-parse-final-start+end in k1441 in k1438 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1550,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
/* srfi-13.scm: 229  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[10],lf[12],((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 230  values */
C_values(4,0,t1,t3,t4);}}

/* a1543 in string-parse-final-start+end in k1441 in k1438 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
/* srfi-13.scm: 228  string-parse-start+end */
t2=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-parse-start+end in k1441 in k1438 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1445,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t3,lf[2]);
t6=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=(C_word)C_i_cdr(t4);
t9=(C_truep((C_word)C_fixnump(t7))?(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1475,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t8,a[6]=lf[5],tmp=(C_word)a,a+=7,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1511,a[2]=t3,a[3]=t2,a[4]=t7,a[5]=lf[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 211  ##sys#call-with-values */
C_call_with_values(4,0,t1,t10,t11);}
else{
/* srfi-13.scm: 223  ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t1,lf[2],lf[8],t2,t7,t3);}}
else{
/* srfi-13.scm: 225  values */
C_values(5,0,t1,C_SCHEME_END_OF_LIST,C_fix(0),t6);}}

/* a1510 in string-parse-start+end in k1441 in k1438 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1511,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t4))){
/* srfi-13.scm: 220  values */
C_values(5,0,t1,t3,((C_word*)t0)[4],t2);}
else{
/* srfi-13.scm: 221  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t1,lf[2],lf[6],((C_word*)t0)[3],((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* a1474 in string-parse-start+end in k1441 in k1438 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_truep((C_word)C_fixnump(t2))?(C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-13.scm: 217  values */
C_values(4,0,t1,t2,t3);}
else{
/* srfi-13.scm: 218  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[2],lf[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 219  values */
C_values(4,0,t1,((C_word*)t0)[4],((C_word*)t0)[5]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[570] = {
{"toplevelsrfi-13.scm",(void*)C_srfi_13_toplevel},
{"f_1440srfi-13.scm",(void*)f_1440},
{"f_1443srfi-13.scm",(void*)f_1443},
{"f_7456srfi-13.scm",(void*)f_7456},
{"f_7568srfi-13.scm",(void*)f_7568},
{"f_7538srfi-13.scm",(void*)f_7538},
{"f_7521srfi-13.scm",(void*)f_7521},
{"f_7476srfi-13.scm",(void*)f_7476},
{"f_7482srfi-13.scm",(void*)f_7482},
{"f_7504srfi-13.scm",(void*)f_7504},
{"f_7383srfi-13.scm",(void*)f_7383},
{"f_7454srfi-13.scm",(void*)f_7454},
{"f_7396srfi-13.scm",(void*)f_7396},
{"f_7414srfi-13.scm",(void*)f_7414},
{"f_7439srfi-13.scm",(void*)f_7439},
{"f_7243srfi-13.scm",(void*)f_7243},
{"f_7296srfi-13.scm",(void*)f_7296},
{"f_7309srfi-13.scm",(void*)f_7309},
{"f_7369srfi-13.scm",(void*)f_7369},
{"f_7373srfi-13.scm",(void*)f_7373},
{"f_7362srfi-13.scm",(void*)f_7362},
{"f_7358srfi-13.scm",(void*)f_7358},
{"f_7252srfi-13.scm",(void*)f_7252},
{"f_7274srfi-13.scm",(void*)f_7274},
{"f_7264srfi-13.scm",(void*)f_7264},
{"f_7105srfi-13.scm",(void*)f_7105},
{"f_7158srfi-13.scm",(void*)f_7158},
{"f_7228srfi-13.scm",(void*)f_7228},
{"f_7232srfi-13.scm",(void*)f_7232},
{"f_7221srfi-13.scm",(void*)f_7221},
{"f_7224srfi-13.scm",(void*)f_7224},
{"f_7218srfi-13.scm",(void*)f_7218},
{"f_7214srfi-13.scm",(void*)f_7214},
{"f_7114srfi-13.scm",(void*)f_7114},
{"f_7136srfi-13.scm",(void*)f_7136},
{"f_7126srfi-13.scm",(void*)f_7126},
{"f_7023srfi-13.scm",(void*)f_7023},
{"f_7041srfi-13.scm",(void*)f_7041},
{"f_7047srfi-13.scm",(void*)f_7047},
{"f_7051srfi-13.scm",(void*)f_7051},
{"f_7060srfi-13.scm",(void*)f_7060},
{"f_7085srfi-13.scm",(void*)f_7085},
{"f_7074srfi-13.scm",(void*)f_7074},
{"f_7035srfi-13.scm",(void*)f_7035},
{"f_6972srfi-13.scm",(void*)f_6972},
{"f_6976srfi-13.scm",(void*)f_6976},
{"f_6987srfi-13.scm",(void*)f_6987},
{"f_7000srfi-13.scm",(void*)f_7000},
{"f_7003srfi-13.scm",(void*)f_7003},
{"f_7006srfi-13.scm",(void*)f_7006},
{"f_7009srfi-13.scm",(void*)f_7009},
{"f_6981srfi-13.scm",(void*)f_6981},
{"f_6929srfi-13.scm",(void*)f_6929},
{"f_6933srfi-13.scm",(void*)f_6933},
{"f_6936srfi-13.scm",(void*)f_6936},
{"f_6941srfi-13.scm",(void*)f_6941},
{"f_6963srfi-13.scm",(void*)f_6963},
{"f_6939srfi-13.scm",(void*)f_6939},
{"f_6800srfi-13.scm",(void*)f_6800},
{"f_6827srfi-13.scm",(void*)f_6827},
{"f_6877srfi-13.scm",(void*)f_6877},
{"f_6712srfi-13.scm",(void*)f_6712},
{"f_6742srfi-13.scm",(void*)f_6742},
{"f_6639srfi-13.scm",(void*)f_6639},
{"f_6646srfi-13.scm",(void*)f_6646},
{"f_6651srfi-13.scm",(void*)f_6651},
{"f_6667srfi-13.scm",(void*)f_6667},
{"f_6649srfi-13.scm",(void*)f_6649},
{"f_6680srfi-13.scm",(void*)f_6680},
{"f_6537srfi-13.scm",(void*)f_6537},
{"f_6543srfi-13.scm",(void*)f_6543},
{"f_6597srfi-13.scm",(void*)f_6597},
{"f_6602srfi-13.scm",(void*)f_6602},
{"f_6618srfi-13.scm",(void*)f_6618},
{"f_6600srfi-13.scm",(void*)f_6600},
{"f_6531srfi-13.scm",(void*)f_6531},
{"f_6485srfi-13.scm",(void*)f_6485},
{"f_6497srfi-13.scm",(void*)f_6497},
{"f_6507srfi-13.scm",(void*)f_6507},
{"f_6491srfi-13.scm",(void*)f_6491},
{"f_6430srfi-13.scm",(void*)f_6430},
{"f_6442srfi-13.scm",(void*)f_6442},
{"f_6452srfi-13.scm",(void*)f_6452},
{"f_6436srfi-13.scm",(void*)f_6436},
{"f_6375srfi-13.scm",(void*)f_6375},
{"f_6387srfi-13.scm",(void*)f_6387},
{"f_6394srfi-13.scm",(void*)f_6394},
{"f_6403srfi-13.scm",(void*)f_6403},
{"f_6381srfi-13.scm",(void*)f_6381},
{"f_6372srfi-13.scm",(void*)f_6372},
{"f_6251srfi-13.scm",(void*)f_6251},
{"f_6275srfi-13.scm",(void*)f_6275},
{"f_6284srfi-13.scm",(void*)f_6284},
{"f_6316srfi-13.scm",(void*)f_6316},
{"f_6323srfi-13.scm",(void*)f_6323},
{"f_6314srfi-13.scm",(void*)f_6314},
{"f_6269srfi-13.scm",(void*)f_6269},
{"f_6213srfi-13.scm",(void*)f_6213},
{"f_6219srfi-13.scm",(void*)f_6219},
{"f_6226srfi-13.scm",(void*)f_6226},
{"f_6078srfi-13.scm",(void*)f_6078},
{"f_6096srfi-13.scm",(void*)f_6096},
{"f_6103srfi-13.scm",(void*)f_6103},
{"f_6120srfi-13.scm",(void*)f_6120},
{"f_6135srfi-13.scm",(void*)f_6135},
{"f_6168srfi-13.scm",(void*)f_6168},
{"f_6162srfi-13.scm",(void*)f_6162},
{"f_6106srfi-13.scm",(void*)f_6106},
{"f_6090srfi-13.scm",(void*)f_6090},
{"f_5980srfi-13.scm",(void*)f_5980},
{"f_5987srfi-13.scm",(void*)f_5987},
{"f_5996srfi-13.scm",(void*)f_5996},
{"f_6018srfi-13.scm",(void*)f_6018},
{"f_5918srfi-13.scm",(void*)f_5918},
{"f_5930srfi-13.scm",(void*)f_5930},
{"f_5942srfi-13.scm",(void*)f_5942},
{"f_5954srfi-13.scm",(void*)f_5954},
{"f_5967srfi-13.scm",(void*)f_5967},
{"f_5936srfi-13.scm",(void*)f_5936},
{"f_5924srfi-13.scm",(void*)f_5924},
{"f_5856srfi-13.scm",(void*)f_5856},
{"f_5868srfi-13.scm",(void*)f_5868},
{"f_5880srfi-13.scm",(void*)f_5880},
{"f_5892srfi-13.scm",(void*)f_5892},
{"f_5905srfi-13.scm",(void*)f_5905},
{"f_5874srfi-13.scm",(void*)f_5874},
{"f_5862srfi-13.scm",(void*)f_5862},
{"f_5775srfi-13.scm",(void*)f_5775},
{"f_5825srfi-13.scm",(void*)f_5825},
{"f_5787srfi-13.scm",(void*)f_5787},
{"f_5743srfi-13.scm",(void*)f_5743},
{"f_5755srfi-13.scm",(void*)f_5755},
{"f_5762srfi-13.scm",(void*)f_5762},
{"f_5749srfi-13.scm",(void*)f_5749},
{"f_5702srfi-13.scm",(void*)f_5702},
{"f_5714srfi-13.scm",(void*)f_5714},
{"f_5724srfi-13.scm",(void*)f_5724},
{"f_5708srfi-13.scm",(void*)f_5708},
{"f_5567srfi-13.scm",(void*)f_5567},
{"f_5579srfi-13.scm",(void*)f_5579},
{"f_5625srfi-13.scm",(void*)f_5625},
{"f_5669srfi-13.scm",(void*)f_5669},
{"f_5690srfi-13.scm",(void*)f_5690},
{"f_5630srfi-13.scm",(void*)f_5630},
{"f_5651srfi-13.scm",(void*)f_5651},
{"f_5591srfi-13.scm",(void*)f_5591},
{"f_5573srfi-13.scm",(void*)f_5573},
{"f_5432srfi-13.scm",(void*)f_5432},
{"f_5444srfi-13.scm",(void*)f_5444},
{"f_5490srfi-13.scm",(void*)f_5490},
{"f_5538srfi-13.scm",(void*)f_5538},
{"f_5551srfi-13.scm",(void*)f_5551},
{"f_5499srfi-13.scm",(void*)f_5499},
{"f_5512srfi-13.scm",(void*)f_5512},
{"f_5460srfi-13.scm",(void*)f_5460},
{"f_5438srfi-13.scm",(void*)f_5438},
{"f_5309srfi-13.scm",(void*)f_5309},
{"f_5321srfi-13.scm",(void*)f_5321},
{"f_5363srfi-13.scm",(void*)f_5363},
{"f_5403srfi-13.scm",(void*)f_5403},
{"f_5416srfi-13.scm",(void*)f_5416},
{"f_5368srfi-13.scm",(void*)f_5368},
{"f_5381srfi-13.scm",(void*)f_5381},
{"f_5333srfi-13.scm",(void*)f_5333},
{"f_5315srfi-13.scm",(void*)f_5315},
{"f_5174srfi-13.scm",(void*)f_5174},
{"f_5186srfi-13.scm",(void*)f_5186},
{"f_5232srfi-13.scm",(void*)f_5232},
{"f_5280srfi-13.scm",(void*)f_5280},
{"f_5293srfi-13.scm",(void*)f_5293},
{"f_5241srfi-13.scm",(void*)f_5241},
{"f_5254srfi-13.scm",(void*)f_5254},
{"f_5202srfi-13.scm",(void*)f_5202},
{"f_5180srfi-13.scm",(void*)f_5180},
{"f_5051srfi-13.scm",(void*)f_5051},
{"f_5063srfi-13.scm",(void*)f_5063},
{"f_5105srfi-13.scm",(void*)f_5105},
{"f_5145srfi-13.scm",(void*)f_5145},
{"f_5158srfi-13.scm",(void*)f_5158},
{"f_5110srfi-13.scm",(void*)f_5110},
{"f_5123srfi-13.scm",(void*)f_5123},
{"f_5075srfi-13.scm",(void*)f_5075},
{"f_5057srfi-13.scm",(void*)f_5057},
{"f_4943srfi-13.scm",(void*)f_4943},
{"f_4955srfi-13.scm",(void*)f_4955},
{"f_5037srfi-13.scm",(void*)f_5037},
{"f_4998srfi-13.scm",(void*)f_4998},
{"f_5024srfi-13.scm",(void*)f_5024},
{"f_5031srfi-13.scm",(void*)f_5031},
{"f_5001srfi-13.scm",(void*)f_5001},
{"f_5004srfi-13.scm",(void*)f_5004},
{"f_5009srfi-13.scm",(void*)f_5009},
{"f_5016srfi-13.scm",(void*)f_5016},
{"f_5007srfi-13.scm",(void*)f_5007},
{"f_4968srfi-13.scm",(void*)f_4968},
{"f_4982srfi-13.scm",(void*)f_4982},
{"f_4989srfi-13.scm",(void*)f_4989},
{"f_4971srfi-13.scm",(void*)f_4971},
{"f_4949srfi-13.scm",(void*)f_4949},
{"f_4835srfi-13.scm",(void*)f_4835},
{"f_4847srfi-13.scm",(void*)f_4847},
{"f_4929srfi-13.scm",(void*)f_4929},
{"f_4890srfi-13.scm",(void*)f_4890},
{"f_4916srfi-13.scm",(void*)f_4916},
{"f_4923srfi-13.scm",(void*)f_4923},
{"f_4893srfi-13.scm",(void*)f_4893},
{"f_4896srfi-13.scm",(void*)f_4896},
{"f_4901srfi-13.scm",(void*)f_4901},
{"f_4908srfi-13.scm",(void*)f_4908},
{"f_4899srfi-13.scm",(void*)f_4899},
{"f_4860srfi-13.scm",(void*)f_4860},
{"f_4874srfi-13.scm",(void*)f_4874},
{"f_4881srfi-13.scm",(void*)f_4881},
{"f_4863srfi-13.scm",(void*)f_4863},
{"f_4841srfi-13.scm",(void*)f_4841},
{"f_4773srfi-13.scm",(void*)f_4773},
{"f_4794srfi-13.scm",(void*)f_4794},
{"f_4814srfi-13.scm",(void*)f_4814},
{"f_4817srfi-13.scm",(void*)f_4817},
{"f_4788srfi-13.scm",(void*)f_4788},
{"f_4715srfi-13.scm",(void*)f_4715},
{"f_4736srfi-13.scm",(void*)f_4736},
{"f_4756srfi-13.scm",(void*)f_4756},
{"f_4759srfi-13.scm",(void*)f_4759},
{"f_4730srfi-13.scm",(void*)f_4730},
{"f_4665srfi-13.scm",(void*)f_4665},
{"f_4683srfi-13.scm",(void*)f_4683},
{"f_4687srfi-13.scm",(void*)f_4687},
{"f_4701srfi-13.scm",(void*)f_4701},
{"f_4677srfi-13.scm",(void*)f_4677},
{"f_4619srfi-13.scm",(void*)f_4619},
{"f_4637srfi-13.scm",(void*)f_4637},
{"f_4641srfi-13.scm",(void*)f_4641},
{"f_4631srfi-13.scm",(void*)f_4631},
{"f_4577srfi-13.scm",(void*)f_4577},
{"f_4595srfi-13.scm",(void*)f_4595},
{"f_4599srfi-13.scm",(void*)f_4599},
{"f_4589srfi-13.scm",(void*)f_4589},
{"f_4550srfi-13.scm",(void*)f_4550},
{"f_4557srfi-13.scm",(void*)f_4557},
{"f_4527srfi-13.scm",(void*)f_4527},
{"f_4534srfi-13.scm",(void*)f_4534},
{"f_4500srfi-13.scm",(void*)f_4500},
{"f_4507srfi-13.scm",(void*)f_4507},
{"f_4480srfi-13.scm",(void*)f_4480},
{"f_4487srfi-13.scm",(void*)f_4487},
{"f_4455srfi-13.scm",(void*)f_4455},
{"f_4467srfi-13.scm",(void*)f_4467},
{"f_4471srfi-13.scm",(void*)f_4471},
{"f_4474srfi-13.scm",(void*)f_4474},
{"f_4461srfi-13.scm",(void*)f_4461},
{"f_4437srfi-13.scm",(void*)f_4437},
{"f_4449srfi-13.scm",(void*)f_4449},
{"f_4443srfi-13.scm",(void*)f_4443},
{"f_4378srfi-13.scm",(void*)f_4378},
{"f_4384srfi-13.scm",(void*)f_4384},
{"f_4431srfi-13.scm",(void*)f_4431},
{"f_4388srfi-13.scm",(void*)f_4388},
{"f_4418srfi-13.scm",(void*)f_4418},
{"f_4400srfi-13.scm",(void*)f_4400},
{"f_4406srfi-13.scm",(void*)f_4406},
{"f_4360srfi-13.scm",(void*)f_4360},
{"f_4372srfi-13.scm",(void*)f_4372},
{"f_4366srfi-13.scm",(void*)f_4366},
{"f_4342srfi-13.scm",(void*)f_4342},
{"f_4354srfi-13.scm",(void*)f_4354},
{"f_4348srfi-13.scm",(void*)f_4348},
{"f_4324srfi-13.scm",(void*)f_4324},
{"f_4336srfi-13.scm",(void*)f_4336},
{"f_4330srfi-13.scm",(void*)f_4330},
{"f_4306srfi-13.scm",(void*)f_4306},
{"f_4318srfi-13.scm",(void*)f_4318},
{"f_4312srfi-13.scm",(void*)f_4312},
{"f_4250srfi-13.scm",(void*)f_4250},
{"f_4260srfi-13.scm",(void*)f_4260},
{"f_4274srfi-13.scm",(void*)f_4274},
{"f_4280srfi-13.scm",(void*)f_4280},
{"f_4268srfi-13.scm",(void*)f_4268},
{"f_4204srfi-13.scm",(void*)f_4204},
{"f_4214srfi-13.scm",(void*)f_4214},
{"f_4228srfi-13.scm",(void*)f_4228},
{"f_4222srfi-13.scm",(void*)f_4222},
{"f_4132srfi-13.scm",(void*)f_4132},
{"f_4150srfi-13.scm",(void*)f_4150},
{"f_4183srfi-13.scm",(void*)f_4183},
{"f_4185srfi-13.scm",(void*)f_4185},
{"f_4134srfi-13.scm",(void*)f_4134},
{"f_4084srfi-13.scm",(void*)f_4084},
{"f_4096srfi-13.scm",(void*)f_4096},
{"f_4108srfi-13.scm",(void*)f_4108},
{"f_4115srfi-13.scm",(void*)f_4115},
{"f_4123srfi-13.scm",(void*)f_4123},
{"f_4102srfi-13.scm",(void*)f_4102},
{"f_4090srfi-13.scm",(void*)f_4090},
{"f_4036srfi-13.scm",(void*)f_4036},
{"f_4048srfi-13.scm",(void*)f_4048},
{"f_4060srfi-13.scm",(void*)f_4060},
{"f_4067srfi-13.scm",(void*)f_4067},
{"f_4075srfi-13.scm",(void*)f_4075},
{"f_4054srfi-13.scm",(void*)f_4054},
{"f_4042srfi-13.scm",(void*)f_4042},
{"f_3985srfi-13.scm",(void*)f_3985},
{"f_3997srfi-13.scm",(void*)f_3997},
{"f_4009srfi-13.scm",(void*)f_4009},
{"f_4016srfi-13.scm",(void*)f_4016},
{"f_4027srfi-13.scm",(void*)f_4027},
{"f_4024srfi-13.scm",(void*)f_4024},
{"f_4003srfi-13.scm",(void*)f_4003},
{"f_3991srfi-13.scm",(void*)f_3991},
{"f_3934srfi-13.scm",(void*)f_3934},
{"f_3946srfi-13.scm",(void*)f_3946},
{"f_3958srfi-13.scm",(void*)f_3958},
{"f_3965srfi-13.scm",(void*)f_3965},
{"f_3976srfi-13.scm",(void*)f_3976},
{"f_3973srfi-13.scm",(void*)f_3973},
{"f_3952srfi-13.scm",(void*)f_3952},
{"f_3940srfi-13.scm",(void*)f_3940},
{"f_3867srfi-13.scm",(void*)f_3867},
{"f_3879srfi-13.scm",(void*)f_3879},
{"f_3891srfi-13.scm",(void*)f_3891},
{"f_3914srfi-13.scm",(void*)f_3914},
{"f_3909srfi-13.scm",(void*)f_3909},
{"f_3885srfi-13.scm",(void*)f_3885},
{"f_3873srfi-13.scm",(void*)f_3873},
{"f_3805srfi-13.scm",(void*)f_3805},
{"f_3817srfi-13.scm",(void*)f_3817},
{"f_3829srfi-13.scm",(void*)f_3829},
{"f_3839srfi-13.scm",(void*)f_3839},
{"f_3850srfi-13.scm",(void*)f_3850},
{"f_3847srfi-13.scm",(void*)f_3847},
{"f_3823srfi-13.scm",(void*)f_3823},
{"f_3811srfi-13.scm",(void*)f_3811},
{"f_3757srfi-13.scm",(void*)f_3757},
{"f_3769srfi-13.scm",(void*)f_3769},
{"f_3781srfi-13.scm",(void*)f_3781},
{"f_3788srfi-13.scm",(void*)f_3788},
{"f_3796srfi-13.scm",(void*)f_3796},
{"f_3775srfi-13.scm",(void*)f_3775},
{"f_3763srfi-13.scm",(void*)f_3763},
{"f_3709srfi-13.scm",(void*)f_3709},
{"f_3721srfi-13.scm",(void*)f_3721},
{"f_3733srfi-13.scm",(void*)f_3733},
{"f_3740srfi-13.scm",(void*)f_3740},
{"f_3748srfi-13.scm",(void*)f_3748},
{"f_3727srfi-13.scm",(void*)f_3727},
{"f_3715srfi-13.scm",(void*)f_3715},
{"f_3658srfi-13.scm",(void*)f_3658},
{"f_3670srfi-13.scm",(void*)f_3670},
{"f_3682srfi-13.scm",(void*)f_3682},
{"f_3689srfi-13.scm",(void*)f_3689},
{"f_3700srfi-13.scm",(void*)f_3700},
{"f_3697srfi-13.scm",(void*)f_3697},
{"f_3676srfi-13.scm",(void*)f_3676},
{"f_3664srfi-13.scm",(void*)f_3664},
{"f_3607srfi-13.scm",(void*)f_3607},
{"f_3619srfi-13.scm",(void*)f_3619},
{"f_3631srfi-13.scm",(void*)f_3631},
{"f_3638srfi-13.scm",(void*)f_3638},
{"f_3649srfi-13.scm",(void*)f_3649},
{"f_3646srfi-13.scm",(void*)f_3646},
{"f_3625srfi-13.scm",(void*)f_3625},
{"f_3613srfi-13.scm",(void*)f_3613},
{"f_3540srfi-13.scm",(void*)f_3540},
{"f_3552srfi-13.scm",(void*)f_3552},
{"f_3564srfi-13.scm",(void*)f_3564},
{"f_3587srfi-13.scm",(void*)f_3587},
{"f_3582srfi-13.scm",(void*)f_3582},
{"f_3558srfi-13.scm",(void*)f_3558},
{"f_3546srfi-13.scm",(void*)f_3546},
{"f_3478srfi-13.scm",(void*)f_3478},
{"f_3490srfi-13.scm",(void*)f_3490},
{"f_3502srfi-13.scm",(void*)f_3502},
{"f_3512srfi-13.scm",(void*)f_3512},
{"f_3523srfi-13.scm",(void*)f_3523},
{"f_3520srfi-13.scm",(void*)f_3520},
{"f_3496srfi-13.scm",(void*)f_3496},
{"f_3484srfi-13.scm",(void*)f_3484},
{"f_3448srfi-13.scm",(void*)f_3448},
{"f_3460srfi-13.scm",(void*)f_3460},
{"f_3472srfi-13.scm",(void*)f_3472},
{"f_3466srfi-13.scm",(void*)f_3466},
{"f_3454srfi-13.scm",(void*)f_3454},
{"f_3418srfi-13.scm",(void*)f_3418},
{"f_3430srfi-13.scm",(void*)f_3430},
{"f_3442srfi-13.scm",(void*)f_3442},
{"f_3436srfi-13.scm",(void*)f_3436},
{"f_3424srfi-13.scm",(void*)f_3424},
{"f_3356srfi-13.scm",(void*)f_3356},
{"f_3366srfi-13.scm",(void*)f_3366},
{"f_3400srfi-13.scm",(void*)f_3400},
{"f_3391srfi-13.scm",(void*)f_3391},
{"f_3294srfi-13.scm",(void*)f_3294},
{"f_3304srfi-13.scm",(void*)f_3304},
{"f_3329srfi-13.scm",(void*)f_3329},
{"f_3172srfi-13.scm",(void*)f_3172},
{"f_3184srfi-13.scm",(void*)f_3184},
{"f_3196srfi-13.scm",(void*)f_3196},
{"f_3288srfi-13.scm",(void*)f_3288},
{"f_3190srfi-13.scm",(void*)f_3190},
{"f_3178srfi-13.scm",(void*)f_3178},
{"f_3142srfi-13.scm",(void*)f_3142},
{"f_3154srfi-13.scm",(void*)f_3154},
{"f_3166srfi-13.scm",(void*)f_3166},
{"f_3265srfi-13.scm",(void*)f_3265},
{"f_3160srfi-13.scm",(void*)f_3160},
{"f_3148srfi-13.scm",(void*)f_3148},
{"f_3112srfi-13.scm",(void*)f_3112},
{"f_3124srfi-13.scm",(void*)f_3124},
{"f_3136srfi-13.scm",(void*)f_3136},
{"f_3242srfi-13.scm",(void*)f_3242},
{"f_3130srfi-13.scm",(void*)f_3130},
{"f_3118srfi-13.scm",(void*)f_3118},
{"f_3082srfi-13.scm",(void*)f_3082},
{"f_3094srfi-13.scm",(void*)f_3094},
{"f_3106srfi-13.scm",(void*)f_3106},
{"f_3219srfi-13.scm",(void*)f_3219},
{"f_3100srfi-13.scm",(void*)f_3100},
{"f_3088srfi-13.scm",(void*)f_3088},
{"f_3052srfi-13.scm",(void*)f_3052},
{"f_3064srfi-13.scm",(void*)f_3064},
{"f_3076srfi-13.scm",(void*)f_3076},
{"f_3070srfi-13.scm",(void*)f_3070},
{"f_3058srfi-13.scm",(void*)f_3058},
{"f_3022srfi-13.scm",(void*)f_3022},
{"f_3034srfi-13.scm",(void*)f_3034},
{"f_3046srfi-13.scm",(void*)f_3046},
{"f_3040srfi-13.scm",(void*)f_3040},
{"f_3028srfi-13.scm",(void*)f_3028},
{"f_2992srfi-13.scm",(void*)f_2992},
{"f_3004srfi-13.scm",(void*)f_3004},
{"f_3016srfi-13.scm",(void*)f_3016},
{"f_3010srfi-13.scm",(void*)f_3010},
{"f_2998srfi-13.scm",(void*)f_2998},
{"f_2962srfi-13.scm",(void*)f_2962},
{"f_2974srfi-13.scm",(void*)f_2974},
{"f_2986srfi-13.scm",(void*)f_2986},
{"f_2980srfi-13.scm",(void*)f_2980},
{"f_2968srfi-13.scm",(void*)f_2968},
{"f_2877srfi-13.scm",(void*)f_2877},
{"f_2881srfi-13.scm",(void*)f_2881},
{"f_2890srfi-13.scm",(void*)f_2890},
{"f_2903srfi-13.scm",(void*)f_2903},
{"f_2938srfi-13.scm",(void*)f_2938},
{"f_2913srfi-13.scm",(void*)f_2913},
{"f_2804srfi-13.scm",(void*)f_2804},
{"f_2808srfi-13.scm",(void*)f_2808},
{"f_2817srfi-13.scm",(void*)f_2817},
{"f_2822srfi-13.scm",(void*)f_2822},
{"f_2853srfi-13.scm",(void*)f_2853},
{"f_2832srfi-13.scm",(void*)f_2832},
{"f_2719srfi-13.scm",(void*)f_2719},
{"f_2723srfi-13.scm",(void*)f_2723},
{"f_2732srfi-13.scm",(void*)f_2732},
{"f_2745srfi-13.scm",(void*)f_2745},
{"f_2755srfi-13.scm",(void*)f_2755},
{"f_2646srfi-13.scm",(void*)f_2646},
{"f_2650srfi-13.scm",(void*)f_2650},
{"f_2659srfi-13.scm",(void*)f_2659},
{"f_2664srfi-13.scm",(void*)f_2664},
{"f_2674srfi-13.scm",(void*)f_2674},
{"f_2607srfi-13.scm",(void*)f_2607},
{"f_2614srfi-13.scm",(void*)f_2614},
{"f_2623srfi-13.scm",(void*)f_2623},
{"f_2644srfi-13.scm",(void*)f_2644},
{"f_2617srfi-13.scm",(void*)f_2617},
{"f_2477srfi-13.scm",(void*)f_2477},
{"f_2489srfi-13.scm",(void*)f_2489},
{"f_2531srfi-13.scm",(void*)f_2531},
{"f_2577srfi-13.scm",(void*)f_2577},
{"f_2596srfi-13.scm",(void*)f_2596},
{"f_2536srfi-13.scm",(void*)f_2536},
{"f_2546srfi-13.scm",(void*)f_2546},
{"f_2501srfi-13.scm",(void*)f_2501},
{"f_2483srfi-13.scm",(void*)f_2483},
{"f_2347srfi-13.scm",(void*)f_2347},
{"f_2359srfi-13.scm",(void*)f_2359},
{"f_2401srfi-13.scm",(void*)f_2401},
{"f_2447srfi-13.scm",(void*)f_2447},
{"f_2469srfi-13.scm",(void*)f_2469},
{"f_2406srfi-13.scm",(void*)f_2406},
{"f_2419srfi-13.scm",(void*)f_2419},
{"f_2371srfi-13.scm",(void*)f_2371},
{"f_2353srfi-13.scm",(void*)f_2353},
{"f_2310srfi-13.scm",(void*)f_2310},
{"f_2322srfi-13.scm",(void*)f_2322},
{"f_2328srfi-13.scm",(void*)f_2328},
{"f_2338srfi-13.scm",(void*)f_2338},
{"f_2316srfi-13.scm",(void*)f_2316},
{"f_2269srfi-13.scm",(void*)f_2269},
{"f_2281srfi-13.scm",(void*)f_2281},
{"f_2287srfi-13.scm",(void*)f_2287},
{"f_2297srfi-13.scm",(void*)f_2297},
{"f_2275srfi-13.scm",(void*)f_2275},
{"f_2080srfi-13.scm",(void*)f_2080},
{"f_2106srfi-13.scm",(void*)f_2106},
{"f_2108srfi-13.scm",(void*)f_2108},
{"f_2114srfi-13.scm",(void*)f_2114},
{"f_2238srfi-13.scm",(void*)f_2238},
{"f_2124srfi-13.scm",(void*)f_2124},
{"f_2127srfi-13.scm",(void*)f_2127},
{"f_2148srfi-13.scm",(void*)f_2148},
{"f_2151srfi-13.scm",(void*)f_2151},
{"f_2171srfi-13.scm",(void*)f_2171},
{"f_2186srfi-13.scm",(void*)f_2186},
{"f_2189srfi-13.scm",(void*)f_2189},
{"f_2192srfi-13.scm",(void*)f_2192},
{"f_2201srfi-13.scm",(void*)f_2201},
{"f_2220srfi-13.scm",(void*)f_2220},
{"f_2195srfi-13.scm",(void*)f_2195},
{"f_2251srfi-13.scm",(void*)f_2251},
{"f_1898srfi-13.scm",(void*)f_1898},
{"f_1924srfi-13.scm",(void*)f_1924},
{"f_1926srfi-13.scm",(void*)f_1926},
{"f_1932srfi-13.scm",(void*)f_1932},
{"f_2049srfi-13.scm",(void*)f_2049},
{"f_1942srfi-13.scm",(void*)f_1942},
{"f_1945srfi-13.scm",(void*)f_1945},
{"f_1967srfi-13.scm",(void*)f_1967},
{"f_1970srfi-13.scm",(void*)f_1970},
{"f_1987srfi-13.scm",(void*)f_1987},
{"f_1999srfi-13.scm",(void*)f_1999},
{"f_2002srfi-13.scm",(void*)f_2002},
{"f_2008srfi-13.scm",(void*)f_2008},
{"f_2016srfi-13.scm",(void*)f_2016},
{"f_2038srfi-13.scm",(void*)f_2038},
{"f_2011srfi-13.scm",(void*)f_2011},
{"f_2014srfi-13.scm",(void*)f_2014},
{"f_2062srfi-13.scm",(void*)f_2062},
{"f_1852srfi-13.scm",(void*)f_1852},
{"f_1864srfi-13.scm",(void*)f_1864},
{"f_1874srfi-13.scm",(void*)f_1874},
{"f_1888srfi-13.scm",(void*)f_1888},
{"f_1858srfi-13.scm",(void*)f_1858},
{"f_1810srfi-13.scm",(void*)f_1810},
{"f_1822srfi-13.scm",(void*)f_1822},
{"f_1828srfi-13.scm",(void*)f_1828},
{"f_1842srfi-13.scm",(void*)f_1842},
{"f_1816srfi-13.scm",(void*)f_1816},
{"f_1777srfi-13.scm",(void*)f_1777},
{"f_1783srfi-13.scm",(void*)f_1783},
{"f_1804srfi-13.scm",(void*)f_1804},
{"f_1759srfi-13.scm",(void*)f_1759},
{"f_1771srfi-13.scm",(void*)f_1771},
{"f_1765srfi-13.scm",(void*)f_1765},
{"f_1716srfi-13.scm",(void*)f_1716},
{"f_1723srfi-13.scm",(void*)f_1723},
{"f_1728srfi-13.scm",(void*)f_1728},
{"f_1753srfi-13.scm",(void*)f_1753},
{"f_1726srfi-13.scm",(void*)f_1726},
{"f_1698srfi-13.scm",(void*)f_1698},
{"f_1710srfi-13.scm",(void*)f_1710},
{"f_1704srfi-13.scm",(void*)f_1704},
{"f_1680srfi-13.scm",(void*)f_1680},
{"f_1692srfi-13.scm",(void*)f_1692},
{"f_1686srfi-13.scm",(void*)f_1686},
{"f_1658srfi-13.scm",(void*)f_1658},
{"f_1665srfi-13.scm",(void*)f_1665},
{"f_1621srfi-13.scm",(void*)f_1621},
{"f_1628srfi-13.scm",(void*)f_1628},
{"f_1634srfi-13.scm",(void*)f_1634},
{"f_1605srfi-13.scm",(void*)f_1605},
{"f_1619srfi-13.scm",(void*)f_1619},
{"f_1565srfi-13.scm",(void*)f_1565},
{"f_1538srfi-13.scm",(void*)f_1538},
{"f_1550srfi-13.scm",(void*)f_1550},
{"f_1544srfi-13.scm",(void*)f_1544},
{"f_1445srfi-13.scm",(void*)f_1445},
{"f_1511srfi-13.scm",(void*)f_1511},
{"f_1475srfi-13.scm",(void*)f_1475},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
