/* Generated from extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-05-13 09:14
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   SVN rev. 10674	compiled 2008-04-30 on debian (Linux)
   command line: extras.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file extras.c -extend private-namespace.scm
   unit: extras
*/

#include "chicken.h"

#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[136];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,19),40,100,111,50,49,32,120,50,51,32,105,50,52,32,120,115,50,53,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,115,108,117,114,112,32,112,111,114,116,50,48,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,57,32,112,111,114,116,49,54,32,114,101,97,100,101,114,49,55,32,109,97,120,49,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,31),40,100,101,102,45,109,97,120,49,51,32,37,112,111,114,116,54,51,49,32,37,114,101,97,100,101,114,55,51,50,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,114,101,97,100,101,114,49,50,32,37,112,111,114,116,54,51,52,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,112,111,114,116,49,49,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,17),40,114,101,97,100,45,102,105,108,101,32,46,32,103,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,19),40,114,97,110,100,111,109,45,115,101,101,100,32,46,32,110,52,56,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,12),40,114,97,110,100,111,109,32,110,53,50,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,17),40,114,97,110,100,111,109,105,122,101,32,46,32,110,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,10),40,108,111,111,112,32,105,55,49,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,20),40,114,101,97,100,45,108,105,110,101,32,46,32,97,114,103,115,54,49,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,110,115,57,51,32,110,57,52,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,15),40,100,111,114,101,97,100,32,112,111,114,116,57,49,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,108,105,110,101,115,32,46,32,112,111,114,116,45,97,110,100,45,109,97,120,56,54,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,115,116,97,114,116,49,48,56,32,110,49,48,57,32,109,49,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,33,32,110,49,48,49,32,100,101,115,116,49,48,50,32,112,111,114,116,49,48,51,32,115,116,97,114,116,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,49,50,52,32,112,111,114,116,49,51,48,32,115,116,97,114,116,49,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,115,116,97,114,116,49,50,55,32,37,112,111,114,116,49,50,50,49,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,49,50,54,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,37),40,114,101,97,100,45,115,116,114,105,110,103,33,32,110,49,49,57,32,100,101,115,116,49,50,48,32,46,32,103,49,49,56,49,50,49,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,49,53,51,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,47,112,111,114,116,32,110,49,52,54,32,112,49,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,49,54,52,32,110,49,55,48,32,112,111,114,116,49,55,49,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,111,114,116,49,54,55,32,37,110,49,54,50,49,55,51,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,23),40,114,101,97,100,45,115,116,114,105,110,103,32,46,32,103,49,54,48,49,54,49,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,116,111,107,101,110,32,112,114,101,100,49,56,49,32,46,32,112,111,114,116,49,56,50,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,49,57,55,32,110,50,48,51,32,112,111,114,116,50,48,52,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,111,114,116,50,48,48,32,37,110,49,57,53,50,48,56,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,115,116,114,105,110,103,32,115,49,57,51,32,46,32,109,111,114,101,49,57,52,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,108,105,110,101,32,115,116,114,50,49,55,32,46,32,112,111,114,116,50,49,56,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,21),40,114,101,97,100,45,98,121,116,101,32,46,32,103,50,50,51,50,50,52,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,30),40,119,114,105,116,101,45,98,121,116,101,32,98,121,116,101,50,51,49,32,46,32,103,50,51,48,50,51,50,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,18),40,114,101,97,100,45,109,97,99,114,111,63,32,108,50,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,17),40,114,101,97,100,45,109,97,99,114,111,45,98,111,100,121,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,109,97,99,114,111,45,112,114,101,102,105,120,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,19),40,111,117,116,32,115,116,114,50,55,48,32,99,111,108,50,55,49,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,50,56,49,32,99,111,108,50,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,119,114,45,108,115,116,32,108,50,55,56,32,99,111,108,50,55,57,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,24),40,119,114,45,101,120,112,114,32,101,120,112,114,50,55,54,32,99,111,108,50,55,55,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,105,50,56,55,32,106,50,56,56,32,99,111,108,50,56,57,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,18),40,119,114,32,111,98,106,50,55,50,32,99,111,108,50,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,115,112,97,99,101,115,32,110,51,51,50,32,99,111,108,51,51,51,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,105,110,100,101,110,116,32,116,111,51,51,52,32,99,111,108,51,51,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,14),40,97,50,51,55,55,32,115,116,114,51,52,52,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,38),40,112,114,32,111,98,106,51,51,54,32,99,111,108,51,51,55,32,101,120,116,114,97,51,51,56,32,112,112,45,112,97,105,114,51,51,57,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,33),40,112,112,45,101,120,112,114,32,101,120,112,114,51,52,56,32,99,111,108,51,52,57,32,101,120,116,114,97,51,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,44),40,112,112,45,99,97,108,108,32,101,120,112,114,51,53,51,32,99,111,108,51,53,52,32,101,120,116,114,97,51,53,53,32,112,112,45,105,116,101,109,51,53,54,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,41),40,112,112,45,108,105,115,116,32,108,51,53,56,32,99,111,108,51,53,57,32,101,120,116,114,97,51,54,48,32,112,112,45,105,116,101,109,51,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,51,54,57,32,99,111,108,51,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,50),40,112,112,45,100,111,119,110,32,108,51,54,51,32,99,111,108,49,51,54,52,32,99,111,108,50,51,54,53,32,101,120,116,114,97,51,54,54,32,112,112,45,105,116,101,109,51,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,31),40,116,97,105,108,51,32,114,101,115,116,51,57,56,32,99,111,108,49,51,57,57,32,99,111,108,50,52,48,48,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,50,32,114,101,115,116,51,57,49,32,99,111,108,49,51,57,50,32,99,111,108,50,51,57,51,32,99,111,108,51,51,57,52,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,49,32,114,101,115,116,51,56,52,32,99,111,108,49,51,56,53,32,99,111,108,50,51,56,54,32,99,111,108,51,51,56,55,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,70),40,112,112,45,103,101,110,101,114,97,108,32,101,120,112,114,51,55,52,32,99,111,108,51,55,53,32,101,120,116,114,97,51,55,54,32,110,97,109,101,100,63,51,55,55,32,112,112,45,49,51,55,56,32,112,112,45,50,51,55,57,32,112,112,45,51,51,56,48,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,35),40,112,112,45,101,120,112,114,45,108,105,115,116,32,108,52,49,48,32,99,111,108,52,49,49,32,101,120,116,114,97,52,49,50,41,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,35),40,112,112,45,108,97,109,98,100,97,32,101,120,112,114,52,49,51,32,99,111,108,52,49,52,32,101,120,116,114,97,52,49,53,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,31),40,112,112,45,105,102,32,101,120,112,114,52,49,54,32,99,111,108,52,49,55,32,101,120,116,114,97,52,49,56,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,111,110,100,32,101,120,112,114,52,49,57,32,99,111,108,52,50,48,32,101,120,116,114,97,52,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,97,115,101,32,101,120,112,114,52,50,50,32,99,111,108,52,50,51,32,101,120,116,114,97,52,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,32),40,112,112,45,97,110,100,32,101,120,112,114,52,50,53,32,99,111,108,52,50,54,32,101,120,116,114,97,52,50,55,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,32),40,112,112,45,108,101,116,32,101,120,112,114,52,50,56,32,99,111,108,52,50,57,32,101,120,116,114,97,52,51,48,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,34),40,112,112,45,98,101,103,105,110,32,101,120,112,114,52,51,51,32,99,111,108,52,51,52,32,101,120,116,114,97,52,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,31),40,112,112,45,100,111,32,101,120,112,114,52,51,54,32,99,111,108,52,51,55,32,101,120,116,114,97,52,51,56,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,15),40,115,116,121,108,101,32,104,101,97,100,52,51,57,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,18),40,112,112,32,111,98,106,51,48,57,32,99,111,108,51,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,62),40,35,35,101,120,116,114,97,115,35,103,101,110,101,114,105,99,45,119,114,105,116,101,32,111,98,106,50,52,48,32,100,105,115,112,108,97,121,63,50,52,49,32,119,105,100,116,104,50,52,50,32,111,117,116,112,117,116,50,52,51,41,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,106,52,56,55,32,107,52,56,56,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,29),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,52,56,49,32,105,52,56,50,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,37),40,35,35,101,120,116,114,97,115,35,114,101,118,101,114,115,101,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,52,55,57,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,12),40,97,51,48,48,56,32,115,52,57,53,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,30),40,112,114,101,116,116,121,45,112,114,105,110,116,32,111,98,106,52,57,50,32,46,32,111,112,116,52,57,51,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,6),40,110,101,120,116,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,6),40,115,107,105,112,41,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,20),40,114,101,99,32,109,115,103,53,48,57,32,97,114,103,115,53,49,48,41,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,49),40,35,35,101,120,116,114,97,115,35,102,112,114,105,110,116,102,48,32,108,111,99,53,48,51,32,112,111,114,116,53,48,52,32,109,115,103,53,48,53,32,97,114,103,115,53,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,35),40,102,112,114,105,110,116,102,32,112,111,114,116,53,52,48,32,102,115,116,114,53,52,49,32,46,32,97,114,103,115,53,52,50,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,26),40,112,114,105,110,116,102,32,102,115,116,114,53,52,51,32,46,32,97,114,103,115,53,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,27),40,115,112,114,105,110,116,102,32,102,115,116,114,53,52,53,32,46,32,97,114,103,115,53,52,54,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,32),40,102,111,114,109,97,116,32,102,109,116,45,111,114,45,100,115,116,53,53,48,32,46,32,97,114,103,115,53,53,49,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k736 */
static C_word C_fcall stub45(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub45(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned int t0=(unsigned int )C_num_to_unsigned_int(C_a0);
srand(t0);
return C_r;}

C_noret_decl(C_extras_toplevel)
C_externexport void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_590)
static void C_ccall f_590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3098)
static void C_fcall f_3098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static C_word C_fcall f_3276(C_word t0,C_word t1);
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_fcall f_3053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static C_word C_fcall f_3046(C_word t0);
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2918)
static void C_fcall f_2918(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_fcall f_2943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_fcall f_2259(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2814)
static void C_fcall f_2814(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2824)
static void C_fcall f_2824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2784)
static void C_fcall f_2784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2593)
static void C_fcall f_2593(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_fcall f_2596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_fcall f_2637(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_fcall f_2678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2516)
static void C_fcall f_2516(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2522)
static void C_fcall f_2522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_fcall f_2507(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_fcall f_2479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_fcall f_2295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_fcall f_2262(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_fcall f_1756(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_fcall f_1995(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2002)
static void C_fcall f_2002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_fcall f_1759(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_fcall f_1806(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_fcall f_1737(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static C_word C_fcall f_1704(C_word t0);
C_noret_decl(f_1698)
static C_word C_fcall f_1698(C_word t0);
C_noret_decl(f_1646)
static void C_fcall f_1646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_fcall f_1678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1496)
static void C_fcall f_1496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1460)
static void C_fcall f_1460(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_fcall f_1477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_fcall f_1401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1338)
static void C_fcall f_1338(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_fcall f_1333(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1328)
static void C_fcall f_1328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_fcall f_1286(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_fcall f_1200(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1158)
static void C_fcall f_1158(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_fcall f_1168(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_fcall f_1076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_fcall f_1084(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_998)
static void C_fcall f_998(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_842)
static void C_fcall f_842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_860)
static void C_ccall f_860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_865)
static void C_fcall f_865(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_929)
static void C_fcall f_929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_789)
static void C_ccall f_789(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_789)
static void C_ccall f_789r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_794)
static void C_fcall f_794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_598)
static void C_ccall f_598(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_598)
static void C_ccall f_598r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_670)
static void C_fcall f_670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_665)
static void C_fcall f_665(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_660)
static void C_fcall f_660(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_600)
static void C_fcall f_600(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_653)
static void C_ccall f_653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_fcall f_613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3037)
static void C_fcall trf_3037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3037(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3037(t0,t1,t2,t3);}

C_noret_decl(trf_3098)
static void C_fcall trf_3098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3098(t0,t1);}

C_noret_decl(trf_3053)
static void C_fcall trf_3053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3053(t0,t1);}

C_noret_decl(trf_2918)
static void C_fcall trf_2918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2918(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2918(t0,t1,t2,t3);}

C_noret_decl(trf_2943)
static void C_fcall trf_2943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2943(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2943(t0,t1,t2,t3);}

C_noret_decl(trf_2259)
static void C_fcall trf_2259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2259(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2259(t0,t1,t2,t3);}

C_noret_decl(trf_2814)
static void C_fcall trf_2814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2814(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2814(t0,t1,t2);}

C_noret_decl(trf_2824)
static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2824(t0,t1);}

C_noret_decl(trf_2784)
static void C_fcall trf_2784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2784(t0,t1);}

C_noret_decl(trf_2593)
static void C_fcall trf_2593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2593(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_2593(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_2596)
static void C_fcall trf_2596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2596(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2596(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2637)
static void C_fcall trf_2637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2637(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2637(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2678)
static void C_fcall trf_2678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2678(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2678(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2516)
static void C_fcall trf_2516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2516(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2516(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2522)
static void C_fcall trf_2522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2522(t0,t1,t2,t3);}

C_noret_decl(trf_2507)
static void C_fcall trf_2507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2507(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2507(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2479)
static void C_fcall trf_2479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2479(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2479(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2327)
static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2327(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2295)
static void C_fcall trf_2295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2295(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2295(t0,t1,t2,t3);}

C_noret_decl(trf_2262)
static void C_fcall trf_2262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2262(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2262(t0,t1,t2,t3);}

C_noret_decl(trf_1756)
static void C_fcall trf_1756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1756(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1756(t0,t1,t2,t3);}

C_noret_decl(trf_1995)
static void C_fcall trf_1995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1995(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1995(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2002)
static void C_fcall trf_2002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2002(t0,t1);}

C_noret_decl(trf_1759)
static void C_fcall trf_1759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1759(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1759(t0,t1,t2,t3);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1786(t0,t1,t2,t3);}

C_noret_decl(trf_1806)
static void C_fcall trf_1806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1806(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1806(t0,t1,t2,t3);}

C_noret_decl(trf_1737)
static void C_fcall trf_1737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1737(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1737(t0,t1,t2,t3);}

C_noret_decl(trf_1646)
static void C_fcall trf_1646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1646(t0,t1);}

C_noret_decl(trf_1678)
static void C_fcall trf_1678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1678(t0,t1);}

C_noret_decl(trf_1496)
static void C_fcall trf_1496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1496(t0,t1);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1491(t0,t1,t2);}

C_noret_decl(trf_1460)
static void C_fcall trf_1460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1460(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1460(t0,t1,t2,t3);}

C_noret_decl(trf_1477)
static void C_fcall trf_1477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1477(t0,t1);}

C_noret_decl(trf_1401)
static void C_fcall trf_1401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1401(t0,t1);}

C_noret_decl(trf_1338)
static void C_fcall trf_1338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1338(t0,t1);}

C_noret_decl(trf_1333)
static void C_fcall trf_1333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1333(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1333(t0,t1,t2);}

C_noret_decl(trf_1328)
static void C_fcall trf_1328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1328(t0,t1,t2);}

C_noret_decl(trf_1286)
static void C_fcall trf_1286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1286(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1286(t0,t1,t2);}

C_noret_decl(trf_1205)
static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1205(t0,t1);}

C_noret_decl(trf_1200)
static void C_fcall trf_1200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1200(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1200(t0,t1,t2);}

C_noret_decl(trf_1158)
static void C_fcall trf_1158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1158(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1158(t0,t1,t2,t3);}

C_noret_decl(trf_1168)
static void C_fcall trf_1168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1168(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1168(t0,t1);}

C_noret_decl(trf_1076)
static void C_fcall trf_1076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1076(t0,t1);}

C_noret_decl(trf_1084)
static void C_fcall trf_1084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1084(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1084(t0,t1,t2,t3,t4);}

C_noret_decl(trf_998)
static void C_fcall trf_998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_998(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_998(t0,t1,t2,t3);}

C_noret_decl(trf_842)
static void C_fcall trf_842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_842(t0,t1);}

C_noret_decl(trf_865)
static void C_fcall trf_865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_865(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_865(t0,t1,t2);}

C_noret_decl(trf_929)
static void C_fcall trf_929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_929(t0,t1);}

C_noret_decl(trf_794)
static void C_fcall trf_794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_794(t0,t1);}

C_noret_decl(trf_670)
static void C_fcall trf_670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_670(t0,t1);}

C_noret_decl(trf_665)
static void C_fcall trf_665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_665(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_665(t0,t1,t2);}

C_noret_decl(trf_660)
static void C_fcall trf_660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_660(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_660(t0,t1,t2,t3);}

C_noret_decl(trf_600)
static void C_fcall trf_600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_600(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_600(t0,t1,t2,t3,t4);}

C_noret_decl(trf_613)
static void C_fcall trf_613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_613(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_613(t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(880)){
C_save(t1);
C_rereclaim2(880*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,136);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],4,"read");
lf[4]=C_h_intern(&lf[4],7,"reverse");
lf[5]=C_h_intern(&lf[5],20,"call-with-input-file");
lf[6]=C_h_intern(&lf[6],9,"read-file");
lf[7]=C_h_intern(&lf[7],5,"port\077");
lf[8]=C_h_intern(&lf[8],18,"\003sysstandard-input");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_h_intern(&lf[10],11,"random-seed");
lf[11]=C_h_intern(&lf[11],17,"\003syscheck-integer");
lf[12]=C_h_intern(&lf[12],15,"current-seconds");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[14]=C_h_intern(&lf[14],6,"random");
lf[15]=C_h_intern(&lf[15],9,"randomize");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_h_intern(&lf[17],9,"read-line");
lf[18]=C_h_intern(&lf[18],13,"\003syssubstring");
lf[19]=C_h_intern(&lf[19],15,"\003sysread-char-0");
lf[20]=C_h_intern(&lf[20],9,"peek-char");
lf[21]=C_h_intern(&lf[21],17,"\003sysstring-append");
lf[22]=C_h_intern(&lf[22],15,"\003sysmake-string");
lf[23]=C_h_intern(&lf[23],14,"\003syscheck-port");
lf[24]=C_h_intern(&lf[24],10,"read-lines");
lf[25]=C_h_intern(&lf[25],16,"\003sysread-string!");
lf[26]=C_h_intern(&lf[26],12,"read-string!");
lf[27]=C_h_intern(&lf[27],18,"open-output-string");
lf[28]=C_h_intern(&lf[28],17,"get-output-string");
lf[29]=C_h_intern(&lf[29],20,"\003sysread-string/port");
lf[30]=C_h_intern(&lf[30],11,"read-string");
lf[31]=C_h_intern(&lf[31],19,"\003syswrite-char/port");
lf[32]=C_h_intern(&lf[32],10,"read-token");
lf[33]=C_h_intern(&lf[33],16,"\003syswrite-char-0");
lf[34]=C_h_intern(&lf[34],15,"\003syspeek-char-0");
lf[35]=C_h_intern(&lf[35],7,"display");
lf[36]=C_h_intern(&lf[36],12,"write-string");
lf[37]=C_h_intern(&lf[37],19,"\003sysstandard-output");
lf[38]=C_h_intern(&lf[38],7,"newline");
lf[39]=C_h_intern(&lf[39],10,"write-line");
lf[40]=C_h_intern(&lf[40],9,"read-byte");
lf[41]=C_h_intern(&lf[41],10,"write-byte");
lf[42]=C_h_intern(&lf[42],20,"\006extrasgeneric-write");
lf[43]=C_h_intern(&lf[43],5,"quote");
lf[44]=C_h_intern(&lf[44],10,"quasiquote");
lf[45]=C_h_intern(&lf[45],7,"unquote");
lf[46]=C_h_intern(&lf[46],16,"unquote-splicing");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001`");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002,@");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\003 . ");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\002()");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[59]=C_h_intern(&lf[59],12,"vector->list");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002#t");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[62]=C_h_intern(&lf[62],18,"\003sysnumber->string");
lf[63]=C_h_intern(&lf[63],9,"\003sysprint");
lf[64]=C_h_intern(&lf[64],21,"\003sysprocedure->string");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\001x");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\001u");
lf[71]=C_h_intern(&lf[71],9,"char-name");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\002#\134");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\016#<unspecified>");
lf[75]=C_h_intern(&lf[75],19,"\003syspointer->string");
lf[76]=C_h_intern(&lf[76],28,"\003sysarbitrary-unbound-symbol");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\020#<unbound value>");
lf[78]=C_h_intern(&lf[78],19,"\003sysuser-print-hook");
lf[79]=C_h_intern(&lf[79],13,"string-append");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\007#<port ");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\025#<static blob of size");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\017#<blob of size ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002#>");
lf[86]=C_h_intern(&lf[86],23,"\003syslambda-info->string");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\016#<lambda info ");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\025#<unprintable object>");
lf[89]=C_h_intern(&lf[89],11,"\003sysnumber\077");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[92]=C_h_intern(&lf[92],28,"\006extrasreverse-string-append");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[94]=C_h_intern(&lf[94],3,"max");
lf[95]=C_h_intern(&lf[95],28,"\003syssymbol->qualified-string");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[103]=C_h_intern(&lf[103],6,"lambda");
lf[104]=C_h_intern(&lf[104],2,"if");
lf[105]=C_h_intern(&lf[105],4,"set!");
lf[106]=C_h_intern(&lf[106],4,"cond");
lf[107]=C_h_intern(&lf[107],4,"case");
lf[108]=C_h_intern(&lf[108],3,"and");
lf[109]=C_h_intern(&lf[109],2,"or");
lf[110]=C_h_intern(&lf[110],3,"let");
lf[111]=C_h_intern(&lf[111],5,"begin");
lf[112]=C_h_intern(&lf[112],2,"do");
lf[113]=C_h_intern(&lf[113],4,"let*");
lf[114]=C_h_intern(&lf[114],6,"letrec");
lf[115]=C_h_intern(&lf[115],6,"define");
lf[116]=C_h_intern(&lf[116],18,"pretty-print-width");
lf[117]=C_h_intern(&lf[117],12,"pretty-print");
lf[118]=C_h_intern(&lf[118],19,"current-output-port");
lf[119]=C_h_intern(&lf[119],2,"pp");
lf[120]=C_h_intern(&lf[120],5,"write");
lf[121]=C_h_intern(&lf[121],15,"\006extrasfprintf0");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[123]=C_h_intern(&lf[123],16,"\003sysflush-output");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\037illegal format-string character");
lf[125]=C_h_intern(&lf[125],13,"\003systty-port\077");
lf[126]=C_h_intern(&lf[126],7,"fprintf");
lf[127]=C_h_intern(&lf[127],6,"printf");
lf[128]=C_h_intern(&lf[128],7,"sprintf");
lf[129]=C_h_intern(&lf[129],6,"format");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal destination");
lf[131]=C_h_intern(&lf[131],12,"output-port\077");
lf[132]=C_h_intern(&lf[132],17,"register-feature!");
lf[133]=C_h_intern(&lf[133],7,"srfi-28");
lf[134]=C_h_intern(&lf[134],14,"make-parameter");
lf[135]=C_h_intern(&lf[135],6,"extras");
C_register_lf2(lf,136,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_590,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k588 */
static void C_ccall f_590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_590,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_596,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 91   register-feature! */
t4=*((C_word*)lf[132]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[135]);}

/* k594 in k588 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[70],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_596,2,t0,t1);}
t2=*((C_word*)lf[3]+1);
t3=*((C_word*)lf[4]+1);
t4=*((C_word*)lf[5]+1);
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_598,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li6),tmp=(C_word)a,a+=6,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_739,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_777,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_789,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[16]+1);
t10=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_832,a[2]=t9,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[17]+1);
t12=*((C_word*)lf[5]+1);
t13=*((C_word*)lf[4]+1);
t14=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_976,a[2]=t12,a[3]=t11,a[4]=t13,a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t15=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1066,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1156,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[27]+1);
t18=*((C_word*)lf[28]+1);
t19=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1253,a[2]=t17,a[3]=t18,a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp));
t20=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1326,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[27]+1);
t22=*((C_word*)lf[28]+1);
t23=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1386,a[2]=t21,a[3]=t22,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t24=*((C_word*)lf[35]+1);
t25=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1455,a[2]=t24,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t26=*((C_word*)lf[35]+1);
t27=*((C_word*)lf[38]+1);
t28=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1544,a[2]=t26,a[3]=t27,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t29=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1565,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[27]+1);
t32=*((C_word*)lf[28]+1);
t33=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1643,a[2]=t31,a[3]=t32,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp));
t34=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2915,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 626  make-parameter */
t36=*((C_word*)lf[134]+1);
((C_proc3)(void*)(*((C_word*)t36+1)))(3,t36,t35,C_fix(79));}

/* k2992 in k594 in k588 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1,t1);
t3=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[119]+1,*((C_word*)lf[117]+1));
t5=*((C_word*)lf[120]+1);
t6=*((C_word*)lf[38]+1);
t7=*((C_word*)lf[35]+1);
t8=*((C_word*)lf[27]+1);
t9=*((C_word*)lf[28]+1);
t10=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3025,a[2]=t8,a[3]=t6,a[4]=t7,a[5]=t5,a[6]=t9,a[7]=((C_word)li79),tmp=(C_word)a,a+=8,tmp));
t11=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3323,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t14=*((C_word*)lf[126]+1);
t15=*((C_word*)lf[128]+1);
t16=*((C_word*)lf[127]+1);
t17=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3341,a[2]=t14,a[3]=t15,a[4]=t16,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 716  register-feature! */
t19=*((C_word*)lf[132]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[133]);}

/* k3382 in k2992 in k594 in k588 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format in k2992 in k594 in k588 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_3341r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3341r(t0,t1,t2,t3);}}

static void C_ccall f_3341r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(15);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3349,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
if(C_truep(t6)){
if(C_truep((C_word)C_booleanp(t2))){
t7=t5;
f_3349(2,t7,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_3349(2,t9,((C_word*)t0)[3]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 711  output-port? */
t8=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}}
else{
t7=t5;
f_3349(2,t7,((C_word*)t0)[3]);}}

/* k3372 in format in k2992 in k594 in k588 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_3349(2,t4,((C_word*)t0)[2]);}
else{
/* extras.scm: 713  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[129],lf[130],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3347 in format in k2992 in k594 in k588 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* sprintf in k2992 in k594 in k588 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3335r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3335r(t0,t1,t2,t3);}}

static void C_ccall f_3335r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 701  fprintf0 */
t4=*((C_word*)lf[121]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,lf[128],C_SCHEME_FALSE,t2,t3);}

/* printf in k2992 in k594 in k588 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3329r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3329r(t0,t1,t2,t3);}}

static void C_ccall f_3329r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 698  fprintf0 */
t4=*((C_word*)lf[121]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,lf[127],*((C_word*)lf[37]+1),t2,t3);}

/* fprintf in k2992 in k594 in k588 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3323r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3323r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3323r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* extras.scm: 695  fprintf0 */
t5=*((C_word*)lf[121]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,lf[126],t2,t3,t4);}

/* ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3025,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3029,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
/* extras.scm: 645  ##sys#check-port */
t7=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,t2);}
else{
t7=t6;
f_3029(2,t7,C_SCHEME_UNDEFINED);}}

/* k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[10])){
/* extras.scm: 646  ##sys#tty-port? */
t4=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[10]);}
else{
t4=t3;
f_3312(2,t4,C_SCHEME_FALSE);}}

/* k3310 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3032(2,t2,((C_word*)t0)[3]);}
else{
/* extras.scm: 646  open-output-string */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}}

/* k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word)li78),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3037(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3037,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_string_2(t2,((C_word*)t0)[9]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=t13,a[10]=t9,a[11]=t8,a[12]=t7,a[13]=((C_word)li77),tmp=(C_word)a,a+=14,tmp));
t15=((C_word*)t13)[1];
f_3098(t15,t11);}

/* loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_fcall f_3098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[53],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3098,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_3046(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3111,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
t5=(C_truep(t4)?(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=f_3046(((C_word*)t0)[10]);
t7=(C_word)C_u_i_char_upcase(t6);
switch(t7){
case C_make_character(83):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 667  next */
t9=((C_word*)t0)[6];
f_3053(t9,t8);
case C_make_character(65):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 668  next */
t9=((C_word*)t0)[6];
f_3053(t9,t8);
case C_make_character(67):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 669  next */
t9=((C_word*)t0)[6];
f_3053(t9,t8);
case C_make_character(66):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3179,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 670  next */
t10=((C_word*)t0)[6];
f_3053(t10,t9);
case C_make_character(79):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 671  next */
t10=((C_word*)t0)[6];
f_3053(t10,t9);
case C_make_character(88):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 672  next */
t10=((C_word*)t0)[6];
f_3053(t10,t9);
case C_make_character(33):
/* extras.scm: 673  ##sys#flush-output */
t8=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t3,((C_word*)t0)[7]);
case C_make_character(63):
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 675  next */
t9=((C_word*)t0)[6];
f_3053(t9,t8);
case C_make_character(126):
/* extras.scm: 679  ##sys#write-char-0 */
t8=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,C_make_character(126),((C_word*)t0)[7]);
default:
t8=(C_word)C_eqp(t7,C_make_character(37));
t9=(C_truep(t8)?t8:(C_word)C_eqp(t7,C_make_character(78)));
if(C_truep(t9)){
/* extras.scm: 680  newline */
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t6))){
t10=f_3046(((C_word*)t0)[10]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[10],a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp);
t12=t3;
f_3111(2,t12,f_3276(t11,t10));}
else{
/* extras.scm: 687  ##sys#error */
t10=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t3,((C_word*)t0)[4],lf[124],t6);}}}}
else{
/* extras.scm: 688  ##sys#write-char-0 */
t6=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t2,((C_word*)t0)[7]);}}}

/* skip in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static C_word C_fcall f_3276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_3046(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k3229 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3234,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 676  next */
t3=((C_word*)t0)[2];
f_3053(t3,t2);}

/* k3232 in k3229 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[5]);
/* extras.scm: 678  rec */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3037(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3211 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 672  ##sys#number->string */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(16));}

/* k3207 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 672  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3194 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 671  ##sys#number->string */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(8));}

/* k3190 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 671  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3177 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 670  ##sys#number->string */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(2));}

/* k3173 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 670  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3160 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 669  ##sys#write-char-0 */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3147 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 668  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3134 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 667  write */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3109 in loop in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 689  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3098(t2,((C_word*)t0)[2]);}

/* k3068 in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3092,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 692  get-output-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}
else{
/* extras.scm: 690  get-output-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k3090 in k3068 in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 692  ##sys#print */
t2=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* next in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static void C_fcall f_3053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3053,NULL,2,t0,t1);}
if(C_truep((C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST))){
/* extras.scm: 657  ##sys#error */
t2=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],lf[122]);}
else{
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(0));
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in rec in k3030 in k3027 in ##extras#fprintf0 in k2992 in k594 in k588 */
static C_word C_fcall f_3046(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* pretty-print in k2992 in k594 in k588 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2996r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2996r(t0,t1,t2,t3);}}

static void C_ccall f_2996r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3000,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_3000(2,t5,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
/* extras.scm: 629  current-output-port */
t5=*((C_word*)lf[118]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2998 in pretty-print in k2992 in k594 in k588 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 630  pretty-print-width */
t4=*((C_word*)lf[116]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3005 in k2998 in pretty-print in k2992 in k594 in k588 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[4],a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 630  generic-write */
t3=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a3008 in k3005 in k2998 in pretty-print in k2992 in k594 in k588 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3009,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3013,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 630  display */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k3011 in a3008 in k3005 in k2998 in pretty-print in k2992 in k594 in k588 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3001 in k2998 in pretty-print in k2992 in k594 in k588 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##extras#reverse-string-append in k594 in k588 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2915,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2918,a[2]=t4,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
/* extras.scm: 621  rev-string-append */
t6=((C_word*)t4)[1];
f_2918(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##extras#reverse-string-append in k594 in k588 */
static void C_fcall f_2918(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2918,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2934,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* extras.scm: 612  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* extras.scm: 619  make-string */
t4=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k2932 in rev-string-append in ##extras#reverse-string-append in k594 in k588 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2943,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_2943(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k2932 in rev-string-append in ##extras#reverse-string-append in k594 in k588 */
static void C_fcall f_2943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2943,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* extras.scm: 617  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* ##extras#generic-write in k594 in k588 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1643,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1698,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1704,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1737,a[2]=t5,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1756,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t9,a[9]=t11,a[10]=((C_word)li44),tmp=(C_word)a,a+=11,tmp));
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2259,a[2]=t6,a[3]=t8,a[4]=t7,a[5]=t11,a[6]=t4,a[7]=t3,a[8]=t9,a[9]=((C_word)li68),tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2906,a[2]=t2,a[3]=t13,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 601  make-string */
t15=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(1),C_make_character(10));}
else{
/* extras.scm: 602  wr */
t14=((C_word*)t11)[1];
f_1756(t14,t1,t2,C_fix(0));}}

/* k2904 in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2910,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 601  pp */
t3=((C_word*)t0)[3];
f_2259(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2908 in k2904 in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 601  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2259(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[151],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2259,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2295,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[8],a[8]=((C_word)li48),tmp=(C_word)a,a+=9,tmp));
t41=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word*)t0)[4],a[12]=((C_word)li49),tmp=(C_word)a,a+=13,tmp));
t42=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t17,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t43=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[8],a[3]=t17,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=t9,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t45=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t9,a[6]=t17,a[7]=((C_word)li57),tmp=(C_word)a,a+=8,tmp));
t46=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2741,a[2]=t11,a[3]=t15,a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp));
t47=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2747,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t48=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2753,a[2]=t11,a[3]=t19,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t49=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2759,a[2]=t21,a[3]=t13,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t50=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2765,a[2]=t21,a[3]=t11,a[4]=t19,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t51=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2771,a[2]=t11,a[3]=t13,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t52=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2777,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t53=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2799,a[2]=t11,a[3]=t19,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t54=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2805,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2814,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,a[10]=((C_word)li67),tmp=(C_word)a,a+=11,tmp));
/* extras.scm: 598  pr */
t56=((C_word*)t9)[1];
f_2327(t56,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2814(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2814,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_2824(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[113]);
if(C_truep(t5)){
t6=t4;
f_2824(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[114]);
t7=t4;
f_2824(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[115])));}}}

/* k2822 in style in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[105]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[106]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[107]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[109]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[110]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[111]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[112]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2805,5,t0,t1,t2,t3,t4);}
/* extras.scm: 576  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2593(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2799,5,t0,t1,t2,t3,t4);}
/* extras.scm: 573  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2593(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2777,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_2784(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_2784(t7,C_SCHEME_FALSE);}}

/* k2782 in pp-let in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 570  pp-general */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2593(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-and in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2771,5,t0,t1,t2,t3,t4);}
/* extras.scm: 565  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2479(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2765,5,t0,t1,t2,t3,t4);}
/* extras.scm: 562  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2593(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2759,5,t0,t1,t2,t3,t4);}
/* extras.scm: 559  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2479(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2753,5,t0,t1,t2,t3,t4);}
/* extras.scm: 556  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2593(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2747,5,t0,t1,t2,t3,t4);}
/* extras.scm: 553  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2593(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2741,5,t0,t1,t2,t3,t4);}
/* extras.scm: 550  pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2507(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2593(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2593,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2678,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,a[5]=t4,a[6]=t7,a[7]=((C_word)li55),tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t4,a[6]=t6,a[7]=((C_word)li56),tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_i_cdr(t2);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,a[6]=t3,a[7]=t13,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2739,a[2]=t12,a[3]=t14,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 541  out */
t16=((C_word*)t0)[2];
f_1737(t16,t15,lf[102],t3);}

/* k2737 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 541  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1756(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2689 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2691,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2706,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2721,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 545  out */
t7=((C_word*)t0)[2];
f_1737(t7,t6,lf[101],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 547  tail1 */
t5=((C_word*)t0)[5];
f_2596(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k2719 in k2689 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 545  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1756(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2704 in k2689 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 546  tail1 */
t4=((C_word*)t0)[4];
f_2596(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail1 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2596,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2619,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 525  indent */
t13=((C_word*)t0)[2];
f_2295(t13,t12,t5,t4);}
else{
/* extras.scm: 526  tail2 */
t7=((C_word*)t0)[4];
f_2637(t7,t1,t2,t3,t4,t5);}}

/* k2621 in tail1 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 525  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2327(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2617 in tail1 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 525  tail2 */
t2=((C_word*)t0)[6];
f_2637(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2637(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2637,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2660,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 533  indent */
t13=((C_word*)t0)[2];
f_2295(t13,t12,t5,t4);}
else{
/* extras.scm: 534  tail3 */
t7=((C_word*)t0)[4];
f_2678(t7,t1,t2,t3,t4);}}

/* k2662 in tail2 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 533  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2327(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2658 in tail2 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 533  tail3 */
t2=((C_word*)t0)[5];
f_2678(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail3 in pp-general in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2678,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 537  pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2516(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2516(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2516,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,a[9]=((C_word)li52),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_2522(t10,t1,t2,t3);}

/* loop in pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2522(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2522,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2545,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 508  indent */
t10=((C_word*)t0)[4];
f_2295(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 510  out */
t4=((C_word*)t0)[2];
f_1737(t4,t1,lf[98],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2575,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 514  indent */
t8=((C_word*)t0)[4];
f_2295(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2589 in loop in pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 514  out */
t2=((C_word*)t0)[3];
f_1737(t2,((C_word*)t0)[2],lf[100],t1);}

/* k2585 in loop in pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 514  indent */
t2=((C_word*)t0)[4];
f_2295(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2577 in loop in pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm: 513  pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2327(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k2573 in loop in pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 512  out */
t2=((C_word*)t0)[3];
f_1737(t2,((C_word*)t0)[2],lf[99],t1);}

/* k2551 in loop in pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 508  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2327(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2543 in loop in pp-down in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 507  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2522(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2507(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2507,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2511,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 498  out */
t7=((C_word*)t0)[2];
f_1737(t7,t6,lf[97],t3);}

/* k2509 in pp-list in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 499  pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2516(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2479,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2483,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 490  out */
t9=((C_word*)t0)[2];
f_1737(t9,t8,lf[96],t3);}

/* k2503 in pp-call in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 490  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1756(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2481 in pp-call in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 492  pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2516(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2414,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* extras.scm: 470  read-macro? */
f_1646(t5,t2);}

/* k2419 in pp-expr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
if(C_truep(t1)){
t2=f_1698(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2432,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t4=f_1704(((C_word*)t0)[13]);
/* extras.scm: 472  out */
t5=((C_word*)t0)[7];
f_1737(t5,t3,t4,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2448,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 477  style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2814(t4,t3,t2);}
else{
/* extras.scm: 484  pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2507(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k2446 in k2419 in pp-expr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm: 479  proc */
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 480  ##sys#symbol->qualified-string */
t3=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2472 in k2446 in k2419 in pp-expr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
/* extras.scm: 482  pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2593(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm: 483  pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2479(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k2430 in k2419 in pp-expr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 471  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2327(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2327,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm: 456  max */
t14=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t13,C_fix(50));}
else{
/* extras.scm: 467  wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1756(t8,t1,t2,t3);}}

/* k2338 in pr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2378,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 457  generic-write */
t6=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a2377 in k2338 in pr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2378,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_i_string_length(t2);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k2341 in k2338 in pr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 463  reverse-string-append */
t3=*((C_word*)lf[92]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm: 465  pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 466  vector->list */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k2370 in k2341 in k2338 in pr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 466  out */
t3=((C_word*)t0)[3];
f_1737(t3,t2,lf[93],((C_word*)t0)[2]);}

/* k2374 in k2370 in k2341 in k2338 in pr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 466  pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2507(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2354 in k2341 in k2338 in pr in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 463  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2295,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2311,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2318,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 450  make-string */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
/* extras.scm: 451  spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2262(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2316 in indent in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 450  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2309 in indent in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 450  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2262(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2262(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2262,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2286,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 443  out */
t6=((C_word*)t0)[2];
f_1737(t6,t5,lf[90],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2293,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 444  ##sys#substring */
t5=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[91],C_fix(0),t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2291 in spaces in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 444  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2284 in spaces in pp in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 443  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2262(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1756(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1756,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],a[8]=((C_word)li42),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
/* extras.scm: 376  wr-expr */
t6=t5;
f_1759(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 377  wr-lst */
t6=t4;
f_1786(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
/* extras.scm: 378  out */
t6=((C_word*)t0)[8];
f_1737(t6,t1,lf[57],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1912,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 379  vector->list */
t7=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=(C_truep(t2)?lf[60]:lf[61]);
/* extras.scm: 380  out */
t7=((C_word*)t0)[8];
f_1737(t7,t1,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 381  ##sys#number? */
t7=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}}}}}

/* k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 381  ##sys#number->string */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 383  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 386  ##sys#procedure->string */
t3=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 388  out */
t2=((C_word*)t0)[8];
f_1737(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 389  out */
t3=((C_word*)t0)[8];
f_1737(t3,t2,lf[67],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 403  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 405  out */
t4=((C_word*)t0)[8];
f_1737(t4,t3,lf[72],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
/* extras.scm: 416  out */
t2=((C_word*)t0)[8];
f_1737(t2,((C_word*)t0)[7],lf[73],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
/* extras.scm: 417  out */
t2=((C_word*)t0)[8];
f_1737(t2,((C_word*)t0)[7],lf[74],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 418  ##sys#pointer->string */
t3=*((C_word*)lf[75]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(lf[76],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* extras.scm: 420  out */
t4=((C_word*)t0)[8];
f_1737(t4,((C_word*)t0)[7],lf[77],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 422  open-output-string */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 425  port? */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}}}}}}}}}}

/* k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2201,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm: 425  string-append */
t4=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[80],t3,lf[81]);}
else{
if(C_truep((C_word)C_bytevectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[2]))){
/* extras.scm: 428  out */
t3=((C_word*)t0)[5];
f_1737(t3,t2,lf[83],((C_word*)t0)[3]);}
else{
/* extras.scm: 429  out */
t3=((C_word*)t0)[5];
f_1737(t3,t2,lf[84],((C_word*)t0)[3]);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 433  out */
t3=((C_word*)t0)[5];
f_1737(t3,t2,lf[87],((C_word*)t0)[3]);}
else{
/* extras.scm: 436  out */
t2=((C_word*)t0)[5];
f_1737(t2,((C_word*)t0)[4],lf[88],((C_word*)t0)[3]);}}}}

/* k2238 in k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 434  ##sys#lambda-info->string */
t4=*((C_word*)lf[86]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2248 in k2238 in k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 434  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2241 in k2238 in k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 435  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],lf[85],((C_word*)t0)[2]);}

/* k2216 in k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 430  number->string */
C_number_to_string(3,0,t3,(C_word)C_block_size(((C_word*)t0)[2]));}

/* k2226 in k2216 in k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 430  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2219 in k2216 in k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 431  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],lf[82],((C_word*)t0)[2]);}

/* k2206 in k2199 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 425  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2183 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2188,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 423  ##sys#user-print-hook */
t3=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2186 in k2183 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 424  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2193 in k2186 in k2183 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 424  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2165 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 418  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2081 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 406  char-name */
t3=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2084 in k2081 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
/* extras.scm: 408  out */
t3=((C_word*)t0)[6];
f_1737(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 410  out */
t3=((C_word*)t0)[6];
f_1737(t3,t2,lf[68],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535));
t4=(C_truep(t3)?lf[69]:lf[70]);
/* extras.scm: 413  out */
t5=((C_word*)t0)[6];
f_1737(t5,t2,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 415  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k2140 in k2084 in k2081 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 415  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2119 in k2084 in k2081 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 414  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2126 in k2119 in k2084 in k2081 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 414  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2103 in k2084 in k2081 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 411  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2110 in k2103 in k2084 in k2081 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 411  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2075 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 403  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1995(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1995(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1995,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2002,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_string_length(((C_word*)t0)[4]);
t7=t5;
f_2002(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_2002(t6,C_SCHEME_FALSE);}}

/* k2000 in loop in k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_fcall f_2002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2002,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2025,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2029,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 397  ##sys#substring */
t9=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm: 399  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_1995(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 401  ##sys#substring */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k2052 in k2000 in loop in k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 401  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2048 in k2000 in loop in k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 400  out */
t2=((C_word*)t0)[3];
f_1737(t2,((C_word*)t0)[2],lf[66],t1);}

/* k2031 in k2000 in loop in k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 397  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2027 in k2000 in loop in k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 396  out */
t2=((C_word*)t0)[3];
f_1737(t2,((C_word*)t0)[2],lf[65],t1);}

/* k2023 in k2000 in loop in k1991 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 394  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1995(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1972 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 386  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1949 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1954,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 384  ##sys#print */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k1952 in k1949 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 385  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1959 in k1952 in k1949 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 385  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1940 in k1933 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 381  out */
t2=((C_word*)t0)[4];
f_1737(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1910 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 379  out */
t3=((C_word*)t0)[3];
f_1737(t3,t2,lf[58],((C_word*)t0)[2]);}

/* k1914 in k1910 in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 379  wr-lst */
t2=((C_word*)t0)[4];
f_1786(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1759(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1759,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1766,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 361  read-macro? */
f_1646(t4,t2);}

/* k1764 in wr-expr in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
if(C_truep(t1)){
t2=f_1698(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1777,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=f_1704(((C_word*)t0)[8]);
/* extras.scm: 362  out */
t5=((C_word*)t0)[4];
f_1737(t5,t3,t4,((C_word*)t0)[3]);}
else{
/* extras.scm: 363  wr-lst */
t2=((C_word*)t0)[2];
f_1786(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k1775 in k1764 in wr-expr in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 362  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1756(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1786,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1804,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1869,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 368  out */
t8=((C_word*)t0)[2];
f_1737(t8,t7,lf[55],t3);}
else{
t6=t5;
f_1804(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm: 374  out */
t4=((C_word*)t0)[2];
f_1737(t4,t1,lf[56],t3);}}

/* k1867 in wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 368  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1756(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1802 in wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1806(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k1802 in wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1806(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1806,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1830,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1838,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 371  out */
t9=((C_word*)t0)[2];
f_1737(t9,t8,lf[51],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 372  out */
t5=((C_word*)t0)[2];
f_1737(t5,t1,lf[52],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1854,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 373  out */
t7=((C_word*)t0)[2];
f_1737(t7,t6,lf[54],t3);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* k1856 in loop in k1802 in wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 373  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1756(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1852 in loop in k1802 in wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 373  out */
t2=((C_word*)t0)[3];
f_1737(t2,((C_word*)t0)[2],lf[53],t1);}

/* k1836 in loop in k1802 in wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 371  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1756(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1828 in loop in k1802 in wr-lst in wr in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 371  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1806(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1737(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1737,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1747,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 356  output */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1745 in out in ##extras#generic-write in k594 in k588 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in ##extras#generic-write in k594 in k588 */
static C_word C_fcall f_1704(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_eqp(t2,lf[43]);
if(C_truep(t4)){
return(lf[47]);}
else{
t5=(C_word)C_eqp(t2,lf[44]);
if(C_truep(t5)){
return(lf[48]);}
else{
t6=(C_word)C_eqp(t2,lf[45]);
if(C_truep(t6)){
return(lf[49]);}
else{
t7=(C_word)C_eqp(t2,lf[46]);
return((C_truep(t7)?lf[50]:C_SCHEME_UNDEFINED));}}}}

/* read-macro-body in ##extras#generic-write in k594 in k588 */
static C_word C_fcall f_1698(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_i_cadr(t1));}

/* read-macro? in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1646(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1646,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,lf[43]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1678,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_1678(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[44]);
if(C_truep(t7)){
t8=t6;
f_1678(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[45]);
t9=t6;
f_1678(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[46])));}}}

/* k1676 in read-macro? in ##extras#generic-write in k594 in k588 */
static void C_fcall f_1678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* write-byte in k594 in k588 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1605r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1605r(t0,t1,t2,t3);}}

static void C_ccall f_1605r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1609,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1609(2,t5,*((C_word*)lf[37]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1609(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1607 in write-byte in k594 in k588 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[41]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1615,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 317  ##sys#check-port */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[41]);}

/* k1613 in k1607 in write-byte in k594 in k588 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[4]));
/* extras.scm: 318  ##sys#write-char-0 */
t3=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* read-byte in k594 in k588 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1565r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1565r(t0,t1,t2);}}

static void C_ccall f_1565r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1569,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1569(2,t4,*((C_word*)lf[8]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1569(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1567 in read-byte in k594 in k588 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1572,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 309  ##sys#check-port */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[40]);}

/* k1570 in k1567 in read-byte in k594 in k588 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 310  ##sys#read-char-0 */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1573 in k1570 in k1567 in read-byte in k594 in k588 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t1:(C_word)C_fix((C_word)C_character_code(t1))));}

/* write-line in k594 in k588 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1544r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1544r(t0,t1,t2,t3);}}

static void C_ccall f_1544r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[37]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 300  ##sys#check-port */
t6=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[39]);}

/* k1549 in write-line in k594 in k588 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[39]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 302  display */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k1555 in k1549 in write-line in k594 in k588 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 303  newline */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k594 in k588 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_1455r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1455r(t0,t1,t2,t3);}}

static void C_ccall f_1455r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t4=(C_word)C_i_check_string_2(t2,lf[36]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1460,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1491,a[2]=t5,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1496,a[2]=t6,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* extras.scm: 284  def-n199 */
t8=t7;
f_1496(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* extras.scm: 284  def-port200 */
t10=t6;
f_1491(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* extras.scm: 284  body197 */
t12=t5;
f_1460(t12,t1,t8,t10);}
else{
/* extras.scm: 284  ##sys#error */
t12=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-n199 in write-string in k594 in k588 */
static void C_fcall f_1496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1496,NULL,2,t0,t1);}
/* extras.scm: 284  def-port200 */
t2=((C_word*)t0)[2];
f_1491(t2,t1,C_SCHEME_FALSE);}

/* def-port200 in write-string in k594 in k588 */
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1491,NULL,3,t0,t1,t2);}
/* extras.scm: 284  body197 */
t3=((C_word*)t0)[2];
f_1460(t3,t1,t2,*((C_word*)lf[37]+1));}

/* body197 in write-string in k594 in k588 */
static void C_fcall f_1460(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1460,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 285  ##sys#check-port */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[36]);}

/* k1462 in body197 in write-string in k594 in k588 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1464,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[36]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(C_word)C_block_size(((C_word*)t0)[2]);
t6=t4;
f_1477(t6,(C_word)C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_1477(t5,C_SCHEME_FALSE);}}

/* k1475 in k1462 in body197 in write-string in k594 in k588 */
static void C_fcall f_1477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 289  ##sys#substring */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_1474(2,t2,((C_word*)t0)[3]);}}

/* k1472 in k1462 in body197 in write-string in k594 in k588 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 287  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k594 in k588 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1386r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1386r(t0,t1,t2,t3);}}

static void C_ccall f_1386r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1390(2,t5,*((C_word*)lf[8]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1390(2,t6,(C_word)C_i_car(t3));}
else{
/* extras.scm: 269  ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1388 in read-token in k594 in k588 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 270  ##sys#check-port */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[32]);}

/* k1391 in k1388 in read-token in k594 in k588 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 271  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1394 in k1391 in k1388 in read-token in k594 in k588 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1396,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=((C_word)li27),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1401(t5,((C_word*)t0)[2]);}

/* loop in k1394 in k1391 in k1388 in read-token in k594 in k588 */
static void C_fcall f_1401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1401,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 273  ##sys#peek-char-0 */
t3=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k1403 in loop in k1394 in k1391 in k1388 in read-token in k594 in k588 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_1411(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm: 274  pred */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k1409 in k1403 in loop in k1394 in k1391 in k1388 in read-token in k594 in k588 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1414,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 276  ##sys#read-char-0 */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* extras.scm: 278  get-output-string */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1419 in k1409 in k1403 in loop in k1394 in k1391 in k1388 in read-token in k594 in k588 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 276  ##sys#write-char-0 */
t2=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1412 in k1409 in k1403 in loop in k1394 in k1391 in k1388 in read-token in k594 in k588 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 277  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1401(t2,((C_word*)t0)[2]);}

/* read-string in k594 in k588 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_1326r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1326r(t0,t1,t2);}}

static void C_ccall f_1326r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1333,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1338,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n166174 */
t6=t5;
f_1338(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-port167172 */
t8=t4;
f_1333(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body164169 */
f_1328(t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n166 in read-string in k594 in k588 */
static void C_fcall f_1338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1338,NULL,2,t0,t1);}
/* def-port167172 */
t2=((C_word*)t0)[2];
f_1333(t2,t1,C_SCHEME_FALSE);}

/* def-port167 in read-string in k594 in k588 */
static void C_fcall f_1333(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1333,NULL,3,t0,t1,t2);}
/* body164169 */
f_1328(t1,t2,*((C_word*)lf[8]+1));}

/* body164 in read-string in k594 in k588 */
static void C_fcall f_1328(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1328,NULL,3,t1,t2,t3);}
/* extras.scm: 263  ##sys#read-string/port */
t4=*((C_word*)lf[29]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1253,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 244  ##sys#check-port */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[30]);}

/* k1255 in ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[30]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 246  ##sys#make-string */
t4=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 252  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k1279 in k1255 in ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1286(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k1279 in k1255 in ##sys#read-string/port in k594 in k588 */
static void C_fcall f_1286(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1286,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 254  get-output-string */
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[4]);}
else{
t5=t3;
f_1290(2,t5,C_SCHEME_FALSE);}}

/* k1288 in loop in k1279 in k1255 in ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1290,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 255  ##sys#read-char-0 */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k1294 in k1288 in loop in k1279 in k1255 in ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1296,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 257  get-output-string */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 259  ##sys#write-char/port */
t3=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[4]);}}

/* k1306 in k1294 in k1288 in loop in k1279 in k1255 in ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
/* extras.scm: 260  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1286(t3,((C_word*)t0)[2],t2);}

/* k1264 in k1255 in ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1269,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 247  ##sys#read-string! */
t3=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[2],C_fix(0));}

/* k1267 in k1264 in k1255 in ##sys#read-string/port in k594 in k588 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 250  ##sys#substring */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* read-string! in k594 in k588 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1156r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1156r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1158,a[2]=t5,a[3]=t3,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1200,a[2]=t6,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1205,a[2]=t7,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port126139 */
t9=t8;
f_1205(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start127137 */
t11=t7;
f_1200(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body124129 */
t13=t6;
f_1158(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port126 in read-string! in k594 in k588 */
static void C_fcall f_1205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1205,NULL,2,t0,t1);}
/* def-start127137 */
t2=((C_word*)t0)[2];
f_1200(t2,t1,*((C_word*)lf[8]+1));}

/* def-start127 in read-string! in k594 in k588 */
static void C_fcall f_1200(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1200,NULL,3,t0,t1,t2);}
/* body124129 */
t3=((C_word*)t0)[2];
f_1158(t3,t1,t2,C_fix(0));}

/* body124 in read-string! in k594 in k588 */
static void C_fcall f_1158(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1158,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1162,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 231  ##sys#check-port */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[26]);}

/* k1160 in body124 in read-string! in k594 in k588 */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1162,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[26]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[26]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
t6=(C_word)C_block_size(((C_word*)t0)[6]);
if(C_truep((C_word)C_fixnum_greaterp(t5,t6))){
t7=(C_word)C_block_size(((C_word*)t0)[6]);
t8=(C_word)C_fixnum_difference(t7,((C_word*)t0)[5]);
t9=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t10=t3;
f_1168(t10,t9);}
else{
t7=t3;
f_1168(t7,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1168(t4,C_SCHEME_UNDEFINED);}}

/* k1166 in k1160 in body124 in read-string! in k594 in k588 */
static void C_fcall f_1168(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[26]);
/* extras.scm: 238  ##sys#read-string! */
t3=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* ##sys#read-string! in k594 in k588 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1066,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1076,a[2]=t2,a[3]=t6,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(t4,C_fix(6)))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1150,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 213  ##sys#read-char-0 */
t10=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t8;
f_1076(t9,C_SCHEME_UNDEFINED);}}}

/* k1148 in ##sys#read-string! in k594 in k588 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1076(t5,t4);}

/* k1074 in ##sys#read-string! in k594 in k588 */
static void C_fcall f_1076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1076,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(7));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t5,a[6]=((C_word)li15),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1084(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}

/* loop in k1074 in ##sys#read-string! in k594 in k588 */
static void C_fcall f_1084(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1084,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
/* extras.scm: 218  rdstring */
t6=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t0)[3],t3,((C_word*)t0)[2],t2);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1133,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 219  ##sys#read-char-0 */
t7=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}}

/* k1131 in loop in k1074 in ##sys#read-string! in k594 in k588 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
f_1088(2,t2,C_fix(0));}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[4];
f_1088(2,t3,C_fix(1));}}

/* k1086 in loop in k1074 in ##sys#read-string! in k594 in k588 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_i_not(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t4)){
t5=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* extras.scm: 227  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1084(t8,((C_word*)t0)[6],t5,t6,t7);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_plus(t1,((C_word*)t0)[5]));}}}

/* read-lines in k594 in k588 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_976r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_976r(t0,t1,t2);}}

static void C_ccall f_976r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[8]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
/* extras.scm: 201  call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1043,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 203  ##sys#check-port */
t11=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t4,lf[24]);}}

/* k1041 in read-lines in k594 in k588 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 204  doread */
t2=((C_word*)t0)[4];
f_988(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k594 in k588 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_988,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(1000000000));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_998,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word)li12),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_998(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in doread in read-lines in k594 in k588 */
static void C_fcall f_998(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_998,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 195  reverse */
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 196  read-line */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k1009 in loop in doread in read-lines in k594 in k588 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 198  reverse */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 199  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_998(t4,((C_word*)t0)[5],t2,t3);}}

/* read-line in k594 in k588 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_832r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_832r(t0,t1,t2);}}

static void C_ccall f_832r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):*((C_word*)lf[8]+1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_842,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_842(t8,(C_truep(t7)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_842(t6,C_SCHEME_FALSE);}}

/* k840 in read-line in k594 in k588 */
static void C_fcall f_842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_842,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_845,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 155  ##sys#check-port */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[17]);}

/* k843 in k840 in read-line in k594 in k588 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_845,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(8));
if(C_truep(t3)){
/* extras.scm: 156  rl */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t4=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_fix(256));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 159  ##sys#make-string */
t8=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t6)[1]);}}

/* k858 in k843 in k840 in read-line in k594 in k588 */
static void C_ccall f_860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_860,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word)li10),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_865(t7,((C_word*)t0)[2],C_fix(0));}

/* loop in k858 in k843 in k840 in read-line in k594 in k588 */
static void C_fcall f_865(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_865,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[7])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* extras.scm: 162  ##sys#substring */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 163  ##sys#read-char-0 */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}

/* k876 in loop in k858 in k843 in k840 in read-line in k594 in k588 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_878,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* extras.scm: 167  ##sys#substring */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);}}
else{
switch(t1){
case C_make_character(10):
/* extras.scm: 169  ##sys#substring */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 171  peek-char */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_929,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[8],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_943,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 178  make-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_929(t3,C_SCHEME_UNDEFINED);}}}}

/* k949 in k876 in loop in k858 in k843 in k840 in read-line in k594 in k588 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 178  ##sys#string-append */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k941 in k876 in loop in k858 in k843 in k840 in read-line in k594 in k588 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_929(t5,t4);}

/* k927 in k876 in loop in k858 in k843 in k840 in read-line in k594 in k588 */
static void C_fcall f_929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 181  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_865(t4,((C_word*)t0)[2],t3);}

/* k909 in k876 in loop in k858 in k843 in k840 in read-line in k594 in k588 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_911,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 173  ##sys#read-char-0 */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 175  ##sys#substring */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}}

/* k918 in k909 in k876 in loop in k858 in k843 in k840 in read-line in k594 in k588 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 174  ##sys#substring */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],C_fix(0),((C_word*)t0)[2]);}

/* randomize in k594 in k588 */
static void C_ccall f_789(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_789r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_789r(t0,t1,t2);}}

static void C_ccall f_789r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t3;
f_794(t4,(C_word)C_fudge(C_fix(2)));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[15]);
t6=t3;
f_794(t6,t4);}}

/* k792 in randomize in k594 in k588 */
static void C_fcall f_794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_randomize(t1));}

/* random in k594 in k588 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_777,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[14]);
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_fix(0):(C_word)C_random_fixnum(t2)));}

/* random-seed in k594 in k588 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_739r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_739r(t0,t1,t2);}}

static void C_ccall f_739r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_743,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_block_size(t2);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(1)))){
t5=(C_word)C_block_size(t2);
/* extras.scm: 118  ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t3,lf[10],lf[13],t5,C_fix(1));}
else{
t5=t3;
f_743(2,t5,C_SCHEME_FALSE);}}

/* k741 in random-seed in k594 in k588 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_746,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(((C_word*)t0)[2]))){
/* extras.scm: 120  current-seconds */
t3=*((C_word*)lf[12]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_746(2,t3,(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0)));}}

/* k744 in k741 in random-seed in k594 in k588 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_749,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 122  ##sys#check-integer */
t3=*((C_word*)lf[11]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[10]);}

/* k747 in k744 in k741 in random-seed in k594 in k588 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub45(C_SCHEME_UNDEFINED,t4));}

/* read-file in k594 in k588 */
static void C_ccall f_598(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr2r,(void*)f_598r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_598r(t0,t1,t2);}}

static void C_ccall f_598r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_660,a[2]=t3,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_665,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_670,a[2]=t5,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-port1135 */
t7=t6;
f_670(t7,t1);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-reader1233 */
t9=t5;
f_665(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-max1330 */
t11=t4;
f_660(t11,t1,t7,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body915 */
t13=t3;
f_600(t13,t1,t7,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-port11 in read-file in k594 in k588 */
static void C_fcall f_670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_670,NULL,2,t0,t1);}
/* def-reader1233 */
t2=((C_word*)t0)[2];
f_665(t2,t1,*((C_word*)lf[8]+1));}

/* def-reader12 in read-file in k594 in k588 */
static void C_fcall f_665(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_665,NULL,3,t0,t1,t2);}
/* def-max1330 */
t3=((C_word*)t0)[3];
f_660(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max13 in read-file in k594 in k588 */
static void C_fcall f_660(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_660,NULL,4,t0,t1,t2,t3);}
/* body915 */
t4=((C_word*)t0)[2];
f_600(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body9 in read-file in k594 in k588 */
static void C_fcall f_600(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_600,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_603,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word)li1),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_653,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 106  port? */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k651 in body9 in read-file in k594 in k588 */
static void C_ccall f_653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 107  slurp */
t2=((C_word*)t0)[5];
f_603(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm: 108  call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body9 in read-file in k594 in k588 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_611,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 102  reader */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k609 in slurp in body9 in read-file in k594 in k588 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_611,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_613,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li0),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_613(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* do21 in k609 in slurp in body9 in read-file in k594 in k588 */
static void C_fcall f_613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_613,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm: 105  reverse */
t7=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_633,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 102  reader */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k631 in do21 in k609 in slurp in body9 in read-file in k594 in k588 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_633,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_613(t4,((C_word*)t0)[2],t1,t2,t3);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[242] = {
{"toplevelextras.scm",(void*)C_extras_toplevel},
{"f_590extras.scm",(void*)f_590},
{"f_596extras.scm",(void*)f_596},
{"f_2994extras.scm",(void*)f_2994},
{"f_3384extras.scm",(void*)f_3384},
{"f_3341extras.scm",(void*)f_3341},
{"f_3374extras.scm",(void*)f_3374},
{"f_3349extras.scm",(void*)f_3349},
{"f_3335extras.scm",(void*)f_3335},
{"f_3329extras.scm",(void*)f_3329},
{"f_3323extras.scm",(void*)f_3323},
{"f_3025extras.scm",(void*)f_3025},
{"f_3029extras.scm",(void*)f_3029},
{"f_3312extras.scm",(void*)f_3312},
{"f_3032extras.scm",(void*)f_3032},
{"f_3037extras.scm",(void*)f_3037},
{"f_3098extras.scm",(void*)f_3098},
{"f_3276extras.scm",(void*)f_3276},
{"f_3231extras.scm",(void*)f_3231},
{"f_3234extras.scm",(void*)f_3234},
{"f_3213extras.scm",(void*)f_3213},
{"f_3209extras.scm",(void*)f_3209},
{"f_3196extras.scm",(void*)f_3196},
{"f_3192extras.scm",(void*)f_3192},
{"f_3179extras.scm",(void*)f_3179},
{"f_3175extras.scm",(void*)f_3175},
{"f_3162extras.scm",(void*)f_3162},
{"f_3149extras.scm",(void*)f_3149},
{"f_3136extras.scm",(void*)f_3136},
{"f_3111extras.scm",(void*)f_3111},
{"f_3070extras.scm",(void*)f_3070},
{"f_3092extras.scm",(void*)f_3092},
{"f_3053extras.scm",(void*)f_3053},
{"f_3046extras.scm",(void*)f_3046},
{"f_2996extras.scm",(void*)f_2996},
{"f_3000extras.scm",(void*)f_3000},
{"f_3007extras.scm",(void*)f_3007},
{"f_3009extras.scm",(void*)f_3009},
{"f_3013extras.scm",(void*)f_3013},
{"f_3003extras.scm",(void*)f_3003},
{"f_2915extras.scm",(void*)f_2915},
{"f_2918extras.scm",(void*)f_2918},
{"f_2934extras.scm",(void*)f_2934},
{"f_2943extras.scm",(void*)f_2943},
{"f_1643extras.scm",(void*)f_1643},
{"f_2906extras.scm",(void*)f_2906},
{"f_2910extras.scm",(void*)f_2910},
{"f_2259extras.scm",(void*)f_2259},
{"f_2814extras.scm",(void*)f_2814},
{"f_2824extras.scm",(void*)f_2824},
{"f_2805extras.scm",(void*)f_2805},
{"f_2799extras.scm",(void*)f_2799},
{"f_2777extras.scm",(void*)f_2777},
{"f_2784extras.scm",(void*)f_2784},
{"f_2771extras.scm",(void*)f_2771},
{"f_2765extras.scm",(void*)f_2765},
{"f_2759extras.scm",(void*)f_2759},
{"f_2753extras.scm",(void*)f_2753},
{"f_2747extras.scm",(void*)f_2747},
{"f_2741extras.scm",(void*)f_2741},
{"f_2593extras.scm",(void*)f_2593},
{"f_2739extras.scm",(void*)f_2739},
{"f_2691extras.scm",(void*)f_2691},
{"f_2721extras.scm",(void*)f_2721},
{"f_2706extras.scm",(void*)f_2706},
{"f_2596extras.scm",(void*)f_2596},
{"f_2623extras.scm",(void*)f_2623},
{"f_2619extras.scm",(void*)f_2619},
{"f_2637extras.scm",(void*)f_2637},
{"f_2664extras.scm",(void*)f_2664},
{"f_2660extras.scm",(void*)f_2660},
{"f_2678extras.scm",(void*)f_2678},
{"f_2516extras.scm",(void*)f_2516},
{"f_2522extras.scm",(void*)f_2522},
{"f_2591extras.scm",(void*)f_2591},
{"f_2587extras.scm",(void*)f_2587},
{"f_2579extras.scm",(void*)f_2579},
{"f_2575extras.scm",(void*)f_2575},
{"f_2553extras.scm",(void*)f_2553},
{"f_2545extras.scm",(void*)f_2545},
{"f_2507extras.scm",(void*)f_2507},
{"f_2511extras.scm",(void*)f_2511},
{"f_2479extras.scm",(void*)f_2479},
{"f_2505extras.scm",(void*)f_2505},
{"f_2483extras.scm",(void*)f_2483},
{"f_2414extras.scm",(void*)f_2414},
{"f_2421extras.scm",(void*)f_2421},
{"f_2448extras.scm",(void*)f_2448},
{"f_2474extras.scm",(void*)f_2474},
{"f_2432extras.scm",(void*)f_2432},
{"f_2327extras.scm",(void*)f_2327},
{"f_2340extras.scm",(void*)f_2340},
{"f_2378extras.scm",(void*)f_2378},
{"f_2343extras.scm",(void*)f_2343},
{"f_2372extras.scm",(void*)f_2372},
{"f_2376extras.scm",(void*)f_2376},
{"f_2356extras.scm",(void*)f_2356},
{"f_2295extras.scm",(void*)f_2295},
{"f_2318extras.scm",(void*)f_2318},
{"f_2311extras.scm",(void*)f_2311},
{"f_2262extras.scm",(void*)f_2262},
{"f_2293extras.scm",(void*)f_2293},
{"f_2286extras.scm",(void*)f_2286},
{"f_1756extras.scm",(void*)f_1756},
{"f_1935extras.scm",(void*)f_1935},
{"f_2201extras.scm",(void*)f_2201},
{"f_2240extras.scm",(void*)f_2240},
{"f_2250extras.scm",(void*)f_2250},
{"f_2243extras.scm",(void*)f_2243},
{"f_2218extras.scm",(void*)f_2218},
{"f_2228extras.scm",(void*)f_2228},
{"f_2221extras.scm",(void*)f_2221},
{"f_2208extras.scm",(void*)f_2208},
{"f_2185extras.scm",(void*)f_2185},
{"f_2188extras.scm",(void*)f_2188},
{"f_2195extras.scm",(void*)f_2195},
{"f_2167extras.scm",(void*)f_2167},
{"f_2083extras.scm",(void*)f_2083},
{"f_2086extras.scm",(void*)f_2086},
{"f_2142extras.scm",(void*)f_2142},
{"f_2121extras.scm",(void*)f_2121},
{"f_2128extras.scm",(void*)f_2128},
{"f_2105extras.scm",(void*)f_2105},
{"f_2112extras.scm",(void*)f_2112},
{"f_2077extras.scm",(void*)f_2077},
{"f_1993extras.scm",(void*)f_1993},
{"f_1995extras.scm",(void*)f_1995},
{"f_2002extras.scm",(void*)f_2002},
{"f_2054extras.scm",(void*)f_2054},
{"f_2050extras.scm",(void*)f_2050},
{"f_2033extras.scm",(void*)f_2033},
{"f_2029extras.scm",(void*)f_2029},
{"f_2025extras.scm",(void*)f_2025},
{"f_1974extras.scm",(void*)f_1974},
{"f_1951extras.scm",(void*)f_1951},
{"f_1954extras.scm",(void*)f_1954},
{"f_1961extras.scm",(void*)f_1961},
{"f_1942extras.scm",(void*)f_1942},
{"f_1912extras.scm",(void*)f_1912},
{"f_1916extras.scm",(void*)f_1916},
{"f_1759extras.scm",(void*)f_1759},
{"f_1766extras.scm",(void*)f_1766},
{"f_1777extras.scm",(void*)f_1777},
{"f_1786extras.scm",(void*)f_1786},
{"f_1869extras.scm",(void*)f_1869},
{"f_1804extras.scm",(void*)f_1804},
{"f_1806extras.scm",(void*)f_1806},
{"f_1858extras.scm",(void*)f_1858},
{"f_1854extras.scm",(void*)f_1854},
{"f_1838extras.scm",(void*)f_1838},
{"f_1830extras.scm",(void*)f_1830},
{"f_1737extras.scm",(void*)f_1737},
{"f_1747extras.scm",(void*)f_1747},
{"f_1704extras.scm",(void*)f_1704},
{"f_1698extras.scm",(void*)f_1698},
{"f_1646extras.scm",(void*)f_1646},
{"f_1678extras.scm",(void*)f_1678},
{"f_1605extras.scm",(void*)f_1605},
{"f_1609extras.scm",(void*)f_1609},
{"f_1615extras.scm",(void*)f_1615},
{"f_1565extras.scm",(void*)f_1565},
{"f_1569extras.scm",(void*)f_1569},
{"f_1572extras.scm",(void*)f_1572},
{"f_1575extras.scm",(void*)f_1575},
{"f_1544extras.scm",(void*)f_1544},
{"f_1551extras.scm",(void*)f_1551},
{"f_1557extras.scm",(void*)f_1557},
{"f_1455extras.scm",(void*)f_1455},
{"f_1496extras.scm",(void*)f_1496},
{"f_1491extras.scm",(void*)f_1491},
{"f_1460extras.scm",(void*)f_1460},
{"f_1464extras.scm",(void*)f_1464},
{"f_1477extras.scm",(void*)f_1477},
{"f_1474extras.scm",(void*)f_1474},
{"f_1386extras.scm",(void*)f_1386},
{"f_1390extras.scm",(void*)f_1390},
{"f_1393extras.scm",(void*)f_1393},
{"f_1396extras.scm",(void*)f_1396},
{"f_1401extras.scm",(void*)f_1401},
{"f_1405extras.scm",(void*)f_1405},
{"f_1411extras.scm",(void*)f_1411},
{"f_1421extras.scm",(void*)f_1421},
{"f_1414extras.scm",(void*)f_1414},
{"f_1326extras.scm",(void*)f_1326},
{"f_1338extras.scm",(void*)f_1338},
{"f_1333extras.scm",(void*)f_1333},
{"f_1328extras.scm",(void*)f_1328},
{"f_1253extras.scm",(void*)f_1253},
{"f_1257extras.scm",(void*)f_1257},
{"f_1281extras.scm",(void*)f_1281},
{"f_1286extras.scm",(void*)f_1286},
{"f_1290extras.scm",(void*)f_1290},
{"f_1296extras.scm",(void*)f_1296},
{"f_1308extras.scm",(void*)f_1308},
{"f_1266extras.scm",(void*)f_1266},
{"f_1269extras.scm",(void*)f_1269},
{"f_1156extras.scm",(void*)f_1156},
{"f_1205extras.scm",(void*)f_1205},
{"f_1200extras.scm",(void*)f_1200},
{"f_1158extras.scm",(void*)f_1158},
{"f_1162extras.scm",(void*)f_1162},
{"f_1168extras.scm",(void*)f_1168},
{"f_1066extras.scm",(void*)f_1066},
{"f_1150extras.scm",(void*)f_1150},
{"f_1076extras.scm",(void*)f_1076},
{"f_1084extras.scm",(void*)f_1084},
{"f_1133extras.scm",(void*)f_1133},
{"f_1088extras.scm",(void*)f_1088},
{"f_976extras.scm",(void*)f_976},
{"f_1043extras.scm",(void*)f_1043},
{"f_988extras.scm",(void*)f_988},
{"f_998extras.scm",(void*)f_998},
{"f_1011extras.scm",(void*)f_1011},
{"f_832extras.scm",(void*)f_832},
{"f_842extras.scm",(void*)f_842},
{"f_845extras.scm",(void*)f_845},
{"f_860extras.scm",(void*)f_860},
{"f_865extras.scm",(void*)f_865},
{"f_878extras.scm",(void*)f_878},
{"f_951extras.scm",(void*)f_951},
{"f_943extras.scm",(void*)f_943},
{"f_929extras.scm",(void*)f_929},
{"f_911extras.scm",(void*)f_911},
{"f_920extras.scm",(void*)f_920},
{"f_789extras.scm",(void*)f_789},
{"f_794extras.scm",(void*)f_794},
{"f_777extras.scm",(void*)f_777},
{"f_739extras.scm",(void*)f_739},
{"f_743extras.scm",(void*)f_743},
{"f_746extras.scm",(void*)f_746},
{"f_749extras.scm",(void*)f_749},
{"f_598extras.scm",(void*)f_598},
{"f_670extras.scm",(void*)f_670},
{"f_665extras.scm",(void*)f_665},
{"f_660extras.scm",(void*)f_660},
{"f_600extras.scm",(void*)f_600},
{"f_653extras.scm",(void*)f_653},
{"f_603extras.scm",(void*)f_603},
{"f_611extras.scm",(void*)f_611},
{"f_613extras.scm",(void*)f_613},
{"f_633extras.scm",(void*)f_633},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
