/* Generated from extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-04-15 09:10
   Version 4.0.1 - SVN rev. 14255
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-04-15 on lenovo-1 (MINGW32_NT-6.0)
   command line: extras.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file extras.c -extend ./private-namespace.scm
   unit: extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[133];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,23),40,100,111,108,111,111,112,56,56,32,120,57,53,32,105,57,54,32,120,115,57,55,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,115,108,117,114,112,32,112,111,114,116,56,55,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,55,49,32,112,111,114,116,56,50,32,114,101,97,100,101,114,56,51,32,109,97,120,56,52,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,109,97,120,55,53,32,37,112,111,114,116,54,56,49,49,50,32,37,114,101,97,100,101,114,54,57,49,49,51,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,114,101,97,100,101,114,55,52,32,37,112,111,114,116,54,56,49,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,112,111,114,116,55,51,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,21),40,114,101,97,100,45,102,105,108,101,32,46,32,116,109,112,54,48,54,49,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,114,97,110,100,111,109,45,115,101,101,100,32,46,32,110,49,52,55,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,18),40,114,97,110,100,111,109,105,122,101,32,46,32,110,49,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,13),40,114,97,110,100,111,109,32,110,49,53,57,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,50,48,56,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,21),40,114,101,97,100,45,108,105,110,101,32,46,32,97,114,103,115,49,55,51,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,110,115,50,53,53,32,110,50,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,100,111,114,101,97,100,32,112,111,114,116,50,53,49,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,108,105,110,101,115,32,46,32,112,111,114,116,45,97,110,100,45,109,97,120,50,51,56,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,115,116,97,114,116,50,57,49,32,110,50,57,50,32,109,50,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,33,32,110,50,55,50,32,100,101,115,116,50,55,51,32,112,111,114,116,50,55,52,32,115,116,97,114,116,50,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,51,51,55,32,112,111,114,116,51,52,55,32,115,116,97,114,116,51,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,115,116,97,114,116,51,52,48,32,37,112,111,114,116,51,51,53,51,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,51,51,57,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,39),40,114,101,97,100,45,115,116,114,105,110,103,33,32,110,51,50,54,32,100,101,115,116,51,50,55,32,46,32,116,109,112,51,50,53,51,50,56,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,51,57,57,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,47,112,111,114,116,32,110,51,55,56,32,112,51,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,52,51,52,32,110,52,52,52,32,112,111,114,116,52,52,53,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,111,114,116,52,51,55,32,37,110,52,51,50,52,52,57,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,52,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,114,101,97,100,45,115,116,114,105,110,103,32,46,32,116,109,112,52,50,52,52,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,116,111,107,101,110,32,112,114,101,100,52,54,54,32,46,32,112,111,114,116,52,54,55,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,53,48,54,32,110,53,49,53,32,112,111,114,116,53,49,54,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,111,114,116,53,48,57,32,37,110,53,48,52,53,50,54,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,53,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,115,116,114,105,110,103,32,115,52,57,53,32,46,32,109,111,114,101,52,57,54,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,108,105,110,101,32,115,116,114,53,52,52,32,46,32,112,111,114,116,53,52,53,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,23),40,114,101,97,100,45,98,121,116,101,32,46,32,116,109,112,53,53,57,53,54,48,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,32),40,119,114,105,116,101,45,98,121,116,101,32,98,121,116,101,53,56,51,32,46,32,116,109,112,53,56,50,53,56,52,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,18),40,114,101,97,100,45,109,97,99,114,111,63,32,108,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,17),40,114,101,97,100,45,109,97,99,114,111,45,98,111,100,121,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,109,97,99,114,111,45,112,114,101,102,105,120,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,19),40,111,117,116,32,115,116,114,54,54,51,32,99,111,108,54,54,52,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,54,57,48,32,99,111,108,54,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,119,114,45,108,115,116,32,108,54,56,53,32,99,111,108,54,56,54,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,24),40,119,114,45,101,120,112,114,32,101,120,112,114,54,56,50,32,99,111,108,54,56,51,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,105,55,48,57,32,106,55,49,48,32,99,111,108,55,49,49,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,18),40,119,114,32,111,98,106,54,55,48,32,99,111,108,54,55,49,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,115,112,97,99,101,115,32,110,55,55,54,32,99,111,108,55,55,55,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,105,110,100,101,110,116,32,116,111,55,55,57,32,99,111,108,55,56,48,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,106,49,48,52,57,32,107,49,48,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,31),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,49,48,51,54,32,105,49,48,51,55,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,14),40,97,51,48,48,53,32,115,116,114,56,48,48,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,38),40,112,114,32,111,98,106,55,56,54,32,99,111,108,55,56,55,32,101,120,116,114,97,55,56,56,32,112,112,45,112,97,105,114,55,56,57,41,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,33),40,112,112,45,101,120,112,114,32,101,120,112,114,56,48,53,32,99,111,108,56,48,54,32,101,120,116,114,97,56,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,44),40,112,112,45,99,97,108,108,32,101,120,112,114,56,49,51,32,99,111,108,56,49,52,32,101,120,116,114,97,56,49,53,32,112,112,45,105,116,101,109,56,49,54,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,41),40,112,112,45,108,105,115,116,32,108,56,50,50,32,99,111,108,56,50,51,32,101,120,116,114,97,56,50,52,32,112,112,45,105,116,101,109,56,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,56,51,55,32,99,111,108,56,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,50),40,112,112,45,100,111,119,110,32,108,56,50,57,32,99,111,108,49,56,51,48,32,99,111,108,50,56,51,49,32,101,120,116,114,97,56,51,50,32,112,112,45,105,116,101,109,56,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,31),40,116,97,105,108,51,32,114,101,115,116,56,57,55,32,99,111,108,49,56,57,56,32,99,111,108,50,56,57,57,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,50,32,114,101,115,116,56,56,50,32,99,111,108,49,56,56,51,32,99,111,108,50,56,56,52,32,99,111,108,51,56,56,53,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,49,32,114,101,115,116,56,54,55,32,99,111,108,49,56,54,56,32,99,111,108,50,56,54,57,32,99,111,108,51,56,55,48,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,70),40,112,112,45,103,101,110,101,114,97,108,32,101,120,112,114,56,53,53,32,99,111,108,56,53,54,32,101,120,116,114,97,56,53,55,32,110,97,109,101,100,63,56,53,56,32,112,112,45,49,56,53,57,32,112,112,45,50,56,54,48,32,112,112,45,51,56,54,49,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,35),40,112,112,45,101,120,112,114,45,108,105,115,116,32,108,57,50,49,32,99,111,108,57,50,50,32,101,120,116,114,97,57,50,51,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,35),40,112,112,45,108,97,109,98,100,97,32,101,120,112,114,57,50,53,32,99,111,108,57,50,54,32,101,120,116,114,97,57,50,55,41,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,31),40,112,112,45,105,102,32,101,120,112,114,57,50,57,32,99,111,108,57,51,48,32,101,120,116,114,97,57,51,49,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,111,110,100,32,101,120,112,114,57,51,51,32,99,111,108,57,51,52,32,101,120,116,114,97,57,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,97,115,101,32,101,120,112,114,57,51,55,32,99,111,108,57,51,56,32,101,120,116,114,97,57,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,32),40,112,112,45,97,110,100,32,101,120,112,114,57,52,49,32,99,111,108,57,52,50,32,101,120,116,114,97,57,52,51,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,32),40,112,112,45,108,101,116,32,101,120,112,114,57,52,53,32,99,111,108,57,52,54,32,101,120,116,114,97,57,52,55,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,34),40,112,112,45,98,101,103,105,110,32,101,120,112,114,57,53,55,32,99,111,108,57,53,56,32,101,120,116,114,97,57,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,31),40,112,112,45,100,111,32,101,120,112,114,57,54,49,32,99,111,108,57,54,50,32,101,120,116,114,97,57,54,51,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,15),40,115,116,121,108,101,32,104,101,97,100,57,54,53,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,18),40,112,112,32,111,98,106,55,53,50,32,99,111,108,55,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,53),40,103,101,110,101,114,105,99,45,119,114,105,116,101,32,111,98,106,54,48,50,32,100,105,115,112,108,97,121,63,54,48,51,32,119,105,100,116,104,54,48,52,32,111,117,116,112,117,116,54,48,53,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,13),40,97,51,54,51,54,32,115,49,48,54,52,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,32),40,112,114,101,116,116,121,45,112,114,105,110,116,32,111,98,106,49,48,53,57,32,46,32,111,112,116,49,48,54,48,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,6),40,110,101,120,116,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,6),40,115,107,105,112,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,22),40,114,101,99,32,109,115,103,49,48,56,57,32,97,114,103,115,49,48,57,48,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,44),40,102,112,114,105,110,116,102,48,32,108,111,99,49,48,55,54,32,112,111,114,116,49,48,55,55,32,109,115,103,49,48,55,56,32,97,114,103,115,49,48,55,57,41,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,38),40,102,112,114,105,110,116,102,32,112,111,114,116,49,49,54,55,32,102,115,116,114,49,49,54,56,32,46,32,97,114,103,115,49,49,54,57,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,28),40,112,114,105,110,116,102,32,102,115,116,114,49,49,55,51,32,46,32,97,114,103,115,49,49,55,52,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,29),40,115,112,114,105,110,116,102,32,102,115,116,114,49,49,55,56,32,46,32,97,114,103,115,49,49,55,57,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,34),40,102,111,114,109,97,116,32,102,109,116,45,111,114,45,100,115,116,49,49,56,54,32,46,32,97,114,103,115,49,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1379 */
static C_word C_fcall stub142(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub142(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned int t0=(unsigned int )C_num_to_unsigned_int(C_a0);
srand(t0);
return C_r;}

C_noret_decl(C_extras_toplevel)
C_externexport void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3653)
static void C_fcall f_3653(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_fcall f_3691(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3726)
static void C_fcall f_3726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static C_word C_fcall f_3904(C_word t0,C_word t1);
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_ccall f_3862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_fcall f_3707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static C_word C_fcall f_3700(C_word t0);
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3635)
static void C_ccall f_3635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_fcall f_2271(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_fcall f_2887(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3442)
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3452)
static void C_fcall f_3452(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3412)
static void C_fcall f_3412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3221)
static void C_fcall f_3221(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_fcall f_3224(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_fcall f_3306(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3144)
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_fcall f_3107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_fcall f_2384(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2630)
static void C_fcall f_2630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_fcall f_2387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_fcall f_2414(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_fcall f_2434(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_fcall f_2365(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static C_word C_fcall f_2332(C_word t0);
C_noret_decl(f_2326)
static C_word C_fcall f_2326(C_word t0);
C_noret_decl(f_2274)
static void C_fcall f_2274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_fcall f_2306(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2124)
static void C_fcall f_2124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_fcall f_2119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2088)
static void C_fcall f_2088(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_fcall f_2105(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_fcall f_2029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1966)
static void C_fcall f_1966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_fcall f_1961(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1956)
static void C_fcall f_1956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_fcall f_1914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1833)
static void C_fcall f_1833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_fcall f_1796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_fcall f_1704(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_fcall f_1712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1626)
static void C_fcall f_1626(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1470)
static void C_fcall f_1470(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_fcall f_1493(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_fcall f_1557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1313)
static void C_fcall f_1313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_fcall f_1308(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1303)
static void C_fcall f_1303(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1243)
static void C_fcall f_1243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_fcall f_1256(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3653)
static void C_fcall trf_3653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3653(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3653(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3691)
static void C_fcall trf_3691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3691(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3691(t0,t1,t2,t3);}

C_noret_decl(trf_3726)
static void C_fcall trf_3726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3726(t0,t1);}

C_noret_decl(trf_3707)
static void C_fcall trf_3707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3707(t0,t1);}

C_noret_decl(trf_2271)
static void C_fcall trf_2271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2271(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2271(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2887)
static void C_fcall trf_2887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2887(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2887(t0,t1,t2,t3);}

C_noret_decl(trf_3442)
static void C_fcall trf_3442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3442(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3442(t0,t1,t2);}

C_noret_decl(trf_3452)
static void C_fcall trf_3452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3452(t0,t1);}

C_noret_decl(trf_3412)
static void C_fcall trf_3412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3412(t0,t1);}

C_noret_decl(trf_3221)
static void C_fcall trf_3221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3221(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3221(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_3224)
static void C_fcall trf_3224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3224(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3224(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3265)
static void C_fcall trf_3265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3265(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3265(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3306)
static void C_fcall trf_3306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3306(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3306(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3144)
static void C_fcall trf_3144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3144(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3144(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3150)
static void C_fcall trf_3150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3150(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3150(t0,t1,t2,t3);}

C_noret_decl(trf_3135)
static void C_fcall trf_3135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3135(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3135(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3107)
static void C_fcall trf_3107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3107(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3107(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2955)
static void C_fcall trf_2955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2955(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2955(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3546)
static void C_fcall trf_3546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3546(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3546(t0,t1,t2,t3);}

C_noret_decl(trf_3571)
static void C_fcall trf_3571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3571(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3571(t0,t1,t2,t3);}

C_noret_decl(trf_2923)
static void C_fcall trf_2923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2923(t0,t1,t2,t3);}

C_noret_decl(trf_2890)
static void C_fcall trf_2890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2890(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2890(t0,t1,t2,t3);}

C_noret_decl(trf_2384)
static void C_fcall trf_2384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2384(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2384(t0,t1,t2,t3);}

C_noret_decl(trf_2623)
static void C_fcall trf_2623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2623(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2623(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2630)
static void C_fcall trf_2630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2630(t0,t1);}

C_noret_decl(trf_2387)
static void C_fcall trf_2387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2387(t0,t1,t2,t3);}

C_noret_decl(trf_2414)
static void C_fcall trf_2414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2414(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2414(t0,t1,t2,t3);}

C_noret_decl(trf_2434)
static void C_fcall trf_2434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2434(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2434(t0,t1,t2,t3);}

C_noret_decl(trf_2365)
static void C_fcall trf_2365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2365(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2365(t0,t1,t2,t3);}

C_noret_decl(trf_2274)
static void C_fcall trf_2274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2274(t0,t1);}

C_noret_decl(trf_2306)
static void C_fcall trf_2306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2306(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2306(t0,t1);}

C_noret_decl(trf_2124)
static void C_fcall trf_2124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2124(t0,t1);}

C_noret_decl(trf_2119)
static void C_fcall trf_2119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2119(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2119(t0,t1,t2);}

C_noret_decl(trf_2088)
static void C_fcall trf_2088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2088(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2088(t0,t1,t2,t3);}

C_noret_decl(trf_2105)
static void C_fcall trf_2105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2105(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2105(t0,t1);}

C_noret_decl(trf_2029)
static void C_fcall trf_2029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2029(t0,t1);}

C_noret_decl(trf_1966)
static void C_fcall trf_1966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1966(t0,t1);}

C_noret_decl(trf_1961)
static void C_fcall trf_1961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1961(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1961(t0,t1,t2);}

C_noret_decl(trf_1956)
static void C_fcall trf_1956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1956(t0,t1,t2);}

C_noret_decl(trf_1914)
static void C_fcall trf_1914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1914(t0,t1,t2);}

C_noret_decl(trf_1833)
static void C_fcall trf_1833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1833(t0,t1);}

C_noret_decl(trf_1828)
static void C_fcall trf_1828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1828(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1828(t0,t1,t2);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1786(t0,t1,t2,t3);}

C_noret_decl(trf_1796)
static void C_fcall trf_1796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1796(t0,t1);}

C_noret_decl(trf_1704)
static void C_fcall trf_1704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1704(t0,t1);}

C_noret_decl(trf_1712)
static void C_fcall trf_1712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1712(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1712(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1626)
static void C_fcall trf_1626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1626(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1626(t0,t1,t2,t3);}

C_noret_decl(trf_1470)
static void C_fcall trf_1470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1470(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1470(t0,t1);}

C_noret_decl(trf_1493)
static void C_fcall trf_1493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1493(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1493(t0,t1,t2);}

C_noret_decl(trf_1557)
static void C_fcall trf_1557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1557(t0,t1);}

C_noret_decl(trf_1313)
static void C_fcall trf_1313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1313(t0,t1);}

C_noret_decl(trf_1308)
static void C_fcall trf_1308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1308(t0,t1,t2);}

C_noret_decl(trf_1303)
static void C_fcall trf_1303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1303(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1303(t0,t1,t2,t3);}

C_noret_decl(trf_1243)
static void C_fcall trf_1243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1243(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1243(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1256)
static void C_fcall trf_1256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1256(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1256(t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(840)){
C_save(t1);
C_rereclaim2(840*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,133);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],4,"read");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],20,"call-with-input-file");
lf[5]=C_h_intern(&lf[5],9,"read-file");
lf[6]=C_h_intern(&lf[6],5,"port\077");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-input");
lf[8]=C_h_intern(&lf[8],9,"\003syserror");
lf[9]=C_h_intern(&lf[9],11,"random-seed");
lf[10]=C_h_intern(&lf[10],17,"\003syscheck-integer");
lf[11]=C_h_intern(&lf[11],15,"current-seconds");
lf[12]=C_h_intern(&lf[12],9,"randomize");
lf[13]=C_h_intern(&lf[13],6,"random");
lf[14]=C_h_intern(&lf[14],11,"make-string");
lf[15]=C_h_intern(&lf[15],9,"read-line");
lf[16]=C_h_intern(&lf[16],13,"\003syssubstring");
lf[17]=C_h_intern(&lf[17],15,"\003sysread-char-0");
lf[18]=C_h_intern(&lf[18],9,"peek-char");
lf[19]=C_h_intern(&lf[19],17,"\003sysstring-append");
lf[20]=C_h_intern(&lf[20],15,"\003sysmake-string");
lf[21]=C_h_intern(&lf[21],14,"\003syscheck-port");
lf[22]=C_h_intern(&lf[22],10,"read-lines");
lf[23]=C_h_intern(&lf[23],16,"\003sysread-string!");
lf[24]=C_h_intern(&lf[24],12,"read-string!");
lf[25]=C_h_intern(&lf[25],18,"open-output-string");
lf[26]=C_h_intern(&lf[26],17,"get-output-string");
lf[27]=C_h_intern(&lf[27],20,"\003sysread-string/port");
lf[28]=C_h_intern(&lf[28],11,"read-string");
lf[29]=C_h_intern(&lf[29],19,"\003syswrite-char/port");
lf[30]=C_h_intern(&lf[30],10,"read-token");
lf[31]=C_h_intern(&lf[31],16,"\003syswrite-char-0");
lf[32]=C_h_intern(&lf[32],15,"\003syspeek-char-0");
lf[33]=C_h_intern(&lf[33],7,"display");
lf[34]=C_h_intern(&lf[34],12,"write-string");
lf[35]=C_h_intern(&lf[35],19,"\003sysstandard-output");
lf[36]=C_h_intern(&lf[36],7,"newline");
lf[37]=C_h_intern(&lf[37],10,"write-line");
lf[38]=C_h_intern(&lf[38],9,"read-byte");
lf[39]=C_h_intern(&lf[39],10,"write-byte");
lf[41]=C_h_intern(&lf[41],5,"quote");
lf[42]=C_h_intern(&lf[42],10,"quasiquote");
lf[43]=C_h_intern(&lf[43],7,"unquote");
lf[44]=C_h_intern(&lf[44],16,"unquote-splicing");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001`");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\002,@");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\003 . ");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\002()");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\005#!eof");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[57]=C_h_intern(&lf[57],12,"vector->list");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002#t");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[60]=C_h_intern(&lf[60],18,"\003sysnumber->string");
lf[61]=C_h_intern(&lf[61],9,"\003sysprint");
lf[62]=C_h_intern(&lf[62],21,"\003sysprocedure->string");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001x");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\001u");
lf[69]=C_h_intern(&lf[69],9,"char-name");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\002#\134");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\016#<unspecified>");
lf[73]=C_h_intern(&lf[73],19,"\003syspointer->string");
lf[74]=C_h_intern(&lf[74],28,"\003sysarbitrary-unbound-symbol");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\020#<unbound value>");
lf[76]=C_h_intern(&lf[76],19,"\003sysuser-print-hook");
lf[77]=C_h_intern(&lf[77],13,"string-append");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\007#<port ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\025#<static blob of size");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\017#<blob of size ");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\002#>");
lf[84]=C_h_intern(&lf[84],23,"\003syslambda-info->string");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\016#<lambda info ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\025#<unprintable object>");
lf[87]=C_h_intern(&lf[87],11,"\003sysnumber\077");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[91]=C_h_intern(&lf[91],3,"max");
lf[92]=C_h_intern(&lf[92],28,"\003syssymbol->qualified-string");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[100]=C_h_intern(&lf[100],6,"lambda");
lf[101]=C_h_intern(&lf[101],2,"if");
lf[102]=C_h_intern(&lf[102],4,"set!");
lf[103]=C_h_intern(&lf[103],4,"cond");
lf[104]=C_h_intern(&lf[104],4,"case");
lf[105]=C_h_intern(&lf[105],3,"and");
lf[106]=C_h_intern(&lf[106],2,"or");
lf[107]=C_h_intern(&lf[107],3,"let");
lf[108]=C_h_intern(&lf[108],5,"begin");
lf[109]=C_h_intern(&lf[109],2,"do");
lf[110]=C_h_intern(&lf[110],4,"let*");
lf[111]=C_h_intern(&lf[111],6,"letrec");
lf[112]=C_h_intern(&lf[112],6,"define");
lf[113]=C_h_intern(&lf[113],18,"pretty-print-width");
lf[114]=C_h_intern(&lf[114],12,"pretty-print");
lf[115]=C_h_intern(&lf[115],19,"current-output-port");
lf[116]=C_h_intern(&lf[116],2,"pp");
lf[117]=C_h_intern(&lf[117],5,"write");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[120]=C_h_intern(&lf[120],16,"\003sysflush-output");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\037illegal format-string character");
lf[122]=C_h_intern(&lf[122],13,"\003systty-port\077");
lf[123]=C_h_intern(&lf[123],7,"fprintf");
lf[124]=C_h_intern(&lf[124],6,"printf");
lf[125]=C_h_intern(&lf[125],7,"sprintf");
lf[126]=C_h_intern(&lf[126],6,"format");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal destination");
lf[128]=C_h_intern(&lf[128],12,"output-port\077");
lf[129]=C_h_intern(&lf[129],17,"register-feature!");
lf[130]=C_h_intern(&lf[130],7,"srfi-28");
lf[131]=C_h_intern(&lf[131],14,"make-parameter");
lf[132]=C_h_intern(&lf[132],6,"extras");
C_register_lf2(lf,133,create_ptable());
t2=C_mutate(&lf[0] /* (set! c133 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1231 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1234 in k1231 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 66   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t2,lf[132]);}

/* k1237 in k1234 in k1231 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[67],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=*((C_word*)lf[4]+1);
t5=C_mutate((C_word*)lf[5]+1 /* (set! read-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1241,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li6),tmp=(C_word)a,a+=6,tmp));
t6=C_mutate((C_word*)lf[9]+1 /* (set! random-seed ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1382,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[12]+1 /* (set! randomize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! random ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[14]+1);
t10=C_mutate((C_word*)lf[15]+1 /* (set! read-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=t9,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[15]+1);
t12=*((C_word*)lf[4]+1);
t13=*((C_word*)lf[3]+1);
t14=C_mutate((C_word*)lf[22]+1 /* (set! read-lines ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1604,a[2]=t12,a[3]=t11,a[4]=t13,a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t15=C_mutate((C_word*)lf[23]+1 /* (set! read-string! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[24]+1 /* (set! read-string! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[25]+1);
t18=*((C_word*)lf[26]+1);
t19=C_mutate((C_word*)lf[27]+1 /* (set! read-string/port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1881,a[2]=t17,a[3]=t18,a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp));
t20=C_mutate((C_word*)lf[28]+1 /* (set! read-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1954,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[25]+1);
t22=*((C_word*)lf[26]+1);
t23=C_mutate((C_word*)lf[30]+1 /* (set! read-token ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2014,a[2]=t21,a[3]=t22,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t24=*((C_word*)lf[33]+1);
t25=C_mutate((C_word*)lf[34]+1 /* (set! write-string ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=t24,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t26=*((C_word*)lf[33]+1);
t27=*((C_word*)lf[36]+1);
t28=C_mutate((C_word*)lf[37]+1 /* (set! write-line ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2172,a[2]=t26,a[3]=t27,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t29=C_mutate((C_word*)lf[38]+1 /* (set! read-byte ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2193,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[39]+1 /* (set! write-byte ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2233,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[25]+1);
t32=*((C_word*)lf[26]+1);
t33=C_mutate(&lf[40] /* (set! generic-write ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2271,a[2]=t31,a[3]=t32,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp));
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 617  make-parameter */
t35=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t34,C_fix(79));}

/* k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! pretty-print-width ...) */,t1);
t3=C_mutate((C_word*)lf[114]+1 /* (set! pretty-print ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3624,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[116]+1 /* (set! pp ...) */,*((C_word*)lf[114]+1));
t5=*((C_word*)lf[117]+1);
t6=*((C_word*)lf[36]+1);
t7=*((C_word*)lf[33]+1);
t8=*((C_word*)lf[25]+1);
t9=*((C_word*)lf[26]+1);
t10=C_mutate(&lf[118] /* (set! fprintf0 ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3653,a[2]=t8,a[3]=t6,a[4]=t7,a[5]=t5,a[6]=t9,a[7]=((C_word)li78),tmp=(C_word)a,a+=8,tmp));
t11=C_mutate((C_word*)lf[123]+1 /* (set! fprintf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3951,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[124]+1 /* (set! printf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3957,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[125]+1 /* (set! sprintf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3963,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t14=*((C_word*)lf[123]+1);
t15=*((C_word*)lf[125]+1);
t16=*((C_word*)lf[124]+1);
t17=C_mutate((C_word*)lf[126]+1 /* (set! format ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=t14,a[3]=t15,a[4]=t16,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 709  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t18,lf[130]);}

/* k4010 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3969r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3969r(t0,t1,t2,t3);}}

static void C_ccall f_3969r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3977,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
if(C_truep(t6)){
if(C_truep((C_word)C_booleanp(t2))){
t7=t5;
f_3977(2,t7,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_3977(2,t9,((C_word*)t0)[3]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 704  output-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),t7,t2);}}}
else{
t7=t5;
f_3977(2,t7,((C_word*)t0)[3]);}}

/* k4000 in format in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_3977(2,t4,((C_word*)t0)[2]);}
else{
/* extras.scm: 706  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[126],lf[127],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3975 in format in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* sprintf in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3963r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3963r(t0,t1,t2,t3);}}

static void C_ccall f_3963r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 694  fprintf0 */
t4=lf[118];
f_3653(t4,t1,lf[125],C_SCHEME_FALSE,t2,t3);}

/* printf in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3957r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3957r(t0,t1,t2,t3);}}

static void C_ccall f_3957r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 691  fprintf0 */
t4=lf[118];
f_3653(t4,t1,lf[124],*((C_word*)lf[35]+1),t2,t3);}

/* fprintf in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3951r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3951r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3951r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* extras.scm: 688  fprintf0 */
t5=lf[118];
f_3653(t5,t1,lf[123],t2,t3,t4);}

/* fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_fcall f_3653(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3653,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
/* extras.scm: 636  ##sys#check-port */
t7=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,t2);}
else{
t7=t6;
f_3657(2,t7,C_SCHEME_UNDEFINED);}}

/* k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[11])){
/* extras.scm: 637  ##sys#tty-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[122]+1)))(3,*((C_word*)lf[122]+1),t3,((C_word*)t0)[11]);}
else{
t4=t3;
f_3940(2,t4,C_SCHEME_FALSE);}}

/* k3938 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3660(2,t2,((C_word*)t0)[3]);}
else{
/* extras.scm: 639  open-output-string */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}}

/* k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3663,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li77),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3691(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_fcall f_3691(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3691,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_string_2(t2,((C_word*)t0)[7]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3707,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t12,a[10]=t9,a[11]=t8,a[12]=t7,a[13]=((C_word)li76),tmp=(C_word)a,a+=14,tmp));
t14=((C_word*)t12)[1];
f_3726(t14,t1);}

/* loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_fcall f_3726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3726,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_3700(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3739,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
t5=(C_truep(t4)?(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=f_3700(((C_word*)t0)[10]);
t7=(C_word)C_u_i_char_upcase(t6);
switch(t7){
case C_make_character(83):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 660  next */
t9=((C_word*)t0)[6];
f_3707(t9,t8);
case C_make_character(65):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 661  next */
t9=((C_word*)t0)[6];
f_3707(t9,t8);
case C_make_character(67):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3790,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 662  next */
t9=((C_word*)t0)[6];
f_3707(t9,t8);
case C_make_character(66):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3807,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 663  next */
t10=((C_word*)t0)[6];
f_3707(t10,t9);
case C_make_character(79):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3824,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 664  next */
t10=((C_word*)t0)[6];
f_3707(t10,t9);
case C_make_character(88):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3841,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 665  next */
t10=((C_word*)t0)[6];
f_3707(t10,t9);
case C_make_character(33):
/* extras.scm: 666  ##sys#flush-output */
t8=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t3,((C_word*)t0)[7]);
case C_make_character(63):
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 668  next */
t9=((C_word*)t0)[6];
f_3707(t9,t8);
case C_make_character(126):
/* extras.scm: 672  ##sys#write-char-0 */
t8=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,C_make_character(126),((C_word*)t0)[7]);
default:
t8=(C_word)C_eqp(t7,C_make_character(37));
t9=(C_truep(t8)?t8:(C_word)C_eqp(t7,C_make_character(78)));
if(C_truep(t9)){
/* extras.scm: 673  newline */
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t6))){
t10=f_3700(((C_word*)t0)[10]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[10],a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
t12=t3;
f_3739(2,t12,f_3904(t11,t10));}
else{
/* extras.scm: 680  ##sys#error */
t10=*((C_word*)lf[8]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t3,((C_word*)t0)[4],lf[121],t6);}}}}
else{
/* extras.scm: 681  ##sys#write-char-0 */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t2,((C_word*)t0)[7]);}}}

/* skip in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static C_word C_fcall f_3904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_3700(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k3857 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3862,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 669  next */
t3=((C_word*)t0)[2];
f_3707(t3,t2);}

/* k3860 in k3857 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3862,2,t0,t1);}
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 671  rec */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3691(t4,t3,((C_word*)t0)[2],t1);}

/* k3866 in k3860 in k3857 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3739(2,t2,((C_word*)t0)[2]);}

/* k3839 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 665  ##sys#number->string */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(16));}

/* k3835 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 665  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3822 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 664  ##sys#number->string */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(8));}

/* k3818 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 664  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3805 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 663  ##sys#number->string */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(2));}

/* k3801 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 663  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3788 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 662  ##sys#write-char-0 */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3775 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 661  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3762 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 660  write */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3737 in loop in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 682  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3726(t2,((C_word*)t0)[2]);}

/* next in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_fcall f_3707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3707,NULL,2,t0,t1);}
if(C_truep((C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST))){
/* extras.scm: 650  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],lf[119]);}
else{
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(0));
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in rec in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static C_word C_fcall f_3700(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* k3661 in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3663,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 685  get-output-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}
else{
/* extras.scm: 683  get-output-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k3683 in k3661 in k3658 in k3655 in fprintf0 in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 685  ##sys#print */
t2=*((C_word*)lf[61]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* pretty-print in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3624r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3624r(t0,t1,t2,t3);}}

static void C_ccall f_3624r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3628,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_3628(2,t5,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
/* extras.scm: 620  current-output-port */
t5=*((C_word*)lf[115]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3626 in pretty-print in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3635,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 621  pretty-print-width */
t4=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3633 in k3626 in pretty-print in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[4],a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 621  generic-write */
t3=lf[40];
f_2271(t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a3636 in k3633 in k3626 in pretty-print in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3637,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 621  display */
t4=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k3639 in a3636 in k3633 in k3626 in pretty-print in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3629 in k3626 in pretty-print in k3620 in k1237 in k1234 in k1231 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2271(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2271,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2365,a[2]=t5,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2384,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t9,a[9]=t11,a[10]=((C_word)li44),tmp=(C_word)a,a+=11,tmp));
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2887,a[2]=t6,a[3]=t8,a[4]=t7,a[5]=t11,a[6]=t4,a[7]=t3,a[8]=t9,a[9]=((C_word)li70),tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3534,a[2]=t2,a[3]=t13,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 592  make-string */
t15=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(1),C_make_character(10));}
else{
/* extras.scm: 593  wr */
t14=((C_word*)t11)[1];
f_2384(t14,t1,t2,C_fix(0));}}

/* k3532 in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3538,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 592  pp */
t3=((C_word*)t0)[3];
f_2887(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3536 in k3532 in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 592  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2887(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[151],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2887,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[8],a[8]=((C_word)li50),tmp=(C_word)a,a+=9,tmp));
t41=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3042,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word*)t0)[4],a[12]=((C_word)li51),tmp=(C_word)a,a+=13,tmp));
t42=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t17,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t43=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[8],a[3]=t17,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=t9,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t45=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t9,a[6]=t17,a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp));
t46=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3369,a[2]=t11,a[3]=t15,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t47=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3375,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t48=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3381,a[2]=t11,a[3]=t19,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t49=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3387,a[2]=t21,a[3]=t13,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t50=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3393,a[2]=t21,a[3]=t11,a[4]=t19,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t51=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3399,a[2]=t11,a[3]=t13,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t52=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3405,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t53=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3427,a[2]=t11,a[3]=t19,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t54=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3433,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3442,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,a[10]=((C_word)li69),tmp=(C_word)a,a+=11,tmp));
/* extras.scm: 589  pr */
t56=((C_word*)t9)[1];
f_2955(t56,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3442,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_3452(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[110]);
if(C_truep(t5)){
t6=t4;
f_3452(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[111]);
t7=t4;
f_3452(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[112])));}}}

/* k3450 in style in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[101]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[102]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[103]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[105]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[106]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[107]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[109]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3433,5,t0,t1,t2,t3,t4);}
/* extras.scm: 567  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3221(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3427,5,t0,t1,t2,t3,t4);}
/* extras.scm: 564  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3221(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3405,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_3412(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_3412(t7,C_SCHEME_FALSE);}}

/* k3410 in pp-let in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 561  pp-general */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3221(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-and in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3399,5,t0,t1,t2,t3,t4);}
/* extras.scm: 556  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3107(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3393,5,t0,t1,t2,t3,t4);}
/* extras.scm: 553  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3221(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3387,5,t0,t1,t2,t3,t4);}
/* extras.scm: 550  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3107(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3381,5,t0,t1,t2,t3,t4);}
/* extras.scm: 547  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3221(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3375,5,t0,t1,t2,t3,t4);}
/* extras.scm: 544  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3221(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3369,5,t0,t1,t2,t3,t4);}
/* extras.scm: 541  pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3135(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3221(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3221,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3306,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,a[5]=t4,a[6]=t7,a[7]=((C_word)li57),tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t4,a[6]=t6,a[7]=((C_word)li58),tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_i_cdr(t2);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,a[6]=t3,a[7]=t13,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3367,a[2]=t12,a[3]=t14,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 532  out */
t16=((C_word*)t0)[2];
f_2365(t16,t15,lf[99],t3);}

/* k3365 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 532  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2384(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3317 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3334,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3349,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 536  out */
t7=((C_word*)t0)[2];
f_2365(t7,t6,lf[98],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 538  tail1 */
t5=((C_word*)t0)[5];
f_3224(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k3347 in k3317 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 536  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2384(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3332 in k3317 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 537  tail1 */
t4=((C_word*)t0)[4];
f_3224(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail1 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3224(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3224,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3247,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 516  indent */
t13=((C_word*)t0)[2];
f_2923(t13,t12,t5,t4);}
else{
/* extras.scm: 517  tail2 */
t7=((C_word*)t0)[4];
f_3265(t7,t1,t2,t3,t4,t5);}}

/* k3249 in tail1 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 516  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2955(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3245 in tail1 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 516  tail2 */
t2=((C_word*)t0)[6];
f_3265(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3265,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3288,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 524  indent */
t13=((C_word*)t0)[2];
f_2923(t13,t12,t5,t4);}
else{
/* extras.scm: 525  tail3 */
t7=((C_word*)t0)[4];
f_3306(t7,t1,t2,t3,t4);}}

/* k3290 in tail2 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 524  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2955(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3286 in tail2 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 524  tail3 */
t2=((C_word*)t0)[5];
f_3306(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail3 in pp-general in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3306(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3306,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 528  pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3144(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3144,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,a[9]=((C_word)li54),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3150(t10,t1,t2,t3);}

/* loop in pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3150(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3150,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3173,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 499  indent */
t10=((C_word*)t0)[4];
f_2923(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 501  out */
t4=((C_word*)t0)[2];
f_2365(t4,t1,lf[95],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3203,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3219,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 505  indent */
t8=((C_word*)t0)[4];
f_2923(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3217 in loop in pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 505  out */
t2=((C_word*)t0)[3];
f_2365(t2,((C_word*)t0)[2],lf[97],t1);}

/* k3213 in loop in pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 505  indent */
t2=((C_word*)t0)[4];
f_2923(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3205 in loop in pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm: 504  pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2955(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k3201 in loop in pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 503  out */
t2=((C_word*)t0)[3];
f_2365(t2,((C_word*)t0)[2],lf[96],t1);}

/* k3179 in loop in pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 499  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2955(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3171 in loop in pp-down in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 498  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3150(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3135,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3139,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 489  out */
t7=((C_word*)t0)[2];
f_2365(t7,t6,lf[94],t3);}

/* k3137 in pp-list in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 490  pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3144(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3107,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3111,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3133,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 481  out */
t9=((C_word*)t0)[2];
f_2365(t9,t8,lf[93],t3);}

/* k3131 in pp-call in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 481  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2384(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3109 in pp-call in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 483  pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3144(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3042,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* extras.scm: 461  read-macro? */
f_2274(t5,t2);}

/* k3047 in pp-expr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
if(C_truep(t1)){
t2=f_2326(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t4=f_2332(((C_word*)t0)[13]);
/* extras.scm: 463  out */
t5=((C_word*)t0)[7];
f_2365(t5,t3,t4,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3076,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 468  style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3442(t4,t3,t2);}
else{
/* extras.scm: 475  pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3135(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k3074 in k3047 in pp-expr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3076,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm: 470  proc */
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 471  ##sys#symbol->qualified-string */
t3=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3100 in k3074 in k3047 in pp-expr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
/* extras.scm: 473  pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_3221(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm: 474  pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3107(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k3058 in k3047 in pp-expr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 462  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2955(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2955,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm: 447  max */
t14=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t13,C_fix(50));}
else{
/* extras.scm: 458  wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2384(t8,t1,t2,t3);}}

/* k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 448  generic-write */
t6=lf[40];
f_2271(t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a3005 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3006,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_i_string_length(t2);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k2969 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[7])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3546,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp));
/* extras.scm: 612  rev-string-append */
t7=((C_word*)t5)[1];
f_3546(t7,t2,t3,C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm: 456  pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 457  vector->list */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k2998 in k2969 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 457  out */
t3=((C_word*)t0)[3];
f_2365(t3,t2,lf[90],((C_word*)t0)[2]);}

/* k3002 in k2998 in k2969 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 457  pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3135(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* rev-string-append in k2969 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3546,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3562,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* extras.scm: 603  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* extras.scm: 610  make-string */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k3560 in rev-string-append in k2969 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3571,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3571(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k3560 in rev-string-append in k2969 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3571,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* extras.scm: 608  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* k2982 in k2969 in k2966 in pr in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 454  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2923,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2939,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2946,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 441  make-string */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
/* extras.scm: 442  spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2890(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2944 in indent in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 441  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2937 in indent in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 441  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2890(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2890,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2914,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 434  out */
t6=((C_word*)t0)[2];
f_2365(t6,t5,lf[88],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2921,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 435  ##sys#substring */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[89],C_fix(0),t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2919 in spaces in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 435  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2912 in spaces in pp in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 434  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2890(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2384(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2384,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],a[8]=((C_word)li42),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
/* extras.scm: 367  wr-expr */
t6=t5;
f_2387(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 368  wr-lst */
t6=t4;
f_2414(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
/* extras.scm: 369  out */
t6=((C_word*)t0)[8];
f_2365(t6,t1,lf[55],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2540,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 370  vector->list */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=(C_truep(t2)?lf[58]:lf[59]);
/* extras.scm: 371  out */
t7=((C_word*)t0)[8];
f_2365(t7,t1,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 372  ##sys#number? */
t7=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}}}}}

/* k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2563,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 372  ##sys#number->string */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 374  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 377  ##sys#procedure->string */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 379  out */
t2=((C_word*)t0)[8];
f_2365(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 380  out */
t3=((C_word*)t0)[8];
f_2365(t3,t2,lf[65],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 394  make-string */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 396  out */
t4=((C_word*)t0)[8];
f_2365(t4,t3,lf[70],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
/* extras.scm: 407  out */
t2=((C_word*)t0)[8];
f_2365(t2,((C_word*)t0)[7],lf[71],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
/* extras.scm: 408  out */
t2=((C_word*)t0)[8];
f_2365(t2,((C_word*)t0)[7],lf[72],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 409  ##sys#pointer->string */
t3=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(lf[74],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* extras.scm: 411  out */
t4=((C_word*)t0)[8];
f_2365(t4,((C_word*)t0)[7],lf[75],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 413  open-output-string */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 416  port? */
t5=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}}}}}}}}}}

/* k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm: 416  string-append */
t4=*((C_word*)lf[77]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[78],t3,lf[79]);}
else{
if(C_truep((C_word)C_bytevectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[2]))){
/* extras.scm: 419  out */
t3=((C_word*)t0)[5];
f_2365(t3,t2,lf[81],((C_word*)t0)[3]);}
else{
/* extras.scm: 420  out */
t3=((C_word*)t0)[5];
f_2365(t3,t2,lf[82],((C_word*)t0)[3]);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 424  out */
t3=((C_word*)t0)[5];
f_2365(t3,t2,lf[85],((C_word*)t0)[3]);}
else{
/* extras.scm: 427  out */
t2=((C_word*)t0)[5];
f_2365(t2,((C_word*)t0)[4],lf[86],((C_word*)t0)[3]);}}}}

/* k2866 in k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 425  ##sys#lambda-info->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t3,((C_word*)t0)[2]);}

/* k2876 in k2866 in k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 425  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2869 in k2866 in k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 426  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],lf[83],((C_word*)t0)[2]);}

/* k2844 in k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 421  number->string */
C_number_to_string(3,0,t3,(C_word)C_block_size(((C_word*)t0)[2]));}

/* k2854 in k2844 in k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 421  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2847 in k2844 in k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 422  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],lf[80],((C_word*)t0)[2]);}

/* k2834 in k2827 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 416  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2811 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2816,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 414  ##sys#user-print-hook */
t3=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2814 in k2811 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 415  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2821 in k2814 in k2811 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 415  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2793 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 409  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2709 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 397  char-name */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2712 in k2709 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
/* extras.scm: 399  out */
t3=((C_word*)t0)[6];
f_2365(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 401  out */
t3=((C_word*)t0)[6];
f_2365(t3,t2,lf[66],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535));
t4=(C_truep(t3)?lf[67]:lf[68]);
/* extras.scm: 404  out */
t5=((C_word*)t0)[6];
f_2365(t5,t2,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 406  make-string */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k2768 in k2712 in k2709 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 406  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2747 in k2712 in k2709 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 405  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2754 in k2747 in k2712 in k2709 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 405  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2731 in k2712 in k2709 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 402  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2738 in k2731 in k2712 in k2709 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 402  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2703 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 394  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2623(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2623,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2630,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_string_length(((C_word*)t0)[4]);
t7=t5;
f_2630(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_2630(t6,C_SCHEME_FALSE);}}

/* k2628 in loop in k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2630,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2653,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2657,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 388  ##sys#substring */
t9=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm: 390  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2623(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 392  ##sys#substring */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k2680 in k2628 in loop in k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 392  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2676 in k2628 in loop in k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 391  out */
t2=((C_word*)t0)[3];
f_2365(t2,((C_word*)t0)[2],lf[64],t1);}

/* k2659 in k2628 in loop in k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 388  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2655 in k2628 in loop in k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 387  out */
t2=((C_word*)t0)[3];
f_2365(t2,((C_word*)t0)[2],lf[63],t1);}

/* k2651 in k2628 in loop in k2619 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 385  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2623(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2600 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 377  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2577 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2582,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 375  ##sys#print */
t3=*((C_word*)lf[61]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2580 in k2577 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 376  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2587 in k2580 in k2577 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 376  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2568 in k2561 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 372  out */
t2=((C_word*)t0)[4];
f_2365(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2538 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2544,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 370  out */
t3=((C_word*)t0)[3];
f_2365(t3,t2,lf[56],((C_word*)t0)[2]);}

/* k2542 in k2538 in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 370  wr-lst */
t2=((C_word*)t0)[4];
f_2414(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2387(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2387,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 352  read-macro? */
f_2274(t4,t2);}

/* k2392 in wr-expr in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
if(C_truep(t1)){
t2=f_2326(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2405,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=f_2332(((C_word*)t0)[8]);
/* extras.scm: 353  out */
t5=((C_word*)t0)[4];
f_2365(t5,t3,t4,((C_word*)t0)[3]);}
else{
/* extras.scm: 354  wr-lst */
t2=((C_word*)t0)[2];
f_2414(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k2403 in k2392 in wr-expr in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 353  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2384(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2414(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2414,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2432,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2497,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 359  out */
t8=((C_word*)t0)[2];
f_2365(t8,t7,lf[53],t3);}
else{
t6=t5;
f_2432(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm: 365  out */
t4=((C_word*)t0)[2];
f_2365(t4,t1,lf[54],t3);}}

/* k2495 in wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 359  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2384(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2430 in wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2434(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k2430 in wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2434(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2434,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2458,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2466,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 362  out */
t9=((C_word*)t0)[2];
f_2365(t9,t8,lf[49],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 363  out */
t5=((C_word*)t0)[2];
f_2365(t5,t1,lf[50],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2482,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2486,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 364  out */
t7=((C_word*)t0)[2];
f_2365(t7,t6,lf[52],t3);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* k2484 in loop in k2430 in wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 364  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2384(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2480 in loop in k2430 in wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 364  out */
t2=((C_word*)t0)[3];
f_2365(t2,((C_word*)t0)[2],lf[51],t1);}

/* k2464 in loop in k2430 in wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 362  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2384(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2456 in loop in k2430 in wr-lst in wr in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 362  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2434(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2365(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2365,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2375,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 347  output */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2373 in out in generic-write in k1237 in k1234 in k1231 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in generic-write in k1237 in k1234 in k1231 */
static C_word C_fcall f_2332(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_eqp(t2,lf[41]);
if(C_truep(t4)){
return(lf[45]);}
else{
t5=(C_word)C_eqp(t2,lf[42]);
if(C_truep(t5)){
return(lf[46]);}
else{
t6=(C_word)C_eqp(t2,lf[43]);
if(C_truep(t6)){
return(lf[47]);}
else{
t7=(C_word)C_eqp(t2,lf[44]);
return((C_truep(t7)?lf[48]:C_SCHEME_UNDEFINED));}}}}

/* read-macro-body in generic-write in k1237 in k1234 in k1231 */
static C_word C_fcall f_2326(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_i_cadr(t1));}

/* read-macro? in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2274(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2274,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,lf[41]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_2306(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[42]);
if(C_truep(t7)){
t8=t6;
f_2306(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[43]);
t9=t6;
f_2306(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[44])));}}}

/* k2304 in read-macro? in generic-write in k1237 in k1234 in k1231 */
static void C_fcall f_2306(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* write-byte in k1237 in k1234 in k1231 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2233r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2233r(t0,t1,t2,t3);}}

static void C_ccall f_2233r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2237(2,t5,*((C_word*)lf[35]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2237(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2235 in write-byte in k1237 in k1234 in k1231 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[39]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2243,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 308  ##sys#check-port */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[39]);}

/* k2241 in k2235 in write-byte in k1237 in k1234 in k1231 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[4]));
/* extras.scm: 309  ##sys#write-char-0 */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* read-byte in k1237 in k1234 in k1231 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2193r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2193r(t0,t1,t2);}}

static void C_ccall f_2193r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2197(2,t4,*((C_word*)lf[7]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2197(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2195 in read-byte in k1237 in k1234 in k1231 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 300  ##sys#check-port */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[38]);}

/* k2198 in k2195 in read-byte in k1237 in k1234 in k1231 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 301  ##sys#read-char-0 */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2201 in k2198 in k2195 in read-byte in k1237 in k1234 in k1231 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t1:(C_word)C_fix((C_word)C_character_code(t1))));}

/* write-line in k1237 in k1234 in k1231 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2172r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2172r(t0,t1,t2,t3);}}

static void C_ccall f_2172r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[35]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 291  ##sys#check-port */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[37]);}

/* k2177 in write-line in k1237 in k1234 in k1231 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[37]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 293  display */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k2183 in k2177 in write-line in k1237 in k1234 in k1231 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 294  newline */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k1237 in k1234 in k1231 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2083r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2083r(t0,t1,t2,t3);}}

static void C_ccall f_2083r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t4=(C_word)C_i_check_string_2(t2,lf[34]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2119,a[2]=t5,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2124,a[2]=t6,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-n508529 */
t8=t7;
f_2124(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-port509525 */
t10=t6;
f_2119(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body506514 */
t12=t5;
f_2088(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-n508 in write-string in k1237 in k1234 in k1231 */
static void C_fcall f_2124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2124,NULL,2,t0,t1);}
/* def-port509525 */
t2=((C_word*)t0)[2];
f_2119(t2,t1,C_SCHEME_FALSE);}

/* def-port509 in write-string in k1237 in k1234 in k1231 */
static void C_fcall f_2119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2119,NULL,3,t0,t1,t2);}
/* body506514 */
t3=((C_word*)t0)[2];
f_2088(t3,t1,t2,*((C_word*)lf[35]+1));}

/* body506 in write-string in k1237 in k1234 in k1231 */
static void C_fcall f_2088(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2088,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 276  ##sys#check-port */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[34]);}

/* k2090 in body506 in write-string in k1237 in k1234 in k1231 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2092,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[34]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(C_word)C_block_size(((C_word*)t0)[2]);
t6=t4;
f_2105(t6,(C_word)C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_2105(t5,C_SCHEME_FALSE);}}

/* k2103 in k2090 in body506 in write-string in k1237 in k1234 in k1231 */
static void C_fcall f_2105(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 280  ##sys#substring */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2102(2,t2,((C_word*)t0)[3]);}}

/* k2100 in k2090 in body506 in write-string in k1237 in k1234 in k1231 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 278  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2014r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2014r(t0,t1,t2,t3);}}

static void C_ccall f_2014r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2018(2,t5,*((C_word*)lf[7]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2018(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2016 in read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 261  ##sys#check-port */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[30]);}

/* k2019 in k2016 in read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 262  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2022 in k2019 in k2016 in read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=((C_word)li27),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2029(t5,((C_word*)t0)[2]);}

/* loop in k2022 in k2019 in k2016 in read-token in k1237 in k1234 in k1231 */
static void C_fcall f_2029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2029,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 264  ##sys#peek-char-0 */
t3=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2031 in loop in k2022 in k2019 in k2016 in read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_2039(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm: 265  pred */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k2037 in k2031 in loop in k2022 in k2019 in k2016 in read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 267  ##sys#read-char-0 */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* extras.scm: 269  get-output-string */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k2047 in k2037 in k2031 in loop in k2022 in k2019 in k2016 in read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 267  ##sys#write-char-0 */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2040 in k2037 in k2031 in loop in k2022 in k2019 in k2016 in read-token in k1237 in k1234 in k1231 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 268  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2029(t2,((C_word*)t0)[2]);}

/* read-string in k1237 in k1234 in k1231 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_1954r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1954r(t0,t1,t2);}}

static void C_ccall f_1954r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1956,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1961,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n436452 */
t6=t5;
f_1966(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-port437448 */
t8=t4;
f_1961(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body434443 */
f_1956(t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n436 in read-string in k1237 in k1234 in k1231 */
static void C_fcall f_1966(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1966,NULL,2,t0,t1);}
/* def-port437448 */
t2=((C_word*)t0)[2];
f_1961(t2,t1,C_SCHEME_FALSE);}

/* def-port437 in read-string in k1237 in k1234 in k1231 */
static void C_fcall f_1961(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1961,NULL,3,t0,t1,t2);}
/* body434443 */
f_1956(t1,t2,*((C_word*)lf[7]+1));}

/* body434 in read-string in k1237 in k1234 in k1231 */
static void C_fcall f_1956(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1956,NULL,3,t1,t2,t3);}
/* extras.scm: 254  ##sys#read-string/port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[27]+1)))(4,*((C_word*)lf[27]+1),t1,t2,t3);}

/* ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1881,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 235  ##sys#check-port */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[28]);}

/* k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[28]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 237  ##sys#make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 243  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k1907 in k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1914(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k1907 in k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_fcall f_1914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1914,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 245  get-output-string */
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[4]);}
else{
t5=t3;
f_1918(2,t5,C_SCHEME_FALSE);}}

/* k1916 in loop in k1907 in k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 246  ##sys#read-char-0 */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k1922 in k1916 in loop in k1907 in k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 248  get-output-string */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 250  ##sys#write-char/port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t2,t1,((C_word*)t0)[4]);}}

/* k1934 in k1922 in k1916 in loop in k1907 in k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
/* extras.scm: 251  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1914(t3,((C_word*)t0)[2],t2);}

/* k1892 in k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 238  ##sys#read-string! */
t3=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[2],C_fix(0));}

/* k1895 in k1892 in k1883 in ##sys#read-string/port in k1237 in k1234 in k1231 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 241  ##sys#substring */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* read-string! in k1237 in k1234 in k1231 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1784r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1784r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1784r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1786,a[2]=t5,a[3]=t3,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=t6,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1833,a[2]=t7,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port339364 */
t9=t8;
f_1833(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start340360 */
t11=t7;
f_1828(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body337346 */
t13=t6;
f_1786(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port339 in read-string! in k1237 in k1234 in k1231 */
static void C_fcall f_1833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1833,NULL,2,t0,t1);}
/* def-start340360 */
t2=((C_word*)t0)[2];
f_1828(t2,t1,*((C_word*)lf[7]+1));}

/* def-start340 in read-string! in k1237 in k1234 in k1231 */
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1828,NULL,3,t0,t1,t2);}
/* body337346 */
t3=((C_word*)t0)[2];
f_1786(t3,t1,t2,C_fix(0));}

/* body337 in read-string! in k1237 in k1234 in k1231 */
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1786,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1790,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 222  ##sys#check-port */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[24]);}

/* k1788 in body337 in read-string! in k1237 in k1234 in k1231 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[24]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[24]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
t6=(C_word)C_block_size(((C_word*)t0)[6]);
if(C_truep((C_word)C_fixnum_greaterp(t5,t6))){
t7=(C_word)C_block_size(((C_word*)t0)[6]);
t8=(C_word)C_fixnum_difference(t7,((C_word*)t0)[5]);
t9=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t10=t3;
f_1796(t10,t9);}
else{
t7=t3;
f_1796(t7,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1796(t4,C_SCHEME_UNDEFINED);}}

/* k1794 in k1788 in body337 in read-string! in k1237 in k1234 in k1231 */
static void C_fcall f_1796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[24]);
/* extras.scm: 229  ##sys#read-string! */
t3=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* ##sys#read-string! in k1237 in k1234 in k1231 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1694,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1704,a[2]=t2,a[3]=t6,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(t4,C_fix(6)))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1778,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 204  ##sys#read-char-0 */
t10=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t8;
f_1704(t9,C_SCHEME_UNDEFINED);}}}

/* k1776 in ##sys#read-string! in k1237 in k1234 in k1231 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1704(t5,t4);}

/* k1702 in ##sys#read-string! in k1237 in k1234 in k1231 */
static void C_fcall f_1704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1704,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(7));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t5,a[6]=((C_word)li15),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1712(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}

/* loop in k1702 in ##sys#read-string! in k1237 in k1234 in k1231 */
static void C_fcall f_1712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1712,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
/* extras.scm: 209  rdstring */
t6=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t0)[3],t3,((C_word*)t0)[2],t2);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1761,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 210  ##sys#read-char-0 */
t7=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}}

/* k1759 in loop in k1702 in ##sys#read-string! in k1237 in k1234 in k1231 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
f_1716(2,t2,C_fix(0));}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[4];
f_1716(2,t3,C_fix(1));}}

/* k1714 in loop in k1702 in ##sys#read-string! in k1237 in k1234 in k1231 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_i_not(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t4)){
t5=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* extras.scm: 218  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1712(t8,((C_word*)t0)[6],t5,t6,t7);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_plus(t1,((C_word*)t0)[5]));}}}

/* read-lines in k1237 in k1234 in k1231 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_1604r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1604r(t0,t1,t2);}}

static void C_ccall f_1604r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[7]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
/* extras.scm: 192  call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1671,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 194  ##sys#check-port */
t11=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t4,lf[22]);}}

/* k1669 in read-lines in k1237 in k1234 in k1231 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 195  doread */
t2=((C_word*)t0)[4];
f_1616(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k1237 in k1234 in k1231 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1616,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(1000000000));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1626,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word)li12),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1626(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in doread in read-lines in k1237 in k1234 in k1231 */
static void C_fcall f_1626(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1626,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 186  reverse */
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 187  read-line */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k1637 in loop in doread in read-lines in k1237 in k1234 in k1231 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 189  reverse */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 190  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1626(t4,((C_word*)t0)[5],t2,t3);}}

/* read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1460r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1460r(t0,t1,t2);}}

static void C_ccall f_1460r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):*((C_word*)lf[7]+1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_1470(t8,(C_truep(t7)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_1470(t6,C_SCHEME_FALSE);}}

/* k1468 in read-line in k1237 in k1234 in k1231 */
static void C_fcall f_1470(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1470,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 146  ##sys#check-port */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[15]);}

/* k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(8));
if(C_truep(t3)){
/* extras.scm: 147  rl */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t4=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_fix(256));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1488,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 150  ##sys#make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t7,((C_word*)t6)[1]);}}

/* k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1488,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word)li10),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_1493(t7,((C_word*)t0)[2],C_fix(0));}

/* loop in k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_fcall f_1493(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1493,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[7])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* extras.scm: 153  ##sys#substring */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 154  ##sys#read-char-0 */
t5=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}

/* k1504 in loop in k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1506,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* extras.scm: 158  ##sys#substring */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);}}
else{
switch(t1){
case C_make_character(10):
/* extras.scm: 160  ##sys#substring */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 162  peek-char */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[8],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1571,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 169  make-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_1557(t3,C_SCHEME_UNDEFINED);}}}}

/* k1577 in k1504 in loop in k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 169  ##sys#string-append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1569 in k1504 in loop in k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1557(t5,t4);}

/* k1555 in k1504 in loop in k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_fcall f_1557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 172  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1493(t4,((C_word*)t0)[2],t3);}

/* k1537 in k1504 in loop in k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 164  ##sys#read-char-0 */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 166  ##sys#substring */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}}

/* k1546 in k1537 in k1504 in loop in k1486 in k1471 in k1468 in read-line in k1237 in k1234 in k1231 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 165  ##sys#substring */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],C_fix(0),((C_word*)t0)[2]);}

/* random in k1237 in k1234 in k1231 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1421,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[13]);
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_fix(0):(C_word)C_random_fixnum(t2)));}

/* randomize in k1237 in k1234 in k1231 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1403r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1403r(t0,t1,t2);}}

static void C_ccall f_1403r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?(C_word)C_fudge(C_fix(2)):(C_word)C_i_vector_ref(t2,C_fix(0)));
t5=(C_word)C_i_check_exact_2(t4,lf[12]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_randomize(t4));}

/* random-seed in k1237 in k1234 in k1231 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1382r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1382r(t0,t1,t2);}}

static void C_ccall f_1382r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1386,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* extras.scm: 116  current-seconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t3);}
else{
t4=t3;
f_1386(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}}

/* k1384 in random-seed in k1237 in k1234 in k1231 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1389,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 117  ##sys#check-integer */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t2,t1,lf[9]);}

/* k1387 in k1384 in random-seed in k1237 in k1234 in k1231 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub142(C_SCHEME_UNDEFINED,t4));}

/* read-file in k1237 in k1234 in k1231 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr2r,(void*)f_1241r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1241r(t0,t1,t2);}}

static void C_ccall f_1241r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=t3,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1313,a[2]=t5,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-port73120 */
t7=t6;
f_1313(t7,t1);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-reader74116 */
t9=t5;
f_1308(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-max75111 */
t11=t4;
f_1303(t11,t1,t7,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body7181 */
t13=t3;
f_1243(t13,t1,t7,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-port73 in read-file in k1237 in k1234 in k1231 */
static void C_fcall f_1313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1313,NULL,2,t0,t1);}
/* def-reader74116 */
t2=((C_word*)t0)[2];
f_1308(t2,t1,*((C_word*)lf[7]+1));}

/* def-reader74 in read-file in k1237 in k1234 in k1231 */
static void C_fcall f_1308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1308,NULL,3,t0,t1,t2);}
/* def-max75111 */
t3=((C_word*)t0)[3];
f_1303(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max75 in read-file in k1237 in k1234 in k1231 */
static void C_fcall f_1303(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1303,NULL,4,t0,t1,t2,t3);}
/* body7181 */
t4=((C_word*)t0)[2];
f_1243(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body71 in read-file in k1237 in k1234 in k1231 */
static void C_fcall f_1243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1243,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1246,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word)li1),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 81   port? */
t7=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k1294 in body71 in read-file in k1237 in k1234 in k1231 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 82   slurp */
t2=((C_word*)t0)[5];
f_1246(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm: 83   call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body71 in read-file in k1237 in k1234 in k1231 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1246,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1254,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 77   reader */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1252 in slurp in body71 in read-file in k1237 in k1234 in k1231 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li0),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1256(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* doloop88 in k1252 in slurp in body71 in read-file in k1237 in k1234 in k1231 */
static void C_fcall f_1256(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1256,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm: 80   reverse */
t7=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1276,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 77   reader */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k1274 in doloop88 in k1252 in slurp in body71 in read-file in k1237 in k1234 in k1231 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_1256(t4,((C_word*)t0)[2],t1,t2,t3);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[241] = {
{"toplevel:extras_scm",(void*)C_extras_toplevel},
{"f_1233:extras_scm",(void*)f_1233},
{"f_1236:extras_scm",(void*)f_1236},
{"f_1239:extras_scm",(void*)f_1239},
{"f_3622:extras_scm",(void*)f_3622},
{"f_4012:extras_scm",(void*)f_4012},
{"f_3969:extras_scm",(void*)f_3969},
{"f_4002:extras_scm",(void*)f_4002},
{"f_3977:extras_scm",(void*)f_3977},
{"f_3963:extras_scm",(void*)f_3963},
{"f_3957:extras_scm",(void*)f_3957},
{"f_3951:extras_scm",(void*)f_3951},
{"f_3653:extras_scm",(void*)f_3653},
{"f_3657:extras_scm",(void*)f_3657},
{"f_3940:extras_scm",(void*)f_3940},
{"f_3660:extras_scm",(void*)f_3660},
{"f_3691:extras_scm",(void*)f_3691},
{"f_3726:extras_scm",(void*)f_3726},
{"f_3904:extras_scm",(void*)f_3904},
{"f_3859:extras_scm",(void*)f_3859},
{"f_3862:extras_scm",(void*)f_3862},
{"f_3868:extras_scm",(void*)f_3868},
{"f_3841:extras_scm",(void*)f_3841},
{"f_3837:extras_scm",(void*)f_3837},
{"f_3824:extras_scm",(void*)f_3824},
{"f_3820:extras_scm",(void*)f_3820},
{"f_3807:extras_scm",(void*)f_3807},
{"f_3803:extras_scm",(void*)f_3803},
{"f_3790:extras_scm",(void*)f_3790},
{"f_3777:extras_scm",(void*)f_3777},
{"f_3764:extras_scm",(void*)f_3764},
{"f_3739:extras_scm",(void*)f_3739},
{"f_3707:extras_scm",(void*)f_3707},
{"f_3700:extras_scm",(void*)f_3700},
{"f_3663:extras_scm",(void*)f_3663},
{"f_3685:extras_scm",(void*)f_3685},
{"f_3624:extras_scm",(void*)f_3624},
{"f_3628:extras_scm",(void*)f_3628},
{"f_3635:extras_scm",(void*)f_3635},
{"f_3637:extras_scm",(void*)f_3637},
{"f_3641:extras_scm",(void*)f_3641},
{"f_3631:extras_scm",(void*)f_3631},
{"f_2271:extras_scm",(void*)f_2271},
{"f_3534:extras_scm",(void*)f_3534},
{"f_3538:extras_scm",(void*)f_3538},
{"f_2887:extras_scm",(void*)f_2887},
{"f_3442:extras_scm",(void*)f_3442},
{"f_3452:extras_scm",(void*)f_3452},
{"f_3433:extras_scm",(void*)f_3433},
{"f_3427:extras_scm",(void*)f_3427},
{"f_3405:extras_scm",(void*)f_3405},
{"f_3412:extras_scm",(void*)f_3412},
{"f_3399:extras_scm",(void*)f_3399},
{"f_3393:extras_scm",(void*)f_3393},
{"f_3387:extras_scm",(void*)f_3387},
{"f_3381:extras_scm",(void*)f_3381},
{"f_3375:extras_scm",(void*)f_3375},
{"f_3369:extras_scm",(void*)f_3369},
{"f_3221:extras_scm",(void*)f_3221},
{"f_3367:extras_scm",(void*)f_3367},
{"f_3319:extras_scm",(void*)f_3319},
{"f_3349:extras_scm",(void*)f_3349},
{"f_3334:extras_scm",(void*)f_3334},
{"f_3224:extras_scm",(void*)f_3224},
{"f_3251:extras_scm",(void*)f_3251},
{"f_3247:extras_scm",(void*)f_3247},
{"f_3265:extras_scm",(void*)f_3265},
{"f_3292:extras_scm",(void*)f_3292},
{"f_3288:extras_scm",(void*)f_3288},
{"f_3306:extras_scm",(void*)f_3306},
{"f_3144:extras_scm",(void*)f_3144},
{"f_3150:extras_scm",(void*)f_3150},
{"f_3219:extras_scm",(void*)f_3219},
{"f_3215:extras_scm",(void*)f_3215},
{"f_3207:extras_scm",(void*)f_3207},
{"f_3203:extras_scm",(void*)f_3203},
{"f_3181:extras_scm",(void*)f_3181},
{"f_3173:extras_scm",(void*)f_3173},
{"f_3135:extras_scm",(void*)f_3135},
{"f_3139:extras_scm",(void*)f_3139},
{"f_3107:extras_scm",(void*)f_3107},
{"f_3133:extras_scm",(void*)f_3133},
{"f_3111:extras_scm",(void*)f_3111},
{"f_3042:extras_scm",(void*)f_3042},
{"f_3049:extras_scm",(void*)f_3049},
{"f_3076:extras_scm",(void*)f_3076},
{"f_3102:extras_scm",(void*)f_3102},
{"f_3060:extras_scm",(void*)f_3060},
{"f_2955:extras_scm",(void*)f_2955},
{"f_2968:extras_scm",(void*)f_2968},
{"f_3006:extras_scm",(void*)f_3006},
{"f_2971:extras_scm",(void*)f_2971},
{"f_3000:extras_scm",(void*)f_3000},
{"f_3004:extras_scm",(void*)f_3004},
{"f_3546:extras_scm",(void*)f_3546},
{"f_3562:extras_scm",(void*)f_3562},
{"f_3571:extras_scm",(void*)f_3571},
{"f_2984:extras_scm",(void*)f_2984},
{"f_2923:extras_scm",(void*)f_2923},
{"f_2946:extras_scm",(void*)f_2946},
{"f_2939:extras_scm",(void*)f_2939},
{"f_2890:extras_scm",(void*)f_2890},
{"f_2921:extras_scm",(void*)f_2921},
{"f_2914:extras_scm",(void*)f_2914},
{"f_2384:extras_scm",(void*)f_2384},
{"f_2563:extras_scm",(void*)f_2563},
{"f_2829:extras_scm",(void*)f_2829},
{"f_2868:extras_scm",(void*)f_2868},
{"f_2878:extras_scm",(void*)f_2878},
{"f_2871:extras_scm",(void*)f_2871},
{"f_2846:extras_scm",(void*)f_2846},
{"f_2856:extras_scm",(void*)f_2856},
{"f_2849:extras_scm",(void*)f_2849},
{"f_2836:extras_scm",(void*)f_2836},
{"f_2813:extras_scm",(void*)f_2813},
{"f_2816:extras_scm",(void*)f_2816},
{"f_2823:extras_scm",(void*)f_2823},
{"f_2795:extras_scm",(void*)f_2795},
{"f_2711:extras_scm",(void*)f_2711},
{"f_2714:extras_scm",(void*)f_2714},
{"f_2770:extras_scm",(void*)f_2770},
{"f_2749:extras_scm",(void*)f_2749},
{"f_2756:extras_scm",(void*)f_2756},
{"f_2733:extras_scm",(void*)f_2733},
{"f_2740:extras_scm",(void*)f_2740},
{"f_2705:extras_scm",(void*)f_2705},
{"f_2621:extras_scm",(void*)f_2621},
{"f_2623:extras_scm",(void*)f_2623},
{"f_2630:extras_scm",(void*)f_2630},
{"f_2682:extras_scm",(void*)f_2682},
{"f_2678:extras_scm",(void*)f_2678},
{"f_2661:extras_scm",(void*)f_2661},
{"f_2657:extras_scm",(void*)f_2657},
{"f_2653:extras_scm",(void*)f_2653},
{"f_2602:extras_scm",(void*)f_2602},
{"f_2579:extras_scm",(void*)f_2579},
{"f_2582:extras_scm",(void*)f_2582},
{"f_2589:extras_scm",(void*)f_2589},
{"f_2570:extras_scm",(void*)f_2570},
{"f_2540:extras_scm",(void*)f_2540},
{"f_2544:extras_scm",(void*)f_2544},
{"f_2387:extras_scm",(void*)f_2387},
{"f_2394:extras_scm",(void*)f_2394},
{"f_2405:extras_scm",(void*)f_2405},
{"f_2414:extras_scm",(void*)f_2414},
{"f_2497:extras_scm",(void*)f_2497},
{"f_2432:extras_scm",(void*)f_2432},
{"f_2434:extras_scm",(void*)f_2434},
{"f_2486:extras_scm",(void*)f_2486},
{"f_2482:extras_scm",(void*)f_2482},
{"f_2466:extras_scm",(void*)f_2466},
{"f_2458:extras_scm",(void*)f_2458},
{"f_2365:extras_scm",(void*)f_2365},
{"f_2375:extras_scm",(void*)f_2375},
{"f_2332:extras_scm",(void*)f_2332},
{"f_2326:extras_scm",(void*)f_2326},
{"f_2274:extras_scm",(void*)f_2274},
{"f_2306:extras_scm",(void*)f_2306},
{"f_2233:extras_scm",(void*)f_2233},
{"f_2237:extras_scm",(void*)f_2237},
{"f_2243:extras_scm",(void*)f_2243},
{"f_2193:extras_scm",(void*)f_2193},
{"f_2197:extras_scm",(void*)f_2197},
{"f_2200:extras_scm",(void*)f_2200},
{"f_2203:extras_scm",(void*)f_2203},
{"f_2172:extras_scm",(void*)f_2172},
{"f_2179:extras_scm",(void*)f_2179},
{"f_2185:extras_scm",(void*)f_2185},
{"f_2083:extras_scm",(void*)f_2083},
{"f_2124:extras_scm",(void*)f_2124},
{"f_2119:extras_scm",(void*)f_2119},
{"f_2088:extras_scm",(void*)f_2088},
{"f_2092:extras_scm",(void*)f_2092},
{"f_2105:extras_scm",(void*)f_2105},
{"f_2102:extras_scm",(void*)f_2102},
{"f_2014:extras_scm",(void*)f_2014},
{"f_2018:extras_scm",(void*)f_2018},
{"f_2021:extras_scm",(void*)f_2021},
{"f_2024:extras_scm",(void*)f_2024},
{"f_2029:extras_scm",(void*)f_2029},
{"f_2033:extras_scm",(void*)f_2033},
{"f_2039:extras_scm",(void*)f_2039},
{"f_2049:extras_scm",(void*)f_2049},
{"f_2042:extras_scm",(void*)f_2042},
{"f_1954:extras_scm",(void*)f_1954},
{"f_1966:extras_scm",(void*)f_1966},
{"f_1961:extras_scm",(void*)f_1961},
{"f_1956:extras_scm",(void*)f_1956},
{"f_1881:extras_scm",(void*)f_1881},
{"f_1885:extras_scm",(void*)f_1885},
{"f_1909:extras_scm",(void*)f_1909},
{"f_1914:extras_scm",(void*)f_1914},
{"f_1918:extras_scm",(void*)f_1918},
{"f_1924:extras_scm",(void*)f_1924},
{"f_1936:extras_scm",(void*)f_1936},
{"f_1894:extras_scm",(void*)f_1894},
{"f_1897:extras_scm",(void*)f_1897},
{"f_1784:extras_scm",(void*)f_1784},
{"f_1833:extras_scm",(void*)f_1833},
{"f_1828:extras_scm",(void*)f_1828},
{"f_1786:extras_scm",(void*)f_1786},
{"f_1790:extras_scm",(void*)f_1790},
{"f_1796:extras_scm",(void*)f_1796},
{"f_1694:extras_scm",(void*)f_1694},
{"f_1778:extras_scm",(void*)f_1778},
{"f_1704:extras_scm",(void*)f_1704},
{"f_1712:extras_scm",(void*)f_1712},
{"f_1761:extras_scm",(void*)f_1761},
{"f_1716:extras_scm",(void*)f_1716},
{"f_1604:extras_scm",(void*)f_1604},
{"f_1671:extras_scm",(void*)f_1671},
{"f_1616:extras_scm",(void*)f_1616},
{"f_1626:extras_scm",(void*)f_1626},
{"f_1639:extras_scm",(void*)f_1639},
{"f_1460:extras_scm",(void*)f_1460},
{"f_1470:extras_scm",(void*)f_1470},
{"f_1473:extras_scm",(void*)f_1473},
{"f_1488:extras_scm",(void*)f_1488},
{"f_1493:extras_scm",(void*)f_1493},
{"f_1506:extras_scm",(void*)f_1506},
{"f_1579:extras_scm",(void*)f_1579},
{"f_1571:extras_scm",(void*)f_1571},
{"f_1557:extras_scm",(void*)f_1557},
{"f_1539:extras_scm",(void*)f_1539},
{"f_1548:extras_scm",(void*)f_1548},
{"f_1421:extras_scm",(void*)f_1421},
{"f_1403:extras_scm",(void*)f_1403},
{"f_1382:extras_scm",(void*)f_1382},
{"f_1386:extras_scm",(void*)f_1386},
{"f_1389:extras_scm",(void*)f_1389},
{"f_1241:extras_scm",(void*)f_1241},
{"f_1313:extras_scm",(void*)f_1313},
{"f_1308:extras_scm",(void*)f_1308},
{"f_1303:extras_scm",(void*)f_1303},
{"f_1243:extras_scm",(void*)f_1243},
{"f_1296:extras_scm",(void*)f_1296},
{"f_1246:extras_scm",(void*)f_1246},
{"f_1254:extras_scm",(void*)f_1254},
{"f_1256:extras_scm",(void*)f_1256},
{"f_1276:extras_scm",(void*)f_1276},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
