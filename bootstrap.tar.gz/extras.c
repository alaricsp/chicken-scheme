/* Generated from extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:15
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: extras.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file extras.c -extend private-namespace.scm
   unit: extras
*/

#include "chicken.h"

#define C_hashptr(x)   C_fix(x & C_MOST_POSITIVE_FIXNUM)
#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[134];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,23),40,100,111,108,111,111,112,56,56,32,120,57,55,32,105,57,56,32,120,115,57,57,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,115,108,117,114,112,32,112,111,114,116,56,55,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,55,49,32,112,111,114,116,56,50,32,114,101,97,100,101,114,56,51,32,109,97,120,56,52,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,109,97,120,55,53,32,37,112,111,114,116,54,56,49,49,52,32,37,114,101,97,100,101,114,54,57,49,49,53,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,114,101,97,100,101,114,55,52,32,37,112,111,114,116,54,56,49,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,112,111,114,116,55,51,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,21),40,114,101,97,100,45,102,105,108,101,32,46,32,116,109,112,54,48,54,49,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,114,97,110,100,111,109,45,115,101,101,100,32,46,32,110,49,52,52,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,13),40,114,97,110,100,111,109,32,110,49,53,52,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,18),40,114,97,110,100,111,109,105,122,101,32,46,32,110,49,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,50,49,48,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,21),40,114,101,97,100,45,108,105,110,101,32,46,32,97,114,103,115,49,55,51,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,110,115,50,54,48,32,110,50,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,100,111,114,101,97,100,32,112,111,114,116,50,53,52,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,108,105,110,101,115,32,46,32,112,111,114,116,45,97,110,100,45,109,97,120,50,52,49,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,115,116,97,114,116,50,57,56,32,110,50,57,57,32,109,51,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,33,32,110,50,55,55,32,100,101,115,116,50,55,56,32,112,111,114,116,50,55,57,32,115,116,97,114,116,50,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,51,52,52,32,112,111,114,116,51,53,52,32,115,116,97,114,116,51,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,115,116,97,114,116,51,52,55,32,37,112,111,114,116,51,52,50,51,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,51,52,54,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,39),40,114,101,97,100,45,115,116,114,105,110,103,33,32,110,51,51,51,32,100,101,115,116,51,51,52,32,46,32,116,109,112,51,51,50,51,51,53,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,52,48,56,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,47,112,111,114,116,32,110,51,56,53,32,112,51,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,52,52,51,32,110,52,53,51,32,112,111,114,116,52,53,52,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,111,114,116,52,52,54,32,37,110,52,52,49,52,53,56,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,52,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,114,101,97,100,45,115,116,114,105,110,103,32,46,32,116,109,112,52,51,51,52,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,116,111,107,101,110,32,112,114,101,100,52,55,53,32,46,32,112,111,114,116,52,55,54,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,53,49,55,32,110,53,50,54,32,112,111,114,116,53,50,55,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,111,114,116,53,50,48,32,37,110,53,49,53,53,51,55,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,53,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,115,116,114,105,110,103,32,115,53,48,54,32,46,32,109,111,114,101,53,48,55,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,108,105,110,101,32,115,116,114,53,53,53,32,46,32,112,111,114,116,53,53,54,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,23),40,114,101,97,100,45,98,121,116,101,32,46,32,116,109,112,53,55,48,53,55,49,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,32),40,119,114,105,116,101,45,98,121,116,101,32,98,121,116,101,53,57,52,32,46,32,116,109,112,53,57,51,53,57,53,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,18),40,114,101,97,100,45,109,97,99,114,111,63,32,108,54,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,17),40,114,101,97,100,45,109,97,99,114,111,45,98,111,100,121,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,109,97,99,114,111,45,112,114,101,102,105,120,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,19),40,111,117,116,32,115,116,114,54,55,54,32,99,111,108,54,55,55,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,55,48,53,32,99,111,108,55,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,119,114,45,108,115,116,32,108,54,57,56,32,99,111,108,54,57,57,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,24),40,119,114,45,101,120,112,114,32,101,120,112,114,54,57,53,32,99,111,108,54,57,54,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,105,55,50,54,32,106,55,50,55,32,99,111,108,55,50,56,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,18),40,119,114,32,111,98,106,54,56,51,32,99,111,108,54,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,115,112,97,99,101,115,32,110,55,57,51,32,99,111,108,55,57,52,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,105,110,100,101,110,116,32,116,111,55,57,54,32,99,111,108,55,57,55,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,106,49,48,55,49,32,107,49,48,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,31),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,49,48,53,54,32,105,49,48,53,55,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,14),40,97,51,48,53,49,32,115,116,114,56,49,55,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,38),40,112,114,32,111,98,106,56,48,51,32,99,111,108,56,48,52,32,101,120,116,114,97,56,48,53,32,112,112,45,112,97,105,114,56,48,54,41,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,33),40,112,112,45,101,120,112,114,32,101,120,112,114,56,50,50,32,99,111,108,56,50,51,32,101,120,116,114,97,56,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,44),40,112,112,45,99,97,108,108,32,101,120,112,114,56,51,48,32,99,111,108,56,51,49,32,101,120,116,114,97,56,51,50,32,112,112,45,105,116,101,109,56,51,51,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,41),40,112,112,45,108,105,115,116,32,108,56,51,57,32,99,111,108,56,52,48,32,101,120,116,114,97,56,52,49,32,112,112,45,105,116,101,109,56,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,56,53,54,32,99,111,108,56,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,50),40,112,112,45,100,111,119,110,32,108,56,52,54,32,99,111,108,49,56,52,55,32,99,111,108,50,56,52,56,32,101,120,116,114,97,56,52,57,32,112,112,45,105,116,101,109,56,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,31),40,116,97,105,108,51,32,114,101,115,116,57,49,54,32,99,111,108,49,57,49,55,32,99,111,108,50,57,49,56,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,50,32,114,101,115,116,57,48,49,32,99,111,108,49,57,48,50,32,99,111,108,50,57,48,51,32,99,111,108,51,57,48,52,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,49,32,114,101,115,116,56,56,54,32,99,111,108,49,56,56,55,32,99,111,108,50,56,56,56,32,99,111,108,51,56,56,57,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,70),40,112,112,45,103,101,110,101,114,97,108,32,101,120,112,114,56,55,52,32,99,111,108,56,55,53,32,101,120,116,114,97,56,55,54,32,110,97,109,101,100,63,56,55,55,32,112,112,45,49,56,55,56,32,112,112,45,50,56,55,57,32,112,112,45,51,56,56,48,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,35),40,112,112,45,101,120,112,114,45,108,105,115,116,32,108,57,52,48,32,99,111,108,57,52,49,32,101,120,116,114,97,57,52,50,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,35),40,112,112,45,108,97,109,98,100,97,32,101,120,112,114,57,52,52,32,99,111,108,57,52,53,32,101,120,116,114,97,57,52,54,41,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,31),40,112,112,45,105,102,32,101,120,112,114,57,52,56,32,99,111,108,57,52,57,32,101,120,116,114,97,57,53,48,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,111,110,100,32,101,120,112,114,57,53,50,32,99,111,108,57,53,51,32,101,120,116,114,97,57,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,97,115,101,32,101,120,112,114,57,53,54,32,99,111,108,57,53,55,32,101,120,116,114,97,57,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,32),40,112,112,45,97,110,100,32,101,120,112,114,57,54,48,32,99,111,108,57,54,49,32,101,120,116,114,97,57,54,50,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,32),40,112,112,45,108,101,116,32,101,120,112,114,57,54,52,32,99,111,108,57,54,53,32,101,120,116,114,97,57,54,54,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,34),40,112,112,45,98,101,103,105,110,32,101,120,112,114,57,55,54,32,99,111,108,57,55,55,32,101,120,116,114,97,57,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,31),40,112,112,45,100,111,32,101,120,112,114,57,56,48,32,99,111,108,57,56,49,32,101,120,116,114,97,57,56,50,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,15),40,115,116,121,108,101,32,104,101,97,100,57,56,52,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,18),40,112,112,32,111,98,106,55,54,57,32,99,111,108,55,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,53),40,103,101,110,101,114,105,99,45,119,114,105,116,101,32,111,98,106,54,49,51,32,100,105,115,112,108,97,121,63,54,49,52,32,119,105,100,116,104,54,49,53,32,111,117,116,112,117,116,54,49,54,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,13),40,97,51,54,56,50,32,115,49,48,56,54,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,32),40,112,114,101,116,116,121,45,112,114,105,110,116,32,111,98,106,49,48,56,49,32,46,32,111,112,116,49,48,56,50,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,6),40,110,101,120,116,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,6),40,115,107,105,112,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,22),40,114,101,99,32,109,115,103,49,49,49,51,32,97,114,103,115,49,49,49,52,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,44),40,102,112,114,105,110,116,102,48,32,108,111,99,49,48,57,56,32,112,111,114,116,49,48,57,57,32,109,115,103,49,49,48,48,32,97,114,103,115,49,49,48,49,41,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,38),40,102,112,114,105,110,116,102,32,112,111,114,116,49,49,57,54,32,102,115,116,114,49,49,57,55,32,46,32,97,114,103,115,49,49,57,56,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,28),40,112,114,105,110,116,102,32,102,115,116,114,49,50,48,50,32,46,32,97,114,103,115,49,50,48,51,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,29),40,115,112,114,105,110,116,102,32,102,115,116,114,49,50,48,55,32,46,32,97,114,103,115,49,50,48,56,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,34),40,102,111,114,109,97,116,32,102,109,116,45,111,114,45,100,115,116,49,50,49,53,32,46,32,97,114,103,115,49,50,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1410 */
static C_word C_fcall stub139(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub139(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned int t0=(unsigned int )C_num_to_unsigned_int(C_a0);
srand(t0);
return C_r;}

C_noret_decl(C_extras_toplevel)
C_externexport void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3699)
static void C_fcall f_3699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_fcall f_3737(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3772)
static void C_fcall f_3772(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static C_word C_fcall f_3950(C_word t0,C_word t1);
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_fcall f_3753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static C_word C_fcall f_3746(C_word t0);
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_fcall f_2317(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_fcall f_2933(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3488)
static void C_fcall f_3488(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3498)
static void C_fcall f_3498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3458)
static void C_fcall f_3458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3267)
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_fcall f_3270(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_fcall f_3311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_fcall f_3352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3190)
static void C_fcall f_3190(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3196)
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_fcall f_3181(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_fcall f_3001(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_fcall f_3617(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_fcall f_2969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_fcall f_2936(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_fcall f_2430(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_fcall f_2669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2676)
static void C_fcall f_2676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_fcall f_2480(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_fcall f_2411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static C_word C_fcall f_2378(C_word t0);
C_noret_decl(f_2372)
static C_word C_fcall f_2372(C_word t0);
C_noret_decl(f_2320)
static void C_fcall f_2320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_fcall f_2352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2170)
static void C_fcall f_2170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_fcall f_2165(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2134)
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_fcall f_2151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_fcall f_2075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2012)
static void C_fcall f_2012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2002)
static void C_fcall f_2002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1879)
static void C_fcall f_1879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_fcall f_1874(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1832)
static void C_fcall f_1832(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_fcall f_1842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_fcall f_1750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_fcall f_1758(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1672)
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1516)
static void C_fcall f_1516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_fcall f_1539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_fcall f_1603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1468)
static void C_fcall f_1468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1344)
static void C_fcall f_1344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_fcall f_1339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1334)
static void C_fcall f_1334(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1274)
static void C_fcall f_1274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3699)
static void C_fcall trf_3699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3699(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3699(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3737)
static void C_fcall trf_3737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3737(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3737(t0,t1,t2,t3);}

C_noret_decl(trf_3772)
static void C_fcall trf_3772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3772(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3772(t0,t1);}

C_noret_decl(trf_3753)
static void C_fcall trf_3753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3753(t0,t1);}

C_noret_decl(trf_2317)
static void C_fcall trf_2317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2317(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2317(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2933)
static void C_fcall trf_2933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2933(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2933(t0,t1,t2,t3);}

C_noret_decl(trf_3488)
static void C_fcall trf_3488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3488(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3488(t0,t1,t2);}

C_noret_decl(trf_3498)
static void C_fcall trf_3498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3498(t0,t1);}

C_noret_decl(trf_3458)
static void C_fcall trf_3458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3458(t0,t1);}

C_noret_decl(trf_3267)
static void C_fcall trf_3267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3267(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3267(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_3270)
static void C_fcall trf_3270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3270(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3270(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3311)
static void C_fcall trf_3311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3311(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3311(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3352)
static void C_fcall trf_3352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3352(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3352(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3190)
static void C_fcall trf_3190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3190(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3190(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3196)
static void C_fcall trf_3196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3196(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3196(t0,t1,t2,t3);}

C_noret_decl(trf_3181)
static void C_fcall trf_3181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3181(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3181(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3153)
static void C_fcall trf_3153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3153(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3153(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3001)
static void C_fcall trf_3001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3001(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3001(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3592)
static void C_fcall trf_3592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3592(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3592(t0,t1,t2,t3);}

C_noret_decl(trf_3617)
static void C_fcall trf_3617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3617(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3617(t0,t1,t2,t3);}

C_noret_decl(trf_2969)
static void C_fcall trf_2969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2969(t0,t1,t2,t3);}

C_noret_decl(trf_2936)
static void C_fcall trf_2936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2936(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2936(t0,t1,t2,t3);}

C_noret_decl(trf_2430)
static void C_fcall trf_2430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2430(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2430(t0,t1,t2,t3);}

C_noret_decl(trf_2669)
static void C_fcall trf_2669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2669(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2669(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2676)
static void C_fcall trf_2676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2676(t0,t1);}

C_noret_decl(trf_2433)
static void C_fcall trf_2433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2433(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2433(t0,t1,t2,t3);}

C_noret_decl(trf_2460)
static void C_fcall trf_2460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2460(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2460(t0,t1,t2,t3);}

C_noret_decl(trf_2480)
static void C_fcall trf_2480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2480(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2480(t0,t1,t2,t3);}

C_noret_decl(trf_2411)
static void C_fcall trf_2411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2411(t0,t1,t2,t3);}

C_noret_decl(trf_2320)
static void C_fcall trf_2320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2320(t0,t1);}

C_noret_decl(trf_2352)
static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2352(t0,t1);}

C_noret_decl(trf_2170)
static void C_fcall trf_2170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2170(t0,t1);}

C_noret_decl(trf_2165)
static void C_fcall trf_2165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2165(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2165(t0,t1,t2);}

C_noret_decl(trf_2134)
static void C_fcall trf_2134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2134(t0,t1,t2,t3);}

C_noret_decl(trf_2151)
static void C_fcall trf_2151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2151(t0,t1);}

C_noret_decl(trf_2075)
static void C_fcall trf_2075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2075(t0,t1);}

C_noret_decl(trf_2012)
static void C_fcall trf_2012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2012(t0,t1);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2007(t0,t1,t2);}

C_noret_decl(trf_2002)
static void C_fcall trf_2002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2002(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2002(t0,t1,t2);}

C_noret_decl(trf_1960)
static void C_fcall trf_1960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1960(t0,t1,t2);}

C_noret_decl(trf_1879)
static void C_fcall trf_1879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1879(t0,t1);}

C_noret_decl(trf_1874)
static void C_fcall trf_1874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1874(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1874(t0,t1,t2);}

C_noret_decl(trf_1832)
static void C_fcall trf_1832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1832(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1832(t0,t1,t2,t3);}

C_noret_decl(trf_1842)
static void C_fcall trf_1842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1842(t0,t1);}

C_noret_decl(trf_1750)
static void C_fcall trf_1750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1750(t0,t1);}

C_noret_decl(trf_1758)
static void C_fcall trf_1758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1758(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1758(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1672)
static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1672(t0,t1,t2,t3);}

C_noret_decl(trf_1516)
static void C_fcall trf_1516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1516(t0,t1);}

C_noret_decl(trf_1539)
static void C_fcall trf_1539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1539(t0,t1,t2);}

C_noret_decl(trf_1603)
static void C_fcall trf_1603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1603(t0,t1);}

C_noret_decl(trf_1468)
static void C_fcall trf_1468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1468(t0,t1);}

C_noret_decl(trf_1344)
static void C_fcall trf_1344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1344(t0,t1);}

C_noret_decl(trf_1339)
static void C_fcall trf_1339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1339(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1339(t0,t1,t2);}

C_noret_decl(trf_1334)
static void C_fcall trf_1334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1334(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1334(t0,t1,t2,t3);}

C_noret_decl(trf_1274)
static void C_fcall trf_1274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1274(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1274(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1287)
static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1287(t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(840)){
C_save(t1);
C_rereclaim2(840*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,134);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],4,"read");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],20,"call-with-input-file");
lf[5]=C_h_intern(&lf[5],9,"read-file");
lf[6]=C_h_intern(&lf[6],5,"port\077");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-input");
lf[8]=C_h_intern(&lf[8],9,"\003syserror");
lf[9]=C_h_intern(&lf[9],11,"random-seed");
lf[10]=C_h_intern(&lf[10],17,"\003syscheck-integer");
lf[11]=C_h_intern(&lf[11],15,"current-seconds");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[13]=C_h_intern(&lf[13],6,"random");
lf[14]=C_h_intern(&lf[14],9,"randomize");
lf[15]=C_h_intern(&lf[15],11,"make-string");
lf[16]=C_h_intern(&lf[16],9,"read-line");
lf[17]=C_h_intern(&lf[17],13,"\003syssubstring");
lf[18]=C_h_intern(&lf[18],15,"\003sysread-char-0");
lf[19]=C_h_intern(&lf[19],9,"peek-char");
lf[20]=C_h_intern(&lf[20],17,"\003sysstring-append");
lf[21]=C_h_intern(&lf[21],15,"\003sysmake-string");
lf[22]=C_h_intern(&lf[22],14,"\003syscheck-port");
lf[23]=C_h_intern(&lf[23],10,"read-lines");
lf[24]=C_h_intern(&lf[24],16,"\003sysread-string!");
lf[25]=C_h_intern(&lf[25],12,"read-string!");
lf[26]=C_h_intern(&lf[26],18,"open-output-string");
lf[27]=C_h_intern(&lf[27],17,"get-output-string");
lf[28]=C_h_intern(&lf[28],20,"\003sysread-string/port");
lf[29]=C_h_intern(&lf[29],11,"read-string");
lf[30]=C_h_intern(&lf[30],19,"\003syswrite-char/port");
lf[31]=C_h_intern(&lf[31],10,"read-token");
lf[32]=C_h_intern(&lf[32],16,"\003syswrite-char-0");
lf[33]=C_h_intern(&lf[33],15,"\003syspeek-char-0");
lf[34]=C_h_intern(&lf[34],7,"display");
lf[35]=C_h_intern(&lf[35],12,"write-string");
lf[36]=C_h_intern(&lf[36],19,"\003sysstandard-output");
lf[37]=C_h_intern(&lf[37],7,"newline");
lf[38]=C_h_intern(&lf[38],10,"write-line");
lf[39]=C_h_intern(&lf[39],9,"read-byte");
lf[40]=C_h_intern(&lf[40],10,"write-byte");
lf[42]=C_h_intern(&lf[42],5,"quote");
lf[43]=C_h_intern(&lf[43],10,"quasiquote");
lf[44]=C_h_intern(&lf[44],7,"unquote");
lf[45]=C_h_intern(&lf[45],16,"unquote-splicing");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001`");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002,@");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\003 . ");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\002()");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[58]=C_h_intern(&lf[58],12,"vector->list");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002#t");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[61]=C_h_intern(&lf[61],18,"\003sysnumber->string");
lf[62]=C_h_intern(&lf[62],9,"\003sysprint");
lf[63]=C_h_intern(&lf[63],21,"\003sysprocedure->string");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001x");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001u");
lf[70]=C_h_intern(&lf[70],9,"char-name");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002#\134");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\016#<unspecified>");
lf[74]=C_h_intern(&lf[74],19,"\003syspointer->string");
lf[75]=C_h_intern(&lf[75],28,"\003sysarbitrary-unbound-symbol");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\020#<unbound value>");
lf[77]=C_h_intern(&lf[77],19,"\003sysuser-print-hook");
lf[78]=C_h_intern(&lf[78],13,"string-append");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\007#<port ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\025#<static blob of size");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017#<blob of size ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\002#>");
lf[85]=C_h_intern(&lf[85],23,"\003syslambda-info->string");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\016#<lambda info ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025#<unprintable object>");
lf[88]=C_h_intern(&lf[88],11,"\003sysnumber\077");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[92]=C_h_intern(&lf[92],3,"max");
lf[93]=C_h_intern(&lf[93],28,"\003syssymbol->qualified-string");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[101]=C_h_intern(&lf[101],6,"lambda");
lf[102]=C_h_intern(&lf[102],2,"if");
lf[103]=C_h_intern(&lf[103],4,"set!");
lf[104]=C_h_intern(&lf[104],4,"cond");
lf[105]=C_h_intern(&lf[105],4,"case");
lf[106]=C_h_intern(&lf[106],3,"and");
lf[107]=C_h_intern(&lf[107],2,"or");
lf[108]=C_h_intern(&lf[108],3,"let");
lf[109]=C_h_intern(&lf[109],5,"begin");
lf[110]=C_h_intern(&lf[110],2,"do");
lf[111]=C_h_intern(&lf[111],4,"let*");
lf[112]=C_h_intern(&lf[112],6,"letrec");
lf[113]=C_h_intern(&lf[113],6,"define");
lf[114]=C_h_intern(&lf[114],18,"pretty-print-width");
lf[115]=C_h_intern(&lf[115],12,"pretty-print");
lf[116]=C_h_intern(&lf[116],19,"current-output-port");
lf[117]=C_h_intern(&lf[117],2,"pp");
lf[118]=C_h_intern(&lf[118],5,"write");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[121]=C_h_intern(&lf[121],16,"\003sysflush-output");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\037illegal format-string character");
lf[123]=C_h_intern(&lf[123],13,"\003systty-port\077");
lf[124]=C_h_intern(&lf[124],7,"fprintf");
lf[125]=C_h_intern(&lf[125],6,"printf");
lf[126]=C_h_intern(&lf[126],7,"sprintf");
lf[127]=C_h_intern(&lf[127],6,"format");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal destination");
lf[129]=C_h_intern(&lf[129],12,"output-port\077");
lf[130]=C_h_intern(&lf[130],17,"register-feature!");
lf[131]=C_h_intern(&lf[131],7,"srfi-28");
lf[132]=C_h_intern(&lf[132],14,"make-parameter");
lf[133]=C_h_intern(&lf[133],6,"extras");
C_register_lf2(lf,134,create_ptable());
t2=C_mutate(&lf[0] /* c135 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1264,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1262 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1265 in k1262 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 76   register-feature!");
t3=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[133]);}

/* k1268 in k1265 in k1262 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[67],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1270,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=*((C_word*)lf[4]+1);
t5=C_mutate((C_word*)lf[5]+1 /* read-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1272,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li6),tmp=(C_word)a,a+=6,tmp));
t6=C_mutate((C_word*)lf[9]+1 /* random-seed ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[13]+1 /* random ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[14]+1 /* randomize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1463,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[15]+1);
t10=C_mutate((C_word*)lf[16]+1 /* read-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1506,a[2]=t9,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[16]+1);
t12=*((C_word*)lf[4]+1);
t13=*((C_word*)lf[3]+1);
t14=C_mutate((C_word*)lf[23]+1 /* read-lines ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1650,a[2]=t12,a[3]=t11,a[4]=t13,a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t15=C_mutate((C_word*)lf[24]+1 /* read-string! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[25]+1 /* read-string! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[26]+1);
t18=*((C_word*)lf[27]+1);
t19=C_mutate((C_word*)lf[28]+1 /* read-string/port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1927,a[2]=t17,a[3]=t18,a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp));
t20=C_mutate((C_word*)lf[29]+1 /* read-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2000,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[26]+1);
t22=*((C_word*)lf[27]+1);
t23=C_mutate((C_word*)lf[31]+1 /* read-token ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2060,a[2]=t21,a[3]=t22,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t24=*((C_word*)lf[34]+1);
t25=C_mutate((C_word*)lf[35]+1 /* write-string ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=t24,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t26=*((C_word*)lf[34]+1);
t27=*((C_word*)lf[37]+1);
t28=C_mutate((C_word*)lf[38]+1 /* write-line ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2218,a[2]=t26,a[3]=t27,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t29=C_mutate((C_word*)lf[39]+1 /* read-byte ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[40]+1 /* write-byte ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[26]+1);
t32=*((C_word*)lf[27]+1);
t33=C_mutate(&lf[41] /* generic-write ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t31,a[3]=t32,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp));
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 610  make-parameter");
t35=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t34,C_fix(79));}

/* k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* pretty-print-width ...) */,t1);
t3=C_mutate((C_word*)lf[115]+1 /* pretty-print ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[117]+1 /* pp ...) */,*((C_word*)lf[115]+1));
t5=*((C_word*)lf[118]+1);
t6=*((C_word*)lf[37]+1);
t7=*((C_word*)lf[34]+1);
t8=*((C_word*)lf[26]+1);
t9=*((C_word*)lf[27]+1);
t10=C_mutate(&lf[119] /* fprintf0 ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3699,a[2]=t8,a[3]=t6,a[4]=t7,a[5]=t5,a[6]=t9,a[7]=((C_word)li78),tmp=(C_word)a,a+=8,tmp));
t11=C_mutate((C_word*)lf[124]+1 /* fprintf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3997,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[125]+1 /* printf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4003,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[126]+1 /* sprintf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t14=*((C_word*)lf[124]+1);
t15=*((C_word*)lf[126]+1);
t16=*((C_word*)lf[125]+1);
t17=C_mutate((C_word*)lf[127]+1 /* format ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4015,a[2]=t14,a[3]=t15,a[4]=t16,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 702  register-feature!");
t19=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[131]);}

/* k4056 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_4015r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4015r(t0,t1,t2,t3);}}

static void C_ccall f_4015r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(15);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4023,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
if(C_truep(t6)){
if(C_truep((C_word)C_booleanp(t2))){
t7=t5;
f_4023(2,t7,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_4023(2,t9,((C_word*)t0)[3]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 697  output-port?");
t8=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}}
else{
t7=t5;
f_4023(2,t7,((C_word*)t0)[3]);}}

/* k4046 in format in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_4023(2,t4,((C_word*)t0)[2]);}
else{
C_trace("extras.scm: 699  ##sys#error");
t2=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[127],lf[128],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4021 in format in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* sprintf in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_4009r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4009r(t0,t1,t2,t3);}}

static void C_ccall f_4009r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_trace("extras.scm: 687  fprintf0");
t4=lf[119];
f_3699(t4,t1,lf[126],C_SCHEME_FALSE,t2,t3);}

/* printf in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_4003r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4003r(t0,t1,t2,t3);}}

static void C_ccall f_4003r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_trace("extras.scm: 684  fprintf0");
t4=lf[119];
f_3699(t4,t1,lf[125],*((C_word*)lf[36]+1),t2,t3);}

/* fprintf in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3997r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3997r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3997r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_trace("extras.scm: 681  fprintf0");
t5=lf[119];
f_3699(t5,t1,lf[124],t2,t3,t4);}

/* fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_fcall f_3699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3699,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
C_trace("extras.scm: 629  ##sys#check-port");
t7=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,t2);}
else{
t7=t6;
f_3703(2,t7,C_SCHEME_UNDEFINED);}}

/* k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[11])){
C_trace("extras.scm: 630  ##sys#tty-port?");
t4=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}
else{
t4=t3;
f_3986(2,t4,C_SCHEME_FALSE);}}

/* k3984 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3706(2,t2,((C_word*)t0)[3]);}
else{
C_trace("extras.scm: 632  open-output-string");
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}}

/* k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li77),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3737(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_fcall f_3737(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3737,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_string_2(t2,((C_word*)t0)[7]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3746,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t12,a[10]=t9,a[11]=t8,a[12]=t7,a[13]=((C_word)li76),tmp=(C_word)a,a+=14,tmp));
t14=((C_word*)t12)[1];
f_3772(t14,t1);}

/* loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_fcall f_3772(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[54],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3772,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_3746(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3785,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
t5=(C_truep(t4)?(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=f_3746(((C_word*)t0)[10]);
t7=(C_word)C_u_i_char_upcase(t6);
switch(t7){
case C_make_character(83):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3810,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 653  next");
t9=((C_word*)t0)[6];
f_3753(t9,t8);
case C_make_character(65):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3823,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 654  next");
t9=((C_word*)t0)[6];
f_3753(t9,t8);
case C_make_character(67):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 655  next");
t9=((C_word*)t0)[6];
f_3753(t9,t8);
case C_make_character(66):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 656  next");
t10=((C_word*)t0)[6];
f_3753(t10,t9);
case C_make_character(79):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3870,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 657  next");
t10=((C_word*)t0)[6];
f_3753(t10,t9);
case C_make_character(88):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3887,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 658  next");
t10=((C_word*)t0)[6];
f_3753(t10,t9);
case C_make_character(33):
C_trace("extras.scm: 659  ##sys#flush-output");
t8=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t3,((C_word*)t0)[7]);
case C_make_character(63):
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 661  next");
t9=((C_word*)t0)[6];
f_3753(t9,t8);
case C_make_character(126):
C_trace("extras.scm: 665  ##sys#write-char-0");
t8=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,C_make_character(126),((C_word*)t0)[7]);
default:
t8=(C_word)C_eqp(t7,C_make_character(37));
t9=(C_truep(t8)?t8:(C_word)C_eqp(t7,C_make_character(78)));
if(C_truep(t9)){
C_trace("extras.scm: 666  newline");
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t6))){
t10=f_3746(((C_word*)t0)[10]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[10],a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
t12=t3;
f_3785(2,t12,f_3950(t11,t10));}
else{
C_trace("extras.scm: 673  ##sys#error");
t10=*((C_word*)lf[8]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t3,((C_word*)t0)[4],lf[122],t6);}}}}
else{
C_trace("extras.scm: 674  ##sys#write-char-0");
t6=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t2,((C_word*)t0)[7]);}}}

/* skip in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static C_word C_fcall f_3950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_3746(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k3903 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3908,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 662  next");
t3=((C_word*)t0)[2];
f_3753(t3,t2);}

/* k3906 in k3903 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3908,2,t0,t1);}
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3914,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 664  rec");
t4=((C_word*)((C_word*)t0)[3])[1];
f_3737(t4,t3,((C_word*)t0)[2],t1);}

/* k3912 in k3906 in k3903 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3785(2,t2,((C_word*)t0)[2]);}

/* k3885 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 658  ##sys#number->string");
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(16));}

/* k3881 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 658  display");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3868 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 657  ##sys#number->string");
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(8));}

/* k3864 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 657  display");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3851 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 656  ##sys#number->string");
t2=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(2));}

/* k3847 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 656  display");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3834 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 655  ##sys#write-char-0");
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3821 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 654  display");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3808 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 653  write");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3783 in loop in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 675  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_3772(t2,((C_word*)t0)[2]);}

/* next in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_fcall f_3753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3753,NULL,2,t0,t1);}
if(C_truep((C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST))){
C_trace("extras.scm: 643  ##sys#error");
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],lf[120]);}
else{
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(0));
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in rec in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static C_word C_fcall f_3746(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* k3707 in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 678  get-output-string");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}
else{
C_trace("extras.scm: 676  get-output-string");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k3729 in k3707 in k3704 in k3701 in fprintf0 in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 678  ##sys#print");
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* pretty-print in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3670r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3670r(t0,t1,t2,t3);}}

static void C_ccall f_3670r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3674,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_3674(2,t5,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
C_trace("extras.scm: 613  current-output-port");
t5=*((C_word*)lf[116]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3672 in pretty-print in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 614  pretty-print-width");
t4=*((C_word*)lf[114]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3679 in k3672 in pretty-print in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[4],a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 614  generic-write");
t3=lf[41];
f_2317(t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a3682 in k3679 in k3672 in pretty-print in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3683,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 614  display");
t4=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k3685 in a3682 in k3679 in k3672 in pretty-print in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3675 in k3672 in pretty-print in k3666 in k1268 in k1265 in k1262 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2317(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2317,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2320,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2372,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2411,a[2]=t5,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2430,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t9,a[9]=t11,a[10]=((C_word)li44),tmp=(C_word)a,a+=11,tmp));
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2933,a[2]=t6,a[3]=t8,a[4]=t7,a[5]=t11,a[6]=t4,a[7]=t3,a[8]=t9,a[9]=((C_word)li70),tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3580,a[2]=t2,a[3]=t13,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 585  make-string");
t15=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(1),C_make_character(10));}
else{
C_trace("extras.scm: 586  wr");
t14=((C_word*)t11)[1];
f_2430(t14,t1,t2,C_fix(0));}}

/* k3578 in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3584,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 585  pp");
t3=((C_word*)t0)[3];
f_2933(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3582 in k3578 in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 585  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2933(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[151],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2933,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[8],a[8]=((C_word)li50),tmp=(C_word)a,a+=9,tmp));
t41=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3088,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word*)t0)[4],a[12]=((C_word)li51),tmp=(C_word)a,a+=13,tmp));
t42=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t17,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t43=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[8],a[3]=t17,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=t9,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t45=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t9,a[6]=t17,a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp));
t46=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3415,a[2]=t11,a[3]=t15,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t47=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3421,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t48=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3427,a[2]=t11,a[3]=t19,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t49=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3433,a[2]=t21,a[3]=t13,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t50=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3439,a[2]=t21,a[3]=t11,a[4]=t19,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t51=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3445,a[2]=t11,a[3]=t13,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t52=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3451,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t53=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3473,a[2]=t11,a[3]=t19,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t54=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3479,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3488,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,a[10]=((C_word)li69),tmp=(C_word)a,a+=11,tmp));
C_trace("extras.scm: 582  pr");
t56=((C_word*)t9)[1];
f_3001(t56,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3488(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3488,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[101]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_3498(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[111]);
if(C_truep(t5)){
t6=t4;
f_3498(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[112]);
t7=t4;
f_3498(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[113])));}}}

/* k3496 in style in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3498(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[102]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[103]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[105]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[106]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[107]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[109]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[110]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3479,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 560  pp-general");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3267(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3473,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 557  pp-general");
t5=((C_word*)((C_word*)t0)[3])[1];
f_3267(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3451,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_3458(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_3458(t7,C_SCHEME_FALSE);}}

/* k3456 in pp-let in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 554  pp-general");
t2=((C_word*)((C_word*)t0)[8])[1];
f_3267(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-and in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3445,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 549  pp-call");
t5=((C_word*)((C_word*)t0)[3])[1];
f_3153(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3439,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 546  pp-general");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3267(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3433,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 543  pp-call");
t5=((C_word*)((C_word*)t0)[3])[1];
f_3153(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3427,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 540  pp-general");
t5=((C_word*)((C_word*)t0)[3])[1];
f_3267(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3421,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 537  pp-general");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3267(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3415,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 534  pp-list");
t5=((C_word*)((C_word*)t0)[3])[1];
f_3181(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3267,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3352,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,a[5]=t4,a[6]=t7,a[7]=((C_word)li57),tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t4,a[6]=t6,a[7]=((C_word)li58),tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_i_cdr(t2);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,a[6]=t3,a[7]=t13,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3413,a[2]=t12,a[3]=t14,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 525  out");
t16=((C_word*)t0)[2];
f_2411(t16,t15,lf[100],t3);}

/* k3411 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 525  wr");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2430(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3363 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3380,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3395,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 529  out");
t7=((C_word*)t0)[2];
f_2411(t7,t6,lf[99],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
C_trace("extras.scm: 531  tail1");
t5=((C_word*)t0)[5];
f_3270(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k3393 in k3363 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 529  wr");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2430(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3378 in k3363 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
C_trace("extras.scm: 530  tail1");
t4=((C_word*)t0)[4];
f_3270(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail1 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3270(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3270,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3293,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 509  indent");
t13=((C_word*)t0)[2];
f_2969(t13,t12,t5,t4);}
else{
C_trace("extras.scm: 510  tail2");
t7=((C_word*)t0)[4];
f_3311(t7,t1,t2,t3,t4,t5);}}

/* k3295 in tail1 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 509  pr");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3001(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3291 in tail1 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 509  tail2");
t2=((C_word*)t0)[6];
f_3311(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3311,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3334,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 517  indent");
t13=((C_word*)t0)[2];
f_2969(t13,t12,t5,t4);}
else{
C_trace("extras.scm: 518  tail3");
t7=((C_word*)t0)[4];
f_3352(t7,t1,t2,t3,t4);}}

/* k3336 in tail2 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 517  pr");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3001(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3332 in tail2 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 517  tail3");
t2=((C_word*)t0)[5];
f_3352(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail3 in pp-general in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3352,NULL,5,t0,t1,t2,t3,t4);}
C_trace("extras.scm: 521  pp-down");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3190(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3190(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3190,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,a[9]=((C_word)li54),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3196(t10,t1,t2,t3);}

/* loop in pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3196,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3219,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 492  indent");
t10=((C_word*)t0)[4];
f_2969(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("extras.scm: 494  out");
t4=((C_word*)t0)[2];
f_2411(t4,t1,lf[96],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3249,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 498  indent");
t8=((C_word*)t0)[4];
f_2969(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3263 in loop in pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 498  out");
t2=((C_word*)t0)[3];
f_2411(t2,((C_word*)t0)[2],lf[98],t1);}

/* k3259 in loop in pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 498  indent");
t2=((C_word*)t0)[4];
f_2969(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3251 in loop in pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
C_trace("extras.scm: 497  pr");
t3=((C_word*)((C_word*)t0)[5])[1];
f_3001(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k3247 in loop in pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 496  out");
t2=((C_word*)t0)[3];
f_2411(t2,((C_word*)t0)[2],lf[97],t1);}

/* k3225 in loop in pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 492  pr");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3001(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3217 in loop in pp-down in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 491  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_3196(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3181(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3181,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3185,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 482  out");
t7=((C_word*)t0)[2];
f_2411(t7,t6,lf[95],t3);}

/* k3183 in pp-list in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 483  pp-down");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3190(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3153,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3157,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3179,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 474  out");
t9=((C_word*)t0)[2];
f_2411(t9,t8,lf[94],t3);}

/* k3177 in pp-call in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 474  wr");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2430(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3155 in pp-call in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3157,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
C_trace("extras.scm: 476  pp-down");
t4=((C_word*)((C_word*)t0)[5])[1];
f_3190(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3088,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
C_trace("extras.scm: 454  read-macro?");
f_2320(t5,t2);}

/* k3093 in pp-expr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
if(C_truep(t1)){
t2=f_2372(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t4=f_2378(((C_word*)t0)[13]);
C_trace("extras.scm: 456  out");
t5=((C_word*)t0)[7];
f_2411(t5,t3,t4,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3122,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
C_trace("extras.scm: 461  style");
t4=((C_word*)((C_word*)t0)[3])[1];
f_3488(t4,t3,t2);}
else{
C_trace("extras.scm: 468  pp-list");
t3=((C_word*)((C_word*)t0)[2])[1];
f_3181(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k3120 in k3093 in pp-expr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
if(C_truep(t1)){
C_trace("extras.scm: 463  proc");
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
C_trace("extras.scm: 464  ##sys#symbol->qualified-string");
t3=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3146 in k3120 in k3093 in pp-expr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
C_trace("extras.scm: 466  pp-general");
t3=((C_word*)((C_word*)t0)[8])[1];
f_3267(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
C_trace("extras.scm: 467  pp-call");
t3=((C_word*)((C_word*)t0)[2])[1];
f_3153(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k3104 in k3093 in pp-expr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 455  pr");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3001(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3001(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3001,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3014,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
C_trace("extras.scm: 440  max");
t14=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t13,C_fix(50));}
else{
C_trace("extras.scm: 451  wr");
t8=((C_word*)((C_word*)t0)[2])[1];
f_2430(t8,t1,t2,t3);}}

/* k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3014,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3052,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 441  generic-write");
t6=lf[41];
f_2317(t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a3051 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3052,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_i_string_length(t2);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k3015 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[7])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3592,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp));
C_trace("extras.scm: 605  rev-string-append");
t7=((C_word*)t5)[1];
f_3592(t7,t2,t3,C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
C_trace("extras.scm: 449  pp-pair");
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("extras.scm: 450  vector->list");
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k3044 in k3015 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 450  out");
t3=((C_word*)t0)[3];
f_2411(t3,t2,lf[91],((C_word*)t0)[2]);}

/* k3048 in k3044 in k3015 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 450  pp-list");
t2=((C_word*)((C_word*)t0)[6])[1];
f_3181(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* rev-string-append in k3015 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3592,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3608,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
C_trace("extras.scm: 596  rev-string-append");
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
C_trace("extras.scm: 603  make-string");
t4=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k3606 in rev-string-append in k3015 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3608,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3617,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3617(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k3606 in rev-string-append in k3015 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_3617(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3617,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
C_trace("extras.scm: 601  loop");
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* k3028 in k3015 in k3012 in pr in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 447  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2969,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2985,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2992,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 434  make-string");
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
C_trace("extras.scm: 435  spaces");
t5=((C_word*)((C_word*)t0)[3])[1];
f_2936(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2990 in indent in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 434  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2983 in indent in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("extras.scm: 434  spaces");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2936(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2936(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2936,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2960,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 427  out");
t6=((C_word*)t0)[2];
f_2411(t6,t5,lf[89],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2967,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 428  ##sys#substring");
t5=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[90],C_fix(0),t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2965 in spaces in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 428  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2958 in spaces in pp in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 427  spaces");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2936(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2430(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2430,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],a[8]=((C_word)li42),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
C_trace("extras.scm: 360  wr-expr");
t6=t5;
f_2433(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("extras.scm: 361  wr-lst");
t6=t4;
f_2460(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
C_trace("extras.scm: 362  out");
t6=((C_word*)t0)[8];
f_2411(t6,t1,lf[56],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2586,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 363  vector->list");
t7=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=(C_truep(t2)?lf[59]:lf[60]);
C_trace("extras.scm: 364  out");
t7=((C_word*)t0)[8];
f_2411(t7,t1,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("extras.scm: 365  ##sys#number?");
t7=*((C_word*)lf[88]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}}}}}

/* k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 365  ##sys#number->string");
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 367  open-output-string");
t3=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 370  ##sys#procedure->string");
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
C_trace("extras.scm: 372  out");
t2=((C_word*)t0)[8];
f_2411(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 373  out");
t3=((C_word*)t0)[8];
f_2411(t3,t2,lf[66],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 387  make-string");
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 389  out");
t4=((C_word*)t0)[8];
f_2411(t4,t3,lf[71],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
C_trace("extras.scm: 400  out");
t2=((C_word*)t0)[8];
f_2411(t2,((C_word*)t0)[7],lf[72],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
C_trace("extras.scm: 401  out");
t2=((C_word*)t0)[8];
f_2411(t2,((C_word*)t0)[7],lf[73],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 402  ##sys#pointer->string");
t3=*((C_word*)lf[74]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(lf[75],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
C_trace("extras.scm: 404  out");
t4=((C_word*)t0)[8];
f_2411(t4,((C_word*)t0)[7],lf[76],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 406  open-output-string");
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 409  port?");
t5=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}}}}}}}}}}

/* k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
C_trace("extras.scm: 409  string-append");
t4=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[79],t3,lf[80]);}
else{
if(C_truep((C_word)C_bytevectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[2]))){
C_trace("extras.scm: 412  out");
t3=((C_word*)t0)[5];
f_2411(t3,t2,lf[82],((C_word*)t0)[3]);}
else{
C_trace("extras.scm: 413  out");
t3=((C_word*)t0)[5];
f_2411(t3,t2,lf[83],((C_word*)t0)[3]);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 417  out");
t3=((C_word*)t0)[5];
f_2411(t3,t2,lf[86],((C_word*)t0)[3]);}
else{
C_trace("extras.scm: 420  out");
t2=((C_word*)t0)[5];
f_2411(t2,((C_word*)t0)[4],lf[87],((C_word*)t0)[3]);}}}}

/* k2912 in k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 418  ##sys#lambda-info->string");
t4=*((C_word*)lf[85]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2922 in k2912 in k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 418  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2915 in k2912 in k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 419  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],lf[84],((C_word*)t0)[2]);}

/* k2890 in k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 414  number->string");
C_number_to_string(3,0,t3,(C_word)C_block_size(((C_word*)t0)[2]));}

/* k2900 in k2890 in k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 414  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2893 in k2890 in k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 415  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],lf[81],((C_word*)t0)[2]);}

/* k2880 in k2873 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 409  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2857 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2862,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 407  ##sys#user-print-hook");
t3=*((C_word*)lf[77]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2860 in k2857 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 408  get-output-string");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2867 in k2860 in k2857 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 408  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2839 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 402  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2755 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 390  char-name");
t3=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2758 in k2755 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
C_trace("extras.scm: 392  out");
t3=((C_word*)t0)[6];
f_2411(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 394  out");
t3=((C_word*)t0)[6];
f_2411(t3,t2,lf[67],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535));
t4=(C_truep(t3)?lf[68]:lf[69]);
C_trace("extras.scm: 397  out");
t5=((C_word*)t0)[6];
f_2411(t5,t2,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 399  make-string");
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k2814 in k2758 in k2755 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 399  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2793 in k2758 in k2755 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 398  number->string");
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2800 in k2793 in k2758 in k2755 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 398  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2777 in k2758 in k2755 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 395  number->string");
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2784 in k2777 in k2758 in k2755 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 395  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2749 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 387  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2669(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2669,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2676,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_string_length(((C_word*)t0)[4]);
t7=t5;
f_2676(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_2676(t6,C_SCHEME_FALSE);}}

/* k2674 in loop in k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2676,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2699,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2703,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 381  ##sys#substring");
t9=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
C_trace("extras.scm: 383  loop");
t6=((C_word*)((C_word*)t0)[6])[1];
f_2669(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 385  ##sys#substring");
t4=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k2726 in k2674 in loop in k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 385  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2722 in k2674 in loop in k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 384  out");
t2=((C_word*)t0)[3];
f_2411(t2,((C_word*)t0)[2],lf[65],t1);}

/* k2705 in k2674 in loop in k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 381  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2701 in k2674 in loop in k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 380  out");
t2=((C_word*)t0)[3];
f_2411(t2,((C_word*)t0)[2],lf[64],t1);}

/* k2697 in k2674 in loop in k2665 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 378  loop");
t2=((C_word*)((C_word*)t0)[5])[1];
f_2669(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2646 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 370  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2623 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2628,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 368  ##sys#print");
t3=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2626 in k2623 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 369  get-output-string");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2633 in k2626 in k2623 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 369  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2614 in k2607 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 365  out");
t2=((C_word*)t0)[4];
f_2411(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2584 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2590,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 363  out");
t3=((C_word*)t0)[3];
f_2411(t3,t2,lf[57],((C_word*)t0)[2]);}

/* k2588 in k2584 in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 363  wr-lst");
t2=((C_word*)t0)[4];
f_2460(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2433,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
C_trace("extras.scm: 345  read-macro?");
f_2320(t4,t2);}

/* k2438 in wr-expr in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
if(C_truep(t1)){
t2=f_2372(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2451,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=f_2378(((C_word*)t0)[8]);
C_trace("extras.scm: 346  out");
t5=((C_word*)t0)[4];
f_2411(t5,t3,t4,((C_word*)t0)[3]);}
else{
C_trace("extras.scm: 347  wr-lst");
t2=((C_word*)t0)[2];
f_2460(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k2449 in k2438 in wr-expr in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 346  wr");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2430(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2460,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2478,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2543,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 352  out");
t8=((C_word*)t0)[2];
f_2411(t8,t7,lf[54],t3);}
else{
t6=t5;
f_2478(2,t6,C_SCHEME_FALSE);}}
else{
C_trace("extras.scm: 358  out");
t4=((C_word*)t0)[2];
f_2411(t4,t1,lf[55],t3);}}

/* k2541 in wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 352  wr");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2430(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2476 in wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2478,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2480(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k2476 in wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2480(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2480,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2504,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2512,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 355  out");
t9=((C_word*)t0)[2];
f_2411(t9,t8,lf[50],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("extras.scm: 356  out");
t5=((C_word*)t0)[2];
f_2411(t5,t1,lf[51],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2532,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 357  out");
t7=((C_word*)t0)[2];
f_2411(t7,t6,lf[53],t3);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* k2530 in loop in k2476 in wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 357  wr");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2430(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2526 in loop in k2476 in wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 357  out");
t2=((C_word*)t0)[3];
f_2411(t2,((C_word*)t0)[2],lf[52],t1);}

/* k2510 in loop in k2476 in wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 355  wr");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2430(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2502 in loop in k2476 in wr-lst in wr in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 355  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2480(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2411,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2421,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 340  output");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2419 in out in generic-write in k1268 in k1265 in k1262 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in generic-write in k1268 in k1265 in k1262 */
static C_word C_fcall f_2378(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_eqp(t2,lf[42]);
if(C_truep(t4)){
return(lf[46]);}
else{
t5=(C_word)C_eqp(t2,lf[43]);
if(C_truep(t5)){
return(lf[47]);}
else{
t6=(C_word)C_eqp(t2,lf[44]);
if(C_truep(t6)){
return(lf[48]);}
else{
t7=(C_word)C_eqp(t2,lf[45]);
return((C_truep(t7)?lf[49]:C_SCHEME_UNDEFINED));}}}}

/* read-macro-body in generic-write in k1268 in k1265 in k1262 */
static C_word C_fcall f_2372(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_i_cadr(t1));}

/* read-macro? in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2320(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2320,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,lf[42]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2352,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_2352(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[43]);
if(C_truep(t7)){
t8=t6;
f_2352(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[44]);
t9=t6;
f_2352(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[45])));}}}

/* k2350 in read-macro? in generic-write in k1268 in k1265 in k1262 */
static void C_fcall f_2352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* write-byte in k1268 in k1265 in k1262 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2279r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2279r(t0,t1,t2,t3);}}

static void C_ccall f_2279r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2283(2,t5,*((C_word*)lf[36]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2283(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2281 in write-byte in k1268 in k1265 in k1262 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[40]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2289,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 301  ##sys#check-port");
t4=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[40]);}

/* k2287 in k2281 in write-byte in k1268 in k1265 in k1262 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[4]));
C_trace("extras.scm: 302  ##sys#write-char-0");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* read-byte in k1268 in k1265 in k1262 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2239r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2239r(t0,t1,t2);}}

static void C_ccall f_2239r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2243,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2243(2,t4,*((C_word*)lf[7]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2243(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2241 in read-byte in k1268 in k1265 in k1262 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2246,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 293  ##sys#check-port");
t3=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[39]);}

/* k2244 in k2241 in read-byte in k1268 in k1265 in k1262 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("extras.scm: 294  ##sys#read-char-0");
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2247 in k2244 in k2241 in read-byte in k1268 in k1265 in k1262 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t1:(C_word)C_fix((C_word)C_character_code(t1))));}

/* write-line in k1268 in k1265 in k1262 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2218r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2218r(t0,t1,t2,t3);}}

static void C_ccall f_2218r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[36]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 284  ##sys#check-port");
t6=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[38]);}

/* k2223 in write-line in k1268 in k1265 in k1262 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[38]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 286  display");
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k2229 in k2223 in write-line in k1268 in k1265 in k1262 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 287  newline");
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k1268 in k1265 in k1262 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2129r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2129r(t0,t1,t2,t3);}}

static void C_ccall f_2129r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t4=(C_word)C_i_check_string_2(t2,lf[35]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2134,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2165,a[2]=t5,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2170,a[2]=t6,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-n519540");
t8=t7;
f_2170(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-port520536");
t10=t6;
f_2165(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body517525");
t12=t5;
f_2134(t12,t1,t8,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-n519 in write-string in k1268 in k1265 in k1262 */
static void C_fcall f_2170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2170,NULL,2,t0,t1);}
C_trace("def-port520536");
t2=((C_word*)t0)[2];
f_2165(t2,t1,C_SCHEME_FALSE);}

/* def-port520 in write-string in k1268 in k1265 in k1262 */
static void C_fcall f_2165(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2165,NULL,3,t0,t1,t2);}
C_trace("body517525");
t3=((C_word*)t0)[2];
f_2134(t3,t1,t2,*((C_word*)lf[36]+1));}

/* body517 in write-string in k1268 in k1265 in k1262 */
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2134,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 269  ##sys#check-port");
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[35]);}

/* k2136 in body517 in write-string in k1268 in k1265 in k1262 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[35]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(C_word)C_block_size(((C_word*)t0)[2]);
t6=t4;
f_2151(t6,(C_word)C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_2151(t5,C_SCHEME_FALSE);}}

/* k2149 in k2136 in body517 in write-string in k1268 in k1265 in k1262 */
static void C_fcall f_2151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("extras.scm: 273  ##sys#substring");
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2148(2,t2,((C_word*)t0)[3]);}}

/* k2146 in k2136 in body517 in write-string in k1268 in k1265 in k1262 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 271  display");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2060r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2060r(t0,t1,t2,t3);}}

static void C_ccall f_2060r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2064(2,t5,*((C_word*)lf[7]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2064(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2062 in read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 254  ##sys#check-port");
t3=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[31]);}

/* k2065 in k2062 in read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 255  open-output-string");
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2068 in k2065 in k2062 in read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=((C_word)li27),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2075(t5,((C_word*)t0)[2]);}

/* loop in k2068 in k2065 in k2062 in read-token in k1268 in k1265 in k1262 */
static void C_fcall f_2075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2075,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("extras.scm: 257  ##sys#peek-char-0");
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2077 in loop in k2068 in k2065 in k2062 in read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_2085(2,t3,C_SCHEME_FALSE);}
else{
C_trace("extras.scm: 258  pred");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k2083 in k2077 in loop in k2068 in k2065 in k2062 in read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 260  ##sys#read-char-0");
t4=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
C_trace("extras.scm: 262  get-output-string");
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k2093 in k2083 in k2077 in loop in k2068 in k2065 in k2062 in read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 260  ##sys#write-char-0");
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2086 in k2083 in k2077 in loop in k2068 in k2065 in k2062 in read-token in k1268 in k1265 in k1262 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 261  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2075(t2,((C_word*)t0)[2]);}

/* read-string in k1268 in k1265 in k1262 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_2000r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2000r(t0,t1,t2);}}

static void C_ccall f_2000r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("def-n445461");
t6=t5;
f_2012(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
C_trace("def-port446457");
t8=t4;
f_2007(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("body443452");
f_2002(t1,t6,t8);}
else{
C_trace("##sys#error");
t10=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n445 in read-string in k1268 in k1265 in k1262 */
static void C_fcall f_2012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2012,NULL,2,t0,t1);}
C_trace("def-port446457");
t2=((C_word*)t0)[2];
f_2007(t2,t1,C_SCHEME_FALSE);}

/* def-port446 in read-string in k1268 in k1265 in k1262 */
static void C_fcall f_2007(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,3,t0,t1,t2);}
C_trace("body443452");
f_2002(t1,t2,*((C_word*)lf[7]+1));}

/* body443 in read-string in k1268 in k1265 in k1262 */
static void C_fcall f_2002(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2002,NULL,3,t1,t2,t3);}
C_trace("extras.scm: 247  ##sys#read-string/port");
t4=*((C_word*)lf[28]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1927,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 228  ##sys#check-port");
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[29]);}

/* k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[29]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 230  ##sys#make-string");
t4=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 236  open-output-string");
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k1953 in k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1960(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k1953 in k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1960,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
C_trace("extras.scm: 238  get-output-string");
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[4]);}
else{
t5=t3;
f_1964(2,t5,C_SCHEME_FALSE);}}

/* k1962 in loop in k1953 in k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 239  ##sys#read-char-0");
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k1968 in k1962 in loop in k1953 in k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
C_trace("extras.scm: 241  get-output-string");
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 243  ##sys#write-char/port");
t3=*((C_word*)lf[30]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[4]);}}

/* k1980 in k1968 in k1962 in loop in k1953 in k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
C_trace("extras.scm: 244  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_1960(t3,((C_word*)t0)[2],t2);}

/* k1938 in k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1943,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 231  ##sys#read-string!");
t3=*((C_word*)lf[24]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[2],C_fix(0));}

/* k1941 in k1938 in k1929 in ##sys#read-string/port in k1268 in k1265 in k1262 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
C_trace("extras.scm: 234  ##sys#substring");
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* read-string! in k1268 in k1265 in k1262 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1830r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1830r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1832,a[2]=t5,a[3]=t3,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1874,a[2]=t6,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=t7,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-port346371");
t9=t8;
f_1879(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("def-start347367");
t11=t7;
f_1874(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("body344353");
t13=t6;
f_1832(t13,t1,t9,t11);}
else{
C_trace("##sys#error");
t13=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port346 in read-string! in k1268 in k1265 in k1262 */
static void C_fcall f_1879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1879,NULL,2,t0,t1);}
C_trace("def-start347367");
t2=((C_word*)t0)[2];
f_1874(t2,t1,*((C_word*)lf[7]+1));}

/* def-start347 in read-string! in k1268 in k1265 in k1262 */
static void C_fcall f_1874(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1874,NULL,3,t0,t1,t2);}
C_trace("body344353");
t3=((C_word*)t0)[2];
f_1832(t3,t1,t2,C_fix(0));}

/* body344 in read-string! in k1268 in k1265 in k1262 */
static void C_fcall f_1832(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1832,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1836,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 215  ##sys#check-port");
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[25]);}

/* k1834 in body344 in read-string! in k1268 in k1265 in k1262 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[25]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[25]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
t6=(C_word)C_block_size(((C_word*)t0)[6]);
if(C_truep((C_word)C_fixnum_greaterp(t5,t6))){
t7=(C_word)C_block_size(((C_word*)t0)[6]);
t8=(C_word)C_fixnum_difference(t7,((C_word*)t0)[5]);
t9=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t10=t3;
f_1842(t10,t9);}
else{
t7=t3;
f_1842(t7,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1842(t4,C_SCHEME_UNDEFINED);}}

/* k1840 in k1834 in body344 in read-string! in k1268 in k1265 in k1262 */
static void C_fcall f_1842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[25]);
C_trace("extras.scm: 222  ##sys#read-string!");
t3=*((C_word*)lf[24]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* ##sys#read-string! in k1268 in k1265 in k1262 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1740,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1750,a[2]=t2,a[3]=t6,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(t4,C_fix(6)))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1824,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 197  ##sys#read-char-0");
t10=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t8;
f_1750(t9,C_SCHEME_UNDEFINED);}}}

/* k1822 in ##sys#read-string! in k1268 in k1265 in k1262 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1750(t5,t4);}

/* k1748 in ##sys#read-string! in k1268 in k1265 in k1262 */
static void C_fcall f_1750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1750,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(7));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t5,a[6]=((C_word)li15),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1758(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}

/* loop in k1748 in ##sys#read-string! in k1268 in k1265 in k1262 */
static void C_fcall f_1758(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1758,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("extras.scm: 202  rdstring");
t6=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t0)[3],t3,((C_word*)t0)[2],t2);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1807,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 203  ##sys#read-char-0");
t7=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}}

/* k1805 in loop in k1748 in ##sys#read-string! in k1268 in k1265 in k1262 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
f_1762(2,t2,C_fix(0));}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[4];
f_1762(2,t3,C_fix(1));}}

/* k1760 in loop in k1748 in ##sys#read-string! in k1268 in k1265 in k1262 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_i_not(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t4)){
t5=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
C_trace("extras.scm: 211  loop");
t8=((C_word*)((C_word*)t0)[2])[1];
f_1758(t8,((C_word*)t0)[6],t5,t6,t7);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_plus(t1,((C_word*)t0)[5]));}}}

/* read-lines in k1268 in k1265 in k1262 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_1650r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1650r(t0,t1,t2);}}

static void C_ccall f_1650r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[7]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
C_trace("extras.scm: 185  call-with-input-file");
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1717,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 187  ##sys#check-port");
t11=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t4,lf[23]);}}

/* k1715 in read-lines in k1268 in k1265 in k1262 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 188  doread");
t2=((C_word*)t0)[4];
f_1662(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k1268 in k1265 in k1262 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1662,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(1000000000));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1672,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word)li12),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1672(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in doread in read-lines in k1268 in k1265 in k1262 */
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
C_trace("extras.scm: 179  reverse");
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 180  read-line");
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k1683 in loop in doread in read-lines in k1268 in k1265 in k1262 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
C_trace("extras.scm: 182  reverse");
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
C_trace("extras.scm: 183  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_1672(t4,((C_word*)t0)[5],t2,t3);}}

/* read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1506r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1506r(t0,t1,t2);}}

static void C_ccall f_1506r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):*((C_word*)lf[7]+1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_1516(t8,(C_truep(t7)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_1516(t6,C_SCHEME_FALSE);}}

/* k1514 in read-line in k1268 in k1265 in k1262 */
static void C_fcall f_1516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1516,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 139  ##sys#check-port");
t3=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[16]);}

/* k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(8));
if(C_truep(t3)){
C_trace("extras.scm: 140  rl");
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t4=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_fix(256));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 143  ##sys#make-string");
t8=*((C_word*)lf[21]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t6)[1]);}}

/* k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word)li10),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_1539(t7,((C_word*)t0)[2],C_fix(0));}

/* loop in k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_fcall f_1539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1539,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[7])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t3)){
C_trace("extras.scm: 146  ##sys#substring");
t4=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
C_trace("extras.scm: 147  ##sys#read-char-0");
t5=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}

/* k1550 in loop in k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
C_trace("extras.scm: 151  ##sys#substring");
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);}}
else{
switch(t1){
case C_make_character(10):
C_trace("extras.scm: 153  ##sys#substring");
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 155  peek-char");
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[8],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1617,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 162  make-string");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_1603(t3,C_SCHEME_UNDEFINED);}}}}

/* k1623 in k1550 in loop in k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 162  ##sys#string-append");
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1615 in k1550 in loop in k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1603(t5,t4);}

/* k1601 in k1550 in loop in k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_fcall f_1603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
C_trace("extras.scm: 165  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_1539(t4,((C_word*)t0)[2],t3);}

/* k1583 in k1550 in loop in k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("extras.scm: 157  ##sys#read-char-0");
t4=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
C_trace("extras.scm: 159  ##sys#substring");
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}}

/* k1592 in k1583 in k1550 in loop in k1532 in k1517 in k1514 in read-line in k1268 in k1265 in k1262 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("extras.scm: 158  ##sys#substring");
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],C_fix(0),((C_word*)t0)[2]);}

/* randomize in k1268 in k1265 in k1262 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1463r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1463r(t0,t1,t2);}}

static void C_ccall f_1463r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t3;
f_1468(t4,(C_word)C_fudge(C_fix(2)));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[14]);
t6=t3;
f_1468(t6,t4);}}

/* k1466 in randomize in k1268 in k1265 in k1262 */
static void C_fcall f_1468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_randomize(t1));}

/* random in k1268 in k1265 in k1262 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1451,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[13]);
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_fix(0):(C_word)C_random_fixnum(t2)));}

/* random-seed in k1268 in k1265 in k1262 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1413r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1413r(t0,t1,t2);}}

static void C_ccall f_1413r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1417,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_block_size(t2);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(1)))){
t5=(C_word)C_block_size(t2);
C_trace("extras.scm: 102  ##sys#error");
t6=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t3,lf[9],lf[12],t5,C_fix(1));}
else{
t5=t3;
f_1417(2,t5,C_SCHEME_FALSE);}}

/* k1415 in random-seed in k1268 in k1265 in k1262 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1420,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(((C_word*)t0)[2]))){
C_trace("extras.scm: 104  current-seconds");
t3=*((C_word*)lf[11]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1420(2,t3,(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0)));}}

/* k1418 in k1415 in random-seed in k1268 in k1265 in k1262 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("extras.scm: 106  ##sys#check-integer");
t3=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[9]);}

/* k1421 in k1418 in k1415 in random-seed in k1268 in k1265 in k1262 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub139(C_SCHEME_UNDEFINED,t4));}

/* read-file in k1268 in k1265 in k1262 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr2r,(void*)f_1272r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1272r(t0,t1,t2);}}

static void C_ccall f_1272r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1334,a[2]=t3,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1344,a[2]=t5,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("def-port73122");
t7=t6;
f_1344(t7,t1);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t8))){
C_trace("def-reader74118");
t9=t5;
f_1339(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("def-max75113");
t11=t4;
f_1334(t11,t1,t7,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("body7181");
t13=t3;
f_1274(t13,t1,t7,t9,t11);}
else{
C_trace("##sys#error");
t13=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-port73 in read-file in k1268 in k1265 in k1262 */
static void C_fcall f_1344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1344,NULL,2,t0,t1);}
C_trace("def-reader74118");
t2=((C_word*)t0)[2];
f_1339(t2,t1,*((C_word*)lf[7]+1));}

/* def-reader74 in read-file in k1268 in k1265 in k1262 */
static void C_fcall f_1339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1339,NULL,3,t0,t1,t2);}
C_trace("def-max75113");
t3=((C_word*)t0)[3];
f_1334(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max75 in read-file in k1268 in k1265 in k1262 */
static void C_fcall f_1334(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1334,NULL,4,t0,t1,t2,t3);}
C_trace("body7181");
t4=((C_word*)t0)[2];
f_1274(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body71 in read-file in k1268 in k1265 in k1262 */
static void C_fcall f_1274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1274,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1277,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word)li1),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_trace("extras.scm: 90   port?");
t7=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k1325 in body71 in read-file in k1268 in k1265 in k1262 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("extras.scm: 91   slurp");
t2=((C_word*)t0)[5];
f_1277(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
C_trace("extras.scm: 92   call-with-input-file");
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body71 in read-file in k1268 in k1265 in k1262 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1277,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1285,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 86   reader");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1283 in slurp in body71 in read-file in k1268 in k1265 in k1262 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li0),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1287(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* doloop88 in k1283 in slurp in body71 in read-file in k1268 in k1265 in k1262 */
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1287,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
C_trace("extras.scm: 89   reverse");
t7=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1307,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("extras.scm: 86   reader");
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k1305 in doloop88 in k1283 in slurp in body71 in read-file in k1268 in k1265 in k1262 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_1287(t4,((C_word*)t0)[2],t1,t2,t3);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[243] = {
{"toplevelextras.scm",(void*)C_extras_toplevel},
{"f_1264extras.scm",(void*)f_1264},
{"f_1267extras.scm",(void*)f_1267},
{"f_1270extras.scm",(void*)f_1270},
{"f_3668extras.scm",(void*)f_3668},
{"f_4058extras.scm",(void*)f_4058},
{"f_4015extras.scm",(void*)f_4015},
{"f_4048extras.scm",(void*)f_4048},
{"f_4023extras.scm",(void*)f_4023},
{"f_4009extras.scm",(void*)f_4009},
{"f_4003extras.scm",(void*)f_4003},
{"f_3997extras.scm",(void*)f_3997},
{"f_3699extras.scm",(void*)f_3699},
{"f_3703extras.scm",(void*)f_3703},
{"f_3986extras.scm",(void*)f_3986},
{"f_3706extras.scm",(void*)f_3706},
{"f_3737extras.scm",(void*)f_3737},
{"f_3772extras.scm",(void*)f_3772},
{"f_3950extras.scm",(void*)f_3950},
{"f_3905extras.scm",(void*)f_3905},
{"f_3908extras.scm",(void*)f_3908},
{"f_3914extras.scm",(void*)f_3914},
{"f_3887extras.scm",(void*)f_3887},
{"f_3883extras.scm",(void*)f_3883},
{"f_3870extras.scm",(void*)f_3870},
{"f_3866extras.scm",(void*)f_3866},
{"f_3853extras.scm",(void*)f_3853},
{"f_3849extras.scm",(void*)f_3849},
{"f_3836extras.scm",(void*)f_3836},
{"f_3823extras.scm",(void*)f_3823},
{"f_3810extras.scm",(void*)f_3810},
{"f_3785extras.scm",(void*)f_3785},
{"f_3753extras.scm",(void*)f_3753},
{"f_3746extras.scm",(void*)f_3746},
{"f_3709extras.scm",(void*)f_3709},
{"f_3731extras.scm",(void*)f_3731},
{"f_3670extras.scm",(void*)f_3670},
{"f_3674extras.scm",(void*)f_3674},
{"f_3681extras.scm",(void*)f_3681},
{"f_3683extras.scm",(void*)f_3683},
{"f_3687extras.scm",(void*)f_3687},
{"f_3677extras.scm",(void*)f_3677},
{"f_2317extras.scm",(void*)f_2317},
{"f_3580extras.scm",(void*)f_3580},
{"f_3584extras.scm",(void*)f_3584},
{"f_2933extras.scm",(void*)f_2933},
{"f_3488extras.scm",(void*)f_3488},
{"f_3498extras.scm",(void*)f_3498},
{"f_3479extras.scm",(void*)f_3479},
{"f_3473extras.scm",(void*)f_3473},
{"f_3451extras.scm",(void*)f_3451},
{"f_3458extras.scm",(void*)f_3458},
{"f_3445extras.scm",(void*)f_3445},
{"f_3439extras.scm",(void*)f_3439},
{"f_3433extras.scm",(void*)f_3433},
{"f_3427extras.scm",(void*)f_3427},
{"f_3421extras.scm",(void*)f_3421},
{"f_3415extras.scm",(void*)f_3415},
{"f_3267extras.scm",(void*)f_3267},
{"f_3413extras.scm",(void*)f_3413},
{"f_3365extras.scm",(void*)f_3365},
{"f_3395extras.scm",(void*)f_3395},
{"f_3380extras.scm",(void*)f_3380},
{"f_3270extras.scm",(void*)f_3270},
{"f_3297extras.scm",(void*)f_3297},
{"f_3293extras.scm",(void*)f_3293},
{"f_3311extras.scm",(void*)f_3311},
{"f_3338extras.scm",(void*)f_3338},
{"f_3334extras.scm",(void*)f_3334},
{"f_3352extras.scm",(void*)f_3352},
{"f_3190extras.scm",(void*)f_3190},
{"f_3196extras.scm",(void*)f_3196},
{"f_3265extras.scm",(void*)f_3265},
{"f_3261extras.scm",(void*)f_3261},
{"f_3253extras.scm",(void*)f_3253},
{"f_3249extras.scm",(void*)f_3249},
{"f_3227extras.scm",(void*)f_3227},
{"f_3219extras.scm",(void*)f_3219},
{"f_3181extras.scm",(void*)f_3181},
{"f_3185extras.scm",(void*)f_3185},
{"f_3153extras.scm",(void*)f_3153},
{"f_3179extras.scm",(void*)f_3179},
{"f_3157extras.scm",(void*)f_3157},
{"f_3088extras.scm",(void*)f_3088},
{"f_3095extras.scm",(void*)f_3095},
{"f_3122extras.scm",(void*)f_3122},
{"f_3148extras.scm",(void*)f_3148},
{"f_3106extras.scm",(void*)f_3106},
{"f_3001extras.scm",(void*)f_3001},
{"f_3014extras.scm",(void*)f_3014},
{"f_3052extras.scm",(void*)f_3052},
{"f_3017extras.scm",(void*)f_3017},
{"f_3046extras.scm",(void*)f_3046},
{"f_3050extras.scm",(void*)f_3050},
{"f_3592extras.scm",(void*)f_3592},
{"f_3608extras.scm",(void*)f_3608},
{"f_3617extras.scm",(void*)f_3617},
{"f_3030extras.scm",(void*)f_3030},
{"f_2969extras.scm",(void*)f_2969},
{"f_2992extras.scm",(void*)f_2992},
{"f_2985extras.scm",(void*)f_2985},
{"f_2936extras.scm",(void*)f_2936},
{"f_2967extras.scm",(void*)f_2967},
{"f_2960extras.scm",(void*)f_2960},
{"f_2430extras.scm",(void*)f_2430},
{"f_2609extras.scm",(void*)f_2609},
{"f_2875extras.scm",(void*)f_2875},
{"f_2914extras.scm",(void*)f_2914},
{"f_2924extras.scm",(void*)f_2924},
{"f_2917extras.scm",(void*)f_2917},
{"f_2892extras.scm",(void*)f_2892},
{"f_2902extras.scm",(void*)f_2902},
{"f_2895extras.scm",(void*)f_2895},
{"f_2882extras.scm",(void*)f_2882},
{"f_2859extras.scm",(void*)f_2859},
{"f_2862extras.scm",(void*)f_2862},
{"f_2869extras.scm",(void*)f_2869},
{"f_2841extras.scm",(void*)f_2841},
{"f_2757extras.scm",(void*)f_2757},
{"f_2760extras.scm",(void*)f_2760},
{"f_2816extras.scm",(void*)f_2816},
{"f_2795extras.scm",(void*)f_2795},
{"f_2802extras.scm",(void*)f_2802},
{"f_2779extras.scm",(void*)f_2779},
{"f_2786extras.scm",(void*)f_2786},
{"f_2751extras.scm",(void*)f_2751},
{"f_2667extras.scm",(void*)f_2667},
{"f_2669extras.scm",(void*)f_2669},
{"f_2676extras.scm",(void*)f_2676},
{"f_2728extras.scm",(void*)f_2728},
{"f_2724extras.scm",(void*)f_2724},
{"f_2707extras.scm",(void*)f_2707},
{"f_2703extras.scm",(void*)f_2703},
{"f_2699extras.scm",(void*)f_2699},
{"f_2648extras.scm",(void*)f_2648},
{"f_2625extras.scm",(void*)f_2625},
{"f_2628extras.scm",(void*)f_2628},
{"f_2635extras.scm",(void*)f_2635},
{"f_2616extras.scm",(void*)f_2616},
{"f_2586extras.scm",(void*)f_2586},
{"f_2590extras.scm",(void*)f_2590},
{"f_2433extras.scm",(void*)f_2433},
{"f_2440extras.scm",(void*)f_2440},
{"f_2451extras.scm",(void*)f_2451},
{"f_2460extras.scm",(void*)f_2460},
{"f_2543extras.scm",(void*)f_2543},
{"f_2478extras.scm",(void*)f_2478},
{"f_2480extras.scm",(void*)f_2480},
{"f_2532extras.scm",(void*)f_2532},
{"f_2528extras.scm",(void*)f_2528},
{"f_2512extras.scm",(void*)f_2512},
{"f_2504extras.scm",(void*)f_2504},
{"f_2411extras.scm",(void*)f_2411},
{"f_2421extras.scm",(void*)f_2421},
{"f_2378extras.scm",(void*)f_2378},
{"f_2372extras.scm",(void*)f_2372},
{"f_2320extras.scm",(void*)f_2320},
{"f_2352extras.scm",(void*)f_2352},
{"f_2279extras.scm",(void*)f_2279},
{"f_2283extras.scm",(void*)f_2283},
{"f_2289extras.scm",(void*)f_2289},
{"f_2239extras.scm",(void*)f_2239},
{"f_2243extras.scm",(void*)f_2243},
{"f_2246extras.scm",(void*)f_2246},
{"f_2249extras.scm",(void*)f_2249},
{"f_2218extras.scm",(void*)f_2218},
{"f_2225extras.scm",(void*)f_2225},
{"f_2231extras.scm",(void*)f_2231},
{"f_2129extras.scm",(void*)f_2129},
{"f_2170extras.scm",(void*)f_2170},
{"f_2165extras.scm",(void*)f_2165},
{"f_2134extras.scm",(void*)f_2134},
{"f_2138extras.scm",(void*)f_2138},
{"f_2151extras.scm",(void*)f_2151},
{"f_2148extras.scm",(void*)f_2148},
{"f_2060extras.scm",(void*)f_2060},
{"f_2064extras.scm",(void*)f_2064},
{"f_2067extras.scm",(void*)f_2067},
{"f_2070extras.scm",(void*)f_2070},
{"f_2075extras.scm",(void*)f_2075},
{"f_2079extras.scm",(void*)f_2079},
{"f_2085extras.scm",(void*)f_2085},
{"f_2095extras.scm",(void*)f_2095},
{"f_2088extras.scm",(void*)f_2088},
{"f_2000extras.scm",(void*)f_2000},
{"f_2012extras.scm",(void*)f_2012},
{"f_2007extras.scm",(void*)f_2007},
{"f_2002extras.scm",(void*)f_2002},
{"f_1927extras.scm",(void*)f_1927},
{"f_1931extras.scm",(void*)f_1931},
{"f_1955extras.scm",(void*)f_1955},
{"f_1960extras.scm",(void*)f_1960},
{"f_1964extras.scm",(void*)f_1964},
{"f_1970extras.scm",(void*)f_1970},
{"f_1982extras.scm",(void*)f_1982},
{"f_1940extras.scm",(void*)f_1940},
{"f_1943extras.scm",(void*)f_1943},
{"f_1830extras.scm",(void*)f_1830},
{"f_1879extras.scm",(void*)f_1879},
{"f_1874extras.scm",(void*)f_1874},
{"f_1832extras.scm",(void*)f_1832},
{"f_1836extras.scm",(void*)f_1836},
{"f_1842extras.scm",(void*)f_1842},
{"f_1740extras.scm",(void*)f_1740},
{"f_1824extras.scm",(void*)f_1824},
{"f_1750extras.scm",(void*)f_1750},
{"f_1758extras.scm",(void*)f_1758},
{"f_1807extras.scm",(void*)f_1807},
{"f_1762extras.scm",(void*)f_1762},
{"f_1650extras.scm",(void*)f_1650},
{"f_1717extras.scm",(void*)f_1717},
{"f_1662extras.scm",(void*)f_1662},
{"f_1672extras.scm",(void*)f_1672},
{"f_1685extras.scm",(void*)f_1685},
{"f_1506extras.scm",(void*)f_1506},
{"f_1516extras.scm",(void*)f_1516},
{"f_1519extras.scm",(void*)f_1519},
{"f_1534extras.scm",(void*)f_1534},
{"f_1539extras.scm",(void*)f_1539},
{"f_1552extras.scm",(void*)f_1552},
{"f_1625extras.scm",(void*)f_1625},
{"f_1617extras.scm",(void*)f_1617},
{"f_1603extras.scm",(void*)f_1603},
{"f_1585extras.scm",(void*)f_1585},
{"f_1594extras.scm",(void*)f_1594},
{"f_1463extras.scm",(void*)f_1463},
{"f_1468extras.scm",(void*)f_1468},
{"f_1451extras.scm",(void*)f_1451},
{"f_1413extras.scm",(void*)f_1413},
{"f_1417extras.scm",(void*)f_1417},
{"f_1420extras.scm",(void*)f_1420},
{"f_1423extras.scm",(void*)f_1423},
{"f_1272extras.scm",(void*)f_1272},
{"f_1344extras.scm",(void*)f_1344},
{"f_1339extras.scm",(void*)f_1339},
{"f_1334extras.scm",(void*)f_1334},
{"f_1274extras.scm",(void*)f_1274},
{"f_1327extras.scm",(void*)f_1327},
{"f_1277extras.scm",(void*)f_1277},
{"f_1285extras.scm",(void*)f_1285},
{"f_1287extras.scm",(void*)f_1287},
{"f_1307extras.scm",(void*)f_1307},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
