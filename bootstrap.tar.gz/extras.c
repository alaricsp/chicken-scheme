/* Generated from extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-12-09 16:20
   Version 2.733 - macosx-unix-gnu-ppc	[ manyargs dload ptables applyhook cross ]
(c)2000-2007 Felix L. Winkelmann	compiled 2007-11-30 on apfel.local (Darwin)
   command line: extras.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file extras.c -extend private-namespace.scm
   unit: extras
*/

#include "chicken.h"

#define C_hashptr(x)   C_fix(x & C_MOST_POSITIVE_FIXNUM)
#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[596];


C_noret_decl(C_extras_toplevel)
C_externexport void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9417)
static void C_ccall f_9417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9480)
static void C_fcall f_9480(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9438)
static void C_fcall f_9438(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9520)
static void C_ccall f_9520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9353)
static void C_ccall f_9353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9380)
static C_word C_fcall f_9380(C_word t0);
C_noret_decl(f_9366)
static void C_fcall f_9366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9270)
static void C_ccall f_9270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9289)
static void C_fcall f_9289(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9299)
static void C_ccall f_9299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9281)
static void C_ccall f_9281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9203)
static void C_fcall f_9203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9182)
static void C_ccall f_9182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_ccall f_9151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9161)
static void C_ccall f_9161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9057)
static void C_ccall f_9057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9072)
static void C_fcall f_9072(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9088)
static void C_fcall f_9088(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9116)
static void C_ccall f_9116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9005)
static void C_ccall f_9005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9020)
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9039)
static void C_ccall f_9039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9030)
static void C_ccall f_9030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8937)
static void C_ccall f_8937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8952)
static void C_fcall f_8952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8968)
static void C_fcall f_8968(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8872)
static void C_ccall f_8872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8887)
static void C_fcall f_8887(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8903)
static void C_fcall f_8903(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8853)
static void C_ccall f_8853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8856)
static void C_ccall f_8856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8776)
static void C_ccall f_8776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8791)
static void C_fcall f_8791(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8807)
static void C_fcall f_8807(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8723)
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8746)
static void C_fcall f_8746(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8759)
static void C_ccall f_8759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_ccall f_8733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8626)
static void C_ccall f_8626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8638)
static void C_fcall f_8638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8661)
static void C_fcall f_8661(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8546)
static void C_fcall f_8546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8572)
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8598)
static void C_fcall f_8598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8585)
static void C_fcall f_8585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8559)
static void C_ccall f_8559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8400)
static void C_ccall f_8400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8472)
static void C_fcall f_8472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8491)
static void C_fcall f_8491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8417)
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8436)
static void C_fcall f_8436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8348)
static void C_ccall f_8348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8358)
static void C_fcall f_8358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8346)
static void C_ccall f_8346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8319)
static void C_ccall f_8319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_ccall f_8309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8294)
static void C_ccall f_8294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8050)
static void C_ccall f_8050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8050)
static void C_ccall f_8050r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8272)
static void C_ccall f_8272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8054)
static void C_ccall f_8054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_fcall f_8062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8078)
static void C_ccall f_8078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8260)
static void C_ccall f_8260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_fcall f_8188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8228)
static void C_ccall f_8228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8216)
static void C_ccall f_8216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8125)
static void C_fcall f_8125(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8153)
static void C_ccall f_8153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8135)
static void C_ccall f_8135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_ccall f_8103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8017)
static void C_ccall f_8017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_ccall f_7985(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7985)
static void C_ccall f_7985r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7989)
static void C_ccall f_7989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7957)
static void C_ccall f_7957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7755)
static void C_fcall f_7755(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7886)
static void C_fcall f_7886(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7921)
static void C_ccall f_7921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7730)
static void C_fcall f_7730(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7740)
static void C_fcall f_7740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7718)
static void C_ccall f_7718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7614)
static void C_ccall f_7614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_fcall f_7632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7674)
static void C_fcall f_7674(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7695)
static void C_ccall f_7695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7551)
static void C_fcall f_7551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_fcall f_7546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7541)
static void C_fcall f_7541(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7529)
static void C_fcall f_7529(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7441)
static void C_fcall f_7441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_fcall f_7455(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7465)
static void C_ccall f_7465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7435)
static void C_ccall f_7435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7376)
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7280)
static void C_fcall f_7280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7331)
static void C_ccall f_7331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7321)
static void C_fcall f_7321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7299)
static void C_ccall f_7299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7145)
static void C_ccall f_7145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7250)
static void C_ccall f_7250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7148)
static void C_fcall f_7148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7080)
static void C_fcall f_7080(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7012)
static void C_fcall f_7012(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6964)
static void C_fcall f_6964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6610)
static void C_fcall f_6610(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_fcall f_6648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6835)
static C_word C_fcall f_6835(C_word t0,C_word t1);
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6629)
static void C_fcall f_6629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static C_word C_fcall f_6622(C_word t0);
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6503)
static void C_fcall f_6503(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6534)
static void C_ccall f_6534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6378)
static void C_fcall f_6378(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6411)
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6476)
static void C_ccall f_6476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_fcall f_6450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_fcall f_6396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6221)
static void C_fcall f_6221(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_fcall f_6167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6178)
static C_word C_fcall f_6178(C_word t0,C_word t1);
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_fcall f_6067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static C_word C_fcall f_6082(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5955)
static void C_fcall f_5955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5982)
static void C_fcall f_5982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_fcall f_5935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_fcall f_5942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5851)
static void C_fcall f_5851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_fcall f_5846(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5841)
static void C_fcall f_5841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5836)
static void C_fcall f_5836(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5807)
static void C_fcall f_5807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5734)
static void C_fcall f_5734(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_fcall f_5729(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5724)
static void C_fcall f_5724(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5719)
static void C_fcall f_5719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5690)
static void C_fcall f_5690(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5497)
static void C_fcall f_5497(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5518)
static void C_fcall f_5518(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5335)
static void C_fcall f_5335(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_fcall f_5360(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5231)
static void C_fcall f_5231(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5241)
static void C_fcall f_5241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5201)
static void C_fcall f_5201(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5010)
static void C_fcall f_5010(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_fcall f_5054(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4933)
static void C_fcall f_4933(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4939)
static void C_fcall f_4939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_fcall f_4924(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_fcall f_4896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_fcall f_4744(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_fcall f_4173(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_fcall f_4412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4419)
static void C_fcall f_4419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_fcall f_4176(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_fcall f_4154(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static C_word C_fcall f_4121(C_word t0);
C_noret_decl(f_4115)
static C_word C_fcall f_4115(C_word t0);
C_noret_decl(f_4063)
static void C_fcall f_4063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_fcall f_4095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3939)
static void C_fcall f_3939(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3929)
static void C_fcall f_3929(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3858)
static void C_fcall f_3858(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3530)
static void C_fcall f_3530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_fcall f_3525(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3494)
static void C_fcall f_3494(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_fcall f_3511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_fcall f_3435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3372)
static void C_fcall f_3372(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3362)
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_fcall f_3320(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3239)
static void C_fcall f_3239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_fcall f_3234(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3192)
static void C_fcall f_3192(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_fcall f_3202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_fcall f_3110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_fcall f_3118(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3032)
static void C_fcall f_3032(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_fcall f_2903(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_fcall f_2967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2832)
static void C_fcall f_2832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2777)
static void C_fcall f_2777(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2717)
static void C_fcall f_2717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2643)
static void C_fcall f_2643(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2678)
static void C_fcall f_2678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_fcall f_2647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2600)
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_fcall f_2562(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2443)
static void C_fcall f_2443(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2387)
static void C_fcall f_2387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_fcall f_2305(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2326)
static void C_fcall f_2326(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2255)
static void C_fcall f_2255(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2226)
static void C_fcall f_2226(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2190)
static void C_fcall f_2190(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2168)
static C_word C_fcall f_2168(C_word t0,C_word t1);
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2122)
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2056)
static void C_fcall f_2056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2021)
static void C_fcall f_2021(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1901)
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1868)
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_fcall f_1781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1776)
static void C_fcall f_1776(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_fcall f_1729(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9480)
static void C_fcall trf_9480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9480(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9480(t0,t1,t2);}

C_noret_decl(trf_9438)
static void C_fcall trf_9438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9438(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9438(t0,t1,t2);}

C_noret_decl(trf_9366)
static void C_fcall trf_9366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9366(t0,t1);}

C_noret_decl(trf_9289)
static void C_fcall trf_9289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9289(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9289(t0,t1,t2);}

C_noret_decl(trf_9203)
static void C_fcall trf_9203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9203(t0,t1);}

C_noret_decl(trf_9072)
static void C_fcall trf_9072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9072(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9072(t0,t1,t2,t3);}

C_noret_decl(trf_9088)
static void C_fcall trf_9088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9088(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9088(t0,t1,t2,t3);}

C_noret_decl(trf_9020)
static void C_fcall trf_9020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9020(t0,t1,t2);}

C_noret_decl(trf_8952)
static void C_fcall trf_8952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8952(t0,t1,t2,t3);}

C_noret_decl(trf_8968)
static void C_fcall trf_8968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8968(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8968(t0,t1,t2,t3);}

C_noret_decl(trf_8887)
static void C_fcall trf_8887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8887(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8887(t0,t1,t2,t3);}

C_noret_decl(trf_8903)
static void C_fcall trf_8903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8903(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8903(t0,t1,t2,t3);}

C_noret_decl(trf_8791)
static void C_fcall trf_8791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8791(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8791(t0,t1,t2,t3);}

C_noret_decl(trf_8807)
static void C_fcall trf_8807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8807(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8807(t0,t1,t2,t3);}

C_noret_decl(trf_8723)
static void C_fcall trf_8723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8723(t0,t1,t2);}

C_noret_decl(trf_8746)
static void C_fcall trf_8746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8746(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8746(t0,t1,t2);}

C_noret_decl(trf_8638)
static void C_fcall trf_8638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8638(t0,t1,t2);}

C_noret_decl(trf_8661)
static void C_fcall trf_8661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8661(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8661(t0,t1,t2);}

C_noret_decl(trf_8546)
static void C_fcall trf_8546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8546(t0,t1,t2);}

C_noret_decl(trf_8572)
static void C_fcall trf_8572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8572(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8572(t0,t1,t2,t3);}

C_noret_decl(trf_8598)
static void C_fcall trf_8598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8598(t0,t1);}

C_noret_decl(trf_8585)
static void C_fcall trf_8585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8585(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8585(t0,t1);}

C_noret_decl(trf_8472)
static void C_fcall trf_8472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8472(t0,t1,t2,t3);}

C_noret_decl(trf_8491)
static void C_fcall trf_8491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8491(t0,t1);}

C_noret_decl(trf_8417)
static void C_fcall trf_8417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8417(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8417(t0,t1,t2,t3);}

C_noret_decl(trf_8436)
static void C_fcall trf_8436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8436(t0,t1);}

C_noret_decl(trf_8358)
static void C_fcall trf_8358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8358(t0,t1);}

C_noret_decl(trf_8062)
static void C_fcall trf_8062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8062(t0,t1);}

C_noret_decl(trf_8188)
static void C_fcall trf_8188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8188(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8188(t0,t1,t2);}

C_noret_decl(trf_8125)
static void C_fcall trf_8125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8125(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8125(t0,t1,t2);}

C_noret_decl(trf_7755)
static void C_fcall trf_7755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7755(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7755(t0,t1,t2,t3);}

C_noret_decl(trf_7886)
static void C_fcall trf_7886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7886(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7886(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7730)
static void C_fcall trf_7730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7730(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7730(t0,t1,t2,t3);}

C_noret_decl(trf_7740)
static void C_fcall trf_7740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7740(t0,t1);}

C_noret_decl(trf_7632)
static void C_fcall trf_7632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7632(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7632(t0,t1,t2);}

C_noret_decl(trf_7674)
static void C_fcall trf_7674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7674(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7674(t0,t1,t2);}

C_noret_decl(trf_7551)
static void C_fcall trf_7551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7551(t0,t1);}

C_noret_decl(trf_7546)
static void C_fcall trf_7546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7546(t0,t1,t2);}

C_noret_decl(trf_7541)
static void C_fcall trf_7541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7541(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7541(t0,t1,t2,t3);}

C_noret_decl(trf_7529)
static void C_fcall trf_7529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7529(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7529(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7441)
static void C_fcall trf_7441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7441(t0,t1);}

C_noret_decl(trf_7455)
static void C_fcall trf_7455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7455(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7455(t0,t1,t2,t3);}

C_noret_decl(trf_7376)
static void C_fcall trf_7376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7376(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7376(t0,t1,t2,t3);}

C_noret_decl(trf_7280)
static void C_fcall trf_7280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7280(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7280(t0,t1,t2);}

C_noret_decl(trf_7321)
static void C_fcall trf_7321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7321(t0,t1);}

C_noret_decl(trf_7148)
static void C_fcall trf_7148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7148(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7148(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7080)
static void C_fcall trf_7080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7080(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7080(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7012)
static void C_fcall trf_7012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7012(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7012(t0,t1,t2,t3);}

C_noret_decl(trf_6964)
static void C_fcall trf_6964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6964(t0,t1,t2);}

C_noret_decl(trf_6610)
static void C_fcall trf_6610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6610(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6610(t0,t1,t2,t3);}

C_noret_decl(trf_6648)
static void C_fcall trf_6648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6648(t0,t1);}

C_noret_decl(trf_6629)
static void C_fcall trf_6629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6629(t0,t1);}

C_noret_decl(trf_6503)
static void C_fcall trf_6503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6503(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6503(t0,t1,t2,t3);}

C_noret_decl(trf_6378)
static void C_fcall trf_6378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6378(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6378(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6411)
static void C_fcall trf_6411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6411(t0,t1,t2);}

C_noret_decl(trf_6450)
static void C_fcall trf_6450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6450(t0,t1);}

C_noret_decl(trf_6396)
static void C_fcall trf_6396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6396(t0,t1);}

C_noret_decl(trf_6221)
static void C_fcall trf_6221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6221(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6221(t0,t1,t2,t3);}

C_noret_decl(trf_6167)
static void C_fcall trf_6167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6167(t0,t1);}

C_noret_decl(trf_6067)
static void C_fcall trf_6067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6067(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6067(t0,t1,t2,t3);}

C_noret_decl(trf_5955)
static void C_fcall trf_5955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5955(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5955(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5982)
static void C_fcall trf_5982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5982(t0,t1,t2);}

C_noret_decl(trf_5935)
static void C_fcall trf_5935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5935(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5935(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5942)
static void C_fcall trf_5942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5942(t0,t1);}

C_noret_decl(trf_5851)
static void C_fcall trf_5851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5851(t0,t1);}

C_noret_decl(trf_5846)
static void C_fcall trf_5846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5846(t0,t1,t2);}

C_noret_decl(trf_5841)
static void C_fcall trf_5841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5841(t0,t1,t2,t3);}

C_noret_decl(trf_5836)
static void C_fcall trf_5836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5836(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5836(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5807)
static void C_fcall trf_5807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5807(t0,t1);}

C_noret_decl(trf_5734)
static void C_fcall trf_5734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5734(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5734(t0,t1);}

C_noret_decl(trf_5729)
static void C_fcall trf_5729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5729(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5729(t0,t1,t2);}

C_noret_decl(trf_5724)
static void C_fcall trf_5724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5724(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5724(t0,t1,t2,t3);}

C_noret_decl(trf_5719)
static void C_fcall trf_5719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5719(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5719(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5690)
static void C_fcall trf_5690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5690(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5690(t0,t1);}

C_noret_decl(trf_5497)
static void C_fcall trf_5497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5497(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5497(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5518)
static void C_fcall trf_5518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5518(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5518(t0,t1,t2,t3);}

C_noret_decl(trf_5335)
static void C_fcall trf_5335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5335(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5335(t0,t1,t2,t3);}

C_noret_decl(trf_5360)
static void C_fcall trf_5360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5360(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5360(t0,t1,t2,t3);}

C_noret_decl(trf_4676)
static void C_fcall trf_4676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4676(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4676(t0,t1,t2,t3);}

C_noret_decl(trf_5231)
static void C_fcall trf_5231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5231(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5231(t0,t1,t2);}

C_noret_decl(trf_5241)
static void C_fcall trf_5241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5241(t0,t1);}

C_noret_decl(trf_5201)
static void C_fcall trf_5201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5201(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5201(t0,t1);}

C_noret_decl(trf_5010)
static void C_fcall trf_5010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5010(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_5010(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_5013)
static void C_fcall trf_5013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5013(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5013(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5054)
static void C_fcall trf_5054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5054(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5054(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5095)
static void C_fcall trf_5095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5095(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5095(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4933)
static void C_fcall trf_4933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4933(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4933(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4939)
static void C_fcall trf_4939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4939(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4939(t0,t1,t2,t3);}

C_noret_decl(trf_4924)
static void C_fcall trf_4924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4924(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4924(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4896)
static void C_fcall trf_4896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4896(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4896(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4744)
static void C_fcall trf_4744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4744(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4744(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4712(t0,t1,t2,t3);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4679(t0,t1,t2,t3);}

C_noret_decl(trf_4173)
static void C_fcall trf_4173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4173(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4173(t0,t1,t2,t3);}

C_noret_decl(trf_4412)
static void C_fcall trf_4412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4412(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4412(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4419)
static void C_fcall trf_4419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4419(t0,t1);}

C_noret_decl(trf_4176)
static void C_fcall trf_4176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4176(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4176(t0,t1,t2,t3);}

C_noret_decl(trf_4203)
static void C_fcall trf_4203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4203(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4203(t0,t1,t2,t3);}

C_noret_decl(trf_4223)
static void C_fcall trf_4223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4223(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4223(t0,t1,t2,t3);}

C_noret_decl(trf_4154)
static void C_fcall trf_4154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4154(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4154(t0,t1,t2,t3);}

C_noret_decl(trf_4063)
static void C_fcall trf_4063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4063(t0,t1);}

C_noret_decl(trf_4095)
static void C_fcall trf_4095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4095(t0,t1);}

C_noret_decl(trf_3939)
static void C_fcall trf_3939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3939(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3939(t0,t1);}

C_noret_decl(trf_3934)
static void C_fcall trf_3934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3934(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3934(t0,t1,t2);}

C_noret_decl(trf_3929)
static void C_fcall trf_3929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3929(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3929(t0,t1,t2,t3);}

C_noret_decl(trf_3858)
static void C_fcall trf_3858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3858(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3858(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3530)
static void C_fcall trf_3530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3530(t0,t1);}

C_noret_decl(trf_3525)
static void C_fcall trf_3525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3525(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3525(t0,t1,t2);}

C_noret_decl(trf_3494)
static void C_fcall trf_3494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3494(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3494(t0,t1,t2,t3);}

C_noret_decl(trf_3511)
static void C_fcall trf_3511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3511(t0,t1);}

C_noret_decl(trf_3435)
static void C_fcall trf_3435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3435(t0,t1);}

C_noret_decl(trf_3372)
static void C_fcall trf_3372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3372(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3372(t0,t1);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3367(t0,t1,t2);}

C_noret_decl(trf_3362)
static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3362(t0,t1,t2);}

C_noret_decl(trf_3320)
static void C_fcall trf_3320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3320(t0,t1,t2);}

C_noret_decl(trf_3239)
static void C_fcall trf_3239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3239(t0,t1);}

C_noret_decl(trf_3234)
static void C_fcall trf_3234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3234(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3234(t0,t1,t2);}

C_noret_decl(trf_3192)
static void C_fcall trf_3192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3192(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3192(t0,t1,t2,t3);}

C_noret_decl(trf_3202)
static void C_fcall trf_3202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3202(t0,t1);}

C_noret_decl(trf_3110)
static void C_fcall trf_3110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3110(t0,t1);}

C_noret_decl(trf_3118)
static void C_fcall trf_3118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3118(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3118(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3032)
static void C_fcall trf_3032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3032(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3032(t0,t1,t2,t3);}

C_noret_decl(trf_2880)
static void C_fcall trf_2880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2880(t0,t1);}

C_noret_decl(trf_2903)
static void C_fcall trf_2903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2903(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2903(t0,t1,t2);}

C_noret_decl(trf_2967)
static void C_fcall trf_2967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2967(t0,t1);}

C_noret_decl(trf_2832)
static void C_fcall trf_2832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2832(t0,t1);}

C_noret_decl(trf_2777)
static void C_fcall trf_2777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2777(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2777(t0,t1,t2);}

C_noret_decl(trf_2717)
static void C_fcall trf_2717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2717(t0,t1);}

C_noret_decl(trf_2712)
static void C_fcall trf_2712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2712(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2712(t0,t1,t2);}

C_noret_decl(trf_2643)
static void C_fcall trf_2643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2643(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2643(t0,t1,t2,t3);}

C_noret_decl(trf_2678)
static void C_fcall trf_2678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2678(t0,t1,t2);}

C_noret_decl(trf_2647)
static void C_fcall trf_2647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2647(t0,t1);}

C_noret_decl(trf_2600)
static void C_fcall trf_2600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2600(t0,t1,t2);}

C_noret_decl(trf_2562)
static void C_fcall trf_2562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2562(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2562(t0,t1);}

C_noret_decl(trf_2443)
static void C_fcall trf_2443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2443(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2443(t0,t1,t2,t3);}

C_noret_decl(trf_2387)
static void C_fcall trf_2387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2387(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2387(t0,t1,t2);}

C_noret_decl(trf_2305)
static void C_fcall trf_2305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2305(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2305(t0,t1,t2,t3);}

C_noret_decl(trf_2326)
static void C_fcall trf_2326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2326(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2326(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2255)
static void C_fcall trf_2255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2255(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2255(t0,t1,t2,t3);}

C_noret_decl(trf_2226)
static void C_fcall trf_2226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2226(t0,t1,t2);}

C_noret_decl(trf_2190)
static void C_fcall trf_2190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2190(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2190(t0,t1,t2);}

C_noret_decl(trf_2122)
static void C_fcall trf_2122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2122(t0,t1,t2);}

C_noret_decl(trf_2056)
static void C_fcall trf_2056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2056(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2056(t0,t1,t2);}

C_noret_decl(trf_2021)
static void C_fcall trf_2021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2021(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2021(t0,t1,t2);}

C_noret_decl(trf_1901)
static void C_fcall trf_1901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1901(t0,t1,t2);}

C_noret_decl(trf_1868)
static void C_fcall trf_1868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1868(t0,t1,t2);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1786(t0,t1);}

C_noret_decl(trf_1781)
static void C_fcall trf_1781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1781(t0,t1,t2);}

C_noret_decl(trf_1776)
static void C_fcall trf_1776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1776(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1776(t0,t1,t2,t3);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1716(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1729)
static void C_fcall trf_1729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1729(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1729(t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2233)){
C_save(t1);
C_rereclaim2(2233*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,596);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],4,"read");
lf[4]=C_h_intern(&lf[4],7,"reverse");
lf[5]=C_h_intern(&lf[5],20,"call-with-input-file");
lf[6]=C_h_intern(&lf[6],9,"read-file");
lf[7]=C_static_lambda_info(C_heaptop,19,"(do21 x23 i24 xs25)");
lf[8]=C_static_lambda_info(C_heaptop,14,"(slurp port20)");
lf[9]=C_h_intern(&lf[9],5,"port\077");
lf[10]=C_static_lambda_info(C_heaptop,29,"(body9 port16 reader17 max18)");
lf[11]=C_static_lambda_info(C_heaptop,31,"(def-max13 %port631 %reader732)");
lf[12]=C_static_lambda_info(C_heaptop,23,"(def-reader12 %port634)");
lf[13]=C_h_intern(&lf[13],18,"\003sysstandard-input");
lf[14]=C_static_lambda_info(C_heaptop,12,"(def-port11)");
lf[15]=C_h_intern(&lf[15],9,"\003syserror");
lf[16]=C_static_lambda_info(C_heaptop,17,"(read-file . g45)");
lf[17]=C_h_intern(&lf[17],8,"identity");
lf[18]=C_static_lambda_info(C_heaptop,14,"(identity x43)");
lf[19]=C_h_intern(&lf[19],7,"project");
lf[20]=C_static_lambda_info(C_heaptop,17,"(f_1854 . args45)");
lf[21]=C_static_lambda_info(C_heaptop,13,"(project n44)");
lf[22]=C_h_intern(&lf[22],7,"conjoin");
lf[23]=C_static_lambda_info(C_heaptop,14,"(loop preds49)");
lf[24]=C_static_lambda_info(C_heaptop,12,"(f_1862 x47)");
lf[25]=C_static_lambda_info(C_heaptop,19,"(conjoin . preds46)");
lf[26]=C_h_intern(&lf[26],7,"disjoin");
lf[27]=C_static_lambda_info(C_heaptop,14,"(loop preds56)");
lf[28]=C_static_lambda_info(C_heaptop,12,"(f_1895 x54)");
lf[29]=C_static_lambda_info(C_heaptop,19,"(disjoin . preds53)");
lf[30]=C_h_intern(&lf[30],10,"constantly");
lf[31]=C_static_lambda_info(C_heaptop,14,"(f_1941 . _62)");
lf[32]=C_static_lambda_info(C_heaptop,14,"(f_1943 . _63)");
lf[33]=C_static_lambda_info(C_heaptop,19,"(constantly . xs60)");
lf[34]=C_h_intern(&lf[34],4,"flip");
lf[35]=C_static_lambda_info(C_heaptop,16,"(f_1955 x65 y66)");
lf[36]=C_static_lambda_info(C_heaptop,13,"(flip proc64)");
lf[37]=C_h_intern(&lf[37],10,"complement");
lf[38]=C_static_lambda_info(C_heaptop,17,"(f_1963 . args68)");
lf[39]=C_static_lambda_info(C_heaptop,16,"(complement p67)");
lf[40]=C_h_intern(&lf[40],7,"compose");
lf[41]=C_static_lambda_info(C_heaptop,7,"(a1989)");
lf[42]=C_static_lambda_info(C_heaptop,17,"(f_1984 . args73)");
lf[43]=C_static_lambda_info(C_heaptop,18,"(rec f071 . fns72)");
lf[44]=C_h_intern(&lf[44],6,"values");
lf[45]=C_static_lambda_info(C_heaptop,17,"(compose . fns69)");
lf[46]=C_h_intern(&lf[46],1,"o");
lf[47]=C_static_lambda_info(C_heaptop,12,"(f_2035 x80)");
lf[48]=C_static_lambda_info(C_heaptop,12,"(loop fns77)");
lf[49]=C_static_lambda_info(C_heaptop,11,"(o . fns75)");
lf[50]=C_h_intern(&lf[50],7,"list-of");
lf[51]=C_static_lambda_info(C_heaptop,12,"(loop lst85)");
lf[52]=C_static_lambda_info(C_heaptop,14,"(f_2050 lst83)");
lf[53]=C_static_lambda_info(C_heaptop,16,"(list-of pred82)");
lf[54]=C_h_intern(&lf[54],4,"noop");
lf[55]=C_static_lambda_info(C_heaptop,12,"(noop . _87)");
lf[56]=C_h_intern(&lf[56],4,"each");
lf[57]=C_static_lambda_info(C_heaptop,14,"(f_2102 . _89)");
lf[58]=C_static_lambda_info(C_heaptop,14,"(loop procs92)");
lf[59]=C_static_lambda_info(C_heaptop,17,"(f_2116 . args90)");
lf[60]=C_static_lambda_info(C_heaptop,16,"(each . procs88)");
lf[61]=C_h_intern(&lf[61],4,"any\077");
lf[62]=C_static_lambda_info(C_heaptop,10,"(any\077 x97)");
lf[63]=C_h_intern(&lf[63],5,"atom\077");
lf[64]=C_static_lambda_info(C_heaptop,11,"(atom\077 x98)");
lf[65]=C_h_intern(&lf[65],5,"tail\077");
lf[66]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[67]=C_static_lambda_info(C_heaptop,16,"(tail\077 x99 y100)");
lf[68]=C_h_intern(&lf[68],11,"intersperse");
lf[69]=C_static_lambda_info(C_heaptop,12,"(loop ns110)");
lf[70]=C_static_lambda_info(C_heaptop,25,"(intersperse lst107 x108)");
lf[71]=C_h_intern(&lf[71],7,"butlast");
lf[72]=C_static_lambda_info(C_heaptop,13,"(loop lst115)");
lf[73]=C_static_lambda_info(C_heaptop,16,"(butlast lst113)");
lf[74]=C_h_intern(&lf[74],7,"flatten");
lf[75]=C_static_lambda_info(C_heaptop,23,"(loop lists121 rest122)");
lf[76]=C_static_lambda_info(C_heaptop,21,"(flatten . lists0119)");
lf[77]=C_h_intern(&lf[77],4,"chop");
lf[78]=C_static_lambda_info(C_heaptop,24,"(do133 hd135 tl136 c137)");
lf[79]=C_static_lambda_info(C_heaptop,18,"(loop lst131 i132)");
lf[80]=C_static_string(C_heaptop,24,"invalid numeric argument");
lf[81]=C_static_lambda_info(C_heaptop,18,"(chop lst127 n128)");
lf[82]=C_h_intern(&lf[82],4,"join");
lf[83]=C_h_intern(&lf[83],10,"\003sysappend");
lf[84]=C_h_intern(&lf[84],27,"\003sysnot-a-proper-list-error");
lf[85]=C_static_lambda_info(C_heaptop,14,"(loop lsts146)");
lf[86]=C_static_lambda_info(C_heaptop,23,"(join lsts142 . lst143)");
lf[87]=C_h_intern(&lf[87],8,"compress");
lf[88]=C_static_string(C_heaptop,37,"bad argument type - not a proper list");
lf[89]=C_h_intern(&lf[89],15,"\003syssignal-hook");
lf[90]=C_h_intern(&lf[90],11,"\000type-error");
lf[91]=C_static_lambda_info(C_heaptop,21,"(loop blst155 lst156)");
lf[92]=C_static_lambda_info(C_heaptop,25,"(compress blst151 lst152)");
lf[93]=C_h_intern(&lf[93],7,"shuffle");
lf[94]=C_h_intern(&lf[94],7,"\003sysmap");
lf[95]=C_h_intern(&lf[95],3,"cdr");
lf[96]=C_static_lambda_info(C_heaptop,17,"(a2530 x162 y163)");
lf[97]=C_h_intern(&lf[97],5,"sort!");
lf[98]=C_h_intern(&lf[98],6,"random");
lf[99]=C_static_lambda_info(C_heaptop,12,"(a2544 x161)");
lf[100]=C_static_lambda_info(C_heaptop,14,"(shuffle l159)");
lf[101]=C_h_intern(&lf[101],13,"alist-update!");
lf[102]=C_h_intern(&lf[102],4,"eqv\077");
lf[103]=C_h_intern(&lf[103],3,"eq\077");
lf[104]=C_h_intern(&lf[104],4,"assq");
lf[105]=C_h_intern(&lf[105],4,"assv");
lf[106]=C_h_intern(&lf[106],6,"equal\077");
lf[107]=C_h_intern(&lf[107],5,"assoc");
lf[108]=C_static_lambda_info(C_heaptop,13,"(loop lst173)");
lf[109]=C_static_lambda_info(C_heaptop,20,"(f_2594 x170 lst171)");
lf[110]=C_static_lambda_info(C_heaptop,41,"(alist-update! x164 y165 lst166 . cmp167)");
lf[111]=C_h_intern(&lf[111],9,"alist-ref");
lf[112]=C_static_lambda_info(C_heaptop,13,"(loop lst196)");
lf[113]=C_static_lambda_info(C_heaptop,20,"(f_2672 x193 lst194)");
lf[114]=C_static_lambda_info(C_heaptop,27,"(body184 cmp190 default191)");
lf[115]=C_static_lambda_info(C_heaptop,27,"(def-default187 %cmp182201)");
lf[116]=C_static_lambda_info(C_heaptop,12,"(def-cmp186)");
lf[117]=C_static_lambda_info(C_heaptop,33,"(alist-ref x179 lst180 . g178181)");
lf[118]=C_h_intern(&lf[118],6,"rassoc");
lf[119]=C_static_lambda_info(C_heaptop,11,"(loop l212)");
lf[120]=C_static_lambda_info(C_heaptop,29,"(rassoc x207 lst208 . tst209)");
lf[121]=C_static_lambda_info(C_heaptop,13,"(random n217)");
lf[122]=C_h_intern(&lf[122],9,"randomize");
lf[123]=C_static_lambda_info(C_heaptop,18,"(randomize . n219)");
lf[124]=C_h_intern(&lf[124],11,"make-string");
lf[125]=C_h_intern(&lf[125],9,"read-line");
lf[126]=C_h_intern(&lf[126],13,"\003syssubstring");
lf[127]=C_h_intern(&lf[127],15,"\003sysread-char-0");
lf[128]=C_h_intern(&lf[128],9,"peek-char");
lf[129]=C_h_intern(&lf[129],17,"\003sysstring-append");
lf[130]=C_static_lambda_info(C_heaptop,11,"(loop i236)");
lf[131]=C_h_intern(&lf[131],15,"\003sysmake-string");
lf[132]=C_h_intern(&lf[132],14,"\003syscheck-port");
lf[133]=C_static_lambda_info(C_heaptop,21,"(read-line . args226)");
lf[134]=C_h_intern(&lf[134],10,"read-lines");
lf[135]=C_static_lambda_info(C_heaptop,18,"(loop lns258 n259)");
lf[136]=C_static_lambda_info(C_heaptop,16,"(doread port256)");
lf[137]=C_static_lambda_info(C_heaptop,30,"(read-lines . port-and-max251)");
lf[138]=C_h_intern(&lf[138],16,"\003sysread-string!");
lf[139]=C_static_lambda_info(C_heaptop,25,"(loop start273 n274 m275)");
lf[140]=C_static_lambda_info(C_heaptop,50,"(##sys#read-string! n266 dest267 port268 start269)");
lf[141]=C_h_intern(&lf[141],12,"read-string!");
lf[142]=C_static_lambda_info(C_heaptop,26,"(body289 port295 start296)");
lf[143]=C_static_lambda_info(C_heaptop,26,"(def-start292 %port287303)");
lf[144]=C_static_lambda_info(C_heaptop,13,"(def-port291)");
lf[145]=C_static_lambda_info(C_heaptop,37,"(read-string! n284 dest285 . g283286)");
lf[146]=C_h_intern(&lf[146],18,"open-output-string");
lf[147]=C_h_intern(&lf[147],17,"get-output-string");
lf[148]=C_h_intern(&lf[148],20,"\003sysread-string/port");
lf[149]=C_h_intern(&lf[149],11,"read-string");
lf[150]=C_h_intern(&lf[150],19,"\003syswrite-char/port");
lf[151]=C_static_lambda_info(C_heaptop,11,"(loop n318)");
lf[152]=C_static_lambda_info(C_heaptop,34,"(##sys#read-string/port n311 p312)");
lf[153]=C_static_lambda_info(C_heaptop,22,"(body329 n335 port336)");
lf[154]=C_static_lambda_info(C_heaptop,22,"(def-port332 %n327338)");
lf[155]=C_static_lambda_info(C_heaptop,10,"(def-n331)");
lf[156]=C_static_lambda_info(C_heaptop,23,"(read-string . g325326)");
lf[157]=C_h_intern(&lf[157],10,"read-token");
lf[158]=C_h_intern(&lf[158],16,"\003syswrite-char-0");
lf[159]=C_h_intern(&lf[159],15,"\003syspeek-char-0");
lf[160]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[161]=C_static_lambda_info(C_heaptop,30,"(read-token pred346 . port347)");
lf[162]=C_h_intern(&lf[162],7,"display");
lf[163]=C_h_intern(&lf[163],12,"write-string");
lf[164]=C_static_lambda_info(C_heaptop,22,"(body362 n368 port369)");
lf[165]=C_h_intern(&lf[165],19,"\003sysstandard-output");
lf[166]=C_static_lambda_info(C_heaptop,22,"(def-port365 %n360373)");
lf[167]=C_static_lambda_info(C_heaptop,10,"(def-n364)");
lf[168]=C_static_lambda_info(C_heaptop,29,"(write-string s358 . more359)");
lf[169]=C_h_intern(&lf[169],7,"newline");
lf[170]=C_h_intern(&lf[170],10,"write-line");
lf[171]=C_static_lambda_info(C_heaptop,29,"(write-line str382 . port383)");
lf[172]=C_h_intern(&lf[172],9,"read-byte");
lf[173]=C_static_lambda_info(C_heaptop,21,"(read-byte . g388389)");
lf[174]=C_h_intern(&lf[174],10,"write-byte");
lf[175]=C_static_lambda_info(C_heaptop,30,"(write-byte byte396 . g395397)");
lf[176]=C_h_intern(&lf[176],20,"with-input-from-port");
lf[177]=C_static_lambda_info(C_heaptop,7,"(a3685)");
lf[178]=C_static_lambda_info(C_heaptop,7,"(a3693)");
lf[179]=C_static_lambda_info(C_heaptop,7,"(a3699)");
lf[180]=C_h_intern(&lf[180],16,"\003sysdynamic-wind");
lf[181]=C_static_lambda_info(C_heaptop,39,"(with-input-from-port port403 thunk404)");
lf[182]=C_h_intern(&lf[182],19,"with-output-to-port");
lf[183]=C_static_lambda_info(C_heaptop,7,"(a3716)");
lf[184]=C_static_lambda_info(C_heaptop,7,"(a3724)");
lf[185]=C_static_lambda_info(C_heaptop,7,"(a3730)");
lf[186]=C_h_intern(&lf[186],21,"with-output-from-port");
lf[187]=C_static_lambda_info(C_heaptop,38,"(with-output-to-port port414 thunk415)");
lf[188]=C_h_intern(&lf[188],25,"with-error-output-to-port");
lf[189]=C_h_intern(&lf[189],18,"\003sysstandard-error");
lf[190]=C_static_lambda_info(C_heaptop,7,"(a3747)");
lf[191]=C_static_lambda_info(C_heaptop,7,"(a3755)");
lf[192]=C_static_lambda_info(C_heaptop,7,"(a3761)");
lf[193]=C_h_intern(&lf[193],27,"with-error-output-from-port");
lf[194]=C_static_lambda_info(C_heaptop,44,"(with-error-output-to-port port425 thunk426)");
lf[195]=C_h_intern(&lf[195],17,"open-input-string");
lf[196]=C_h_intern(&lf[196],22,"call-with-input-string");
lf[197]=C_static_lambda_info(C_heaptop,39,"(call-with-input-string str437 proc438)");
lf[198]=C_h_intern(&lf[198],23,"call-with-output-string");
lf[199]=C_static_lambda_info(C_heaptop,33,"(call-with-output-string proc442)");
lf[200]=C_h_intern(&lf[200],22,"with-input-from-string");
lf[201]=C_static_lambda_info(C_heaptop,7,"(a3799)");
lf[202]=C_static_lambda_info(C_heaptop,7,"(a3807)");
lf[203]=C_static_lambda_info(C_heaptop,7,"(a3813)");
lf[204]=C_static_lambda_info(C_heaptop,40,"(with-input-from-string str446 thunk447)");
lf[205]=C_h_intern(&lf[205],21,"with-output-to-string");
lf[206]=C_static_lambda_info(C_heaptop,7,"(a3830)");
lf[207]=C_static_lambda_info(C_heaptop,7,"(a3838)");
lf[208]=C_static_lambda_info(C_heaptop,7,"(a3847)");
lf[209]=C_static_lambda_info(C_heaptop,32,"(with-output-to-string thunk458)");
lf[210]=C_h_intern(&lf[210],15,"make-input-port");
lf[211]=C_static_lambda_info(C_heaptop,12,"(a3872 p487)");
lf[212]=C_static_lambda_info(C_heaptop,12,"(a3893 p490)");
lf[213]=C_static_lambda_info(C_heaptop,12,"(a3914 p494)");
lf[214]=C_static_lambda_info(C_heaptop,12,"(a3923 p496)");
lf[215]=C_h_intern(&lf[215],13,"\003sysmake-port");
lf[216]=C_static_string(C_heaptop,8,"(custom)");
lf[217]=C_h_intern(&lf[217],6,"custom");
lf[218]=C_static_lambda_info(C_heaptop,45,"(body476 peek483 read-string484 read-line485)");
lf[219]=C_static_lambda_info(C_heaptop,49,"(def-read-line480 %peek473501 %read-string474502)");
lf[220]=C_static_lambda_info(C_heaptop,32,"(def-read-string479 %peek473504)");
lf[221]=C_static_lambda_info(C_heaptop,13,"(def-peek478)");
lf[222]=C_static_lambda_info(C_heaptop,54,"(make-input-port read469 ready\077470 close471 . g468472)");
lf[223]=C_h_intern(&lf[223],6,"string");
lf[224]=C_h_intern(&lf[224],16,"make-output-port");
lf[225]=C_static_lambda_info(C_heaptop,17,"(a4019 p518 c519)");
lf[226]=C_static_lambda_info(C_heaptop,17,"(a4029 p520 s521)");
lf[227]=C_static_lambda_info(C_heaptop,12,"(a4035 p522)");
lf[228]=C_static_lambda_info(C_heaptop,12,"(a4044 p524)");
lf[229]=C_static_string(C_heaptop,8,"(custom)");
lf[230]=C_static_lambda_info(C_heaptop,47,"(make-output-port write513 close514 . flush515)");
lf[231]=C_h_intern(&lf[231],20,"\006extrasgeneric-write");
lf[232]=C_h_intern(&lf[232],5,"quote");
lf[233]=C_h_intern(&lf[233],10,"quasiquote");
lf[234]=C_h_intern(&lf[234],7,"unquote");
lf[235]=C_h_intern(&lf[235],16,"unquote-splicing");
lf[236]=C_static_lambda_info(C_heaptop,18,"(read-macro\077 l540)");
lf[237]=C_static_lambda_info(C_heaptop,17,"(read-macro-body)");
lf[238]=C_static_string(C_heaptop,1,"\047");
lf[239]=C_static_string(C_heaptop,1,"`");
lf[240]=C_static_string(C_heaptop,1,",");
lf[241]=C_static_string(C_heaptop,2,",@");
lf[242]=C_static_lambda_info(C_heaptop,19,"(read-macro-prefix)");
lf[243]=C_static_lambda_info(C_heaptop,19,"(out str560 col561)");
lf[244]=C_static_string(C_heaptop,1," ");
lf[245]=C_static_string(C_heaptop,1,")");
lf[246]=C_static_string(C_heaptop,1,")");
lf[247]=C_static_string(C_heaptop,3," . ");
lf[248]=C_static_lambda_info(C_heaptop,18,"(loop l571 col572)");
lf[249]=C_static_string(C_heaptop,1,"(");
lf[250]=C_static_string(C_heaptop,2,"()");
lf[251]=C_static_lambda_info(C_heaptop,20,"(wr-lst l568 col569)");
lf[252]=C_static_lambda_info(C_heaptop,24,"(wr-expr expr566 col567)");
lf[253]=C_static_string(C_heaptop,6,"#<eof>");
lf[254]=C_static_string(C_heaptop,1,"#");
lf[255]=C_h_intern(&lf[255],12,"vector->list");
lf[256]=C_static_string(C_heaptop,2,"#t");
lf[257]=C_static_string(C_heaptop,2,"#f");
lf[258]=C_h_intern(&lf[258],18,"\003sysnumber->string");
lf[259]=C_h_intern(&lf[259],9,"\003sysprint");
lf[260]=C_h_intern(&lf[260],21,"\003sysprocedure->string");
lf[261]=C_static_string(C_heaptop,1,"\134");
lf[262]=C_static_string(C_heaptop,1,"\042");
lf[263]=C_static_lambda_info(C_heaptop,23,"(loop i577 j578 col579)");
lf[264]=C_static_string(C_heaptop,1,"\042");
lf[265]=C_static_string(C_heaptop,1,"x");
lf[266]=C_static_string(C_heaptop,1,"U");
lf[267]=C_static_string(C_heaptop,1,"u");
lf[268]=C_h_intern(&lf[268],9,"char-name");
lf[269]=C_static_string(C_heaptop,2,"#\134");
lf[270]=C_static_string(C_heaptop,6,"#<eof>");
lf[271]=C_static_string(C_heaptop,14,"#<unspecified>");
lf[272]=C_h_intern(&lf[272],19,"\003syspointer->string");
lf[273]=C_h_intern(&lf[273],28,"\003sysarbitrary-unbound-symbol");
lf[274]=C_static_string(C_heaptop,16,"#<unbound value>");
lf[275]=C_h_intern(&lf[275],19,"\003sysuser-print-hook");
lf[276]=C_h_intern(&lf[276],13,"string-append");
lf[277]=C_static_string(C_heaptop,7,"#<port ");
lf[278]=C_static_string(C_heaptop,1,">");
lf[279]=C_static_string(C_heaptop,1,">");
lf[280]=C_static_string(C_heaptop,21,"#<static blob of size");
lf[281]=C_static_string(C_heaptop,15,"#<blob of size ");
lf[282]=C_static_string(C_heaptop,2,"#>");
lf[283]=C_h_intern(&lf[283],23,"\003syslambda-info->string");
lf[284]=C_static_string(C_heaptop,14,"#<lambda info ");
lf[285]=C_static_string(C_heaptop,21,"#<unprintable object>");
lf[286]=C_h_intern(&lf[286],11,"\003sysnumber\077");
lf[287]=C_static_lambda_info(C_heaptop,18,"(wr obj562 col563)");
lf[288]=C_static_string(C_heaptop,8,"        ");
lf[289]=C_static_string(C_heaptop,8,"        ");
lf[290]=C_static_lambda_info(C_heaptop,20,"(spaces n622 col623)");
lf[291]=C_static_lambda_info(C_heaptop,21,"(indent to624 col625)");
lf[292]=C_h_intern(&lf[292],28,"\006extrasreverse-string-append");
lf[293]=C_static_string(C_heaptop,1,"#");
lf[294]=C_static_lambda_info(C_heaptop,14,"(a4794 str634)");
lf[295]=C_h_intern(&lf[295],3,"max");
lf[296]=C_static_lambda_info(C_heaptop,38,"(pr obj626 col627 extra628 pp-pair629)");
lf[297]=C_h_intern(&lf[297],28,"\003syssymbol->qualified-string");
lf[298]=C_static_lambda_info(C_heaptop,33,"(pp-expr expr638 col639 extra640)");
lf[299]=C_static_string(C_heaptop,1,"(");
lf[300]=C_static_lambda_info(C_heaptop,44,"(pp-call expr643 col644 extra645 pp-item646)");
lf[301]=C_static_string(C_heaptop,1,"(");
lf[302]=C_static_lambda_info(C_heaptop,41,"(pp-list l648 col649 extra650 pp-item651)");
lf[303]=C_static_string(C_heaptop,1,")");
lf[304]=C_static_string(C_heaptop,1,")");
lf[305]=C_static_string(C_heaptop,1,".");
lf[306]=C_static_lambda_info(C_heaptop,18,"(loop l659 col660)");
lf[307]=C_static_lambda_info(C_heaptop,50,"(pp-down l653 col1654 col2655 extra656 pp-item657)");
lf[308]=C_static_lambda_info(C_heaptop,31,"(tail3 rest688 col1689 col2690)");
lf[309]=C_static_lambda_info(C_heaptop,39,"(tail2 rest681 col1682 col2683 col3684)");
lf[310]=C_static_lambda_info(C_heaptop,39,"(tail1 rest674 col1675 col2676 col3677)");
lf[311]=C_static_string(C_heaptop,1," ");
lf[312]=C_static_string(C_heaptop,1,"(");
lf[313]=C_static_lambda_info(C_heaptop,70,"(pp-general expr664 col665 extra666 named\077667 pp-1668 pp-2669 pp-3670)");
lf[314]=C_static_lambda_info(C_heaptop,35,"(pp-expr-list l700 col701 extra702)");
lf[315]=C_static_lambda_info(C_heaptop,35,"(pp-lambda expr703 col704 extra705)");
lf[316]=C_static_lambda_info(C_heaptop,31,"(pp-if expr706 col707 extra708)");
lf[317]=C_static_lambda_info(C_heaptop,33,"(pp-cond expr709 col710 extra711)");
lf[318]=C_static_lambda_info(C_heaptop,33,"(pp-case expr712 col713 extra714)");
lf[319]=C_static_lambda_info(C_heaptop,32,"(pp-and expr715 col716 extra717)");
lf[320]=C_static_lambda_info(C_heaptop,32,"(pp-let expr718 col719 extra720)");
lf[321]=C_static_lambda_info(C_heaptop,34,"(pp-begin expr723 col724 extra725)");
lf[322]=C_static_lambda_info(C_heaptop,31,"(pp-do expr726 col727 extra728)");
lf[323]=C_h_intern(&lf[323],6,"lambda");
lf[324]=C_h_intern(&lf[324],2,"if");
lf[325]=C_h_intern(&lf[325],4,"set!");
lf[326]=C_h_intern(&lf[326],4,"cond");
lf[327]=C_h_intern(&lf[327],4,"case");
lf[328]=C_h_intern(&lf[328],3,"and");
lf[329]=C_h_intern(&lf[329],2,"or");
lf[330]=C_h_intern(&lf[330],3,"let");
lf[331]=C_h_intern(&lf[331],5,"begin");
lf[332]=C_h_intern(&lf[332],2,"do");
lf[333]=C_h_intern(&lf[333],4,"let*");
lf[334]=C_h_intern(&lf[334],6,"letrec");
lf[335]=C_h_intern(&lf[335],6,"define");
lf[336]=C_static_lambda_info(C_heaptop,15,"(style head729)");
lf[337]=C_static_lambda_info(C_heaptop,18,"(pp obj599 col600)");
lf[338]=C_static_lambda_info(C_heaptop,62,"(##extras#generic-write obj530 display\077531 width532 output533)");
lf[339]=C_static_lambda_info(C_heaptop,16,"(loop j777 k778)");
lf[340]=C_static_lambda_info(C_heaptop,29,"(rev-string-append l771 i772)");
lf[341]=C_static_lambda_info(C_heaptop,37,"(##extras#reverse-string-append l769)");
lf[342]=C_h_intern(&lf[342],18,"pretty-print-width");
lf[343]=C_h_intern(&lf[343],12,"pretty-print");
lf[344]=C_static_lambda_info(C_heaptop,12,"(a5425 s785)");
lf[345]=C_h_intern(&lf[345],19,"current-output-port");
lf[346]=C_static_lambda_info(C_heaptop,30,"(pretty-print obj782 . opt783)");
lf[347]=C_h_intern(&lf[347],2,"pp");
lf[348]=C_h_intern(&lf[348],8,"->string");
lf[349]=C_h_intern(&lf[349],14,"symbol->string");
lf[350]=C_static_lambda_info(C_heaptop,15,"(->string x792)");
lf[351]=C_h_intern(&lf[351],4,"conc");
lf[352]=C_static_lambda_info(C_heaptop,16,"(conc . args796)");
lf[353]=C_static_lambda_info(C_heaptop,24,"(loop istart806 iend807)");
lf[354]=C_static_lambda_info(C_heaptop,52,"(traverse which798 where799 start800 test801 loc802)");
lf[355]=C_h_intern(&lf[355],19,"\003syssubstring-index");
lf[356]=C_static_lambda_info(C_heaptop,17,"(a5549 i815 l816)");
lf[357]=C_h_intern(&lf[357],15,"substring-index");
lf[358]=C_static_lambda_info(C_heaptop,50,"(##sys#substring-index which812 where813 start814)");
lf[359]=C_h_intern(&lf[359],22,"\003syssubstring-index-ci");
lf[360]=C_static_lambda_info(C_heaptop,17,"(a5558 i820 l821)");
lf[361]=C_h_intern(&lf[361],18,"substring-index-ci");
lf[362]=C_static_lambda_info(C_heaptop,53,"(##sys#substring-index-ci which817 where818 start819)");
lf[363]=C_static_lambda_info(C_heaptop,45,"(substring-index which825 where826 . g824827)");
lf[364]=C_static_lambda_info(C_heaptop,48,"(substring-index-ci which832 where833 . g831834)");
lf[365]=C_h_intern(&lf[365],15,"string-compare3");
lf[366]=C_static_lambda_info(C_heaptop,29,"(string-compare3 s1838 s2839)");
lf[367]=C_h_intern(&lf[367],18,"string-compare3-ci");
lf[368]=C_static_lambda_info(C_heaptop,32,"(string-compare3-ci s1846 s2847)");
lf[369]=C_h_intern(&lf[369],15,"\003syssubstring=\077");
lf[370]=C_h_intern(&lf[370],11,"substring=\077");
lf[371]=C_static_lambda_info(C_heaptop,56,"(##sys#substring=\077 s1854 s2855 start1856 start2857 n858)");
lf[372]=C_static_lambda_info(C_heaptop,36,"(body873 start1880 start2881 len882)");
lf[373]=C_static_lambda_info(C_heaptop,40,"(def-len877 %start1870884 %start2871885)");
lf[374]=C_static_lambda_info(C_heaptop,29,"(def-start2876 %start1870887)");
lf[375]=C_static_lambda_info(C_heaptop,15,"(def-start1875)");
lf[376]=C_static_lambda_info(C_heaptop,35,"(substring=\077 s1867 s2868 . g866869)");
lf[377]=C_h_intern(&lf[377],18,"\003syssubstring-ci=\077");
lf[378]=C_h_intern(&lf[378],14,"substring-ci=\077");
lf[379]=C_static_lambda_info(C_heaptop,59,"(##sys#substring-ci=\077 s1895 s2896 start1897 start2898 n899)");
lf[380]=C_static_lambda_info(C_heaptop,36,"(body914 start1921 start2922 len923)");
lf[381]=C_static_lambda_info(C_heaptop,40,"(def-len918 %start1911925 %start2912926)");
lf[382]=C_static_lambda_info(C_heaptop,29,"(def-start2917 %start1911928)");
lf[383]=C_static_lambda_info(C_heaptop,15,"(def-start1916)");
lf[384]=C_static_lambda_info(C_heaptop,38,"(substring-ci=\077 s1908 s2909 . g907910)");
lf[385]=C_h_intern(&lf[385],12,"string-split");
lf[386]=C_static_string(C_heaptop,3,"\011\012 ");
lf[387]=C_static_lambda_info(C_heaptop,27,"(add from944 to945 last946)");
lf[388]=C_static_lambda_info(C_heaptop,11,"(scan j960)");
lf[389]=C_static_lambda_info(C_heaptop,27,"(loop i950 last951 from952)");
lf[390]=C_static_lambda_info(C_heaptop,42,"(string-split str936 . delstr-and-flag937)");
lf[391]=C_h_intern(&lf[391],18,"string-intersperse");
lf[392]=C_static_string(C_heaptop,0,"");
lf[393]=C_static_lambda_info(C_heaptop,13,"(loop2 n2982)");
lf[394]=C_h_intern(&lf[394],19,"\003sysallocate-vector");
lf[395]=C_static_lambda_info(C_heaptop,18,"(loop1 ss977 n978)");
lf[396]=C_static_string(C_heaptop,1," ");
lf[397]=C_static_lambda_info(C_heaptop,38,"(string-intersperse strs970 . g969971)");
lf[398]=C_h_intern(&lf[398],12,"list->string");
lf[399]=C_h_intern(&lf[399],16,"string-translate");
lf[400]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[401]=C_static_lambda_info(C_heaptop,14,"(f_6172 c1003)");
lf[402]=C_static_lambda_info(C_heaptop,16,"(instring s1001)");
lf[403]=C_static_string(C_heaptop,31,"invalid translation destination");
lf[404]=C_static_lambda_info(C_heaptop,18,"(loop i1017 j1018)");
lf[405]=C_static_lambda_info(C_heaptop,14,"(f_6341 c1008)");
lf[406]=C_static_lambda_info(C_heaptop,41,"(string-translate str997 from998 . to999)");
lf[407]=C_h_intern(&lf[407],17,"string-translate*");
lf[408]=C_h_intern(&lf[408],21,"\003sysfragments->string");
lf[409]=C_static_lambda_info(C_heaptop,15,"(loop smap1036)");
lf[410]=C_static_lambda_info(C_heaptop,41,"(collect i1031 from1032 total1033 fs1034)");
lf[411]=C_static_lambda_info(C_heaptop,36,"(string-translate* str1027 smap1028)");
lf[412]=C_h_intern(&lf[412],11,"string-chop");
lf[413]=C_static_lambda_info(C_heaptop,24,"(loop total1051 pos1052)");
lf[414]=C_static_lambda_info(C_heaptop,29,"(string-chop str1047 len1048)");
lf[415]=C_h_intern(&lf[415],12,"string-chomp");
lf[416]=C_static_string(C_heaptop,1,"\012");
lf[417]=C_static_lambda_info(C_heaptop,34,"(string-chomp str1057 . g10561058)");
lf[418]=C_h_intern(&lf[418],5,"write");
lf[419]=C_h_intern(&lf[419],7,"fprintf");
lf[420]=C_static_string(C_heaptop,47,"too few arguments to formatted output procedure");
lf[421]=C_static_lambda_info(C_heaptop,6,"(next)");
lf[422]=C_h_intern(&lf[422],16,"\003sysflush-output");
lf[423]=C_static_lambda_info(C_heaptop,6,"(skip)");
lf[424]=C_static_string(C_heaptop,31,"illegal format-string character");
lf[425]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[426]=C_static_lambda_info(C_heaptop,22,"(rec msg1074 args1075)");
lf[427]=C_static_lambda_info(C_heaptop,37,"(fprintf port1070 msg1071 . args1072)");
lf[428]=C_h_intern(&lf[428],6,"printf");
lf[429]=C_static_lambda_info(C_heaptop,27,"(printf msg1106 . args1107)");
lf[430]=C_h_intern(&lf[430],7,"sprintf");
lf[431]=C_static_lambda_info(C_heaptop,29,"(sprintf fstr1111 . args1112)");
lf[432]=C_h_intern(&lf[432],6,"format");
lf[433]=C_static_string(C_heaptop,19,"illegal destination");
lf[434]=C_h_intern(&lf[434],12,"output-port\077");
lf[435]=C_static_lambda_info(C_heaptop,34,"(format fmt-or-dst1118 . args1119)");
lf[436]=C_h_intern(&lf[436],7,"sorted\077");
lf[437]=C_static_lambda_info(C_heaptop,14,"(do1125 i1127)");
lf[438]=C_static_lambda_info(C_heaptop,24,"(loop last1132 next1133)");
lf[439]=C_static_lambda_info(C_heaptop,27,"(sorted\077 seq1122 less\0771123)");
lf[440]=C_h_intern(&lf[440],5,"merge");
lf[441]=C_static_lambda_info(C_heaptop,30,"(loop x1141 a1142 y1143 b1144)");
lf[442]=C_static_lambda_info(C_heaptop,29,"(merge a1137 b1138 less\0771139)");
lf[443]=C_h_intern(&lf[443],6,"merge!");
lf[444]=C_static_lambda_info(C_heaptop,24,"(loop r1150 a1151 b1152)");
lf[445]=C_static_lambda_info(C_heaptop,30,"(merge! a1146 b1147 less\0771148)");
lf[446]=C_static_lambda_info(C_heaptop,12,"(step n1161)");
lf[447]=C_static_lambda_info(C_heaptop,20,"(do1178 p1180 i1181)");
lf[448]=C_static_lambda_info(C_heaptop,25,"(sort! seq1158 less\0771159)");
lf[449]=C_h_intern(&lf[449],4,"sort");
lf[450]=C_h_intern(&lf[450],12,"list->vector");
lf[451]=C_h_intern(&lf[451],6,"append");
lf[452]=C_static_lambda_info(C_heaptop,24,"(sort seq1186 less\0771187)");
lf[453]=C_h_intern(&lf[453],13,"binary-search");
lf[454]=C_static_lambda_info(C_heaptop,20,"(loop ps1193 pe1194)");
lf[455]=C_static_lambda_info(C_heaptop,32,"(binary-search vec1189 proc1190)");
tmp=C_fix(307);
C_save(tmp);
tmp=C_fix(617);
C_save(tmp);
tmp=C_fix(1237);
C_save(tmp);
tmp=C_fix(2477);
C_save(tmp);
tmp=C_fix(4957);
C_save(tmp);
tmp=C_fix(9923);
C_save(tmp);
tmp=C_fix(19853);
C_save(tmp);
tmp=C_fix(39709);
C_save(tmp);
tmp=C_fix(79423);
C_save(tmp);
tmp=C_fix(158849);
C_save(tmp);
tmp=C_fix(317701);
C_save(tmp);
tmp=C_fix(635413);
C_save(tmp);
tmp=C_fix(1270849);
C_save(tmp);
tmp=C_fix(2541701);
C_save(tmp);
tmp=C_fix(5083423);
C_save(tmp);
tmp=C_fix(10166857);
C_save(tmp);
tmp=C_fix(20333759);
C_save(tmp);
tmp=C_fix(40667527);
C_save(tmp);
tmp=C_fix(81335063);
C_save(tmp);
tmp=C_fix(162670129);
C_save(tmp);
tmp=C_fix(325340273);
C_save(tmp);
tmp=C_fix(650680571);
C_save(tmp);
tmp=C_fix(1073741823);
C_save(tmp);
lf[457]=C_h_list(23,C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(23);
lf[458]=C_h_intern(&lf[458],11,"hash-table\077");
lf[459]=C_h_intern(&lf[459],10,"hash-table");
lf[460]=C_static_lambda_info(C_heaptop,19,"(hash-table\077 x1201)");
lf[461]=C_h_intern(&lf[461],11,"make-vector");
lf[462]=C_h_intern(&lf[462],15,"make-hash-table");
lf[463]=C_static_lambda_info(C_heaptop,37,"(body1207 test1214 hashf1215 len1216)");
lf[464]=C_static_lambda_info(C_heaptop,42,"(def-len1211 %test12041219 %hashf12051220)");
lf[465]=C_h_intern(&lf[465],8,"\003syshash");
lf[466]=C_static_lambda_info(C_heaptop,29,"(def-hashf1210 %test12041222)");
lf[467]=C_static_lambda_info(C_heaptop,14,"(def-test1209)");
lf[468]=C_static_lambda_info(C_heaptop,37,"(make-hash-table . test-and-size1203)");
lf[469]=C_h_intern(&lf[469],15,"hash-table-copy");
lf[470]=C_static_lambda_info(C_heaptop,14,"(copy lst1239)");
lf[471]=C_static_lambda_info(C_heaptop,14,"(do1235 i1237)");
lf[472]=C_static_lambda_info(C_heaptop,24,"(hash-table-copy ht1231)");
lf[473]=C_h_intern(&lf[473],31,"hash-table-equivalence-function");
lf[474]=C_static_lambda_info(C_heaptop,40,"(hash-table-equivalence-function ht1245)");
lf[475]=C_h_intern(&lf[475],24,"hash-table-hash-function");
lf[476]=C_static_lambda_info(C_heaptop,33,"(hash-table-hash-function ht1247)");
lf[477]=C_static_lambda_info(C_heaptop,28,"(hash-with-test x1253 d1254)");
lf[478]=C_h_intern(&lf[478],11,"input-port\077");
lf[479]=C_static_lambda_info(C_heaptop,26,"(loop k1264 i1265 len1266)");
lf[480]=C_static_lambda_info(C_heaptop,21,"(rechash x1259 d1260)");
lf[481]=C_h_intern(&lf[481],4,"hash");
lf[482]=C_static_lambda_info(C_heaptop,28,"(##sys#hash x1249 limit1250)");
lf[483]=C_static_lambda_info(C_heaptop,24,"(hash x1273 . g12721274)");
lf[484]=C_h_intern(&lf[484],16,"hash-by-identity");
lf[485]=C_h_intern(&lf[485],11,"string-hash");
lf[486]=C_static_lambda_info(C_heaptop,31,"(string-hash s1280 . g12791281)");
lf[487]=C_h_intern(&lf[487],14,"string-ci-hash");
lf[488]=C_static_lambda_info(C_heaptop,34,"(string-ci-hash s1287 . g12861288)");
lf[489]=C_h_intern(&lf[489],15,"hash-table-size");
lf[490]=C_static_lambda_info(C_heaptop,24,"(hash-table-size ht1293)");
lf[491]=C_h_intern(&lf[491],5,"floor");
lf[492]=C_h_intern(&lf[492],18,"hash-table-update!");
lf[493]=C_h_intern(&lf[493],21,"\006extrashashtab-rehash");
lf[494]=C_h_intern(&lf[494],16,"\003syshash-new-len");
lf[495]=C_static_lambda_info(C_heaptop,17,"(loop bucket1317)");
lf[496]=C_static_lambda_info(C_heaptop,17,"(loop bucket1326)");
lf[497]=C_flonum(C_heaptop,0.5);
lf[498]=C_static_lambda_info(C_heaptop,9,"(restart)");
lf[499]=C_h_intern(&lf[499],13,"\000access-error");
lf[500]=C_static_string(C_heaptop,31,"hash-table does not contain key");
lf[501]=C_static_lambda_info(C_heaptop,8,"(f_8272)");
lf[502]=C_static_lambda_info(C_heaptop,56,"(hash-table-update! ht1298 key1299 proc1300 . g12971301)");
lf[503]=C_h_intern(&lf[503],26,"hash-table-update!/default");
lf[504]=C_static_lambda_info(C_heaptop,7,"(a8299)");
lf[505]=C_static_lambda_info(C_heaptop,60,"(hash-table-update!/default ht1337 key1338 func1339 def1340)");
lf[506]=C_h_intern(&lf[506],15,"hash-table-set!");
lf[507]=C_static_lambda_info(C_heaptop,13,"(a8308 x1345)");
lf[508]=C_static_lambda_info(C_heaptop,7,"(a8311)");
lf[509]=C_static_lambda_info(C_heaptop,40,"(hash-table-set! ht1342 key1343 val1344)");
lf[510]=C_h_intern(&lf[510],14,"hash-table-ref");
lf[511]=C_h_intern(&lf[511],22,"hash-table-ref/default");
lf[512]=C_static_lambda_info(C_heaptop,7,"(a8324)");
lf[513]=C_static_lambda_info(C_heaptop,47,"(hash-table-ref/default ht1365 key1366 def1367)");
lf[514]=C_h_intern(&lf[514],18,"hash-table-exists\077");
lf[515]=C_static_lambda_info(C_heaptop,35,"(hash-table-exists\077 ht1370 key1371)");
lf[516]=C_static_lambda_info(C_heaptop,36,"(##sys#hash-new-len tab1373 req1374)");
lf[517]=C_h_intern(&lf[517],18,"hash-table-delete!");
lf[518]=C_static_lambda_info(C_heaptop,26,"(loop prev1388 bucket1389)");
lf[519]=C_static_lambda_info(C_heaptop,26,"(loop prev1395 bucket1396)");
lf[520]=C_static_lambda_info(C_heaptop,35,"(hash-table-delete! ht1378 key1379)");
lf[521]=C_h_intern(&lf[521],18,"hash-table-remove!");
lf[522]=C_static_lambda_info(C_heaptop,26,"(loop prev1411 bucket1412)");
lf[523]=C_static_lambda_info(C_heaptop,14,"(do1407 i1409)");
lf[524]=C_static_lambda_info(C_heaptop,36,"(hash-table-remove! ht1402 proc1403)");
lf[525]=C_static_lambda_info(C_heaptop,17,"(loop bucket1429)");
lf[526]=C_static_lambda_info(C_heaptop,14,"(do1425 i1427)");
lf[527]=C_static_lambda_info(C_heaptop,53,"(##extras#hashtab-rehash vec11420 vec21421 hashf1422)");
lf[528]=C_h_intern(&lf[528],17,"hash-table-merge!");
lf[529]=C_static_lambda_info(C_heaptop,16,"(do1445 lst1447)");
lf[530]=C_static_lambda_info(C_heaptop,14,"(do1442 i1444)");
lf[531]=C_static_lambda_info(C_heaptop,35,"(hash-table-merge! ht11438 ht21439)");
lf[532]=C_h_intern(&lf[532],17,"hash-table->alist");
lf[533]=C_static_lambda_info(C_heaptop,26,"(loop2 bucket1462 lst1463)");
lf[534]=C_static_lambda_info(C_heaptop,20,"(loop i1459 lst1460)");
lf[535]=C_static_lambda_info(C_heaptop,26,"(hash-table->alist ht1455)");
lf[536]=C_h_intern(&lf[536],17,"alist->hash-table");
lf[537]=C_static_lambda_info(C_heaptop,13,"(a8857 x1473)");
lf[538]=C_h_intern(&lf[538],12,"\003sysfor-each");
lf[539]=C_static_lambda_info(C_heaptop,40,"(alist->hash-table alist1470 . rest1471)");
lf[540]=C_h_intern(&lf[540],15,"hash-table-keys");
lf[541]=C_static_lambda_info(C_heaptop,26,"(loop2 bucket1482 lst1483)");
lf[542]=C_static_lambda_info(C_heaptop,20,"(loop i1479 lst1480)");
lf[543]=C_static_lambda_info(C_heaptop,24,"(hash-table-keys ht1475)");
lf[544]=C_h_intern(&lf[544],17,"hash-table-values");
lf[545]=C_static_lambda_info(C_heaptop,26,"(loop2 bucket1495 lst1496)");
lf[546]=C_static_lambda_info(C_heaptop,20,"(loop i1492 lst1493)");
lf[547]=C_static_lambda_info(C_heaptop,26,"(hash-table-values ht1488)");
lf[548]=C_h_intern(&lf[548],15,"hash-table-walk");
lf[549]=C_static_lambda_info(C_heaptop,18,"(a9038 bucket1508)");
lf[550]=C_static_lambda_info(C_heaptop,14,"(do1505 i1507)");
lf[551]=C_static_lambda_info(C_heaptop,30,"(hash-table-walk ht1501 p1502)");
lf[552]=C_h_intern(&lf[552],15,"hash-table-fold");
lf[553]=C_static_lambda_info(C_heaptop,27,"(fold2 buckets1521 acc1522)");
lf[554]=C_static_lambda_info(C_heaptop,20,"(loop i1518 acc1519)");
lf[555]=C_static_lambda_info(C_heaptop,39,"(hash-table-fold ht1512 p1513 init1514)");
lf[556]=C_h_intern(&lf[556],10,"make-queue");
lf[557]=C_h_intern(&lf[557],5,"queue");
lf[558]=C_static_lambda_info(C_heaptop,12,"(make-queue)");
lf[559]=C_h_intern(&lf[559],6,"queue\077");
lf[560]=C_static_lambda_info(C_heaptop,14,"(queue\077 x1527)");
lf[561]=C_h_intern(&lf[561],12,"queue-empty\077");
lf[562]=C_static_lambda_info(C_heaptop,20,"(queue-empty\077 q1528)");
lf[563]=C_h_intern(&lf[563],11,"queue-first");
lf[564]=C_static_string(C_heaptop,14,"queue is empty");
lf[565]=C_static_lambda_info(C_heaptop,19,"(queue-first q1530)");
lf[566]=C_h_intern(&lf[566],10,"queue-last");
lf[567]=C_static_string(C_heaptop,14,"queue is empty");
lf[568]=C_static_lambda_info(C_heaptop,18,"(queue-last q1534)");
lf[569]=C_h_intern(&lf[569],10,"queue-add!");
lf[570]=C_static_lambda_info(C_heaptop,28,"(queue-add! q1538 datum1539)");
lf[571]=C_h_intern(&lf[571],13,"queue-remove!");
lf[572]=C_static_string(C_heaptop,14,"queue is empty");
lf[573]=C_static_lambda_info(C_heaptop,21,"(queue-remove! q1544)");
lf[574]=C_h_intern(&lf[574],11,"queue->list");
lf[575]=C_static_lambda_info(C_heaptop,19,"(queue->list q1551)");
lf[576]=C_h_intern(&lf[576],11,"list->queue");
lf[577]=C_static_lambda_info(C_heaptop,16,"(do1554 lst1556)");
lf[578]=C_static_lambda_info(C_heaptop,22,"(list->queue lst01553)");
lf[579]=C_h_intern(&lf[579],16,"queue-push-back!");
lf[580]=C_static_lambda_info(C_heaptop,33,"(queue-push-back! q1562 item1563)");
lf[581]=C_h_intern(&lf[581],21,"queue-push-back-list!");
lf[582]=C_static_lambda_info(C_heaptop,8,"(do1571)");
lf[583]=C_static_lambda_info(C_heaptop,42,"(queue-push-back-list! q1567 itemlist1568)");
lf[584]=C_h_intern(&lf[584],17,"register-feature!");
lf[585]=C_h_intern(&lf[585],7,"srfi-69");
lf[586]=C_static_string(C_heaptop,31,"hash-table does not contain key");
lf[587]=C_static_lambda_info(C_heaptop,8,"(f_9520)");
lf[588]=C_static_lambda_info(C_heaptop,17,"(loop bucket1356)");
lf[589]=C_static_lambda_info(C_heaptop,17,"(loop bucket1360)");
lf[590]=C_static_lambda_info(C_heaptop,36,"(a9403 ht1347 key1348 . default1349)");
lf[591]=C_h_intern(&lf[591],18,"getter-with-setter");
lf[592]=C_h_intern(&lf[592],7,"srfi-28");
lf[593]=C_h_intern(&lf[593],14,"make-parameter");
lf[594]=C_h_intern(&lf[594],6,"extras");
lf[595]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf2(lf,596,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=*((C_word*)lf[2]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1712,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 95   register-feature! */
t5=*((C_word*)lf[584]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[594]);}

/* k1710 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word ab[177],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=*((C_word*)lf[3]+1);
t3=*((C_word*)lf[4]+1);
t4=*((C_word*)lf[5]+1);
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1714,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=lf[16],tmp=(C_word)a,a+=6,tmp));
t6=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=lf[18],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=lf[21],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1860,a[2]=lf[25],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1893,a[2]=lf[29],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=lf[33],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=lf[36],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1961,a[2]=lf[39],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1973,a[2]=lf[45],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2009,a[2]=lf[49],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=lf[53],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2088,a[2]=lf[55],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=lf[60],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=lf[62],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2153,a[2]=lf[64],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=lf[67],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=lf[70],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=lf[73],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2249,a[2]=lf[76],tmp=(C_word)a,a+=3,tmp));
t24=*((C_word*)lf[4]+1);
t25=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2290,a[2]=t24,a[3]=lf[81],tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2375,a[2]=lf[86],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=lf[92],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=lf[100],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=lf[110],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=lf[117],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2765,a[2]=lf[120],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2815,a[2]=lf[121],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2827,a[2]=lf[123],tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[124]+1);
t35=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t34,a[3]=lf[133],tmp=(C_word)a,a+=4,tmp));
t36=*((C_word*)lf[125]+1);
t37=*((C_word*)lf[5]+1);
t38=*((C_word*)lf[4]+1);
t39=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3010,a[2]=t37,a[3]=t36,a[4]=t38,a[5]=lf[137],tmp=(C_word)a,a+=6,tmp));
t40=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=lf[140],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=lf[145],tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[146]+1);
t43=*((C_word*)lf[147]+1);
t44=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3287,a[2]=t42,a[3]=t43,a[4]=lf[152],tmp=(C_word)a,a+=5,tmp));
t45=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3360,a[2]=lf[156],tmp=(C_word)a,a+=3,tmp));
t46=*((C_word*)lf[146]+1);
t47=*((C_word*)lf[147]+1);
t48=C_mutate((C_word*)lf[157]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3420,a[2]=t46,a[3]=t47,a[4]=lf[161],tmp=(C_word)a,a+=5,tmp));
t49=*((C_word*)lf[162]+1);
t50=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3489,a[2]=t49,a[3]=lf[168],tmp=(C_word)a,a+=4,tmp));
t51=*((C_word*)lf[162]+1);
t52=*((C_word*)lf[169]+1);
t53=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3578,a[2]=t51,a[3]=t52,a[4]=lf[171],tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3599,a[2]=lf[173],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3639,a[2]=lf[175],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3677,a[2]=lf[181],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[182]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3708,a[2]=lf[187],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3739,a[2]=lf[194],tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[195]+1);
t60=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3770,a[2]=t59,a[3]=lf[197],tmp=(C_word)a,a+=4,tmp));
t61=*((C_word*)lf[146]+1);
t62=*((C_word*)lf[147]+1);
t63=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3779,a[2]=t61,a[3]=t62,a[4]=lf[199],tmp=(C_word)a,a+=5,tmp));
t64=*((C_word*)lf[195]+1);
t65=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3791,a[2]=t64,a[3]=lf[204],tmp=(C_word)a,a+=4,tmp));
t66=*((C_word*)lf[146]+1);
t67=*((C_word*)lf[147]+1);
t68=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3822,a[2]=t66,a[3]=t67,a[4]=lf[209],tmp=(C_word)a,a+=5,tmp));
t69=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=lf[222],tmp=(C_word)a,a+=3,tmp));
t70=*((C_word*)lf[223]+1);
t71=C_mutate((C_word*)lf[224]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4002,a[2]=t70,a[3]=lf[230],tmp=(C_word)a,a+=4,tmp));
t72=*((C_word*)lf[146]+1);
t73=*((C_word*)lf[147]+1);
t74=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4060,a[2]=t72,a[3]=t73,a[4]=lf[338],tmp=(C_word)a,a+=5,tmp));
t75=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5332,a[2]=lf[341],tmp=(C_word)a,a+=3,tmp));
t76=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 958  make-parameter */
t77=*((C_word*)lf[593]+1);
((C_proc3)(void*)(*((C_word*)t77+1)))(3,t77,t76,C_fix(79));}

/* k5409 in k1710 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[95],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5411,2,t0,t1);}
t2=C_mutate((C_word*)lf[342]+1,t1);
t3=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5413,a[2]=lf[346],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[347]+1,*((C_word*)lf[343]+1));
t5=*((C_word*)lf[146]+1);
t6=*((C_word*)lf[162]+1);
t7=*((C_word*)lf[223]+1);
t8=*((C_word*)lf[147]+1);
t9=C_mutate((C_word*)lf[348]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5442,a[2]=t5,a[3]=t6,a[4]=t8,a[5]=t7,a[6]=lf[350],tmp=(C_word)a,a+=7,tmp));
t10=*((C_word*)lf[276]+1);
t11=C_mutate((C_word*)lf[351]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5487,a[2]=t10,a[3]=lf[352],tmp=(C_word)a,a+=4,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5497,a[2]=lf[354],tmp=(C_word)a,a+=3,tmp);
t13=C_mutate((C_word*)lf[355]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5544,a[2]=t12,a[3]=lf[358],tmp=(C_word)a,a+=4,tmp));
t14=C_mutate((C_word*)lf[359]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5553,a[2]=t12,a[3]=lf[362],tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[357]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5562,a[2]=lf[363],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5590,a[2]=lf[364],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5618,a[2]=lf[366],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5649,a[2]=lf[368],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5680,a[2]=lf[371],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5717,a[2]=lf[376],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5797,a[2]=lf[379],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5834,a[2]=lf[384],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[385]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5914,a[2]=lf[390],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6049,a[2]=lf[397],tmp=(C_word)a,a+=3,tmp));
t25=*((C_word*)lf[124]+1);
t26=*((C_word*)lf[398]+1);
t27=C_mutate((C_word*)lf[399]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6164,a[2]=t26,a[3]=t25,a[4]=lf[406],tmp=(C_word)a,a+=5,tmp));
t28=C_mutate((C_word*)lf[407]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6366,a[2]=lf[411],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6488,a[2]=lf[414],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6552,a[2]=lf[417],tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[418]+1);
t32=*((C_word*)lf[169]+1);
t33=*((C_word*)lf[162]+1);
t34=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6604,a[2]=t32,a[3]=t33,a[4]=t31,a[5]=lf[427],tmp=(C_word)a,a+=6,tmp));
t35=*((C_word*)lf[419]+1);
t36=*((C_word*)lf[345]+1);
t37=C_mutate((C_word*)lf[428]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6870,a[2]=t36,a[3]=t35,a[4]=lf[429],tmp=(C_word)a,a+=5,tmp));
t38=*((C_word*)lf[146]+1);
t39=*((C_word*)lf[147]+1);
t40=*((C_word*)lf[419]+1);
t41=C_mutate((C_word*)lf[430]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6880,a[2]=t38,a[3]=t40,a[4]=t39,a[5]=lf[431],tmp=(C_word)a,a+=6,tmp));
t42=*((C_word*)lf[419]+1);
t43=*((C_word*)lf[430]+1);
t44=*((C_word*)lf[428]+1);
t45=C_mutate((C_word*)lf[432]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6892,a[2]=t42,a[3]=t43,a[4]=t44,a[5]=lf[435],tmp=(C_word)a,a+=6,tmp));
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1337 register-feature! */
t47=*((C_word*)lf[584]+1);
((C_proc3)C_retrieve_proc(t47))(3,t47,t46,lf[592]);}

/* k6933 in k5409 in k1710 */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[71],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6935,2,t0,t1);}
t2=C_mutate((C_word*)lf[436]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6937,a[2]=lf[439],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[440]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7046,a[2]=lf[442],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[443]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7145,a[2]=lf[445],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7277,a[2]=lf[448],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[449]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7410,a[2]=lf[452],tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[450]+1);
t8=C_mutate((C_word*)lf[453]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7437,a[2]=t7,a[3]=lf[455],tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[456],lf[457]);
t10=C_mutate((C_word*)lf[458]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7521,a[2]=lf[460],tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[461]+1);
t12=C_mutate((C_word*)lf[462]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7527,a[2]=t11,a[3]=lf[468],tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[461]+1);
t14=C_mutate((C_word*)lf[469]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7614,a[2]=t13,a[3]=lf[472],tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[473]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7709,a[2]=lf[474],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[475]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7718,a[2]=lf[476],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[465]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7727,a[2]=lf[482],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[481]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7953,a[2]=lf[483],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[484]+1,*((C_word*)lf[481]+1));
t20=C_mutate((C_word*)lf[485]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7985,a[2]=lf[486],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[487]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8013,a[2]=lf[488],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[489]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8041,a[2]=lf[490],tmp=(C_word)a,a+=3,tmp));
t23=*((C_word*)lf[103]+1);
t24=*((C_word*)lf[491]+1);
t25=C_mutate((C_word*)lf[492]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8050,a[2]=t24,a[3]=t23,a[4]=lf[502],tmp=(C_word)a,a+=5,tmp));
t26=*((C_word*)lf[492]+1);
t27=C_mutate((C_word*)lf[503]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8294,a[2]=t26,a[3]=lf[505],tmp=(C_word)a,a+=4,tmp));
t28=*((C_word*)lf[492]+1);
t29=C_mutate((C_word*)lf[506]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8303,a[2]=t28,a[3]=lf[509],tmp=(C_word)a,a+=4,tmp));
t30=*((C_word*)lf[103]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9404,a[2]=t30,a[3]=lf[590],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1711 getter-with-setter */
t33=*((C_word*)lf[591]+1);
((C_proc4)C_retrieve_proc(t33))(4,t33,t31,t32,*((C_word*)lf[506]+1));}

/* a9403 in k6933 in k5409 in k1710 */
static void C_ccall f_9404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_9404r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_9404r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9404r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_structure_2(t2,lf[459],lf[510]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9417,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_block_size(t6);
/* extras.scm: 1716 hashf */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k9415 in a9403 in k6933 in k5409 in k1710 */
static void C_ccall f_9417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9417,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9520,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=lf[587],tmp=(C_word)a,a+=5,tmp));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],t1);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9438,a[2]=t8,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=lf[588],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_9438(t10,((C_word*)t0)[2],t6);}
else{
t6=(C_word)C_slot(((C_word*)t0)[3],t1);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9480,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t8,a[5]=t3,a[6]=lf[589],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_9480(t10,((C_word*)t0)[2],t6);}}

/* loop in k9415 in a9403 in k6933 in k5409 in k1710 */
static void C_fcall f_9480(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9480,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
/* extras.scm: 1732 def */
t4=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9499,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1734 test */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k9497 in loop in k9415 in a9403 in k6933 in k5409 in k1710 */
static void C_ccall f_9499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1736 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9480(t3,((C_word*)t0)[5],t2);}}

/* loop in k9415 in a9403 in k6933 in k5409 in k1710 */
static void C_fcall f_9438(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9438,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
/* extras.scm: 1725 def */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_slot(t4,C_fix(1)));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1729 loop */
t9=t1;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* f_9520 in k9415 in a9403 in k6933 in k5409 in k1710 */
static void C_ccall f_9520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9520,2,t0,t1);}
/* ##sys#signal-hook */
t2=*((C_word*)lf[89]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[499],lf[510],lf[586],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8317,2,t0,t1);}
t2=C_mutate((C_word*)lf[510]+1,t1);
t3=*((C_word*)lf[510]+1);
t4=C_mutate((C_word*)lf[511]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8319,a[2]=t3,a[3]=lf[513],tmp=(C_word)a,a+=4,tmp));
t5=(C_word)C_a_i_vector(&a,1,C_fix(42));
t6=*((C_word*)lf[511]+1);
t7=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8331,a[2]=t6,a[3]=t5,a[4]=lf[515],tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[494]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8348,a[2]=lf[516],tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[103]+1);
t10=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8381,a[2]=t9,a[3]=lf[520],tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8528,a[2]=lf[524],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[493]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8626,a[2]=lf[527],tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[506]+1);
t14=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8705,a[2]=t13,a[3]=lf[531],tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8776,a[2]=lf[535],tmp=(C_word)a,a+=3,tmp));
t16=*((C_word*)lf[462]+1);
t17=*((C_word*)lf[506]+1);
t18=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8849,a[2]=t16,a[3]=t17,a[4]=lf[539],tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8872,a[2]=lf[543],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[544]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8937,a[2]=lf[547],tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1896 register-feature! */
t22=*((C_word*)lf[584]+1);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[585]);}

/* k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9003,2,t0,t1);}
t2=C_mutate((C_word*)lf[548]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9005,a[2]=lf[551],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[552]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9057,a[2]=lf[555],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[556]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9126,a[2]=lf[558],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[559]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9132,a[2]=lf[560],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[561]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9138,a[2]=lf[562],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[563]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9151,a[2]=lf[565],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[566]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9172,a[2]=lf[568],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[569]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9193,a[2]=lf[570],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[571]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9225,a[2]=lf[573],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[574]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9261,a[2]=lf[575],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[576]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9270,a[2]=lf[578],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[579]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9324,a[2]=lf[580],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[581]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9353,a[2]=lf[583],tmp=(C_word)a,a+=3,tmp));
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}

/* queue-push-back-list! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9353,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[557],lf[581]);
t5=(C_word)C_i_check_list_2(t3,lf[581]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9363,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 2035 append */
t8=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t3,t7);}

/* k9361 in queue-push-back-list! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9366,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_9366(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9380,a[2]=lf[582],tmp=(C_word)a,a+=3,tmp);
t5=t2;
f_9366(t5,f_9380(t1));}}

/* do1571 in k9361 in queue-push-back-list! in k9001 in k8315 in k6933 in k5409 in k1710 */
static C_word C_fcall f_9380(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* k9364 in k9361 in queue-push-back-list! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_9366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1));}

/* queue-push-back! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9324,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[557],lf[579]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_i_setslot(t2,C_fix(1),t6);
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?(C_word)C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED));}

/* list->queue in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9270,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[576]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9281,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_9281(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9289,a[2]=t2,a[3]=t7,a[4]=lf[577],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_9289(t9,t4,t2);}}

/* do1554 in list->queue in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_9289(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9289,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9299,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* extras.scm: 2011 ##sys#not-a-proper-list-error */
t8=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[576]);}
else{
t8=t5;
f_9299(2,t8,C_SCHEME_UNDEFINED);}}}

/* k9297 in do1554 in list->queue in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9289(t3,((C_word*)t0)[2],t2);}

/* k9279 in list->queue in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9281,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[557],((C_word*)t0)[2],t1));}

/* queue->list in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9261,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[557],lf[574]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9225,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[557],lf[571]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9235,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 1989 ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[571],lf[572],t2);}
else{
t7=t5;
f_9235(2,t7,C_SCHEME_UNDEFINED);}}

/* k9233 in queue-remove! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(((C_word*)t0)[4],C_fix(0)));}

/* queue-add! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9193,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[557],lf[569]);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9203,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t7);
if(C_truep(t8)){
t9=t6;
f_9203(t9,(C_word)C_i_setslot(t2,C_fix(1),t5));}
else{
t9=(C_word)C_slot(t2,C_fix(2));
t10=t6;
f_9203(t10,(C_word)C_i_setslot(t9,C_fix(1),t5));}}

/* k9201 in queue-add! in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_9203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9172,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[557],lf[566]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9182,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 1970 ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[566],lf[567],t2);}
else{
t7=t5;
f_9182(2,t7,C_SCHEME_UNDEFINED);}}

/* k9180 in queue-last in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-first in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9151,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[557],lf[563]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9161,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* extras.scm: 1959 ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[563],lf[564],t2);}
else{
t7=t5;
f_9161(2,t7,C_SCHEME_UNDEFINED);}}

/* k9159 in queue-first in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-empty? in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9138,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[557],lf[561]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* queue? in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9132,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[557]));}

/* make-queue in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9126,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[557],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* hash-table-fold in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9057,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[459],lf[552]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_block_size(t6);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9072,a[2]=t3,a[3]=t9,a[4]=t6,a[5]=t7,a[6]=lf[554],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_9072(t11,t1,C_fix(0),t4);}

/* loop in hash-table-fold in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_9072(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9072,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9088,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=lf[553],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_9088(t8,t1,t4,t3);}}

/* fold2 in loop in hash-table-fold in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_9088(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9088,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1923 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9072(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9116,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* extras.scm: 1926 p */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,t3);}}

/* k9114 in fold2 in loop in hash-table-fold in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1925 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9088(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* hash-table-walk in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9005,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[459],lf[548]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9020,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t6,a[6]=lf[550],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_9020(t10,t1,C_fix(0));}

/* do1505 in hash-table-walk in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9020,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9030,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9039,a[2]=((C_word*)t0)[3],a[3]=lf[549],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* extras.scm: 1908 ##sys#for-each */
t6=*((C_word*)lf[538]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a9038 in do1505 in hash-table-walk in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9039,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1909 p */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k9028 in do1505 in hash-table-walk in k9001 in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_9030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9020(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8937,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[459],lf[544]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8952,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=lf[546],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_8952(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8952(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8952,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8968,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[545],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8968(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8968(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8968,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1891 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8952(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 1892 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8872,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[459],lf[540]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8887,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=lf[542],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_8887(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8887(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8887,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8903,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[541],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8903(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8903(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8903,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1877 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8887(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* extras.scm: 1878 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8849(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_8849r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8849r(t0,t1,t2,t3);}}

static void C_ccall f_8849r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8853,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t3);}

/* k8851 in alist->hash-table in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8856,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8858,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[537],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[538]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8857 in k8851 in alist->hash-table in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8858,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* extras.scm: 1865 hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* k8854 in k8851 in alist->hash-table in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8776,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[459],lf[532]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8791,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=lf[534],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_8791(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8791(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8791,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8807,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=lf[533],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8807(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8807(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8807,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1855 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8791(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* extras.scm: 1856 loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8705,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[459],lf[528]);
t5=(C_word)C_i_check_structure_2(t3,lf[459],lf[528]);
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_block_size(t6);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8723,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t9,a[5]=t2,a[6]=t7,a[7]=lf[530],tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_8723(t11,t1,C_fix(0));}

/* do1442 in hash-table-merge! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8723,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8733,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8746,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=lf[529],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8746(t8,t3,t4);}}

/* do1445 in do1442 in hash-table-merge! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8746(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8746,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8759,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 1841 hash-table-set! */
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,((C_word*)t0)[2],t5,t6);}}

/* k8757 in do1445 in do1442 in hash-table-merge! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8746(t3,((C_word*)t0)[2],t2);}

/* k8731 in do1442 in hash-table-merge! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8723(t3,((C_word*)t0)[2],t2);}

/* ##extras#hashtab-rehash in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8626,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t2);
t6=(C_word)C_block_size(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8638,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t8,a[7]=t5,a[8]=lf[526],tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_8638(t10,t1,C_fix(0));}

/* do1425 in ##extras#hashtab-rehash in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8638,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8648,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=lf[525],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_8661(t8,t3,t4);}}

/* loop in do1425 in ##extras#hashtab-rehash in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8661(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8661,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8677,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1825 hashf */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k8675 in loop in do1425 in ##extras#hashtab-rehash in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8677,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1827 loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_8661(t8,((C_word*)t0)[2],t7);}

/* k8646 in do1425 in ##extras#hashtab-rehash in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8638(t3,((C_word*)t0)[2],t2);}

/* hash-table-remove! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8528,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[459],lf[521]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(2));
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8546,a[2]=t3,a[3]=t5,a[4]=t11,a[5]=t9,a[6]=t2,a[7]=t6,a[8]=lf[523],tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_8546(t13,t1,C_fix(0));}

/* do1407 in hash-table-remove! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8546,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8559,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8572,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=lf[522],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_8572(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in do1407 in hash-table-remove! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8572,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8585,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t5,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* extras.scm: 1808 proc */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}

/* k8593 in loop in do1407 in hash-table-remove! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8595,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8598,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=t2;
f_8598(t4,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=t2;
f_8598(t4,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t3));}}
else{
t2=((C_word*)t0)[6];
f_8585(t2,C_SCHEME_UNDEFINED);}}

/* k8596 in k8593 in loop in do1407 in hash-table-remove! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_8585(t4,t3);}

/* k8583 in loop in do1407 in hash-table-remove! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1813 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8572(t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k8557 in do1407 in hash-table-remove! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8546(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8381,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[459],lf[517]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(4));
t7=(C_word)C_block_size(t5);
t8=(C_word)C_slot(t2,C_fix(3));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8400,a[2]=t1,a[3]=t3,a[4]=t8,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1765 hashf */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t3,t7);}

/* k8398 in hash-table-delete! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8400,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[6],t1);
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8417,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=lf[518],tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_8417(t9,((C_word*)t0)[2],C_SCHEME_FALSE,t4);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=lf[519],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_8472(t9,((C_word*)t0)[2],C_SCHEME_FALSE,t4);}}

/* loop in k8398 in hash-table-delete! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8472,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8488,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1788 test */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k8486 in loop in k8398 in hash-table-delete! in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8488,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8491,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[6];
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=t2;
f_8491(t5,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),t4));}
else{
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=t2;
f_8491(t5,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4));}}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1795 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8472(t3,((C_word*)t0)[7],((C_word*)t0)[5],t2);}}

/* k8489 in k8486 in loop in k8398 in hash-table-delete! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* loop in k8398 in hash-table-delete! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8417,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8436,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=t2;
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(1));
t10=t7;
f_8436(t10,(C_word)C_i_setslot(t2,C_fix(1),t9));}
else{
t9=(C_word)C_slot(t3,C_fix(1));
t10=t7;
f_8436(t10,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t9));}}
else{
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 1782 loop */
t13=t1;
t14=t3;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k8434 in loop in k8398 in hash-table-delete! in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##sys#hash-new-len in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8348,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_fixnum_greater_or_equal_p(t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8358,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_8358(t7,t5);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=t6;
f_8358(t8,(C_word)C_eqp(t7,C_SCHEME_END_OF_LIST));}}

/* k8356 in ##sys#hash-new-len in k8315 in k6933 in k5409 in k1710 */
static void C_fcall f_8358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1755 ##sys#hash-new-len */
t3=*((C_word*)lf[494]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* hash-table-exists? in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8331,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[459],lf[514]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8346,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1749 ref */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,t3,((C_word*)t0)[3]);}

/* k8344 in hash-table-exists? in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}

/* hash-table-ref/default in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8319,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8325,a[2]=t4,a[3]=lf[512],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1742 hash-table-ref */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t3,t5);}

/* a8324 in hash-table-ref/default in k8315 in k6933 in k5409 in k1710 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8325,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-set! in k6933 in k5409 in k1710 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8303,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8309,a[2]=t4,a[3]=lf[507],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8312,a[2]=t4,a[3]=lf[508],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1707 hash-table-update! */
t7=((C_word*)t0)[2];
((C_proc6)C_retrieve_proc(t7))(6,t7,t1,t2,t3,t5,t6);}

/* a8311 in hash-table-set! in k6933 in k5409 in k1710 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8312,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a8308 in hash-table-set! in k6933 in k5409 in k1710 */
static void C_ccall f_8309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8309,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* hash-table-update!/default in k6933 in k5409 in k1710 */
static void C_ccall f_8294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8294,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8300,a[2]=t5,a[3]=lf[504],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1702 hash-table-update! */
t7=((C_word*)t0)[2];
((C_proc6)C_retrieve_proc(t7))(6,t7,t1,t2,t3,t4,t6);}

/* a8299 in hash-table-update!/default in k6933 in k5409 in k1710 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8300,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr5r,(void*)f_8050r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_8050r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8050r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(13);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8054,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_8054(2,t7,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8272,a[2]=t2,a[3]=t3,a[4]=lf[501],tmp=(C_word)a,a+=5,tmp));}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_8054(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}

/* f_8272 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8272,2,t0,t1);}
/* extras.scm: 1650 ##sys#signal-hook */
t2=*((C_word*)lf[89]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[499],lf[492],lf[500],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8054,2,t0,t1);}
t2=(C_word)C_i_check_structure_2(((C_word*)t0)[7],lf[459],lf[492]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8062,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=lf[498],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_8062(t6,((C_word*)t0)[2]);}

/* restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_fcall f_8062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8062,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t4=(C_word)C_block_size(t2);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* extras.scm: 1658 hashf */
t7=t3;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],t4);}

/* k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8078,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(2));
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t5=(C_word)C_a_i_times(&a,2,((C_word*)t0)[12],lf[497]);
/* extras.scm: 1660 floor */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8260,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[14],t2);
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(((C_word*)t0)[13],C_fix(1073741823)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8103,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_times(((C_word*)t0)[13],C_fix(2));
t8=(C_word)C_i_fixnum_min(C_fix(1073741823),t7);
/* extras.scm: 1663 ##sys#hash-new-len */
t9=*((C_word*)lf[494]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,lf[457],t8);}
else{
t5=(C_word)C_slot(((C_word*)t0)[9],((C_word*)t0)[7]);
t6=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8125,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=t5,a[10]=((C_word*)t0)[4],a[11]=lf[495],tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_8125(t10,((C_word*)t0)[10],t5);}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8188,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=t5,a[11]=((C_word*)t0)[4],a[12]=lf[496],tmp=(C_word)a,a+=13,tmp));
t10=((C_word*)t8)[1];
f_8188(t10,((C_word*)t0)[10],t5);}}}

/* loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_fcall f_8188(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8188,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8198,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8216,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1687 init */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_slot(t4,C_fix(0));
/* extras.scm: 1693 test */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[11],t6);}}

/* k8223 in loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8225,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1694 proc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1697 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8188(t3,((C_word*)t0)[5],t2);}}

/* k8226 in k8223 in loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k8214 in loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1687 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8196 in loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8198,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_fcall f_8125(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8125,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8135,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8153,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1674 init */
t6=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[10],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8165,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t4,C_fix(1));
/* extras.scm: 1681 proc */
t9=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1684 loop */
t13=t1;
t14=t7;
t1=t13;
t2=t14;
goto loop;}}}

/* k8163 in loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k8151 in loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1674 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8133 in loop in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8135,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k8101 in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1662 make-vector */
t2=*((C_word*)lf[461]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8088 in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1666 hashtab-rehash */
t3=*((C_word*)lf[493]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8091 in k8088 in k8258 in k8076 in restart in k8052 in hash-table-update! in k6933 in k5409 in k1710 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]);
/* extras.scm: 1668 restart */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8062(t3,((C_word*)t0)[2]);}

/* hash-table-size in k6933 in k5409 in k1710 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8041,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[459],lf[489]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* string-ci-hash in k6933 in k5409 in k1710 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_8013r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8013r(t0,t1,t2,t3);}}

static void C_ccall f_8013r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8017,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_8017(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_8017(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k8015 in string-ci-hash in k6933 in k5409 in k1710 */
static void C_ccall f_8017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[487]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo((C_word)C_hash_string_ci(((C_word*)t0)[3]),t1));}

/* string-hash in k6933 in k5409 in k1710 */
static void C_ccall f_7985(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7985r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7985r(t0,t1,t2,t3);}}

static void C_ccall f_7985r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7989,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7989(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7989(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7987 in string-hash in k6933 in k5409 in k1710 */
static void C_ccall f_7989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[485]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo((C_word)C_hash_string(((C_word*)t0)[3]),t1));}

/* hash in k6933 in k5409 in k1710 */
static void C_ccall f_7953(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7953r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7953r(t0,t1,t2,t3);}}

static void C_ccall f_7953r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7957,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7957(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7957(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7955 in hash in k6933 in k5409 in k1710 */
static void C_ccall f_7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(t1,lf[481]);
/* extras.scm: 1620 ##sys#hash */
t3=*((C_word*)lf[465]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash in k6933 in k5409 in k1710 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7727,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7730,a[2]=t7,a[3]=lf[477],tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7755,a[2]=t7,a[3]=t5,a[4]=lf[480],tmp=(C_word)a,a+=5,tmp));
t10=(C_word)C_i_check_exact_2(t3,lf[481]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7951,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1616 rechash */
t12=((C_word*)t7)[1];
f_7755(t12,t11,t2,C_fix(0));}

/* k7949 in ##sys#hash in k6933 in k5409 in k1710 */
static void C_ccall f_7951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_modulo(t2,((C_word*)t0)[2]));}

/* rechash in ##sys#hash in k6933 in k5409 in k1710 */
static void C_fcall f_7755(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7755,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
case C_SCHEME_END_OF_LIST:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));
default:
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_hash_string(t4));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7822,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1598 hash-with-test */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7730(t7,t5,t6,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7851,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 1600 hash-with-test */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7730(t6,t4,t5,t3);}
else{
if(C_truep((C_word)C_portp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7864,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1602 input-port? */
t5=*((C_word*)lf[478]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_hash_string(t2));}
else{
t4=(C_word)C_block_size(t2);
t5=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t6=(C_truep((C_word)C_specialp(t2))?(C_word)C_peek_fixnum(t2,C_fix(0)):C_fix(0));
t7=(C_word)C_fixnum_plus(t4,t6);
t8=(C_word)C_fixnum_greaterp(t4,C_fix(4));
t9=(C_truep(t8)?C_fix(4):t4);
t10=(C_word)C_fixnum_difference(t9,t5);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t12,a[6]=lf[479],tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_7886(t14,t1,t7,t5,t10);}}}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(262));}}}}}}}

/* loop in rechash in ##sys#hash in k6933 in k5409 in k1710 */
static void C_fcall f_7886(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7886,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_times(t2,C_fix(16));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7921,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1612 rechash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_7755(t10,t7,t8,t9);}}

/* k7919 in loop in rechash in ##sys#hash in k6933 in k5409 in k1710 */
static void C_ccall f_7921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_fix(t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[7],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],t3);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1612 loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7886(t7,((C_word*)t0)[2],t4,t5,t6);}

/* k7862 in rechash in ##sys#hash in k6933 in k5409 in k1710 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_fix(260):C_fix(261)));}

/* k7849 in rechash in ##sys#hash in k6933 in k5409 in k1710 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7843,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 1601 hash-with-test */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7730(t5,t3,t4,((C_word*)t0)[2]);}

/* k7841 in k7849 in rechash in ##sys#hash in k6933 in k5409 in k1710 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k7820 in rechash in ##sys#hash in k6933 in k5409 in k1710 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* hash-with-test in ##sys#hash in k6933 in k5409 in k1710 */
static void C_fcall f_7730(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7730,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7740,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_7740(t6,t4);}
else{
t6=(C_word)C_byteblockp(t2);
t7=t5;
f_7740(t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}

/* k7738 in hash-with-test in ##sys#hash in k6933 in k5409 in k1710 */
static void C_fcall f_7740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 1586 rechash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7755(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* hash-table-hash-function in k6933 in k5409 in k1710 */
static void C_ccall f_7718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7718,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[459],lf[475]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k6933 in k5409 in k1710 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7709,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[459],lf[473]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-copy in k6933 in k5409 in k1710 */
static void C_ccall f_7614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7614,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[459],lf[469]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7627,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1551 make-vector */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t5,C_SCHEME_END_OF_LIST);}

/* k7625 in hash-table-copy in k6933 in k5409 in k1710 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7627,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=lf[471],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_7632(t5,((C_word*)t0)[2],C_fix(0));}

/* do1235 in k7625 in hash-table-copy in k6933 in k5409 in k1710 */
static void C_fcall f_7632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7632,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,5,lf[459],((C_word*)t0)[4],t3,t4,t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7668,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7674,a[2]=t6,a[3]=lf[470],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7674(t8,t3,t4);}}

/* copy in do1235 in k7625 in hash-table-copy in k6933 in k5409 in k1710 */
static void C_fcall f_7674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7674,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7695,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 1563 copy */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k7693 in copy in do1235 in k7625 in hash-table-copy in k6933 in k5409 in k1710 */
static void C_ccall f_7695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7695,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7666 in do1235 in k7625 in hash-table-copy in k6933 in k5409 in k1710 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7632(t4,((C_word*)t0)[2],t3);}

/* make-hash-table in k6933 in k5409 in k1710 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr2r,(void*)f_7527r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7527r(t0,t1,t2);}}

static void C_ccall f_7527r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(16);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[2],a[3]=lf[463],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7541,a[2]=t3,a[3]=lf[464],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7546,a[2]=t4,a[3]=lf[466],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7551,a[2]=t5,a[3]=lf[467],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-test12091223 */
t7=t6;
f_7551(t7,t1);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-hashf12101221 */
t9=t5;
f_7546(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-len12111218 */
t11=t4;
f_7541(t11,t1,t7,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body12071213 */
t13=t3;
f_7529(t13,t1,t7,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-test1209 in make-hash-table in k6933 in k5409 in k1710 */
static void C_fcall f_7551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7551,NULL,2,t0,t1);}
/* def-hashf12101221 */
t2=((C_word*)t0)[2];
f_7546(t2,t1,*((C_word*)lf[106]+1));}

/* def-hashf1210 in make-hash-table in k6933 in k5409 in k1710 */
static void C_fcall f_7546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7546,NULL,3,t0,t1,t2);}
/* def-len12111218 */
t3=((C_word*)t0)[2];
f_7541(t3,t1,t2,*((C_word*)lf[465]+1));}

/* def-len1211 in make-hash-table in k6933 in k5409 in k1710 */
static void C_fcall f_7541(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7541,NULL,4,t0,t1,t2,t3);}
/* body12071213 */
t4=((C_word*)t0)[2];
f_7529(t4,t1,t2,t3,C_fix(307));}

/* body1207 in make-hash-table in k6933 in k5409 in k1710 */
static void C_fcall f_7529(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7529,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(t4,lf[462]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7540,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1543 make-vector */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t4,C_SCHEME_END_OF_LIST);}

/* k7538 in body1207 in make-hash-table in k6933 in k5409 in k1710 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7540,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,5,lf[459],t1,C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]));}

/* hash-table? in k6933 in k5409 in k1710 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7521,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[459]));}

/* binary-search in k6933 in k5409 in k1710 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7437,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7441,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7515,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1497 list->vector */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_7441(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[453]));}}

/* k7513 in binary-search in k6933 in k5409 in k1710 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7441(t3,t2);}

/* k7439 in binary-search in k6933 in k5409 in k1710 */
static void C_fcall f_7441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7441,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=lf[454],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7455(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k7439 in binary-search in k6933 in k5409 in k1710 */
static void C_fcall f_7455(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7455,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_divide(t4,C_fix(2));
t6=(C_word)C_fixnum_plus(t2,t5);
t7=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7465,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1505 proc */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t7);}

/* k7463 in loop in k7439 in binary-search in k6933 in k5409 in k1710 */
static void C_ccall f_7465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1507 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7455(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* extras.scm: 1508 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7455(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k6933 in k5409 in k1710 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7410,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7424,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7428,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1487 vector->list */
t6=*((C_word*)lf[255]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7435,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1488 append */
t5=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k7433 in sort in k6933 in k5409 in k1710 */
static void C_ccall f_7435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1488 sort! */
t2=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7426 in sort in k6933 in k5409 in k1710 */
static void C_ccall f_7428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1487 sort! */
t2=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7422 in sort in k6933 in k5409 in k1710 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1487 list->vector */
t2=*((C_word*)lf[450]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k6933 in k5409 in k1710 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7277,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7280,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=lf[446],tmp=(C_word)a,a+=6,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_i_vector_length(((C_word*)t4)[1]);
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7367,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1470 vector->list */
t11=*((C_word*)lf[255]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* extras.scm: 1476 step */
t9=((C_word*)t6)[1];
f_7280(t9,t1,t8);}}

/* k7365 in sort! in k6933 in k5409 in k1710 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7367,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1471 step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7280(t4,t3,((C_word*)t0)[2]);}

/* k7372 in k7365 in sort! in k6933 in k5409 in k1710 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7374,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7376,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[447],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7376(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* do1178 in k7372 in k7365 in sort! in k6933 in k5409 in k1710 */
static void C_fcall f_7376(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7376,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_vector_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k6933 in k5409 in k1710 */
static void C_fcall f_7280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7280,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7321,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7331,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1455 less? */
t10=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k7329 in step in sort! in k6933 in k5409 in k1710 */
static void C_ccall f_7331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_car(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
f_7321(t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_7321(t2,C_SCHEME_UNDEFINED);}}

/* k7319 in step in sort! in k6933 in k5409 in k1710 */
static void C_fcall f_7321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k7288 in step in sort! in k6933 in k5409 in k1710 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1446 step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7280(t3,t2,t1);}

/* k7291 in k7288 in step in sort! in k6933 in k5409 in k1710 */
static void C_ccall f_7293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7293,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7299,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1448 step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7280(t4,t3,t2);}

/* k7297 in k7291 in k7288 in step in sort! in k6933 in k5409 in k1710 */
static void C_ccall f_7299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1449 merge! */
t2=*((C_word*)lf[443]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k6933 in k5409 in k1710 */
static void C_ccall f_7145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7145,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7148,a[2]=t4,a[3]=t6,a[4]=lf[444],tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7227,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* extras.scm: 1423 less? */
t11=t4;
((C_proc4)C_retrieve_proc(t11))(4,t11,t8,t9,t10);}}}

/* k7225 in merge! in k6933 in k5409 in k1710 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7230,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_7230(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* extras.scm: 1426 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7148(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7250,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_7250(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[4]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* extras.scm: 1431 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7148(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k7248 in k7225 in merge! in k6933 in k5409 in k1710 */
static void C_ccall f_7250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7228 in k7225 in merge! in k6933 in k5409 in k1710 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k6933 in k5409 in k1710 */
static void C_fcall f_7148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7148,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7155,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_car(t3);
/* extras.scm: 1408 less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k7153 in loop in merge! in k6933 in k5409 in k1710 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[5],((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* extras.scm: 1413 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7148(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_set_cdr(((C_word*)t0)[6],((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_cdr(((C_word*)t0)[3],((C_word*)t0)[5]));}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* extras.scm: 1419 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7148(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k6933 in k5409 in k1710 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7046,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7080,a[2]=t4,a[3]=t10,a[4]=lf[441],tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_7080(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k6933 in k5409 in k1710 */
static void C_fcall f_7080(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7080,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7087,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1391 less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t4,t2);}

/* k7085 in loop in merge in k6933 in k5409 in k1710 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7087,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* extras.scm: 1394 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7080(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7135,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* extras.scm: 1398 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7080(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k7133 in k7085 in loop in merge in k6933 in k5409 in k1710 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7135,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7105 in k7085 in loop in merge in k6933 in k5409 in k1710 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7107,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k6933 in k5409 in k1710 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6937,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6964,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=lf[437],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6964(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7012,a[2]=t3,a[3]=t7,a[4]=lf[438],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7012(t9,t1,t4,t5);}}}

/* loop in sorted? in k6933 in k5409 in k1710 */
static void C_fcall f_7012(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7012,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t3);
/* extras.scm: 1374 less? */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}}

/* k7038 in loop in sorted? in k6933 in k5409 in k1710 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* extras.scm: 1375 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7012(t4,((C_word*)t0)[4],t2,t3);}}

/* do1125 in sorted? in k6933 in k5409 in k1710 */
static void C_fcall f_6964(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6964,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6974(2,t5,t3);}
else{
t5=(C_word)C_i_vector_ref(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[3],t6);
/* extras.scm: 1368 less? */
t8=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t8))(4,t8,t4,t5,t7);}}

/* k6972 in do1125 in sorted? in k6933 in k5409 in k1710 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_6964(t3,((C_word*)t0)[5],t2);}}

/* format in k5409 in k1710 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_6892r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6892r(t0,t1,t2,t3);}}

static void C_ccall f_6892r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(15);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6900,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
if(C_truep(t6)){
if(C_truep((C_word)C_booleanp(t2))){
t7=t5;
f_6900(2,t7,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=t5;
f_6900(2,t9,((C_word*)t0)[3]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6925,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1333 output-port? */
t8=*((C_word*)lf[434]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}}
else{
t7=t5;
f_6900(2,t7,((C_word*)t0)[3]);}}

/* k6923 in format in k5409 in k1710 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6925,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_6900(2,t4,((C_word*)t0)[2]);}
else{
/* extras.scm: 1334 ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[432],lf[433],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}}

/* k6898 in format in k5409 in k1710 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* sprintf in k5409 in k1710 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6880r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6880r(t0,t1,t2,t3);}}

static void C_ccall f_6880r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6884,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 1320 open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6882 in sprintf in k5409 in k1710 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6887,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_apply(6,0,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6885 in k6882 in sprintf in k5409 in k1710 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1322 get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* printf in k5409 in k1710 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6870r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6870r(t0,t1,t2,t3);}}

static void C_ccall f_6870r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6878,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1312 current-output-port */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6876 in printf in k5409 in k1710 */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fprintf in k5409 in k1710 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_6604r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6604r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6604r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=lf[426],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6610(t8,t1,t3,t4);}

/* rec in fprintf in k5409 in k1710 */
static void C_fcall f_6610(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6610,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_string_2(t2,lf[419]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6617,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 1263 ##sys#check-port */
t7=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[5],lf[419]);}

/* k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6617,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6622,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6629,a[2]=((C_word*)t0)[8],a[3]=lf[421],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t8,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=lf[425],tmp=(C_word)a,a+=13,tmp));
t10=((C_word*)t8)[1];
f_6648(t10,((C_word*)t0)[2]);}

/* loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_fcall f_6648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6648,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[10]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_6622(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6661,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
t5=(C_truep(t4)?(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[10]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=f_6622(((C_word*)t0)[9]);
t7=(C_word)C_u_i_char_upcase(t6);
switch(t7){
case C_make_character(83):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6686,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1282 next */
t9=((C_word*)t0)[5];
f_6629(t9,t8);
case C_make_character(65):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1283 next */
t9=((C_word*)t0)[5];
f_6629(t9,t8);
case C_make_character(67):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6712,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1284 next */
t9=((C_word*)t0)[5];
f_6629(t9,t8);
case C_make_character(66):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6725,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6729,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1285 next */
t10=((C_word*)t0)[5];
f_6629(t10,t9);
case C_make_character(79):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6742,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6746,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1286 next */
t10=((C_word*)t0)[5];
f_6629(t10,t9);
case C_make_character(88):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6759,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6763,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 1287 next */
t10=((C_word*)t0)[5];
f_6629(t10,t9);
case C_make_character(33):
/* extras.scm: 1288 ##sys#flush-output */
t8=*((C_word*)lf[422]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t3,((C_word*)t0)[6]);
case C_make_character(63):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1290 next */
t9=((C_word*)t0)[5];
f_6629(t9,t8);
case C_make_character(126):
/* extras.scm: 1294 ##sys#write-char-0 */
t8=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,C_make_character(126),((C_word*)t0)[6]);
case C_make_character(37):
/* extras.scm: 1295 newline */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t3,((C_word*)t0)[6]);
default:
t8=(C_word)C_eqp(t7,C_make_character(37));
t9=(C_truep(t8)?t8:(C_word)C_eqp(t7,C_make_character(78)));
if(C_truep(t9)){
/* extras.scm: 1296 newline */
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t6))){
t10=f_6622(((C_word*)t0)[9]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6835,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[9],a[4]=lf[423],tmp=(C_word)a,a+=5,tmp);
t12=t3;
f_6661(2,t12,f_6835(t11,t10));}
else{
/* extras.scm: 1303 ##sys#error */
t10=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t3,lf[419],lf[424],t6);}}}}
else{
/* extras.scm: 1304 ##sys#write-char-0 */
t6=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t2,((C_word*)t0)[6]);}}}

/* skip in loop in k6615 in rec in fprintf in k5409 in k1710 */
static C_word C_fcall f_6835(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_6622(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k6779 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6784,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1291 next */
t3=((C_word*)t0)[2];
f_6629(t3,t2);}

/* k6782 in k6779 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_list_2(t1,lf[419]);
/* extras.scm: 1293 rec */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6610(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6761 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1287 ##sys#number->string */
t2=*((C_word*)lf[258]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(16));}

/* k6757 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1287 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6744 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1286 ##sys#number->string */
t2=*((C_word*)lf[258]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(8));}

/* k6740 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1286 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6727 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1285 ##sys#number->string */
t2=*((C_word*)lf[258]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(2));}

/* k6723 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1285 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6710 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1284 ##sys#write-char-0 */
t2=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6697 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1283 display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6684 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1282 write */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6659 in loop in k6615 in rec in fprintf in k5409 in k1710 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1305 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6648(t2,((C_word*)t0)[2]);}

/* next in k6615 in rec in fprintf in k5409 in k1710 */
static void C_fcall f_6629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6629,NULL,2,t0,t1);}
if(C_truep((C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST))){
/* extras.scm: 1272 ##sys#error */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[419],lf[420]);}
else{
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in k6615 in rec in fprintf in k5409 in k1710 */
static C_word C_fcall f_6622(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* string-chomp in k5409 in k1710 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6552r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6552r(t0,t1,t2,t3);}}

static void C_ccall f_6552r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6556,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6556(2,t5,lf[416]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_6556(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k6554 in string-chomp in k5409 in k1710 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[415]);
t3=(C_word)C_i_check_string_2(t1,lf[415]);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
t5=(C_word)C_block_size(t1);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_fixnum_greater_or_equal_p(t4,t5);
t8=(C_truep(t7)?(C_word)C_substring_compare(((C_word*)t0)[3],t1,t6,C_fix(0),t5):C_SCHEME_FALSE);
if(C_truep(t8)){
/* extras.scm: 1250 ##sys#substring */
t9=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t6);}
else{
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}}

/* string-chop in k5409 in k1710 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6488,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[412]);
t5=(C_word)C_i_check_exact_2(t3,lf[412]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6503,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=lf[413],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_6503(t10,t1,t6,C_fix(0));}

/* loop in string-chop in k5409 in k1710 */
static void C_fcall f_6503(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6503,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6523,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(t3,t2);
/* extras.scm: 1236 ##sys#substring */
t6=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6534,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
/* extras.scm: 1237 ##sys#substring */
t6=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k6532 in loop in string-chop in k5409 in k1710 */
static void C_ccall f_6534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6538,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* extras.scm: 1237 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6503(t5,t2,t3,t4);}

/* k6536 in k6532 in loop in string-chop in k5409 in k1710 */
static void C_ccall f_6538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6538,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6521 in loop in string-chop in k5409 in k1710 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k5409 in k1710 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6366,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[407]);
t5=(C_word)C_i_check_list_2(t3,lf[407]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6378,a[2]=t3,a[3]=t8,a[4]=t2,a[5]=t6,a[6]=lf[410],tmp=(C_word)a,a+=7,tmp));
/* extras.scm: 1225 collect */
t10=((C_word*)t8)[1];
f_6378(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k5409 in k1710 */
static void C_fcall f_6378(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6378,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6406,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1207 ##sys#substring */
t10=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_6396(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6411,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,a[9]=lf[409],tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_6411(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k5409 in k1710 */
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6411,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1211 collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_6378(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6450,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6476,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1219 ##sys#substring */
t10=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_6450(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_i_cdr(t2);
/* extras.scm: 1224 loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k6474 in loop in collect in string-translate* in k5409 in k1710 */
static void C_ccall f_6476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6476,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6450(t4,t3);}

/* k6448 in loop in collect in string-translate* in k5409 in k1710 */
static void C_fcall f_6450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6450,NULL,2,t0,t1);}
t2=(C_word)C_i_string_length(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* extras.scm: 1220 collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6378(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k6404 in collect in string-translate* in k5409 in k1710 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6396(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k6394 in collect in string-translate* in k5409 in k1710 */
static void C_fcall f_6396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1205 reverse */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6390 in collect in string-translate* in k5409 in k1710 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1203 ##sys#fragments->string */
t2=*((C_word*)lf[408]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k5409 in k1710 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_6164r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6164r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6164r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6167,a[2]=lf[402],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6201,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_6201(2,t7,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6341,a[2]=t3,a[3]=lf[405],tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6358,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 1161 list->string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_check_string_2(t3,lf[399]);
/* extras.scm: 1164 instring */
f_6167(t6,t3);}}}

/* k6356 in string-translate in k5409 in k1710 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1161 instring */
f_6167(((C_word*)t0)[2],t1);}

/* f_6341 in string-translate in k5409 in k1710 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6341,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k6199 in string-translate in k5409 in k1710 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_6204(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* extras.scm: 1169 list->string */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t4=(C_word)C_i_check_string_2(t3,lf[399]);
t5=t2;
f_6204(2,t5,t3);}}}
else{
t3=t2;
f_6204(2,t3,C_SCHEME_FALSE);}}

/* k6202 in k6199 in string-translate in k5409 in k1710 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[399]);
t5=(C_word)C_block_size(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 1176 make-string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k6214 in k6202 in k6199 in string-translate in k5409 in k1710 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6216,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=lf[404],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6221(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k6214 in k6202 in k6199 in string-translate in k5409 in k1710 */
static void C_fcall f_6221(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6221,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* extras.scm: 1180 ##sys#substring */
t4=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[7],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[6],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6240,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 1183 from */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}

/* k6238 in loop in k6214 in k6202 in k6199 in string-translate in k5409 in k1710 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[9];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1190 loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6221(t7,((C_word*)t0)[4],t5,t6);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
/* extras.scm: 1192 ##sys#error */
t4=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[399],lf[403],((C_word*)t0)[6],((C_word*)t0)[9]);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],(C_word)C_subchar(((C_word*)t0)[9],t1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1195 loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6221(t7,((C_word*)t0)[4],t5,t6);}}}
else{
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* extras.scm: 1187 loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_6221(t5,((C_word*)t0)[4],t4,((C_word*)t0)[7]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* extras.scm: 1186 loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_6221(t6,((C_word*)t0)[4],t4,t5);}}

/* instring in string-translate in k5409 in k1710 */
static void C_fcall f_6167(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6167,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6172,a[2]=t2,a[3]=t3,a[4]=lf[401],tmp=(C_word)a,a+=5,tmp));}

/* f_6172 in instring in string-translate in k5409 in k1710 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6172,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=lf[400],tmp=(C_word)a,a+=6,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6178(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_6178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k5409 in k1710 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6049r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6049r(t0,t1,t2,t3);}}

static void C_ccall f_6049r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6053,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6053(2,t5,lf[396]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_6053(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k6051 in string-intersperse in k5409 in k1710 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=(C_word)C_i_check_list_2(((C_word*)t0)[3],lf[391]);
t3=(C_word)C_i_check_string_2(t1,lf[391]);
t4=(C_word)C_block_size(t1);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6067,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=lf[395],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6067(t8,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* loop1 in k6051 in string-intersperse in k5409 in k1710 */
static void C_fcall f_6067(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6067,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[392]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6077,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_fixnum_difference(t3,((C_word*)t0)[3]);
/* extras.scm: 1124 ##sys#allocate-vector */
t6=*((C_word*)lf[394]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_i_check_string_2(t5,lf[391]);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t5);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],t3);
t10=(C_word)C_fixnum_plus(t8,t9);
/* extras.scm: 1139 loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* extras.scm: 1141 ##sys#not-a-proper-list-error */
t5=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k6075 in loop1 in k6051 in string-intersperse in k5409 in k1710 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6082,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=lf[393],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_6082(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k6075 in loop1 in k6051 in string-intersperse in k5409 in k1710 */
static C_word C_fcall f_6082(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
C_stack_check;
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k5409 in k1710 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5914r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5914r(t0,t1,t2,t3);}}

static void C_ccall f_5914r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(20);
t4=(C_word)C_i_check_string_2(t2,lf[385]);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?lf[386]:(C_word)C_i_vector_ref(t3,C_fix(0)));
t7=(C_word)C_block_size(t3);
t8=(C_word)C_eqp(t7,C_fix(2));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_string_2(t6,lf[385]);
t12=(C_word)C_block_size(t6);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5935,a[2]=t2,a[3]=t14,a[4]=lf[387],tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5955,a[2]=t6,a[3]=t17,a[4]=t12,a[5]=t2,a[6]=t15,a[7]=t9,a[8]=t14,a[9]=t10,a[10]=lf[389],tmp=(C_word)a,a+=11,tmp));
t19=((C_word*)t17)[1];
f_5955(t19,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k5409 in k1710 */
static void C_fcall f_5955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5955,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5965,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* extras.scm: 1100 add */
t8=((C_word*)t0)[6];
f_5935(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_5965(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5982,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],a[12]=lf[388],tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_5982(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k5409 in k1710 */
static void C_fcall f_5982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5982,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* extras.scm: 1105 loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_5955(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6021,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1109 add */
t8=((C_word*)t0)[3];
f_5935(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* extras.scm: 1110 loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_5955(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* extras.scm: 1111 scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k6019 in scan in loop in string-split in k5409 in k1710 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1109 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5955(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k5963 in loop in string-split in k5409 in k1710 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k5409 in k1710 */
static void C_fcall f_5935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5935,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5950,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1093 ##sys#substring */
t6=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k5948 in add in string-split in k5409 in k1710 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5950,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5942,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_5942(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_5942(t5,t4);}}

/* k5940 in k5948 in add in string-split in k5409 in k1710 */
static void C_fcall f_5942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k5409 in k1710 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5834r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5834r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5836,a[2]=t3,a[3]=t2,a[4]=lf[380],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5841,a[2]=t5,a[3]=lf[381],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5846,a[2]=t6,a[3]=lf[382],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5851,a[2]=t7,a[3]=lf[383],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1916929 */
t9=t8;
f_5851(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2917927 */
t11=t7;
f_5846(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len918924 */
t13=t6;
f_5841(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body914920 */
t15=t5;
f_5836(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1916 in substring-ci=? in k5409 in k1710 */
static void C_fcall f_5851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5851,NULL,2,t0,t1);}
/* def-start2917927 */
t2=((C_word*)t0)[2];
f_5846(t2,t1,C_fix(0));}

/* def-start2917 in substring-ci=? in k5409 in k1710 */
static void C_fcall f_5846(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5846,NULL,3,t0,t1,t2);}
/* def-len918924 */
t3=((C_word*)t0)[2];
f_5841(t3,t1,t2,C_fix(0));}

/* def-len918 in substring-ci=? in k5409 in k1710 */
static void C_fcall f_5841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5841,NULL,4,t0,t1,t2,t3);}
/* body914920 */
t4=((C_word*)t0)[2];
f_5836(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body914 in substring-ci=? in k5409 in k1710 */
static void C_fcall f_5836(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5836,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 1078 ##sys#substring-ci=? */
t5=*((C_word*)lf[377]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring-ci=? in k5409 in k1710 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_5797,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[378]);
t8=(C_word)C_i_check_string_2(t3,lf[378]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5807,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_5807(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_5807(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k5805 in ##sys#substring-ci=? in k5409 in k1710 */
static void C_fcall f_5807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[378]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[378]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* substring=? in k5409 in k1710 */
static void C_ccall f_5717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5717r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5717r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5717r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5719,a[2]=t3,a[3]=t2,a[4]=lf[372],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5724,a[2]=t5,a[3]=lf[373],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5729,a[2]=t6,a[3]=lf[374],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5734,a[2]=t7,a[3]=lf[375],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1875888 */
t9=t8;
f_5734(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2876886 */
t11=t7;
f_5729(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len877883 */
t13=t6;
f_5724(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body873879 */
t15=t5;
f_5719(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-start1875 in substring=? in k5409 in k1710 */
static void C_fcall f_5734(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5734,NULL,2,t0,t1);}
/* def-start2876886 */
t2=((C_word*)t0)[2];
f_5729(t2,t1,C_fix(0));}

/* def-start2876 in substring=? in k5409 in k1710 */
static void C_fcall f_5729(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5729,NULL,3,t0,t1,t2);}
/* def-len877883 */
t3=((C_word*)t0)[2];
f_5724(t3,t1,t2,C_fix(0));}

/* def-len877 in substring=? in k5409 in k1710 */
static void C_fcall f_5724(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5724,NULL,4,t0,t1,t2,t3);}
/* body873879 */
t4=((C_word*)t0)[2];
f_5719(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body873 in substring=? in k5409 in k1710 */
static void C_fcall f_5719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5719,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 1064 ##sys#substring=? */
t5=*((C_word*)lf[369]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring=? in k5409 in k1710 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_5680,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[370]);
t8=(C_word)C_i_check_string_2(t3,lf[370]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5690,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_5690(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_fixnum_difference(t12,t5);
t14=t9;
f_5690(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k5688 in ##sys#substring=? in k5409 in k1710 */
static void C_fcall f_5690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[370]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[370]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* string-compare3-ci in k5409 in k1710 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5649,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[367]);
t5=(C_word)C_i_check_string_2(t3,lf[367]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_string_compare_case_insensitive(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* string-compare3 in k5409 in k1710 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5618,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[365]);
t5=(C_word)C_i_check_string_2(t3,lf[365]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_mem_compare(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* substring-index-ci in k5409 in k1710 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5590r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5590r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5590r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5594,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5594(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5594(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5592 in substring-index-ci in k5409 in k1710 */
static void C_ccall f_5594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1023 ##sys#substring-index-ci */
t2=*((C_word*)lf[359]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* substring-index in k5409 in k1710 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5562r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5562r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5562r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5566,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5566(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5566(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k5564 in substring-index in k5409 in k1710 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 1020 ##sys#substring-index */
t2=*((C_word*)lf[355]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#substring-index-ci in k5409 in k1710 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5553,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5559,a[2]=t3,a[3]=t2,a[4]=lf[360],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1014 traverse */
f_5497(t1,t2,t3,t4,t5,lf[361]);}

/* a5558 in ##sys#substring-index-ci in k5409 in k1710 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5559,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* ##sys#substring-index in k5409 in k1710 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5544,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5550,a[2]=t3,a[3]=t2,a[4]=lf[356],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 1008 traverse */
f_5497(t1,t2,t3,t4,t5,lf[357]);}

/* a5549 in ##sys#substring-index in k5409 in k1710 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5550,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k5409 in k1710 */
static void C_fcall f_5497(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5497,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,t6);
t8=(C_word)C_i_check_string_2(t3,t6);
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_exact_2(t4,t6);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5518,a[2]=t10,a[3]=t5,a[4]=t13,a[5]=t9,a[6]=lf[353],tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_5518(t15,t1,t4,t10);}

/* loop in traverse in k5409 in k1710 */
static void C_fcall f_5518(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5518,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5531,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 1002 test */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k5529 in loop in traverse in k5409 in k1710 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 1004 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5518(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k5409 in k1710 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5487r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5487r(t0,t1,t2);}}

static void C_ccall f_5487r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[348]+1),t2);}

/* k5493 in conc in k5409 in k1710 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k5409 in k1710 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5442,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* extras.scm: 977  symbol->string */
t3=*((C_word*)lf[349]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
/* extras.scm: 978  string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* extras.scm: 979  ##sys#number->string */
t3=*((C_word*)lf[258]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5479,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 981  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}}}}

/* k5477 in ->string in k5409 in k1710 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5482,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 982  display */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5480 in k5477 in ->string in k5409 in k1710 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 983  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pretty-print in k5409 in k1710 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5413r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5413r(t0,t1,t2,t3);}}

static void C_ccall f_5413r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5417,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_5417(2,t5,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
/* extras.scm: 961  current-output-port */
t5=*((C_word*)lf[345]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5415 in pretty-print in k5409 in k1710 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5424,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 962  pretty-print-width */
t4=*((C_word*)lf[342]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5422 in k5415 in pretty-print in k5409 in k1710 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5426,a[2]=((C_word*)t0)[4],a[3]=lf[344],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 962  generic-write */
t3=*((C_word*)lf[231]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a5425 in k5422 in k5415 in pretty-print in k5409 in k1710 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5426,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 962  display */
t4=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k5428 in a5425 in k5422 in k5415 in pretty-print in k5409 in k1710 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k5418 in k5415 in pretty-print in k5409 in k1710 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##extras#reverse-string-append in k1710 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5332,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=t4,a[3]=lf[340],tmp=(C_word)a,a+=4,tmp));
/* extras.scm: 953  rev-string-append */
t6=((C_word*)t4)[1];
f_5335(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##extras#reverse-string-append in k1710 */
static void C_fcall f_5335(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5335,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_length(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5351,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* extras.scm: 944  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* extras.scm: 951  make-string */
t4=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k5349 in rev-string-append in ##extras#reverse-string-append in k1710 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5351,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5360,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[339],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5360(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k5349 in rev-string-append in ##extras#reverse-string-append in k1710 */
static void C_fcall f_5360(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5360,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t5=(C_word)C_i_string_set(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* extras.scm: 949  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* ##extras#generic-write in k1710 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4060,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4063,a[2]=lf[236],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=lf[237],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=lf[242],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4154,a[2]=t5,a[3]=lf[243],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4173,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t9,a[9]=t11,a[10]=lf[287],tmp=(C_word)a,a+=11,tmp));
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4676,a[2]=t6,a[3]=t8,a[4]=t7,a[5]=t11,a[6]=t4,a[7]=t3,a[8]=t9,a[9]=lf[337],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5323,a[2]=t2,a[3]=t13,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 933  make-string */
t15=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(1),C_make_character(10));}
else{
/* extras.scm: 934  wr */
t14=((C_word*)t11)[1];
f_4173(t14,t1,t2,C_fix(0));}}

/* k5321 in ##extras#generic-write in k1710 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5327,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 933  pp */
t3=((C_word*)t0)[3];
f_4676(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5325 in k5321 in ##extras#generic-write in k1710 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 933  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in ##extras#generic-write in k1710 */
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[151],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4676,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=lf[290],tmp=(C_word)a,a+=5,tmp));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=lf[291],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[8],a[8]=lf[296],tmp=(C_word)a,a+=9,tmp));
t41=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word*)t0)[4],a[12]=lf[298],tmp=(C_word)a,a+=13,tmp));
t42=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t17,a[5]=lf[300],tmp=(C_word)a,a+=6,tmp));
t43=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[8],a[3]=t17,a[4]=lf[302],tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=t9,a[5]=lf[307],tmp=(C_word)a,a+=6,tmp));
t45=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t9,a[6]=t17,a[7]=lf[313],tmp=(C_word)a,a+=8,tmp));
t46=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5158,a[2]=t11,a[3]=t15,a[4]=lf[314],tmp=(C_word)a,a+=5,tmp));
t47=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5164,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=lf[315],tmp=(C_word)a,a+=6,tmp));
t48=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5170,a[2]=t11,a[3]=t19,a[4]=lf[316],tmp=(C_word)a,a+=5,tmp));
t49=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5176,a[2]=t21,a[3]=t13,a[4]=lf[317],tmp=(C_word)a,a+=5,tmp));
t50=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5182,a[2]=t21,a[3]=t11,a[4]=t19,a[5]=lf[318],tmp=(C_word)a,a+=6,tmp));
t51=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5188,a[2]=t11,a[3]=t13,a[4]=lf[319],tmp=(C_word)a,a+=5,tmp));
t52=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5194,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=lf[320],tmp=(C_word)a,a+=6,tmp));
t53=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5216,a[2]=t11,a[3]=t19,a[4]=lf[321],tmp=(C_word)a,a+=5,tmp));
t54=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5222,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=lf[322],tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5231,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,a[10]=lf[336],tmp=(C_word)a,a+=11,tmp));
/* extras.scm: 930  pr */
t56=((C_word*)t9)[1];
f_4744(t56,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in ##extras#generic-write in k1710 */
static void C_fcall f_5231(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5231,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[323]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_5241(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t5)){
t6=t4;
f_5241(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[334]);
t7=t4;
f_5241(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[335])));}}}

/* k5239 in style in pp in ##extras#generic-write in k1710 */
static void C_fcall f_5241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[324]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[325]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[326]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[327]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[328]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[329]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[330]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[331]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[332]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5222,5,t0,t1,t2,t3,t4);}
/* extras.scm: 908  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5010(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5216,5,t0,t1,t2,t3,t4);}
/* extras.scm: 905  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5010(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5194,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_5201(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5201(t7,C_SCHEME_FALSE);}}

/* k5199 in pp-let in pp in ##extras#generic-write in k1710 */
static void C_fcall f_5201(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 902  pp-general */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5010(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-and in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5188,5,t0,t1,t2,t3,t4);}
/* extras.scm: 897  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4896(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5182,5,t0,t1,t2,t3,t4);}
/* extras.scm: 894  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5010(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5176,5,t0,t1,t2,t3,t4);}
/* extras.scm: 891  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4896(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5170,5,t0,t1,t2,t3,t4);}
/* extras.scm: 888  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5010(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5164,5,t0,t1,t2,t3,t4);}
/* extras.scm: 885  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5010(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5158,5,t0,t1,t2,t3,t4);}
/* extras.scm: 882  pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4924(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in ##extras#generic-write in k1710 */
static void C_fcall f_5010(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5010,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5095,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=lf[308],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,a[5]=t4,a[6]=t7,a[7]=lf[309],tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t4,a[6]=t6,a[7]=lf[310],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_i_cdr(t2);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t11,a[6]=t3,a[7]=t13,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t12,a[3]=t14,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 873  out */
t16=((C_word*)t0)[2];
f_4154(t16,t15,lf[312],t3);}

/* k5154 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 873  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4173(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5106 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5123,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5138,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 877  out */
t7=((C_word*)t0)[2];
f_4154(t7,t6,lf[311],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 879  tail1 */
t5=((C_word*)t0)[5];
f_5013(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k5136 in k5106 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 877  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4173(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5121 in k5106 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5123,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 878  tail1 */
t4=((C_word*)t0)[4];
f_5013(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail1 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5013,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5036,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5040,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 857  indent */
t13=((C_word*)t0)[2];
f_4712(t13,t12,t5,t4);}
else{
/* extras.scm: 858  tail2 */
t7=((C_word*)t0)[4];
f_5054(t7,t1,t2,t3,t4,t5);}}

/* k5038 in tail1 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 857  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4744(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5034 in tail1 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 857  tail2 */
t2=((C_word*)t0)[6];
f_5054(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_fcall f_5054(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5054,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5077,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 865  indent */
t13=((C_word*)t0)[2];
f_4712(t13,t12,t5,t4);}
else{
/* extras.scm: 866  tail3 */
t7=((C_word*)t0)[4];
f_5095(t7,t1,t2,t3,t4);}}

/* k5079 in tail2 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 865  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4744(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5075 in tail2 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 865  tail3 */
t2=((C_word*)t0)[5];
f_5095(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail3 in pp-general in pp in ##extras#generic-write in k1710 */
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5095,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 869  pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4933(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-down in pp in ##extras#generic-write in k1710 */
static void C_fcall f_4933(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4933,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,a[9]=lf[306],tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4939(t10,t1,t2,t3);}

/* loop in pp-down in pp in ##extras#generic-write in k1710 */
static void C_fcall f_4939(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4939,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4962,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 840  indent */
t10=((C_word*)t0)[4];
f_4712(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 842  out */
t4=((C_word*)t0)[2];
f_4154(t4,t1,lf[303],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4992,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5008,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 846  indent */
t8=((C_word*)t0)[4];
f_4712(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5006 in loop in pp-down in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 846  out */
t2=((C_word*)t0)[3];
f_4154(t2,((C_word*)t0)[2],lf[305],t1);}

/* k5002 in loop in pp-down in pp in ##extras#generic-write in k1710 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 846  indent */
t2=((C_word*)t0)[4];
f_4712(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4994 in loop in pp-down in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm: 845  pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4744(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k4990 in loop in pp-down in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 844  out */
t2=((C_word*)t0)[3];
f_4154(t2,((C_word*)t0)[2],lf[304],t1);}

/* k4968 in loop in pp-down in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 840  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4744(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4960 in loop in pp-down in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 839  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4939(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in ##extras#generic-write in k1710 */
static void C_fcall f_4924(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4924,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4928,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 830  out */
t7=((C_word*)t0)[2];
f_4154(t7,t6,lf[301],t3);}

/* k4926 in pp-list in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 831  pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4933(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in ##extras#generic-write in k1710 */
static void C_fcall f_4896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4896,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4900,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4922,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 822  out */
t9=((C_word*)t0)[2];
f_4154(t9,t8,lf[299],t3);}

/* k4920 in pp-call in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 822  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4173(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4898 in pp-call in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 824  pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4933(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4831,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* extras.scm: 802  read-macro? */
f_4063(t5,t2);}

/* k4836 in pp-expr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4838,2,t0,t1);}
if(C_truep(t1)){
t2=f_4115(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t4=f_4121(((C_word*)t0)[13]);
/* extras.scm: 804  out */
t5=((C_word*)t0)[7];
f_4154(t5,t3,t4,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4865,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 809  style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5231(t4,t3,t2);}
else{
/* extras.scm: 816  pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4924(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k4863 in k4836 in pp-expr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm: 811  proc */
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 812  ##sys#symbol->qualified-string */
t3=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4889 in k4863 in k4836 in pp-expr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
/* extras.scm: 814  pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_5010(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm: 815  pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4896(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k4847 in k4836 in pp-expr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 803  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4744(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in ##extras#generic-write in k1710 */
static void C_fcall f_4744(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4744,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm: 788  max */
t14=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t13,C_fix(50));}
else{
/* extras.scm: 799  wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4173(t8,t1,t2,t3);}}

/* k4755 in pr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4795,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=lf[294],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 789  generic-write */
t6=*((C_word*)lf[231]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a4794 in k4755 in pr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4795,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_i_string_length(t2);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k4758 in k4755 in pr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 795  reverse-string-append */
t3=*((C_word*)lf[292]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm: 797  pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 798  vector->list */
t3=*((C_word*)lf[255]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k4787 in k4758 in k4755 in pr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 798  out */
t3=((C_word*)t0)[3];
f_4154(t3,t2,lf[293],((C_word*)t0)[2]);}

/* k4791 in k4787 in k4758 in k4755 in pr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 798  pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4924(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k4771 in k4758 in k4755 in pr in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 795  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in ##extras#generic-write in k1710 */
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4712,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4735,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 782  make-string */
t6=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
/* extras.scm: 783  spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4679(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4733 in indent in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 782  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4726 in indent in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 782  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4679(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in ##extras#generic-write in k1710 */
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4679,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4703,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 775  out */
t6=((C_word*)t0)[2];
f_4154(t6,t5,lf[288],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4710,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 776  ##sys#substring */
t5=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[289],C_fix(0),t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4708 in spaces in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 776  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4701 in spaces in pp in ##extras#generic-write in k1710 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 775  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4679(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in ##extras#generic-write in k1710 */
static void C_fcall f_4173(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4173,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=lf[251],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],a[8]=lf[252],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
/* extras.scm: 708  wr-expr */
t6=t5;
f_4176(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 709  wr-lst */
t6=t4;
f_4203(t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
/* extras.scm: 710  out */
t6=((C_word*)t0)[8];
f_4154(t6,t1,lf[253],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4329,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 711  vector->list */
t7=*((C_word*)lf[255]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=(C_truep(t2)?lf[256]:lf[257]);
/* extras.scm: 712  out */
t7=((C_word*)t0)[8];
f_4154(t7,t1,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 713  ##sys#number? */
t7=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}}}}}

/* k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 713  ##sys#number->string */
t3=*((C_word*)lf[258]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 715  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 718  ##sys#procedure->string */
t3=*((C_word*)lf[260]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 720  out */
t2=((C_word*)t0)[8];
f_4154(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 721  out */
t3=((C_word*)t0)[8];
f_4154(t3,t2,lf[264],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 735  make-string */
t3=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 737  out */
t4=((C_word*)t0)[8];
f_4154(t4,t3,lf[269],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
/* extras.scm: 748  out */
t2=((C_word*)t0)[8];
f_4154(t2,((C_word*)t0)[7],lf[270],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
/* extras.scm: 749  out */
t2=((C_word*)t0)[8];
f_4154(t2,((C_word*)t0)[7],lf[271],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 750  ##sys#pointer->string */
t3=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(lf[273],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* extras.scm: 752  out */
t4=((C_word*)t0)[8];
f_4154(t4,((C_word*)t0)[7],lf[274],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 754  open-output-string */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 757  port? */
t5=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}}}}}}}}}}

/* k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm: 757  string-append */
t4=*((C_word*)lf[276]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[277],t3,lf[278]);}
else{
if(C_truep((C_word)C_bytevectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[2]))){
/* extras.scm: 760  out */
t3=((C_word*)t0)[5];
f_4154(t3,t2,lf[280],((C_word*)t0)[3]);}
else{
/* extras.scm: 761  out */
t3=((C_word*)t0)[5];
f_4154(t3,t2,lf[281],((C_word*)t0)[3]);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 765  out */
t3=((C_word*)t0)[5];
f_4154(t3,t2,lf[284],((C_word*)t0)[3]);}
else{
/* extras.scm: 768  out */
t2=((C_word*)t0)[5];
f_4154(t2,((C_word*)t0)[4],lf[285],((C_word*)t0)[3]);}}}}

/* k4655 in k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 766  ##sys#lambda-info->string */
t4=*((C_word*)lf[283]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4665 in k4655 in k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 766  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4658 in k4655 in k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 767  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],lf[282],((C_word*)t0)[2]);}

/* k4633 in k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 762  number->string */
C_number_to_string(3,0,t3,(C_word)C_block_size(((C_word*)t0)[2]));}

/* k4643 in k4633 in k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 762  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4636 in k4633 in k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 763  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],lf[279],((C_word*)t0)[2]);}

/* k4623 in k4616 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 757  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4600 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4605,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 755  ##sys#user-print-hook */
t3=*((C_word*)lf[275]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k4603 in k4600 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 756  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4610 in k4603 in k4600 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 756  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4582 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 750  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4498 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 738  char-name */
t3=*((C_word*)lf[268]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4501 in k4498 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
/* extras.scm: 740  out */
t3=((C_word*)t0)[6];
f_4154(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 742  out */
t3=((C_word*)t0)[6];
f_4154(t3,t2,lf[265],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535));
t4=(C_truep(t3)?lf[266]:lf[267]);
/* extras.scm: 745  out */
t5=((C_word*)t0)[6];
f_4154(t5,t2,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 747  make-string */
t3=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k4557 in k4501 in k4498 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 747  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4536 in k4501 in k4498 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 746  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k4543 in k4536 in k4501 in k4498 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 746  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4520 in k4501 in k4498 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 743  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k4527 in k4520 in k4501 in k4498 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 743  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4492 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 735  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=lf[263],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4412(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_fcall f_4412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4412,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4419,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_string_length(((C_word*)t0)[4]);
t7=t5;
f_4419(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_4419(t6,C_SCHEME_FALSE);}}

/* k4417 in loop in k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_fcall f_4419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4419,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4442,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4446,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 729  ##sys#substring */
t9=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm: 731  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4412(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4467,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 733  ##sys#substring */
t4=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k4469 in k4417 in loop in k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 733  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4465 in k4417 in loop in k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 732  out */
t2=((C_word*)t0)[3];
f_4154(t2,((C_word*)t0)[2],lf[262],t1);}

/* k4448 in k4417 in loop in k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 729  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4444 in k4417 in loop in k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 728  out */
t2=((C_word*)t0)[3];
f_4154(t2,((C_word*)t0)[2],lf[261],t1);}

/* k4440 in k4417 in loop in k4408 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 726  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4412(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4389 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 718  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4366 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4371,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 716  ##sys#print */
t3=*((C_word*)lf[259]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k4369 in k4366 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 717  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4376 in k4369 in k4366 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 717  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4357 in k4350 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 713  out */
t2=((C_word*)t0)[4];
f_4154(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4327 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4333,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 711  out */
t3=((C_word*)t0)[3];
f_4154(t3,t2,lf[254],((C_word*)t0)[2]);}

/* k4331 in k4327 in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 711  wr-lst */
t2=((C_word*)t0)[4];
f_4203(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in ##extras#generic-write in k1710 */
static void C_fcall f_4176(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4176,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 693  read-macro? */
f_4063(t4,t2);}

/* k4181 in wr-expr in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
if(C_truep(t1)){
t2=f_4115(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=f_4121(((C_word*)t0)[8]);
/* extras.scm: 694  out */
t5=((C_word*)t0)[4];
f_4154(t5,t3,t4,((C_word*)t0)[3]);}
else{
/* extras.scm: 695  wr-lst */
t2=((C_word*)t0)[2];
f_4203(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k4192 in k4181 in wr-expr in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 694  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4173(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in ##extras#generic-write in k1710 */
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4203,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4221,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4286,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 700  out */
t8=((C_word*)t0)[2];
f_4154(t8,t7,lf[249],t3);}
else{
t6=t5;
f_4221(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm: 706  out */
t4=((C_word*)t0)[2];
f_4154(t4,t1,lf[250],t3);}}

/* k4284 in wr-lst in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 700  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4173(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4219 in wr-lst in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=lf[248],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4223(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4219 in wr-lst in wr in ##extras#generic-write in k1710 */
static void C_fcall f_4223(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4223,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4247,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4255,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 703  out */
t9=((C_word*)t0)[2];
f_4154(t9,t8,lf[244],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 704  out */
t5=((C_word*)t0)[2];
f_4154(t5,t1,lf[245],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4275,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 705  out */
t7=((C_word*)t0)[2];
f_4154(t7,t6,lf[247],t3);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* k4273 in loop in k4219 in wr-lst in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 705  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4173(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4269 in loop in k4219 in wr-lst in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 705  out */
t2=((C_word*)t0)[3];
f_4154(t2,((C_word*)t0)[2],lf[246],t1);}

/* k4253 in loop in k4219 in wr-lst in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 703  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4173(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4245 in loop in k4219 in wr-lst in wr in ##extras#generic-write in k1710 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 703  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4223(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in ##extras#generic-write in k1710 */
static void C_fcall f_4154(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4154,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4164,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 688  output */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4162 in out in ##extras#generic-write in k1710 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in ##extras#generic-write in k1710 */
static C_word C_fcall f_4121(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_eqp(t2,lf[232]);
if(C_truep(t4)){
return(lf[238]);}
else{
t5=(C_word)C_eqp(t2,lf[233]);
if(C_truep(t5)){
return(lf[239]);}
else{
t6=(C_word)C_eqp(t2,lf[234]);
if(C_truep(t6)){
return(lf[240]);}
else{
t7=(C_word)C_eqp(t2,lf[235]);
return((C_truep(t7)?lf[241]:C_SCHEME_UNDEFINED));}}}}

/* read-macro-body in ##extras#generic-write in k1710 */
static C_word C_fcall f_4115(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_i_cadr(t1));}

/* read-macro? in ##extras#generic-write in k1710 */
static void C_fcall f_4063(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4063,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,lf[232]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4095,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_4095(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[233]);
if(C_truep(t7)){
t8=t6;
f_4095(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[234]);
t9=t6;
f_4095(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[235])));}}}

/* k4093 in read-macro? in ##extras#generic-write in k1710 */
static void C_fcall f_4095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* make-output-port in k1710 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+33)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4002r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4002r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4002r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(33);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[225],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4030,a[2]=t2,a[3]=lf[226],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4036,a[2]=t3,a[3]=lf[227],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4045,a[2]=t6,a[3]=lf[228],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_vector(&a,9,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,t8,t9,t10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t12=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4015,a[2]=t1,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 650  ##sys#make-port */
t14=*((C_word*)lf[215]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,C_SCHEME_FALSE,t11,lf[229],lf[217]);}

/* k4013 in make-output-port in k1710 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4044 in make-output-port in k1710 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4045,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 645  flush */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a4035 in make-output-port in k1710 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4036,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4040,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 642  close */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4038 in a4035 in make-output-port in k1710 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a4029 in make-output-port in k1710 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4030,4,t0,t1,t2,t3);}
/* extras.scm: 640  write */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4019 in make-output-port in k1710 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4020,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 638  string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k4026 in a4019 in make-output-port in k1710 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 638  write */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* make-input-port in k1710 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_3856r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3856r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3856r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3858,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=lf[218],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3929,a[2]=t6,a[3]=lf[219],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3934,a[2]=t7,a[3]=lf[220],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3939,a[2]=t8,a[3]=lf[221],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-peek478505 */
t10=t9;
f_3939(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-read-string479503 */
t12=t8;
f_3934(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-read-line480500 */
t14=t7;
f_3929(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body476482 */
t16=t6;
f_3858(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-peek478 in make-input-port in k1710 */
static void C_fcall f_3939(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3939,NULL,2,t0,t1);}
/* def-read-string479503 */
t2=((C_word*)t0)[2];
f_3934(t2,t1,C_SCHEME_FALSE);}

/* def-read-string479 in make-input-port in k1710 */
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3934,NULL,3,t0,t1,t2);}
/* def-read-line480500 */
t3=((C_word*)t0)[2];
f_3929(t3,t1,t2,C_SCHEME_FALSE);}

/* def-read-line480 in make-input-port in k1710 */
static void C_fcall f_3929(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3929,NULL,4,t0,t1,t2,t3);}
/* body476482 */
t4=((C_word*)t0)[2];
f_3858(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body476 in make-input-port in k1710 */
static void C_fcall f_3858(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3858,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[211],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[212],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[3],a[3]=lf[213],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=lf[214],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_a_i_vector(&a,9,t5,t6,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,C_SCHEME_FALSE,t8,t3,t4);
t10=(C_word)C_a_i_vector(&a,1,C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3868,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 625  ##sys#make-port */
t12=*((C_word*)lf[215]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t11,C_SCHEME_TRUE,t9,lf[216],lf[217]);}

/* k3866 in body476 in make-input-port in k1710 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3923 in body476 in make-input-port in k1710 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3924,3,t0,t1,t2);}
/* extras.scm: 621  ready? */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a3914 in body476 in make-input-port in k1710 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3915,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3919,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 617  close */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3917 in a3914 in body476 in make-input-port in k1710 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a3893 in body476 in make-input-port in k1710 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3894,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 608  peek */
t4=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3910,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 611  read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}}

/* k3908 in a3893 in body476 in make-input-port in k1710 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(10),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3872 in body476 in make-input-port in k1710 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3873,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* extras.scm: 601  read */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=(C_word)C_i_set_i_slot(t2,C_fix(10),C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* extras.scm: 605  read */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}}}

/* with-output-to-string in k1710 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3826,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 584  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3824 in with-output-to-string in k1710 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3831,a[2]=t3,a[3]=t5,a[4]=lf[206],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[207],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3848,a[2]=t5,a[3]=t3,a[4]=lf[208],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3847 in k3824 in with-output-to-string in k1710 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3848,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[165]+1));
t3=C_mutate((C_word*)lf[165]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a3838 in k3824 in with-output-to-string in k1710 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3843,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 585  thunk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3841 in a3838 in k3824 in with-output-to-string in k1710 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 586  get-output-string */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],*((C_word*)lf[165]+1));}

/* a3830 in k3824 in with-output-to-string in k1710 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[165]+1));
t3=C_mutate((C_word*)lf[165]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* with-input-from-string in k1710 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3791,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3795,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 577  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3793 in with-input-from-string in k1710 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3795,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3800,a[2]=t3,a[3]=t5,a[4]=lf[201],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[3],a[3]=lf[202],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3814,a[2]=t5,a[3]=t3,a[4]=lf[203],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3813 in k3793 in with-input-from-string in k1710 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[13]+1));
t3=C_mutate((C_word*)lf[13]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a3807 in k3793 in with-input-from-string in k1710 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3808,2,t0,t1);}
/* extras.scm: 578  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3799 in k3793 in with-input-from-string in k1710 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[13]+1));
t3=C_mutate((C_word*)lf[13]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* call-with-output-string in k1710 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3779,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3783,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 570  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3781 in call-with-output-string in k1710 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3786,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 571  proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k3784 in k3781 in call-with-output-string in k1710 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 572  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-input-string in k1710 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3770,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3774,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 563  open-input-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3772 in call-with-input-string in k1710 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 564  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* with-error-output-to-port in k1710 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3739,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3743,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 553  ##sys#check-port */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[193]);}

/* k3741 in with-error-output-to-port in k1710 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3748,a[2]=t3,a[3]=t5,a[4]=lf[190],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[3],a[3]=lf[191],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3762,a[2]=t5,a[3]=t3,a[4]=lf[192],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 554  ##sys#dynamic-wind */
t9=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3761 in k3741 in with-error-output-to-port in k1710 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3762,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[189]+1));
t3=C_mutate((C_word*)lf[189]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a3755 in k3741 in with-error-output-to-port in k1710 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3756,2,t0,t1);}
/* extras.scm: 555  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3747 in k3741 in with-error-output-to-port in k1710 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[189]+1));
t3=C_mutate((C_word*)lf[189]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* with-output-to-port in k1710 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3708,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3712,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 548  ##sys#check-port */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[186]);}

/* k3710 in with-output-to-port in k1710 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3717,a[2]=t3,a[3]=t5,a[4]=lf[183],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3725,a[2]=((C_word*)t0)[3],a[3]=lf[184],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3731,a[2]=t5,a[3]=t3,a[4]=lf[185],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 549  ##sys#dynamic-wind */
t9=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3730 in k3710 in with-output-to-port in k1710 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[165]+1));
t3=C_mutate((C_word*)lf[165]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a3724 in k3710 in with-output-to-port in k1710 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
/* extras.scm: 550  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3716 in k3710 in with-output-to-port in k1710 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[165]+1));
t3=C_mutate((C_word*)lf[165]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* with-input-from-port in k1710 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3677,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3681,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 543  ##sys#check-port */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[176]);}

/* k3679 in with-input-from-port in k1710 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3686,a[2]=t3,a[3]=t5,a[4]=lf[177],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[3],a[3]=lf[178],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=t5,a[3]=t3,a[4]=lf[179],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 544  ##sys#dynamic-wind */
t9=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3699 in k3679 in with-input-from-port in k1710 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[13]+1));
t3=C_mutate((C_word*)lf[13]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* a3693 in k3679 in with-input-from-port in k1710 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
/* extras.scm: 545  thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3685 in k3679 in with-input-from-port in k1710 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[13]+1));
t3=C_mutate((C_word*)lf[13]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[2]+1));}

/* write-byte in k1710 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3639r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3639r(t0,t1,t2,t3);}}

static void C_ccall f_3639r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3643,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3643(2,t5,*((C_word*)lf[165]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3643(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3641 in write-byte in k1710 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3643,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[174]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3649,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 536  ##sys#check-port */
t4=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[174]);}

/* k3647 in k3641 in write-byte in k1710 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[4]));
/* extras.scm: 537  ##sys#write-char-0 */
t3=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* read-byte in k1710 */
static void C_ccall f_3599(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3599r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3599r(t0,t1,t2);}}

static void C_ccall f_3599r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3603,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3603(2,t4,*((C_word*)lf[13]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3603(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3601 in read-byte in k1710 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 528  ##sys#check-port */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[172]);}

/* k3604 in k3601 in read-byte in k1710 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 529  ##sys#read-char-0 */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3607 in k3604 in k3601 in read-byte in k1710 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t1:(C_word)C_fix((C_word)C_character_code(t1))));}

/* write-line in k1710 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3578r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3578r(t0,t1,t2,t3);}}

static void C_ccall f_3578r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[165]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3585,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 519  ##sys#check-port */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[170]);}

/* k3583 in write-line in k1710 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3585,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[170]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 521  display */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k3589 in k3583 in write-line in k1710 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 522  newline */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k1710 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3489r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3489r(t0,t1,t2,t3);}}

static void C_ccall f_3489r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t4=(C_word)C_i_check_string_2(t2,lf[163]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3494,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[164],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3525,a[2]=t5,a[3]=lf[166],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3530,a[2]=t6,a[3]=lf[167],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* extras.scm: 503  def-n364 */
t8=t7;
f_3530(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* extras.scm: 503  def-port365 */
t10=t6;
f_3525(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* extras.scm: 503  body362 */
t12=t5;
f_3494(t12,t1,t8,t10);}
else{
/* extras.scm: 503  ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-n364 in write-string in k1710 */
static void C_fcall f_3530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3530,NULL,2,t0,t1);}
/* extras.scm: 503  def-port365 */
t2=((C_word*)t0)[2];
f_3525(t2,t1,C_SCHEME_FALSE);}

/* def-port365 in write-string in k1710 */
static void C_fcall f_3525(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3525,NULL,3,t0,t1,t2);}
/* extras.scm: 503  body362 */
t3=((C_word*)t0)[2];
f_3494(t3,t1,t2,*((C_word*)lf[165]+1));}

/* body362 in write-string in k1710 */
static void C_fcall f_3494(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3494,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 504  ##sys#check-port */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[163]);}

/* k3496 in body362 in write-string in k1710 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[163]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(C_word)C_block_size(((C_word*)t0)[2]);
t6=t4;
f_3511(t6,(C_word)C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_3511(t5,C_SCHEME_FALSE);}}

/* k3509 in k3496 in body362 in write-string in k1710 */
static void C_fcall f_3511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 508  ##sys#substring */
t2=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3508(2,t2,((C_word*)t0)[3]);}}

/* k3506 in k3496 in body362 in write-string in k1710 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 506  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k1710 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_3420r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3420r(t0,t1,t2,t3);}}

static void C_ccall f_3420r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3424(2,t5,*((C_word*)lf[13]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3424(2,t6,(C_word)C_i_car(t3));}
else{
/* extras.scm: 488  ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3422 in read-token in k1710 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 489  ##sys#check-port */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[157]);}

/* k3425 in k3422 in read-token in k1710 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 490  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3428 in k3425 in k3422 in read-token in k1710 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=lf[160],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3435(t5,((C_word*)t0)[2]);}

/* loop in k3428 in k3425 in k3422 in read-token in k1710 */
static void C_fcall f_3435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3435,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 492  ##sys#peek-char-0 */
t3=*((C_word*)lf[159]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k3437 in loop in k3428 in k3425 in k3422 in read-token in k1710 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_3445(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm: 493  pred */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3443 in k3437 in loop in k3428 in k3425 in k3422 in read-token in k1710 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 495  ##sys#read-char-0 */
t4=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* extras.scm: 497  get-output-string */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k3453 in k3443 in k3437 in loop in k3428 in k3425 in k3422 in read-token in k1710 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 495  ##sys#write-char-0 */
t2=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3446 in k3443 in k3437 in loop in k3428 in k3425 in k3422 in read-token in k1710 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 496  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3435(t2,((C_word*)t0)[2]);}

/* read-string in k1710 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_3360r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3360r(t0,t1,t2);}}

static void C_ccall f_3360r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=lf[153],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3367,a[2]=t3,a[3]=lf[154],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3372,a[2]=t4,a[3]=lf[155],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n331339 */
t6=t5;
f_3372(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-port332337 */
t8=t4;
f_3367(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body329334 */
f_3362(t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n331 in read-string in k1710 */
static void C_fcall f_3372(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3372,NULL,2,t0,t1);}
/* def-port332337 */
t2=((C_word*)t0)[2];
f_3367(t2,t1,C_SCHEME_FALSE);}

/* def-port332 in read-string in k1710 */
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3367,NULL,3,t0,t1,t2);}
/* body329334 */
f_3362(t1,t2,*((C_word*)lf[13]+1));}

/* body329 in read-string in k1710 */
static void C_fcall f_3362(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,3,t1,t2,t3);}
/* extras.scm: 482  ##sys#read-string/port */
t4=*((C_word*)lf[148]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* ##sys#read-string/port in k1710 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3287,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 463  ##sys#check-port */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[149]);}

/* k3289 in ##sys#read-string/port in k1710 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[149]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3300,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 465  ##sys#make-string */
t4=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 471  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k3313 in k3289 in ##sys#read-string/port in k1710 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=lf[151],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3320(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k3313 in k3289 in ##sys#read-string/port in k1710 */
static void C_fcall f_3320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3320,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 473  get-output-string */
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[4]);}
else{
t5=t3;
f_3324(2,t5,C_SCHEME_FALSE);}}

/* k3322 in loop in k3313 in k3289 in ##sys#read-string/port in k1710 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3324,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 474  ##sys#read-char-0 */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3328 in k3322 in loop in k3313 in k3289 in ##sys#read-string/port in k1710 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3330,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 476  get-output-string */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3342,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 478  ##sys#write-char/port */
t3=*((C_word*)lf[150]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[4]);}}

/* k3340 in k3328 in k3322 in loop in k3313 in k3289 in ##sys#read-string/port in k1710 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
/* extras.scm: 479  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3320(t3,((C_word*)t0)[2],t2);}

/* k3298 in k3289 in ##sys#read-string/port in k1710 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3303,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 466  ##sys#read-string! */
t3=*((C_word*)lf[138]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[2],C_fix(0));}

/* k3301 in k3298 in k3289 in ##sys#read-string/port in k1710 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 469  ##sys#substring */
t3=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* read-string! in k1710 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_3190r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3190r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3192,a[2]=t5,a[3]=t3,a[4]=lf[142],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3234,a[2]=t6,a[3]=lf[143],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3239,a[2]=t7,a[3]=lf[144],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port291304 */
t9=t8;
f_3239(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start292302 */
t11=t7;
f_3234(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body289294 */
t13=t6;
f_3192(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port291 in read-string! in k1710 */
static void C_fcall f_3239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3239,NULL,2,t0,t1);}
/* def-start292302 */
t2=((C_word*)t0)[2];
f_3234(t2,t1,*((C_word*)lf[13]+1));}

/* def-start292 in read-string! in k1710 */
static void C_fcall f_3234(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3234,NULL,3,t0,t1,t2);}
/* body289294 */
t3=((C_word*)t0)[2];
f_3192(t3,t1,t2,C_fix(0));}

/* body289 in read-string! in k1710 */
static void C_fcall f_3192(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3192,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3196,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 450  ##sys#check-port */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[141]);}

/* k3194 in body289 in read-string! in k1710 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3196,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[141]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[141]);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
t6=(C_word)C_block_size(((C_word*)t0)[6]);
if(C_truep((C_word)C_fixnum_greaterp(t5,t6))){
t7=(C_word)C_block_size(((C_word*)t0)[6]);
t8=(C_word)C_fixnum_difference(t7,((C_word*)t0)[5]);
t9=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t10=t3;
f_3202(t10,t9);}
else{
t7=t3;
f_3202(t7,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3202(t4,C_SCHEME_UNDEFINED);}}

/* k3200 in k3194 in body289 in read-string! in k1710 */
static void C_fcall f_3202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[141]);
/* extras.scm: 457  ##sys#read-string! */
t3=*((C_word*)lf[138]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* ##sys#read-string! in k1710 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3100,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3110,a[2]=t2,a[3]=t6,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(t4,C_fix(6)))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3184,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 432  ##sys#read-char-0 */
t10=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t8;
f_3110(t9,C_SCHEME_UNDEFINED);}}}

/* k3182 in ##sys#read-string! in k1710 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3110(t5,t4);}

/* k3108 in ##sys#read-string! in k1710 */
static void C_fcall f_3110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3110,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(7));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t5,a[6]=lf[139],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3118(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}

/* loop in k3108 in ##sys#read-string! in k1710 */
static void C_fcall f_3118(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3118,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
/* extras.scm: 437  rdstring */
t6=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t0)[3],t3,((C_word*)t0)[2],t2);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3167,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 438  ##sys#read-char-0 */
t7=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}}

/* k3165 in loop in k3108 in ##sys#read-string! in k1710 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
f_3122(2,t2,C_fix(0));}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[4];
f_3122(2,t3,C_fix(1));}}

/* k3120 in loop in k3108 in ##sys#read-string! in k1710 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_i_not(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t4)){
t5=(C_word)C_fixnum_plus(((C_word*)t0)[3],t1);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* extras.scm: 446  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3118(t8,((C_word*)t0)[6],t5,t6,t7);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_plus(t1,((C_word*)t0)[5]));}}}

/* read-lines in k1710 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_3010r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3010r(t0,t1,t2);}}

static void C_ccall f_3010r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[13]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=lf[136],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
/* extras.scm: 420  call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 422  ##sys#check-port */
t11=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t4,lf[134]);}}

/* k3075 in read-lines in k1710 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 423  doread */
t2=((C_word*)t0)[4];
f_3022(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k1710 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3022,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(1000000));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3032,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=lf[135],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3032(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in doread in read-lines in k1710 */
static void C_fcall f_3032(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3032,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 414  reverse */
t5=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3045,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 415  read-line */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3043 in loop in doread in read-lines in k1710 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 417  reverse */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 418  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3032(t4,((C_word*)t0)[5],t2,t3);}}

/* read-line in k1710 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2870r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2870r(t0,t1,t2);}}

static void C_ccall f_2870r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):*((C_word*)lf[13]+1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_2880(t8,(C_truep(t7)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_2880(t6,C_SCHEME_FALSE);}}

/* k2878 in read-line in k1710 */
static void C_fcall f_2880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2880,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 374  ##sys#check-port */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[125]);}

/* k2881 in k2878 in read-line in k1710 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
if(C_truep(t2)){
/* extras.scm: 375  rl */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_fix(256));
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 378  ##sys#make-string */
t7=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t5)[1]);}}

/* k2896 in k2881 in k2878 in read-line in k1710 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=lf[130],tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_2903(t7,((C_word*)t0)[2],C_fix(0));}

/* loop in k2896 in k2881 in k2878 in read-line in k1710 */
static void C_fcall f_2903(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2903,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[7])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* extras.scm: 381  ##sys#substring */
t4=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 382  ##sys#read-char-0 */
t5=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}

/* k2914 in loop in k2896 in k2881 in k2878 in read-line in k1710 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* extras.scm: 386  ##sys#substring */
t3=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);}}
else{
switch(t1){
case C_make_character(10):
/* extras.scm: 388  ##sys#substring */
t2=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 390  peek-char */
t3=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[8],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2981,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 397  make-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_2967(t3,C_SCHEME_UNDEFINED);}}}}

/* k2987 in k2914 in loop in k2896 in k2881 in k2878 in read-line in k1710 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 397  ##sys#string-append */
t2=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2979 in k2914 in loop in k2896 in k2881 in k2878 in read-line in k1710 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_2967(t5,t4);}

/* k2965 in k2914 in loop in k2896 in k2881 in k2878 in read-line in k1710 */
static void C_fcall f_2967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 400  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2903(t4,((C_word*)t0)[2],t3);}

/* k2947 in k2914 in loop in k2896 in k2881 in k2878 in read-line in k1710 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2949,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 392  ##sys#read-char-0 */
t4=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 394  ##sys#substring */
t3=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}}

/* k2956 in k2947 in k2914 in loop in k2896 in k2881 in k2878 in read-line in k1710 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 393  ##sys#substring */
t2=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],C_fix(0),((C_word*)t0)[2]);}

/* randomize in k1710 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2827r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2827r(t0,t1,t2);}}

static void C_ccall f_2827r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2832,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t3;
f_2832(t4,(C_word)C_fudge(C_fix(2)));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[122]);
t6=t3;
f_2832(t6,t4);}}

/* k2830 in randomize in k1710 */
static void C_fcall f_2832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_randomize(t1));}

/* random in k1710 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2815,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[98]);
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_fix(0):(C_word)C_random_fixnum(t2)));}

/* rassoc in k1710 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2765r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2765r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2765r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_list_2(t3,lf[118]);
t6=(C_word)C_notvemptyp(t4);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t4,C_fix(0)):*((C_word*)lf[102]+1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2777,a[2]=t2,a[3]=t7,a[4]=t9,a[5]=lf[119],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2777(t11,t1,t3);}

/* loop in rassoc in k1710 */
static void C_fcall f_2777(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2777,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[118]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 337  tst */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2794 in loop in rassoc in k1710 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 339  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2777(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k1710 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_2641r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2641r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2641r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2643,a[2]=t3,a[3]=t2,a[4]=lf[114],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t5,a[3]=lf[115],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2717,a[2]=t6,a[3]=lf[116],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp186202 */
t8=t7;
f_2717(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default187200 */
t10=t6;
f_2712(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body184189 */
t12=t5;
f_2643(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-cmp186 in alist-ref in k1710 */
static void C_fcall f_2717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2717,NULL,2,t0,t1);}
/* def-default187200 */
t2=((C_word*)t0)[2];
f_2712(t2,t1,*((C_word*)lf[102]+1));}

/* def-default187 in alist-ref in k1710 */
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2712,NULL,3,t0,t1,t2);}
/* body184189 */
t3=((C_word*)t0)[2];
f_2643(t3,t1,t2,C_SCHEME_FALSE);}

/* body184 in alist-ref in k1710 */
static void C_fcall f_2643(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2643,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[103]+1),t2);
if(C_truep(t5)){
t6=t4;
f_2647(t6,*((C_word*)lf[104]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[102]+1),t2);
if(C_truep(t6)){
t7=t4;
f_2647(t7,*((C_word*)lf[105]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[106]+1),t2);
t8=t4;
f_2647(t8,(C_truep(t7)?*((C_word*)lf[107]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2672,a[2]=t2,a[3]=lf[113],tmp=(C_word)a,a+=4,tmp)));}}}

/* f_2672 in body184 in alist-ref in k1710 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2672,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2678,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=lf[112],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2678(t7,t1,t3);}

/* loop */
static void C_fcall f_2678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2678,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 322  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2694(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2692 in loop */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 324  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2678(t3,((C_word*)t0)[5],t2);}}

/* k2645 in body184 in alist-ref in k1710 */
static void C_fcall f_2647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2647,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 325  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2648 in k2645 in body184 in alist-ref in k1710 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k1710 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2555r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2555r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2555r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t5,C_fix(0)):*((C_word*)lf[102]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2562,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[103]+1),t7);
if(C_truep(t9)){
t10=t8;
f_2562(t10,*((C_word*)lf[104]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[102]+1),t7);
if(C_truep(t10)){
t11=t8;
f_2562(t11,*((C_word*)lf[105]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[106]+1),t7);
t12=t8;
f_2562(t12,(C_truep(t11)?*((C_word*)lf[107]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2594,a[2]=t7,a[3]=lf[109],tmp=(C_word)a,a+=4,tmp)));}}}

/* f_2594 in alist-update! in k1710 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2594,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2600,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=lf[108],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2600(t7,t1,t3);}

/* loop */
static void C_fcall f_2600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2600,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* extras.scm: 303  cmp */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2616(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2614 in loop */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 305  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2600(t3,((C_word*)t0)[5],t2);}}

/* k2560 in alist-update! in k1710 */
static void C_fcall f_2562(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2562,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 306  aq */
t3=t1;
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2563 in k2560 in alist-update! in k1710 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k1710 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2514,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2525,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2529,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2545,a[2]=t3,a[3]=lf[99],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a2544 in shuffle in k1710 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2545,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2553,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 287  random */
t4=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2551 in a2544 in shuffle in k1710 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2527 in shuffle in k1710 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=lf[96],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 287  sort! */
t3=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2530 in k2527 in shuffle in k1710 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2531,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k2523 in shuffle in k1710 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[95]+1),t1);}

/* compress in k1710 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2434,4,t0,t1,t2,t3);}
t4=lf[88];
t5=(C_word)C_i_check_list_2(t3,lf[87]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2443,a[2]=t4,a[3]=t7,a[4]=lf[91],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2443(t9,t1,t2,t3);}

/* loop in compress in k1710 */
static void C_fcall f_2443(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2443,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2485,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 279  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* extras.scm: 280  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
/* extras.scm: 278  ##sys#signal-hook */
t4=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[90],lf[87],((C_word*)t0)[2],t3);}}
else{
/* extras.scm: 276  ##sys#signal-hook */
t4=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[90],lf[87],((C_word*)t0)[2],t2);}}}

/* k2483 in loop in compress in k1710 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k1710 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2375r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2375r(t0,t1,t2,t3);}}

static void C_ccall f_2375r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[82]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2387,a[2]=t8,a[3]=t5,a[4]=lf[85],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2387(t10,t1,t2);}

/* loop in join in k1710 */
static void C_fcall f_2387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2387,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 267  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}
else{
/* extras.scm: 261  ##sys#not-a-proper-list-error */
t3=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}}

/* k2420 in loop in join in k1710 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 267  ##sys#append */
t2=*((C_word*)lf[83]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k1710 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2290,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[77]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2297,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* extras.scm: 242  ##sys#error */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[77],lf[80],t3);}
else{
t6=t5;
f_2297(2,t6,C_SCHEME_UNDEFINED);}}

/* k2295 in chop in k1710 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=lf[79],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2305(t6,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* loop in k2295 in chop in k1710 */
static void C_fcall f_2305(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2305,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2326,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=lf[78],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_2326(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* do133 in loop in k2295 in chop in k1710 */
static void C_fcall f_2326(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2326,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2340,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 253  reverse */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k2338 in do133 in loop in k2295 in chop in k1710 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2344,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* extras.scm: 253  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2305(t4,t2,((C_word*)t0)[2],t3);}

/* k2342 in k2338 in do133 in loop in k2295 in chop in k1710 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k1710 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2249r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2249r(t0,t1,t2);}}

static void C_ccall f_2249r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2255,a[2]=t4,a[3]=lf[75],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2255(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k1710 */
static void C_fcall f_2255(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2255,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2281,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 234  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2288,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 235  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k2286 in loop in flatten in k1710 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2279 in loop in flatten in k1710 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 234  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2255(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k1710 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2217,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[71]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2226,a[2]=t5,a[3]=lf[72],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2226(t7,t1,t2);}

/* loop in butlast in k1710 */
static void C_fcall f_2226(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2226,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 224  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2245 in loop in butlast in k1710 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k1710 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2184,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2190,a[2]=t5,a[3]=t3,a[4]=lf[69],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2190(t7,t1,t2);}

/* loop in intersperse in k1710 */
static void C_fcall f_2190(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2190,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2215,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 217  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k2213 in loop in intersperse in k1710 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k1710 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2156,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[65]);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=t2,a[3]=lf[66],tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_2168(t6,t3));}}

/* loop in tail? in k1710 */
static C_word C_fcall f_2168(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k1710 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2153,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* any? in k1710 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2150,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* each in k1710 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2094r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2094r(t0,t1,t2);}}

static void C_ccall f_2094r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=lf[57],tmp=(C_word)a,a+=3,tmp));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2116,a[2]=t2,a[3]=lf[59],tmp=(C_word)a,a+=4,tmp)));}}

/* f_2116 in each in k1710 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2116r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2116r(t0,t1,t2);}}

static void C_ccall f_2116r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=t4,a[3]=t2,a[4]=lf[58],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2122(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2122,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
C_apply(4,0,t1,t3,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2141,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,t3,((C_word*)t0)[3]);}}

/* k2139 in loop */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 192  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2122(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_2102 in each in k1710 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* noop in k1710 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[2]+1));}

/* list-of in k1710 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2048,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2050,a[2]=t2,a[3]=lf[52],tmp=(C_word)a,a+=4,tmp));}

/* f_2050 in list-of in k1710 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2050,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[51],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2056(t6,t1,t2);}

/* loop */
static void C_fcall f_2056(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2056,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2075,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* extras.scm: 175  pred */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k2073 in loop */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 175  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2056(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* o in k1710 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2009r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2009r(t0,t1,t2);}}

static void C_ccall f_2009r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[17]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=t4,a[3]=lf[48],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2021(t6,t1,t2);}}

/* loop in o in k1710 */
static void C_fcall f_2021(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2021,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2035,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=lf[47],tmp=(C_word)a,a+=6,tmp)));}

/* f_2035 in loop in o in k1710 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2035,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2043,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 168  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2021(t5,t4,((C_word*)t0)[2]);}

/* k2044 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2041 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 168  h */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* compose in k1710 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1973r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1973r(t0,t1,t2);}}

static void C_ccall f_1973r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=t4,a[3]=lf[43],tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[44]+1));}
else{
C_apply(4,0,t1,((C_word*)t4)[1],t2);}}

/* rec in compose in k1710 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1976r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1976r(t0,t1,t2,t3);}}

static void C_ccall f_1976r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1984,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=lf[42],tmp=(C_word)a,a+=6,tmp)));}

/* f_1984 in rec in compose in k1710 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1984r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1984r(t0,t1,t2);}}

static void C_ccall f_1984r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=lf[41],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 153  call-with-values */
C_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a1989 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1996 in a1989 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k1710 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1961,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1963,a[2]=t2,a[3]=lf[38],tmp=(C_word)a,a+=4,tmp));}

/* f_1963 in complement in k1710 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1963r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1963r(t0,t1,t2);}}

static void C_ccall f_1963r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1971,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k1969 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k1710 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1953,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=t2,a[3]=lf[35],tmp=(C_word)a,a+=4,tmp));}

/* f_1955 in flip in k1710 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1955,4,t0,t1,t2,t3);}
/* extras.scm: 142  proc */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* constantly in k1710 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_1930r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1930r(t0,t1,t2);}}

static void C_ccall f_1930r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1941,a[2]=t5,a[3]=lf[31],tmp=(C_word)a,a+=4,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1943,a[2]=t2,a[3]=lf[32],tmp=(C_word)a,a+=4,tmp));}}

/* f_1943 in constantly in k1710 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1943,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_1941 in constantly in k1710 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k1710 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1893r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1893r(t0,t1,t2);}}

static void C_ccall f_1893r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=t2,a[3]=lf[28],tmp=(C_word)a,a+=4,tmp));}

/* f_1895 in disjoin in k1710 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1895,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1901,a[2]=t2,a[3]=t4,a[4]=lf[27],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1901(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1901,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[2]);}}

/* k1909 in loop */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 134  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1901(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k1710 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1860r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1860r(t0,t1,t2);}}

static void C_ccall f_1860r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1862,a[2]=t2,a[3]=lf[24],tmp=(C_word)a,a+=4,tmp));}

/* f_1862 in conjoin in k1710 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1862,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1868,a[2]=t2,a[3]=t4,a[4]=lf[23],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1868(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1868,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1881,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[2]);}}

/* k1879 in loop */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* extras.scm: 127  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1868(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k1710 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1852,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1854,a[2]=t2,a[3]=lf[20],tmp=(C_word)a,a+=4,tmp));}

/* f_1854 in project in k1710 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1854r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1854r(t0,t1,t2);}}

static void C_ccall f_1854r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,((C_word*)t0)[2]));}

/* identity in k1710 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1849,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* read-file in k1710 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr2r,(void*)f_1714r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1714r(t0,t1,t2);}}

static void C_ccall f_1714r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[10],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1776,a[2]=t3,a[3]=lf[11],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[12],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1786,a[2]=t5,a[3]=lf[14],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-port1135 */
t7=t6;
f_1786(t7,t1);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-reader1233 */
t9=t5;
f_1781(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-max1330 */
t11=t4;
f_1776(t11,t1,t7,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body915 */
t13=t3;
f_1716(t13,t1,t7,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-port11 in read-file in k1710 */
static void C_fcall f_1786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1786,NULL,2,t0,t1);}
/* def-reader1233 */
t2=((C_word*)t0)[2];
f_1781(t2,t1,*((C_word*)lf[13]+1));}

/* def-reader12 in read-file in k1710 */
static void C_fcall f_1781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1781,NULL,3,t0,t1,t2);}
/* def-max1330 */
t3=((C_word*)t0)[3];
f_1776(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max13 in read-file in k1710 */
static void C_fcall f_1776(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1776,NULL,4,t0,t1,t2,t3);}
/* body915 */
t4=((C_word*)t0)[2];
f_1716(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body9 in read-file in k1710 */
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1719,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=lf[8],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 110  port? */
t7=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k1767 in body9 in read-file in k1710 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 111  slurp */
t2=((C_word*)t0)[5];
f_1719(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm: 112  call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body9 in read-file in k1710 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1719,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1727,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 106  reader */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1725 in slurp in body9 in read-file in k1710 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=lf[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1729(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* do21 in k1725 in slurp in body9 in read-file in k1710 */
static void C_fcall f_1729(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1729,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm: 109  reverse */
t7=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1749,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 106  reader */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k1747 in do21 in k1725 in slurp in body9 in read-file in k1710 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_1729(t4,((C_word*)t0)[2],t1,t2,t3);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[617] = {
{"toplevelextras.scm",(void*)C_extras_toplevel},
{"f_1712extras.scm",(void*)f_1712},
{"f_5411extras.scm",(void*)f_5411},
{"f_6935extras.scm",(void*)f_6935},
{"f_9404extras.scm",(void*)f_9404},
{"f_9417extras.scm",(void*)f_9417},
{"f_9480extras.scm",(void*)f_9480},
{"f_9499extras.scm",(void*)f_9499},
{"f_9438extras.scm",(void*)f_9438},
{"f_9520extras.scm",(void*)f_9520},
{"f_8317extras.scm",(void*)f_8317},
{"f_9003extras.scm",(void*)f_9003},
{"f_9353extras.scm",(void*)f_9353},
{"f_9363extras.scm",(void*)f_9363},
{"f_9380extras.scm",(void*)f_9380},
{"f_9366extras.scm",(void*)f_9366},
{"f_9324extras.scm",(void*)f_9324},
{"f_9270extras.scm",(void*)f_9270},
{"f_9289extras.scm",(void*)f_9289},
{"f_9299extras.scm",(void*)f_9299},
{"f_9281extras.scm",(void*)f_9281},
{"f_9261extras.scm",(void*)f_9261},
{"f_9225extras.scm",(void*)f_9225},
{"f_9235extras.scm",(void*)f_9235},
{"f_9193extras.scm",(void*)f_9193},
{"f_9203extras.scm",(void*)f_9203},
{"f_9172extras.scm",(void*)f_9172},
{"f_9182extras.scm",(void*)f_9182},
{"f_9151extras.scm",(void*)f_9151},
{"f_9161extras.scm",(void*)f_9161},
{"f_9138extras.scm",(void*)f_9138},
{"f_9132extras.scm",(void*)f_9132},
{"f_9126extras.scm",(void*)f_9126},
{"f_9057extras.scm",(void*)f_9057},
{"f_9072extras.scm",(void*)f_9072},
{"f_9088extras.scm",(void*)f_9088},
{"f_9116extras.scm",(void*)f_9116},
{"f_9005extras.scm",(void*)f_9005},
{"f_9020extras.scm",(void*)f_9020},
{"f_9039extras.scm",(void*)f_9039},
{"f_9030extras.scm",(void*)f_9030},
{"f_8937extras.scm",(void*)f_8937},
{"f_8952extras.scm",(void*)f_8952},
{"f_8968extras.scm",(void*)f_8968},
{"f_8872extras.scm",(void*)f_8872},
{"f_8887extras.scm",(void*)f_8887},
{"f_8903extras.scm",(void*)f_8903},
{"f_8849extras.scm",(void*)f_8849},
{"f_8853extras.scm",(void*)f_8853},
{"f_8858extras.scm",(void*)f_8858},
{"f_8856extras.scm",(void*)f_8856},
{"f_8776extras.scm",(void*)f_8776},
{"f_8791extras.scm",(void*)f_8791},
{"f_8807extras.scm",(void*)f_8807},
{"f_8705extras.scm",(void*)f_8705},
{"f_8723extras.scm",(void*)f_8723},
{"f_8746extras.scm",(void*)f_8746},
{"f_8759extras.scm",(void*)f_8759},
{"f_8733extras.scm",(void*)f_8733},
{"f_8626extras.scm",(void*)f_8626},
{"f_8638extras.scm",(void*)f_8638},
{"f_8661extras.scm",(void*)f_8661},
{"f_8677extras.scm",(void*)f_8677},
{"f_8648extras.scm",(void*)f_8648},
{"f_8528extras.scm",(void*)f_8528},
{"f_8546extras.scm",(void*)f_8546},
{"f_8572extras.scm",(void*)f_8572},
{"f_8595extras.scm",(void*)f_8595},
{"f_8598extras.scm",(void*)f_8598},
{"f_8585extras.scm",(void*)f_8585},
{"f_8559extras.scm",(void*)f_8559},
{"f_8381extras.scm",(void*)f_8381},
{"f_8400extras.scm",(void*)f_8400},
{"f_8472extras.scm",(void*)f_8472},
{"f_8488extras.scm",(void*)f_8488},
{"f_8491extras.scm",(void*)f_8491},
{"f_8417extras.scm",(void*)f_8417},
{"f_8436extras.scm",(void*)f_8436},
{"f_8348extras.scm",(void*)f_8348},
{"f_8358extras.scm",(void*)f_8358},
{"f_8331extras.scm",(void*)f_8331},
{"f_8346extras.scm",(void*)f_8346},
{"f_8319extras.scm",(void*)f_8319},
{"f_8325extras.scm",(void*)f_8325},
{"f_8303extras.scm",(void*)f_8303},
{"f_8312extras.scm",(void*)f_8312},
{"f_8309extras.scm",(void*)f_8309},
{"f_8294extras.scm",(void*)f_8294},
{"f_8300extras.scm",(void*)f_8300},
{"f_8050extras.scm",(void*)f_8050},
{"f_8272extras.scm",(void*)f_8272},
{"f_8054extras.scm",(void*)f_8054},
{"f_8062extras.scm",(void*)f_8062},
{"f_8078extras.scm",(void*)f_8078},
{"f_8260extras.scm",(void*)f_8260},
{"f_8188extras.scm",(void*)f_8188},
{"f_8225extras.scm",(void*)f_8225},
{"f_8228extras.scm",(void*)f_8228},
{"f_8216extras.scm",(void*)f_8216},
{"f_8198extras.scm",(void*)f_8198},
{"f_8125extras.scm",(void*)f_8125},
{"f_8165extras.scm",(void*)f_8165},
{"f_8153extras.scm",(void*)f_8153},
{"f_8135extras.scm",(void*)f_8135},
{"f_8103extras.scm",(void*)f_8103},
{"f_8090extras.scm",(void*)f_8090},
{"f_8093extras.scm",(void*)f_8093},
{"f_8041extras.scm",(void*)f_8041},
{"f_8013extras.scm",(void*)f_8013},
{"f_8017extras.scm",(void*)f_8017},
{"f_7985extras.scm",(void*)f_7985},
{"f_7989extras.scm",(void*)f_7989},
{"f_7953extras.scm",(void*)f_7953},
{"f_7957extras.scm",(void*)f_7957},
{"f_7727extras.scm",(void*)f_7727},
{"f_7951extras.scm",(void*)f_7951},
{"f_7755extras.scm",(void*)f_7755},
{"f_7886extras.scm",(void*)f_7886},
{"f_7921extras.scm",(void*)f_7921},
{"f_7864extras.scm",(void*)f_7864},
{"f_7851extras.scm",(void*)f_7851},
{"f_7843extras.scm",(void*)f_7843},
{"f_7822extras.scm",(void*)f_7822},
{"f_7730extras.scm",(void*)f_7730},
{"f_7740extras.scm",(void*)f_7740},
{"f_7718extras.scm",(void*)f_7718},
{"f_7709extras.scm",(void*)f_7709},
{"f_7614extras.scm",(void*)f_7614},
{"f_7627extras.scm",(void*)f_7627},
{"f_7632extras.scm",(void*)f_7632},
{"f_7674extras.scm",(void*)f_7674},
{"f_7695extras.scm",(void*)f_7695},
{"f_7668extras.scm",(void*)f_7668},
{"f_7527extras.scm",(void*)f_7527},
{"f_7551extras.scm",(void*)f_7551},
{"f_7546extras.scm",(void*)f_7546},
{"f_7541extras.scm",(void*)f_7541},
{"f_7529extras.scm",(void*)f_7529},
{"f_7540extras.scm",(void*)f_7540},
{"f_7521extras.scm",(void*)f_7521},
{"f_7437extras.scm",(void*)f_7437},
{"f_7515extras.scm",(void*)f_7515},
{"f_7441extras.scm",(void*)f_7441},
{"f_7455extras.scm",(void*)f_7455},
{"f_7465extras.scm",(void*)f_7465},
{"f_7410extras.scm",(void*)f_7410},
{"f_7435extras.scm",(void*)f_7435},
{"f_7428extras.scm",(void*)f_7428},
{"f_7424extras.scm",(void*)f_7424},
{"f_7277extras.scm",(void*)f_7277},
{"f_7367extras.scm",(void*)f_7367},
{"f_7374extras.scm",(void*)f_7374},
{"f_7376extras.scm",(void*)f_7376},
{"f_7280extras.scm",(void*)f_7280},
{"f_7331extras.scm",(void*)f_7331},
{"f_7321extras.scm",(void*)f_7321},
{"f_7290extras.scm",(void*)f_7290},
{"f_7293extras.scm",(void*)f_7293},
{"f_7299extras.scm",(void*)f_7299},
{"f_7145extras.scm",(void*)f_7145},
{"f_7227extras.scm",(void*)f_7227},
{"f_7250extras.scm",(void*)f_7250},
{"f_7230extras.scm",(void*)f_7230},
{"f_7148extras.scm",(void*)f_7148},
{"f_7155extras.scm",(void*)f_7155},
{"f_7046extras.scm",(void*)f_7046},
{"f_7080extras.scm",(void*)f_7080},
{"f_7087extras.scm",(void*)f_7087},
{"f_7135extras.scm",(void*)f_7135},
{"f_7107extras.scm",(void*)f_7107},
{"f_6937extras.scm",(void*)f_6937},
{"f_7012extras.scm",(void*)f_7012},
{"f_7040extras.scm",(void*)f_7040},
{"f_6964extras.scm",(void*)f_6964},
{"f_6974extras.scm",(void*)f_6974},
{"f_6892extras.scm",(void*)f_6892},
{"f_6925extras.scm",(void*)f_6925},
{"f_6900extras.scm",(void*)f_6900},
{"f_6880extras.scm",(void*)f_6880},
{"f_6884extras.scm",(void*)f_6884},
{"f_6887extras.scm",(void*)f_6887},
{"f_6870extras.scm",(void*)f_6870},
{"f_6878extras.scm",(void*)f_6878},
{"f_6604extras.scm",(void*)f_6604},
{"f_6610extras.scm",(void*)f_6610},
{"f_6617extras.scm",(void*)f_6617},
{"f_6648extras.scm",(void*)f_6648},
{"f_6835extras.scm",(void*)f_6835},
{"f_6781extras.scm",(void*)f_6781},
{"f_6784extras.scm",(void*)f_6784},
{"f_6763extras.scm",(void*)f_6763},
{"f_6759extras.scm",(void*)f_6759},
{"f_6746extras.scm",(void*)f_6746},
{"f_6742extras.scm",(void*)f_6742},
{"f_6729extras.scm",(void*)f_6729},
{"f_6725extras.scm",(void*)f_6725},
{"f_6712extras.scm",(void*)f_6712},
{"f_6699extras.scm",(void*)f_6699},
{"f_6686extras.scm",(void*)f_6686},
{"f_6661extras.scm",(void*)f_6661},
{"f_6629extras.scm",(void*)f_6629},
{"f_6622extras.scm",(void*)f_6622},
{"f_6552extras.scm",(void*)f_6552},
{"f_6556extras.scm",(void*)f_6556},
{"f_6488extras.scm",(void*)f_6488},
{"f_6503extras.scm",(void*)f_6503},
{"f_6534extras.scm",(void*)f_6534},
{"f_6538extras.scm",(void*)f_6538},
{"f_6523extras.scm",(void*)f_6523},
{"f_6366extras.scm",(void*)f_6366},
{"f_6378extras.scm",(void*)f_6378},
{"f_6411extras.scm",(void*)f_6411},
{"f_6476extras.scm",(void*)f_6476},
{"f_6450extras.scm",(void*)f_6450},
{"f_6406extras.scm",(void*)f_6406},
{"f_6396extras.scm",(void*)f_6396},
{"f_6392extras.scm",(void*)f_6392},
{"f_6164extras.scm",(void*)f_6164},
{"f_6358extras.scm",(void*)f_6358},
{"f_6341extras.scm",(void*)f_6341},
{"f_6201extras.scm",(void*)f_6201},
{"f_6204extras.scm",(void*)f_6204},
{"f_6216extras.scm",(void*)f_6216},
{"f_6221extras.scm",(void*)f_6221},
{"f_6240extras.scm",(void*)f_6240},
{"f_6167extras.scm",(void*)f_6167},
{"f_6172extras.scm",(void*)f_6172},
{"f_6178extras.scm",(void*)f_6178},
{"f_6049extras.scm",(void*)f_6049},
{"f_6053extras.scm",(void*)f_6053},
{"f_6067extras.scm",(void*)f_6067},
{"f_6077extras.scm",(void*)f_6077},
{"f_6082extras.scm",(void*)f_6082},
{"f_5914extras.scm",(void*)f_5914},
{"f_5955extras.scm",(void*)f_5955},
{"f_5982extras.scm",(void*)f_5982},
{"f_6021extras.scm",(void*)f_6021},
{"f_5965extras.scm",(void*)f_5965},
{"f_5935extras.scm",(void*)f_5935},
{"f_5950extras.scm",(void*)f_5950},
{"f_5942extras.scm",(void*)f_5942},
{"f_5834extras.scm",(void*)f_5834},
{"f_5851extras.scm",(void*)f_5851},
{"f_5846extras.scm",(void*)f_5846},
{"f_5841extras.scm",(void*)f_5841},
{"f_5836extras.scm",(void*)f_5836},
{"f_5797extras.scm",(void*)f_5797},
{"f_5807extras.scm",(void*)f_5807},
{"f_5717extras.scm",(void*)f_5717},
{"f_5734extras.scm",(void*)f_5734},
{"f_5729extras.scm",(void*)f_5729},
{"f_5724extras.scm",(void*)f_5724},
{"f_5719extras.scm",(void*)f_5719},
{"f_5680extras.scm",(void*)f_5680},
{"f_5690extras.scm",(void*)f_5690},
{"f_5649extras.scm",(void*)f_5649},
{"f_5618extras.scm",(void*)f_5618},
{"f_5590extras.scm",(void*)f_5590},
{"f_5594extras.scm",(void*)f_5594},
{"f_5562extras.scm",(void*)f_5562},
{"f_5566extras.scm",(void*)f_5566},
{"f_5553extras.scm",(void*)f_5553},
{"f_5559extras.scm",(void*)f_5559},
{"f_5544extras.scm",(void*)f_5544},
{"f_5550extras.scm",(void*)f_5550},
{"f_5497extras.scm",(void*)f_5497},
{"f_5518extras.scm",(void*)f_5518},
{"f_5531extras.scm",(void*)f_5531},
{"f_5487extras.scm",(void*)f_5487},
{"f_5495extras.scm",(void*)f_5495},
{"f_5442extras.scm",(void*)f_5442},
{"f_5479extras.scm",(void*)f_5479},
{"f_5482extras.scm",(void*)f_5482},
{"f_5413extras.scm",(void*)f_5413},
{"f_5417extras.scm",(void*)f_5417},
{"f_5424extras.scm",(void*)f_5424},
{"f_5426extras.scm",(void*)f_5426},
{"f_5430extras.scm",(void*)f_5430},
{"f_5420extras.scm",(void*)f_5420},
{"f_5332extras.scm",(void*)f_5332},
{"f_5335extras.scm",(void*)f_5335},
{"f_5351extras.scm",(void*)f_5351},
{"f_5360extras.scm",(void*)f_5360},
{"f_4060extras.scm",(void*)f_4060},
{"f_5323extras.scm",(void*)f_5323},
{"f_5327extras.scm",(void*)f_5327},
{"f_4676extras.scm",(void*)f_4676},
{"f_5231extras.scm",(void*)f_5231},
{"f_5241extras.scm",(void*)f_5241},
{"f_5222extras.scm",(void*)f_5222},
{"f_5216extras.scm",(void*)f_5216},
{"f_5194extras.scm",(void*)f_5194},
{"f_5201extras.scm",(void*)f_5201},
{"f_5188extras.scm",(void*)f_5188},
{"f_5182extras.scm",(void*)f_5182},
{"f_5176extras.scm",(void*)f_5176},
{"f_5170extras.scm",(void*)f_5170},
{"f_5164extras.scm",(void*)f_5164},
{"f_5158extras.scm",(void*)f_5158},
{"f_5010extras.scm",(void*)f_5010},
{"f_5156extras.scm",(void*)f_5156},
{"f_5108extras.scm",(void*)f_5108},
{"f_5138extras.scm",(void*)f_5138},
{"f_5123extras.scm",(void*)f_5123},
{"f_5013extras.scm",(void*)f_5013},
{"f_5040extras.scm",(void*)f_5040},
{"f_5036extras.scm",(void*)f_5036},
{"f_5054extras.scm",(void*)f_5054},
{"f_5081extras.scm",(void*)f_5081},
{"f_5077extras.scm",(void*)f_5077},
{"f_5095extras.scm",(void*)f_5095},
{"f_4933extras.scm",(void*)f_4933},
{"f_4939extras.scm",(void*)f_4939},
{"f_5008extras.scm",(void*)f_5008},
{"f_5004extras.scm",(void*)f_5004},
{"f_4996extras.scm",(void*)f_4996},
{"f_4992extras.scm",(void*)f_4992},
{"f_4970extras.scm",(void*)f_4970},
{"f_4962extras.scm",(void*)f_4962},
{"f_4924extras.scm",(void*)f_4924},
{"f_4928extras.scm",(void*)f_4928},
{"f_4896extras.scm",(void*)f_4896},
{"f_4922extras.scm",(void*)f_4922},
{"f_4900extras.scm",(void*)f_4900},
{"f_4831extras.scm",(void*)f_4831},
{"f_4838extras.scm",(void*)f_4838},
{"f_4865extras.scm",(void*)f_4865},
{"f_4891extras.scm",(void*)f_4891},
{"f_4849extras.scm",(void*)f_4849},
{"f_4744extras.scm",(void*)f_4744},
{"f_4757extras.scm",(void*)f_4757},
{"f_4795extras.scm",(void*)f_4795},
{"f_4760extras.scm",(void*)f_4760},
{"f_4789extras.scm",(void*)f_4789},
{"f_4793extras.scm",(void*)f_4793},
{"f_4773extras.scm",(void*)f_4773},
{"f_4712extras.scm",(void*)f_4712},
{"f_4735extras.scm",(void*)f_4735},
{"f_4728extras.scm",(void*)f_4728},
{"f_4679extras.scm",(void*)f_4679},
{"f_4710extras.scm",(void*)f_4710},
{"f_4703extras.scm",(void*)f_4703},
{"f_4173extras.scm",(void*)f_4173},
{"f_4352extras.scm",(void*)f_4352},
{"f_4618extras.scm",(void*)f_4618},
{"f_4657extras.scm",(void*)f_4657},
{"f_4667extras.scm",(void*)f_4667},
{"f_4660extras.scm",(void*)f_4660},
{"f_4635extras.scm",(void*)f_4635},
{"f_4645extras.scm",(void*)f_4645},
{"f_4638extras.scm",(void*)f_4638},
{"f_4625extras.scm",(void*)f_4625},
{"f_4602extras.scm",(void*)f_4602},
{"f_4605extras.scm",(void*)f_4605},
{"f_4612extras.scm",(void*)f_4612},
{"f_4584extras.scm",(void*)f_4584},
{"f_4500extras.scm",(void*)f_4500},
{"f_4503extras.scm",(void*)f_4503},
{"f_4559extras.scm",(void*)f_4559},
{"f_4538extras.scm",(void*)f_4538},
{"f_4545extras.scm",(void*)f_4545},
{"f_4522extras.scm",(void*)f_4522},
{"f_4529extras.scm",(void*)f_4529},
{"f_4494extras.scm",(void*)f_4494},
{"f_4410extras.scm",(void*)f_4410},
{"f_4412extras.scm",(void*)f_4412},
{"f_4419extras.scm",(void*)f_4419},
{"f_4471extras.scm",(void*)f_4471},
{"f_4467extras.scm",(void*)f_4467},
{"f_4450extras.scm",(void*)f_4450},
{"f_4446extras.scm",(void*)f_4446},
{"f_4442extras.scm",(void*)f_4442},
{"f_4391extras.scm",(void*)f_4391},
{"f_4368extras.scm",(void*)f_4368},
{"f_4371extras.scm",(void*)f_4371},
{"f_4378extras.scm",(void*)f_4378},
{"f_4359extras.scm",(void*)f_4359},
{"f_4329extras.scm",(void*)f_4329},
{"f_4333extras.scm",(void*)f_4333},
{"f_4176extras.scm",(void*)f_4176},
{"f_4183extras.scm",(void*)f_4183},
{"f_4194extras.scm",(void*)f_4194},
{"f_4203extras.scm",(void*)f_4203},
{"f_4286extras.scm",(void*)f_4286},
{"f_4221extras.scm",(void*)f_4221},
{"f_4223extras.scm",(void*)f_4223},
{"f_4275extras.scm",(void*)f_4275},
{"f_4271extras.scm",(void*)f_4271},
{"f_4255extras.scm",(void*)f_4255},
{"f_4247extras.scm",(void*)f_4247},
{"f_4154extras.scm",(void*)f_4154},
{"f_4164extras.scm",(void*)f_4164},
{"f_4121extras.scm",(void*)f_4121},
{"f_4115extras.scm",(void*)f_4115},
{"f_4063extras.scm",(void*)f_4063},
{"f_4095extras.scm",(void*)f_4095},
{"f_4002extras.scm",(void*)f_4002},
{"f_4015extras.scm",(void*)f_4015},
{"f_4045extras.scm",(void*)f_4045},
{"f_4036extras.scm",(void*)f_4036},
{"f_4040extras.scm",(void*)f_4040},
{"f_4030extras.scm",(void*)f_4030},
{"f_4020extras.scm",(void*)f_4020},
{"f_4028extras.scm",(void*)f_4028},
{"f_3856extras.scm",(void*)f_3856},
{"f_3939extras.scm",(void*)f_3939},
{"f_3934extras.scm",(void*)f_3934},
{"f_3929extras.scm",(void*)f_3929},
{"f_3858extras.scm",(void*)f_3858},
{"f_3868extras.scm",(void*)f_3868},
{"f_3924extras.scm",(void*)f_3924},
{"f_3915extras.scm",(void*)f_3915},
{"f_3919extras.scm",(void*)f_3919},
{"f_3894extras.scm",(void*)f_3894},
{"f_3910extras.scm",(void*)f_3910},
{"f_3873extras.scm",(void*)f_3873},
{"f_3822extras.scm",(void*)f_3822},
{"f_3826extras.scm",(void*)f_3826},
{"f_3848extras.scm",(void*)f_3848},
{"f_3839extras.scm",(void*)f_3839},
{"f_3843extras.scm",(void*)f_3843},
{"f_3831extras.scm",(void*)f_3831},
{"f_3791extras.scm",(void*)f_3791},
{"f_3795extras.scm",(void*)f_3795},
{"f_3814extras.scm",(void*)f_3814},
{"f_3808extras.scm",(void*)f_3808},
{"f_3800extras.scm",(void*)f_3800},
{"f_3779extras.scm",(void*)f_3779},
{"f_3783extras.scm",(void*)f_3783},
{"f_3786extras.scm",(void*)f_3786},
{"f_3770extras.scm",(void*)f_3770},
{"f_3774extras.scm",(void*)f_3774},
{"f_3739extras.scm",(void*)f_3739},
{"f_3743extras.scm",(void*)f_3743},
{"f_3762extras.scm",(void*)f_3762},
{"f_3756extras.scm",(void*)f_3756},
{"f_3748extras.scm",(void*)f_3748},
{"f_3708extras.scm",(void*)f_3708},
{"f_3712extras.scm",(void*)f_3712},
{"f_3731extras.scm",(void*)f_3731},
{"f_3725extras.scm",(void*)f_3725},
{"f_3717extras.scm",(void*)f_3717},
{"f_3677extras.scm",(void*)f_3677},
{"f_3681extras.scm",(void*)f_3681},
{"f_3700extras.scm",(void*)f_3700},
{"f_3694extras.scm",(void*)f_3694},
{"f_3686extras.scm",(void*)f_3686},
{"f_3639extras.scm",(void*)f_3639},
{"f_3643extras.scm",(void*)f_3643},
{"f_3649extras.scm",(void*)f_3649},
{"f_3599extras.scm",(void*)f_3599},
{"f_3603extras.scm",(void*)f_3603},
{"f_3606extras.scm",(void*)f_3606},
{"f_3609extras.scm",(void*)f_3609},
{"f_3578extras.scm",(void*)f_3578},
{"f_3585extras.scm",(void*)f_3585},
{"f_3591extras.scm",(void*)f_3591},
{"f_3489extras.scm",(void*)f_3489},
{"f_3530extras.scm",(void*)f_3530},
{"f_3525extras.scm",(void*)f_3525},
{"f_3494extras.scm",(void*)f_3494},
{"f_3498extras.scm",(void*)f_3498},
{"f_3511extras.scm",(void*)f_3511},
{"f_3508extras.scm",(void*)f_3508},
{"f_3420extras.scm",(void*)f_3420},
{"f_3424extras.scm",(void*)f_3424},
{"f_3427extras.scm",(void*)f_3427},
{"f_3430extras.scm",(void*)f_3430},
{"f_3435extras.scm",(void*)f_3435},
{"f_3439extras.scm",(void*)f_3439},
{"f_3445extras.scm",(void*)f_3445},
{"f_3455extras.scm",(void*)f_3455},
{"f_3448extras.scm",(void*)f_3448},
{"f_3360extras.scm",(void*)f_3360},
{"f_3372extras.scm",(void*)f_3372},
{"f_3367extras.scm",(void*)f_3367},
{"f_3362extras.scm",(void*)f_3362},
{"f_3287extras.scm",(void*)f_3287},
{"f_3291extras.scm",(void*)f_3291},
{"f_3315extras.scm",(void*)f_3315},
{"f_3320extras.scm",(void*)f_3320},
{"f_3324extras.scm",(void*)f_3324},
{"f_3330extras.scm",(void*)f_3330},
{"f_3342extras.scm",(void*)f_3342},
{"f_3300extras.scm",(void*)f_3300},
{"f_3303extras.scm",(void*)f_3303},
{"f_3190extras.scm",(void*)f_3190},
{"f_3239extras.scm",(void*)f_3239},
{"f_3234extras.scm",(void*)f_3234},
{"f_3192extras.scm",(void*)f_3192},
{"f_3196extras.scm",(void*)f_3196},
{"f_3202extras.scm",(void*)f_3202},
{"f_3100extras.scm",(void*)f_3100},
{"f_3184extras.scm",(void*)f_3184},
{"f_3110extras.scm",(void*)f_3110},
{"f_3118extras.scm",(void*)f_3118},
{"f_3167extras.scm",(void*)f_3167},
{"f_3122extras.scm",(void*)f_3122},
{"f_3010extras.scm",(void*)f_3010},
{"f_3077extras.scm",(void*)f_3077},
{"f_3022extras.scm",(void*)f_3022},
{"f_3032extras.scm",(void*)f_3032},
{"f_3045extras.scm",(void*)f_3045},
{"f_2870extras.scm",(void*)f_2870},
{"f_2880extras.scm",(void*)f_2880},
{"f_2883extras.scm",(void*)f_2883},
{"f_2898extras.scm",(void*)f_2898},
{"f_2903extras.scm",(void*)f_2903},
{"f_2916extras.scm",(void*)f_2916},
{"f_2989extras.scm",(void*)f_2989},
{"f_2981extras.scm",(void*)f_2981},
{"f_2967extras.scm",(void*)f_2967},
{"f_2949extras.scm",(void*)f_2949},
{"f_2958extras.scm",(void*)f_2958},
{"f_2827extras.scm",(void*)f_2827},
{"f_2832extras.scm",(void*)f_2832},
{"f_2815extras.scm",(void*)f_2815},
{"f_2765extras.scm",(void*)f_2765},
{"f_2777extras.scm",(void*)f_2777},
{"f_2796extras.scm",(void*)f_2796},
{"f_2641extras.scm",(void*)f_2641},
{"f_2717extras.scm",(void*)f_2717},
{"f_2712extras.scm",(void*)f_2712},
{"f_2643extras.scm",(void*)f_2643},
{"f_2672extras.scm",(void*)f_2672},
{"f_2678extras.scm",(void*)f_2678},
{"f_2694extras.scm",(void*)f_2694},
{"f_2647extras.scm",(void*)f_2647},
{"f_2650extras.scm",(void*)f_2650},
{"f_2555extras.scm",(void*)f_2555},
{"f_2594extras.scm",(void*)f_2594},
{"f_2600extras.scm",(void*)f_2600},
{"f_2616extras.scm",(void*)f_2616},
{"f_2562extras.scm",(void*)f_2562},
{"f_2565extras.scm",(void*)f_2565},
{"f_2514extras.scm",(void*)f_2514},
{"f_2545extras.scm",(void*)f_2545},
{"f_2553extras.scm",(void*)f_2553},
{"f_2529extras.scm",(void*)f_2529},
{"f_2531extras.scm",(void*)f_2531},
{"f_2525extras.scm",(void*)f_2525},
{"f_2434extras.scm",(void*)f_2434},
{"f_2443extras.scm",(void*)f_2443},
{"f_2485extras.scm",(void*)f_2485},
{"f_2375extras.scm",(void*)f_2375},
{"f_2387extras.scm",(void*)f_2387},
{"f_2422extras.scm",(void*)f_2422},
{"f_2290extras.scm",(void*)f_2290},
{"f_2297extras.scm",(void*)f_2297},
{"f_2305extras.scm",(void*)f_2305},
{"f_2326extras.scm",(void*)f_2326},
{"f_2340extras.scm",(void*)f_2340},
{"f_2344extras.scm",(void*)f_2344},
{"f_2249extras.scm",(void*)f_2249},
{"f_2255extras.scm",(void*)f_2255},
{"f_2288extras.scm",(void*)f_2288},
{"f_2281extras.scm",(void*)f_2281},
{"f_2217extras.scm",(void*)f_2217},
{"f_2226extras.scm",(void*)f_2226},
{"f_2247extras.scm",(void*)f_2247},
{"f_2184extras.scm",(void*)f_2184},
{"f_2190extras.scm",(void*)f_2190},
{"f_2215extras.scm",(void*)f_2215},
{"f_2156extras.scm",(void*)f_2156},
{"f_2168extras.scm",(void*)f_2168},
{"f_2153extras.scm",(void*)f_2153},
{"f_2150extras.scm",(void*)f_2150},
{"f_2094extras.scm",(void*)f_2094},
{"f_2116extras.scm",(void*)f_2116},
{"f_2122extras.scm",(void*)f_2122},
{"f_2141extras.scm",(void*)f_2141},
{"f_2102extras.scm",(void*)f_2102},
{"f_2088extras.scm",(void*)f_2088},
{"f_2048extras.scm",(void*)f_2048},
{"f_2050extras.scm",(void*)f_2050},
{"f_2056extras.scm",(void*)f_2056},
{"f_2075extras.scm",(void*)f_2075},
{"f_2009extras.scm",(void*)f_2009},
{"f_2021extras.scm",(void*)f_2021},
{"f_2035extras.scm",(void*)f_2035},
{"f_2046extras.scm",(void*)f_2046},
{"f_2043extras.scm",(void*)f_2043},
{"f_1973extras.scm",(void*)f_1973},
{"f_1976extras.scm",(void*)f_1976},
{"f_1984extras.scm",(void*)f_1984},
{"f_1990extras.scm",(void*)f_1990},
{"f_1998extras.scm",(void*)f_1998},
{"f_1961extras.scm",(void*)f_1961},
{"f_1963extras.scm",(void*)f_1963},
{"f_1971extras.scm",(void*)f_1971},
{"f_1953extras.scm",(void*)f_1953},
{"f_1955extras.scm",(void*)f_1955},
{"f_1930extras.scm",(void*)f_1930},
{"f_1943extras.scm",(void*)f_1943},
{"f_1941extras.scm",(void*)f_1941},
{"f_1893extras.scm",(void*)f_1893},
{"f_1895extras.scm",(void*)f_1895},
{"f_1901extras.scm",(void*)f_1901},
{"f_1911extras.scm",(void*)f_1911},
{"f_1860extras.scm",(void*)f_1860},
{"f_1862extras.scm",(void*)f_1862},
{"f_1868extras.scm",(void*)f_1868},
{"f_1881extras.scm",(void*)f_1881},
{"f_1852extras.scm",(void*)f_1852},
{"f_1854extras.scm",(void*)f_1854},
{"f_1849extras.scm",(void*)f_1849},
{"f_1714extras.scm",(void*)f_1714},
{"f_1786extras.scm",(void*)f_1786},
{"f_1781extras.scm",(void*)f_1781},
{"f_1776extras.scm",(void*)f_1776},
{"f_1716extras.scm",(void*)f_1716},
{"f_1769extras.scm",(void*)f_1769},
{"f_1719extras.scm",(void*)f_1719},
{"f_1727extras.scm",(void*)f_1727},
{"f_1729extras.scm",(void*)f_1729},
{"f_1749extras.scm",(void*)f_1749},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
