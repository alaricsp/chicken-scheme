/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-07-30 23:14
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-28 on dill (Linux)
   command line: optimizer.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[259];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9508)
static void C_ccall f_9508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9516)
static void C_ccall f_9516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9521)
static void C_fcall f_9521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9566)
static void C_ccall f_9566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9570)
static void C_ccall f_9570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9531)
static void C_ccall f_9531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9555)
static void C_ccall f_9555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9540)
static void C_fcall f_9540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8879)
static void C_ccall f_8879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8955)
static void C_ccall f_8955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8965)
static void C_fcall f_8965(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9058)
static void C_fcall f_9058(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9181)
static void C_ccall f_9181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9074)
static void C_fcall f_9074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9121)
static void C_ccall f_9121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9111)
static void C_ccall f_9111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9119)
static void C_ccall f_9119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9223)
static void C_ccall f_9223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9255)
static void C_ccall f_9255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9259)
static void C_ccall f_9259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_9358)
static void C_ccall f_9358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9410)
static void C_ccall f_9410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9402)
static void C_ccall f_9402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9386)
static void C_ccall f_9386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9390)
static void C_ccall f_9390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9394)
static void C_ccall f_9394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_ccall f_8697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8719)
static void C_ccall f_8719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8770)
static void C_ccall f_8770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8742)
static void C_ccall f_8742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8808)
static void C_ccall f_8808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_8822)
static void C_ccall f_8822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8584)
static void C_ccall f_8584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8587)
static void C_ccall f_8587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8590)
static void C_ccall f_8590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8596)
static void C_ccall f_8596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8676)
static void C_ccall f_8676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8608)
static void C_ccall f_8608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8670)
static void C_ccall f_8670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_fcall f_7646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7664)
static void C_ccall f_7664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7670)
static void C_ccall f_7670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8617)
static void C_ccall f_8617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8659)
static void C_ccall f_8659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8657)
static void C_ccall f_8657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8620)
static void C_ccall f_8620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8623)
static void C_ccall f_8623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8626)
static void C_ccall f_8626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8650)
static void C_ccall f_8650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8629)
static void C_ccall f_8629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8632)
static void C_ccall f_8632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8638)
static void C_ccall f_8638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8644)
static void C_ccall f_8644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8437)
static void C_fcall f_8437(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8443)
static void C_ccall f_8443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8567)
static void C_ccall f_8567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8467)
static void C_fcall f_8467(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8508)
static void C_fcall f_8508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8490)
static void C_ccall f_8490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8497)
static void C_ccall f_8497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_fcall f_8350(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8408)
static void C_ccall f_8408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8378)
static void C_ccall f_8378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8100)
static void C_fcall f_8100(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8141)
static void C_ccall f_8141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8144)
static void C_ccall f_8144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8296)
static void C_ccall f_8296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8283)
static void C_ccall f_8283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8266)
static void C_ccall f_8266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8184)
static void C_ccall f_8184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8180)
static void C_ccall f_8180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_fcall f_7899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7906)
static void C_ccall f_7906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7986)
static void C_ccall f_7986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8008)
static void C_ccall f_8008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7996)
static void C_ccall f_7996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7680)
static void C_fcall f_7680(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7686)
static void C_fcall f_7686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7705)
static void C_fcall f_7705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7767)
static void C_ccall f_7767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7716)
static void C_fcall f_7716(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7436)
static void C_fcall f_7436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7442)
static void C_fcall f_7442(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7461)
static void C_fcall f_7461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7520)
static void C_fcall f_7520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7529)
static void C_ccall f_7529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_fcall f_7472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7490)
static void C_ccall f_7490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_fcall f_7337(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7392)
static void C_fcall f_7392(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_fcall f_7140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7294)
static void C_ccall f_7294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_fcall f_7143(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7211)
static void C_fcall f_7211(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_fcall f_7168(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7171)
static void C_fcall f_7171(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7176)
static void C_ccall f_7176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7040)
static void C_fcall f_7040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7077)
static void C_fcall f_7077(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_fcall f_5945(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6107)
static void C_fcall f_6107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_fcall f_6110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6386)
static void C_fcall f_6386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6358)
static void C_fcall f_6358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6305)
static void C_ccall f_6305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_fcall f_6311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_fcall f_6270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6248)
static void C_ccall f_6248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_fcall f_6526(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6540)
static void C_ccall f_6540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6546)
static void C_fcall f_6546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6836)
static void C_ccall f_6836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6582)
static void C_ccall f_6582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5835)
static void C_ccall f_5835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5861)
static void C_fcall f_5861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_fcall f_3987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5769)
static void C_fcall f_5769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_fcall f_5292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_fcall f_5223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_fcall f_4967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_fcall f_4823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_fcall f_4599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_fcall f_4602(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_fcall f_4158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_fcall f_4155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_fcall f_4022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_fcall f_3965(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3707)
static void C_fcall f_3707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_fcall f_3620(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3626)
static void C_fcall f_3626(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_fcall f_3414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_fcall f_3429(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_fcall f_3441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_fcall f_3450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_fcall f_3203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_fcall f_3215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_fcall f_3230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_fcall f_3145(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3141)
static C_word C_fcall f_3141(C_word t0);
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_fcall f_3023(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_fcall f_2008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_fcall f_2977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_fcall f_2948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_fcall f_2524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_fcall f_2545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_fcall f_2741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_fcall f_2596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_fcall f_2434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_fcall f_2392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_fcall f_2111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_fcall f_2033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_fcall f_2072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_fcall f_1903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_fcall f_1700(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_fcall f_1743(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static C_word C_fcall f_1696(C_word t0);
C_noret_decl(f_1686)
static C_word C_fcall f_1686(C_word t0);
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1670)
static void C_fcall f_1670(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1509)
static void C_fcall f_1509(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_fcall f_1534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_fcall f_1497(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static C_word C_fcall f_1464(C_word *a,C_word t0,C_word t1);

C_noret_decl(trf_9521)
static void C_fcall trf_9521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9521(t0,t1,t2);}

C_noret_decl(trf_9540)
static void C_fcall trf_9540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9540(t0,t1);}

C_noret_decl(trf_8965)
static void C_fcall trf_8965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8965(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8965(t0,t1,t2,t3);}

C_noret_decl(trf_9058)
static void C_fcall trf_9058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9058(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9058(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9074)
static void C_fcall trf_9074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9074(t0,t1);}

C_noret_decl(trf_7646)
static void C_fcall trf_7646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7646(t0,t1,t2,t3);}

C_noret_decl(trf_8437)
static void C_fcall trf_8437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8437(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8437(t0,t1,t2);}

C_noret_decl(trf_8467)
static void C_fcall trf_8467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8467(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8467(t0,t1,t2,t3);}

C_noret_decl(trf_8508)
static void C_fcall trf_8508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8508(t0,t1);}

C_noret_decl(trf_8350)
static void C_fcall trf_8350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8350(t0,t1,t2);}

C_noret_decl(trf_8100)
static void C_fcall trf_8100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8100(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8100(t0,t1,t2,t3);}

C_noret_decl(trf_7899)
static void C_fcall trf_7899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7899(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7899(t0,t1,t2);}

C_noret_decl(trf_7680)
static void C_fcall trf_7680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7680(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7680(t0,t1,t2);}

C_noret_decl(trf_7686)
static void C_fcall trf_7686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7686(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7686(t0,t1,t2,t3);}

C_noret_decl(trf_7705)
static void C_fcall trf_7705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7705(t0,t1);}

C_noret_decl(trf_7716)
static void C_fcall trf_7716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7716(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7716(t0,t1,t2,t3);}

C_noret_decl(trf_7436)
static void C_fcall trf_7436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7436(t0,t1,t2);}

C_noret_decl(trf_7442)
static void C_fcall trf_7442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7442(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7442(t0,t1,t2,t3);}

C_noret_decl(trf_7461)
static void C_fcall trf_7461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7461(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7461(t0,t1);}

C_noret_decl(trf_7520)
static void C_fcall trf_7520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7520(t0,t1);}

C_noret_decl(trf_7472)
static void C_fcall trf_7472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7472(t0,t1,t2,t3);}

C_noret_decl(trf_7337)
static void C_fcall trf_7337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7337(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7337(t0,t1,t2,t3);}

C_noret_decl(trf_7392)
static void C_fcall trf_7392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7392(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7392(t0,t1,t2,t3);}

C_noret_decl(trf_7140)
static void C_fcall trf_7140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7140(t0,t1,t2);}

C_noret_decl(trf_7143)
static void C_fcall trf_7143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7143(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7143(t0,t1,t2,t3);}

C_noret_decl(trf_7211)
static void C_fcall trf_7211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7211(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7211(t0,t1,t2,t3);}

C_noret_decl(trf_7168)
static void C_fcall trf_7168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7168(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7168(t0,t1);}

C_noret_decl(trf_7171)
static void C_fcall trf_7171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7171(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7171(t0,t1);}

C_noret_decl(trf_7040)
static void C_fcall trf_7040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7040(t0,t1);}

C_noret_decl(trf_7077)
static void C_fcall trf_7077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7077(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7077(t0,t1);}

C_noret_decl(trf_5945)
static void C_fcall trf_5945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5945(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5945(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6107)
static void C_fcall trf_6107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6107(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6107(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6110)
static void C_fcall trf_6110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6110(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6110(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6386)
static void C_fcall trf_6386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6386(t0,t1);}

C_noret_decl(trf_6358)
static void C_fcall trf_6358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6358(t0,t1);}

C_noret_decl(trf_6311)
static void C_fcall trf_6311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6311(t0,t1);}

C_noret_decl(trf_6270)
static void C_fcall trf_6270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6270(t0,t1);}

C_noret_decl(trf_6526)
static void C_fcall trf_6526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6526(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6526(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6546)
static void C_fcall trf_6546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6546(t0,t1);}

C_noret_decl(trf_5861)
static void C_fcall trf_5861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5861(t0,t1,t2,t3);}

C_noret_decl(trf_3987)
static void C_fcall trf_3987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3987(t0,t1);}

C_noret_decl(trf_5769)
static void C_fcall trf_5769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5769(t0,t1);}

C_noret_decl(trf_5292)
static void C_fcall trf_5292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5292(t0,t1);}

C_noret_decl(trf_5223)
static void C_fcall trf_5223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5223(t0,t1);}

C_noret_decl(trf_4967)
static void C_fcall trf_4967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4967(t0,t1);}

C_noret_decl(trf_4823)
static void C_fcall trf_4823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4823(t0,t1);}

C_noret_decl(trf_4599)
static void C_fcall trf_4599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4599(t0,t1);}

C_noret_decl(trf_4602)
static void C_fcall trf_4602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4602(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4602(t0,t1);}

C_noret_decl(trf_4158)
static void C_fcall trf_4158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4158(t0,t1);}

C_noret_decl(trf_4155)
static void C_fcall trf_4155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4155(t0,t1);}

C_noret_decl(trf_4022)
static void C_fcall trf_4022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4022(t0,t1);}

C_noret_decl(trf_3965)
static void C_fcall trf_3965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3965(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3965(t0,t1,t2,t3);}

C_noret_decl(trf_3707)
static void C_fcall trf_3707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3707(t0,t1);}

C_noret_decl(trf_3620)
static void C_fcall trf_3620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3620(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3620(t0,t1,t2,t3);}

C_noret_decl(trf_3626)
static void C_fcall trf_3626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3626(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3626(t0,t1,t2,t3);}

C_noret_decl(trf_3414)
static void C_fcall trf_3414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3414(t0,t1);}

C_noret_decl(trf_3429)
static void C_fcall trf_3429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3429(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3429(t0,t1);}

C_noret_decl(trf_3441)
static void C_fcall trf_3441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3441(t0,t1);}

C_noret_decl(trf_3450)
static void C_fcall trf_3450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3450(t0,t1);}

C_noret_decl(trf_3203)
static void C_fcall trf_3203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3203(t0,t1);}

C_noret_decl(trf_3215)
static void C_fcall trf_3215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3215(t0,t1);}

C_noret_decl(trf_3230)
static void C_fcall trf_3230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3230(t0,t1);}

C_noret_decl(trf_3145)
static void C_fcall trf_3145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3145(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3145(t0,t1,t2,t3);}

C_noret_decl(trf_3023)
static void C_fcall trf_3023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3023(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3023(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2008)
static void C_fcall trf_2008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2008(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2008(t0,t1,t2);}

C_noret_decl(trf_2977)
static void C_fcall trf_2977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2977(t0,t1);}

C_noret_decl(trf_2948)
static void C_fcall trf_2948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2948(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2948(t0,t1);}

C_noret_decl(trf_2524)
static void C_fcall trf_2524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2524(t0,t1);}

C_noret_decl(trf_2545)
static void C_fcall trf_2545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2545(t0,t1);}

C_noret_decl(trf_2741)
static void C_fcall trf_2741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2741(t0,t1);}

C_noret_decl(trf_2596)
static void C_fcall trf_2596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2596(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2596(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2434)
static void C_fcall trf_2434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2434(t0,t1);}

C_noret_decl(trf_2392)
static void C_fcall trf_2392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2392(t0,t1);}

C_noret_decl(trf_2111)
static void C_fcall trf_2111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2111(t0,t1);}

C_noret_decl(trf_2033)
static void C_fcall trf_2033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2033(t0,t1,t2);}

C_noret_decl(trf_2072)
static void C_fcall trf_2072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2072(t0,t1);}

C_noret_decl(trf_1903)
static void C_fcall trf_1903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1903(t0,t1);}

C_noret_decl(trf_1700)
static void C_fcall trf_1700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1700(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1700(t0,t1,t2);}

C_noret_decl(trf_1743)
static void C_fcall trf_1743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1743(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1743(t0,t1);}

C_noret_decl(trf_1670)
static void C_fcall trf_1670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1670(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1670(t0,t1,t2,t3);}

C_noret_decl(trf_1509)
static void C_fcall trf_1509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1509(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1509(t0,t1,t2,t3);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1534)
static void C_fcall trf_1534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1534(t0,t1);}

C_noret_decl(trf_1497)
static void C_fcall trf_1497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1497(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1497(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1914)){
C_save(t1);
C_rereclaim2(1914*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,259);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],34,"\010compilerscan-toplevel-assignments");
lf[2]=C_h_intern(&lf[2],12,"always-bound");
lf[3]=C_h_intern(&lf[3],6,"append");
lf[4]=C_h_intern(&lf[4],18,"\010compilerdebugging");
lf[5]=C_h_intern(&lf[5],1,"o");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[7]=C_h_intern(&lf[7],12,"\003sysfor-each");
lf[8]=C_h_intern(&lf[8],13,"\004corevariable");
lf[9]=C_h_intern(&lf[9],2,"if");
lf[10]=C_h_intern(&lf[10],3,"let");
lf[11]=C_h_intern(&lf[11],6,"lambda");
lf[12]=C_h_intern(&lf[12],13,"\004corecallunit");
lf[13]=C_h_intern(&lf[13],9,"\004corecall");
lf[14]=C_h_intern(&lf[14],4,"set!");
lf[15]=C_h_intern(&lf[15],9,"\004corecond");
lf[16]=C_h_intern(&lf[16],11,"\004coreswitch");
lf[17]=C_h_intern(&lf[17],30,"call-with-current-continuation");
lf[18]=C_h_intern(&lf[18],1,"p");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[20]=C_h_intern(&lf[20],24,"\010compilersimplifications");
lf[21]=C_h_intern(&lf[21],23,"\010compilersimplified-ops");
lf[22]=C_h_intern(&lf[22],41,"\010compilerperform-high-level-optimizations");
lf[23]=C_h_intern(&lf[23],12,"\010compilerget");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],10,"alist-cons");
lf[26]=C_h_intern(&lf[26],4,"caar");
lf[27]=C_h_intern(&lf[27],7,"\003sysmap");
lf[28]=C_h_intern(&lf[28],19,"\010compilermatch-node");
lf[29]=C_h_intern(&lf[29],3,"any");
lf[30]=C_h_intern(&lf[30],18,"\003syshash-table-ref");
lf[31]=C_h_intern(&lf[31],30,"\010compilerbroken-constant-nodes");
lf[32]=C_h_intern(&lf[32],11,"lset-adjoin");
lf[33]=C_h_intern(&lf[33],3,"eq\077");
lf[34]=C_h_intern(&lf[34],4,"node");
lf[35]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[36]=C_h_intern(&lf[36],14,"\010compilerqnode");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[38]=C_h_intern(&lf[38],4,"eval");
lf[39]=C_h_intern(&lf[39],22,"with-exception-handler");
lf[40]=C_h_intern(&lf[40],5,"every");
lf[41]=C_h_intern(&lf[41],8,"foldable");
lf[42]=C_h_intern(&lf[42],16,"extended-binding");
lf[43]=C_h_intern(&lf[43],16,"standard-binding");
lf[44]=C_h_intern(&lf[44],5,"value");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[46]=C_h_intern(&lf[46],16,"\010compilervarnode");
lf[47]=C_h_intern(&lf[47],11,"collapsable");
lf[48]=C_h_intern(&lf[48],10,"replacable");
lf[49]=C_h_intern(&lf[49],9,"replacing");
lf[50]=C_h_intern(&lf[50],12,"contractable");
lf[51]=C_h_intern(&lf[51],9,"removable");
lf[52]=C_h_intern(&lf[52],11,"\004corelambda");
lf[53]=C_h_intern(&lf[53],6,"unused");
lf[54]=C_h_intern(&lf[54],9,"partition");
lf[55]=C_h_intern(&lf[55],26,"\010compilerbuild-lambda-list");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[57]=C_h_intern(&lf[57],13,"explicit-rest");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[59]=C_h_intern(&lf[59],30,"\010compilerdecompose-lambda-list");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[61]=C_h_intern(&lf[61],21,"has-unused-parameters");
lf[62]=C_h_intern(&lf[62],31,"\010compilerinline-lambda-bindings");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[64]=C_h_intern(&lf[64],24,"\010compilercheck-signature");
lf[65]=C_h_intern(&lf[65],30,"\010compilerconstant-declarations");
lf[66]=C_h_intern(&lf[66],14,"\004coreundefined");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[68]=C_h_intern(&lf[68],1,"x");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[70]=C_h_intern(&lf[70],37,"\010compilerexpression-has-side-effects\077");
lf[71]=C_h_intern(&lf[71],8,"assigned");
lf[72]=C_h_intern(&lf[72],10,"references");
lf[73]=C_h_intern(&lf[73],7,"unknown");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[75]=C_h_intern(&lf[75],1,"i");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\023procedure inlinable");
lf[77]=C_h_intern(&lf[77],14,"append-reverse");
lf[78]=C_h_intern(&lf[78],6,"gensym");
lf[79]=C_h_intern(&lf[79],1,"t");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[81]=C_h_intern(&lf[81],8,"split-at");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[83]=C_h_intern(&lf[83],20,"\004coreinline_allocate");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[85]=C_h_intern(&lf[85],24,"\010compilernot-inline-list");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilerinline-max-size");
lf[88]=C_h_intern(&lf[88],9,"inlinable");
lf[89]=C_h_intern(&lf[89],6,"simple");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[91]=C_h_intern(&lf[91],26,"\010compilerblock-compilation");
lf[92]=C_h_intern(&lf[92],20,"\010compilerexport-list");
lf[93]=C_h_intern(&lf[93],6,"global");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[97]=C_h_intern(&lf[97],5,"print");
lf[98]=C_h_intern(&lf[98],7,"newline");
lf[99]=C_h_intern(&lf[99],6,"print*");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[103]=C_h_intern(&lf[103],34,"\010compilerperform-pre-optimization!");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[105]=C_h_intern(&lf[105],24,"node-subexpressions-set!");
lf[106]=C_h_intern(&lf[106],20,"node-parameters-set!");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\034removed call in test-context");
lf[109]=C_h_intern(&lf[109],10,"call-sites");
lf[110]=C_h_intern(&lf[110],67,"\010compilerside-effect-free-standard-bindings-that-never-return-false");
lf[111]=C_h_intern(&lf[111],7,"reverse");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[113]=C_h_intern(&lf[113],3,"not");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[115]=C_h_intern(&lf[115],24,"register-simplifications");
lf[116]=C_h_intern(&lf[116],19,"\003syshash-table-set!");
lf[117]=C_h_intern(&lf[117],38,"\010compilerreorganize-recursive-bindings");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[119]=C_h_intern(&lf[119],10,"fold-right");
lf[120]=C_h_intern(&lf[120],4,"fold");
lf[121]=C_h_intern(&lf[121],25,"\010compilertopological-sort");
lf[122]=C_h_intern(&lf[122],6,"lset<=");
lf[123]=C_h_intern(&lf[123],10,"filter-map");
lf[124]=C_h_intern(&lf[124],6,"filter");
lf[125]=C_h_intern(&lf[125],10,"append-map");
lf[126]=C_h_intern(&lf[126],28,"\010compilerscan-used-variables");
lf[127]=C_h_intern(&lf[127],8,"for-each");
lf[128]=C_h_intern(&lf[128],3,"map");
lf[129]=C_h_intern(&lf[129],4,"cons");
lf[130]=C_h_intern(&lf[130],27,"\010compilersubstitution-table");
lf[131]=C_h_intern(&lf[131],16,"\010compilerrewrite");
lf[132]=C_h_intern(&lf[132],28,"\010compilersimplify-named-call");
lf[133]=C_h_intern(&lf[133],37,"\010compilerinline-substitutions-enabled");
lf[134]=C_h_intern(&lf[134],11,"\004coreinline");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[137]=C_h_intern(&lf[137],6,"unsafe");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[139]=C_h_intern(&lf[139],6,"vector");
lf[140]=C_h_intern(&lf[140],14,"rest-parameter");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_h_intern(&lf[142],11,"number-type");
lf[143]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[147]=C_h_intern(&lf[147],6,"fixnum");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_h_intern(&lf[149],21,"\010compilerfold-boolean");
lf[150]=C_h_intern(&lf[150],6,"flonum");
lf[151]=C_h_intern(&lf[151],7,"generic");
lf[152]=C_h_intern(&lf[152],5,"cons*");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_h_intern(&lf[154],9,"\004coreproc");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_h_intern(&lf[163],19,"\010compilerfold-inner");
lf[164]=C_h_intern(&lf[164],6,"remove");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_h_intern(&lf[169],5,"fifth");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_h_intern(&lf[171],13,"\010compilerbomb");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[173]=C_h_intern(&lf[173],34,"\010compilertransform-direct-lambdas!");
lf[174]=C_h_intern(&lf[174],19,"\010compilercopy-node!");
lf[175]=C_h_intern(&lf[175],16,"\004coredirect_call");
lf[176]=C_h_intern(&lf[176],4,"quit");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[178]=C_h_intern(&lf[178],15,"lset-difference");
lf[179]=C_h_intern(&lf[179],15,"node-class-set!");
lf[180]=C_h_intern(&lf[180],12,"\004corerecurse");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[182]=C_h_intern(&lf[182],4,"take");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[185]=C_h_intern(&lf[185],11,"\004corereturn");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[187]=C_h_intern(&lf[187],18,"\004coredirect_lambda");
lf[188]=C_h_intern(&lf[188],6,"cdaddr");
lf[189]=C_h_intern(&lf[189],6,"caaddr");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[192]=C_h_intern(&lf[192],6,"unzip1");
lf[193]=C_h_intern(&lf[193],16,"\003sysmake-promise");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[195]=C_h_intern(&lf[195],5,"boxed");
lf[196]=C_h_intern(&lf[196],15,"\004coreinline_ref");
lf[197]=C_h_intern(&lf[197],37,"\010compilerestimate-foreign-result-size");
lf[198]=C_h_intern(&lf[198],19,"\004coreinline_loc_ref");
lf[199]=C_h_intern(&lf[199],5,"lset=");
lf[200]=C_h_intern(&lf[200],6,"delete");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[202]=C_h_intern(&lf[202],32,"\010compilerperform-lambda-lifting!");
lf[203]=C_h_intern(&lf[203],23,"\003syshash-table-for-each");
lf[204]=C_h_intern(&lf[204],1,"+");
lf[205]=C_h_intern(&lf[205],17,"delete-duplicates");
lf[206]=C_h_intern(&lf[206],14,"\004coreprimitive");
lf[207]=C_h_intern(&lf[207],7,"delete!");
lf[208]=C_h_intern(&lf[208],11,"concatenate");
lf[209]=C_h_intern(&lf[209],5,"count");
lf[210]=C_h_intern(&lf[210],22,"\010compilerblock-globals");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[214]=C_h_intern(&lf[214],12,"pretty-print");
lf[215]=C_h_intern(&lf[215],1,"l");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[226]=C_h_intern(&lf[226],11,"make-vector");
lf[227]=C_h_intern(&lf[227],3,"var");
lf[228]=C_h_intern(&lf[228],2,"d2");
lf[229]=C_h_intern(&lf[229],1,"y");
lf[230]=C_h_intern(&lf[230],2,"d3");
lf[231]=C_h_intern(&lf[231],1,"z");
lf[232]=C_h_intern(&lf[232],2,"d1");
lf[233]=C_h_intern(&lf[233],2,"op");
lf[234]=C_h_intern(&lf[234],5,"clist");
lf[235]=C_h_intern(&lf[235],34,"\010compilermembership-test-operators");
lf[236]=C_h_intern(&lf[236],32,"\010compilermembership-unfold-limit");
lf[237]=C_h_intern(&lf[237],4,"var1");
lf[238]=C_h_intern(&lf[238],4,"var0");
lf[239]=C_h_intern(&lf[239],6,"const1");
lf[240]=C_h_intern(&lf[240],4,"var2");
lf[241]=C_h_intern(&lf[241],6,"const2");
lf[242]=C_h_intern(&lf[242],5,"body2");
lf[243]=C_h_intern(&lf[243],4,"rest");
lf[244]=C_h_intern(&lf[244],5,"body1");
lf[245]=C_h_intern(&lf[245],27,"\010compilereq-inline-operator");
lf[246]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[247]=C_h_intern(&lf[247],19,"\010compilerimmediate\077");
lf[248]=C_h_intern(&lf[248],5,"const");
lf[249]=C_h_intern(&lf[249],1,"n");
lf[250]=C_h_intern(&lf[250],7,"clauses");
lf[251]=C_h_intern(&lf[251],1,"d");
lf[252]=C_h_intern(&lf[252],4,"body");
lf[253]=C_h_intern(&lf[253],4,"more");
lf[254]=C_h_intern(&lf[254],4,"args");
lf[255]=C_h_intern(&lf[255],1,"a");
lf[256]=C_h_intern(&lf[256],1,"b");
lf[257]=C_h_intern(&lf[257],1,"c");
lf[258]=C_h_intern(&lf[258],4,"cdar");
C_register_lf2(lf,259,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1448 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1451 in k1448 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1454 in k1451 in k1448 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_mutate((C_word*)lf[1]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1461,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 141  make-vector */
t5=*((C_word*)lf[226]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=C_mutate((C_word*)lf[20]+1,t1);
t3=C_set_block_item(lf[21],0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1667,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3138,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3599,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,lf[255]);
t9=(C_word)C_a_i_list(&a,2,lf[8],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[256],lf[257]);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[251],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[13],t12);
t14=(C_word)C_a_i_list(&a,4,lf[255],lf[256],lf[257],lf[251]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9508,tmp=(C_word)a,a+=2,tmp);
t16=(C_word)C_a_i_list(&a,3,t13,t14,t15);
/* optimizer.scm: 533  register-simplifications */
t17=C_retrieve(lf[115]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t7,lf[13],t16);}

/* a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_9508,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9516,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 539  ##sys#hash-table-ref */
t8=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,C_retrieve(lf[130]),t3);}

/* k9514 in a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9516,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_9521(t6,((C_word*)t0)[2],t2);}

/* loop in k9514 in a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_9521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9521,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9531,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9566,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 541  caar */
t5=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k9564 in loop in k9514 in a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9570,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 541  cdar */
t3=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9568 in k9564 in loop in k9514 in a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 541  simplify-named-call */
t2=C_retrieve(lf[132]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9529 in loop in k9514 in a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9531,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[21]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9540,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_9540(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9555,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 546  alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[21]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 548  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9521(t3,((C_word*)t0)[4],t2);}}

/* k9553 in k9529 in loop in k9514 in a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[21]+1,t1);
t3=((C_word*)t0)[2];
f_9540(t3,t2);}

/* k9538 in k9529 in loop in k9514 in a9507 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_9540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[237]);
t4=(C_word)C_a_i_list(&a,1,lf[233]);
t5=(C_word)C_a_i_list(&a,1,lf[238]);
t6=(C_word)C_a_i_list(&a,2,lf[8],t5);
t7=(C_word)C_a_i_list(&a,1,lf[239]);
t8=(C_word)C_a_i_list(&a,2,lf[24],t7);
t9=(C_word)C_a_i_list(&a,4,lf[134],t4,t6,t8);
t10=(C_word)C_a_i_list(&a,1,lf[237]);
t11=(C_word)C_a_i_list(&a,2,lf[8],t10);
t12=(C_word)C_a_i_list(&a,1,lf[240]);
t13=(C_word)C_a_i_list(&a,1,lf[233]);
t14=(C_word)C_a_i_list(&a,1,lf[238]);
t15=(C_word)C_a_i_list(&a,2,lf[8],t14);
t16=(C_word)C_a_i_list(&a,1,lf[241]);
t17=(C_word)C_a_i_list(&a,2,lf[24],t16);
t18=(C_word)C_a_i_list(&a,4,lf[134],t13,t15,t17);
t19=(C_word)C_a_i_list(&a,1,lf[240]);
t20=(C_word)C_a_i_list(&a,2,lf[8],t19);
t21=(C_word)C_a_i_list(&a,5,lf[9],lf[228],t20,lf[242],lf[243]);
t22=(C_word)C_a_i_list(&a,4,lf[10],t12,t18,t21);
t23=(C_word)C_a_i_list(&a,5,lf[9],lf[232],t11,lf[244],t22);
t24=(C_word)C_a_i_list(&a,4,lf[10],t3,t9,t23);
t25=(C_word)C_a_i_list(&a,11,lf[238],lf[237],lf[240],lf[233],lf[239],lf[241],lf[244],lf[242],lf[232],lf[228],lf[243]);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9345,tmp=(C_word)a,a+=2,tmp);
t27=(C_word)C_a_i_list(&a,3,t24,t25,t26);
t28=(C_word)C_a_i_list(&a,1,lf[227]);
t29=(C_word)C_a_i_list(&a,1,lf[233]);
t30=(C_word)C_a_i_list(&a,1,lf[238]);
t31=(C_word)C_a_i_list(&a,2,lf[8],t30);
t32=(C_word)C_a_i_list(&a,1,lf[248]);
t33=(C_word)C_a_i_list(&a,2,lf[24],t32);
t34=(C_word)C_a_i_list(&a,4,lf[134],t29,t31,t33);
t35=(C_word)C_a_i_list(&a,1,lf[227]);
t36=(C_word)C_a_i_list(&a,2,lf[8],t35);
t37=(C_word)C_a_i_list(&a,1,lf[249]);
t38=(C_word)C_a_i_list(&a,1,lf[238]);
t39=(C_word)C_a_i_list(&a,2,lf[8],t38);
t40=(C_word)C_a_i_cons(&a,2,t39,lf[250]);
t41=(C_word)C_a_i_cons(&a,2,t37,t40);
t42=(C_word)C_a_i_cons(&a,2,lf[16],t41);
t43=(C_word)C_a_i_list(&a,5,lf[9],lf[251],t36,lf[252],t42);
t44=(C_word)C_a_i_list(&a,4,lf[10],t28,t34,t43);
t45=(C_word)C_a_i_list(&a,8,lf[227],lf[233],lf[238],lf[248],lf[251],lf[252],lf[249],lf[250]);
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9223,tmp=(C_word)a,a+=2,tmp);
t47=(C_word)C_a_i_list(&a,3,t44,t45,t46);
t48=(C_word)C_a_i_list(&a,1,lf[237]);
t49=(C_word)C_a_i_list(&a,2,lf[66],C_SCHEME_END_OF_LIST);
t50=(C_word)C_a_i_list(&a,4,lf[10],t48,t49,lf[253]);
t51=(C_word)C_a_i_list(&a,2,lf[237],lf[253]);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8955,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_list(&a,3,t50,t51,t52);
t54=(C_word)C_a_i_list(&a,1,lf[227]);
t55=(C_word)C_a_i_list(&a,1,lf[233]);
t56=(C_word)C_a_i_cons(&a,2,t55,lf[254]);
t57=(C_word)C_a_i_cons(&a,2,lf[134],t56);
t58=(C_word)C_a_i_list(&a,1,lf[227]);
t59=(C_word)C_a_i_list(&a,2,lf[8],t58);
t60=(C_word)C_a_i_list(&a,5,lf[9],lf[251],t59,lf[68],lf[229]);
t61=(C_word)C_a_i_list(&a,4,lf[10],t54,t57,t60);
t62=(C_word)C_a_i_list(&a,6,lf[227],lf[233],lf[254],lf[251],lf[68],lf[229]);
t63=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8879,tmp=(C_word)a,a+=2,tmp);
t64=(C_word)C_a_i_list(&a,3,t61,t62,t63);
/* optimizer.scm: 551  register-simplifications */
t65=C_retrieve(lf[115]);
((C_proc7)C_retrieve_proc(t65))(7,t65,t2,lf[10],t27,t47,t53,t64);}

/* a8878 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8879,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[245])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8913,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 686  get */
t10=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,t2,t3,lf[72]);}}

/* k8911 in a8878 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8913,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[34],lf[9],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8955,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8965,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_8965(t9,t1,t5,t4);}

/* loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_8965(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8965,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[66]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
/* optimizer.scm: 632  loop1 */
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[14]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9029,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 634  reverse */
t19=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k9027 in loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9029,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9058,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_9058(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k9027 in loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_9058(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9058,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9074,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[10]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9181,a[2]=t10,a[3]=t3,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t8);
/* optimizer.scm: 645  get */
t16=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t14,((C_word*)t0)[2],t15,lf[72]);}
else{
t14=t11;
f_9074(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_9074(t13,C_SCHEME_FALSE);}}

/* k9179 in loop2 in k9027 in loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9074(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[14],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_9074(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_9074(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_9074(t2,C_SCHEME_FALSE);}}}

/* k9072 in loop2 in k9027 in loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_9074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9074,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 649  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_9058(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9111,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9121,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 653  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a9120 in k9072 in loop2 in k9027 in loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9121,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a9110 in k9072 in loop2 in k9027 in loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 654  reverse */
t3=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9117 in a9110 in k9072 in loop2 in k9027 in loop1 in a8954 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 654  reorganize-recursive-bindings */
t2=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a9222 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_9223,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[245])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9236,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 598  immediate? */
t12=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k9234 in a9222 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9236,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9271,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 599  get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9269 in k9234 in a9222 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9271,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9248,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 603  varnode */
t8=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9253 in k9269 in k9234 in a9222 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 604  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9257 in k9253 in k9269 in k9234 in a9222 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 603  cons* */
t2=C_retrieve(lf[152]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9246 in k9269 in k9234 in a9222 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9248,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[16],((C_word*)t0)[2],t1));}

/* a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_9345,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[245])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9358,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 571  immediate? */
t15=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k9356 in a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9358,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 572  immediate? */
t3=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9362 in k9356 in a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9364,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 573  get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9408 in k9362 in k9356 in a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9410,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9402,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 574  get */
t5=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[72]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9400 in k9408 in k9362 in k9356 in a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9402,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 578  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9384 in k9400 in k9408 in k9362 in k9356 in a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 579  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9388 in k9384 in k9400 in k9408 in k9362 in k9356 in a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 581  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9392 in k9388 in k9384 in k9400 in k9408 in k9362 in k9356 in a9344 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_9394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9394,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[16],lf[246],t2));}

/* k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[227]);
t4=(C_word)C_a_i_list(&a,2,lf[8],t3);
t5=(C_word)C_a_i_list(&a,4,lf[13],lf[228],t4,lf[229]);
t6=(C_word)C_a_i_list(&a,1,lf[227]);
t7=(C_word)C_a_i_list(&a,2,lf[8],t6);
t8=(C_word)C_a_i_list(&a,4,lf[13],lf[230],t7,lf[231]);
t9=(C_word)C_a_i_list(&a,5,lf[9],lf[232],lf[68],t5,t8);
t10=(C_word)C_a_i_list(&a,7,lf[232],lf[228],lf[230],lf[68],lf[229],lf[231],lf[227]);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8808,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_a_i_list(&a,3,t9,t10,t11);
t13=(C_word)C_a_i_list(&a,1,lf[233]);
t14=(C_word)C_a_i_list(&a,1,lf[234]);
t15=(C_word)C_a_i_list(&a,2,lf[24],t14);
t16=(C_word)C_a_i_list(&a,4,lf[134],t13,lf[68],t15);
t17=(C_word)C_a_i_list(&a,5,lf[9],lf[232],t16,lf[229],lf[231]);
t18=(C_word)C_a_i_list(&a,6,lf[232],lf[233],lf[68],lf[234],lf[229],lf[231]);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8697,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_list(&a,3,t17,t18,t19);
/* optimizer.scm: 693  register-simplifications */
t21=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t2,lf[9],t12,t20);}

/* a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8697,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[235]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[236]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8719,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 724  gensym */
t13=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8717 in a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8719,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8742,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8744,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8774,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 741  qnode */
t9=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_FALSE);}

/* k8772 in k8717 in a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 733  fold-right */
t2=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a8743 in k8717 in a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8744,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8766,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 738  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k8764 in a8743 in k8717 in a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 738  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8768 in k8764 in a8743 in k8717 in a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8770,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 739  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k8760 in k8768 in k8764 in a8743 in k8717 in a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8762,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[15],C_SCHEME_END_OF_LIST,t2));}

/* k8740 in k8717 in a8696 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8742,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[9],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t4));}

/* a8807 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_8808,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8822,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 709  varnode */
t11=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8820 in a8807 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8822,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[15],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t4));}

/* k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3614,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 836  make-vector */
t4=*((C_word*)lf[226]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1,t1);
t3=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3942,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3962,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5942,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7037,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7037,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7040,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7140,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7337,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7436,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7680,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7899,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8100,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8350,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8437,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8584,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1816 debugging */
t16=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[18],lf[225]);}

/* k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1817 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_7040(t3,t2);}

/* k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8590,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1818 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[224]);}

/* k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1819 build-call-graph */
t3=((C_word*)t0)[2];
f_7140(t3,t2,((C_word*)t0)[3]);}

/* k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8596,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1820 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[223]);}

/* k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1821 eliminate */
t3=((C_word*)t0)[4];
f_7337(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8602,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8676,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1822 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[222]);}

/* k8674 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1822 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8602(2,t2,C_SCHEME_UNDEFINED);}}

/* k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1823 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[221]);}

/* k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1824 collect-accessibles */
t3=((C_word*)t0)[2];
f_7436(t3,t2,((C_word*)t0)[3]);}

/* k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8670,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1825 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[220]);}

/* k8668 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1825 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8611(2,t2,C_SCHEME_UNDEFINED);}}

/* k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1826 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[219]);}

/* k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8617,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8667,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1827 eliminate4 */
t4=((C_word*)t0)[3];
f_7680(t4,t3,((C_word*)t0)[2]);}

/* k8665 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8667,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7646,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7646(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8665 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7646,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7664,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1621 filter */
t6=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,t2);}

/* a7663 in loop in k8665 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7664,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1621 every */
t5=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a7669 in a7663 in loop in k8665 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7670,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k7648 in loop in k8665 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1625 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7646(t5,((C_word*)t0)[3],t1,t2);}}

/* k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8657,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1828 ##sys#make-promise */
t5=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8658 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8659,2,t0,t1);}
/* optimizer.scm: 1828 unzip1 */
t2=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k8655 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1828 debugging */
t2=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[5],lf[218],t1);}

/* k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1829 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[217]);}

/* k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1830 compute-extra-variables */
t3=((C_word*)t0)[2];
f_7899(t3,t2,((C_word*)t0)[5]);}

/* k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8650,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1831 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[216]);}

/* k8648 in k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1831 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8629(2,t2,C_SCHEME_UNDEFINED);}}

/* k8627 in k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1832 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[213]);}

/* k8630 in k8627 in k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1833 extend-call-sites! */
t3=((C_word*)t0)[2];
f_8350(t3,t2,((C_word*)t0)[4]);}

/* k8633 in k8630 in k8627 in k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1834 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[212]);}

/* k8636 in k8633 in k8630 in k8627 in k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1835 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_8437(t3,t2,((C_word*)t0)[4]);}

/* k8639 in k8636 in k8633 in k8630 in k8627 in k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1836 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[211]);}

/* k8642 in k8639 in k8636 in k8633 in k8630 in k8627 in k8624 in k8621 in k8618 in k8615 in k8612 in k8609 in k8606 in k8603 in k8600 in k8597 in k8594 in k8591 in k8588 in k8585 in k8582 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1837 reconstruct! */
t2=((C_word*)t0)[5];
f_8100(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_8437(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8437,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8443,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8443(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8443,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8462,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t10,((C_word*)((C_word*)t0)[2])[1],t12);}
else{
t10=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8555,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
/* for-each */
t14=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,((C_word*)((C_word*)t0)[2])[1],t13);}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* k8553 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8555,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1811 node-class-set! */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[66]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8562 in k8553 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1812 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8565 in k8562 in k8553 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1813 node-subexpressions-set! */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8460 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8462,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8467,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_8467(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do1378 in k8460 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_8467(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8467,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1801 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8490,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1803 reverse */
t6=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8508,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_8508(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_8508(t12,t11);}}}

/* k8506 in do1378 in k8460 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_8508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_8467(t4,((C_word*)t0)[2],t2,t3);}

/* k8503 in do1378 in k8460 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1803 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8488 in do1378 in k8460 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8497,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8501,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1804 reverse */
t4=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k8499 in k8488 in do1378 in k8460 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1804 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8495 in k8488 in do1378 in k8460 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1804 node-subexpressions-set! */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_8350(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8350,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8356,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8356(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8356,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[13]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8378,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[8],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8408,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8412,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
/* map */
t21=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[46]),t20);}
else{
t17=t11;
f_8378(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_8378(2,t14,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t10=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}

/* k8410 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1783 append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k8406 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8408,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1781 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8376 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
/* for-each */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_8100(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8100,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8112,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8114,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
/* optimizer.scm: 1717 fold-right */
t9=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,t2);}

/* a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8114,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8121,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1720 get */
t6=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t4,lf[44]);}

/* k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8121,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_retrieve(lf[210]));
t3=C_mutate((C_word*)lf[210]+1,t2);
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8134,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1722 decompose-lambda-list */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8134,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8141,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[78]),t6);}

/* k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8144,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1727 map */
t3=*((C_word*)lf[128]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[5],t1);}

/* k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8225,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8240,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_8240(3,t9,t2,t4);}

/* walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8240,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8259,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8266,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[8]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8283,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
/* optimizer.scm: 1756 rename */
t13=((C_word*)t0)[2];
f_8225(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8296,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8307,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 1758 rename */
t15=((C_word*)t0)[2];
f_8225(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1761 decompose-lambda-list */
t15=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,t13,t14);}
else{
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}}}

/* a8325 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8326,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8341,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8345,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k8343 in a8325 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1764 build-lambda-list */
t2=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8339 in a8325 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1765 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8240(3,t4,((C_word*)t0)[2],t3);}

/* k8305 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8307,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1758 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8294 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k8281 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8283,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1756 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8264 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1753 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8257 in walk in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8225,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k8145 in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1730 gensym */
t3=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[79]);}

/* k8194 in k8145 in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8196,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8180,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8184,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1736 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8182 in k8194 in k8145 in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1736 build-lambda-list */
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8178 in k8194 in k8145 in k8142 in k8139 in a8133 in k8119 in a8113 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8180,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[11],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[34],lf[14],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t7));}

/* k8110 in reconstruct! in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8112,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1714 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7899,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7964,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8086,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8085 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8086,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7964,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7966,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8041,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8046,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8046,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8084,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1703 get */
t5=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,lf[44]);}

/* k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8084,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7908,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7908(3,t8,t4,t1);}

/* walk in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7908,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7928,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1679 append */
t11=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7946,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1682 decompose-lambda-list */
t13=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t13))(4,t13,t1,t11,t12);}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* a7945 in walk in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7946,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7951,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1685 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7949 in a7945 in walk in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1686 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7908(3,t4,((C_word*)t0)[2],t3);}

/* k7926 in walk in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7904 in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7906,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8062,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8076,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1709 delete-duplicates */
t7=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,*((C_word*)lf[33]+1));}

/* k8074 in k7904 in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1705 remove */
t2=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8061 in k7904 in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8062,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k8058 in k7904 in k8082 in a8045 in k8039 in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8060,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7966,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8034,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1694 count */
t6=C_retrieve(lf[209]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a8033 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8034,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k8030 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8032,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7986,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a8019 in k8030 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8020,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1697 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7966(3,t4,t1,t3);}

/* k7984 in k8030 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7986,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7996,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8004,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8008,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8010,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a8009 in k7984 in k8030 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8010,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k8006 in k7984 in k8030 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1699 concatenate */
t2=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8002 in k7984 in k8030 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1699 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7994 in k7984 in k8030 in walk in k7962 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7680(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7680,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7684,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7686,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7686(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7686,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_7705(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t12)){
t13=t11;
f_7705(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t13)){
t14=t11;
f_7705(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[206]);
t15=t11;
f_7705(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[154])));}}}}

/* k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7705,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7716,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7716(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1644 decompose-lambda-list */
t6=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1650 call-with-current-continuation */
t8=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a7871 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7872,3,t0,t1,t2);}
/* optimizer.scm: 1665 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7686(t3,t1,t2,((C_word*)t0)[2]);}

/* a7801 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7802,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[8],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7818,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_7818(3,t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a7801 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7818,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7838,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7848,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1659 lset<= */
t9=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[33]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k7846 in loop in a7801 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_7838(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7852,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1661 delete! */
t3=C_retrieve(lf[207]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[33]+1));}}

/* k7850 in k7846 in loop in a7801 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1662 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7836 in loop in a7801 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7789 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7796,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7795 in k7789 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7796,3,t0,t1,t2);}
/* optimizer.scm: 1664 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7686(t3,t1,t2,((C_word*)t0)[2]);}

/* a7766 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7767,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7779,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1647 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7777 in a7766 in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1647 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7686(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7716(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7716,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7734,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1639 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7737,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1641 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7686(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7735 in loop in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1642 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7716(t4,((C_word*)t0)[2],t2,t3);}

/* k7732 in loop in k7703 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1639 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7686(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7682 in eliminate4 in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7436,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7440,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7442,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_7442(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7442(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7442,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_7461(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t12)){
t13=t11;
f_7461(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t13)){
t14=t11;
f_7461(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[206]);
t15=t11;
f_7461(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[154])));}}}}

/* k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7461,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7472,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7472(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7520,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7554,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1596 alist-cons */
t9=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_7520(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_7520(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7563,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a7562 in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7563,3,t0,t1,t2);}
/* optimizer.scm: 1602 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7442(t3,t1,t2,((C_word*)t0)[2]);}

/* k7552 in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7520(t3,t2);}

/* k7518 in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7520,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1597 decompose-lambda-list */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a7528 in k7518 in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7529,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7541,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1600 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7539 in a7528 in k7518 in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1600 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7442(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7472,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7490,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1587 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7493,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1589 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7442(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7491 in loop in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1590 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7472(t4,((C_word*)t0)[2],t2,t3);}

/* k7488 in loop in k7459 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1587 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7442(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7438 in collect-accessibles in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7337(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7337,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7343,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1557 remove */
t5=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7343,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7377,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7387,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1567 unzip1 */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k7385 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7387,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7392,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7392(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k7385 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7392(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7392,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7399,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1570 lset-difference */
t7=C_retrieve(lf[178]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t5,*((C_word*)lf[33]+1),t6,t3,((C_word*)t0)[2]);}

/* k7397 in count in k7385 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7426,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1571 delete-duplicates */
t4=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,*((C_word*)lf[33]+1));}

/* k7424 in k7397 in count in k7385 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7426,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1572 append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7420 in k7424 in k7397 in count in k7385 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7422,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7412,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7414,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7413 in k7420 in k7424 in k7397 in count in k7385 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7414,3,t0,t1,t2);}
/* optimizer.scm: 1573 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7392(t3,t1,t2,((C_word*)t0)[2]);}

/* k7410 in k7420 in k7424 in k7397 in count in k7385 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1573 fold */
t2=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[204]+1),((C_word*)t0)[2],t1);}

/* k7375 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7377,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1560 any */
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[5],t3,t4);}}

/* a7354 in k7375 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7355,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7362,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1561 get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],t2,lf[71]);}

/* k7360 in a7354 in k7375 in a7342 in eliminate in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7140,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7143,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7292,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7294,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a7293 in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7294,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7309,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7319,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1546 decompose-lambda-list */
t11=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t6,t10);}

/* a7318 in a7293 in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7319,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
/* optimizer.scm: 1549 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7143(t7,t1,t6,t2);}

/* k7307 in a7293 in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7313,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1550 alist-cons */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k7311 in k7307 in a7293 in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7290 in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7143(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7143,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[14]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7168,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7193,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_7193(2,t16,t14);}
else{
/* optimizer.scm: 1522 get */
t16=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t15,((C_word*)t0)[2],t12,lf[93]);}}
else{
t12=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7211,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_7211(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7265,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1534 decompose-lambda-list */
t16=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7282,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t9);}}}}

/* a7281 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7282,3,t0,t1,t2);}
/* optimizer.scm: 1537 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7143(t3,t1,t2,((C_word*)t0)[2]);}

/* a7264 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7265,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7277,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1536 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7275 in a7264 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1536 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7143(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7211(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7211,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7229,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1529 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7235,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1531 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_7143(t7,t5,t6,((C_word*)t0)[3]);}}

/* k7233 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1532 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7211(t4,((C_word*)t0)[2],t2,t3);}

/* k7227 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1529 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7143(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7191 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7193,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7168(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_7168(t4,t3);}}

/* k7166 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7168(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7168,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7171,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_7171(t5,t4);}
else{
t3=t2;
f_7171(t3,C_SCHEME_UNDEFINED);}}

/* k7169 in k7166 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7171(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7171,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7176,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7175 in k7169 in k7166 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7176,3,t0,t1,t2);}
/* optimizer.scm: 1525 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7143(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7040,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7044,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7046,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1493 ##sys#hash-table-for-each */
t6=C_retrieve(lf[203]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7045 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7046,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[44],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[72],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[109],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7077,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[73],t3))){
t10=t9;
f_7077(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[11],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[93],t3))){
t13=t9;
f_7077(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_7077(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_7077(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k7075 in a7045 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_7077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7077,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1504 alist-cons */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7079 in k7075 in a7045 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7081,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7085,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1505 alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k7083 in k7079 in k7075 in a7045 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7042 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5942,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6107,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5945,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7032,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1472 debugging */
t18=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t17,lf[18],lf[201]);}

/* k7030 in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1473 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5945(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7033 in k7030 in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_5945(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(30);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5945,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[52]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5970,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1264 get */
t15=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[2],t2,lf[73]);}
else{
t14=t13;
f_5970(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_5970(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[14]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
/* optimizer.scm: 1274 walk */
t24=t1;
t25=t13;
t26=t14;
t27=C_SCHEME_FALSE;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[10]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6081,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
/* optimizer.scm: 1276 walk */
t24=t14;
t25=t15;
t26=t16;
t27=t3;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6101,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t15=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t8);}}}}

/* a6100 in walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6101,3,t0,t1,t2);}
/* optimizer.scm: 1278 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5945(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k6079 in walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1277 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5945(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k6053 in walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6055,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_5970(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1266 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[44]);}
else{
t2=((C_word*)t0)[9];
f_5970(2,t2,C_SCHEME_FALSE);}}}

/* k5999 in k6053 in walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6001,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1267 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[72]);}
else{
t2=((C_word*)t0)[4];
f_5970(2,t2,C_SCHEME_FALSE);}}

/* k6005 in k5999 in k6053 in walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6007,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1268 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[109]);}
else{
t2=((C_word*)t0)[4];
f_5970(2,t2,C_SCHEME_FALSE);}}

/* k6011 in k6005 in k5999 in k6053 in walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6013,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1271 scan */
t9=((C_word*)t0)[4];
f_6107(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_5970(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5970(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_5970(2,t2,C_SCHEME_FALSE);}}

/* k5968 in walk in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1272 transform */
t2=((C_word*)t0)[11];
f_6526(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1273 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5945(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6107,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6110,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1357 rec */
t18=((C_word*)t12)[1];
f_6110(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k6515 in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6517,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1358 delete */
t3=C_retrieve(lf[200]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[33]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6522 in k6515 in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1358 lset= */
t2=C_retrieve(lf[199]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(68);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6110,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[8]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6159,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1289 get */
t15=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[9],t13,lf[195]);}
else{
t13=(C_word)C_eqp(t11,lf[52]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6177,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1297 decompose-lambda-list */
t16=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[83]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6214,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1306 every */
t20=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t20))(4,t20,t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[187]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6248,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
/* optimizer.scm: 1309 scan-used-variables */
t18=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[196]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6264,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
/* optimizer.scm: 1314 estimate-foreign-result-size */
t19=C_retrieve(lf[197]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[198]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6305,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
/* optimizer.scm: 1322 estimate-foreign-result-size */
t20=C_retrieve(lf[197]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[13]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[8],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6358,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6386,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[8],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_6386(t35,t34);}
else{
t31=t28;
f_6386(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_6358(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_6358(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6447,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1348 every */
t26=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t26))(4,t26,t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[14]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
/* optimizer.scm: 1349 rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[10]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6480,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
/* optimizer.scm: 1351 rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6504,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1353 every */
t23=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t23))(4,t23,t1,t22,t9);}}}}}}}}}}}

/* a6503 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6504,3,t0,t1,t2);}
/* optimizer.scm: 1353 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6110(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6478 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6491,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1352 append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6489 in k6478 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1352 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6110(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a6446 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6447,3,t0,t1,t2);}
/* optimizer.scm: 1348 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6110(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6384 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_6358(t3,C_SCHEME_TRUE);}

/* k6356 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6358,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1341 every */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6362 in k6356 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6363,3,t0,t1,t2);}
/* optimizer.scm: 1341 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6110(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6303 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6305,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6311(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_6311(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_6311(t7,C_SCHEME_TRUE);}}}

/* k6309 in k6303 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6311,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1328 every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6315 in k6309 in k6303 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6316,3,t0,t1,t2);}
/* optimizer.scm: 1328 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6110(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6262 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6264,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6270(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_6270(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_6270(t7,C_SCHEME_TRUE);}}}

/* k6268 in k6262 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6270,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6275,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1320 every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6274 in k6268 in k6262 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6275,3,t0,t1,t2);}
/* optimizer.scm: 1320 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6110(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6246 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6248,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1311 alist-cons */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6242 in k6246 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a6213 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6214,3,t0,t1,t2);}
/* optimizer.scm: 1306 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6110(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a6176 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6177,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6193,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1301 append */
t9=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t2,((C_word*)t0)[2]);}

/* k6191 in a6176 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1301 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6110(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k6157 in rec in scan in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6526(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6526,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6530,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7020,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7022,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1362 ##sys#make-promise */
t11=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1363 debugging */
t9=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,lf[5],lf[194],t3,t7);}}

/* a7021 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7022,2,t0,t1);}
/* optimizer.scm: 1362 unzip1 */
t2=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k7018 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1362 debugging */
t2=C_retrieve(lf[4]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[5],lf[191],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6530,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6540,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1368 get */
t10=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[109]);}

/* k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6540,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t5=(C_word)C_i_length(((C_word*)t0)[11]);
t6=(C_word)C_eqp(t5,C_fix(4));
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
t8=t4;
f_6546(t8,(C_word)C_i_listp(t7));}
else{
t7=t4;
f_6546(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_6546(t5,C_SCHEME_FALSE);}}

/* k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_6546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6546,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1372 caaddr */
t4=*((C_word*)lf[189]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1470 bomb */
t2=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[10],lf[190],((C_word*)t0)[13]);}}

/* k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1373 cdaddr */
t3=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1377 node-class-set! */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[187]);}

/* k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6564,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6737,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6737(3,t9,t2,t5);}

/* rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6737,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[13]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[8],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1391 alist-cons */
t19=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t19))(5,t19,t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6912,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1416 node-class-set! */
t21=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t21))(4,t21,t20,t2,lf[185]);}
else{
/* optimizer.scm: 1419 bomb */
t20=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t1,lf[186]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6959,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1424 alist-cons */
t14=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}}

/* k6957 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6959,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1425 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k6960 in k6957 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1426 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6737(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6910 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1417 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6913 in k6910 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1418 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6790,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_6790(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1394 quit */
t9=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[181],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6836,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_6836(2,t14,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1405 quit */
t14=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t10,lf[183],((C_word*)t0)[4]);}}
else{
/* optimizer.scm: 1414 bomb */
t7=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[8],lf[184],((C_word*)t0)[11]);}}}

/* k6834 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1408 node-class-set! */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[10]);}

/* k6837 in k6834 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
/* optimizer.scm: 1409 take */
t6=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t5,C_fix(1));}

/* k6864 in k6837 in k6834 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1409 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6840 in k6837 in k6834 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[180],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1410 node-subexpressions-set! */
t7=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[2],t6);}

/* k6843 in k6840 in k6837 in k6834 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1413 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6737(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6788 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1397 node-class-set! */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[180]);}

/* k6791 in k6788 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1398 node-parameters-set! */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[3],t3);}

/* k6794 in k6791 in k6788 in k6779 in rec in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1399 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6567,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6660,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6717,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6719,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1447 lset-difference */
t6=C_retrieve(lf[178]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a6718 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6719,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k6715 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6659 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6660,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6670,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_6670(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1437 quit */
t9=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[177],((C_word*)t0)[2]);}}

/* k6668 in a6659 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[175],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t2,t7);
/* optimizer.scm: 1440 node-subexpressions-set! */
t9=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6567,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[34],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6579,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1452 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6577 in k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6618,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1454 fold-right */
t4=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6617 in k6577 in k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6618,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[34],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t5,t13));}

/* k6580 in k6577 in k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1463 copy-node! */
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6583 in k6580 in k6577 in k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6590,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6589 in k6583 in k6580 in k6577 in k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6590,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6597,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6616,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1467 gensym */
t6=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6614 in a6589 in k6583 in k6580 in k6577 in k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1467 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6595 in a6589 in k6583 in k6580 in k6577 in k6565 in k6562 in k6559 in k6553 in k6550 in k6544 in k6538 in k6528 in transform in ##compiler#transform-direct-lambdas! in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6597,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t2,t3));}

/* ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word ab[182],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_3962,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
switch(t6){
case C_fix(1):
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4019,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 854  test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);
case C_fix(2):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4127,a[2]=t4,a[3]=t9,a[4]=t2,a[5]=t1,a[6]=t5,a[7]=t8,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 872  test */
t14=t9;
f_3965(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4231,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 890  test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep(C_retrieve(lf[137]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(2),t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4275,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 898  test */
t13=t9;
f_3965(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4331,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 910  test */
t11=t9;
f_3965(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(6):
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[133]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_eqp(C_fix(1),t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4424,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 926  test */
t15=t9;
f_3965(t15,t14,t4,lf[43]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(7):
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[133]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t12,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4489,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 938  test */
t16=t9;
f_3965(t16,t15,t4,lf[43]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4550,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t2,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 948  test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4577,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 956  test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4721,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 983  test */
t13=t9;
f_3965(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4808,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1000 test */
t13=t9;
f_3965(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4873,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1013 test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4949,a[2]=t4,a[3]=t9,a[4]=t3,a[5]=t8,a[6]=t5,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1026 test */
t11=t9;
f_3965(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_cadr(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5014,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1037 test */
t14=t9;
f_3965(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(1),t10);
if(C_truep(t11)){
t12=C_retrieve(lf[137]);
t13=(C_truep(t12)?t12:(C_word)C_i_cadddr(t7));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5097,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1055 test */
t15=t9;
f_3965(t15,t14,t4,lf[42]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(16):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_i_not(t10);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t11,t10));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5190,a[2]=t4,a[3]=t9,a[4]=t11,a[5]=t12,a[6]=t1,a[7]=t5,a[8]=t8,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1076 test */
t16=t9;
f_3965(t16,t15,t4,lf[42]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5269,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1093 test */
t14=t9;
f_3965(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5337,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1107 test */
t11=t9;
f_3965(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5372,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1117 test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(20):
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
t12=(C_truep(t11)?t11:C_retrieve(lf[137]));
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t10,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5520,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t10,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1146 test */
t16=t9;
f_3965(t16,t15,t4,lf[43]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5593,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1164 test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(22):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_eqp(t11,t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5747,a[2]=t4,a[3]=t9,a[4]=t12,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1198 test */
t15=t9;
f_3965(t15,t14,t4,lf[42]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5810,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=t1,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1219 test */
t11=t9;
f_3965(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1239 bomb */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t1,lf[172]);}}

/* k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5813(2,t3,t1);}
else{
/* optimizer.scm: 1219 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5835,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1225 varnode */
t10=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5847,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1227 ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a5846 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5847,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5855,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5861,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_5861(t9,t4,t3,t5);}

/* loop in a5846 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_5861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5861,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 845  varnode */
t6=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3987,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_3987(t8,(C_word)C_eqp(lf[24],t7));}
else{
t7=t6;
f_3987(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5910,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1237 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k5908 in loop in a5846 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3985 in loop in a5846 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 846  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 847  qnode */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k5879 in loop in a5846 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5885,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1235 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5861(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k5883 in k5879 in loop in a5846 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5853 in a5846 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1228 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5840 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
/* optimizer.scm: 1227 split-at */
t2=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5837 in k5833 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1224 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5826 in k5811 in k5808 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k5745 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5750,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5750(2,t3,t1);}
else{
/* optimizer.scm: 1198 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5748 in k5745 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5769,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5782,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1206 fifth */
t7=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_5769(t9,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5780 in k5748 in k5745 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_5769(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t2,t3));}

/* k5767 in k5748 in k5745 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_5769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5769,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[170],t2));}

/* k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5596(2,t3,t1);}
else{
/* optimizer.scm: 1164 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5594 in k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5602,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1166 fifth */
t4=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5600 in k5594 in k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5602,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5611,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1170 remove */
t6=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a5685 in k5600 in k5594 in k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5686,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[24],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5609 in k5600 in k5594 in k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5627,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1175 qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[167],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1183 fold-inner */
t5=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t1);}}}

/* a5654 in k5609 in k5600 in k5594 in k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5655,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t5,t6));}}

/* k5651 in k5609 in k5600 in k5594 in k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[168],t2));}

/* k5625 in k5609 in k5600 in k5594 in k5591 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5627,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[166],t2));}

/* k5518 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5523(2,t3,t1);}
else{
/* optimizer.scm: 1146 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5521 in k5518 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1152 ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5550 in k5521 in k5518 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5551,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5563,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1154 qnode */
t6=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k5561 in a5550 in k5521 in k5518 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1153 append */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5540 in k5521 in k5518 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1152 split-at */
t3=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k5534 in k5521 in k5518 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[165],t3));}

/* k5370 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5375,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5375(2,t3,t1);}
else{
/* optimizer.scm: 1117 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5373 in k5370 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5375,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5384,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5456,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1121 remove */
t6=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5455 in k5373 in k5370 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5456,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[24],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5382 in k5373 in k5370 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5384,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1126 qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[161],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[142]),lf[147]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1134 fold-inner */
t7=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a5436 in k5382 in k5373 in k5370 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5437,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t4,t5));}

/* k5433 in k5382 in k5373 in k5370 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5435,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[162],t2));}

/* k5398 in k5382 in k5373 in k5370 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5400,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[160],t2));}

/* k5335 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_5340(2,t3,t1);}
else{
/* optimizer.scm: 1107 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5338 in k5335 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5340,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1108 qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5348 in k5338 in k5335 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5350,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[159],t2));}

/* k5267 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5272,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5272(2,t3,t1);}
else{
/* optimizer.scm: 1093 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5270 in k5267 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5272,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[137]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_5292(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_5292(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5290 in k5270 in k5267 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_5292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5292,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[158],t6));}

/* k5188 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5193,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_5193(2,t3,t1);}
else{
/* optimizer.scm: 1076 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5191 in k5188 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5193,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5223,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_5223(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_5223(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_5223(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5221 in k5191 in k5188 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_5223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5223,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[83],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[157],t5));}

/* k5095 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5100(2,t3,t1);}
else{
/* optimizer.scm: 1056 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5098 in k5095 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5100,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[142]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5112,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1059 varnode */
t9=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[142]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[156],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5117 in k5098 in k5095 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1059 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5110 in k5098 in k5095 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5112,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k5012 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5017(2,t3,t1);}
else{
/* optimizer.scm: 1038 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5015 in k5012 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5017,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[142]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[137]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[155],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4947 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4952(2,t3,t1);}
else{
/* optimizer.scm: 1026 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4950 in k4947 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_4967(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_4967(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4965 in k4950 in k4947 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_4967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4967,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4970,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[154],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 1030 cons* */
t5=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4968 in k4965 in k4950 in k4947 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4871 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4876(2,t3,t1);}
else{
/* optimizer.scm: 1013 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4874 in k4871 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[153],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4912,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1020 varnode */
t12=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4917 in k4874 in k4871 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1020 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4910 in k4874 in k4871 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4912,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4806 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4811(2,t3,t1);}
else{
/* optimizer.scm: 1000 test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4809 in k4806 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4811,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_4823(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_4823(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4821 in k4809 in k4806 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_4823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4823,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4829,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1005 varnode */
t7=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4834 in k4821 in k4809 in k4806 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1005 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4827 in k4821 in k4809 in k4806 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4719 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 987  varnode */
t7=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4741 in k4719 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 990  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4749 in k4741 in k4719 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 992  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}
else{
t4=t2;
f_4755(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k4753 in k4749 in k4741 in k4719 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t2));}

/* k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 958  qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[137]))){
t4=(C_word)C_eqp(C_retrieve(lf[142]),lf[151]);
t5=t3;
f_4599(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4599(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_4599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4599,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4602(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_4602(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[142]),lf[150]);
t6=t2;
f_4602(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k4600 in k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_4602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4602,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4661,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4660 in k4600 in k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4661,3,t0,t1,t2);}
/* optimizer.scm: 962  gensym */
t3=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k4603 in k4600 in k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4608,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[46]),t1);}

/* k4606 in k4603 in k4600 in k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4613,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4639,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 974  fold-boolean */
t8=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t1);}

/* a4638 in k4606 in k4603 in k4600 in k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4639,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[2],t4));}

/* k4635 in k4606 in k4603 in k4600 in k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[148],t2);
/* optimizer.scm: 964  fold-right */
t4=C_retrieve(lf[119]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4612 in k4606 in k4603 in k4600 in k4597 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4613,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t5,t6));}

/* k4591 in k4575 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[146],t2));}

/* k4548 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4553(2,t3,t1);}
else{
/* optimizer.scm: 949  test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4551 in k4548 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4487 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4492(2,t3,t1);}
else{
/* optimizer.scm: 938  test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4490 in k4487 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4492,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 943  qnode */
t7=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4514 in k4490 in k4487 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 942  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4503 in k4490 in k4487 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[145],t3));}

/* k4422 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[144],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4329 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4334(2,t3,t1);}
else{
/* optimizer.scm: 911  test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4332 in k4329 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[142])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 919  qnode */
t12=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4374 in k4332 in k4329 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[143],t4));}

/* k4273 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 900  varnode */
t6=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4286 in k4273 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 903  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4294 in k4286 in k4273 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t3));}

/* k4229 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4234(2,t3,t1);}
else{
/* optimizer.scm: 890  test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4232 in k4229 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 891  varnode */
t4=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4242 in k4232 in k4229 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[141],t2));}

/* k4125 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4130(2,t3,t1);}
else{
/* optimizer.scm: 872  test */
t3=((C_word*)t0)[3];
f_3965(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4128 in k4125 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4130,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4187,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
/* optimizer.scm: 882  get */
t13=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t13))(5,t13,t10,((C_word*)t0)[2],t12,lf[140]);}
else{
t10=t7;
f_4158(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_4158(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4185 in k4128 in k4125 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4158(t2,(C_word)C_eqp(lf[139],t1));}

/* k4156 in k4128 in k4125 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_4158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4158,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_4155(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_4155(t5,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4));}}

/* k4153 in k4128 in k4125 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_4155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4155,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[138],t2));}

/* k4017 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[8],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4082,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 861  qnode */
t15=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_4022(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_4022(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_4022(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_4022(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4080 in k4017 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_4022(t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[136],t2));}

/* k4020 in k4017 in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_4022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4022,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[133]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[135],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* test in ##compiler#simplify-named-call in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3965(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3965,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 843  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#rewrite in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3942r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3942r(t0,t1,t2,t3);}}

static void C_ccall f_3942r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3946,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 839  ##sys#hash-table-ref */
t5=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[130]),t2);}

/* k3944 in ##compiler#rewrite in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 840  append */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}

/* k3954 in k3944 in ##compiler#rewrite in k3938 in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 840  ##sys#hash-table-set! */
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[130]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3614,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3618,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 751  map */
t8=*((C_word*)lf[128]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,*((C_word*)lf[129]+1),t2,t3);}

/* k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 762  for-each */
t5=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3926 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3927,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3932,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 763  scan-used-variables */
t6=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}

/* k3934 in a3926 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 763  alist-cons */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3930 in a3926 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a3868 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3869,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3879,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 772  filter */
t5=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a3900 in a3868 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3901,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3914,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 773  find-path */
t5=((C_word*)t0)[2];
f_3620(t5,t4,((C_word*)t0)[3],t2);}}

/* k3912 in a3900 in a3868 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 773  find-path */
t2=((C_word*)t0)[5];
f_3620(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3877 in a3868 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3883,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 775  gensym */
t4=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3893 in k3877 in a3868 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 775  alist-cons */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3881 in k3877 in a3868 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 776  append */
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k3885 in k3881 in k3877 in a3868 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3671,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3810,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 785  append-map */
t7=C_retrieve(lf[125]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* a3852 in a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3853,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3859,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 786  filter */
t4=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a3858 in a3852 in a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3859,3,t0,t1,t2);}
/* optimizer.scm: 786  find-path */
t3=((C_word*)t0)[3];
f_3620(t3,t1,((C_word*)t0)[2],t2);}

/* k3815 in a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 791  filter-map */
t5=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a3826 in k3815 in a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3827,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3840,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 792  lset<= */
t6=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,*((C_word*)lf[33]+1),t5,((C_word*)t0)[2]);}}

/* k3838 in a3826 in k3815 in a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k3823 in k3815 in a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 789  alist-cons */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3819 in k3815 in a3809 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 798  topological-sort */
t3=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[33]+1));}

/* k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3674,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 803  fold */
t6=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a3693 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3694,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3707,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_3707(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_3707(t9,C_SCHEME_FALSE);}}

/* k3705 in a3693 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3707,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3730,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 817  fold-right */
t5=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a3749 in k3705 in a3693 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3750,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3782,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 820  gensym */
t5=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3780 in a3749 in k3705 in a3693 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[14],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t2,t8));}

/* k3746 in k3705 in a3693 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 812  fold-right */
t2=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3729 in k3705 in a3693 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3730,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t4,t6));}

/* k3675 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3686,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 829  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[118],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 831  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k3684 in k3675 in k3672 in k3669 in k3666 in k3663 in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 830  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3620(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3620,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3626,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3626(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3626(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3626,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3650,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 759  any */
t9=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,t8,t5);}}}

/* a3649 in find in find-path in k3616 in ##compiler#reorganize-recursive-bindings in k3610 in k3607 in k3604 in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3650,3,t0,t1,t2);}
/* optimizer.scm: 759  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3626(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3599(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3599r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3599r(t0,t1,t2,t3);}}

static void C_ccall f_3599r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 530  ##sys#hash-table-set! */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[20]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3138,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3141,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3152,a[2]=t3,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 443  debugging */
t11=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,lf[18],lf[114]);}

/* k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3387,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 446  test */
t4=((C_word*)t0)[3];
f_3145(t4,t3,lf[113],lf[43]);}

/* k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3594,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 482  test */
t4=((C_word*)t0)[3];
f_3145(t4,t3,lf[113],lf[109]);}
else{
t2=((C_word*)t0)[2];
f_3155(2,t2,C_SCHEME_UNDEFINED);}}

/* k3592 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3392,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3405,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3583,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 452  test */
t10=((C_word*)t0)[2];
f_3145(t10,t9,t7,lf[73]);}

/* k3581 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3405(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 452  test */
t2=((C_word*)t0)[3];
f_3145(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 453  test */
t3=((C_word*)t0)[3];
f_3145(t3,t2,((C_word*)t0)[2],lf[72]);}

/* k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=t2;
f_3414(t8,(C_word)C_eqp(lf[52],t7));}
else{
t7=t2;
f_3414(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3414(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3414(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3414(t3,C_SCHEME_FALSE);}}

/* k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3414,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_3429(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_3429(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3429(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3429,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3435,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 464  test */
t4=((C_word*)t0)[2];
f_3145(t4,t3,t2,lf[72]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3433 in k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_3441(t6,(C_word)C_eqp(lf[9],t5));}
else{
t5=t2;
f_3441(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3441(t3,C_SCHEME_FALSE);}}

/* k3439 in k3433 in k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3441,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[8],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_3450(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_3450(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3448 in k3439 in k3433 in k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3450,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 476  node-parameters-set! */
t5=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[112]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3455 in k3448 in k3439 in k3433 in k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 477  node-subexpressions-set! */
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3458 in k3455 in k3448 in k3439 in k3433 in k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 480  reverse */
t6=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k3476 in k3458 in k3455 in k3448 in k3439 in k3433 in k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3478,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 478  node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3461 in k3458 in k3455 in k3448 in k3439 in k3433 in k3427 in k3412 in k3406 in k3403 in a3391 in k3385 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 481  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3141(((C_word*)t0)[2]));}

/* k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[110]));}

/* a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3169,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3176,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 487  test */
t4=((C_word*)t0)[3];
f_3145(t4,t3,t2,lf[43]);}

/* k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3176,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3381,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 520  test */
t4=((C_word*)t0)[4];
f_3145(t4,t3,((C_word*)t0)[5],lf[109]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3379 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3181,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3194,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 493  test */
t9=((C_word*)t0)[3];
f_3145(t9,t8,t7,lf[72]);}

/* k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3197,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 494  test */
t4=((C_word*)t0)[4];
f_3145(t4,t3,((C_word*)t0)[2],lf[73]);}

/* k3368 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3197(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 494  test */
t2=((C_word*)t0)[3];
f_3145(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3203,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_eqp(lf[52],t3);
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3342,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* optimizer.scm: 499  any */
t10=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t7=t2;
f_3203(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3203(t5,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3203(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3203(t3,C_SCHEME_FALSE);}}

/* a3343 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3344,3,t0,t1,t2);}
/* optimizer.scm: 499  expression-has-side-effects? */
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k3340 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3203(t2,(C_word)C_i_not(t1));}

/* k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3203,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t7=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_slot(t5,C_fix(1));
t9=t6;
f_3215(t9,(C_word)C_eqp(lf[9],t8));}
else{
t8=t6;
f_3215(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3215(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3213 in k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3215,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3221,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 507  test */
t4=((C_word*)t0)[2];
f_3145(t4,t3,t2,lf[72]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3219 in k3213 in k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3221,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_length(t1);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(lf[8],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(2));
t10=(C_word)C_i_car(t9);
t11=t4;
f_3230(t11,(C_word)C_eqp(((C_word*)t0)[2],t10));}
else{
t9=t4;
f_3230(t9,C_SCHEME_FALSE);}}
else{
t7=t4;
f_3230(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_3230(t5,C_SCHEME_FALSE);}}

/* k3228 in k3219 in k3213 in k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3230,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 516  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[108],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3234 in k3228 in k3219 in k3213 in k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 517  node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[107]);}

/* k3237 in k3234 in k3228 in k3219 in k3213 in k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3257,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 518  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k3255 in k3237 in k3234 in k3228 in k3219 in k3213 in k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 518  node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3240 in k3237 in k3234 in k3228 in k3219 in k3213 in k3201 in k3195 in k3192 in a3180 in k3174 in a3168 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 519  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3141(((C_word*)t0)[2]));}

/* k3156 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 523  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[104],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3161(2,t4,C_SCHEME_UNDEFINED);}}

/* k3159 in k3156 in k3153 in k3150 in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3145(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3145,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 441  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k1662 in k1454 in k1451 in k1448 */
static C_word C_fcall f_3141(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[70],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1667,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1676,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1686,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1696,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1700,a[2]=t3,a[3]=t21,a[4]=t19,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1792,a[2]=t26,a[3]=t16,a[4]=t17,a[5]=t24,a[6]=t18,a[7]=t19,a[8]=t7,a[9]=t21,a[10]=t15,tmp=(C_word)a,a+=11,tmp));
t30=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2008,a[2]=t11,a[3]=t3,a[4]=t28,a[5]=t24,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t19,tmp=(C_word)a,a+=10,tmp));
t31=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3042,a[2]=t24,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 409  perform-pre-optimization! */
t33=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t33))(4,t33,t32,t2,t3);}

/* k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3042,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 410  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 412  debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[102]);}}

/* k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=C_set_block_item(lf[21],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 414  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1792(3,t4,t3,((C_word*)t0)[2]);}

/* k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 415  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[101],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_3055(2,t3,C_SCHEME_UNDEFINED);}}

/* k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[21])))){
/* optimizer.scm: 416  debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[5],lf[100]);}
else{
t4=t3;
f_3091(2,t4,C_SCHEME_FALSE);}}

/* k3089 in k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3096,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[21]));}
else{
t2=((C_word*)t0)[2];
f_3058(2,t2,C_SCHEME_UNDEFINED);}}

/* a3095 in k3089 in k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3100,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 419  print* */
t5=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_make_character(9),t4);}

/* k3098 in a3095 in k3089 in k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 421  print */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 422  newline */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[2]);}}

/* k3056 in k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 424  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[96],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3061(2,t4,C_SCHEME_UNDEFINED);}}

/* k3059 in k3056 in k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 425  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[95],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3064(2,t4,C_SCHEME_UNDEFINED);}}

/* k3062 in k3059 in k3056 in k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 426  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[94],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3067(2,t4,C_SCHEME_UNDEFINED);}}

/* k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3046 in k3040 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 427  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_3023(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3023,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3027,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k3025 in walk-generic in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3033,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 405  every */
t3=C_retrieve(lf[40]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k3031 in k3025 in walk-generic in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2008,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[8]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_2033(t14,t1,t10);}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2108,a[2]=t11,a[3]=((C_word*)t0)[8],a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 240  test */
t13=((C_word*)t0)[8];
f_1670(t13,t12,t11,lf[48]);}
else{
t11=(C_word)C_eqp(t8,lf[52]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2165,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t6,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 250  test */
t15=((C_word*)t0)[8];
f_1670(t15,t13,t14,lf[61]);}
else{
t12=(C_word)C_eqp(t8,lf[13]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t4);
t14=(C_word)C_slot(t13,C_fix(1));
t15=(C_word)C_eqp(t14,lf[8]);
if(C_truep(t15)){
t16=(C_word)C_slot(t13,C_fix(2));
t17=(C_word)C_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=t17,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2883,a[2]=t17,a[3]=((C_word*)t0)[8],a[4]=t18,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 288  test */
t20=((C_word*)t0)[8];
f_1670(t20,t19,t17,lf[73]);}
else{
t16=(C_word)C_eqp(t14,lf[52]);
if(C_truep(t16)){
if(C_truep((C_word)C_i_car(t6))){
/* optimizer.scm: 382  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_3023(t17,t1,t2,t8,t6,t4);}
else{
t17=(C_word)C_i_cdr(t6);
t18=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2908,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t20=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
/* optimizer.scm: 384  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_3023(t17,t1,t2,t8,t6,t4);}}}
else{
t13=(C_word)C_eqp(t8,lf[14]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t6);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t14,a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 388  test */
t16=((C_word*)t0)[8];
f_1670(t16,t15,t14,lf[50]);}
else{
/* optimizer.scm: 401  walk-generic */
t14=((C_word*)((C_word*)t0)[4])[1];
f_3023(t14,t1,t2,t8,t6,t4);}}}}}}

/* k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_2936(2,t3,t1);}
else{
/* optimizer.scm: 388  test */
t3=((C_word*)t0)[2];
f_1670(t3,t2,((C_word*)t0)[7],lf[48]);}}

/* k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
if(C_truep(t1)){
t2=f_1696(((C_word*)t0)[9]);
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 391  test */
t4=((C_word*)t0)[2];
f_1670(t4,t3,((C_word*)t0)[7],lf[93]);}}

/* k3013 in k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2977(t4,t2);}
else{
t4=C_retrieve(lf[91]);
if(C_truep(t4)){
t5=t3;
f_2977(t5,t4);}
else{
if(C_truep(C_retrieve(lf[92]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[92]));
t6=t3;
f_2977(t6,(C_word)C_i_not(t5));}
else{
t5=t3;
f_2977(t5,C_SCHEME_FALSE);}}}}

/* k2975 in k3013 in k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2977,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 394  test */
t3=((C_word*)t0)[3];
f_1670(t3,t2,((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[6];
f_2948(t2,C_SCHEME_FALSE);}}

/* k2996 in k2975 in k3013 in k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2948(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 395  expression-has-side-effects? */
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* k2988 in k2996 in k2975 in k3013 in k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2948(t2,(C_word)C_i_not(t1));}

/* k2946 in k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2948,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1696(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 397  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[90],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 399  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1792(3,t4,t2,t3);}}

/* k2965 in k2946 in k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[14],((C_word*)t0)[2],t2));}

/* k2952 in k2946 in k2934 in k2931 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k2906 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k2881 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2341(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 288  test */
t2=((C_word*)t0)[3];
f_1670(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t1,tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 290  test */
t4=((C_word*)t0)[4];
f_1670(t4,t3,((C_word*)t0)[10],lf[50]);}

/* k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t3,a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 293  check-signature */
t5=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[11],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[65])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[8],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2510,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 301  test */
t10=((C_word*)t0)[4];
f_1670(t10,t9,t7,lf[73]);}
else{
t8=t3;
f_2392(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2392(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2392(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t4=t2;
f_2524(t4,(C_word)C_eqp(lf[52],t3));}
else{
t3=t2;
f_2524(t3,C_SCHEME_FALSE);}}}}

/* k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2524,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 316  decompose-lambda-list */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
/* optimizer.scm: 379  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_3023(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2535,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[17],a[4]=t6,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 320  test */
t8=((C_word*)t0)[3];
f_1670(t8,t7,t5,lf[89]);}

/* k2832 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 321  test */
t3=((C_word*)t0)[2];
f_1670(t3,t2,((C_word*)t0)[5],lf[88]);}
else{
t2=((C_word*)t0)[4];
f_2545(t2,C_SCHEME_FALSE);}}

/* k2838 in k2832 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[85])))){
t2=((C_word*)t0)[3];
f_2545(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[86]));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_2545(t3,t2);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t4=C_retrieve(lf[87]);
t5=((C_word*)t0)[3];
f_2545(t5,(C_word)C_fixnum_lessp(t3,t4));}}}
else{
t2=((C_word*)t0)[3];
f_2545(t2,C_SCHEME_FALSE);}}

/* k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[14]);
/* optimizer.scm: 325  debugging */
t4=C_retrieve(lf[4]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,lf[75],lf[76],((C_word*)t0)[15],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 330  test */
t3=((C_word*)t0)[4];
f_1670(t3,t2,((C_word*)t0)[13],lf[61]);}}

/* k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 332  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_3023(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_2596(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[4],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2824,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 354  test */
t4=((C_word*)t0)[6];
f_1670(t4,t3,((C_word*)t0)[2],lf[57]);}}

/* k2822 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_2741(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2741(t2,C_SCHEME_FALSE);}}

/* k2739 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2741,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[13]);
t3=(C_word)C_i_length(((C_word*)t0)[12]);
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* optimizer.scm: 358  walk-generic */
t4=((C_word*)((C_word*)t0)[11])[1];
f_3023(t4,((C_word*)t0)[10],t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 360  debugging */
t5=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[5],lf[84],((C_word*)t0)[3],t2);}}
else{
/* optimizer.scm: 378  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_3023(t2,((C_word*)t0)[10],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k2754 in k2739 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 361  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2766 in k2754 in k2739 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2767,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2771,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 371  qnode */
t7=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_i_length(t3);
t8=(C_word)C_fixnum_times(C_fix(3),t7);
t9=(C_word)C_a_i_list(&a,2,lf[82],t8);
t10=t6;
f_2794(2,t10,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t9,t3));}}

/* k2792 in a2766 in k2754 in k2739 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 367  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2784 in a2766 in k2754 in k2739 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2769 in a2766 in k2754 in k2739 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2760 in k2754 in k2739 in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
/* optimizer.scm: 361  split-at */
t2=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2596,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_1696(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 339  append-reverse */
t11=C_retrieve(lf[77]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 340  test */
t10=((C_word*)t0)[2];
f_1670(t10,t8,t9,lf[53]);}}

/* k2627 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2629,2,t0,t1);}
if(C_truep(t1)){
t2=f_1696(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 342  debugging */
t5=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,lf[5],lf[80],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 350  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_2596(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k2633 in k2627 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 343  expression-has-side-effects? */
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k2639 in k2633 in k2627 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2641,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 346  gensym */
t3=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[79]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 349  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2596(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k2676 in k2639 in k2633 in k2627 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 347  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1792(3,t5,t3,t4);}

/* k2652 in k2676 in k2639 in k2633 in k2627 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 348  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2596(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k2656 in k2652 in k2676 in k2639 in k2633 in k2627 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t2));}

/* k2621 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2610 in loop in k2580 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k2546 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 326  check-signature */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2549 in k2546 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 327  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[74],((C_word*)t0)[2]);}

/* k2552 in k2549 in k2546 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=f_1696(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 329  inline-lambda-bindings */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_TRUE);}

/* k2562 in k2552 in k2549 in k2546 in k2543 in a2534 in k2522 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 329  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1792(3,t2,((C_word*)t0)[2],t1);}

/* k2508 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2413(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 301  test */
t2=((C_word*)t0)[3];
f_1670(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_caddr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2431,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 304  test */
t6=((C_word*)t0)[2];
f_1670(t6,t4,t5,lf[53]);}
else{
t4=((C_word*)t0)[7];
f_2392(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_2392(t2,C_SCHEME_FALSE);}}

/* k2429 in k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_2434(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 305  test */
t5=((C_word*)t0)[2];
f_1670(t5,t3,t4,lf[72]);}}

/* k2486 in k2429 in k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2434(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 306  test */
t4=((C_word*)t0)[2];
f_1670(t4,t2,t3,lf[71]);}}

/* k2478 in k2486 in k2429 in k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2434(t2,(C_word)C_i_not(t1));}

/* k2432 in k2429 in k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2434,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 307  any */
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_2392(t2,C_SCHEME_FALSE);}}

/* a2458 in k2432 in k2429 in k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2455 in k2432 in k2429 in k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2457,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2392(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 308  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[68],lf[69],((C_word*)t0)[2]);}}

/* k2441 in k2455 in k2432 in k2429 in k2411 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2392(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[67],t3));}

/* k2390 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 312  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3023(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2357 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 294  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[63],((C_word*)t0)[2]);}

/* k2360 in k2357 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=f_1696(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 296  inline-lambda-bindings */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2370 in k2360 in k2357 in k2348 in k2339 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 296  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1792(3,t2,((C_word*)t0)[2],t1);}

/* k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 251  decompose-lambda-list */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 266  test */
t4=((C_word*)t0)[11];
f_1670(t4,t2,t3,lf[57]);}}

/* k2255 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 267  decompose-lambda-list */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 279  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3023(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a2261 in k2255 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2262,5,t0,t1,t2,t3,t4);}
t5=f_1696(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2269,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 271  debugging */
t7=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[5],lf[60],t4);}

/* k2267 in a2261 in k2255 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 276  build-lambda-list */
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2296 in k2267 in a2261 in k2255 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2282,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 278  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1792(3,t6,t4,t5);}

/* k2280 in k2296 in k2267 in a2261 in k2255 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[52],((C_word*)t0)[2],t2));}

/* a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2170,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2176,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2187 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2188,4,t0,t1,t2,t3);}
t4=f_1696(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 256  debugging */
t6=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[5],lf[58],t2);}

/* k2193 in a2187 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 260  test */
t7=((C_word*)t0)[2];
f_1670(t7,t5,t6,lf[57]);}
else{
t6=t5;
f_2231(2,t6,C_SCHEME_FALSE);}}

/* k2229 in k2193 in a2187 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 261  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[56],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 263  build-lambda-list */
t2=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2232 in k2229 in k2193 in a2187 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 262  build-lambda-list */
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k2222 in k2193 in a2187 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2208,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 265  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1792(3,t6,t4,t5);}

/* k2206 in k2222 in k2193 in a2187 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[52],((C_word*)t0)[2],t2));}

/* a2175 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 254  partition */
t3=C_retrieve(lf[54]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2181 in a2175 in a2169 in k2163 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2182,3,t0,t1,t2);}
/* optimizer.scm: 254  test */
t3=((C_word*)t0)[2];
f_1670(t3,t1,t2,lf[53]);}

/* k2106 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_2111(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 241  test */
t4=((C_word*)t0)[3];
f_1670(t4,t3,((C_word*)t0)[2],lf[51]);}}

/* k2132 in k2106 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2111(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 242  test */
t3=((C_word*)t0)[3];
f_1670(t3,t2,((C_word*)t0)[2],lf[50]);}}

/* k2141 in k2132 in k2106 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 242  test */
t3=((C_word*)t0)[3];
f_1670(t3,t2,((C_word*)t0)[2],lf[49]);}
else{
t2=((C_word*)t0)[4];
f_2111(t2,C_SCHEME_FALSE);}}

/* k2148 in k2141 in k2132 in k2106 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2111(t2,(C_word)C_i_not(t1));}

/* k2109 in k2106 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2111,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1696(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 245  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1792(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k2126 in k2109 in k2106 in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2033,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 226  test */
t4=((C_word*)t0)[4];
f_1670(t4,t3,t2,lf[48]);}

/* k2035 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
if(C_truep(t1)){
/* replace119 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2033(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 227  test */
t3=((C_word*)t0)[5];
f_1670(t3,t2,((C_word*)t0)[4],lf[47]);}}

/* k2047 in k2035 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
if(C_truep(t1)){
t2=f_1696(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 229  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[45],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2072,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_2072(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_1696(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_2072(t8,t7);}}}

/* k2070 in k2047 in k2035 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_2072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 236  varnode */
t2=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2053 in k2047 in k2035 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 230  test */
t3=((C_word*)t0)[3];
f_1670(t3,t2,((C_word*)t0)[2],lf[44]);}

/* k2064 in k2053 in k2047 in k2035 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
/* optimizer.scm: 230  qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1792,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[31])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[10])[1];
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 179  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2008(t5,t4,t2);}}

/* k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[9]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1824,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t2);
/* optimizer.scm: 184  constant-node? */
t8=((C_word*)t0)[5];
f_1676(3,t8,t6,t7);}
else{
t6=(C_word)C_eqp(t3,lf[13]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=t4,a[9]=t12,tmp=(C_word)a,a+=10,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1973,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t13,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 195  test */
t15=((C_word*)t0)[2];
f_1670(t15,t14,t12,lf[43]);}
else{
t10=t4;
f_1815(2,t10,t1);}}
else{
t7=t4;
f_1815(2,t7,t1);}}}

/* k1971 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1976(2,t3,t1);}
else{
/* optimizer.scm: 196  test */
t3=((C_word*)t0)[3];
f_1670(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k1974 in k1971 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 197  test */
t3=((C_word*)t0)[3];
f_1670(t3,t2,((C_word*)t0)[2],lf[41]);}
else{
t2=((C_word*)t0)[5];
f_1876(2,t2,C_SCHEME_FALSE);}}

/* k1980 in k1974 in k1971 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 198  every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_1876(2,t2,C_SCHEME_FALSE);}}

/* k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
f_1815(2,t2,((C_word*)t0)[7]);}}

/* a1957 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1958,3,t0,t1,t2);}
t3=f_1686(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[24],t3));}

/* k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1956,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1887,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1887,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1893,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1910,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1909 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1941 in a1909 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1942r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1942r(t0,t1,t2);}}

static void C_ccall f_1942r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g9799 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1947 in a1941 in a1909 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1915 in a1909 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 206  eval */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1918 in a1915 in a1909 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1923,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 207  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[37],((C_word*)t0)[2]);}

/* k1921 in k1918 in a1915 in a1909 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=f_1696(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 212  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1938 in k1921 in k1918 in a1915 in a1909 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[35],t2));}

/* a1892 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1893,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* g9799 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1898 in a1892 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1903(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_1903(t4,t3);}}

/* k1901 in a1898 in a1892 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_1903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1903,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 204  lset-adjoin */
t3=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[33]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}

/* k1905 in k1901 in a1898 in a1892 in a1886 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k1883 in k1954 in k1874 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1822 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=f_1696(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=f_1686(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[6]):(C_word)C_i_caddr(((C_word*)t0)[6]));
/* optimizer.scm: 187  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_1792(3,t8,((C_word*)t0)[3],t7);}
else{
t2=((C_word*)t0)[3];
f_1815(2,t2,((C_word*)t0)[2]);}}

/* k1813 in k1804 in walk in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 177  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1700(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_1700(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1700,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
/* optimizer.scm: 158  ##sys#hash-table-ref */
t6=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_retrieve(lf[20]),t5);}

/* k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1707,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 159  any */
t4=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}
else{
t3=t2;
f_1707(2,t3,C_SCHEME_FALSE);}}

/* a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1715,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1725,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 161  match-node */
t6=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1723 in a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1773 in k1723 in a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1774,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1770 in k1723 in a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1729 in k1723 in a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1737,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 164  caar */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1735 in k1729 in k1723 in a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_1743(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1764,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 168  alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k1762 in k1735 in k1729 in k1723 in a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1743(t3,t2);}

/* k1741 in k1735 in k1729 in k1723 in a1714 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_1743(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1696(((C_word*)t0)[5]);
/* optimizer.scm: 170  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1700(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1705 in k1702 in simplify in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static C_word C_fcall f_1696(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* node-value in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static C_word C_fcall f_1686(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(2));
return((C_word)C_i_car(t2));}

/* constant-node? in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1676,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[24],t3));}

/* test in ##compiler#perform-high-level-optimizations in k1662 in k1454 in k1451 in k1448 */
static void C_fcall f_1670(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1670,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 152  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1461,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1482,a[2]=t2,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 84   debugging */
t9=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[18],lf[19]);}

/* k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 85   call-with-current-continuation */
t4=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1494,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1509,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 120  scan */
t9=((C_word*)t6)[1];
f_1509(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_fcall f_1509(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1509,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[8]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1534,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_1534(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_1534(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[9]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_1561(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[15]);
t14=t12;
f_1561(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[16])));}}}

/* k1559 in scan in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 102  scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1509(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 106  scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1509(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[11]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[12]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[13]);
if(C_truep(t5)){
/* optimizer.scm: 111  return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[14]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))?C_SCHEME_UNDEFINED:f_1464(C_a_i(&a,3),((C_word*)t0)[3],t7));
t9=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 116  scan */
t10=((C_word*)((C_word*)t0)[7])[1];
f_1509(t10,((C_word*)t0)[9],t9,((C_word*)t0)[6]);}
else{
/* optimizer.scm: 118  scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1497(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k1578 in k1559 in scan in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1591,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 107  append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1589 in k1578 in k1559 in scan in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 107  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1509(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1562 in k1559 in scan in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 103  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1532 in scan in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_fcall f_1534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1534,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_fcall f_1497(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1497,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1503,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1502 in scan-each in a1493 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1503,3,t0,t1,t2);}
/* optimizer.scm: 89   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1509(t3,t1,t2,((C_word*)t0)[2]);}

/* k1483 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 121  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[6],((C_word*)((C_word*)t0)[2])[1]);}

/* k1486 in k1483 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 122  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],C_retrieve(lf[2]));}

/* k1490 in k1486 in k1483 in k1480 in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[2]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* mark in ##compiler#scan-toplevel-assignments in k1454 in k1451 in k1448 */
static C_word C_fcall f_1464(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_memq(t1,((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[613] = {
{"topleveloptimizer.scm",(void*)C_optimizer_toplevel},
{"f_1450optimizer.scm",(void*)f_1450},
{"f_1453optimizer.scm",(void*)f_1453},
{"f_1456optimizer.scm",(void*)f_1456},
{"f_1664optimizer.scm",(void*)f_1664},
{"f_9508optimizer.scm",(void*)f_9508},
{"f_9516optimizer.scm",(void*)f_9516},
{"f_9521optimizer.scm",(void*)f_9521},
{"f_9566optimizer.scm",(void*)f_9566},
{"f_9570optimizer.scm",(void*)f_9570},
{"f_9531optimizer.scm",(void*)f_9531},
{"f_9555optimizer.scm",(void*)f_9555},
{"f_9540optimizer.scm",(void*)f_9540},
{"f_3606optimizer.scm",(void*)f_3606},
{"f_8879optimizer.scm",(void*)f_8879},
{"f_8913optimizer.scm",(void*)f_8913},
{"f_8955optimizer.scm",(void*)f_8955},
{"f_8965optimizer.scm",(void*)f_8965},
{"f_9029optimizer.scm",(void*)f_9029},
{"f_9058optimizer.scm",(void*)f_9058},
{"f_9181optimizer.scm",(void*)f_9181},
{"f_9074optimizer.scm",(void*)f_9074},
{"f_9121optimizer.scm",(void*)f_9121},
{"f_9111optimizer.scm",(void*)f_9111},
{"f_9119optimizer.scm",(void*)f_9119},
{"f_9223optimizer.scm",(void*)f_9223},
{"f_9236optimizer.scm",(void*)f_9236},
{"f_9271optimizer.scm",(void*)f_9271},
{"f_9255optimizer.scm",(void*)f_9255},
{"f_9259optimizer.scm",(void*)f_9259},
{"f_9248optimizer.scm",(void*)f_9248},
{"f_9345optimizer.scm",(void*)f_9345},
{"f_9358optimizer.scm",(void*)f_9358},
{"f_9364optimizer.scm",(void*)f_9364},
{"f_9410optimizer.scm",(void*)f_9410},
{"f_9402optimizer.scm",(void*)f_9402},
{"f_9386optimizer.scm",(void*)f_9386},
{"f_9390optimizer.scm",(void*)f_9390},
{"f_9394optimizer.scm",(void*)f_9394},
{"f_3609optimizer.scm",(void*)f_3609},
{"f_8697optimizer.scm",(void*)f_8697},
{"f_8719optimizer.scm",(void*)f_8719},
{"f_8774optimizer.scm",(void*)f_8774},
{"f_8744optimizer.scm",(void*)f_8744},
{"f_8766optimizer.scm",(void*)f_8766},
{"f_8770optimizer.scm",(void*)f_8770},
{"f_8762optimizer.scm",(void*)f_8762},
{"f_8742optimizer.scm",(void*)f_8742},
{"f_8808optimizer.scm",(void*)f_8808},
{"f_8822optimizer.scm",(void*)f_8822},
{"f_3612optimizer.scm",(void*)f_3612},
{"f_3940optimizer.scm",(void*)f_3940},
{"f_7037optimizer.scm",(void*)f_7037},
{"f_8584optimizer.scm",(void*)f_8584},
{"f_8587optimizer.scm",(void*)f_8587},
{"f_8590optimizer.scm",(void*)f_8590},
{"f_8593optimizer.scm",(void*)f_8593},
{"f_8596optimizer.scm",(void*)f_8596},
{"f_8599optimizer.scm",(void*)f_8599},
{"f_8676optimizer.scm",(void*)f_8676},
{"f_8602optimizer.scm",(void*)f_8602},
{"f_8605optimizer.scm",(void*)f_8605},
{"f_8608optimizer.scm",(void*)f_8608},
{"f_8670optimizer.scm",(void*)f_8670},
{"f_8611optimizer.scm",(void*)f_8611},
{"f_8614optimizer.scm",(void*)f_8614},
{"f_8667optimizer.scm",(void*)f_8667},
{"f_7646optimizer.scm",(void*)f_7646},
{"f_7664optimizer.scm",(void*)f_7664},
{"f_7670optimizer.scm",(void*)f_7670},
{"f_7650optimizer.scm",(void*)f_7650},
{"f_8617optimizer.scm",(void*)f_8617},
{"f_8659optimizer.scm",(void*)f_8659},
{"f_8657optimizer.scm",(void*)f_8657},
{"f_8620optimizer.scm",(void*)f_8620},
{"f_8623optimizer.scm",(void*)f_8623},
{"f_8626optimizer.scm",(void*)f_8626},
{"f_8650optimizer.scm",(void*)f_8650},
{"f_8629optimizer.scm",(void*)f_8629},
{"f_8632optimizer.scm",(void*)f_8632},
{"f_8635optimizer.scm",(void*)f_8635},
{"f_8638optimizer.scm",(void*)f_8638},
{"f_8641optimizer.scm",(void*)f_8641},
{"f_8644optimizer.scm",(void*)f_8644},
{"f_8437optimizer.scm",(void*)f_8437},
{"f_8443optimizer.scm",(void*)f_8443},
{"f_8555optimizer.scm",(void*)f_8555},
{"f_8564optimizer.scm",(void*)f_8564},
{"f_8567optimizer.scm",(void*)f_8567},
{"f_8462optimizer.scm",(void*)f_8462},
{"f_8467optimizer.scm",(void*)f_8467},
{"f_8508optimizer.scm",(void*)f_8508},
{"f_8505optimizer.scm",(void*)f_8505},
{"f_8490optimizer.scm",(void*)f_8490},
{"f_8501optimizer.scm",(void*)f_8501},
{"f_8497optimizer.scm",(void*)f_8497},
{"f_8350optimizer.scm",(void*)f_8350},
{"f_8356optimizer.scm",(void*)f_8356},
{"f_8412optimizer.scm",(void*)f_8412},
{"f_8408optimizer.scm",(void*)f_8408},
{"f_8378optimizer.scm",(void*)f_8378},
{"f_8100optimizer.scm",(void*)f_8100},
{"f_8114optimizer.scm",(void*)f_8114},
{"f_8121optimizer.scm",(void*)f_8121},
{"f_8134optimizer.scm",(void*)f_8134},
{"f_8141optimizer.scm",(void*)f_8141},
{"f_8144optimizer.scm",(void*)f_8144},
{"f_8240optimizer.scm",(void*)f_8240},
{"f_8326optimizer.scm",(void*)f_8326},
{"f_8345optimizer.scm",(void*)f_8345},
{"f_8341optimizer.scm",(void*)f_8341},
{"f_8307optimizer.scm",(void*)f_8307},
{"f_8296optimizer.scm",(void*)f_8296},
{"f_8283optimizer.scm",(void*)f_8283},
{"f_8266optimizer.scm",(void*)f_8266},
{"f_8259optimizer.scm",(void*)f_8259},
{"f_8225optimizer.scm",(void*)f_8225},
{"f_8147optimizer.scm",(void*)f_8147},
{"f_8196optimizer.scm",(void*)f_8196},
{"f_8184optimizer.scm",(void*)f_8184},
{"f_8180optimizer.scm",(void*)f_8180},
{"f_8112optimizer.scm",(void*)f_8112},
{"f_7899optimizer.scm",(void*)f_7899},
{"f_8086optimizer.scm",(void*)f_8086},
{"f_7964optimizer.scm",(void*)f_7964},
{"f_8041optimizer.scm",(void*)f_8041},
{"f_8046optimizer.scm",(void*)f_8046},
{"f_8084optimizer.scm",(void*)f_8084},
{"f_7908optimizer.scm",(void*)f_7908},
{"f_7946optimizer.scm",(void*)f_7946},
{"f_7951optimizer.scm",(void*)f_7951},
{"f_7928optimizer.scm",(void*)f_7928},
{"f_7906optimizer.scm",(void*)f_7906},
{"f_8076optimizer.scm",(void*)f_8076},
{"f_8062optimizer.scm",(void*)f_8062},
{"f_8060optimizer.scm",(void*)f_8060},
{"f_7966optimizer.scm",(void*)f_7966},
{"f_8034optimizer.scm",(void*)f_8034},
{"f_8032optimizer.scm",(void*)f_8032},
{"f_8020optimizer.scm",(void*)f_8020},
{"f_7986optimizer.scm",(void*)f_7986},
{"f_8010optimizer.scm",(void*)f_8010},
{"f_8008optimizer.scm",(void*)f_8008},
{"f_8004optimizer.scm",(void*)f_8004},
{"f_7996optimizer.scm",(void*)f_7996},
{"f_7680optimizer.scm",(void*)f_7680},
{"f_7686optimizer.scm",(void*)f_7686},
{"f_7705optimizer.scm",(void*)f_7705},
{"f_7872optimizer.scm",(void*)f_7872},
{"f_7802optimizer.scm",(void*)f_7802},
{"f_7818optimizer.scm",(void*)f_7818},
{"f_7848optimizer.scm",(void*)f_7848},
{"f_7852optimizer.scm",(void*)f_7852},
{"f_7838optimizer.scm",(void*)f_7838},
{"f_7791optimizer.scm",(void*)f_7791},
{"f_7796optimizer.scm",(void*)f_7796},
{"f_7767optimizer.scm",(void*)f_7767},
{"f_7779optimizer.scm",(void*)f_7779},
{"f_7716optimizer.scm",(void*)f_7716},
{"f_7737optimizer.scm",(void*)f_7737},
{"f_7734optimizer.scm",(void*)f_7734},
{"f_7684optimizer.scm",(void*)f_7684},
{"f_7436optimizer.scm",(void*)f_7436},
{"f_7442optimizer.scm",(void*)f_7442},
{"f_7461optimizer.scm",(void*)f_7461},
{"f_7563optimizer.scm",(void*)f_7563},
{"f_7554optimizer.scm",(void*)f_7554},
{"f_7520optimizer.scm",(void*)f_7520},
{"f_7529optimizer.scm",(void*)f_7529},
{"f_7541optimizer.scm",(void*)f_7541},
{"f_7472optimizer.scm",(void*)f_7472},
{"f_7493optimizer.scm",(void*)f_7493},
{"f_7490optimizer.scm",(void*)f_7490},
{"f_7440optimizer.scm",(void*)f_7440},
{"f_7337optimizer.scm",(void*)f_7337},
{"f_7343optimizer.scm",(void*)f_7343},
{"f_7387optimizer.scm",(void*)f_7387},
{"f_7392optimizer.scm",(void*)f_7392},
{"f_7399optimizer.scm",(void*)f_7399},
{"f_7426optimizer.scm",(void*)f_7426},
{"f_7422optimizer.scm",(void*)f_7422},
{"f_7414optimizer.scm",(void*)f_7414},
{"f_7412optimizer.scm",(void*)f_7412},
{"f_7377optimizer.scm",(void*)f_7377},
{"f_7355optimizer.scm",(void*)f_7355},
{"f_7362optimizer.scm",(void*)f_7362},
{"f_7140optimizer.scm",(void*)f_7140},
{"f_7294optimizer.scm",(void*)f_7294},
{"f_7319optimizer.scm",(void*)f_7319},
{"f_7309optimizer.scm",(void*)f_7309},
{"f_7313optimizer.scm",(void*)f_7313},
{"f_7292optimizer.scm",(void*)f_7292},
{"f_7143optimizer.scm",(void*)f_7143},
{"f_7282optimizer.scm",(void*)f_7282},
{"f_7265optimizer.scm",(void*)f_7265},
{"f_7277optimizer.scm",(void*)f_7277},
{"f_7211optimizer.scm",(void*)f_7211},
{"f_7235optimizer.scm",(void*)f_7235},
{"f_7229optimizer.scm",(void*)f_7229},
{"f_7193optimizer.scm",(void*)f_7193},
{"f_7168optimizer.scm",(void*)f_7168},
{"f_7171optimizer.scm",(void*)f_7171},
{"f_7176optimizer.scm",(void*)f_7176},
{"f_7040optimizer.scm",(void*)f_7040},
{"f_7046optimizer.scm",(void*)f_7046},
{"f_7077optimizer.scm",(void*)f_7077},
{"f_7081optimizer.scm",(void*)f_7081},
{"f_7085optimizer.scm",(void*)f_7085},
{"f_7044optimizer.scm",(void*)f_7044},
{"f_5942optimizer.scm",(void*)f_5942},
{"f_7032optimizer.scm",(void*)f_7032},
{"f_7035optimizer.scm",(void*)f_7035},
{"f_5945optimizer.scm",(void*)f_5945},
{"f_6101optimizer.scm",(void*)f_6101},
{"f_6081optimizer.scm",(void*)f_6081},
{"f_6055optimizer.scm",(void*)f_6055},
{"f_6001optimizer.scm",(void*)f_6001},
{"f_6007optimizer.scm",(void*)f_6007},
{"f_6013optimizer.scm",(void*)f_6013},
{"f_5970optimizer.scm",(void*)f_5970},
{"f_6107optimizer.scm",(void*)f_6107},
{"f_6517optimizer.scm",(void*)f_6517},
{"f_6524optimizer.scm",(void*)f_6524},
{"f_6110optimizer.scm",(void*)f_6110},
{"f_6504optimizer.scm",(void*)f_6504},
{"f_6480optimizer.scm",(void*)f_6480},
{"f_6491optimizer.scm",(void*)f_6491},
{"f_6447optimizer.scm",(void*)f_6447},
{"f_6386optimizer.scm",(void*)f_6386},
{"f_6358optimizer.scm",(void*)f_6358},
{"f_6363optimizer.scm",(void*)f_6363},
{"f_6305optimizer.scm",(void*)f_6305},
{"f_6311optimizer.scm",(void*)f_6311},
{"f_6316optimizer.scm",(void*)f_6316},
{"f_6264optimizer.scm",(void*)f_6264},
{"f_6270optimizer.scm",(void*)f_6270},
{"f_6275optimizer.scm",(void*)f_6275},
{"f_6248optimizer.scm",(void*)f_6248},
{"f_6244optimizer.scm",(void*)f_6244},
{"f_6214optimizer.scm",(void*)f_6214},
{"f_6177optimizer.scm",(void*)f_6177},
{"f_6193optimizer.scm",(void*)f_6193},
{"f_6159optimizer.scm",(void*)f_6159},
{"f_6526optimizer.scm",(void*)f_6526},
{"f_7022optimizer.scm",(void*)f_7022},
{"f_7020optimizer.scm",(void*)f_7020},
{"f_6530optimizer.scm",(void*)f_6530},
{"f_6540optimizer.scm",(void*)f_6540},
{"f_6546optimizer.scm",(void*)f_6546},
{"f_6552optimizer.scm",(void*)f_6552},
{"f_6555optimizer.scm",(void*)f_6555},
{"f_6561optimizer.scm",(void*)f_6561},
{"f_6737optimizer.scm",(void*)f_6737},
{"f_6959optimizer.scm",(void*)f_6959},
{"f_6962optimizer.scm",(void*)f_6962},
{"f_6912optimizer.scm",(void*)f_6912},
{"f_6915optimizer.scm",(void*)f_6915},
{"f_6781optimizer.scm",(void*)f_6781},
{"f_6836optimizer.scm",(void*)f_6836},
{"f_6839optimizer.scm",(void*)f_6839},
{"f_6866optimizer.scm",(void*)f_6866},
{"f_6842optimizer.scm",(void*)f_6842},
{"f_6845optimizer.scm",(void*)f_6845},
{"f_6790optimizer.scm",(void*)f_6790},
{"f_6793optimizer.scm",(void*)f_6793},
{"f_6796optimizer.scm",(void*)f_6796},
{"f_6564optimizer.scm",(void*)f_6564},
{"f_6719optimizer.scm",(void*)f_6719},
{"f_6717optimizer.scm",(void*)f_6717},
{"f_6660optimizer.scm",(void*)f_6660},
{"f_6670optimizer.scm",(void*)f_6670},
{"f_6567optimizer.scm",(void*)f_6567},
{"f_6579optimizer.scm",(void*)f_6579},
{"f_6618optimizer.scm",(void*)f_6618},
{"f_6582optimizer.scm",(void*)f_6582},
{"f_6585optimizer.scm",(void*)f_6585},
{"f_6590optimizer.scm",(void*)f_6590},
{"f_6616optimizer.scm",(void*)f_6616},
{"f_6597optimizer.scm",(void*)f_6597},
{"f_3962optimizer.scm",(void*)f_3962},
{"f_5810optimizer.scm",(void*)f_5810},
{"f_5813optimizer.scm",(void*)f_5813},
{"f_5835optimizer.scm",(void*)f_5835},
{"f_5847optimizer.scm",(void*)f_5847},
{"f_5861optimizer.scm",(void*)f_5861},
{"f_5910optimizer.scm",(void*)f_5910},
{"f_3987optimizer.scm",(void*)f_3987},
{"f_5881optimizer.scm",(void*)f_5881},
{"f_5885optimizer.scm",(void*)f_5885},
{"f_5855optimizer.scm",(void*)f_5855},
{"f_5841optimizer.scm",(void*)f_5841},
{"f_5839optimizer.scm",(void*)f_5839},
{"f_5828optimizer.scm",(void*)f_5828},
{"f_5747optimizer.scm",(void*)f_5747},
{"f_5750optimizer.scm",(void*)f_5750},
{"f_5782optimizer.scm",(void*)f_5782},
{"f_5769optimizer.scm",(void*)f_5769},
{"f_5593optimizer.scm",(void*)f_5593},
{"f_5596optimizer.scm",(void*)f_5596},
{"f_5602optimizer.scm",(void*)f_5602},
{"f_5686optimizer.scm",(void*)f_5686},
{"f_5611optimizer.scm",(void*)f_5611},
{"f_5655optimizer.scm",(void*)f_5655},
{"f_5653optimizer.scm",(void*)f_5653},
{"f_5627optimizer.scm",(void*)f_5627},
{"f_5520optimizer.scm",(void*)f_5520},
{"f_5523optimizer.scm",(void*)f_5523},
{"f_5551optimizer.scm",(void*)f_5551},
{"f_5563optimizer.scm",(void*)f_5563},
{"f_5541optimizer.scm",(void*)f_5541},
{"f_5536optimizer.scm",(void*)f_5536},
{"f_5372optimizer.scm",(void*)f_5372},
{"f_5375optimizer.scm",(void*)f_5375},
{"f_5456optimizer.scm",(void*)f_5456},
{"f_5384optimizer.scm",(void*)f_5384},
{"f_5437optimizer.scm",(void*)f_5437},
{"f_5435optimizer.scm",(void*)f_5435},
{"f_5400optimizer.scm",(void*)f_5400},
{"f_5337optimizer.scm",(void*)f_5337},
{"f_5340optimizer.scm",(void*)f_5340},
{"f_5350optimizer.scm",(void*)f_5350},
{"f_5269optimizer.scm",(void*)f_5269},
{"f_5272optimizer.scm",(void*)f_5272},
{"f_5292optimizer.scm",(void*)f_5292},
{"f_5190optimizer.scm",(void*)f_5190},
{"f_5193optimizer.scm",(void*)f_5193},
{"f_5223optimizer.scm",(void*)f_5223},
{"f_5097optimizer.scm",(void*)f_5097},
{"f_5100optimizer.scm",(void*)f_5100},
{"f_5119optimizer.scm",(void*)f_5119},
{"f_5112optimizer.scm",(void*)f_5112},
{"f_5014optimizer.scm",(void*)f_5014},
{"f_5017optimizer.scm",(void*)f_5017},
{"f_4949optimizer.scm",(void*)f_4949},
{"f_4952optimizer.scm",(void*)f_4952},
{"f_4967optimizer.scm",(void*)f_4967},
{"f_4970optimizer.scm",(void*)f_4970},
{"f_4873optimizer.scm",(void*)f_4873},
{"f_4876optimizer.scm",(void*)f_4876},
{"f_4919optimizer.scm",(void*)f_4919},
{"f_4912optimizer.scm",(void*)f_4912},
{"f_4808optimizer.scm",(void*)f_4808},
{"f_4811optimizer.scm",(void*)f_4811},
{"f_4823optimizer.scm",(void*)f_4823},
{"f_4836optimizer.scm",(void*)f_4836},
{"f_4829optimizer.scm",(void*)f_4829},
{"f_4721optimizer.scm",(void*)f_4721},
{"f_4743optimizer.scm",(void*)f_4743},
{"f_4751optimizer.scm",(void*)f_4751},
{"f_4755optimizer.scm",(void*)f_4755},
{"f_4577optimizer.scm",(void*)f_4577},
{"f_4599optimizer.scm",(void*)f_4599},
{"f_4602optimizer.scm",(void*)f_4602},
{"f_4661optimizer.scm",(void*)f_4661},
{"f_4605optimizer.scm",(void*)f_4605},
{"f_4608optimizer.scm",(void*)f_4608},
{"f_4639optimizer.scm",(void*)f_4639},
{"f_4637optimizer.scm",(void*)f_4637},
{"f_4613optimizer.scm",(void*)f_4613},
{"f_4593optimizer.scm",(void*)f_4593},
{"f_4550optimizer.scm",(void*)f_4550},
{"f_4553optimizer.scm",(void*)f_4553},
{"f_4489optimizer.scm",(void*)f_4489},
{"f_4492optimizer.scm",(void*)f_4492},
{"f_4516optimizer.scm",(void*)f_4516},
{"f_4505optimizer.scm",(void*)f_4505},
{"f_4424optimizer.scm",(void*)f_4424},
{"f_4331optimizer.scm",(void*)f_4331},
{"f_4334optimizer.scm",(void*)f_4334},
{"f_4376optimizer.scm",(void*)f_4376},
{"f_4275optimizer.scm",(void*)f_4275},
{"f_4288optimizer.scm",(void*)f_4288},
{"f_4296optimizer.scm",(void*)f_4296},
{"f_4231optimizer.scm",(void*)f_4231},
{"f_4234optimizer.scm",(void*)f_4234},
{"f_4244optimizer.scm",(void*)f_4244},
{"f_4127optimizer.scm",(void*)f_4127},
{"f_4130optimizer.scm",(void*)f_4130},
{"f_4187optimizer.scm",(void*)f_4187},
{"f_4158optimizer.scm",(void*)f_4158},
{"f_4155optimizer.scm",(void*)f_4155},
{"f_4019optimizer.scm",(void*)f_4019},
{"f_4082optimizer.scm",(void*)f_4082},
{"f_4022optimizer.scm",(void*)f_4022},
{"f_3965optimizer.scm",(void*)f_3965},
{"f_3942optimizer.scm",(void*)f_3942},
{"f_3946optimizer.scm",(void*)f_3946},
{"f_3956optimizer.scm",(void*)f_3956},
{"f_3614optimizer.scm",(void*)f_3614},
{"f_3618optimizer.scm",(void*)f_3618},
{"f_3927optimizer.scm",(void*)f_3927},
{"f_3936optimizer.scm",(void*)f_3936},
{"f_3932optimizer.scm",(void*)f_3932},
{"f_3665optimizer.scm",(void*)f_3665},
{"f_3869optimizer.scm",(void*)f_3869},
{"f_3901optimizer.scm",(void*)f_3901},
{"f_3914optimizer.scm",(void*)f_3914},
{"f_3879optimizer.scm",(void*)f_3879},
{"f_3895optimizer.scm",(void*)f_3895},
{"f_3883optimizer.scm",(void*)f_3883},
{"f_3887optimizer.scm",(void*)f_3887},
{"f_3668optimizer.scm",(void*)f_3668},
{"f_3810optimizer.scm",(void*)f_3810},
{"f_3853optimizer.scm",(void*)f_3853},
{"f_3859optimizer.scm",(void*)f_3859},
{"f_3817optimizer.scm",(void*)f_3817},
{"f_3827optimizer.scm",(void*)f_3827},
{"f_3840optimizer.scm",(void*)f_3840},
{"f_3825optimizer.scm",(void*)f_3825},
{"f_3821optimizer.scm",(void*)f_3821},
{"f_3671optimizer.scm",(void*)f_3671},
{"f_3674optimizer.scm",(void*)f_3674},
{"f_3694optimizer.scm",(void*)f_3694},
{"f_3707optimizer.scm",(void*)f_3707},
{"f_3750optimizer.scm",(void*)f_3750},
{"f_3782optimizer.scm",(void*)f_3782},
{"f_3748optimizer.scm",(void*)f_3748},
{"f_3730optimizer.scm",(void*)f_3730},
{"f_3677optimizer.scm",(void*)f_3677},
{"f_3686optimizer.scm",(void*)f_3686},
{"f_3620optimizer.scm",(void*)f_3620},
{"f_3626optimizer.scm",(void*)f_3626},
{"f_3650optimizer.scm",(void*)f_3650},
{"f_3599optimizer.scm",(void*)f_3599},
{"f_3138optimizer.scm",(void*)f_3138},
{"f_3152optimizer.scm",(void*)f_3152},
{"f_3387optimizer.scm",(void*)f_3387},
{"f_3594optimizer.scm",(void*)f_3594},
{"f_3392optimizer.scm",(void*)f_3392},
{"f_3583optimizer.scm",(void*)f_3583},
{"f_3405optimizer.scm",(void*)f_3405},
{"f_3408optimizer.scm",(void*)f_3408},
{"f_3414optimizer.scm",(void*)f_3414},
{"f_3429optimizer.scm",(void*)f_3429},
{"f_3435optimizer.scm",(void*)f_3435},
{"f_3441optimizer.scm",(void*)f_3441},
{"f_3450optimizer.scm",(void*)f_3450},
{"f_3457optimizer.scm",(void*)f_3457},
{"f_3460optimizer.scm",(void*)f_3460},
{"f_3478optimizer.scm",(void*)f_3478},
{"f_3463optimizer.scm",(void*)f_3463},
{"f_3155optimizer.scm",(void*)f_3155},
{"f_3169optimizer.scm",(void*)f_3169},
{"f_3176optimizer.scm",(void*)f_3176},
{"f_3381optimizer.scm",(void*)f_3381},
{"f_3181optimizer.scm",(void*)f_3181},
{"f_3194optimizer.scm",(void*)f_3194},
{"f_3370optimizer.scm",(void*)f_3370},
{"f_3197optimizer.scm",(void*)f_3197},
{"f_3344optimizer.scm",(void*)f_3344},
{"f_3342optimizer.scm",(void*)f_3342},
{"f_3203optimizer.scm",(void*)f_3203},
{"f_3215optimizer.scm",(void*)f_3215},
{"f_3221optimizer.scm",(void*)f_3221},
{"f_3230optimizer.scm",(void*)f_3230},
{"f_3236optimizer.scm",(void*)f_3236},
{"f_3239optimizer.scm",(void*)f_3239},
{"f_3257optimizer.scm",(void*)f_3257},
{"f_3242optimizer.scm",(void*)f_3242},
{"f_3158optimizer.scm",(void*)f_3158},
{"f_3161optimizer.scm",(void*)f_3161},
{"f_3145optimizer.scm",(void*)f_3145},
{"f_3141optimizer.scm",(void*)f_3141},
{"f_1667optimizer.scm",(void*)f_1667},
{"f_3042optimizer.scm",(void*)f_3042},
{"f_3048optimizer.scm",(void*)f_3048},
{"f_3052optimizer.scm",(void*)f_3052},
{"f_3055optimizer.scm",(void*)f_3055},
{"f_3091optimizer.scm",(void*)f_3091},
{"f_3096optimizer.scm",(void*)f_3096},
{"f_3100optimizer.scm",(void*)f_3100},
{"f_3058optimizer.scm",(void*)f_3058},
{"f_3061optimizer.scm",(void*)f_3061},
{"f_3064optimizer.scm",(void*)f_3064},
{"f_3067optimizer.scm",(void*)f_3067},
{"f_3023optimizer.scm",(void*)f_3023},
{"f_3027optimizer.scm",(void*)f_3027},
{"f_3033optimizer.scm",(void*)f_3033},
{"f_2008optimizer.scm",(void*)f_2008},
{"f_2933optimizer.scm",(void*)f_2933},
{"f_2936optimizer.scm",(void*)f_2936},
{"f_3015optimizer.scm",(void*)f_3015},
{"f_2977optimizer.scm",(void*)f_2977},
{"f_2998optimizer.scm",(void*)f_2998},
{"f_2990optimizer.scm",(void*)f_2990},
{"f_2948optimizer.scm",(void*)f_2948},
{"f_2967optimizer.scm",(void*)f_2967},
{"f_2954optimizer.scm",(void*)f_2954},
{"f_2908optimizer.scm",(void*)f_2908},
{"f_2883optimizer.scm",(void*)f_2883},
{"f_2341optimizer.scm",(void*)f_2341},
{"f_2350optimizer.scm",(void*)f_2350},
{"f_2524optimizer.scm",(void*)f_2524},
{"f_2535optimizer.scm",(void*)f_2535},
{"f_2834optimizer.scm",(void*)f_2834},
{"f_2840optimizer.scm",(void*)f_2840},
{"f_2545optimizer.scm",(void*)f_2545},
{"f_2582optimizer.scm",(void*)f_2582},
{"f_2824optimizer.scm",(void*)f_2824},
{"f_2741optimizer.scm",(void*)f_2741},
{"f_2756optimizer.scm",(void*)f_2756},
{"f_2767optimizer.scm",(void*)f_2767},
{"f_2794optimizer.scm",(void*)f_2794},
{"f_2786optimizer.scm",(void*)f_2786},
{"f_2771optimizer.scm",(void*)f_2771},
{"f_2761optimizer.scm",(void*)f_2761},
{"f_2596optimizer.scm",(void*)f_2596},
{"f_2629optimizer.scm",(void*)f_2629},
{"f_2635optimizer.scm",(void*)f_2635},
{"f_2641optimizer.scm",(void*)f_2641},
{"f_2678optimizer.scm",(void*)f_2678},
{"f_2654optimizer.scm",(void*)f_2654},
{"f_2658optimizer.scm",(void*)f_2658},
{"f_2623optimizer.scm",(void*)f_2623},
{"f_2612optimizer.scm",(void*)f_2612},
{"f_2548optimizer.scm",(void*)f_2548},
{"f_2551optimizer.scm",(void*)f_2551},
{"f_2554optimizer.scm",(void*)f_2554},
{"f_2564optimizer.scm",(void*)f_2564},
{"f_2510optimizer.scm",(void*)f_2510},
{"f_2413optimizer.scm",(void*)f_2413},
{"f_2431optimizer.scm",(void*)f_2431},
{"f_2488optimizer.scm",(void*)f_2488},
{"f_2480optimizer.scm",(void*)f_2480},
{"f_2434optimizer.scm",(void*)f_2434},
{"f_2459optimizer.scm",(void*)f_2459},
{"f_2457optimizer.scm",(void*)f_2457},
{"f_2443optimizer.scm",(void*)f_2443},
{"f_2392optimizer.scm",(void*)f_2392},
{"f_2359optimizer.scm",(void*)f_2359},
{"f_2362optimizer.scm",(void*)f_2362},
{"f_2372optimizer.scm",(void*)f_2372},
{"f_2165optimizer.scm",(void*)f_2165},
{"f_2257optimizer.scm",(void*)f_2257},
{"f_2262optimizer.scm",(void*)f_2262},
{"f_2269optimizer.scm",(void*)f_2269},
{"f_2298optimizer.scm",(void*)f_2298},
{"f_2282optimizer.scm",(void*)f_2282},
{"f_2170optimizer.scm",(void*)f_2170},
{"f_2188optimizer.scm",(void*)f_2188},
{"f_2195optimizer.scm",(void*)f_2195},
{"f_2231optimizer.scm",(void*)f_2231},
{"f_2234optimizer.scm",(void*)f_2234},
{"f_2224optimizer.scm",(void*)f_2224},
{"f_2208optimizer.scm",(void*)f_2208},
{"f_2176optimizer.scm",(void*)f_2176},
{"f_2182optimizer.scm",(void*)f_2182},
{"f_2108optimizer.scm",(void*)f_2108},
{"f_2134optimizer.scm",(void*)f_2134},
{"f_2143optimizer.scm",(void*)f_2143},
{"f_2150optimizer.scm",(void*)f_2150},
{"f_2111optimizer.scm",(void*)f_2111},
{"f_2128optimizer.scm",(void*)f_2128},
{"f_2033optimizer.scm",(void*)f_2033},
{"f_2037optimizer.scm",(void*)f_2037},
{"f_2049optimizer.scm",(void*)f_2049},
{"f_2072optimizer.scm",(void*)f_2072},
{"f_2055optimizer.scm",(void*)f_2055},
{"f_2066optimizer.scm",(void*)f_2066},
{"f_1792optimizer.scm",(void*)f_1792},
{"f_1806optimizer.scm",(void*)f_1806},
{"f_1973optimizer.scm",(void*)f_1973},
{"f_1976optimizer.scm",(void*)f_1976},
{"f_1982optimizer.scm",(void*)f_1982},
{"f_1876optimizer.scm",(void*)f_1876},
{"f_1958optimizer.scm",(void*)f_1958},
{"f_1956optimizer.scm",(void*)f_1956},
{"f_1887optimizer.scm",(void*)f_1887},
{"f_1910optimizer.scm",(void*)f_1910},
{"f_1942optimizer.scm",(void*)f_1942},
{"f_1948optimizer.scm",(void*)f_1948},
{"f_1916optimizer.scm",(void*)f_1916},
{"f_1920optimizer.scm",(void*)f_1920},
{"f_1923optimizer.scm",(void*)f_1923},
{"f_1940optimizer.scm",(void*)f_1940},
{"f_1893optimizer.scm",(void*)f_1893},
{"f_1899optimizer.scm",(void*)f_1899},
{"f_1903optimizer.scm",(void*)f_1903},
{"f_1907optimizer.scm",(void*)f_1907},
{"f_1885optimizer.scm",(void*)f_1885},
{"f_1824optimizer.scm",(void*)f_1824},
{"f_1815optimizer.scm",(void*)f_1815},
{"f_1700optimizer.scm",(void*)f_1700},
{"f_1704optimizer.scm",(void*)f_1704},
{"f_1715optimizer.scm",(void*)f_1715},
{"f_1725optimizer.scm",(void*)f_1725},
{"f_1774optimizer.scm",(void*)f_1774},
{"f_1772optimizer.scm",(void*)f_1772},
{"f_1731optimizer.scm",(void*)f_1731},
{"f_1737optimizer.scm",(void*)f_1737},
{"f_1764optimizer.scm",(void*)f_1764},
{"f_1743optimizer.scm",(void*)f_1743},
{"f_1707optimizer.scm",(void*)f_1707},
{"f_1696optimizer.scm",(void*)f_1696},
{"f_1686optimizer.scm",(void*)f_1686},
{"f_1676optimizer.scm",(void*)f_1676},
{"f_1670optimizer.scm",(void*)f_1670},
{"f_1461optimizer.scm",(void*)f_1461},
{"f_1482optimizer.scm",(void*)f_1482},
{"f_1494optimizer.scm",(void*)f_1494},
{"f_1509optimizer.scm",(void*)f_1509},
{"f_1561optimizer.scm",(void*)f_1561},
{"f_1580optimizer.scm",(void*)f_1580},
{"f_1591optimizer.scm",(void*)f_1591},
{"f_1564optimizer.scm",(void*)f_1564},
{"f_1534optimizer.scm",(void*)f_1534},
{"f_1497optimizer.scm",(void*)f_1497},
{"f_1503optimizer.scm",(void*)f_1503},
{"f_1485optimizer.scm",(void*)f_1485},
{"f_1488optimizer.scm",(void*)f_1488},
{"f_1492optimizer.scm",(void*)f_1492},
{"f_1464optimizer.scm",(void*)f_1464},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
