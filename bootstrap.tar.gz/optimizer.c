/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:21
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: optimizer.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[258];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13078)
static void C_ccall f_13078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_13086)
static void C_ccall f_13086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13091)
static void C_fcall f_13091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13136)
static void C_ccall f_13136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13140)
static void C_ccall f_13140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13101)
static void C_ccall f_13101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13125)
static void C_ccall f_13125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13110)
static void C_fcall f_13110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12029)
static void C_ccall f_12029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_12075)
static void C_ccall f_12075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12063)
static void C_ccall f_12063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12058)
static void C_ccall f_12058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12050)
static void C_ccall f_12050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12177)
static void C_ccall f_12177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12187)
static void C_fcall f_12187(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12486)
static void C_ccall f_12486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12191)
static void C_ccall f_12191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12481)
static void C_ccall f_12481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12194)
static void C_ccall f_12194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12476)
static void C_ccall f_12476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12197)
static void C_ccall f_12197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12467)
static void C_ccall f_12467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12215)
static void C_ccall f_12215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12462)
static void C_ccall f_12462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12218)
static void C_ccall f_12218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12457)
static void C_ccall f_12457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12221)
static void C_ccall f_12221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12251)
static void C_ccall f_12251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12280)
static void C_fcall f_12280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12440)
static void C_ccall f_12440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12284)
static void C_ccall f_12284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12435)
static void C_ccall f_12435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12287)
static void C_ccall f_12287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12430)
static void C_ccall f_12430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12290)
static void C_ccall f_12290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12421)
static void C_ccall f_12421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12413)
static void C_ccall f_12413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12408)
static void C_ccall f_12408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12400)
static void C_ccall f_12400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12395)
static void C_ccall f_12395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12296)
static void C_fcall f_12296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12349)
static void C_ccall f_12349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12339)
static void C_ccall f_12339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12347)
static void C_ccall f_12347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12324)
static void C_ccall f_12324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12319)
static void C_ccall f_12319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12536)
static void C_ccall f_12536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_12549)
static void C_ccall f_12549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12591)
static void C_ccall f_12591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12575)
static void C_ccall f_12575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12579)
static void C_ccall f_12579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12566)
static void C_ccall f_12566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12567)
static void C_ccall f_12567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12757)
static void C_ccall f_12757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_12770)
static void C_ccall f_12770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12776)
static void C_ccall f_12776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12828)
static void C_ccall f_12828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12820)
static void C_ccall f_12820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12804)
static void C_ccall f_12804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12808)
static void C_ccall f_12808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12812)
static void C_ccall f_12812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12796)
static void C_ccall f_12796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11670)
static void C_ccall f_11670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_11692)
static void C_ccall f_11692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11772)
static void C_ccall f_11772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11730)
static void C_ccall f_11730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11764)
static void C_ccall f_11764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11768)
static void C_ccall f_11768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11756)
static void C_ccall f_11756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11747)
static void C_ccall f_11747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11751)
static void C_ccall f_11751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11739)
static void C_ccall f_11739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11728)
static void C_ccall f_11728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11720)
static void C_ccall f_11720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11715)
static void C_ccall f_11715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11707)
static void C_ccall f_11707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11866)
static void C_ccall f_11866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_11886)
static void C_ccall f_11886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11895)
static void C_ccall f_11895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11890)
static void C_ccall f_11890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11878)
static void C_ccall f_11878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9805)
static void C_ccall f_9805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11549)
static void C_ccall f_11549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11552)
static void C_ccall f_11552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11558)
static void C_ccall f_11558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11561)
static void C_ccall f_11561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11564)
static void C_ccall f_11564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11641)
static void C_ccall f_11641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11567)
static void C_ccall f_11567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11570)
static void C_ccall f_11570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11573)
static void C_ccall f_11573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11635)
static void C_ccall f_11635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11576)
static void C_ccall f_11576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11579)
static void C_ccall f_11579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11632)
static void C_ccall f_11632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10460)
static void C_fcall f_10460(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10478)
static void C_ccall f_10478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10484)
static void C_ccall f_10484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10464)
static void C_ccall f_10464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11582)
static void C_ccall f_11582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11624)
static void C_ccall f_11624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11622)
static void C_ccall f_11622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11585)
static void C_ccall f_11585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11588)
static void C_ccall f_11588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11591)
static void C_ccall f_11591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11615)
static void C_ccall f_11615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11594)
static void C_ccall f_11594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11597)
static void C_ccall f_11597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11600)
static void C_ccall f_11600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11603)
static void C_ccall f_11603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11606)
static void C_ccall f_11606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11609)
static void C_ccall f_11609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11377)
static void C_fcall f_11377(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11383)
static void C_ccall f_11383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11542)
static void C_ccall f_11542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11387)
static void C_ccall f_11387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11537)
static void C_ccall f_11537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11390)
static void C_ccall f_11390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11532)
static void C_ccall f_11532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11393)
static void C_ccall f_11393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11524)
static void C_ccall f_11524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11523)
static void C_ccall f_11523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11500)
static void C_ccall f_11500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11509)
static void C_ccall f_11509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11512)
static void C_ccall f_11512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11487)
static void C_ccall f_11487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11486)
static void C_ccall f_11486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11402)
static void C_ccall f_11402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11407)
static void C_fcall f_11407(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11448)
static void C_fcall f_11448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11445)
static void C_ccall f_11445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11430)
static void C_ccall f_11430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11441)
static void C_ccall f_11441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11437)
static void C_ccall f_11437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11260)
static void C_fcall f_11260(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11266)
static void C_ccall f_11266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11371)
static void C_ccall f_11371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11270)
static void C_ccall f_11270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11366)
static void C_ccall f_11366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11273)
static void C_ccall f_11273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11361)
static void C_ccall f_11361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11276)
static void C_ccall f_11276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11353)
static void C_ccall f_11353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11352)
static void C_ccall f_11352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11344)
static void C_ccall f_11344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11343)
static void C_ccall f_11343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11327)
static void C_ccall f_11327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11323)
static void C_ccall f_11323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11288)
static void C_ccall f_11288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11296)
static void C_ccall f_11296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11295)
static void C_ccall f_11295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10954)
static void C_fcall f_10954(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11111)
static void C_ccall f_11111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11110)
static void C_ccall f_11110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10968)
static void C_ccall f_10968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10975)
static void C_ccall f_10975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11098)
static void C_ccall f_11098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11097)
static void C_ccall f_11097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10988)
static void C_ccall f_10988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10995)
static void C_ccall f_10995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11135)
static void C_ccall f_11135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11254)
static void C_ccall f_11254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11249)
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11244)
static void C_ccall f_11244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11145)
static void C_ccall f_11145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11221)
static void C_ccall f_11221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11240)
static void C_ccall f_11240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11236)
static void C_ccall f_11236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11202)
static void C_ccall f_11202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11191)
static void C_ccall f_11191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11178)
static void C_ccall f_11178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11154)
static void C_ccall f_11154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11120)
static void C_ccall f_11120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11001)
static void C_ccall f_11001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11076)
static void C_ccall f_11076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11064)
static void C_ccall f_11064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11060)
static void C_ccall f_11060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11052)
static void C_ccall f_11052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11046)
static void C_ccall f_11046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11047)
static void C_ccall f_11047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11038)
static void C_ccall f_11038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11030)
static void C_ccall f_11030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11021)
static void C_ccall f_11021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10966)
static void C_ccall f_10966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10738)
static void C_fcall f_10738(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10940)
static void C_ccall f_10940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10818)
static void C_ccall f_10818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10900)
static void C_ccall f_10900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10938)
static void C_ccall f_10938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10747)
static void C_ccall f_10747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10811)
static void C_ccall f_10811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10751)
static void C_ccall f_10751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10806)
static void C_ccall f_10806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10754)
static void C_ccall f_10754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10801)
static void C_ccall f_10801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10757)
static void C_ccall f_10757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10785)
static void C_ccall f_10785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10790)
static void C_ccall f_10790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_ccall f_10767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10745)
static void C_ccall f_10745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10930)
static void C_ccall f_10930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10916)
static void C_ccall f_10916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10914)
static void C_ccall f_10914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10820)
static void C_ccall f_10820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10888)
static void C_ccall f_10888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10886)
static void C_ccall f_10886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10874)
static void C_ccall f_10874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10840)
static void C_ccall f_10840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10864)
static void C_ccall f_10864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10862)
static void C_ccall f_10862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10858)
static void C_ccall f_10858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10850)
static void C_ccall f_10850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10494)
static void C_fcall f_10494(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10500)
static void C_fcall f_10500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10732)
static void C_ccall f_10732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10504)
static void C_ccall f_10504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10507)
static void C_ccall f_10507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10510)
static void C_ccall f_10510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10519)
static void C_fcall f_10519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10616)
static void C_ccall f_10616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10687)
static void C_ccall f_10687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10686)
static void C_ccall f_10686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10678)
static void C_ccall f_10678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10677)
static void C_ccall f_10677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10632)
static void C_ccall f_10632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10662)
static void C_ccall f_10662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10666)
static void C_ccall f_10666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10652)
static void C_ccall f_10652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10605)
static void C_ccall f_10605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10610)
static void C_ccall f_10610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10581)
static void C_ccall f_10581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10593)
static void C_ccall f_10593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10530)
static void C_fcall f_10530(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10551)
static void C_ccall f_10551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10498)
static void C_ccall f_10498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10235)
static void C_fcall f_10235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10241)
static void C_fcall f_10241(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10398)
static void C_ccall f_10398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10245)
static void C_ccall f_10245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10393)
static void C_ccall f_10393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10248)
static void C_ccall f_10248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10388)
static void C_ccall f_10388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10251)
static void C_ccall f_10251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10260)
static void C_fcall f_10260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10362)
static void C_ccall f_10362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10319)
static void C_fcall f_10319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10328)
static void C_ccall f_10328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10340)
static void C_ccall f_10340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10271)
static void C_fcall f_10271(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10292)
static void C_ccall f_10292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10289)
static void C_ccall f_10289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10239)
static void C_ccall f_10239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10136)
static void C_fcall f_10136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10142)
static void C_ccall f_10142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10191)
static void C_fcall f_10191(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10198)
static void C_ccall f_10198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10225)
static void C_ccall f_10225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10221)
static void C_ccall f_10221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10213)
static void C_ccall f_10213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10211)
static void C_ccall f_10211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10176)
static void C_ccall f_10176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10154)
static void C_ccall f_10154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10161)
static void C_ccall f_10161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9914)
static void C_fcall f_9914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10083)
static void C_ccall f_10083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10129)
static void C_ccall f_10129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10108)
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10120)
static void C_ccall f_10120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10098)
static void C_ccall f_10098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10102)
static void C_ccall f_10102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10081)
static void C_ccall f_10081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9917)
static void C_fcall f_9917(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10074)
static void C_ccall f_10074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9921)
static void C_ccall f_9921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10069)
static void C_ccall f_10069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9924)
static void C_ccall f_9924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10064)
static void C_ccall f_10064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9927)
static void C_ccall f_9927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10056)
static void C_ccall f_10056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10039)
static void C_ccall f_10039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10051)
static void C_ccall f_10051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9985)
static void C_fcall f_9985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10009)
static void C_ccall f_10009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10003)
static void C_ccall f_10003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9967)
static void C_ccall f_9967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9942)
static void C_fcall f_9942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9945)
static void C_fcall f_9945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9950)
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9808)
static void C_fcall f_9808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9900)
static void C_ccall f_9900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9895)
static void C_ccall f_9895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9845)
static void C_fcall f_9845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9849)
static void C_ccall f_9849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9853)
static void C_ccall f_9853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9812)
static void C_ccall f_9812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9803)
static void C_ccall f_9803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8543)
static void C_fcall f_8543(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8547)
static void C_ccall f_8547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8709)
static void C_ccall f_8709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8550)
static void C_ccall f_8550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8704)
static void C_ccall f_8704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8553)
static void C_ccall f_8553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8653)
static void C_ccall f_8653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8720)
static void C_fcall f_8720(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9165)
static void C_ccall f_9165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9152)
static void C_ccall f_9152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9147)
static void C_ccall f_9147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8733)
static void C_ccall f_8733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9124)
static void C_ccall f_9124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9046)
static void C_ccall f_9046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9045)
static void C_ccall f_9045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9036)
static void C_ccall f_9036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9025)
static void C_ccall f_9025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9015)
static void C_ccall f_9015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_fcall f_8999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8971)
static void C_fcall f_8971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8976)
static void C_ccall f_8976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8918)
static void C_ccall f_8918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8924)
static void C_fcall f_8924(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8929)
static void C_ccall f_8929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8877)
static void C_ccall f_8877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8883)
static void C_fcall f_8883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8861)
static void C_ccall f_8861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8857)
static void C_ccall f_8857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8827)
static void C_ccall f_8827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8790)
static void C_ccall f_8790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8806)
static void C_ccall f_8806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8772)
static void C_ccall f_8772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_fcall f_9174(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_9790)
static void C_ccall f_9790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9788)
static void C_ccall f_9788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9182)
static void C_ccall f_9182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9188)
static void C_ccall f_9188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_fcall f_9194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9200)
static void C_ccall f_9200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9203)
static void C_ccall f_9203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9209)
static void C_ccall f_9209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9738)
static void C_ccall f_9738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9448)
static void C_ccall f_9448(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9729)
static void C_ccall f_9729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9452)
static void C_ccall f_9452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9724)
static void C_ccall f_9724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9458)
static void C_ccall f_9458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9702)
static void C_ccall f_9702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9705)
static void C_ccall f_9705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9676)
static void C_ccall f_9676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9671)
static void C_ccall f_9671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9476)
static void C_ccall f_9476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9666)
static void C_ccall f_9666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9640)
static void C_ccall f_9640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9643)
static void C_ccall f_9643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9615)
static void C_ccall f_9615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9547)
static void C_ccall f_9547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9550)
static void C_ccall f_9550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9593)
static void C_ccall f_9593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9592)
static void C_ccall f_9592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9584)
static void C_ccall f_9584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9576)
static void C_ccall f_9576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9567)
static void C_ccall f_9567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9556)
static void C_ccall f_9556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9501)
static void C_ccall f_9501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9504)
static void C_ccall f_9504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_ccall f_9430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9428)
static void C_ccall f_9428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9359)
static void C_ccall f_9359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9369)
static void C_ccall f_9369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9393)
static void C_ccall f_9393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9384)
static void C_ccall f_9384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9215)
static void C_ccall f_9215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9350)
static void C_ccall f_9350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9224)
static void C_ccall f_9224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9227)
static void C_ccall f_9227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9276)
static void C_ccall f_9276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9336)
static void C_ccall f_9336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9328)
static void C_ccall f_9328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9304)
static void C_ccall f_9304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9323)
static void C_ccall f_9323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9308)
static void C_ccall f_9308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9318)
static void C_ccall f_9318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9312)
static void C_ccall f_9312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9313)
static void C_ccall f_9313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9292)
static void C_ccall f_9292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9233)
static void C_ccall f_9233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9257)
static void C_ccall f_9257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9256)
static void C_ccall f_9256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8401)
static void C_ccall f_8401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8404)
static void C_ccall f_8404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8445)
static void C_ccall f_8445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8459)
static void C_fcall f_8459(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8508)
static void C_ccall f_8508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6226)
static void C_fcall f_6226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8483)
static void C_ccall f_8483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8453)
static void C_ccall f_8453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8439)
static void C_ccall f_8439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8437)
static void C_ccall f_8437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8425)
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8375)
static void C_ccall f_8375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8367)
static void C_ccall f_8367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8348)
static void C_ccall f_8348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8124)
static void C_ccall f_8124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8276)
static void C_ccall f_8276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8267)
static void C_ccall f_8267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8223)
static void C_ccall f_8223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8194)
static void C_ccall f_8194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8178)
static void C_ccall f_8178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8072)
static void C_ccall f_8072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8066)
static void C_ccall f_8066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8049)
static void C_ccall f_8049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7855)
static void C_ccall f_7855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7991)
static void C_ccall f_7991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7982)
static void C_ccall f_7982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7936)
static void C_ccall f_7936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_ccall f_7825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_fcall f_7769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7753)
static void C_ccall f_7753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7643)
static void C_ccall f_7643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_fcall f_7688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7676)
static void C_ccall f_7676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7386)
static void C_fcall f_7386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7391)
static void C_ccall f_7391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7334)
static void C_ccall f_7334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7326)
static void C_ccall f_7326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7218)
static void C_fcall f_7218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7138)
static void C_ccall f_7138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7150)
static void C_ccall f_7150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_fcall f_6968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6971)
static void C_fcall f_6971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6977)
static void C_ccall f_6977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_ccall f_6707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static void C_fcall f_6441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6204)
static void C_fcall f_6204(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5914)
static void C_fcall f_5914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_fcall f_5827(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5833)
static void C_fcall f_5833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5757)
static void C_ccall f_5757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5570)
static void C_fcall f_5570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_fcall f_5585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_fcall f_5597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_fcall f_5606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_fcall f_5308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_fcall f_5320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_fcall f_5335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_fcall f_5250(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5246)
static C_word C_fcall f_5246(C_word t0);
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5123)
static void C_fcall f_5123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3958)
static void C_fcall f_3958(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_fcall f_5062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_fcall f_5022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_fcall f_4536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_fcall f_4557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_fcall f_4771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_fcall f_4613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_fcall f_4420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_fcall f_4067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3983)
static void C_fcall f_3983(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_fcall f_4028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_fcall f_3821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_fcall f_3613(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_fcall f_3656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static C_word C_fcall f_3609(C_word t0);
C_noret_decl(f_3594)
static void C_fcall f_3594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_fcall f_3573(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3397)
static void C_fcall f_3397(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_fcall f_3449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_fcall f_3422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_fcall f_3385(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static C_word C_fcall f_3352(C_word *a,C_word t0,C_word t1);

C_noret_decl(trf_13091)
static void C_fcall trf_13091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13091(t0,t1,t2);}

C_noret_decl(trf_13110)
static void C_fcall trf_13110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13110(t0,t1);}

C_noret_decl(trf_12187)
static void C_fcall trf_12187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12187(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12187(t0,t1,t2,t3);}

C_noret_decl(trf_12280)
static void C_fcall trf_12280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12280(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_12280(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12296)
static void C_fcall trf_12296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12296(t0,t1);}

C_noret_decl(trf_10460)
static void C_fcall trf_10460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10460(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10460(t0,t1,t2,t3);}

C_noret_decl(trf_11377)
static void C_fcall trf_11377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11377(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11377(t0,t1,t2);}

C_noret_decl(trf_11407)
static void C_fcall trf_11407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11407(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11407(t0,t1,t2,t3);}

C_noret_decl(trf_11448)
static void C_fcall trf_11448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11448(t0,t1);}

C_noret_decl(trf_11260)
static void C_fcall trf_11260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11260(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11260(t0,t1,t2);}

C_noret_decl(trf_10954)
static void C_fcall trf_10954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10954(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10954(t0,t1,t2,t3);}

C_noret_decl(trf_10738)
static void C_fcall trf_10738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10738(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10738(t0,t1,t2);}

C_noret_decl(trf_10494)
static void C_fcall trf_10494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10494(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10494(t0,t1,t2);}

C_noret_decl(trf_10500)
static void C_fcall trf_10500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10500(t0,t1,t2,t3);}

C_noret_decl(trf_10519)
static void C_fcall trf_10519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10519(t0,t1);}

C_noret_decl(trf_10530)
static void C_fcall trf_10530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10530(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10530(t0,t1,t2,t3);}

C_noret_decl(trf_10235)
static void C_fcall trf_10235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10235(t0,t1,t2);}

C_noret_decl(trf_10241)
static void C_fcall trf_10241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10241(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10241(t0,t1,t2,t3);}

C_noret_decl(trf_10260)
static void C_fcall trf_10260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10260(t0,t1);}

C_noret_decl(trf_10319)
static void C_fcall trf_10319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10319(t0,t1);}

C_noret_decl(trf_10271)
static void C_fcall trf_10271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10271(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10271(t0,t1,t2,t3);}

C_noret_decl(trf_10136)
static void C_fcall trf_10136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10136(t0,t1,t2,t3);}

C_noret_decl(trf_10191)
static void C_fcall trf_10191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10191(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10191(t0,t1,t2,t3);}

C_noret_decl(trf_9914)
static void C_fcall trf_9914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9914(t0,t1,t2);}

C_noret_decl(trf_9917)
static void C_fcall trf_9917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9917(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9917(t0,t1,t2,t3);}

C_noret_decl(trf_9985)
static void C_fcall trf_9985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9985(t0,t1,t2,t3);}

C_noret_decl(trf_9942)
static void C_fcall trf_9942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9942(t0,t1);}

C_noret_decl(trf_9945)
static void C_fcall trf_9945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9945(t0,t1);}

C_noret_decl(trf_9808)
static void C_fcall trf_9808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9808(t0,t1);}

C_noret_decl(trf_9845)
static void C_fcall trf_9845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9845(t0,t1);}

C_noret_decl(trf_8543)
static void C_fcall trf_8543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8543(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8543(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8720)
static void C_fcall trf_8720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8720(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8720(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8723)
static void C_fcall trf_8723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8723(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8723(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8999)
static void C_fcall trf_8999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8999(t0,t1);}

C_noret_decl(trf_8971)
static void C_fcall trf_8971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8971(t0,t1);}

C_noret_decl(trf_8924)
static void C_fcall trf_8924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8924(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8924(t0,t1);}

C_noret_decl(trf_8883)
static void C_fcall trf_8883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8883(t0,t1);}

C_noret_decl(trf_9174)
static void C_fcall trf_9174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9174(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_9174(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_9194)
static void C_fcall trf_9194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9194(t0,t1);}

C_noret_decl(trf_8459)
static void C_fcall trf_8459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8459(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8459(t0,t1,t2,t3);}

C_noret_decl(trf_6226)
static void C_fcall trf_6226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6226(t0,t1);}

C_noret_decl(trf_7769)
static void C_fcall trf_7769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7769(t0,t1);}

C_noret_decl(trf_7688)
static void C_fcall trf_7688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7688(t0,t1);}

C_noret_decl(trf_7386)
static void C_fcall trf_7386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7386(t0,t1);}

C_noret_decl(trf_7218)
static void C_fcall trf_7218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7218(t0,t1);}

C_noret_decl(trf_6968)
static void C_fcall trf_6968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6968(t0,t1);}

C_noret_decl(trf_6971)
static void C_fcall trf_6971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6971(t0,t1);}

C_noret_decl(trf_6441)
static void C_fcall trf_6441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6441(t0,t1);}

C_noret_decl(trf_6204)
static void C_fcall trf_6204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6204(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6204(t0,t1,t2,t3);}

C_noret_decl(trf_5914)
static void C_fcall trf_5914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5914(t0,t1);}

C_noret_decl(trf_5827)
static void C_fcall trf_5827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5827(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5827(t0,t1,t2,t3);}

C_noret_decl(trf_5833)
static void C_fcall trf_5833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5833(t0,t1,t2,t3);}

C_noret_decl(trf_5570)
static void C_fcall trf_5570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5570(t0,t1);}

C_noret_decl(trf_5585)
static void C_fcall trf_5585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5585(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5585(t0,t1);}

C_noret_decl(trf_5597)
static void C_fcall trf_5597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5597(t0,t1);}

C_noret_decl(trf_5606)
static void C_fcall trf_5606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5606(t0,t1);}

C_noret_decl(trf_5308)
static void C_fcall trf_5308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5308(t0,t1);}

C_noret_decl(trf_5320)
static void C_fcall trf_5320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5320(t0,t1);}

C_noret_decl(trf_5335)
static void C_fcall trf_5335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5335(t0,t1);}

C_noret_decl(trf_5250)
static void C_fcall trf_5250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5250(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5250(t0,t1,t2,t3);}

C_noret_decl(trf_5123)
static void C_fcall trf_5123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5123(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5123(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3958)
static void C_fcall trf_3958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3958(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3958(t0,t1,t2);}

C_noret_decl(trf_5062)
static void C_fcall trf_5062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5062(t0,t1);}

C_noret_decl(trf_5022)
static void C_fcall trf_5022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5022(t0,t1);}

C_noret_decl(trf_4536)
static void C_fcall trf_4536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4536(t0,t1);}

C_noret_decl(trf_4557)
static void C_fcall trf_4557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4557(t0,t1);}

C_noret_decl(trf_4771)
static void C_fcall trf_4771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4771(t0,t1);}

C_noret_decl(trf_4613)
static void C_fcall trf_4613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4613(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4613(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4420)
static void C_fcall trf_4420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4420(t0,t1);}

C_noret_decl(trf_4067)
static void C_fcall trf_4067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4067(t0,t1);}

C_noret_decl(trf_3983)
static void C_fcall trf_3983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3983(t0,t1,t2);}

C_noret_decl(trf_4028)
static void C_fcall trf_4028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4028(t0,t1);}

C_noret_decl(trf_3821)
static void C_fcall trf_3821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3821(t0,t1);}

C_noret_decl(trf_3613)
static void C_fcall trf_3613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3613(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3613(t0,t1,t2);}

C_noret_decl(trf_3656)
static void C_fcall trf_3656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3656(t0,t1);}

C_noret_decl(trf_3594)
static void C_fcall trf_3594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3594(t0,t1);}

C_noret_decl(trf_3573)
static void C_fcall trf_3573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3573(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3573(t0,t1,t2,t3);}

C_noret_decl(trf_3397)
static void C_fcall trf_3397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3397(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3397(t0,t1,t2,t3);}

C_noret_decl(trf_3449)
static void C_fcall trf_3449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3449(t0,t1);}

C_noret_decl(trf_3422)
static void C_fcall trf_3422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3422(t0,t1);}

C_noret_decl(trf_3385)
static void C_fcall trf_3385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3385(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3385(t0,t1,t2,t3);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1904)){
C_save(t1);
C_rereclaim2(1904*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,258);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],12,"always-bound");
lf[2]=C_h_intern(&lf[2],6,"append");
lf[3]=C_h_intern(&lf[3],18,"\010compilerdebugging");
lf[4]=C_h_intern(&lf[4],1,"o");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[6]=C_h_intern(&lf[6],12,"\003sysfor-each");
lf[7]=C_h_intern(&lf[7],13,"\004corevariable");
lf[8]=C_h_intern(&lf[8],2,"if");
lf[9]=C_h_intern(&lf[9],3,"let");
lf[10]=C_h_intern(&lf[10],6,"lambda");
lf[11]=C_h_intern(&lf[11],13,"\004corecallunit");
lf[12]=C_h_intern(&lf[12],9,"\004corecall");
lf[13]=C_h_intern(&lf[13],4,"set!");
lf[14]=C_h_intern(&lf[14],9,"\004corecond");
lf[15]=C_h_intern(&lf[15],11,"\004coreswitch");
lf[16]=C_h_intern(&lf[16],30,"call-with-current-continuation");
lf[17]=C_h_intern(&lf[17],1,"p");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[19]=C_h_intern(&lf[19],24,"\010compilersimplifications");
lf[20]=C_h_intern(&lf[20],23,"\010compilersimplified-ops");
lf[21]=C_h_intern(&lf[21],41,"\010compilerperform-high-level-optimizations");
lf[22]=C_h_intern(&lf[22],12,"\010compilerget");
lf[23]=C_h_intern(&lf[23],5,"quote");
lf[24]=C_h_intern(&lf[24],10,"alist-cons");
lf[25]=C_h_intern(&lf[25],4,"caar");
lf[26]=C_h_intern(&lf[26],7,"\003sysmap");
lf[27]=C_h_intern(&lf[27],19,"\010compilermatch-node");
lf[28]=C_h_intern(&lf[28],3,"any");
lf[29]=C_h_intern(&lf[29],18,"\003syshash-table-ref");
lf[30]=C_h_intern(&lf[30],30,"\010compilerbroken-constant-nodes");
lf[31]=C_h_intern(&lf[31],11,"lset-adjoin");
lf[32]=C_h_intern(&lf[32],3,"eq\077");
lf[33]=C_h_intern(&lf[33],4,"node");
lf[34]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[35]=C_h_intern(&lf[35],14,"\010compilerqnode");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[37]=C_h_intern(&lf[37],4,"eval");
lf[38]=C_h_intern(&lf[38],22,"with-exception-handler");
lf[39]=C_h_intern(&lf[39],5,"every");
lf[40]=C_h_intern(&lf[40],8,"foldable");
lf[41]=C_h_intern(&lf[41],16,"extended-binding");
lf[42]=C_h_intern(&lf[42],16,"standard-binding");
lf[43]=C_h_intern(&lf[43],5,"value");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[45]=C_h_intern(&lf[45],16,"\010compilervarnode");
lf[46]=C_h_intern(&lf[46],11,"collapsable");
lf[47]=C_h_intern(&lf[47],10,"replacable");
lf[48]=C_h_intern(&lf[48],9,"replacing");
lf[49]=C_h_intern(&lf[49],12,"contractable");
lf[50]=C_h_intern(&lf[50],9,"removable");
lf[51]=C_h_intern(&lf[51],11,"\004corelambda");
lf[52]=C_h_intern(&lf[52],6,"unused");
lf[53]=C_h_intern(&lf[53],9,"partition");
lf[54]=C_h_intern(&lf[54],26,"\010compilerbuild-lambda-list");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[56]=C_h_intern(&lf[56],13,"explicit-rest");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[58]=C_h_intern(&lf[58],30,"\010compilerdecompose-lambda-list");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[60]=C_h_intern(&lf[60],21,"has-unused-parameters");
lf[61]=C_h_intern(&lf[61],31,"\010compilerinline-lambda-bindings");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[63]=C_h_intern(&lf[63],24,"\010compilercheck-signature");
lf[64]=C_h_intern(&lf[64],30,"\010compilerconstant-declarations");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[66]=C_h_intern(&lf[66],14,"\004coreundefined");
lf[67]=C_h_intern(&lf[67],1,"x");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[69]=C_h_intern(&lf[69],37,"\010compilerexpression-has-side-effects\077");
lf[70]=C_h_intern(&lf[70],8,"assigned");
lf[71]=C_h_intern(&lf[71],10,"references");
lf[72]=C_h_intern(&lf[72],7,"unknown");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[74]=C_h_intern(&lf[74],1,"i");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\023procedure inlinable");
lf[76]=C_h_intern(&lf[76],14,"append-reverse");
lf[77]=C_h_intern(&lf[77],6,"gensym");
lf[78]=C_h_intern(&lf[78],1,"t");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[80]=C_h_intern(&lf[80],8,"split-at");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[82]=C_h_intern(&lf[82],20,"\004coreinline_allocate");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[84]=C_h_intern(&lf[84],24,"\010compilernot-inline-list");
lf[85]=C_h_intern(&lf[85],20,"\010compilerinline-list");
lf[86]=C_h_intern(&lf[86],24,"\010compilerinline-max-size");
lf[87]=C_h_intern(&lf[87],9,"inlinable");
lf[88]=C_h_intern(&lf[88],6,"simple");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[90]=C_h_intern(&lf[90],26,"\010compilerblock-compilation");
lf[91]=C_h_intern(&lf[91],20,"\010compilerexport-list");
lf[92]=C_h_intern(&lf[92],6,"global");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[96]=C_h_intern(&lf[96],5,"print");
lf[97]=C_h_intern(&lf[97],7,"newline");
lf[98]=C_h_intern(&lf[98],6,"print*");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[102]=C_h_intern(&lf[102],34,"\010compilerperform-pre-optimization!");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[104]=C_h_intern(&lf[104],24,"node-subexpressions-set!");
lf[105]=C_h_intern(&lf[105],20,"node-parameters-set!");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\034removed call in test-context");
lf[108]=C_h_intern(&lf[108],10,"call-sites");
lf[109]=C_h_intern(&lf[109],67,"\010compilerside-effect-free-standard-bindings-that-never-return-false");
lf[110]=C_h_intern(&lf[110],7,"reverse");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[112]=C_h_intern(&lf[112],3,"not");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[114]=C_h_intern(&lf[114],24,"register-simplifications");
lf[115]=C_h_intern(&lf[115],19,"\003syshash-table-set!");
lf[116]=C_h_intern(&lf[116],38,"\010compilerreorganize-recursive-bindings");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[118]=C_h_intern(&lf[118],10,"fold-right");
lf[119]=C_h_intern(&lf[119],4,"fold");
lf[120]=C_h_intern(&lf[120],25,"\010compilertopological-sort");
lf[121]=C_h_intern(&lf[121],6,"lset<=");
lf[122]=C_h_intern(&lf[122],10,"filter-map");
lf[123]=C_h_intern(&lf[123],6,"filter");
lf[124]=C_h_intern(&lf[124],10,"append-map");
lf[125]=C_h_intern(&lf[125],28,"\010compilerscan-used-variables");
lf[126]=C_h_intern(&lf[126],8,"for-each");
lf[127]=C_h_intern(&lf[127],3,"map");
lf[128]=C_h_intern(&lf[128],4,"cons");
lf[129]=C_h_intern(&lf[129],27,"\010compilersubstitution-table");
lf[130]=C_h_intern(&lf[130],16,"\010compilerrewrite");
lf[131]=C_h_intern(&lf[131],28,"\010compilersimplify-named-call");
lf[132]=C_h_intern(&lf[132],37,"\010compilerinline-substitutions-enabled");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[134]=C_h_intern(&lf[134],11,"\004coreinline");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[136]=C_h_intern(&lf[136],6,"unsafe");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[138]=C_h_intern(&lf[138],6,"vector");
lf[139]=C_h_intern(&lf[139],14,"rest-parameter");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[141]=C_h_intern(&lf[141],11,"number-type");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[143]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[146]=C_h_intern(&lf[146],6,"fixnum");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[148]=C_h_intern(&lf[148],21,"\010compilerfold-boolean");
lf[149]=C_h_intern(&lf[149],6,"flonum");
lf[150]=C_h_intern(&lf[150],7,"generic");
lf[151]=C_h_intern(&lf[151],5,"cons*");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[153]=C_h_intern(&lf[153],9,"\004coreproc");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_h_intern(&lf[162],19,"\010compilerfold-inner");
lf[163]=C_h_intern(&lf[163],6,"remove");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_h_intern(&lf[168],5,"fifth");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[170]=C_h_intern(&lf[170],13,"\010compilerbomb");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[172]=C_h_intern(&lf[172],34,"\010compilertransform-direct-lambdas!");
lf[173]=C_h_intern(&lf[173],19,"\010compilercopy-node!");
lf[174]=C_h_intern(&lf[174],16,"\004coredirect_call");
lf[175]=C_h_intern(&lf[175],4,"quit");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[177]=C_h_intern(&lf[177],15,"lset-difference");
lf[178]=C_h_intern(&lf[178],15,"node-class-set!");
lf[179]=C_h_intern(&lf[179],12,"\004corerecurse");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[181]=C_h_intern(&lf[181],4,"take");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[184]=C_h_intern(&lf[184],11,"\004corereturn");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[186]=C_h_intern(&lf[186],18,"\004coredirect_lambda");
lf[187]=C_h_intern(&lf[187],6,"cdaddr");
lf[188]=C_h_intern(&lf[188],6,"caaddr");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[191]=C_h_intern(&lf[191],6,"unzip1");
lf[192]=C_h_intern(&lf[192],16,"\003sysmake-promise");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[194]=C_h_intern(&lf[194],5,"boxed");
lf[195]=C_h_intern(&lf[195],15,"\004coreinline_ref");
lf[196]=C_h_intern(&lf[196],37,"\010compilerestimate-foreign-result-size");
lf[197]=C_h_intern(&lf[197],19,"\004coreinline_loc_ref");
lf[198]=C_h_intern(&lf[198],5,"lset=");
lf[199]=C_h_intern(&lf[199],6,"delete");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[201]=C_h_intern(&lf[201],32,"\010compilerperform-lambda-lifting!");
lf[202]=C_h_intern(&lf[202],23,"\003syshash-table-for-each");
lf[203]=C_h_intern(&lf[203],1,"+");
lf[204]=C_h_intern(&lf[204],17,"delete-duplicates");
lf[205]=C_h_intern(&lf[205],14,"\004coreprimitive");
lf[206]=C_h_intern(&lf[206],7,"delete!");
lf[207]=C_h_intern(&lf[207],11,"concatenate");
lf[208]=C_h_intern(&lf[208],5,"count");
lf[209]=C_h_intern(&lf[209],22,"\010compilerblock-globals");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[213]=C_h_intern(&lf[213],12,"pretty-print");
lf[214]=C_h_intern(&lf[214],1,"l");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[225]=C_h_intern(&lf[225],11,"make-vector");
lf[226]=C_h_intern(&lf[226],3,"var");
lf[227]=C_h_intern(&lf[227],1,"y");
lf[228]=C_h_intern(&lf[228],2,"d2");
lf[229]=C_h_intern(&lf[229],1,"z");
lf[230]=C_h_intern(&lf[230],2,"d3");
lf[231]=C_h_intern(&lf[231],2,"d1");
lf[232]=C_h_intern(&lf[232],2,"op");
lf[233]=C_h_intern(&lf[233],5,"clist");
lf[234]=C_h_intern(&lf[234],34,"\010compilermembership-test-operators");
lf[235]=C_h_intern(&lf[235],32,"\010compilermembership-unfold-limit");
lf[236]=C_h_intern(&lf[236],4,"var1");
lf[237]=C_h_intern(&lf[237],4,"var0");
lf[238]=C_h_intern(&lf[238],6,"const1");
lf[239]=C_h_intern(&lf[239],4,"var2");
lf[240]=C_h_intern(&lf[240],6,"const2");
lf[241]=C_h_intern(&lf[241],4,"rest");
lf[242]=C_h_intern(&lf[242],5,"body2");
lf[243]=C_h_intern(&lf[243],5,"body1");
lf[244]=C_h_intern(&lf[244],27,"\010compilereq-inline-operator");
lf[245]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[246]=C_h_intern(&lf[246],19,"\010compilerimmediate\077");
lf[247]=C_h_intern(&lf[247],5,"const");
lf[248]=C_h_intern(&lf[248],1,"n");
lf[249]=C_h_intern(&lf[249],7,"clauses");
lf[250]=C_h_intern(&lf[250],4,"body");
lf[251]=C_h_intern(&lf[251],1,"d");
lf[252]=C_h_intern(&lf[252],4,"more");
lf[253]=C_h_intern(&lf[253],4,"args");
lf[254]=C_h_intern(&lf[254],1,"a");
lf[255]=C_h_intern(&lf[255],1,"b");
lf[256]=C_h_intern(&lf[256],1,"c");
lf[257]=C_h_intern(&lf[257],4,"cdar");
C_register_lf2(lf,258,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3332,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3330 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3333 in k3330 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3336 in k3333 in k3330 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3349,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 141  make-vector");
t4=*((C_word*)lf[225]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=C_mutate((C_word*)lf[19]+1 /* simplifications ...) */,t1);
t3=C_set_block_item(lf[20] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[21]+1 /* perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3570,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[102]+1 /* perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5243,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[114]+1 /* register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5806,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[254],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[7],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[255],lf[256]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[251],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[12],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[256],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[255],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[254],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13078,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
C_trace("optimizer.scm: 533  register-simplifications");
t23=C_retrieve(lf[114]);
((C_proc4)C_retrieve_proc(t23))(4,t23,t7,lf[12],t22);}

/* a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_13078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_13078,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13086,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 539  ##sys#hash-table-ref");
t8=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,C_retrieve(lf[129]),t3);}

/* k13084 in a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_13086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13086,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_13091(t6,((C_word*)t0)[2],t2);}

/* loop in k13084 in a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_13091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13091,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13101,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13136,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 541  caar");
t5=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k13134 in loop in k13084 in a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_13136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13140,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 541  cdar");
t3=*((C_word*)lf[257]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k13138 in k13134 in loop in k13084 in a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_13140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 541  simplify-named-call");
t2=C_retrieve(lf[131]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k13099 in loop in k13084 in a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_13101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13101,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[20]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13110,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_13110(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13125,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 546  alist-cons");
t5=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[20]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 548  loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_13091(t3,((C_word*)t0)[4],t2);}}

/* k13123 in k13099 in loop in k13084 in a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_13125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[20]+1 /* simplified-ops ...) */,t1);
t3=((C_word*)t0)[2];
f_13110(t3,t2);}

/* k13108 in k13099 in loop in k13084 in a13077 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_13110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[7],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[23],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[134],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[7],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[7],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[23],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[134],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[7],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[242],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[228],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[8],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[9],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[243],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[231],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[8],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[9],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[228],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[231],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[242],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[243],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[240],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[238],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[232],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[239],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[236],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[237],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12757,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[7],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[23],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[134],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[7],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[7],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[249]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[15],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[250],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[251],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[8],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[9],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[249],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[248],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[250],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[251],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[247],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[237],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[232],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[226],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12536,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[66],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[252],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[9],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[252],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[236],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12177,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[253]);
t125=(C_word)C_a_i_cons(&a,2,lf[134],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[7],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[227],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[67],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[251],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[8],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[9],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[227],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[67],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[251],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[253],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[232],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[226],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12029,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
C_trace("optimizer.scm: 551  register-simplifications");
t148=C_retrieve(lf[114]);
((C_proc7)C_retrieve_proc(t148))(7,t148,t2,lf[9],t65,t108,t121,t147);}

/* a12028 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_12029,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[244])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12075,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 686  get");
t10=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,t2,t3,lf[71]);}}

/* k12073 in a12028 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12075,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12063,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[134],t5,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_12063 in k12073 in a12028 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12063,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k12056 in k12073 in a12028 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12058,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12050,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[8],((C_word*)t0)[2],t2);}

/* f_12050 in k12056 in k12073 in a12028 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12050,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12177,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12187,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12187(t9,t1,t5,t4);}

/* loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_12187(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12187,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12191,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12486,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_12486 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12486,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12481,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12481 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12481,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12197,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12476,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12476 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12476,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12197,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t1);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12215,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12467,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_12467 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12467,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12462,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12462 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12462,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12221,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12457,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12457 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12457,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12221,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[66]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_cadr(((C_word*)t0)[7]);
C_trace("optimizer.scm: 632  loop1");
t6=((C_word*)((C_word*)t0)[6])[1];
f_12187(t6,((C_word*)t0)[5],t4,t5);}
else{
t3=(C_word)C_eqp(t1,lf[13]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12251,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 634  reverse");
t5=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12251,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12280,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12280(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_12280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12280,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12284,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12440,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* f_12440 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12440,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12287,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12435,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_12435 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12435,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12290,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12430,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_12430 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12430,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12296,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[9]);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12421,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 645  get");
t7=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[2],t6,lf[71]);}
else{
t5=t2;
f_12296(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_12296(t4,C_SCHEME_FALSE);}}

/* k12419 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12421,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_12296(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12413,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
f_12296(t2,C_SCHEME_FALSE);}}}

/* f_12413 in k12419 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12413,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12406 in k12419 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12408,2,t0,t1);}
t2=(C_word)C_eqp(lf[13],t1);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12395,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12400,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_12296(t3,C_SCHEME_FALSE);}}

/* f_12400 in k12406 in k12419 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12400,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12393 in k12406 in k12419 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_12296(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k12294 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_12296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12296,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12319,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12324,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12339,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12349,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a12348 in k12294 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12349,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a12338 in k12294 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 654  reverse");
t3=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12345 in a12338 in k12294 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 654  reorganize-recursive-bindings");
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_12324 in k12294 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12324,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12317 in k12294 in k12288 in k12285 in k12282 in loop2 in k12249 in k12219 in k12216 in k12213 in k12195 in k12192 in k12189 in loop1 in a12176 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12319,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 649  loop2");
t6=((C_word*)((C_word*)t0)[3])[1];
f_12280(t6,((C_word*)t0)[2],t3,t4,t5);}

/* a12535 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_12536,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[244])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12549,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 598  immediate?");
t12=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k12547 in a12535 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12549,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12591,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 599  get");
t3=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[71]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12589 in k12547 in a12535 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12591,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12566,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 603  varnode");
t8=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12573 in k12589 in k12547 in a12535 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 604  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12577 in k12573 in k12589 in k12547 in a12535 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 603  cons*");
t2=C_retrieve(lf[151]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12564 in k12589 in k12547 in a12535 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12567,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_12567 in k12564 in k12589 in k12547 in a12535 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12567,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_12757,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[244])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12770,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 571  immediate?");
t15=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12770,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 572  immediate?");
t3=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12774 in k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12776,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 573  get");
t3=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[71]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12826 in k12774 in k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12828,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12820,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 574  get");
t5=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[71]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12818 in k12826 in k12774 in k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12820,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 578  varnode");
t5=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12802 in k12818 in k12826 in k12774 in k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 579  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12806 in k12802 in k12818 in k12826 in k12774 in k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 581  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12810 in k12806 in k12802 in k12818 in k12826 in k12774 in k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12812,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12796,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[245],t2);}

/* f_12796 in k12810 in k12806 in k12802 in k12818 in k12826 in k12774 in k12768 in a12756 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_12796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12796,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[7],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[227],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[228],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[12],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[7],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[229],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[230],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[12],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[67],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[231],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[8],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[226],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[229],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[227],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[67],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[230],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[228],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[231],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11866,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[23],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[67],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[134],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[229],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[227],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[231],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[8],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[229],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[227],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[233],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[67],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[232],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[231],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11670,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
C_trace("optimizer.scm: 693  register-simplifications");
t56=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t56))(5,t56,t2,lf[8],t32,t55);}

/* a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_11670,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[234]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[235]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11692,a[2]=t6,a[3]=t3,a[4]=t8,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 724  gensym");
t13=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11692,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11715,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11728,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11730,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11772,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 741  qnode");
t9=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_FALSE);}

/* k11770 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 733  fold-right");
t2=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11729 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11730,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11747,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11764,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 738  varnode");
t6=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k11762 in a11729 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 738  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k11766 in k11762 in a11729 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11768,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11756,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[134],((C_word*)t0)[2],t2);}

/* f_11756 in k11766 in k11762 in a11729 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11756,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k11745 in a11729 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 739  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k11749 in k11745 in a11729 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11751,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11739,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[14],C_SCHEME_END_OF_LIST,t2);}

/* f_11739 in k11749 in k11745 in a11729 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11739,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k11726 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11728,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11720,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[8],((C_word*)t0)[2],t2);}

/* f_11720 in k11726 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11720,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k11713 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11715,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11707,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t2);}

/* f_11707 in k11713 in k11690 in a11669 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11707,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* a11865 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_11866,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11886,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 709  varnode");
t11=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11884 in a11865 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11890,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11895,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[14],C_SCHEME_END_OF_LIST,t3);}

/* f_11895 in k11884 in a11865 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11895,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k11888 in k11884 in a11865 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11890,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11878,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t2);}

/* f_11878 in k11888 in k11884 in a11865 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11878,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5819,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5821,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 836  make-vector");
t4=*((C_word*)lf[225]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1 /* substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[130]+1 /* rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6181,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[131]+1 /* simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6201,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[172]+1 /* transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8540,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[201]+1 /* perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9805,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9805,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9808,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9914,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10136,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10235,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10494,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10738,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10954,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11260,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11377,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11549,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1816 debugging");
t16=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[17],lf[224]);}

/* k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1817 find-lifting-candidates");
t3=((C_word*)t0)[2];
f_9808(t3,t2);}

/* k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11555,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1818 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[223]);}

/* k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1819 build-call-graph");
t3=((C_word*)t0)[2];
f_9914(t3,t2,((C_word*)t0)[3]);}

/* k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11561,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1820 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[222]);}

/* k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11564,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1821 eliminate");
t3=((C_word*)t0)[4];
f_10136(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11567,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11641,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1822 debugging");
t4=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[214],lf[221]);}

/* k11639 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1822 pretty-print");
t2=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11567(2,t2,C_SCHEME_UNDEFINED);}}

/* k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 1823 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[220]);}

/* k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1824 collect-accessibles");
t3=((C_word*)t0)[2];
f_10235(t3,t2,((C_word*)t0)[3]);}

/* k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11635,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1825 debugging");
t4=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[214],lf[219]);}

/* k11633 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1825 pretty-print");
t2=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11576(2,t2,C_SCHEME_UNDEFINED);}}

/* k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1826 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[218]);}

/* k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11582,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11632,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1827 eliminate4");
t4=((C_word*)t0)[3];
f_10494(t4,t3,((C_word*)t0)[2]);}

/* k11630 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11632,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10460,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10460(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k11630 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10460(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10460,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10464,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10478,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1621 filter");
t6=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,t2);}

/* a10477 in loop in k11630 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10478,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
C_trace("optimizer.scm: 1621 every");
t5=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a10483 in a10477 in loop in k11630 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10484,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k10462 in loop in k11630 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
C_trace("optimizer.scm: 1625 loop");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10460(t5,((C_word*)t0)[3],t1,t2);}}

/* k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11624,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#make-promise");
t5=*((C_word*)lf[192]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a11623 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11624,2,t0,t1);}
C_trace("optimizer.scm: 1828 unzip1");
t2=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k11620 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1828 debugging");
t2=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[4],lf[217],t1);}

/* k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1829 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[216]);}

/* k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1830 compute-extra-variables");
t3=((C_word*)t0)[2];
f_10738(t3,t2,((C_word*)t0)[5]);}

/* k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11615,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1831 debugging");
t4=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[214],lf[215]);}

/* k11613 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1831 pretty-print");
t2=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11594(2,t2,C_SCHEME_UNDEFINED);}}

/* k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1832 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[212]);}

/* k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1833 extend-call-sites!");
t3=((C_word*)t0)[2];
f_11260(t3,t2,((C_word*)t0)[4]);}

/* k11598 in k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1834 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[211]);}

/* k11601 in k11598 in k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1835 remove-local-bindings!");
t3=((C_word*)t0)[2];
f_11377(t3,t2,((C_word*)t0)[4]);}

/* k11604 in k11601 in k11598 in k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1836 debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[210]);}

/* k11607 in k11604 in k11601 in k11598 in k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1837 reconstruct!");
t2=((C_word*)t0)[5];
f_10954(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_11377(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11377,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11383,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11383(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11383,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11387,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11542,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11542 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11542,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11537,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11537 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11537,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11393,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11532,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11532 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11532,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11393,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11402,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11486,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11487,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11500,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11523,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11524,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t1);}}}

/* f_11524 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11524,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11521 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k11498 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11500,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1811 node-class-set!");
t4=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[66]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k11507 in k11498 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1812 node-parameters-set!");
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11510 in k11507 in k11498 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1813 node-subexpressions-set!");
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* f_11487 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11487,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11484 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k11400 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11402,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11407,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_11407(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3222 in k11400 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_11407(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11407,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1801 copy-node!");
t5=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11430,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11445,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1803 reverse");
t6=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11448,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_11448(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_11448(t12,t11);}}}

/* k11446 in doloop3222 in k11400 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_11448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_11407(t4,((C_word*)t0)[2],t2,t3);}

/* k11443 in doloop3222 in k11400 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1803 node-parameters-set!");
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11428 in doloop3222 in k11400 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11441,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1804 reverse");
t4=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k11439 in k11428 in doloop3222 in k11400 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1804 append");
t2=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11435 in k11428 in doloop3222 in k11400 in k11391 in k11388 in k11385 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1804 node-subexpressions-set!");
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_11260(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11260,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11266,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11266(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11270,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11371,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11371 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11371,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11366,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11366 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11366,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11276,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11361,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11361 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11361,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11276,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[12]);
if(C_truep(t2)){
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11288,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11352,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11353,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],t1);}}

/* f_11353 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11353,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11350 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11352,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11344,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[4];
f_11288(2,t3,C_SCHEME_UNDEFINED);}}

/* f_11344 in k11350 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11344,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11341 in k11350 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11343,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(C_word)C_i_set_car(((C_word*)t0)[6],C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11327,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t3);
C_trace("map");
t8=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,C_retrieve(lf[45]),t7);}
else{
t4=((C_word*)t0)[4];
f_11288(2,t4,C_SCHEME_UNDEFINED);}}

/* k11325 in k11341 in k11350 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1783 append");
t3=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11321 in k11341 in k11350 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11323,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("optimizer.scm: 1781 node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11286 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11296,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_11296 in k11286 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11296,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11293 in k11286 in k11274 in k11271 in k11268 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10954(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10954,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10966,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10968,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11110,a[2]=t2,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11111,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}

/* f_11111 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11111,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11108 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
C_trace("optimizer.scm: 1717 fold-right");
t3=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10968,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10975,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1720 get");
t6=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t4,lf[43]);}

/* k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10975,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_retrieve(lf[209]));
t3=C_mutate((C_word*)lf[209]+1 /* block-globals ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11097,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11098,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}

/* f_11098 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11098,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11097,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1722 decompose-lambda-list");
t4=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10988,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10995,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
C_trace("map");
t8=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[77]),t6);}

/* k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1727 map");
t3=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[128]+1),((C_word*)t0)[5],t1);}

/* k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11084,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11085,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* f_11085 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11085,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11084,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11120,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11135,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11135(3,t8,((C_word*)t0)[2],t2);}

/* walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11135,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11139,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11254,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11254 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11254,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11249,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11249 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11249,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11145,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11244,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11244 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11244,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11145,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11154,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11161,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11178,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1756 rename");
t6=((C_word*)t0)[3];
f_11120(3,t6,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11191,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11202,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1758 rename");
t8=((C_word*)t0)[3];
f_11120(3,t8,t6,t7);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[10]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1761 decompose-lambda-list");
t8=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],t6,t7);}
else{
C_trace("for-each");
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],t1);}}}}}

/* a11220 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11221,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11236,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11240,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k11238 in a11220 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1764 build-lambda-list");
t2=C_retrieve(lf[54]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11234 in a11220 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1765 walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_11135(3,t4,((C_word*)t0)[2],t3);}

/* k11200 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11202,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1758 node-parameters-set!");
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11189 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k11176 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11178,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1756 node-parameters-set!");
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11159 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1753 node-parameters-set!");
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11152 in k11143 in k11140 in k11137 in walk in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k11082 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11120,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1730 gensym");
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[78]);}

/* k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11076,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11021,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11038,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11060,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11064,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1736 append");
t8=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11062 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
C_trace("optimizer.scm: 1736 build-lambda-list");
t4=C_retrieve(lf[54]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k11058 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11060,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11046,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11052,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_11052 in k11058 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11052,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11044 in k11058 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11047,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t1);}

/* f_11047 in k11044 in k11058 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11047,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k11036 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11038,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11030,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[13],((C_word*)t0)[2],t2);}

/* f_11030 in k11036 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11030,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k11019 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11021,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11013,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t2);}

/* f_11013 in k11019 in k11074 in k10999 in k10996 in k10993 in a10987 in k11095 in k10973 in a10967 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11013,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k10964 in reconstruct! in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10966,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1714 node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10738(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10738,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10818,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10940,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a10939 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10940,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10818,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10820,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10895,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("for-each");
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10900,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10900,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10938,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1703 get");
t5=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,lf[43]);}

/* k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10938,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10747,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10747(3,t8,t4,t1);}

/* walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10747,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10751,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10811,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10811 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10811,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10806,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10806 in k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10806,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10752 in k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10757,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10801,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10801 in k10752 in k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10801,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10755 in k10752 in k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10757,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[9]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10767,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1679 append");
t4=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[10]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10785,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1682 decompose-lambda-list");
t6=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[4],t4,t5);}
else{
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);}}}

/* a10784 in k10755 in k10752 in k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10785,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10790,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1685 append");
t6=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k10788 in a10784 in k10755 in k10752 in k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1686 walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_10747(3,t4,((C_word*)t0)[2],t3);}

/* k10765 in k10755 in k10752 in k10749 in walk in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10743 in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10745,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10914,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10916,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10930,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1709 delete-duplicates");
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,*((C_word*)lf[32]+1));}

/* k10928 in k10743 in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1705 remove");
t2=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10915 in k10743 in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10916,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k10912 in k10743 in k10936 in a10899 in k10893 in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10914,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10820,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10888,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1694 count");
t6=C_retrieve(lf[208]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a10887 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10888,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k10884 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10886,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10840,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a10873 in k10884 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10874,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
C_trace("optimizer.scm: 1697 walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_10820(3,t4,t1,t3);}

/* k10838 in k10884 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10840,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10850,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10858,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10862,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10864,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t8=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a10863 in k10838 in k10884 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10864,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k10860 in k10838 in k10884 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1699 concatenate");
t2=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10856 in k10838 in k10884 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1699 append");
t2=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10848 in k10838 in k10884 in walk in k10816 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10494(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10494,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10498,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10500,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10500(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10500(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10500,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10504,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10732,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10732 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10732,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10727,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10727 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10727,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10722,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10722 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10722,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10510,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[7]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10519,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_10519(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[23]);
if(C_truep(t4)){
t5=t3;
f_10519(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[66]);
if(C_truep(t5)){
t6=t3;
f_10519(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[205]);
t7=t3;
f_10519(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[7],lf[153])));}}}}

/* k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10519,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10530,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_10530(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[10]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10581,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1644 decompose-lambda-list");
t6=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[12]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10616,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1650 call-with-current-continuation");
t8=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10696,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a10695 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10696,3,t0,t1,t2);}
C_trace("optimizer.scm: 1665 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10500(t3,t1,t2,((C_word*)t0)[2]);}

/* a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10616,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10686,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10687,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_10687 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10687,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10684 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10686,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10678,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* f_10678 in k10684 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10678,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10675 in k10684 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10677,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_10632(3,t6,((C_word*)t0)[2],t2);}

/* loop in k10675 in k10684 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10632,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10652,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10662,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
C_trace("optimizer.scm: 1659 lset<=");
t9=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[32]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k10660 in loop in k10675 in k10684 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10662,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10652(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10666,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1661 delete!");
t3=C_retrieve(lf[206]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[32]+1));}}

/* k10664 in k10660 in loop in k10675 in k10684 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
C_trace("optimizer.scm: 1662 return");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k10650 in loop in k10675 in k10684 in a10615 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k10603 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10609 in k10603 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10610,3,t0,t1,t2);}
C_trace("optimizer.scm: 1664 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10500(t3,t1,t2,((C_word*)t0)[2]);}

/* a10580 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10581,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10593,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1647 append");
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10591 in a10580 in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1647 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10500(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10530(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10530,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10548,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1639 append");
t6=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10551,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1641 walk");
t6=((C_word*)((C_word*)t0)[5])[1];
f_10500(t6,t4,t5,((C_word*)t0)[3]);}}

/* k10549 in loop in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1642 loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_10530(t4,((C_word*)t0)[2],t2,t3);}

/* k10546 in loop in k10517 in k10508 in k10505 in k10502 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1639 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10500(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10496 in eliminate4 in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10235,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10239,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10241,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_10241(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10241(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10241,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10398,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10398 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10398,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10393,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10393 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10393,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10388,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10388 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10388,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10251,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[7]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=t3;
f_10260(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[10],lf[23]);
if(C_truep(t4)){
t5=t3;
f_10260(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[66]);
if(C_truep(t5)){
t6=t3;
f_10260(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[10],lf[205]);
t7=t3;
f_10260(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[10],lf[153])));}}}}

/* k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10260,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[9]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10271,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_10271(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[10]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10319,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10353,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
C_trace("optimizer.scm: 1596 alist-cons");
t9=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_10319(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_10319(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10362,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a10361 in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10362,3,t0,t1,t2);}
C_trace("optimizer.scm: 1602 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10241(t3,t1,t2,((C_word*)t0)[2]);}

/* k10351 in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10319(t3,t2);}

/* k10317 in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10319,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1597 decompose-lambda-list");
t4=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a10327 in k10317 in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10328,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10340,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1600 append");
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10338 in a10327 in k10317 in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1600 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10241(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10271(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10271,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10289,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1587 append");
t6=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10292,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1589 walk");
t6=((C_word*)((C_word*)t0)[5])[1];
f_10241(t6,t4,t5,((C_word*)t0)[3]);}}

/* k10290 in loop in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1590 loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_10271(t4,((C_word*)t0)[2],t2,t3);}

/* k10287 in loop in k10258 in k10249 in k10246 in k10243 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1587 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10241(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10237 in collect-accessibles in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10136(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10136,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10142,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1557 remove");
t5=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10142,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10176,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10186,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1567 unzip1");
t7=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k10184 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10186,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10191,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10191(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k10184 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_10191(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10191,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10198,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
C_trace("optimizer.scm: 1570 lset-difference");
t7=C_retrieve(lf[177]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t5,*((C_word*)lf[32]+1),t6,t3,((C_word*)t0)[2]);}

/* k10196 in count in k10184 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10225,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1571 delete-duplicates");
t4=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,*((C_word*)lf[32]+1));}

/* k10223 in k10196 in count in k10184 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10225,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1572 append");
t4=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10219 in k10223 in k10196 in count in k10184 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10221,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10211,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10213,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10212 in k10219 in k10223 in k10196 in count in k10184 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10213,3,t0,t1,t2);}
C_trace("optimizer.scm: 1573 count");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10191(t3,t1,t2,((C_word*)t0)[2]);}

/* k10209 in k10219 in k10223 in k10196 in count in k10184 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1573 fold");
t2=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[203]+1),((C_word*)t0)[2],t1);}

/* k10174 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10176,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1560 any");
t5=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[5],t3,t4);}}

/* a10153 in k10174 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10154,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10161,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1561 get");
t4=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],t2,lf[70]);}

/* k10159 in a10153 in k10174 in a10141 in eliminate in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9914,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9917,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10081,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10083,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("for-each");
t14=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10083,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10129,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10130,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* f_10130 in a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10130,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10127 in a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10129,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10098,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1546 decompose-lambda-list");
t7=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t2,t6);}

/* a10107 in k10127 in a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10108,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10120,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10121,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* f_10121 in a10107 in k10127 in a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10121,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10118 in a10107 in k10127 in a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
C_trace("optimizer.scm: 1549 walk");
t3=((C_word*)((C_word*)t0)[4])[1];
f_9917(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10096 in k10127 in a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10102,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
C_trace("optimizer.scm: 1550 alist-cons");
t4=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k10100 in k10096 in k10127 in a10082 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10079 in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9917(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9917,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9921,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10074,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10074 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10074,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10069,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10069 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10069,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10064,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10064 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10064,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9927,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[10],lf[13]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_memq(t4,((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9967,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_9967(2,t8,t6);}
else{
C_trace("optimizer.scm: 1522 get");
t8=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],t4,lf[92]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[10],lf[9]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9985,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_9985(t8,((C_word*)t0)[6],((C_word*)t0)[9],t1);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[10]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10039,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1534 decompose-lambda-list");
t8=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10056,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],t6,t1);}}}}

/* a10055 in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10056,3,t0,t1,t2);}
C_trace("optimizer.scm: 1537 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_9917(t3,t1,t2,((C_word*)t0)[2]);}

/* a10038 in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10039,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10051,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1536 append");
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10049 in a10038 in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1536 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_9917(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9985,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10003,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1529 append");
t6=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10009,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1531 walk");
t7=((C_word*)((C_word*)t0)[5])[1];
f_9917(t7,t5,t6,((C_word*)t0)[3]);}}

/* k10007 in loop in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1532 loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_9985(t4,((C_word*)t0)[2],t2,t3);}

/* k10001 in loop in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_10003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1529 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_9917(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9965 in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9967,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9942(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_9942(t4,t3);}}

/* k9940 in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9942,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9945,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_9945(t5,t4);}
else{
t3=t2;
f_9945(t3,C_SCHEME_UNDEFINED);}}

/* k9943 in k9940 in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9945,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9949 in k9943 in k9940 in k9925 in k9922 in k9919 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9950,3,t0,t1,t2);}
C_trace("optimizer.scm: 1525 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_9917(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9808,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9812,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9814,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1493 ##sys#hash-table-for-each");
t6=C_retrieve(lf[202]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9813 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9814,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[43],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[71],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[108],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9845,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[72],t3))){
t10=t9;
f_9845(t10,C_SCHEME_FALSE);}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9895,a[2]=t8,a[3]=t6,a[4]=t9,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(t4);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9900,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* f_9900 in a9813 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9900,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9893 in a9813 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[10],t1);
if(C_truep(t2)){
if(C_truep((C_word)C_i_assq(lf[92],((C_word*)t0)[5]))){
t3=((C_word*)t0)[4];
f_9845(t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_length(t3);
t5=((C_word*)t0)[4];
f_9845(t5,(C_word)C_eqp(((C_word*)t0)[2],t4));}}
else{
t3=((C_word*)t0)[4];
f_9845(t3,C_SCHEME_FALSE);}}

/* k9843 in a9813 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9845,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1504 alist-cons");
t4=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9847 in k9843 in a9813 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9849,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9853,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1505 alist-cons");
t5=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k9851 in k9847 in k9843 in a9813 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9810 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8540,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9174,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8720,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8543,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9800,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1472 debugging");
t18=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t17,lf[17],lf[200]);}

/* k9798 in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9803,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1473 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8543(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9801 in k9798 in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8543(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8543,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=t3,a[11]=t1,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8714,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* f_8714 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8714,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8709,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_8709 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8709,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8704,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_8704 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8704,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8553,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[51]);
if(C_truep(t2)){
t3=(C_word)C_i_caddr(((C_word*)t0)[14]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8568,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[10])){
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[14]))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=t3,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 1264 get");
t6=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[10],lf[72]);}
else{
t5=t4;
f_8568(2,t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8568(2,t5,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_eqp(t1,lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[14]);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1274 walk");
t6=((C_word*)((C_word*)t0)[4])[1];
f_8543(t6,((C_word*)t0)[12],t4,t5,C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[14]);
t7=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1276 walk");
t8=((C_word*)((C_word*)t0)[4])[1];
f_8543(t8,t5,t6,t7,((C_word*)t0)[11]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8699,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[12],t5,((C_word*)t0)[5]);}}}}

/* a8698 in k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8699,3,t0,t1,t2);}
C_trace("optimizer.scm: 1278 walk");
t3=((C_word*)((C_word*)t0)[2])[1];
f_8543(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8677 in k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1277 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8543(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8651 in k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8653,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_8568(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 1266 get");
t3=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[43]);}
else{
t2=((C_word*)t0)[9];
f_8568(2,t2,C_SCHEME_FALSE);}}}

/* k8597 in k8651 in k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8599,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1267 get");
t3=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[71]);}
else{
t2=((C_word*)t0)[4];
f_8568(2,t2,C_SCHEME_FALSE);}}

/* k8603 in k8597 in k8651 in k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8605,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1268 get");
t3=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[108]);}
else{
t2=((C_word*)t0)[4];
f_8568(2,t2,C_SCHEME_FALSE);}}

/* k8609 in k8603 in k8597 in k8651 in k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8611,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
C_trace("optimizer.scm: 1271 scan");
t9=((C_word*)t0)[4];
f_8720(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_8568(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_8568(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8568(2,t2,C_SCHEME_FALSE);}}

/* k8566 in k8551 in k8548 in k8545 in walk in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1272 transform");
t2=((C_word*)t0)[11];
f_9174(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1273 walk");
t3=((C_word*)((C_word*)t0)[2])[1];
f_8543(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8720(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8720,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8723,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9165,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1357 rec");
t18=((C_word*)t12)[1];
f_8723(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k9163 in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9165,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1358 delete");
t3=C_retrieve(lf[199]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[32]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9170 in k9163 in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1358 lset=");
t2=C_retrieve(lf[198]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[32]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8723,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8727,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9152,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* f_9152 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9152,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t1,tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9147,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9147 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9147,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_8733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9142,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9142 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9142,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8733,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[7]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8772,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=t3,a[6]=((C_word*)t0)[18],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1289 get");
t5=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[14],t3,lf[194]);}
else{
t3=(C_word)C_eqp(t1,lf[51]);
if(C_truep(t3)){
if(C_truep(((C_word*)t0)[13])){
t4=(C_word)C_i_caddr(((C_word*)t0)[19]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8790,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1297 decompose-lambda-list");
t6=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[18],t4,t5);}
else{
t4=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_eqp(t1,lf[82]);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[16])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[19]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[15])[1],t6);
t8=C_mutate(((C_word *)((C_word*)t0)[15])+1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8827,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1306 every");
t10=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[18],t9,((C_word*)t0)[11]);}}
else{
t5=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t5)){
if(C_truep(((C_word*)t0)[8])){
if(C_truep(((C_word*)t0)[7])){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8861,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[11]);
C_trace("optimizer.scm: 1309 scan-used-variables");
t8=C_retrieve(lf[125]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,((C_word*)t0)[9]);}
else{
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8877,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cadr(((C_word*)t0)[19]);
C_trace("optimizer.scm: 1314 estimate-foreign-result-size");
t9=C_retrieve(lf[196]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t7=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8918,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_i_car(((C_word*)t0)[19]);
C_trace("optimizer.scm: 1322 estimate-foreign-result-size");
t10=C_retrieve(lf[196]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}
else{
t8=(C_word)C_eqp(t1,lf[12]);
if(C_truep(t8)){
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9045,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9046,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[174]);
if(C_truep(t9)){
t10=(C_word)C_i_cadddr(((C_word*)t0)[19]);
t11=(C_word)C_eqp(t10,C_fix(0));
if(C_truep(t11)){
t12=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t12=((C_word*)((C_word*)t0)[16])[1];
if(C_truep(t12)){
t13=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[15])[1],t10);
t14=C_mutate(((C_word *)((C_word*)t0)[15])+1,t13);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9080,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1348 every");
t16=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t16))(4,t16,((C_word*)t0)[18],t15,((C_word*)t0)[11]);}}}
else{
t10=(C_word)C_eqp(t1,lf[13]);
if(C_truep(t10)){
t11=(C_word)C_i_car(((C_word*)t0)[11]);
t12=(C_word)C_i_car(((C_word*)t0)[19]);
C_trace("optimizer.scm: 1349 rec");
t13=((C_word*)((C_word*)t0)[10])[1];
f_8723(t13,((C_word*)t0)[18],t11,t12,C_SCHEME_FALSE,((C_word*)t0)[9]);}
else{
t11=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_car(((C_word*)t0)[11]);
t14=(C_word)C_i_car(((C_word*)t0)[19]);
C_trace("optimizer.scm: 1351 rec");
t15=((C_word*)((C_word*)t0)[10])[1];
f_8723(t15,t12,t13,t14,((C_word*)t0)[2],((C_word*)t0)[9]);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1353 every");
t13=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t13))(4,t13,((C_word*)t0)[18],t12,((C_word*)t0)[11]);}}}}}}}}}}}

/* a9136 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9137,3,t0,t1,t2);}
C_trace("optimizer.scm: 1353 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8723(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9111 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9113,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9124,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1352 append");
t4=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9122 in k9111 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1352 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8723(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a9079 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9080,3,t0,t1,t2);}
C_trace("optimizer.scm: 1348 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8723(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* f_9046 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9046,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9045,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9037,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9037 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9037,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9036,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8971,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8999,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9024,a[2]=t6,a[3]=t7,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9025,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t6=t3;
f_8971(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8971(t5,(C_word)C_eqp(t2,((C_word*)t0)[2]));}}

/* f_9025 in k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9025,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9022 in k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9024,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9016,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_8999(t3,C_SCHEME_UNDEFINED);}}

/* f_9016 in k9022 in k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9016,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9013 in k9022 in k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9015,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_8999(t5,t4);}

/* k8997 in k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8971(t3,C_SCHEME_TRUE);}

/* k8969 in k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8971,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1341 every");
t4=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8975 in k8969 in k9034 in k9043 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8976,3,t0,t1,t2);}
C_trace("optimizer.scm: 1341 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8723(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8916 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8918,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8924(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8924(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8924(t7,C_SCHEME_TRUE);}}}

/* k8922 in k8916 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8924(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8924,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8929,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1328 every");
t3=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8928 in k8922 in k8916 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8929,3,t0,t1,t2);}
C_trace("optimizer.scm: 1328 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8723(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8875 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8877,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8883,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8883(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8883(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8883(t7,C_SCHEME_TRUE);}}}

/* k8881 in k8875 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8883,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8888,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1320 every");
t3=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8887 in k8881 in k8875 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8888,3,t0,t1,t2);}
C_trace("optimizer.scm: 1320 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8723(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8859 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8861,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8857,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1311 alist-cons");
t3=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8855 in k8859 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a8826 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8827,3,t0,t1,t2);}
C_trace("optimizer.scm: 1306 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8723(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a8789 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8790,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8806,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1301 append");
t9=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t2,((C_word*)t0)[2]);}

/* k8804 in a8789 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1301 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8723(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k8770 in k8731 in k8728 in k8725 in rec in scan in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9174(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9174,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9178,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=t1,a[8]=t5,a[9]=t6,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9788,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9790,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#make-promise");
t11=*((C_word*)lf[192]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
C_trace("optimizer.scm: 1363 debugging");
t9=C_retrieve(lf[3]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,lf[4],lf[193],t3,t7);}}

/* a9789 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9790,2,t0,t1);}
C_trace("optimizer.scm: 1362 unzip1");
t2=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k9786 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1362 debugging");
t2=C_retrieve(lf[3]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[4],lf[190],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9178,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9774,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* f_9774 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9774,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9182,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_length(t2);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1368 get");
t7=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[5],lf[108]);}

/* k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t5=(C_word)C_i_length(((C_word*)t0)[11]);
t6=(C_word)C_eqp(t5,C_fix(4));
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
t8=t4;
f_9194(t8,(C_word)C_i_listp(t7));}
else{
t7=t4;
f_9194(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9194(t5,C_SCHEME_FALSE);}}

/* k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_9194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9194,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("optimizer.scm: 1372 caaddr");
t4=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[13]);}
else{
C_trace("optimizer.scm: 1470 bomb");
t2=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[10],lf[189],((C_word*)t0)[13]);}}

/* k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
C_trace("optimizer.scm: 1373 cdaddr");
t3=*((C_word*)lf[187]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9203,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
C_trace("optimizer.scm: 1377 node-class-set!");
t5=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[186]);}

/* k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9212,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9737,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9738,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_9738 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9738,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9737,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9448,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_9448(3,t6,((C_word*)t0)[2],t2);}

/* rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9448(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9448,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9729,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_9729 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9729,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9455,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9724,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* f_9724 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9724,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9719,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}

/* f_9719 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9719,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9458,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[12]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(C_word)C_i_cadr(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9473,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9676,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t3=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9702,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1424 alist-cons");
t7=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}
else{
C_trace("for-each");
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[9],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[13]);}}
else{
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[13]);}}}

/* k9700 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9702,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1425 copy-node!");
t5=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k9703 in k9700 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1426 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_9448(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9676 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9676,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9671,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9671 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9671,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9666,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9666 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9666,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9665,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(C_word)C_eqp(((C_word*)t0)[12],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("optimizer.scm: 1391 alist-cons");
t6=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)((C_word*)t0)[11])[1]);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[13]);
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9640,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1416 node-class-set!");
t8=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,((C_word*)t0)[6],lf[184]);}
else{
C_trace("optimizer.scm: 1419 bomb");
t7=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[7],lf[185]);}}}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9638 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1417 node-parameters-set!");
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k9641 in k9638 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1418 node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9492,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9501,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_9501(2,t9,C_SCHEME_UNDEFINED);}
else{
C_trace("optimizer.scm: 1394 quit");
t9=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[180],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[2],tmp=(C_word)a,a+=10,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9616,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}
else{
C_trace("optimizer.scm: 1414 bomb");
t7=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[8],lf[183],((C_word*)t0)[11]);}}}

/* f_9616 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9616,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9615,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_i_length(t4);
t6=(C_word)C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t3;
f_9547(2,t7,C_SCHEME_UNDEFINED);}
else{
C_trace("optimizer.scm: 1405 quit");
t7=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,lf[182],((C_word*)t0)[2]);}}

/* k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1408 node-class-set!");
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],lf[9]);}

/* k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9584,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9592,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9593,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_9593 in k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9593,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9590 in k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(t1);
C_trace("optimizer.scm: 1409 take");
t3=C_retrieve(lf[181]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_fix(1));}

/* k9582 in k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1409 node-parameters-set!");
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9551 in k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9567,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9576,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[179],t4,t5);}

/* f_9576 in k9551 in k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9576,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k9565 in k9551 in k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9567,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
C_trace("optimizer.scm: 1410 node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9554 in k9551 in k9548 in k9545 in k9613 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1413 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_9448(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9499 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1397 node-class-set!");
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[179]);}

/* k9502 in k9499 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
C_trace("optimizer.scm: 1398 node-parameters-set!");
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[3],t3);}

/* k9505 in k9502 in k9499 in k9490 in k9663 in k9474 in k9471 in k9456 in k9453 in k9450 in rec in k9735 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1399 node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9215,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9359,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9428,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9430,tmp=(C_word)a,a+=2,tmp);
C_trace("optimizer.scm: 1447 lset-difference");
t6=C_retrieve(lf[177]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a9429 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9430,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k9426 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9358 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9359,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9420,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_9420 in a9358 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9420,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9364 in a9358 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9369,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_length(t3);
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t2;
f_9369(2,t6,C_SCHEME_UNDEFINED);}
else{
C_trace("optimizer.scm: 1437 quit");
t6=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,lf[176],((C_word*)t0)[2]);}}

/* k9367 in k9364 in a9358 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9369,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9384,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(C_word)C_i_cddr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9393,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t3,lf[174],t4,t7);}

/* f_9393 in k9367 in k9364 in a9358 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9393,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k9382 in k9367 in k9364 in a9358 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9384,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
C_trace("optimizer.scm: 1440 node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9215,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9350,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* f_9350 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9350,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9227,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1452 copy-node!");
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9276,tmp=(C_word)a,a+=2,tmp);
C_trace("optimizer.scm: 1454 fold-right");
t4=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9276,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9336,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9341,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* f_9341 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9341,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9336,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9304,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9328,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_9328 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9328,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9302 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9308,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9323,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9323 in k9302 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9323,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9306 in k9302 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9312,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9318,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9318 in k9306 in k9302 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9318,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9310 in k9306 in k9302 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9313,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9313 in k9310 in k9306 in k9302 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9313,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k9298 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9300,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9292,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t2);}

/* f_9292 in k9298 in k9334 in a9275 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9292,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1463 copy-node!");
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9238,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9237 in k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9238,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9245,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9274,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1467 gensym");
t6=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k9272 in a9237 in k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9274,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1467 node-parameters-set!");
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9243 in a9237 in k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9252,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9262,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9262 in k9243 in a9237 in k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9262,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9250 in k9243 in a9237 in k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9256,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9257,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_9257 in k9250 in k9243 in a9237 in k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9257,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k9254 in k9250 in k9243 in a9237 in k9231 in k9228 in k9225 in k9222 in k9213 in k9210 in k9207 in k9201 in k9198 in k9192 in k9186 in k9180 in k9176 in transform in ##compiler#transform-direct-lambdas! in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_9256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_car(((C_word*)t0)[2],t1));}

/* ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word ab[182],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6201,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6204,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
switch(t6){
case C_fix(1):
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6258,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 854  test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);
case C_fix(2):
if(C_truep(C_retrieve(lf[132]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6404,a[2]=t4,a[3]=t9,a[4]=t2,a[5]=t1,a[6]=t5,a[7]=t8,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 872  test");
t14=t9;
f_6204(t14,t13,t4,lf[41]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[132]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6536,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 890  test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[132]))){
if(C_truep(C_retrieve(lf[136]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(2),t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6586,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 898  test");
t13=t9;
f_6204(t13,t12,t4,lf[42]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6649,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 910  test");
t11=t9;
f_6204(t11,t10,t4,lf[41]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(6):
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[136]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[132]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_eqp(C_fix(1),t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6755,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 926  test");
t15=t9;
f_6204(t15,t14,t4,lf[42]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(7):
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[136]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[132]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t12,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6839,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 938  test");
t16=t9;
f_6204(t16,t15,t4,lf[42]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6913,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t2,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 948  test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6940,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 956  test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[132]))){
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[136]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7109,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 983  test");
t13=t9;
f_6204(t13,t12,t4,lf[42]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[132]))){
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[136]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7203,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1000 test");
t13=t9;
f_6204(t13,t12,t4,lf[42]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7275,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1013 test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7364,a[2]=t4,a[3]=t9,a[4]=t3,a[5]=t8,a[6]=t5,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1026 test");
t11=t9;
f_6204(t11,t10,t4,lf[41]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[132]))){
t10=(C_word)C_i_cadr(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7442,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1037 test");
t14=t9;
f_6204(t14,t13,t4,lf[41]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[132]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(1),t10);
if(C_truep(t11)){
t12=C_retrieve(lf[136]);
t13=(C_truep(t12)?t12:(C_word)C_i_cadddr(t7));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7537,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1055 test");
t15=t9;
f_6204(t15,t14,t4,lf[41]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(16):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[132]))){
t13=(C_word)C_i_not(t10);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t11,t10));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7643,a[2]=t4,a[3]=t9,a[4]=t11,a[5]=t12,a[6]=t8,a[7]=t1,a[8]=t5,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 1076 test");
t16=t9;
f_6204(t16,t15,t4,lf[41]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[132]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7734,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1093 test");
t14=t9;
f_6204(t14,t13,t4,lf[41]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[132]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7814,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1107 test");
t11=t9;
f_6204(t11,t10,t4,lf[41]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7855,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1117 test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(20):
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
t12=(C_truep(t11)?t11:C_retrieve(lf[136]));
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[132]))){
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t10,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8038,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t10,a[6]=t7,a[7]=t1,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1146 test");
t16=t9;
f_6204(t16,t15,t4,lf[42]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8124,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1164 test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(22):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[132]))){
t13=(C_word)C_eqp(t11,t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8320,a[2]=t4,a[3]=t9,a[4]=t12,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1198 test");
t15=t9;
f_6204(t15,t14,t4,lf[41]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[132]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8401,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=t1,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1219 test");
t11=t9;
f_6204(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
default:
C_trace("optimizer.scm: 1239 bomb");
t10=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t1,lf[171]);}}

/* k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8404,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_8404(2,t3,t1);}
else{
C_trace("optimizer.scm: 1219 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8404,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8424,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8433,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1225 varnode");
t10=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8437,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t2,t3,t4);}

/* a8444 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8445,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8453,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8459,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_8459(t9,t4,t3,t5);}

/* loop in a8444 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_8459(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8459,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8479,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
C_trace("optimizer.scm: 845  varnode");
t6=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6226,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_6226(t8,(C_word)C_eqp(lf[23],t7));}
else{
t7=t6;
f_6226(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8508,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
C_trace("optimizer.scm: 1237 loop");
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k8506 in loop in a8444 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8508,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6224 in loop in a8444 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_6226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 846  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
C_trace("optimizer.scm: 847  qnode");
t2=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8477 in loop in a8444 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8483,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1235 loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_8459(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k8481 in k8477 in loop in a8444 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8483,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8451 in a8444 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1228 append");
t2=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8438 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8439,2,t0,t1);}
C_trace("optimizer.scm: 1227 split-at");
t2=C_retrieve(lf[80]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8435 in k8431 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1224 cons*");
t2=C_retrieve(lf[151]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8422 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8425,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_8425 in k8422 in k8402 in k8399 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8425,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8318 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8323(2,t3,t1);}
else{
C_trace("optimizer.scm: 1198 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k8321 in k8318 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8323,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[136]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8348,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[141]),lf[146]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8367,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1206 fifth");
t7=C_retrieve(lf[168]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8375,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t4,lf[82],t7,((C_word*)t0)[3]);}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8375 in k8321 in k8318 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8375,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8365 in k8321 in k8318 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8367,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8359,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[134],t2,((C_word*)t0)[2]);}

/* f_8359 in k8365 in k8321 in k8318 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8359,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8346 in k8321 in k8318 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8348,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8340,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[169],t2);}

/* f_8340 in k8346 in k8321 in k8318 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8340,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8127,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_8127(2,t3,t1);}
else{
C_trace("optimizer.scm: 1164 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8127,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8133,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1166 fifth");
t4=C_retrieve(lf[168]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[136]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8142,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8249,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1170 remove");
t6=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a8248 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8249,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8276,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8277,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8277 in a8248 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8277,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8274 in a8248 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8276,2,t0,t1);}
t2=(C_word)C_eqp(lf[23],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8268,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8268 in k8274 in a8248 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8268,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8265 in k8274 in a8248 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1175 qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8178,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[6],lf[12],lf[166],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8202,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1183 fold-inner");
t5=C_retrieve(lf[162]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t1);}}}

/* a8203 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8204,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[141]),lf[146]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8223,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[134],t5,t6);}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8239,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[82],t5,t6);}}

/* f_8239 in a8203 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8239,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_8223 in a8203 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8223,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8200 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8202,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8194,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[167],t2);}

/* f_8194 in k8200 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8194,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_8178 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8178,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8162 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8164,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8156,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[165],t2);}

/* f_8156 in k8162 in k8140 in k8131 in k8125 in k8122 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8156,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8041,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8041(2,t3,t1);}
else{
C_trace("optimizer.scm: 1146 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8041,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8057,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8065,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t5,t6,t7);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8081 in k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8082,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8094,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1154 qnode");
t6=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k8092 in a8081 in k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8094,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1153 append");
t3=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8071 in k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8072,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1152 split-at");
t3=C_retrieve(lf[80]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k8063 in k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8066,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[134],((C_word*)t0)[2],t1);}

/* f_8066 in k8063 in k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8066,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k8055 in k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8057,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8049,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[164],t2);}

/* f_8049 in k8055 in k8039 in k8036 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_8049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8049,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7858(2,t3,t1);}
else{
C_trace("optimizer.scm: 1117 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[136]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7867,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7964,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1121 remove");
t6=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7963 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7964,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7991,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7992,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7992 in a7963 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7992,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7989 in a7963 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7991,2,t0,t1);}
t2=(C_word)C_eqp(lf[23],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7983,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_7983 in k7989 in a7963 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7983,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7980 in k7989 in a7963 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7867,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1126 qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7903,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],lf[12],lf[160],t4);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[141]),lf[146]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7936,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1134 fold-inner");
t7=C_retrieve(lf[162]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a7937 in k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7938,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7951,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[134],t4,t5);}

/* f_7951 in a7937 in k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7951,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7934 in k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7936,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7928,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[161],t2);}

/* f_7928 in k7934 in k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7928,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_7903 in k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7903,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7887 in k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7889,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7881,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[159],t2);}

/* f_7881 in k7887 in k7865 in k7856 in k7853 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7881,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7812 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7817,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_7817(2,t3,t1);}
else{
C_trace("optimizer.scm: 1107 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k7815 in k7812 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7817,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1108 qnode");
t4=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7831 in k7815 in k7812 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7833,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7825,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[158],t2);}

/* f_7825 in k7831 in k7815 in k7812 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7825,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7732 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7737(2,t3,t1);}
else{
C_trace("optimizer.scm: 1093 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k7735 in k7732 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7737,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7753,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[136]))){
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=t3;
f_7769(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_7769(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7767 in k7735 in k7732 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_7769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7769,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[4]):(C_word)C_i_cadr(((C_word*)t0)[4]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7758,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[134],t3,((C_word*)t0)[2]);}

/* f_7758 in k7767 in k7735 in k7732 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7758,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7751 in k7735 in k7732 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7753,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7745,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[157],t2);}

/* f_7745 in k7751 in k7735 in k7732 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7745,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7641 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_7646(2,t3,t1);}
else{
C_trace("optimizer.scm: 1076 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k7644 in k7641 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7646,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[136]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7671,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t7)){
t8=t6;
f_7688(t8,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=t6;
f_7688(t9,(C_word)C_fixnum_times(((C_word*)t0)[2],t8));}
else{
t8=t6;
f_7688(t8,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7686 in k7644 in k7641 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_7688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7688,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7676,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[82],t2,((C_word*)t0)[2]);}

/* f_7676 in k7686 in k7644 in k7641 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7676,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7669 in k7644 in k7641 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7671,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7663,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[156],t2);}

/* f_7663 in k7669 in k7644 in k7641 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7663,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7535 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7540(2,t3,t1);}
else{
C_trace("optimizer.scm: 1056 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k7538 in k7535 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7540,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[141]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7557,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1059 varnode");
t9=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[141]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7588,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[4],lf[12],lf[155],t6);}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7588 in k7538 in k7535 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7588,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7564 in k7538 in k7535 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1059 cons*");
t2=C_retrieve(lf[151]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7555 in k7538 in k7535 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7558,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_7558 in k7555 in k7538 in k7535 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7558,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7440 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7445,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7445(2,t3,t1);}
else{
C_trace("optimizer.scm: 1038 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k7443 in k7440 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7445,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[141]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[136]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(C_retrieve(lf[136]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7481,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,lf[134],t8,((C_word*)t0)[2]);}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7481 in k7443 in k7440 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7481,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7474 in k7443 in k7440 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7476,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7468,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[154],t2);}

/* f_7468 in k7474 in k7443 in k7440 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7468,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7362 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7367,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_7367(2,t3,t1);}
else{
C_trace("optimizer.scm: 1026 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k7365 in k7362 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7367,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[136]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7386,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_7386(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_7386(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7384 in k7365 in k7362 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_7386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7386,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7390,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7404,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[153],t4,C_SCHEME_END_OF_LIST);}

/* f_7404 in k7384 in k7365 in k7362 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7404,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7397 in k7384 in k7365 in k7362 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1030 cons*");
t2=C_retrieve(lf[151]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7388 in k7384 in k7365 in k7362 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7391,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_7391 in k7388 in k7384 in k7365 in k7362 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7391,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7273 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7278(2,t3,t1);}
else{
C_trace("optimizer.scm: 1013 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k7276 in k7273 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7278,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[136]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7310,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],lf[12],lf[152],t7);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7325,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7334,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1020 varnode");
t12=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7332 in k7276 in k7273 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1020 cons*");
t2=C_retrieve(lf[151]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7323 in k7276 in k7273 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7326,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_7326 in k7323 in k7276 in k7273 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7326,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_7310 in k7276 in k7273 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7310,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7201 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7206,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7206(2,t3,t1);}
else{
C_trace("optimizer.scm: 1000 test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k7204 in k7201 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7206,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7218(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_7218(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7216 in k7204 in k7201 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_7218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7218,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7229,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1005 varnode");
t7=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7236 in k7216 in k7204 in k7201 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1005 cons*");
t2=C_retrieve(lf[151]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7227 in k7216 in k7204 in k7201 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7230,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_7230 in k7227 in k7216 in k7204 in k7201 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7230,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7107 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7109,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7138,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 987  varnode");
t7=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7136 in k7107 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7138,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 990  qnode");
t5=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k7144 in k7136 in k7107 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7150,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 992  varnode");
t5=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}
else{
t4=t2;
f_7150(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k7148 in k7144 in k7136 in k7107 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7150,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7130,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t2);}

/* f_7130 in k7148 in k7144 in k7136 in k7107 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7130,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6940,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 958  qnode");
t4=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[136]))){
t4=(C_word)C_eqp(C_retrieve(lf[141]),lf[150]);
t5=t3;
f_6968(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6968(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_6968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6968,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6971(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[141]),lf[146]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_6971(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[141]),lf[149]);
t6=t2;
f_6971(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[3]):C_SCHEME_FALSE));}}}

/* k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_6971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6971,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7049,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7048 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7049,3,t0,t1,t2);}
C_trace("optimizer.scm: 962  gensym");
t3=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("map");
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[45]),t1);}

/* k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6982,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7003,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_retrieve(lf[141]),lf[146]);
t5=(C_truep(t4)?(C_word)C_i_car(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7019,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7021,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 974  fold-boolean");
t9=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,t8,t1);}

/* a7020 in k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7021,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7030,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[134],((C_word*)t0)[2],t4);}

/* f_7030 in a7020 in k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7030,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7017 in k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7008,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[147],t2);}

/* f_7008 in k7017 in k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7008,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k7001 in k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 964  fold-right");
t2=C_retrieve(lf[118]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6981 in k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6982,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6995,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[9],t5,t6);}

/* f_6995 in a6981 in k6975 in k6972 in k6969 in k6966 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6995,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6960 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6962,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6954,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[145],t2);}

/* f_6954 in k6960 in k6938 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6954,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6911 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_6916(2,t3,t1);}
else{
C_trace("optimizer.scm: 949  test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k6914 in k6911 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6837 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6842(2,t3,t1);}
else{
C_trace("optimizer.scm: 938  test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k6840 in k6837 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6866,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 943  qnode");
t8=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6877 in k6840 in k6837 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6879,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 942  append");
t3=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6864 in k6840 in k6837 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6867,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[134],((C_word*)t0)[2],t1);}

/* f_6867 in k6864 in k6840 in k6837 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6867,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6856 in k6840 in k6837 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6858,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6850,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[144],t2);}

/* f_6850 in k6856 in k6840 in k6837 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6850,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6753 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6771,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6788,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6793,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[134],t7,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6793 in k6753 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6793,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6786 in k6753 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6788,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6780,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[134],((C_word*)t0)[2],t2);}

/* f_6780 in k6786 in k6753 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6780,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6769 in k6753 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6771,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6763,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[143],t2);}

/* f_6763 in k6769 in k6753 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6763,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6647 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6652,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6652(2,t3,t1);}
else{
C_trace("optimizer.scm: 911  test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k6650 in k6647 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6652,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[141])));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_car(((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6707,a[2]=t9,a[3]=t7,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 919  qnode");
t13=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,t12);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6705 in k6650 in k6647 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6707,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6695,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[134],((C_word*)t0)[2],t2);}

/* f_6695 in k6705 in k6650 in k6647 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6695,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6684 in k6650 in k6647 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6686,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6678,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[142],t2);}

/* f_6678 in k6684 in k6650 in k6647 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6678,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6584 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6606,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("optimizer.scm: 900  varnode");
t6=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6604 in k6584 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6606,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 903  qnode");
t5=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k6612 in k6604 in k6584 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6614,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6598,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t3);}

/* f_6598 in k6612 in k6604 in k6584 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6598,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6534 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_6539(2,t3,t1);}
else{
C_trace("optimizer.scm: 890  test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k6537 in k6534 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("optimizer.scm: 891  varnode");
t4=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6553 in k6537 in k6534 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6547,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[140],t2);}

/* f_6547 in k6553 in k6537 in k6534 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6547,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_6407(2,t3,t1);}
else{
C_trace("optimizer.scm: 872  test");
t3=((C_word*)t0)[3];
f_6204(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[136]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6441,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6499,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6500,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}
else{
t8=t7;
f_6441(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6500 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6500,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6497 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6499,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6482,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6491,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_6441(t3,C_SCHEME_FALSE);}}

/* f_6491 in k6497 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6491,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6488 in k6497 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
C_trace("optimizer.scm: 882  get");
t3=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,lf[139]);}

/* k6480 in k6497 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6441(t2,(C_word)C_eqp(lf[138],t1));}

/* k6439 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_6441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6441,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6449,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[134],t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6461,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],lf[134],t3,((C_word*)t0)[3]);}}

/* f_6461 in k6439 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6461,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_6449 in k6439 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6449,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6436 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6430,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[137],t2);}

/* f_6430 in k6436 in k6405 in k6402 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6430,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6370,a[2]=t6,a[3]=t7,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6371,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t6=t2;
f_6261(2,t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6371 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6371,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6362,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[4];
f_6261(2,t3,C_SCHEME_FALSE);}}

/* f_6362 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6362,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6359 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6353,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_6261(2,t3,C_SCHEME_FALSE);}}

/* f_6353 in k6359 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6353,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6341 in k6359 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6348,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_6348 in k6341 in k6359 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6348,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6345 in k6341 in k6359 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6347,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[4],t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 861  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6261(2,t2,C_SCHEME_FALSE);}}

/* k6337 in k6345 in k6341 in k6359 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6331,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[135],t2);}

/* f_6331 in k6337 in k6345 in k6341 in k6359 in k6368 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6331,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6259 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6261,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[132]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6288,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[134],t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* f_6288 in k6259 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6288,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k6281 in k6259 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6283,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6275,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[133],t2);}

/* f_6275 in k6281 in k6259 in k6256 in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6275,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* test in ##compiler#simplify-named-call in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_6204(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6204,NULL,4,t0,t1,t2,t3);}
C_trace("optimizer.scm: 843  get");
t4=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#rewrite in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6181r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6181r(t0,t1,t2,t3);}}

static void C_ccall f_6181r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6185,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 839  ##sys#hash-table-ref");
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[129]),t2);}

/* k6183 in ##compiler#rewrite in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6185,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("optimizer.scm: 840  append");
t5=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}

/* k6193 in k6183 in ##compiler#rewrite in k6177 in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 840  ##sys#hash-table-set!");
t2=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[129]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5821,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5825,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 751  map");
t8=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,*((C_word*)lf[128]+1),t2,t3);}

/* k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 762  for-each");
t5=*((C_word*)lf[126]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6165 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6166,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6175,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 763  scan-used-variables");
t6=C_retrieve(lf[125]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}

/* k6173 in a6165 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 763  alist-cons");
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6169 in a6165 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_trace("for-each");
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a6107 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6108,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6118,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 772  filter");
t5=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a6139 in a6107 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6140,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 773  find-path");
t5=((C_word*)t0)[2];
f_5827(t5,t4,((C_word*)t0)[3],t2);}}

/* k6151 in a6139 in a6107 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 773  find-path");
t2=((C_word*)t0)[5];
f_5827(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6116 in a6107 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6122,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 775  gensym");
t4=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6132 in k6116 in a6107 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("optimizer.scm: 775  alist-cons");
t3=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k6120 in k6116 in a6107 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6122,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
C_trace("optimizer.scm: 776  append");
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k6124 in k6120 in k6116 in a6107 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5875,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5878,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("for-each");
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6049,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
C_trace("optimizer.scm: 785  append-map");
t7=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* a6091 in a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6092,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6098,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 786  filter");
t4=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a6097 in a6091 in a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6098,3,t0,t1,t2);}
C_trace("optimizer.scm: 786  find-path");
t3=((C_word*)t0)[3];
f_5827(t3,t1,((C_word*)t0)[2],t2);}

/* k6054 in a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6064,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6066,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 791  filter-map");
t5=C_retrieve(lf[122]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a6065 in k6054 in a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6066,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6079,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
C_trace("optimizer.scm: 792  lset<=");
t6=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,*((C_word*)lf[32]+1),t5,((C_word*)t0)[2]);}}

/* k6077 in a6065 in k6054 in a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k6062 in k6054 in a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 789  alist-cons");
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6058 in k6054 in a6048 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 798  topological-sort");
t3=C_retrieve(lf[120]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[32]+1));}

/* k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 803  fold");
t6=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5901,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5914,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_5914(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_5914(t9,C_SCHEME_FALSE);}}

/* k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5926,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5943,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 817  fold-right");
t5=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5974 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5975,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6021,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 820  gensym");
t5=C_retrieve(lf[77]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6019 in a5974 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6021,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5996,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t5=(C_word)C_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6005,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t3,lf[13],t4,t7);}

/* f_6005 in k6019 in a5974 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6005,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k5994 in k6019 in a5974 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5996,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5988,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t2);}

/* f_5988 in k5994 in k6019 in a5974 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5988,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k5971 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 812  fold-right");
t2=C_retrieve(lf[118]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5942 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5943,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5964,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5965,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_5965 in a5942 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5965,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k5962 in a5942 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5956,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t2);}

/* f_5956 in k5962 in a5942 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5956,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_5926 in k5912 in a5900 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5926,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k5882 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5884,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5893,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 829  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[117],((C_word*)((C_word*)t0)[3])[1]);}
else{
C_trace("optimizer.scm: 831  values");
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k5891 in k5882 in k5879 in k5876 in k5873 in k5870 in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 830  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5827(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5827,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5833,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5833(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5833,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5857,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 759  any");
t9=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,t8,t5);}}}

/* a5856 in find in find-path in k5823 in ##compiler#reorganize-recursive-bindings in k5817 in k5814 in k5811 in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5857,3,t0,t1,t2);}
C_trace("optimizer.scm: 759  find");
t3=((C_word*)((C_word*)t0)[3])[1];
f_5833(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_5806r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5806r(t0,t1,t2,t3);}}

static void C_ccall f_5806r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_trace("optimizer.scm: 530  ##sys#hash-table-set!");
t4=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,*((C_word*)lf[19]+1),t2,t3);}

/* ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5243,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5246,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5250,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5257,a[2]=t3,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 443  debugging");
t11=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,lf[17],lf[113]);}

/* k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5543,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 446  test");
t4=((C_word*)t0)[3];
f_5250(t4,t3,lf[112],lf[42]);}

/* k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5801,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 482  test");
t4=((C_word*)t0)[3];
f_5250(t4,t3,lf[112],lf[108]);}
else{
t2=((C_word*)t0)[2];
f_5260(2,t2,C_SCHEME_UNDEFINED);}}

/* k5799 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5548,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5793,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_5793 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5793,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cadr(t1);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5788,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* f_5788 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5788,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5783,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5561,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5779,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 452  test");
t5=((C_word*)t0)[2];
f_5250(t5,t4,t2,lf[72]);}

/* k5777 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5561(2,t2,C_SCHEME_FALSE);}
else{
C_trace("optimizer.scm: 452  test");
t2=((C_word*)t0)[3];
f_5250(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[43]);}}

/* k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5564,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 453  test");
t3=((C_word*)t0)[3];
f_5250(t3,t2,((C_word*)t0)[2],lf[71]);}

/* k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[5]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5756,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5757,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
t7=t2;
f_5570(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5570(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5570(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5570(t3,C_SCHEME_FALSE);}}

/* f_5757 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5757,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5754 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5570(t2,(C_word)C_eqp(lf[51],t1));}

/* k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5570,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5730,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5730 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5730,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5729,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5721,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_5721 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5721,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5720,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5712,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_5712 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5712,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=t2;
f_5585(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_5585(t3,C_SCHEME_FALSE);}}

/* k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5585,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5591,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 464  test");
t4=((C_word*)t0)[2];
f_5250(t4,t3,t2,lf[71]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5693,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t2;
f_5597(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5597(t3,C_SCHEME_FALSE);}}

/* f_5693 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5693,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5690 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5597(t2,(C_word)C_eqp(lf[8],t1));}

/* k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5597,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5675,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5675 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5675,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5674,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5665,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5666,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_5666 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5666,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5663 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5657,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_5606(t3,C_SCHEME_FALSE);}}

/* f_5657 in k5663 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5657,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5654 in k5663 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_5606(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k5604 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5606,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 476  node-parameters-set!");
t5=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[111]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5611 in k5604 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5616,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 477  node-subexpressions-set!");
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k5614 in k5611 in k5604 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 480  reverse");
t6=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k5632 in k5614 in k5611 in k5604 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("optimizer.scm: 478  node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5617 in k5614 in k5611 in k5604 in k5672 in k5595 in k5589 in k5583 in k5577 in k5718 in k5727 in k5568 in k5562 in k5559 in k5781 in k5553 in a5547 in k5541 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 481  touch");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5246(((C_word*)t0)[2]));}

/* k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[109]));}

/* a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5274,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5281,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 487  test");
t4=((C_word*)t0)[3];
f_5250(t4,t3,t2,lf[42]);}

/* k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5281,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5537,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 520  test");
t4=((C_word*)t0)[4];
f_5250(t4,t3,((C_word*)t0)[5],lf[108]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5535 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5286,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5529,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_5529 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5529,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadr(t1);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5524,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* f_5524 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5524,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5519,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5299,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 493  test");
t4=((C_word*)t0)[3];
f_5250(t4,t3,t2,lf[71]);}

/* k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5302,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 494  test");
t4=((C_word*)t0)[4];
f_5250(t4,t3,((C_word*)t0)[2],lf[72]);}

/* k5513 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5302(2,t2,C_SCHEME_FALSE);}
else{
C_trace("optimizer.scm: 494  test");
t2=((C_word*)t0)[3];
f_5250(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[43]);}}

/* k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5308,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5501,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}
else{
t3=t2;
f_5308(t3,C_SCHEME_FALSE);}}

/* f_5501 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5501,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5498 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(C_word)C_eqp(lf[51],t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
t3=(C_word)C_i_length(((C_word*)t0)[5]);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5482,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 499  any");
t8=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}
else{
t5=((C_word*)t0)[4];
f_5308(t5,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[4];
f_5308(t3,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[4];
f_5308(t3,C_SCHEME_FALSE);}}

/* a5483 in k5498 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5484,3,t0,t1,t2);}
C_trace("optimizer.scm: 499  expression-has-side-effects?");
t3=C_retrieve(lf[69]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k5480 in k5498 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5308(t2,(C_word)C_i_not(t1));}

/* k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5308,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5456,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5456 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5456,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5447,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_5447 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5447,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5433,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5434,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t3;
f_5320(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_5320(t4,C_SCHEME_FALSE);}}

/* f_5434 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5431 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5320(t2,(C_word)C_eqp(lf[8],t1));}

/* k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5320,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5326,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 507  test");
t4=((C_word*)t0)[2];
f_5250(t4,t3,t2,lf[71]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5413,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_5413 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5413,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5412,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5399,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5400,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t6=t3;
f_5335(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_5335(t4,C_SCHEME_FALSE);}}

/* f_5400 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5400,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5397 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5391,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_5335(t3,C_SCHEME_FALSE);}}

/* f_5391 in k5397 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5391,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5388 in k5397 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_5335(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k5333 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5335,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5363,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5363 in k5333 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5363,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5336 in k5333 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 516  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[107],((C_word*)t0)[2]);}

/* k5339 in k5336 in k5333 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 517  node-parameters-set!");
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[106]);}

/* k5342 in k5339 in k5336 in k5333 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5362,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 518  qnode");
t5=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k5360 in k5342 in k5339 in k5336 in k5333 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5362,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
C_trace("optimizer.scm: 518  node-subexpressions-set!");
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5345 in k5342 in k5339 in k5336 in k5333 in k5410 in k5324 in k5318 in k5444 in k5453 in k5306 in k5300 in k5297 in k5517 in k5291 in a5285 in k5279 in a5273 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 519  touch");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5246(((C_word*)t0)[2]));}

/* k5261 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 523  debugging");
t4=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[4],lf[103],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5266(2,t4,C_SCHEME_UNDEFINED);}}

/* k5264 in k5261 in k5258 in k5255 in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5250(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5250,NULL,4,t0,t1,t2,t3);}
C_trace("optimizer.scm: 441  get");
t4=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static C_word C_fcall f_5246(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[70],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3570,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3573,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3579,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3594,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3613,a[2]=t3,a[3]=t21,a[4]=t19,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3710,a[2]=t26,a[3]=t16,a[4]=t17,a[5]=t18,a[6]=t24,a[7]=t19,a[8]=t7,a[9]=t21,a[10]=t15,tmp=(C_word)a,a+=11,tmp));
t30=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3958,a[2]=t11,a[3]=t3,a[4]=t28,a[5]=t24,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t19,tmp=(C_word)a,a+=10,tmp));
t31=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5123,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5147,a[2]=t24,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 409  perform-pre-optimization!");
t33=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t33))(4,t33,t32,t2,t3);}

/* k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5147,2,t0,t1);}
if(C_truep(t1)){
C_trace("optimizer.scm: 410  values");
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 412  debugging");
t3=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[17],lf[101]);}}

/* k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5153,2,t0,t1);}
t2=C_set_block_item(lf[20] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5157,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 414  walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_3710(3,t4,t3,((C_word*)t0)[2]);}

/* k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
C_trace("optimizer.scm: 415  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[100],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5160(2,t3,C_SCHEME_UNDEFINED);}}

/* k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5196,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[20])))){
C_trace("optimizer.scm: 416  debugging");
t4=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[4],lf[99]);}
else{
t4=t3;
f_5196(2,t4,C_SCHEME_FALSE);}}

/* k5194 in k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5201,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[20]));}
else{
t2=((C_word*)t0)[2];
f_5163(2,t2,C_SCHEME_UNDEFINED);}}

/* a5200 in k5194 in k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5201,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
C_trace("optimizer.scm: 419  print*");
t5=*((C_word*)lf[98]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_make_character(9),t4);}

/* k5203 in a5200 in k5194 in k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 421  print");
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_make_character(9),t3);}
else{
C_trace("optimizer.scm: 422  newline");
t3=*((C_word*)lf[97]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[2]);}}

/* k5161 in k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 424  debugging");
t4=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[4],lf[95],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5166(2,t4,C_SCHEME_UNDEFINED);}}

/* k5164 in k5161 in k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 425  debugging");
t4=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[4],lf[94],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5169(2,t4,C_SCHEME_UNDEFINED);}}

/* k5167 in k5164 in k5161 in k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 426  debugging");
t4=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[4],lf[93],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5172(2,t4,C_SCHEME_UNDEFINED);}}

/* k5170 in k5167 in k5164 in k5161 in k5158 in k5155 in k5151 in k5145 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 427  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5123,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5127,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("map");
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5125 in walk-generic in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5133,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 405  every");
t3=C_retrieve(lf[39]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1);}

/* k5131 in k5125 in walk-generic in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5133,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5137,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_5137 in k5131 in k5125 in walk-generic in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5137,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3958(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3958,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5117,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_5117 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5117,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5112,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_5112 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5112,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5107,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_5107 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5107,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[7]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3983(t7,((C_word*)t0)[9],t3);}
else{
t3=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4064,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 240  test");
t6=((C_word*)t0)[11];
f_3573(t6,t5,t4,lf[47]);}
else{
t4=(C_word)C_eqp(t1,lf[51]);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4127,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[13]);
C_trace("optimizer.scm: 250  test");
t8=((C_word*)t0)[11];
f_3573(t8,t6,t7,lf[60]);}
else{
t5=(C_word)C_eqp(t1,lf[12]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4305,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[13],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4983,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t6=(C_word)C_eqp(t1,lf[13]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[13]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[13],a[7]=t7,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 388  test");
t9=((C_word*)t0)[11];
f_3573(t9,t8,t7,lf[49]);}
else{
C_trace("optimizer.scm: 401  walk-generic");
t7=((C_word*)((C_word*)t0)[5])[1];
f_5123(t7,((C_word*)t0)[9],((C_word*)t0)[4],t1,((C_word*)t0)[13],((C_word*)t0)[7]);}}}}}}

/* k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_5005(2,t3,t1);}
else{
C_trace("optimizer.scm: 388  test");
t3=((C_word*)t0)[2];
f_3573(t3,t2,((C_word*)t0)[7],lf[47]);}}

/* k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5005,2,t0,t1);}
if(C_truep(t1)){
t2=f_3609(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5012,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 391  test");
t4=((C_word*)t0)[2];
f_3573(t4,t3,((C_word*)t0)[7],lf[92]);}}

/* k5098 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5100,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5062(t4,t2);}
else{
t4=C_retrieve(lf[90]);
if(C_truep(t4)){
t5=t3;
f_5062(t5,t4);}
else{
if(C_truep(C_retrieve(lf[91]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[91]));
t6=t3;
f_5062(t6,(C_word)C_i_not(t5));}
else{
t5=t3;
f_5062(t5,C_SCHEME_FALSE);}}}}

/* k5060 in k5098 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5062,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 394  test");
t3=((C_word*)t0)[3];
f_3573(t3,t2,((C_word*)t0)[2],lf[71]);}
else{
t2=((C_word*)t0)[6];
f_5022(t2,C_SCHEME_FALSE);}}

/* k5081 in k5060 in k5098 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5083,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5022(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 395  expression-has-side-effects?");
t4=C_retrieve(lf[69]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* k5073 in k5081 in k5060 in k5098 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5022(t2,(C_word)C_i_not(t1));}

/* k5020 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_5022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5022,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3609(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 397  debugging");
t4=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[4],lf[89],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 399  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_3710(3,t4,t2,t3);}}

/* k5050 in k5020 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5044,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[13],((C_word*)t0)[2],t2);}

/* f_5044 in k5050 in k5020 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5044,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k5026 in k5020 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5032,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_5032 in k5026 in k5020 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5032,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_5012 in k5003 in k5000 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5012,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_4983 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4983,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4305,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[7]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4940,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(t1,lf[51]);
if(C_truep(t3)){
if(C_truep((C_word)C_i_car(((C_word*)t0)[6]))){
C_trace("optimizer.scm: 382  walk-generic");
t4=((C_word*)((C_word*)t0)[9])[1];
f_5123(t4,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[13]);}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4970,a[2]=t5,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[13]);}}
else{
C_trace("optimizer.scm: 384  walk-generic");
t4=((C_word*)((C_word*)t0)[9])[1];
f_5123(t4,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[13]);}}}

/* k4968 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4971,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_4971 in k4968 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4971,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* f_4940 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4940,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4939,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4935,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 288  test");
t5=((C_word*)t0)[4];
f_3573(t5,t4,t2,lf[72]);}

/* k4933 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4317(2,t2,C_SCHEME_FALSE);}
else{
C_trace("optimizer.scm: 288  test");
t2=((C_word*)t0)[3];
f_3573(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[43]);}}

/* k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t1,a[13]=t2,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word*)t0)[13],tmp=(C_word)a,a+=17,tmp);
C_trace("optimizer.scm: 290  test");
t4=((C_word*)t0)[4];
f_3573(t4,t3,((C_word*)t0)[10],lf[49]);}

/* k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4362,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[64])))){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4378,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4526,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t3;
f_4378(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4536,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[12])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4920,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4921,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}
else{
t3=t2;
f_4536(t3,C_SCHEME_FALSE);}}}}

/* f_4921 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4921,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4918 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4536(t2,(C_word)C_eqp(lf[51],t1));}

/* k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_4536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4536,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4906,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[13]);}
else{
C_trace("optimizer.scm: 379  walk-generic");
t2=((C_word*)((C_word*)t0)[11])[1];
f_5123(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* f_4906 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4906,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
C_trace("optimizer.scm: 316  decompose-lambda-list");
t4=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4547,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[17],a[4]=t6,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 320  test");
t8=((C_word*)t0)[3];
f_3573(t8,t7,t5,lf[88]);}

/* k4874 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 321  test");
t3=((C_word*)t0)[2];
f_3573(t3,t2,((C_word*)t0)[5],lf[87]);}
else{
t2=((C_word*)t0)[4];
f_4557(t2,C_SCHEME_FALSE);}}

/* k4880 in k4874 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[84])))){
t2=((C_word*)t0)[3];
f_4557(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[85]));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4557(t3,t2);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t4=C_retrieve(lf[86]);
t5=((C_word*)t0)[3];
f_4557(t5,(C_word)C_fixnum_lessp(t3,t4));}}}
else{
t2=((C_word*)t0)[3];
f_4557(t2,C_SCHEME_FALSE);}}

/* k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_4557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4557,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[14]);
C_trace("optimizer.scm: 325  debugging");
t4=C_retrieve(lf[3]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,lf[74],lf[75],((C_word*)t0)[15],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[17],tmp=(C_word)a,a+=20,tmp);
C_trace("optimizer.scm: 330  test");
t3=((C_word*)t0)[4];
f_3573(t3,t2,((C_word*)t0)[13],lf[60]);}}

/* k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
C_trace("optimizer.scm: 332  walk-generic");
t4=((C_word*)((C_word*)t0)[17])[1];
f_5123(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4613(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4771,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[4],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4866,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 354  test");
t4=((C_word*)t0)[6];
f_3573(t4,t3,((C_word*)t0)[2],lf[56]);}}

/* k4864 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_4771(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_4771(t2,C_SCHEME_FALSE);}}

/* k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_4771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4771,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[13]);
t3=(C_word)C_i_length(((C_word*)t0)[12]);
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
C_trace("optimizer.scm: 358  walk-generic");
t4=((C_word*)((C_word*)t0)[11])[1];
f_5123(t4,((C_word*)t0)[10],t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4786,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 360  debugging");
t5=C_retrieve(lf[3]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[4],lf[83],((C_word*)t0)[3],t2);}}
else{
C_trace("optimizer.scm: 378  walk-generic");
t2=((C_word*)((C_word*)t0)[11])[1];
f_5123(t2,((C_word*)t0)[10],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4796 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4797,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4801,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4830,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("optimizer.scm: 371  qnode");
t8=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_length(t3);
t9=(C_word)C_fixnum_times(C_fix(3),t8);
t10=(C_word)C_a_i_list(&a,2,lf[81],t9);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4844,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,lf[82],t10,t3);}}

/* f_4844 in a4796 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4844,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k4828 in a4796 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 367  append");
t3=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4820 in a4796 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("map");
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4807 in a4796 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4810,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_4810 in k4807 in a4796 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4810,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k4799 in a4796 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a4790 in k4784 in k4769 in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
C_trace("optimizer.scm: 361  split-at");
t2=C_retrieve(lf[80]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_4613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4613,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3609(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 339  append-reverse");
t11=C_retrieve(lf[76]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
C_trace("optimizer.scm: 340  test");
t10=((C_word*)t0)[2];
f_3573(t10,t8,t9,lf[52]);}}

/* k4650 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4652,2,t0,t1);}
if(C_truep(t1)){
t2=f_3609(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
C_trace("optimizer.scm: 342  debugging");
t5=C_retrieve(lf[3]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,lf[4],lf[79],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
C_trace("optimizer.scm: 350  loop");
t7=((C_word*)((C_word*)t0)[6])[1];
f_4613(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k4656 in k4650 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
C_trace("optimizer.scm: 343  expression-has-side-effects?");
t4=C_retrieve(lf[69]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k4662 in k4656 in k4650 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 346  gensym");
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[78]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 349  loop");
t5=((C_word*)((C_word*)t0)[4])[1];
f_4613(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k4706 in k4662 in k4656 in k4650 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("optimizer.scm: 347  walk");
t5=((C_word*)((C_word*)t0)[2])[1];
f_3710(3,t5,t3,t4);}

/* k4682 in k4706 in k4662 in k4656 in k4650 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4688,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 348  loop");
t6=((C_word*)((C_word*)t0)[3])[1];
f_4613(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4686 in k4682 in k4706 in k4662 in k4656 in k4650 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4688,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4676,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t2);}

/* f_4676 in k4686 in k4682 in k4706 in k4662 in k4656 in k4650 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4676,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k4644 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("map");
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4631 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4634,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2],t1);}

/* f_4634 in k4631 in loop in k4597 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4634,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k4558 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 326  check-signature");
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4561 in k4558 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 327  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[73],((C_word*)t0)[2]);}

/* k4564 in k4561 in k4558 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
t2=f_3609(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4585,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_4585 in k4564 in k4561 in k4558 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4585,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k4582 in k4564 in k4561 in k4558 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
C_trace("optimizer.scm: 329  inline-lambda-bindings");
t3=C_retrieve(lf[61]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k4574 in k4564 in k4561 in k4558 in k4555 in a4546 in k4537 in k4534 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 329  walk");
t2=((C_word*)((C_word*)t0)[3])[1];
f_3710(3,t2,((C_word*)t0)[2],t1);}

/* f_4526 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4526,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4517,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
f_4378(2,t3,C_SCHEME_FALSE);}}

/* f_4517 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4517,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4512,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 301  test");
t5=((C_word*)t0)[2];
f_3573(t5,t4,t2,lf[72]);}
else{
t3=((C_word*)t0)[7];
f_4378(2,t3,C_SCHEME_FALSE);}}

/* k4510 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4399(2,t2,C_SCHEME_FALSE);}
else{
C_trace("optimizer.scm: 301  test");
t2=((C_word*)t0)[3];
f_3573(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[43]);}}

/* k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4498,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[7];
f_4378(2,t2,C_SCHEME_FALSE);}}

/* f_4498 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4498,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4417,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(t2);
C_trace("optimizer.scm: 304  test");
t5=((C_word*)t0)[2];
f_3573(t5,t3,t4,lf[52]);}
else{
t3=((C_word*)t0)[7];
f_4378(2,t3,C_SCHEME_FALSE);}}

/* k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4420(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 305  test");
t5=((C_word*)t0)[2];
f_3573(t5,t3,t4,lf[71]);}}

/* k4483 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4420(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4477,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 306  test");
t4=((C_word*)t0)[2];
f_3573(t4,t2,t3,lf[70]);}}

/* k4475 in k4483 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4420(t2,(C_word)C_i_not(t1));}

/* k4418 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_4420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4420,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 307  any");
t5=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_4378(2,t2,C_SCHEME_FALSE);}}

/* a4455 in k4418 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4456,3,t0,t1,t2);}
C_trace("##compiler#expression-has-side-effects?");
t3=C_retrieve(lf[69]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k4452 in k4418 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4378(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 308  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[67],lf[68],((C_word*)t0)[2]);}}

/* k4427 in k4452 in k4418 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4446,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_4446 in k4427 in k4452 in k4418 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4446,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k4443 in k4427 in k4452 in k4418 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4437,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[65],t2);}

/* f_4437 in k4443 in k4427 in k4452 in k4418 in k4415 in k4495 in k4397 in k4514 in k4523 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4437,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* k4376 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
C_trace("optimizer.scm: 312  walk-generic");
t2=((C_word*)((C_word*)t0)[6])[1];
f_5123(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_4362 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4362,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4327 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 293  check-signature");
t4=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k4333 in k4327 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 294  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[62],((C_word*)t0)[2]);}

/* k4336 in k4333 in k4327 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=f_3609(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4357,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_4357 in k4336 in k4333 in k4327 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4357,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k4354 in k4336 in k4333 in k4327 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
C_trace("optimizer.scm: 296  inline-lambda-bindings");
t3=C_retrieve(lf[61]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4346 in k4336 in k4333 in k4327 in k4324 in k4315 in k4937 in k4303 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 296  walk");
t2=((C_word*)((C_word*)t0)[3])[1];
f_3710(3,t2,((C_word*)t0)[2],t1);}

/* k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4127,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 251  decompose-lambda-list");
t3=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
C_trace("optimizer.scm: 266  test");
t4=((C_word*)t0)[11];
f_3573(t4,t2,t3,lf[56]);}}

/* k4224 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4231,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 267  decompose-lambda-list");
t3=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
C_trace("optimizer.scm: 279  walk-generic");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5123(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a4230 in k4224 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4231,5,t0,t1,t2,t3,t4);}
t5=f_3609(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4238,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 271  debugging");
t7=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[4],lf[59],t4);}

/* k4236 in a4230 in k4224 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
C_trace("optimizer.scm: 276  build-lambda-list");
t6=C_retrieve(lf[54]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4272 in k4236 in a4230 in k4224 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4258,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 278  walk");
t6=((C_word*)((C_word*)t0)[2])[1];
f_3710(3,t6,t4,t5);}

/* k4256 in k4272 in k4236 in a4230 in k4224 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4250,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[51],((C_word*)t0)[2],t2);}

/* f_4250 in k4256 in k4272 in k4236 in a4230 in k4224 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4250,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4132,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t5,t6);}

/* a4149 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4150,4,t0,t1,t2,t3);}
t4=f_3609(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 256  debugging");
t6=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[4],lf[57],t2);}

/* k4155 in a4149 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4157,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
C_trace("optimizer.scm: 260  test");
t7=((C_word*)t0)[2];
f_3573(t7,t5,t6,lf[56]);}
else{
t6=t5;
f_4200(2,t6,C_SCHEME_FALSE);}}

/* k4198 in k4155 in a4149 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 261  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[55],((C_word*)t0)[2]);}
else{
C_trace("optimizer.scm: 263  build-lambda-list");
t2=C_retrieve(lf[54]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4201 in k4198 in k4155 in a4149 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
C_trace("optimizer.scm: 262  build-lambda-list");
t3=C_retrieve(lf[54]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4191 in k4155 in a4149 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4193,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4177,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 265  walk");
t6=((C_word*)((C_word*)t0)[2])[1];
f_3710(3,t6,t4,t5);}

/* k4175 in k4191 in k4155 in a4149 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4169,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[51],((C_word*)t0)[2],t2);}

/* f_4169 in k4175 in k4191 in k4155 in a4149 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4169,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* a4137 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4144,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 254  partition");
t3=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a4143 in a4137 in a4131 in k4125 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4144,3,t0,t1,t2);}
C_trace("optimizer.scm: 254  test");
t3=((C_word*)t0)[2];
f_3573(t3,t1,t2,lf[52]);}

/* k4062 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_4067(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 241  test");
t4=((C_word*)t0)[3];
f_3573(t4,t3,((C_word*)t0)[2],lf[50]);}}

/* k4094 in k4062 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4067(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 242  test");
t3=((C_word*)t0)[3];
f_3573(t3,t2,((C_word*)t0)[2],lf[49]);}}

/* k4103 in k4094 in k4062 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 242  test");
t3=((C_word*)t0)[3];
f_3573(t3,t2,((C_word*)t0)[2],lf[48]);}
else{
t2=((C_word*)t0)[4];
f_4067(t2,C_SCHEME_FALSE);}}

/* k4110 in k4103 in k4094 in k4062 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4067(t2,(C_word)C_i_not(t1));}

/* k4065 in k4062 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_4067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4067,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3609(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 245  walk");
t6=((C_word*)((C_word*)t0)[4])[1];
f_3710(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k4086 in k4065 in k4062 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4089,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[9],((C_word*)t0)[2],t1);}

/* f_4089 in k4086 in k4065 in k4062 in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4089,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3983(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3983,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 226  test");
t4=((C_word*)t0)[4];
f_3573(t4,t3,t2,lf[47]);}

/* k3985 in replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
if(C_truep(t1)){
C_trace("replace293");
t2=((C_word*)((C_word*)t0)[8])[1];
f_3983(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 227  test");
t3=((C_word*)t0)[5];
f_3573(t3,t2,((C_word*)t0)[4],lf[46]);}}

/* k3997 in k3985 in replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
if(C_truep(t1)){
t2=f_3609(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 229  debugging");
t4=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[4],lf[44],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_4028(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_3609(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_4028(t8,t7);}}}

/* k4026 in k3997 in k3985 in replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_4028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 236  varnode");
t2=C_retrieve(lf[45]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4003 in k3997 in k3985 in replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4020,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 230  test");
t4=((C_word*)t0)[3];
f_3573(t4,t3,((C_word*)t0)[2],lf[43]);}

/* k4018 in k4003 in k3997 in k3985 in replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4021,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4021 in k4018 in k4003 in k3997 in k3985 in replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4021,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4014 in k4003 in k3997 in k3985 in replace in k3966 in k3963 in k3960 in walk1 in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
C_trace("optimizer.scm: 230  qnode");
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3710,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[30])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[10])[1];
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 179  walk1");
t5=((C_word*)((C_word*)t0)[2])[1];
f_3958(t5,t4,t2);}}

/* k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3952,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_3952 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3952,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3947,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* f_3947 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3947,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(t1,lf[8]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[9]);
C_trace("optimizer.scm: 184  constant-node?");
t6=((C_word*)t0)[5];
f_3579(3,t6,t4,t5);}
else{
t4=(C_word)C_eqp(t1,lf[12]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[6],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3942,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t2;
f_3733(2,t5,((C_word*)t0)[6]);}}}

/* f_3942 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3942,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=(C_word)C_eqp(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3929,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)t0)[10];
f_3733(2,t3,((C_word*)t0)[9]);}}

/* f_3929 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3929,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3901,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 195  test");
t5=((C_word*)t0)[2];
f_3573(t5,t4,t2,lf[42]);}

/* k3899 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_3904(2,t3,t1);}
else{
C_trace("optimizer.scm: 196  test");
t3=((C_word*)t0)[3];
f_3573(t3,t2,((C_word*)t0)[2],lf[41]);}}

/* k3902 in k3899 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3910,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 197  test");
t3=((C_word*)t0)[3];
f_3573(t3,t2,((C_word*)t0)[2],lf[40]);}
else{
t2=((C_word*)t0)[5];
f_3794(2,t2,C_SCHEME_FALSE);}}

/* k3908 in k3902 in k3899 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 198  every");
t3=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3794(2,t2,C_SCHEME_FALSE);}}

/* k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("map");
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
f_3733(2,t2,((C_word*)t0)[7]);}}

/* a3881 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3882,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 199  node-value");
f_3594(t3,t2);}

/* k3892 in a3881 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[23],t2));}

/* k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3805,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("call-with-current-continuation");
t5=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3805,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3811,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3828,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("with-exception-handler");
t5=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a3865 in a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3866r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3866r(t0,t1,t2);}}

static void C_ccall f_3866r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3872,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("k243249");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3871 in a3865 in a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3833 in a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3838,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 206  eval");
t3=C_retrieve(lf[37]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3836 in a3833 in a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3841,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 207  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[36],((C_word*)t0)[2]);}

/* k3839 in k3836 in a3833 in a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=f_3609(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 212  qnode");
t5=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3862 in k3839 in k3836 in a3833 in a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3852,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[12],lf[34],t2);}

/* f_3852 in k3862 in k3839 in k3836 in a3833 in a3827 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3852,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[33],t2,t3,t4));}

/* a3810 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3811,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("k243249");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3816 in a3810 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3821(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_3821(t4,t3);}}

/* k3819 in a3816 in a3810 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3821,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 204  lset-adjoin");
t3=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[32]+1),C_retrieve(lf[30]),((C_word*)t0)[2]);}

/* k3823 in k3819 in a3816 in a3810 in a3804 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[30]+1 /* broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3801 in k3878 in k3792 in k3922 in k3935 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3740 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=f_3609(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
C_trace("optimizer.scm: 187  node-value");
f_3594(t5,t6);}
else{
t2=((C_word*)t0)[4];
f_3733(2,t2,((C_word*)t0)[2]);}}

/* k3757 in k3740 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_caddr(((C_word*)t0)[4]));
C_trace("optimizer.scm: 187  walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3710(3,t3,((C_word*)t0)[2],t2);}

/* k3731 in k3728 in k3725 in k3722 in walk in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 177  simplify");
t2=((C_word*)((C_word*)t0)[3])[1];
f_3613(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3613(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3613,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3704,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3704 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3704,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3701 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 158  ##sys#hash-table-ref");
t2=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[19]+1),t1);}

/* k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 159  any");
t4=C_retrieve(lf[28]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}
else{
t3=t2;
f_3620(2,t3,C_SCHEME_FALSE);}}

/* a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3628,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3638,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
C_trace("optimizer.scm: 161  match-node");
t6=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3636 in a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3638,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3644,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3686 in k3636 in a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3687,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k3683 in k3636 in a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3642 in k3636 in a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3650,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 164  caar");
t3=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3648 in k3642 in k3636 in a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3650,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_3656(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3677,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 168  alist-cons");
t5=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k3675 in k3648 in k3642 in k3636 in a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3656(t3,t2);}

/* k3654 in k3648 in k3642 in k3636 in a3627 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3609(((C_word*)t0)[5]);
C_trace("optimizer.scm: 170  simplify");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3613(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3618 in k3615 in simplify in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static C_word C_fcall f_3609(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* node-value in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3594(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3594,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3602,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3603,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3603 in node-value in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3603,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3600 in node-value in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* constant-node? in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3579,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3587,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3588,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3588 in constant-node? in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3588,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3585 in constant-node? in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(lf[23],t1));}

/* test in ##compiler#perform-high-level-optimizations in k3565 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3573(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3573,NULL,4,t0,t1,t2,t3);}
C_trace("optimizer.scm: 152  get");
t4=C_retrieve(lf[22]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3349,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3352,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3370,a[2]=t2,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 84   debugging");
t9=C_retrieve(lf[3]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[17],lf[18]);}

/* k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 85   call-with-current-continuation");
t4=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3382,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3385,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3397,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
C_trace("optimizer.scm: 120  scan");
t9=((C_word*)t6)[1];
f_3397(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3397(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3397,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3401,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3556,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3556 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3556,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3551,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3551 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3551,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3546,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3546 in k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3546,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3405 in k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[7]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[8]))){
t5=t4;
f_3422(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_memq(t3,((C_word*)((C_word*)t0)[7])[1]);
t6=t4;
f_3422(t6,(C_word)C_i_not(t5));}}
else{
t3=(C_word)C_eqp(t1,lf[8]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t3)){
t5=t4;
f_3449(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[14]);
t6=t4;
f_3449(t6,(C_truep(t5)?t5:(C_word)C_eqp(t1,lf[15])));}}}

/* k3447 in k3405 in k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3449,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("optimizer.scm: 102  scan");
t4=((C_word*)((C_word*)t0)[7])[1];
f_3397(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[9]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("optimizer.scm: 106  scan");
t5=((C_word*)((C_word*)t0)[7])[1];
f_3397(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[10]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[11]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[12]);
if(C_truep(t5)){
C_trace("optimizer.scm: 111  return");
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[13]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))?C_SCHEME_UNDEFINED:f_3352(C_a_i(&a,3),((C_word*)t0)[3],t7));
t9=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("optimizer.scm: 116  scan");
t10=((C_word*)((C_word*)t0)[7])[1];
f_3397(t10,((C_word*)t0)[9],t9,((C_word*)t0)[6]);}
else{
C_trace("optimizer.scm: 118  scan-each");
t7=((C_word*)((C_word*)t0)[2])[1];
f_3385(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k3466 in k3447 in k3405 in k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3479,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 107  append");
t4=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3477 in k3466 in k3447 in k3405 in k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 107  scan");
t2=((C_word*)((C_word*)t0)[4])[1];
f_3397(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3450 in k3447 in k3405 in k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 103  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3420 in k3405 in k3402 in k3399 in scan in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3422,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_fcall f_3385(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3385,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3390 in scan-each in a3381 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3391,3,t0,t1,t2);}
C_trace("optimizer.scm: 89   scan");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3397(t3,t1,t2,((C_word*)t0)[2]);}

/* k3371 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 121  debugging");
t3=C_retrieve(lf[3]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[4],lf[5],((C_word*)((C_word*)t0)[2])[1]);}

/* k3374 in k3371 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 122  append");
t3=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],C_retrieve(lf[1]));}

/* k3378 in k3374 in k3371 in k3368 in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[1]+1 /* always-bound ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* mark in ##compiler#scan-toplevel-assignments in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 */
static C_word C_fcall f_3352(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_memq(t1,((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[986] = {
{"topleveloptimizer.scm",(void*)C_optimizer_toplevel},
{"f_3332optimizer.scm",(void*)f_3332},
{"f_3335optimizer.scm",(void*)f_3335},
{"f_3338optimizer.scm",(void*)f_3338},
{"f_3341optimizer.scm",(void*)f_3341},
{"f_3344optimizer.scm",(void*)f_3344},
{"f_3347optimizer.scm",(void*)f_3347},
{"f_3567optimizer.scm",(void*)f_3567},
{"f_13078optimizer.scm",(void*)f_13078},
{"f_13086optimizer.scm",(void*)f_13086},
{"f_13091optimizer.scm",(void*)f_13091},
{"f_13136optimizer.scm",(void*)f_13136},
{"f_13140optimizer.scm",(void*)f_13140},
{"f_13101optimizer.scm",(void*)f_13101},
{"f_13125optimizer.scm",(void*)f_13125},
{"f_13110optimizer.scm",(void*)f_13110},
{"f_5813optimizer.scm",(void*)f_5813},
{"f_12029optimizer.scm",(void*)f_12029},
{"f_12075optimizer.scm",(void*)f_12075},
{"f_12063optimizer.scm",(void*)f_12063},
{"f_12058optimizer.scm",(void*)f_12058},
{"f_12050optimizer.scm",(void*)f_12050},
{"f_12177optimizer.scm",(void*)f_12177},
{"f_12187optimizer.scm",(void*)f_12187},
{"f_12486optimizer.scm",(void*)f_12486},
{"f_12191optimizer.scm",(void*)f_12191},
{"f_12481optimizer.scm",(void*)f_12481},
{"f_12194optimizer.scm",(void*)f_12194},
{"f_12476optimizer.scm",(void*)f_12476},
{"f_12197optimizer.scm",(void*)f_12197},
{"f_12467optimizer.scm",(void*)f_12467},
{"f_12215optimizer.scm",(void*)f_12215},
{"f_12462optimizer.scm",(void*)f_12462},
{"f_12218optimizer.scm",(void*)f_12218},
{"f_12457optimizer.scm",(void*)f_12457},
{"f_12221optimizer.scm",(void*)f_12221},
{"f_12251optimizer.scm",(void*)f_12251},
{"f_12280optimizer.scm",(void*)f_12280},
{"f_12440optimizer.scm",(void*)f_12440},
{"f_12284optimizer.scm",(void*)f_12284},
{"f_12435optimizer.scm",(void*)f_12435},
{"f_12287optimizer.scm",(void*)f_12287},
{"f_12430optimizer.scm",(void*)f_12430},
{"f_12290optimizer.scm",(void*)f_12290},
{"f_12421optimizer.scm",(void*)f_12421},
{"f_12413optimizer.scm",(void*)f_12413},
{"f_12408optimizer.scm",(void*)f_12408},
{"f_12400optimizer.scm",(void*)f_12400},
{"f_12395optimizer.scm",(void*)f_12395},
{"f_12296optimizer.scm",(void*)f_12296},
{"f_12349optimizer.scm",(void*)f_12349},
{"f_12339optimizer.scm",(void*)f_12339},
{"f_12347optimizer.scm",(void*)f_12347},
{"f_12324optimizer.scm",(void*)f_12324},
{"f_12319optimizer.scm",(void*)f_12319},
{"f_12536optimizer.scm",(void*)f_12536},
{"f_12549optimizer.scm",(void*)f_12549},
{"f_12591optimizer.scm",(void*)f_12591},
{"f_12575optimizer.scm",(void*)f_12575},
{"f_12579optimizer.scm",(void*)f_12579},
{"f_12566optimizer.scm",(void*)f_12566},
{"f_12567optimizer.scm",(void*)f_12567},
{"f_12757optimizer.scm",(void*)f_12757},
{"f_12770optimizer.scm",(void*)f_12770},
{"f_12776optimizer.scm",(void*)f_12776},
{"f_12828optimizer.scm",(void*)f_12828},
{"f_12820optimizer.scm",(void*)f_12820},
{"f_12804optimizer.scm",(void*)f_12804},
{"f_12808optimizer.scm",(void*)f_12808},
{"f_12812optimizer.scm",(void*)f_12812},
{"f_12796optimizer.scm",(void*)f_12796},
{"f_5816optimizer.scm",(void*)f_5816},
{"f_11670optimizer.scm",(void*)f_11670},
{"f_11692optimizer.scm",(void*)f_11692},
{"f_11772optimizer.scm",(void*)f_11772},
{"f_11730optimizer.scm",(void*)f_11730},
{"f_11764optimizer.scm",(void*)f_11764},
{"f_11768optimizer.scm",(void*)f_11768},
{"f_11756optimizer.scm",(void*)f_11756},
{"f_11747optimizer.scm",(void*)f_11747},
{"f_11751optimizer.scm",(void*)f_11751},
{"f_11739optimizer.scm",(void*)f_11739},
{"f_11728optimizer.scm",(void*)f_11728},
{"f_11720optimizer.scm",(void*)f_11720},
{"f_11715optimizer.scm",(void*)f_11715},
{"f_11707optimizer.scm",(void*)f_11707},
{"f_11866optimizer.scm",(void*)f_11866},
{"f_11886optimizer.scm",(void*)f_11886},
{"f_11895optimizer.scm",(void*)f_11895},
{"f_11890optimizer.scm",(void*)f_11890},
{"f_11878optimizer.scm",(void*)f_11878},
{"f_5819optimizer.scm",(void*)f_5819},
{"f_6179optimizer.scm",(void*)f_6179},
{"f_9805optimizer.scm",(void*)f_9805},
{"f_11549optimizer.scm",(void*)f_11549},
{"f_11552optimizer.scm",(void*)f_11552},
{"f_11555optimizer.scm",(void*)f_11555},
{"f_11558optimizer.scm",(void*)f_11558},
{"f_11561optimizer.scm",(void*)f_11561},
{"f_11564optimizer.scm",(void*)f_11564},
{"f_11641optimizer.scm",(void*)f_11641},
{"f_11567optimizer.scm",(void*)f_11567},
{"f_11570optimizer.scm",(void*)f_11570},
{"f_11573optimizer.scm",(void*)f_11573},
{"f_11635optimizer.scm",(void*)f_11635},
{"f_11576optimizer.scm",(void*)f_11576},
{"f_11579optimizer.scm",(void*)f_11579},
{"f_11632optimizer.scm",(void*)f_11632},
{"f_10460optimizer.scm",(void*)f_10460},
{"f_10478optimizer.scm",(void*)f_10478},
{"f_10484optimizer.scm",(void*)f_10484},
{"f_10464optimizer.scm",(void*)f_10464},
{"f_11582optimizer.scm",(void*)f_11582},
{"f_11624optimizer.scm",(void*)f_11624},
{"f_11622optimizer.scm",(void*)f_11622},
{"f_11585optimizer.scm",(void*)f_11585},
{"f_11588optimizer.scm",(void*)f_11588},
{"f_11591optimizer.scm",(void*)f_11591},
{"f_11615optimizer.scm",(void*)f_11615},
{"f_11594optimizer.scm",(void*)f_11594},
{"f_11597optimizer.scm",(void*)f_11597},
{"f_11600optimizer.scm",(void*)f_11600},
{"f_11603optimizer.scm",(void*)f_11603},
{"f_11606optimizer.scm",(void*)f_11606},
{"f_11609optimizer.scm",(void*)f_11609},
{"f_11377optimizer.scm",(void*)f_11377},
{"f_11383optimizer.scm",(void*)f_11383},
{"f_11542optimizer.scm",(void*)f_11542},
{"f_11387optimizer.scm",(void*)f_11387},
{"f_11537optimizer.scm",(void*)f_11537},
{"f_11390optimizer.scm",(void*)f_11390},
{"f_11532optimizer.scm",(void*)f_11532},
{"f_11393optimizer.scm",(void*)f_11393},
{"f_11524optimizer.scm",(void*)f_11524},
{"f_11523optimizer.scm",(void*)f_11523},
{"f_11500optimizer.scm",(void*)f_11500},
{"f_11509optimizer.scm",(void*)f_11509},
{"f_11512optimizer.scm",(void*)f_11512},
{"f_11487optimizer.scm",(void*)f_11487},
{"f_11486optimizer.scm",(void*)f_11486},
{"f_11402optimizer.scm",(void*)f_11402},
{"f_11407optimizer.scm",(void*)f_11407},
{"f_11448optimizer.scm",(void*)f_11448},
{"f_11445optimizer.scm",(void*)f_11445},
{"f_11430optimizer.scm",(void*)f_11430},
{"f_11441optimizer.scm",(void*)f_11441},
{"f_11437optimizer.scm",(void*)f_11437},
{"f_11260optimizer.scm",(void*)f_11260},
{"f_11266optimizer.scm",(void*)f_11266},
{"f_11371optimizer.scm",(void*)f_11371},
{"f_11270optimizer.scm",(void*)f_11270},
{"f_11366optimizer.scm",(void*)f_11366},
{"f_11273optimizer.scm",(void*)f_11273},
{"f_11361optimizer.scm",(void*)f_11361},
{"f_11276optimizer.scm",(void*)f_11276},
{"f_11353optimizer.scm",(void*)f_11353},
{"f_11352optimizer.scm",(void*)f_11352},
{"f_11344optimizer.scm",(void*)f_11344},
{"f_11343optimizer.scm",(void*)f_11343},
{"f_11327optimizer.scm",(void*)f_11327},
{"f_11323optimizer.scm",(void*)f_11323},
{"f_11288optimizer.scm",(void*)f_11288},
{"f_11296optimizer.scm",(void*)f_11296},
{"f_11295optimizer.scm",(void*)f_11295},
{"f_10954optimizer.scm",(void*)f_10954},
{"f_11111optimizer.scm",(void*)f_11111},
{"f_11110optimizer.scm",(void*)f_11110},
{"f_10968optimizer.scm",(void*)f_10968},
{"f_10975optimizer.scm",(void*)f_10975},
{"f_11098optimizer.scm",(void*)f_11098},
{"f_11097optimizer.scm",(void*)f_11097},
{"f_10988optimizer.scm",(void*)f_10988},
{"f_10995optimizer.scm",(void*)f_10995},
{"f_10998optimizer.scm",(void*)f_10998},
{"f_11085optimizer.scm",(void*)f_11085},
{"f_11084optimizer.scm",(void*)f_11084},
{"f_11135optimizer.scm",(void*)f_11135},
{"f_11254optimizer.scm",(void*)f_11254},
{"f_11139optimizer.scm",(void*)f_11139},
{"f_11249optimizer.scm",(void*)f_11249},
{"f_11142optimizer.scm",(void*)f_11142},
{"f_11244optimizer.scm",(void*)f_11244},
{"f_11145optimizer.scm",(void*)f_11145},
{"f_11221optimizer.scm",(void*)f_11221},
{"f_11240optimizer.scm",(void*)f_11240},
{"f_11236optimizer.scm",(void*)f_11236},
{"f_11202optimizer.scm",(void*)f_11202},
{"f_11191optimizer.scm",(void*)f_11191},
{"f_11178optimizer.scm",(void*)f_11178},
{"f_11161optimizer.scm",(void*)f_11161},
{"f_11154optimizer.scm",(void*)f_11154},
{"f_11120optimizer.scm",(void*)f_11120},
{"f_11001optimizer.scm",(void*)f_11001},
{"f_11076optimizer.scm",(void*)f_11076},
{"f_11064optimizer.scm",(void*)f_11064},
{"f_11060optimizer.scm",(void*)f_11060},
{"f_11052optimizer.scm",(void*)f_11052},
{"f_11046optimizer.scm",(void*)f_11046},
{"f_11047optimizer.scm",(void*)f_11047},
{"f_11038optimizer.scm",(void*)f_11038},
{"f_11030optimizer.scm",(void*)f_11030},
{"f_11021optimizer.scm",(void*)f_11021},
{"f_11013optimizer.scm",(void*)f_11013},
{"f_10966optimizer.scm",(void*)f_10966},
{"f_10738optimizer.scm",(void*)f_10738},
{"f_10940optimizer.scm",(void*)f_10940},
{"f_10818optimizer.scm",(void*)f_10818},
{"f_10895optimizer.scm",(void*)f_10895},
{"f_10900optimizer.scm",(void*)f_10900},
{"f_10938optimizer.scm",(void*)f_10938},
{"f_10747optimizer.scm",(void*)f_10747},
{"f_10811optimizer.scm",(void*)f_10811},
{"f_10751optimizer.scm",(void*)f_10751},
{"f_10806optimizer.scm",(void*)f_10806},
{"f_10754optimizer.scm",(void*)f_10754},
{"f_10801optimizer.scm",(void*)f_10801},
{"f_10757optimizer.scm",(void*)f_10757},
{"f_10785optimizer.scm",(void*)f_10785},
{"f_10790optimizer.scm",(void*)f_10790},
{"f_10767optimizer.scm",(void*)f_10767},
{"f_10745optimizer.scm",(void*)f_10745},
{"f_10930optimizer.scm",(void*)f_10930},
{"f_10916optimizer.scm",(void*)f_10916},
{"f_10914optimizer.scm",(void*)f_10914},
{"f_10820optimizer.scm",(void*)f_10820},
{"f_10888optimizer.scm",(void*)f_10888},
{"f_10886optimizer.scm",(void*)f_10886},
{"f_10874optimizer.scm",(void*)f_10874},
{"f_10840optimizer.scm",(void*)f_10840},
{"f_10864optimizer.scm",(void*)f_10864},
{"f_10862optimizer.scm",(void*)f_10862},
{"f_10858optimizer.scm",(void*)f_10858},
{"f_10850optimizer.scm",(void*)f_10850},
{"f_10494optimizer.scm",(void*)f_10494},
{"f_10500optimizer.scm",(void*)f_10500},
{"f_10732optimizer.scm",(void*)f_10732},
{"f_10504optimizer.scm",(void*)f_10504},
{"f_10727optimizer.scm",(void*)f_10727},
{"f_10507optimizer.scm",(void*)f_10507},
{"f_10722optimizer.scm",(void*)f_10722},
{"f_10510optimizer.scm",(void*)f_10510},
{"f_10519optimizer.scm",(void*)f_10519},
{"f_10696optimizer.scm",(void*)f_10696},
{"f_10616optimizer.scm",(void*)f_10616},
{"f_10687optimizer.scm",(void*)f_10687},
{"f_10686optimizer.scm",(void*)f_10686},
{"f_10678optimizer.scm",(void*)f_10678},
{"f_10677optimizer.scm",(void*)f_10677},
{"f_10632optimizer.scm",(void*)f_10632},
{"f_10662optimizer.scm",(void*)f_10662},
{"f_10666optimizer.scm",(void*)f_10666},
{"f_10652optimizer.scm",(void*)f_10652},
{"f_10605optimizer.scm",(void*)f_10605},
{"f_10610optimizer.scm",(void*)f_10610},
{"f_10581optimizer.scm",(void*)f_10581},
{"f_10593optimizer.scm",(void*)f_10593},
{"f_10530optimizer.scm",(void*)f_10530},
{"f_10551optimizer.scm",(void*)f_10551},
{"f_10548optimizer.scm",(void*)f_10548},
{"f_10498optimizer.scm",(void*)f_10498},
{"f_10235optimizer.scm",(void*)f_10235},
{"f_10241optimizer.scm",(void*)f_10241},
{"f_10398optimizer.scm",(void*)f_10398},
{"f_10245optimizer.scm",(void*)f_10245},
{"f_10393optimizer.scm",(void*)f_10393},
{"f_10248optimizer.scm",(void*)f_10248},
{"f_10388optimizer.scm",(void*)f_10388},
{"f_10251optimizer.scm",(void*)f_10251},
{"f_10260optimizer.scm",(void*)f_10260},
{"f_10362optimizer.scm",(void*)f_10362},
{"f_10353optimizer.scm",(void*)f_10353},
{"f_10319optimizer.scm",(void*)f_10319},
{"f_10328optimizer.scm",(void*)f_10328},
{"f_10340optimizer.scm",(void*)f_10340},
{"f_10271optimizer.scm",(void*)f_10271},
{"f_10292optimizer.scm",(void*)f_10292},
{"f_10289optimizer.scm",(void*)f_10289},
{"f_10239optimizer.scm",(void*)f_10239},
{"f_10136optimizer.scm",(void*)f_10136},
{"f_10142optimizer.scm",(void*)f_10142},
{"f_10186optimizer.scm",(void*)f_10186},
{"f_10191optimizer.scm",(void*)f_10191},
{"f_10198optimizer.scm",(void*)f_10198},
{"f_10225optimizer.scm",(void*)f_10225},
{"f_10221optimizer.scm",(void*)f_10221},
{"f_10213optimizer.scm",(void*)f_10213},
{"f_10211optimizer.scm",(void*)f_10211},
{"f_10176optimizer.scm",(void*)f_10176},
{"f_10154optimizer.scm",(void*)f_10154},
{"f_10161optimizer.scm",(void*)f_10161},
{"f_9914optimizer.scm",(void*)f_9914},
{"f_10083optimizer.scm",(void*)f_10083},
{"f_10130optimizer.scm",(void*)f_10130},
{"f_10129optimizer.scm",(void*)f_10129},
{"f_10108optimizer.scm",(void*)f_10108},
{"f_10121optimizer.scm",(void*)f_10121},
{"f_10120optimizer.scm",(void*)f_10120},
{"f_10098optimizer.scm",(void*)f_10098},
{"f_10102optimizer.scm",(void*)f_10102},
{"f_10081optimizer.scm",(void*)f_10081},
{"f_9917optimizer.scm",(void*)f_9917},
{"f_10074optimizer.scm",(void*)f_10074},
{"f_9921optimizer.scm",(void*)f_9921},
{"f_10069optimizer.scm",(void*)f_10069},
{"f_9924optimizer.scm",(void*)f_9924},
{"f_10064optimizer.scm",(void*)f_10064},
{"f_9927optimizer.scm",(void*)f_9927},
{"f_10056optimizer.scm",(void*)f_10056},
{"f_10039optimizer.scm",(void*)f_10039},
{"f_10051optimizer.scm",(void*)f_10051},
{"f_9985optimizer.scm",(void*)f_9985},
{"f_10009optimizer.scm",(void*)f_10009},
{"f_10003optimizer.scm",(void*)f_10003},
{"f_9967optimizer.scm",(void*)f_9967},
{"f_9942optimizer.scm",(void*)f_9942},
{"f_9945optimizer.scm",(void*)f_9945},
{"f_9950optimizer.scm",(void*)f_9950},
{"f_9808optimizer.scm",(void*)f_9808},
{"f_9814optimizer.scm",(void*)f_9814},
{"f_9900optimizer.scm",(void*)f_9900},
{"f_9895optimizer.scm",(void*)f_9895},
{"f_9845optimizer.scm",(void*)f_9845},
{"f_9849optimizer.scm",(void*)f_9849},
{"f_9853optimizer.scm",(void*)f_9853},
{"f_9812optimizer.scm",(void*)f_9812},
{"f_8540optimizer.scm",(void*)f_8540},
{"f_9800optimizer.scm",(void*)f_9800},
{"f_9803optimizer.scm",(void*)f_9803},
{"f_8543optimizer.scm",(void*)f_8543},
{"f_8714optimizer.scm",(void*)f_8714},
{"f_8547optimizer.scm",(void*)f_8547},
{"f_8709optimizer.scm",(void*)f_8709},
{"f_8550optimizer.scm",(void*)f_8550},
{"f_8704optimizer.scm",(void*)f_8704},
{"f_8553optimizer.scm",(void*)f_8553},
{"f_8699optimizer.scm",(void*)f_8699},
{"f_8679optimizer.scm",(void*)f_8679},
{"f_8653optimizer.scm",(void*)f_8653},
{"f_8599optimizer.scm",(void*)f_8599},
{"f_8605optimizer.scm",(void*)f_8605},
{"f_8611optimizer.scm",(void*)f_8611},
{"f_8568optimizer.scm",(void*)f_8568},
{"f_8720optimizer.scm",(void*)f_8720},
{"f_9165optimizer.scm",(void*)f_9165},
{"f_9172optimizer.scm",(void*)f_9172},
{"f_8723optimizer.scm",(void*)f_8723},
{"f_9152optimizer.scm",(void*)f_9152},
{"f_8727optimizer.scm",(void*)f_8727},
{"f_9147optimizer.scm",(void*)f_9147},
{"f_8730optimizer.scm",(void*)f_8730},
{"f_9142optimizer.scm",(void*)f_9142},
{"f_8733optimizer.scm",(void*)f_8733},
{"f_9137optimizer.scm",(void*)f_9137},
{"f_9113optimizer.scm",(void*)f_9113},
{"f_9124optimizer.scm",(void*)f_9124},
{"f_9080optimizer.scm",(void*)f_9080},
{"f_9046optimizer.scm",(void*)f_9046},
{"f_9045optimizer.scm",(void*)f_9045},
{"f_9037optimizer.scm",(void*)f_9037},
{"f_9036optimizer.scm",(void*)f_9036},
{"f_9025optimizer.scm",(void*)f_9025},
{"f_9024optimizer.scm",(void*)f_9024},
{"f_9016optimizer.scm",(void*)f_9016},
{"f_9015optimizer.scm",(void*)f_9015},
{"f_8999optimizer.scm",(void*)f_8999},
{"f_8971optimizer.scm",(void*)f_8971},
{"f_8976optimizer.scm",(void*)f_8976},
{"f_8918optimizer.scm",(void*)f_8918},
{"f_8924optimizer.scm",(void*)f_8924},
{"f_8929optimizer.scm",(void*)f_8929},
{"f_8877optimizer.scm",(void*)f_8877},
{"f_8883optimizer.scm",(void*)f_8883},
{"f_8888optimizer.scm",(void*)f_8888},
{"f_8861optimizer.scm",(void*)f_8861},
{"f_8857optimizer.scm",(void*)f_8857},
{"f_8827optimizer.scm",(void*)f_8827},
{"f_8790optimizer.scm",(void*)f_8790},
{"f_8806optimizer.scm",(void*)f_8806},
{"f_8772optimizer.scm",(void*)f_8772},
{"f_9174optimizer.scm",(void*)f_9174},
{"f_9790optimizer.scm",(void*)f_9790},
{"f_9788optimizer.scm",(void*)f_9788},
{"f_9178optimizer.scm",(void*)f_9178},
{"f_9774optimizer.scm",(void*)f_9774},
{"f_9182optimizer.scm",(void*)f_9182},
{"f_9188optimizer.scm",(void*)f_9188},
{"f_9194optimizer.scm",(void*)f_9194},
{"f_9200optimizer.scm",(void*)f_9200},
{"f_9203optimizer.scm",(void*)f_9203},
{"f_9209optimizer.scm",(void*)f_9209},
{"f_9738optimizer.scm",(void*)f_9738},
{"f_9737optimizer.scm",(void*)f_9737},
{"f_9448optimizer.scm",(void*)f_9448},
{"f_9729optimizer.scm",(void*)f_9729},
{"f_9452optimizer.scm",(void*)f_9452},
{"f_9724optimizer.scm",(void*)f_9724},
{"f_9455optimizer.scm",(void*)f_9455},
{"f_9719optimizer.scm",(void*)f_9719},
{"f_9458optimizer.scm",(void*)f_9458},
{"f_9702optimizer.scm",(void*)f_9702},
{"f_9705optimizer.scm",(void*)f_9705},
{"f_9676optimizer.scm",(void*)f_9676},
{"f_9473optimizer.scm",(void*)f_9473},
{"f_9671optimizer.scm",(void*)f_9671},
{"f_9476optimizer.scm",(void*)f_9476},
{"f_9666optimizer.scm",(void*)f_9666},
{"f_9665optimizer.scm",(void*)f_9665},
{"f_9640optimizer.scm",(void*)f_9640},
{"f_9643optimizer.scm",(void*)f_9643},
{"f_9492optimizer.scm",(void*)f_9492},
{"f_9616optimizer.scm",(void*)f_9616},
{"f_9615optimizer.scm",(void*)f_9615},
{"f_9547optimizer.scm",(void*)f_9547},
{"f_9550optimizer.scm",(void*)f_9550},
{"f_9593optimizer.scm",(void*)f_9593},
{"f_9592optimizer.scm",(void*)f_9592},
{"f_9584optimizer.scm",(void*)f_9584},
{"f_9553optimizer.scm",(void*)f_9553},
{"f_9576optimizer.scm",(void*)f_9576},
{"f_9567optimizer.scm",(void*)f_9567},
{"f_9556optimizer.scm",(void*)f_9556},
{"f_9501optimizer.scm",(void*)f_9501},
{"f_9504optimizer.scm",(void*)f_9504},
{"f_9507optimizer.scm",(void*)f_9507},
{"f_9212optimizer.scm",(void*)f_9212},
{"f_9430optimizer.scm",(void*)f_9430},
{"f_9428optimizer.scm",(void*)f_9428},
{"f_9359optimizer.scm",(void*)f_9359},
{"f_9420optimizer.scm",(void*)f_9420},
{"f_9366optimizer.scm",(void*)f_9366},
{"f_9369optimizer.scm",(void*)f_9369},
{"f_9393optimizer.scm",(void*)f_9393},
{"f_9384optimizer.scm",(void*)f_9384},
{"f_9215optimizer.scm",(void*)f_9215},
{"f_9350optimizer.scm",(void*)f_9350},
{"f_9224optimizer.scm",(void*)f_9224},
{"f_9227optimizer.scm",(void*)f_9227},
{"f_9276optimizer.scm",(void*)f_9276},
{"f_9341optimizer.scm",(void*)f_9341},
{"f_9336optimizer.scm",(void*)f_9336},
{"f_9328optimizer.scm",(void*)f_9328},
{"f_9304optimizer.scm",(void*)f_9304},
{"f_9323optimizer.scm",(void*)f_9323},
{"f_9308optimizer.scm",(void*)f_9308},
{"f_9318optimizer.scm",(void*)f_9318},
{"f_9312optimizer.scm",(void*)f_9312},
{"f_9313optimizer.scm",(void*)f_9313},
{"f_9300optimizer.scm",(void*)f_9300},
{"f_9292optimizer.scm",(void*)f_9292},
{"f_9230optimizer.scm",(void*)f_9230},
{"f_9233optimizer.scm",(void*)f_9233},
{"f_9238optimizer.scm",(void*)f_9238},
{"f_9274optimizer.scm",(void*)f_9274},
{"f_9245optimizer.scm",(void*)f_9245},
{"f_9262optimizer.scm",(void*)f_9262},
{"f_9252optimizer.scm",(void*)f_9252},
{"f_9257optimizer.scm",(void*)f_9257},
{"f_9256optimizer.scm",(void*)f_9256},
{"f_6201optimizer.scm",(void*)f_6201},
{"f_8401optimizer.scm",(void*)f_8401},
{"f_8404optimizer.scm",(void*)f_8404},
{"f_8433optimizer.scm",(void*)f_8433},
{"f_8445optimizer.scm",(void*)f_8445},
{"f_8459optimizer.scm",(void*)f_8459},
{"f_8508optimizer.scm",(void*)f_8508},
{"f_6226optimizer.scm",(void*)f_6226},
{"f_8479optimizer.scm",(void*)f_8479},
{"f_8483optimizer.scm",(void*)f_8483},
{"f_8453optimizer.scm",(void*)f_8453},
{"f_8439optimizer.scm",(void*)f_8439},
{"f_8437optimizer.scm",(void*)f_8437},
{"f_8424optimizer.scm",(void*)f_8424},
{"f_8425optimizer.scm",(void*)f_8425},
{"f_8320optimizer.scm",(void*)f_8320},
{"f_8323optimizer.scm",(void*)f_8323},
{"f_8375optimizer.scm",(void*)f_8375},
{"f_8367optimizer.scm",(void*)f_8367},
{"f_8359optimizer.scm",(void*)f_8359},
{"f_8348optimizer.scm",(void*)f_8348},
{"f_8340optimizer.scm",(void*)f_8340},
{"f_8124optimizer.scm",(void*)f_8124},
{"f_8127optimizer.scm",(void*)f_8127},
{"f_8133optimizer.scm",(void*)f_8133},
{"f_8249optimizer.scm",(void*)f_8249},
{"f_8277optimizer.scm",(void*)f_8277},
{"f_8276optimizer.scm",(void*)f_8276},
{"f_8268optimizer.scm",(void*)f_8268},
{"f_8267optimizer.scm",(void*)f_8267},
{"f_8142optimizer.scm",(void*)f_8142},
{"f_8204optimizer.scm",(void*)f_8204},
{"f_8239optimizer.scm",(void*)f_8239},
{"f_8223optimizer.scm",(void*)f_8223},
{"f_8202optimizer.scm",(void*)f_8202},
{"f_8194optimizer.scm",(void*)f_8194},
{"f_8178optimizer.scm",(void*)f_8178},
{"f_8164optimizer.scm",(void*)f_8164},
{"f_8156optimizer.scm",(void*)f_8156},
{"f_8038optimizer.scm",(void*)f_8038},
{"f_8041optimizer.scm",(void*)f_8041},
{"f_8082optimizer.scm",(void*)f_8082},
{"f_8094optimizer.scm",(void*)f_8094},
{"f_8072optimizer.scm",(void*)f_8072},
{"f_8065optimizer.scm",(void*)f_8065},
{"f_8066optimizer.scm",(void*)f_8066},
{"f_8057optimizer.scm",(void*)f_8057},
{"f_8049optimizer.scm",(void*)f_8049},
{"f_7855optimizer.scm",(void*)f_7855},
{"f_7858optimizer.scm",(void*)f_7858},
{"f_7964optimizer.scm",(void*)f_7964},
{"f_7992optimizer.scm",(void*)f_7992},
{"f_7991optimizer.scm",(void*)f_7991},
{"f_7983optimizer.scm",(void*)f_7983},
{"f_7982optimizer.scm",(void*)f_7982},
{"f_7867optimizer.scm",(void*)f_7867},
{"f_7938optimizer.scm",(void*)f_7938},
{"f_7951optimizer.scm",(void*)f_7951},
{"f_7936optimizer.scm",(void*)f_7936},
{"f_7928optimizer.scm",(void*)f_7928},
{"f_7903optimizer.scm",(void*)f_7903},
{"f_7889optimizer.scm",(void*)f_7889},
{"f_7881optimizer.scm",(void*)f_7881},
{"f_7814optimizer.scm",(void*)f_7814},
{"f_7817optimizer.scm",(void*)f_7817},
{"f_7833optimizer.scm",(void*)f_7833},
{"f_7825optimizer.scm",(void*)f_7825},
{"f_7734optimizer.scm",(void*)f_7734},
{"f_7737optimizer.scm",(void*)f_7737},
{"f_7769optimizer.scm",(void*)f_7769},
{"f_7758optimizer.scm",(void*)f_7758},
{"f_7753optimizer.scm",(void*)f_7753},
{"f_7745optimizer.scm",(void*)f_7745},
{"f_7643optimizer.scm",(void*)f_7643},
{"f_7646optimizer.scm",(void*)f_7646},
{"f_7688optimizer.scm",(void*)f_7688},
{"f_7676optimizer.scm",(void*)f_7676},
{"f_7671optimizer.scm",(void*)f_7671},
{"f_7663optimizer.scm",(void*)f_7663},
{"f_7537optimizer.scm",(void*)f_7537},
{"f_7540optimizer.scm",(void*)f_7540},
{"f_7588optimizer.scm",(void*)f_7588},
{"f_7566optimizer.scm",(void*)f_7566},
{"f_7557optimizer.scm",(void*)f_7557},
{"f_7558optimizer.scm",(void*)f_7558},
{"f_7442optimizer.scm",(void*)f_7442},
{"f_7445optimizer.scm",(void*)f_7445},
{"f_7481optimizer.scm",(void*)f_7481},
{"f_7476optimizer.scm",(void*)f_7476},
{"f_7468optimizer.scm",(void*)f_7468},
{"f_7364optimizer.scm",(void*)f_7364},
{"f_7367optimizer.scm",(void*)f_7367},
{"f_7386optimizer.scm",(void*)f_7386},
{"f_7404optimizer.scm",(void*)f_7404},
{"f_7399optimizer.scm",(void*)f_7399},
{"f_7390optimizer.scm",(void*)f_7390},
{"f_7391optimizer.scm",(void*)f_7391},
{"f_7275optimizer.scm",(void*)f_7275},
{"f_7278optimizer.scm",(void*)f_7278},
{"f_7334optimizer.scm",(void*)f_7334},
{"f_7325optimizer.scm",(void*)f_7325},
{"f_7326optimizer.scm",(void*)f_7326},
{"f_7310optimizer.scm",(void*)f_7310},
{"f_7203optimizer.scm",(void*)f_7203},
{"f_7206optimizer.scm",(void*)f_7206},
{"f_7218optimizer.scm",(void*)f_7218},
{"f_7238optimizer.scm",(void*)f_7238},
{"f_7229optimizer.scm",(void*)f_7229},
{"f_7230optimizer.scm",(void*)f_7230},
{"f_7109optimizer.scm",(void*)f_7109},
{"f_7138optimizer.scm",(void*)f_7138},
{"f_7146optimizer.scm",(void*)f_7146},
{"f_7150optimizer.scm",(void*)f_7150},
{"f_7130optimizer.scm",(void*)f_7130},
{"f_6940optimizer.scm",(void*)f_6940},
{"f_6968optimizer.scm",(void*)f_6968},
{"f_6971optimizer.scm",(void*)f_6971},
{"f_7049optimizer.scm",(void*)f_7049},
{"f_6974optimizer.scm",(void*)f_6974},
{"f_6977optimizer.scm",(void*)f_6977},
{"f_7021optimizer.scm",(void*)f_7021},
{"f_7030optimizer.scm",(void*)f_7030},
{"f_7019optimizer.scm",(void*)f_7019},
{"f_7008optimizer.scm",(void*)f_7008},
{"f_7003optimizer.scm",(void*)f_7003},
{"f_6982optimizer.scm",(void*)f_6982},
{"f_6995optimizer.scm",(void*)f_6995},
{"f_6962optimizer.scm",(void*)f_6962},
{"f_6954optimizer.scm",(void*)f_6954},
{"f_6913optimizer.scm",(void*)f_6913},
{"f_6916optimizer.scm",(void*)f_6916},
{"f_6839optimizer.scm",(void*)f_6839},
{"f_6842optimizer.scm",(void*)f_6842},
{"f_6879optimizer.scm",(void*)f_6879},
{"f_6866optimizer.scm",(void*)f_6866},
{"f_6867optimizer.scm",(void*)f_6867},
{"f_6858optimizer.scm",(void*)f_6858},
{"f_6850optimizer.scm",(void*)f_6850},
{"f_6755optimizer.scm",(void*)f_6755},
{"f_6793optimizer.scm",(void*)f_6793},
{"f_6788optimizer.scm",(void*)f_6788},
{"f_6780optimizer.scm",(void*)f_6780},
{"f_6771optimizer.scm",(void*)f_6771},
{"f_6763optimizer.scm",(void*)f_6763},
{"f_6649optimizer.scm",(void*)f_6649},
{"f_6652optimizer.scm",(void*)f_6652},
{"f_6707optimizer.scm",(void*)f_6707},
{"f_6695optimizer.scm",(void*)f_6695},
{"f_6686optimizer.scm",(void*)f_6686},
{"f_6678optimizer.scm",(void*)f_6678},
{"f_6586optimizer.scm",(void*)f_6586},
{"f_6606optimizer.scm",(void*)f_6606},
{"f_6614optimizer.scm",(void*)f_6614},
{"f_6598optimizer.scm",(void*)f_6598},
{"f_6536optimizer.scm",(void*)f_6536},
{"f_6539optimizer.scm",(void*)f_6539},
{"f_6555optimizer.scm",(void*)f_6555},
{"f_6547optimizer.scm",(void*)f_6547},
{"f_6404optimizer.scm",(void*)f_6404},
{"f_6407optimizer.scm",(void*)f_6407},
{"f_6500optimizer.scm",(void*)f_6500},
{"f_6499optimizer.scm",(void*)f_6499},
{"f_6491optimizer.scm",(void*)f_6491},
{"f_6490optimizer.scm",(void*)f_6490},
{"f_6482optimizer.scm",(void*)f_6482},
{"f_6441optimizer.scm",(void*)f_6441},
{"f_6461optimizer.scm",(void*)f_6461},
{"f_6449optimizer.scm",(void*)f_6449},
{"f_6438optimizer.scm",(void*)f_6438},
{"f_6430optimizer.scm",(void*)f_6430},
{"f_6258optimizer.scm",(void*)f_6258},
{"f_6371optimizer.scm",(void*)f_6371},
{"f_6370optimizer.scm",(void*)f_6370},
{"f_6362optimizer.scm",(void*)f_6362},
{"f_6361optimizer.scm",(void*)f_6361},
{"f_6353optimizer.scm",(void*)f_6353},
{"f_6343optimizer.scm",(void*)f_6343},
{"f_6348optimizer.scm",(void*)f_6348},
{"f_6347optimizer.scm",(void*)f_6347},
{"f_6339optimizer.scm",(void*)f_6339},
{"f_6331optimizer.scm",(void*)f_6331},
{"f_6261optimizer.scm",(void*)f_6261},
{"f_6288optimizer.scm",(void*)f_6288},
{"f_6283optimizer.scm",(void*)f_6283},
{"f_6275optimizer.scm",(void*)f_6275},
{"f_6204optimizer.scm",(void*)f_6204},
{"f_6181optimizer.scm",(void*)f_6181},
{"f_6185optimizer.scm",(void*)f_6185},
{"f_6195optimizer.scm",(void*)f_6195},
{"f_5821optimizer.scm",(void*)f_5821},
{"f_5825optimizer.scm",(void*)f_5825},
{"f_6166optimizer.scm",(void*)f_6166},
{"f_6175optimizer.scm",(void*)f_6175},
{"f_6171optimizer.scm",(void*)f_6171},
{"f_5872optimizer.scm",(void*)f_5872},
{"f_6108optimizer.scm",(void*)f_6108},
{"f_6140optimizer.scm",(void*)f_6140},
{"f_6153optimizer.scm",(void*)f_6153},
{"f_6118optimizer.scm",(void*)f_6118},
{"f_6134optimizer.scm",(void*)f_6134},
{"f_6122optimizer.scm",(void*)f_6122},
{"f_6126optimizer.scm",(void*)f_6126},
{"f_5875optimizer.scm",(void*)f_5875},
{"f_6049optimizer.scm",(void*)f_6049},
{"f_6092optimizer.scm",(void*)f_6092},
{"f_6098optimizer.scm",(void*)f_6098},
{"f_6056optimizer.scm",(void*)f_6056},
{"f_6066optimizer.scm",(void*)f_6066},
{"f_6079optimizer.scm",(void*)f_6079},
{"f_6064optimizer.scm",(void*)f_6064},
{"f_6060optimizer.scm",(void*)f_6060},
{"f_5878optimizer.scm",(void*)f_5878},
{"f_5881optimizer.scm",(void*)f_5881},
{"f_5901optimizer.scm",(void*)f_5901},
{"f_5914optimizer.scm",(void*)f_5914},
{"f_5975optimizer.scm",(void*)f_5975},
{"f_6021optimizer.scm",(void*)f_6021},
{"f_6005optimizer.scm",(void*)f_6005},
{"f_5996optimizer.scm",(void*)f_5996},
{"f_5988optimizer.scm",(void*)f_5988},
{"f_5973optimizer.scm",(void*)f_5973},
{"f_5943optimizer.scm",(void*)f_5943},
{"f_5965optimizer.scm",(void*)f_5965},
{"f_5964optimizer.scm",(void*)f_5964},
{"f_5956optimizer.scm",(void*)f_5956},
{"f_5926optimizer.scm",(void*)f_5926},
{"f_5884optimizer.scm",(void*)f_5884},
{"f_5893optimizer.scm",(void*)f_5893},
{"f_5827optimizer.scm",(void*)f_5827},
{"f_5833optimizer.scm",(void*)f_5833},
{"f_5857optimizer.scm",(void*)f_5857},
{"f_5806optimizer.scm",(void*)f_5806},
{"f_5243optimizer.scm",(void*)f_5243},
{"f_5257optimizer.scm",(void*)f_5257},
{"f_5543optimizer.scm",(void*)f_5543},
{"f_5801optimizer.scm",(void*)f_5801},
{"f_5548optimizer.scm",(void*)f_5548},
{"f_5793optimizer.scm",(void*)f_5793},
{"f_5555optimizer.scm",(void*)f_5555},
{"f_5788optimizer.scm",(void*)f_5788},
{"f_5783optimizer.scm",(void*)f_5783},
{"f_5779optimizer.scm",(void*)f_5779},
{"f_5561optimizer.scm",(void*)f_5561},
{"f_5564optimizer.scm",(void*)f_5564},
{"f_5757optimizer.scm",(void*)f_5757},
{"f_5756optimizer.scm",(void*)f_5756},
{"f_5570optimizer.scm",(void*)f_5570},
{"f_5730optimizer.scm",(void*)f_5730},
{"f_5729optimizer.scm",(void*)f_5729},
{"f_5721optimizer.scm",(void*)f_5721},
{"f_5720optimizer.scm",(void*)f_5720},
{"f_5712optimizer.scm",(void*)f_5712},
{"f_5579optimizer.scm",(void*)f_5579},
{"f_5585optimizer.scm",(void*)f_5585},
{"f_5591optimizer.scm",(void*)f_5591},
{"f_5693optimizer.scm",(void*)f_5693},
{"f_5692optimizer.scm",(void*)f_5692},
{"f_5597optimizer.scm",(void*)f_5597},
{"f_5675optimizer.scm",(void*)f_5675},
{"f_5674optimizer.scm",(void*)f_5674},
{"f_5666optimizer.scm",(void*)f_5666},
{"f_5665optimizer.scm",(void*)f_5665},
{"f_5657optimizer.scm",(void*)f_5657},
{"f_5656optimizer.scm",(void*)f_5656},
{"f_5606optimizer.scm",(void*)f_5606},
{"f_5613optimizer.scm",(void*)f_5613},
{"f_5616optimizer.scm",(void*)f_5616},
{"f_5634optimizer.scm",(void*)f_5634},
{"f_5619optimizer.scm",(void*)f_5619},
{"f_5260optimizer.scm",(void*)f_5260},
{"f_5274optimizer.scm",(void*)f_5274},
{"f_5281optimizer.scm",(void*)f_5281},
{"f_5537optimizer.scm",(void*)f_5537},
{"f_5286optimizer.scm",(void*)f_5286},
{"f_5529optimizer.scm",(void*)f_5529},
{"f_5293optimizer.scm",(void*)f_5293},
{"f_5524optimizer.scm",(void*)f_5524},
{"f_5519optimizer.scm",(void*)f_5519},
{"f_5299optimizer.scm",(void*)f_5299},
{"f_5515optimizer.scm",(void*)f_5515},
{"f_5302optimizer.scm",(void*)f_5302},
{"f_5501optimizer.scm",(void*)f_5501},
{"f_5500optimizer.scm",(void*)f_5500},
{"f_5484optimizer.scm",(void*)f_5484},
{"f_5482optimizer.scm",(void*)f_5482},
{"f_5308optimizer.scm",(void*)f_5308},
{"f_5456optimizer.scm",(void*)f_5456},
{"f_5455optimizer.scm",(void*)f_5455},
{"f_5447optimizer.scm",(void*)f_5447},
{"f_5446optimizer.scm",(void*)f_5446},
{"f_5434optimizer.scm",(void*)f_5434},
{"f_5433optimizer.scm",(void*)f_5433},
{"f_5320optimizer.scm",(void*)f_5320},
{"f_5326optimizer.scm",(void*)f_5326},
{"f_5413optimizer.scm",(void*)f_5413},
{"f_5412optimizer.scm",(void*)f_5412},
{"f_5400optimizer.scm",(void*)f_5400},
{"f_5399optimizer.scm",(void*)f_5399},
{"f_5391optimizer.scm",(void*)f_5391},
{"f_5390optimizer.scm",(void*)f_5390},
{"f_5335optimizer.scm",(void*)f_5335},
{"f_5363optimizer.scm",(void*)f_5363},
{"f_5338optimizer.scm",(void*)f_5338},
{"f_5341optimizer.scm",(void*)f_5341},
{"f_5344optimizer.scm",(void*)f_5344},
{"f_5362optimizer.scm",(void*)f_5362},
{"f_5347optimizer.scm",(void*)f_5347},
{"f_5263optimizer.scm",(void*)f_5263},
{"f_5266optimizer.scm",(void*)f_5266},
{"f_5250optimizer.scm",(void*)f_5250},
{"f_5246optimizer.scm",(void*)f_5246},
{"f_3570optimizer.scm",(void*)f_3570},
{"f_5147optimizer.scm",(void*)f_5147},
{"f_5153optimizer.scm",(void*)f_5153},
{"f_5157optimizer.scm",(void*)f_5157},
{"f_5160optimizer.scm",(void*)f_5160},
{"f_5196optimizer.scm",(void*)f_5196},
{"f_5201optimizer.scm",(void*)f_5201},
{"f_5205optimizer.scm",(void*)f_5205},
{"f_5163optimizer.scm",(void*)f_5163},
{"f_5166optimizer.scm",(void*)f_5166},
{"f_5169optimizer.scm",(void*)f_5169},
{"f_5172optimizer.scm",(void*)f_5172},
{"f_5123optimizer.scm",(void*)f_5123},
{"f_5127optimizer.scm",(void*)f_5127},
{"f_5133optimizer.scm",(void*)f_5133},
{"f_5137optimizer.scm",(void*)f_5137},
{"f_3958optimizer.scm",(void*)f_3958},
{"f_5117optimizer.scm",(void*)f_5117},
{"f_3962optimizer.scm",(void*)f_3962},
{"f_5112optimizer.scm",(void*)f_5112},
{"f_3965optimizer.scm",(void*)f_3965},
{"f_5107optimizer.scm",(void*)f_5107},
{"f_3968optimizer.scm",(void*)f_3968},
{"f_5002optimizer.scm",(void*)f_5002},
{"f_5005optimizer.scm",(void*)f_5005},
{"f_5100optimizer.scm",(void*)f_5100},
{"f_5062optimizer.scm",(void*)f_5062},
{"f_5083optimizer.scm",(void*)f_5083},
{"f_5075optimizer.scm",(void*)f_5075},
{"f_5022optimizer.scm",(void*)f_5022},
{"f_5052optimizer.scm",(void*)f_5052},
{"f_5044optimizer.scm",(void*)f_5044},
{"f_5028optimizer.scm",(void*)f_5028},
{"f_5032optimizer.scm",(void*)f_5032},
{"f_5012optimizer.scm",(void*)f_5012},
{"f_4983optimizer.scm",(void*)f_4983},
{"f_4305optimizer.scm",(void*)f_4305},
{"f_4970optimizer.scm",(void*)f_4970},
{"f_4971optimizer.scm",(void*)f_4971},
{"f_4940optimizer.scm",(void*)f_4940},
{"f_4939optimizer.scm",(void*)f_4939},
{"f_4935optimizer.scm",(void*)f_4935},
{"f_4317optimizer.scm",(void*)f_4317},
{"f_4326optimizer.scm",(void*)f_4326},
{"f_4921optimizer.scm",(void*)f_4921},
{"f_4920optimizer.scm",(void*)f_4920},
{"f_4536optimizer.scm",(void*)f_4536},
{"f_4906optimizer.scm",(void*)f_4906},
{"f_4539optimizer.scm",(void*)f_4539},
{"f_4547optimizer.scm",(void*)f_4547},
{"f_4876optimizer.scm",(void*)f_4876},
{"f_4882optimizer.scm",(void*)f_4882},
{"f_4557optimizer.scm",(void*)f_4557},
{"f_4599optimizer.scm",(void*)f_4599},
{"f_4866optimizer.scm",(void*)f_4866},
{"f_4771optimizer.scm",(void*)f_4771},
{"f_4786optimizer.scm",(void*)f_4786},
{"f_4797optimizer.scm",(void*)f_4797},
{"f_4844optimizer.scm",(void*)f_4844},
{"f_4830optimizer.scm",(void*)f_4830},
{"f_4822optimizer.scm",(void*)f_4822},
{"f_4809optimizer.scm",(void*)f_4809},
{"f_4810optimizer.scm",(void*)f_4810},
{"f_4801optimizer.scm",(void*)f_4801},
{"f_4791optimizer.scm",(void*)f_4791},
{"f_4613optimizer.scm",(void*)f_4613},
{"f_4652optimizer.scm",(void*)f_4652},
{"f_4658optimizer.scm",(void*)f_4658},
{"f_4664optimizer.scm",(void*)f_4664},
{"f_4708optimizer.scm",(void*)f_4708},
{"f_4684optimizer.scm",(void*)f_4684},
{"f_4688optimizer.scm",(void*)f_4688},
{"f_4676optimizer.scm",(void*)f_4676},
{"f_4646optimizer.scm",(void*)f_4646},
{"f_4633optimizer.scm",(void*)f_4633},
{"f_4634optimizer.scm",(void*)f_4634},
{"f_4560optimizer.scm",(void*)f_4560},
{"f_4563optimizer.scm",(void*)f_4563},
{"f_4566optimizer.scm",(void*)f_4566},
{"f_4585optimizer.scm",(void*)f_4585},
{"f_4584optimizer.scm",(void*)f_4584},
{"f_4576optimizer.scm",(void*)f_4576},
{"f_4526optimizer.scm",(void*)f_4526},
{"f_4525optimizer.scm",(void*)f_4525},
{"f_4517optimizer.scm",(void*)f_4517},
{"f_4516optimizer.scm",(void*)f_4516},
{"f_4512optimizer.scm",(void*)f_4512},
{"f_4399optimizer.scm",(void*)f_4399},
{"f_4498optimizer.scm",(void*)f_4498},
{"f_4497optimizer.scm",(void*)f_4497},
{"f_4417optimizer.scm",(void*)f_4417},
{"f_4485optimizer.scm",(void*)f_4485},
{"f_4477optimizer.scm",(void*)f_4477},
{"f_4420optimizer.scm",(void*)f_4420},
{"f_4456optimizer.scm",(void*)f_4456},
{"f_4454optimizer.scm",(void*)f_4454},
{"f_4429optimizer.scm",(void*)f_4429},
{"f_4446optimizer.scm",(void*)f_4446},
{"f_4445optimizer.scm",(void*)f_4445},
{"f_4437optimizer.scm",(void*)f_4437},
{"f_4378optimizer.scm",(void*)f_4378},
{"f_4362optimizer.scm",(void*)f_4362},
{"f_4329optimizer.scm",(void*)f_4329},
{"f_4335optimizer.scm",(void*)f_4335},
{"f_4338optimizer.scm",(void*)f_4338},
{"f_4357optimizer.scm",(void*)f_4357},
{"f_4356optimizer.scm",(void*)f_4356},
{"f_4348optimizer.scm",(void*)f_4348},
{"f_4127optimizer.scm",(void*)f_4127},
{"f_4226optimizer.scm",(void*)f_4226},
{"f_4231optimizer.scm",(void*)f_4231},
{"f_4238optimizer.scm",(void*)f_4238},
{"f_4274optimizer.scm",(void*)f_4274},
{"f_4258optimizer.scm",(void*)f_4258},
{"f_4250optimizer.scm",(void*)f_4250},
{"f_4132optimizer.scm",(void*)f_4132},
{"f_4150optimizer.scm",(void*)f_4150},
{"f_4157optimizer.scm",(void*)f_4157},
{"f_4200optimizer.scm",(void*)f_4200},
{"f_4203optimizer.scm",(void*)f_4203},
{"f_4193optimizer.scm",(void*)f_4193},
{"f_4177optimizer.scm",(void*)f_4177},
{"f_4169optimizer.scm",(void*)f_4169},
{"f_4138optimizer.scm",(void*)f_4138},
{"f_4144optimizer.scm",(void*)f_4144},
{"f_4064optimizer.scm",(void*)f_4064},
{"f_4096optimizer.scm",(void*)f_4096},
{"f_4105optimizer.scm",(void*)f_4105},
{"f_4112optimizer.scm",(void*)f_4112},
{"f_4067optimizer.scm",(void*)f_4067},
{"f_4088optimizer.scm",(void*)f_4088},
{"f_4089optimizer.scm",(void*)f_4089},
{"f_3983optimizer.scm",(void*)f_3983},
{"f_3987optimizer.scm",(void*)f_3987},
{"f_3999optimizer.scm",(void*)f_3999},
{"f_4028optimizer.scm",(void*)f_4028},
{"f_4005optimizer.scm",(void*)f_4005},
{"f_4020optimizer.scm",(void*)f_4020},
{"f_4021optimizer.scm",(void*)f_4021},
{"f_4016optimizer.scm",(void*)f_4016},
{"f_3710optimizer.scm",(void*)f_3710},
{"f_3724optimizer.scm",(void*)f_3724},
{"f_3952optimizer.scm",(void*)f_3952},
{"f_3727optimizer.scm",(void*)f_3727},
{"f_3947optimizer.scm",(void*)f_3947},
{"f_3730optimizer.scm",(void*)f_3730},
{"f_3942optimizer.scm",(void*)f_3942},
{"f_3937optimizer.scm",(void*)f_3937},
{"f_3929optimizer.scm",(void*)f_3929},
{"f_3924optimizer.scm",(void*)f_3924},
{"f_3901optimizer.scm",(void*)f_3901},
{"f_3904optimizer.scm",(void*)f_3904},
{"f_3910optimizer.scm",(void*)f_3910},
{"f_3794optimizer.scm",(void*)f_3794},
{"f_3882optimizer.scm",(void*)f_3882},
{"f_3894optimizer.scm",(void*)f_3894},
{"f_3880optimizer.scm",(void*)f_3880},
{"f_3805optimizer.scm",(void*)f_3805},
{"f_3828optimizer.scm",(void*)f_3828},
{"f_3866optimizer.scm",(void*)f_3866},
{"f_3872optimizer.scm",(void*)f_3872},
{"f_3834optimizer.scm",(void*)f_3834},
{"f_3838optimizer.scm",(void*)f_3838},
{"f_3841optimizer.scm",(void*)f_3841},
{"f_3864optimizer.scm",(void*)f_3864},
{"f_3852optimizer.scm",(void*)f_3852},
{"f_3811optimizer.scm",(void*)f_3811},
{"f_3817optimizer.scm",(void*)f_3817},
{"f_3821optimizer.scm",(void*)f_3821},
{"f_3825optimizer.scm",(void*)f_3825},
{"f_3803optimizer.scm",(void*)f_3803},
{"f_3742optimizer.scm",(void*)f_3742},
{"f_3759optimizer.scm",(void*)f_3759},
{"f_3733optimizer.scm",(void*)f_3733},
{"f_3613optimizer.scm",(void*)f_3613},
{"f_3704optimizer.scm",(void*)f_3704},
{"f_3703optimizer.scm",(void*)f_3703},
{"f_3617optimizer.scm",(void*)f_3617},
{"f_3628optimizer.scm",(void*)f_3628},
{"f_3638optimizer.scm",(void*)f_3638},
{"f_3687optimizer.scm",(void*)f_3687},
{"f_3685optimizer.scm",(void*)f_3685},
{"f_3644optimizer.scm",(void*)f_3644},
{"f_3650optimizer.scm",(void*)f_3650},
{"f_3677optimizer.scm",(void*)f_3677},
{"f_3656optimizer.scm",(void*)f_3656},
{"f_3620optimizer.scm",(void*)f_3620},
{"f_3609optimizer.scm",(void*)f_3609},
{"f_3594optimizer.scm",(void*)f_3594},
{"f_3603optimizer.scm",(void*)f_3603},
{"f_3602optimizer.scm",(void*)f_3602},
{"f_3579optimizer.scm",(void*)f_3579},
{"f_3588optimizer.scm",(void*)f_3588},
{"f_3587optimizer.scm",(void*)f_3587},
{"f_3573optimizer.scm",(void*)f_3573},
{"f_3349optimizer.scm",(void*)f_3349},
{"f_3370optimizer.scm",(void*)f_3370},
{"f_3382optimizer.scm",(void*)f_3382},
{"f_3397optimizer.scm",(void*)f_3397},
{"f_3556optimizer.scm",(void*)f_3556},
{"f_3401optimizer.scm",(void*)f_3401},
{"f_3551optimizer.scm",(void*)f_3551},
{"f_3404optimizer.scm",(void*)f_3404},
{"f_3546optimizer.scm",(void*)f_3546},
{"f_3407optimizer.scm",(void*)f_3407},
{"f_3449optimizer.scm",(void*)f_3449},
{"f_3468optimizer.scm",(void*)f_3468},
{"f_3479optimizer.scm",(void*)f_3479},
{"f_3452optimizer.scm",(void*)f_3452},
{"f_3422optimizer.scm",(void*)f_3422},
{"f_3385optimizer.scm",(void*)f_3385},
{"f_3391optimizer.scm",(void*)f_3391},
{"f_3373optimizer.scm",(void*)f_3373},
{"f_3376optimizer.scm",(void*)f_3376},
{"f_3380optimizer.scm",(void*)f_3380},
{"f_3352optimizer.scm",(void*)f_3352},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
